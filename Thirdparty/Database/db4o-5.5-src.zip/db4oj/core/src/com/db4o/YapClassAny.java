/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o;

import com.db4o.inside.marshall.*;
import com.db4o.reflect.*;


/**
 * Undefined YapClass used for members of type Object.
 */
final class YapClassAny extends YapClass {
    
	public YapClassAny(YapStream stream){
		super(stream, stream.i_handlers.ICLASS_OBJECT);
	}

	public boolean canHold(ReflectClass claxx) {
		return true;
	}

	public void cascadeActivation(
		Transaction a_trans,
		Object a_object,
		int a_depth,
		boolean a_activate) {
		YapClass yc = forObject(a_trans, a_object, false);
		if (yc != null) {
			yc.cascadeActivation(a_trans, a_object, a_depth, a_activate);
		}
	}
    
	public void deleteEmbedded(MarshallerFamily mf, YapWriter reader) {
        mf._untyped.deleteEmbedded(reader);
	}
	
	public int getID() {
		return 11;
	}

	public boolean hasField(YapStream a_stream, String a_path) {
		return a_stream.i_classCollection.fieldExists(a_path);
	}
	
	boolean hasIndex() {
	    return false;
	}
    
    public boolean hasFixedLength(){
        return false;
    }

	public boolean holdsAnyClass() {
		return true;
	}
    
    public int isSecondClass(){
        return YapConst.UNKNOWN;
    }
	
	boolean isStrongTyped(){
		return false;
	}
    
    public void calculateLengths(Transaction trans, ObjectHeaderAttributes header, boolean topLevel, Object obj, boolean withIndirection) {
        if(topLevel){
            header.addBaseLength(YapConst.YAPINT_LENGTH); 
        }else{
            header.addPayLoadLength(YapConst.YAPINT_LENGTH);  // single relink
        }
        YapClass yc = forObject(trans, obj, true);
        if( yc == null){
            return;
        }
        header.addPayLoadLength(YapConst.YAPINT_LENGTH); //  type information int
        yc.calculateLengths(trans, header, false, obj, false);
    }
    
    public Object read(MarshallerFamily mf, YapWriter a_bytes, boolean redirect) throws CorruptionException{
        if(mf._untyped.useNormalClassRead()){
            return super.read(mf, a_bytes, redirect);
        }
        return mf._untyped.read(a_bytes);
    }

	public TypeHandler4 readArrayHandler(Transaction a_trans, MarshallerFamily mf, YapReader[] a_bytes) {
        return mf._untyped.readArrayHandler(a_trans, a_bytes);
	}
    
    public Object readQuery(Transaction trans, MarshallerFamily mf, boolean withRedirection, YapReader reader, boolean toArray) throws CorruptionException{
        if(mf._untyped.useNormalClassRead()){
            return super.readQuery(trans, mf, withRedirection, reader, toArray);
        }
        return mf._untyped.readQuery(trans, reader, toArray);
    }
    
    public QCandidate readSubCandidate(MarshallerFamily mf, YapReader reader, QCandidates candidates, boolean withIndirection) {
        if(mf._untyped.useNormalClassRead()){
            return super.readSubCandidate(mf, reader, candidates, withIndirection);
        }
        return mf._untyped.readSubCandidate(reader, candidates, withIndirection);
    } 
	
    public boolean supportsIndex() {
        return false;
    }
    
    public Object writeNew(MarshallerFamily mf, Object obj, boolean topLevel, YapWriter writer, boolean withIndirection, boolean restoreLinkeOffset) {
        return mf._untyped.writeNew(obj, restoreLinkeOffset, writer);
    }


}
