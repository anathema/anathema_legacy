/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.btree;

import com.db4o.*;
import com.db4o.foundation.*;


public abstract class BTreePatch {
    
    protected BTreePatch _previous;
    
    protected BTreePatch _next;
    
    protected final Transaction _transaction;
    
    final Object _object;

    public BTreePatch(Transaction transaction, Object obj) {
        _transaction = transaction;
        _object = obj;
    }
    
    public BTreePatch append(BTreePatch patch){
        if(_transaction == patch._transaction){
            patch._next = _next;
            return patch;
        }
        if(_next == null){
            _next = patch;
        }else{
            _next = _next.append(patch);
        }
        return this;
    }
    
    public Object commit(Transaction trans, BTree btree){
        return commit(trans, btree, true);
    }
    
    private Object commit(Transaction trans, BTree btree, boolean firstInList){
        if(_transaction == trans){
            if(_next != null){
                return _next;
            }
            return committed(btree);
        }
        if(_next != null){
            Object newNext = _next.commit(trans, btree, false);
            if(newNext instanceof BTreePatch){
                _next = (BTreePatch)newNext;
            } else{
                _next = null;
            }
        }
        return this;
    }
    
    protected abstract Object committed(BTree btree);
    
    public BTreePatch forTransaction(Transaction trans){
        if(_transaction == trans){
            return this;
        }
        if(_next == null){
            return null;
        }
        return _next.forTransaction(trans);
    }
    
    public Object getObject(Transaction trans){
        BTreePatch patch = forTransaction(trans);
        if(patch == null){
            return No4.INSTANCE;
        }
        return patch.getObject();
    }
    
    protected abstract Object getObject();
    
    public Object rollback(Transaction trans, BTree btree){
        return rollback(trans, btree, true);
    }
    
    
    public Object rollback(Transaction trans, BTree btree, boolean firstInList){
        if(_transaction == trans){
            if(_next != null){
                return _next;
            }
            return rolledBack(btree);
        }
        if(_next != null){
            Object newNext = _next.rollback(trans, btree, false);
            if(newNext instanceof BTreePatch){
                _next = (BTreePatch)newNext;
            } else{
                _next = null;
            }
        }
        return this;
    }
    
    protected abstract Object rolledBack(BTree btree);
    
    public String toString(){
        if(_object == null){
            return "[NULL]";
        }
        return _object.toString();
    }
    

}
