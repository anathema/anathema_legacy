/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.marshall;

import com.db4o.*;
import com.db4o.inside.*;


/**
 * @exclude
 */
public class UntypedMarshaller0 extends UntypedMarshaller {
    
    public void deleteEmbedded(YapWriter parentBytes) {
        int objectID = parentBytes.readInt();
        if (objectID > 0) {
            YapWriter reader =
                parentBytes.getStream().readWriterByID(parentBytes.getTransaction(), objectID);
            if (reader != null) {
                reader.setCascadeDeletes(parentBytes.cascadeDeletes());
                ObjectHeader oh = new ObjectHeader(reader);
                if(oh._yapClass != null){
                    oh._yapClass.deleteEmbedded1(_family, reader, objectID);
                }
            }
        }
    }
    
    public boolean useNormalClassRead(){
        return true;
    }


    public Object read(YapWriter reader) {
        throw Exceptions4.shouldNeverBeCalled();
    }
    
    public Object readQuery(Transaction trans, YapReader reader, boolean toArray) throws CorruptionException{
        throw Exceptions4.shouldNeverBeCalled();
    }

    
    public TypeHandler4 readArrayHandler(Transaction a_trans, YapReader[] a_bytes) {
        int id = 0;

        int offset = a_bytes[0]._offset;
        try {
            id = a_bytes[0].readInt();
        } catch (Exception e) {
        }
        a_bytes[0]._offset = offset;

        if (id != 0) {
            YapWriter reader =
                a_trans.i_stream.readWriterByID(a_trans, id);
            if (reader != null) {
                ObjectHeader oh = new ObjectHeader(reader);
                try {
                    if (oh._yapClass != null) {
                        a_bytes[0] = reader;
                        return oh._yapClass.readArrayHandler1(a_bytes);
                    }
                } catch (Exception e) {
                    
                    if(Debug.atHome){
                        e.printStackTrace();
                    }
                    
                    // TODO: Check Exception Types
                    // Errors typically occur, if classes don't match
                }
            }
        }
        return null;
    }

    public QCandidate readSubCandidate(YapReader reader, QCandidates candidates, boolean withIndirection) {
        return null;
    }

    public Object writeNew(Object a_object, boolean restoreLinkOffset, YapWriter a_bytes) {
        if (a_object == null) {
            a_bytes.writeInt(0);
            return new Integer(0);
        }

        int id = a_bytes.getStream().setInternal(
                    a_bytes.getTransaction(),
                    a_object,
                    a_bytes.getUpdateDepth(), true);
        
        a_bytes.writeInt(id);
        return new Integer(id);
    }

    


}
