/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.btree;


/**
 * @exclude
 */
public class Searcher {
    
    public int _lower;
    
    public int _upper;
    
    public int _cursor;
    
    public int _cmp;
    
    private int _target;
    
    private static final int ANY = 0;
    
    private static final int HIGHEST = 1;
    
    private static final int LOWEST = -1;
    
    
    public Searcher(int count){
        start(count);
    }
    
    public void start(int count){
        _lower = 0;
        _upper = count - 1;
        _cursor = -1;
    }
    
    public boolean incomplete() {
        if (_upper < _lower) {
            return false;
        }
        int oldCursor = _cursor;
        _cursor = _lower + ((_upper - _lower) / 2);
        if (_cursor == oldCursor && _cursor == _lower && _lower < _upper) {
            _cursor ++;
        }
        return _cursor != oldCursor;
    }
    
    void resultIs(int cmp){
        
        _cmp = cmp;
        
        if(cmp > 0){
            _upper = _cursor - 1;
            if (_upper < _lower) {
                _upper = _lower;
            }
            return;
        }
        
        if (cmp < 0) {
            _lower = _cursor + 1;
            if (_lower > _upper) {
                _lower = _upper;
            }
            return;
        }
        
        if(_target == ANY){
            _lower = _cursor;
            _upper = _cursor;
            return;
        }
        
        if(_target == HIGHEST){
            _lower = _cursor;
            return;
        }

        // _target must be LOWEST here
        _upper = _cursor;
        
    }
    
    void highest(){
        _target = HIGHEST;
    }
    
    void lowest(){
        _target = LOWEST;
    }

}
