/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.marshall;

import com.db4o.*;
import com.db4o.inside.*;

/**
 * @exclude
 */
public class UntypedMarshaller1 extends UntypedMarshaller{
    
    public boolean useNormalClassRead(){
        return false;
    }
    
    public void deleteEmbedded(YapWriter reader) {
        int payLoadOffset = reader.readInt();
        if (payLoadOffset > 0) {
            int linkOffset = reader._offset;
            reader._offset = payLoadOffset;
            int yapClassID = reader.readInt();
            YapClass yc = reader.getStream().getYapClass(yapClassID);
            if(yc != null){
                yc.deleteEmbedded(_family, reader);
            }
            reader._offset = linkOffset;
        }
    }
    
    public Object read(YapWriter reader) throws CorruptionException{
        
        Object ret = null;
        
        int payLoadOffSet = reader.readInt();
        if(payLoadOffSet == 0){
            return null;
        }
        
        int linkOffSet = reader._offset;
        reader._offset = payLoadOffSet;
        
        int yapClassID = reader.readInt();
        
        YapClass yc = reader.getStream().getYapClass(yapClassID);
        if(yc != null){
            ret = yc.read(_family, reader, true);
        }
        
        reader._offset = linkOffSet;
        
        return ret;
    }
    
    public Object readQuery(Transaction trans, YapReader reader, boolean toArray) throws CorruptionException{
        
        Object ret = null;
        
        int payLoadOffSet = reader.readInt();
        if(payLoadOffSet == 0){
            return null;
        }
        
        int linkOffSet = reader._offset;
        reader._offset = payLoadOffSet;
        
        int yapClassID = reader.readInt();
        
        YapClass yc = trans.i_stream.getYapClass(yapClassID);
        if(yc != null){
            ret = yc.readQuery(trans, _family, false, reader, toArray);
        }
        
        reader._offset = linkOffSet;
        
        return ret;
    }

    
    public TypeHandler4 readArrayHandler(Transaction trans, YapReader[] reader) {
        
        int payLoadOffSet = reader[0].readInt();
        if(payLoadOffSet == 0){
            return null;
        }

        TypeHandler4 ret = null;

        int linkOffSet = reader[0]._offset;
        reader[0]._offset = payLoadOffSet;
        
        int yapClassID = reader[0].readInt();
        
        YapClass yc = trans.i_stream.getYapClass(yapClassID);
        if(yc != null){
            ret = yc.readArrayHandler(trans, _family, reader);
        }
        return ret;
    }
    
    public QCandidate readSubCandidate(YapReader reader, QCandidates candidates, boolean withIndirection) {
        int payLoadOffSet = reader.readInt();
        if(payLoadOffSet == 0){
            return null;
        }
        
        QCandidate ret = null;

        int linkOffSet = reader._offset;
        reader._offset = payLoadOffSet;
        
        int yapClassID = reader.readInt();
        
        YapClass yc = candidates.i_trans.i_stream.getYapClass(yapClassID);
        if(yc != null){
            ret = yc.readSubCandidate(_family, reader, candidates, false);
        }
        reader._offset = linkOffSet;
        
        return ret;
    }

    
    public Object writeNew(Object obj, boolean restoreLinkOffset, YapWriter writer) {
        if (obj == null) {
            writer.writeInt(0);
            return new Integer(0);
        }
        
        YapClass yc = YapClass.forObject(writer.getTransaction(), obj, false);
        
        if(yc == null){
            writer.writeInt(0);
            return new Integer(0);
        }
        
        
        writer.writeInt(writer._payloadOffset);
        int linkOffset = writer._offset;
        writer._offset = writer._payloadOffset;
        
        
        writer.writeInt(yc.getID());
        
        yc.writeNew(_family, obj, false, writer, false, false);
        
        if(writer._payloadOffset < writer._offset){
            writer._payloadOffset = writer._offset;
        }
        
        if(restoreLinkOffset){
            writer._offset = linkOffset;
        }
        
        return obj;
    }

}
