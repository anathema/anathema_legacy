/* Copyright (C) 2004 - 2005  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o;

import com.db4o.ext.*;

/**
 * @exclude
 */
class QResult extends IntArrayList implements ObjectSet, ExtObjectSet, Visitor4 {
	Tree i_candidates;
	boolean i_checkDuplicates;
	// Iterator4 i_iterator;
	final Transaction i_trans;

	QResult(Transaction a_trans) {
		i_trans = a_trans;
	}
    
    QResult(Transaction trans, int initialSize){
        super(initialSize);
        i_trans = trans;
    }

	final Object activate(Object obj){
		YapStream stream = i_trans.i_stream;
		stream.beginEndActivation();
		stream.activate2(i_trans, obj, stream.i_config.i_activationDepth);
		stream.beginEndActivation();
		return obj;
	}

	final void checkDuplicates(){
		i_checkDuplicates = true;
	}

	public ExtObjectSet ext() {
		return this;
	}

	public long[] getIDs() {
		synchronized (streamLock()) {
		    return asLong();
		}
	}

	public boolean hasNext() {
		synchronized (streamLock()) {
			return super.hasNext();
		}
	}

	public Object next() {
		synchronized (streamLock()) {
			YapStream stream = i_trans.i_stream;
			stream.checkClosed();
			if (super.hasNext()) {
				Object ret = stream.getByID2(i_trans, nextInt());
				if (ret == null) {
					return next();
				}
				return activate(ret);
			}
			return null;
		}
	}

	public void reset() {
		synchronized (streamLock()) {
		    super.reset();
		}
	}

	public void visit(Object a_tree) {
		QCandidate candidate = (QCandidate) a_tree;
		if (candidate.include()) {
		    addKeyCheckDuplicates(candidate.i_key);
		}
	}
	
	void addKeyCheckDuplicates(int a_key){
	    if(i_checkDuplicates){
	        TreeInt newNode = new TreeInt(a_key);
	        i_candidates = Tree.add(i_candidates, newNode);
	        if(newNode.i_size == 0){
	            return;
	        }
	    }
	    
	    // TODO: It would be more efficient to hold TreeInts
	    // here only but it won't work, in case an ordering
	    // is applied. Modify to hold a tree here, in case
	    // there is no ordering.
	    
	    add(a_key);
	    
	}
	
	protected Object streamLock(){
		return i_trans.i_stream.i_lock;
	}

}
