/* Copyright (C) 2004 - 2005  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o;

class PendingClassInits {
	
	private final YapClassCollection _classColl;
	
	private Collection4 _pending = new Collection4();

	private List4 _members;
	private List4 _statics;
	private List4 _writes;
	
	private boolean _running = false;
	
	PendingClassInits(YapClassCollection classColl){
		_classColl = classColl;
	}
	
	void process(YapClass newYapClass) {
		
		if(_pending.contains(newYapClass)) {
			return;
		}
		
        YapClass ancestor = newYapClass.getAncestor();
        if (ancestor != null) {
            process(ancestor);
        }
		
		_pending.add(newYapClass);
		_members = new List4(_members, newYapClass);
		
		if(_running) {
			return;
		}
		
		_running = true;
		
		checkWrites();
		
		_pending = new Collection4();
		
		_running = false;
	}

	
	private void checkMembers() {
		while(_members != null) {
			Iterator4 members = new Iterator4(_members);
			_members = null;
			while(members.hasNext()) {
				YapClass yc = (YapClass)members.next();
				yc.addMembers(_classColl.i_stream);
				_statics = new List4(_statics, yc);
			}
		}
	}
	
	private void checkStatics() {
		checkMembers();
		while(_statics != null) {
			Iterator4 statics = new Iterator4(_statics);
			_statics = null;
			while(statics.hasNext()) {
				YapClass yc = (YapClass)statics.next();
				yc.storeStaticFieldValues(_classColl.i_systemTrans, true);
				_writes = new List4(_writes, yc);
				checkMembers();
			}
		}
	}
	
	private void checkWrites() {
		checkStatics();
		while(_writes != null) {
			Iterator4 writes = new Iterator4(_writes);
			_writes = null;
			while(writes.hasNext()) {
				YapClass yc = (YapClass)writes.next();
		        yc.setStateDirty();
		        yc.write(_classColl.i_stream, _classColl.i_systemTrans);
				checkStatics();
			}
		}
	}

}
