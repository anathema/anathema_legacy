/* Copyright (C) 2004 - 2005  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o;

import java.io.*;

/**
 * Fakes a socket connection for an embedded client.
 */
class YapSocketFake extends YapSocket {
	
	final YapServer i_server;

    private YapSocketFake i_affiliate;
    private ByteBuffer4 i_uploadBuffer;
    private ByteBuffer4 i_downloadBuffer;

    public YapSocketFake(YapServer a_server) {
    	i_server = a_server;
        i_uploadBuffer = new ByteBuffer4(((Config4Impl)a_server.configure()).i_timeoutClientSocket);
        i_downloadBuffer = new ByteBuffer4(((Config4Impl)a_server.configure()).i_timeoutClientSocket);
    }

    public YapSocketFake(YapServer a_server, YapSocketFake affiliate) {
        this(a_server);
        i_affiliate = affiliate;
        affiliate.i_affiliate = this;
        i_downloadBuffer = affiliate.i_uploadBuffer;
        i_uploadBuffer = affiliate.i_downloadBuffer;
    }

    public void close() throws IOException {
        if (i_affiliate != null) {
            YapSocketFake temp = i_affiliate;
            i_affiliate = null;
            temp.close();
        }
        i_affiliate = null;

    }

    public void flush() {
        // do nothing
    }

    public String getHostName() {
        return null;
    }

    public boolean isClosed() {
        return i_affiliate == null;
    }

    public int read() throws IOException {
        return i_downloadBuffer.read();
    }

    public int read(byte[] a_bytes, int a_offset, int a_length) throws IOException {
        return i_downloadBuffer.read(a_bytes, a_offset, a_length);
    }

    public void setSoTimeout(int a_timeout) {
        i_uploadBuffer.setTimeout(a_timeout);
        i_downloadBuffer.setTimeout(a_timeout);
    }

    public void write(byte[] bytes) throws IOException {
        i_uploadBuffer.write(bytes);
    }

    public void write(int i) throws IOException {
        i_uploadBuffer.write(i);
    }
}
