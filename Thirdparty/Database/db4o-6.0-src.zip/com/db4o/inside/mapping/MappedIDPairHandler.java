/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.mapping;

import com.db4o.*;
import com.db4o.foundation.*;
import com.db4o.inside.ix.*;

/**
 * @exclude
 */
public class MappedIDPairHandler implements Indexable4 {

	private final YInt _origHandler;
	private final YInt _mappedHandler;
	
	public MappedIDPairHandler(YapStream stream) {
		_origHandler=new YInt(stream);
		_mappedHandler=new YInt(stream);
	}

	public Object comparableObject(Transaction trans, Object indexEntry) {
        throw new NotImplementedException();
	}

	public void defragIndexEntry(ReaderPair readers) {
        throw new NotImplementedException();
	}

	public int linkLength() {
		return _origHandler.linkLength()+_mappedHandler.linkLength();
	}

	public Object readIndexEntry(YapReader reader) {
		int origID=readID(reader);
		int mappedID=readID(reader);
        return new MappedIDPair(origID,mappedID);
	}

	public void writeIndexEntry(YapReader reader, Object obj) {
		MappedIDPair mappedIDs=(MappedIDPair)obj;
		_origHandler.writeIndexEntry(reader, new Integer(mappedIDs.orig()));
		_mappedHandler.writeIndexEntry(reader, new Integer(mappedIDs.mapped()));
	}

	public int compareTo(Object obj) {
        return _origHandler.compareTo(((MappedIDPair)obj).orig());
	}

	public Object current() {
		return new MappedIDPair(_origHandler.currentInt(),_mappedHandler.currentInt());
	}

	public boolean isEqual(Object obj) {
    	throw new NotImplementedException();
	}

	public boolean isGreater(Object obj) {
    	throw new NotImplementedException();
	}

	public boolean isSmaller(Object obj) {
    	throw new NotImplementedException();
	}

	public YapComparable prepareComparison(Object obj) {
        MappedIDPair mappedIDs = (MappedIDPair)obj;
        _origHandler.prepareComparison(mappedIDs.orig());
        _mappedHandler.prepareComparison(mappedIDs.mapped());
        return this;
	}
	
	private int readID(YapReader a_reader) {
		return ((Integer)_origHandler.readIndexEntry(a_reader)).intValue();
	}
}
