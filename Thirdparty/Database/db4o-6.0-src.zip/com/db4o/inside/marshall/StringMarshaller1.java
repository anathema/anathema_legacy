/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.marshall;

import com.db4o.*;


public class StringMarshaller1 extends StringMarshaller{
	
    private static final int DEFRAGMENT_INCREMENT_OFFSET = YapConst.INT_LENGTH * 2;  
    
    public boolean inlinedStrings(){
        return true;
    }
    
    public void calculateLengths(Transaction trans, ObjectHeaderAttributes header, boolean topLevel, Object obj, boolean withIndirection) {
        
        if(topLevel){
            header.addBaseLength(linkLength());
            header.prepareIndexedPayLoadEntry(trans);
        }else{
            if(withIndirection){
                header.addPayLoadLength(linkLength());
            }
        }
        
        if(obj == null){
            return;
        }
        
        header.addPayLoadLength(trans.stream().stringIO().length((String)obj));
    }
    
    public Object writeNew(Object obj, boolean topLevel, YapWriter writer, boolean redirect) {
        
        YapStream stream = writer.getStream();
        String str = (String) obj;
        
        if(! redirect){
            if(str != null){
                writeShort(stream,str , writer);
            }
            // TODO:  Really we should return a YapWriter for indexing but
            //        for now it's not needed since this is used for untyped
            //        references only which are not indexed.
            return str;  
        }
        
        if (str == null) {
            writer.writeEmbeddedNull();
            return null;
        }
        
        int length = stream.stringIO().length(str);
        
        YapWriter bytes = new YapWriter(writer.getTransaction(), length);
        writeShort(stream, str, bytes);
        
        writer.writePayload(bytes, topLevel);
        return bytes;
    }
    
    public YapReader readIndexEntry(YapWriter parentSlot) throws CorruptionException{
        int payLoadOffSet = parentSlot.readInt();
        int length = parentSlot.readInt();
        if(payLoadOffSet == 0){
            return null;
        }
        return parentSlot.readPayloadWriter(payLoadOffSet, length);
    }
    
    public YapReader readSlotFromParentSlot(YapStream stream, YapReader reader) throws CorruptionException {
        int payLoadOffSet = reader.readInt();
        int length = reader.readInt();
        if(payLoadOffSet == 0){
            return null;
        }
        return reader.readPayloadReader(payLoadOffSet, length);
    }

	public void defrag(SlotReader reader) {
		reader.incrementOffset(DEFRAGMENT_INCREMENT_OFFSET);
	}

}
