/* Copyright (C) 2004 - 2006  db4objects Inc.  http://www.db4o.com

This file is part of the db4o open source object database.

db4o is free software; you can redistribute it and/or modify it under
the terms of version 2 of the GNU General Public License as published
by the Free Software Foundation and as clarified by db4objects' GPL 
interpretation policy, available at
http://www.db4o.com/about/company/legalpolicies/gplinterpretation/
Alternatively you can write to db4objects, Inc., 1900 S Norfolk Street,
Suite 350, San Mateo, CA 94403, USA.

db4o is distributed in the hope that it will be useful, but WITHOUT ANY
WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
59 Temple Place - Suite 330, Boston, MA  02111-1307, USA. */
package com.db4o.inside.marshall;

import com.db4o.*;
import com.db4o.inside.btree.*;

/**
 * @exclude
 */
public class FieldMarshaller1 extends FieldMarshaller0 {
    
    private boolean hasBTreeIndex(YapField field){
        return ! field.isVirtual();
    }

    public void write(Transaction trans, YapClass clazz, YapField field, YapReader writer) {
        super.write(trans, clazz, field, writer);
        if(! hasBTreeIndex(field)){
            return;
        }
        writer.writeIDOf(trans, field.getIndex(trans));
    }

    public RawFieldSpec readSpec(YapStream stream, YapReader reader) {
    	RawFieldSpec spec=super.readSpec(stream, reader);
    	if(spec==null) {
    		return null;
    	}
		if (spec.isVirtual()) {
			return spec;
		}
        int indexID = reader.readInt();
        spec.indexID(indexID);
    	return spec;
    }
    
    protected YapField fromSpec(RawFieldSpec spec, YapStream stream, YapField field) {
		YapField actualField = super.fromSpec(spec, stream, field);
		if(spec==null) {
			return field;
		}
		if (spec.indexID() != 0) {
			actualField.initIndex(stream.getSystemTransaction(), spec.indexID());
		}
		return actualField;
	}
    
    public int marshalledLength(YapStream stream, YapField field) {
        int len = super.marshalledLength(stream, field);
        if(! hasBTreeIndex(field)){
            return len;
        }
        final int BTREE_ID = YapConst.ID_LENGTH;
        return  len + BTREE_ID;
    }

    public void defrag(YapClass yapClass, YapField yapField, YapStringIO sio,
    		final ReaderPair readers)
    		throws CorruptionException {
    	super.defrag(yapClass, yapField, sio, readers);
    	if(yapField.isVirtual()) {
    		return;
    	}
    	if(yapField.hasIndex()) {
        	BTree index = yapField.getIndex(readers.systemTrans());
    		int targetIndexID=readers.copyID();
    		if(targetIndexID!=0) {
    			index.defragBTree(readers.context());
    		}
    	}
    	else {
        	readers.writeInt(0);
    	}
    }
}
