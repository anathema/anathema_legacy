/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.provider.test;

import net.disy.commons.core.provider.IProvider;

public class DummyProvider<T> implements IProvider<T> {

  private T object;

  public DummyProvider(final T object) {
    setObject(object);
  }

  @Override
  public T getObject() {
    return object;
  }

  public void setObject(final T object) {
    this.object = object;
  }
}