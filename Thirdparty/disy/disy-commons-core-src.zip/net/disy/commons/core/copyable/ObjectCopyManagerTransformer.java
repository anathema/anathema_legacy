/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.copyable;

import java.text.MessageFormat;

import net.disy.commons.core.util.ITransformer;

public class ObjectCopyManagerTransformer<T> implements ITransformer<T, T> {

  private final Class<T> clazz;
  private final IObjectCopyManager<T> copyManager;

  public ObjectCopyManagerTransformer(IObjectCopyManager<T> copyManager, Class<T> clazz) {
    this.copyManager = copyManager;
    this.clazz = clazz;
  }

  @Override
  public T transform(T input) {
    try {
      T output = clazz.newInstance();
      copyManager.copy(input, output);
      return output;
    }
    catch (InstantiationException e) {
      throw new IllegalArgumentException(MessageFormat.format(
          "Cannot instatiate copyable class {0}, perhaps parameterless constructor is missing?", //$NON-NLS-1$
          clazz.getName()), e);
    }
    catch (IllegalAccessException e) {
      throw new IllegalArgumentException(MessageFormat.format("Cannot access copyable class {0}", //$NON-NLS-1$
          clazz.getName()), e);
    }
  }

}
