/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.copyable.test;


public class TestObjectToCopy {

  private String foo;

  private String complex;

  public TestObjectToCopy() {
  }

  public TestObjectToCopy(String foo) {
    this.foo = foo;
  }

  public String getFoo() {
    return foo;
  }

  public void setFoo(String foo) {
    this.foo = foo;
  }

  public String getComplex() {
    return complex;
  }

  public void setComplex(String complex) {
    this.complex = complex;
  }

}
