/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.copyable.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.copyable.ObjectCopyManagerTransformer;
import net.disy.commons.core.util.CollectionUtilities;

import org.junit.Test;

public class ObjectCopyManagerTransformerTest {

  @SuppressWarnings("nls")
  @Test
  public void test() {
    List<TestObjectToCopy> originalList = new ArrayList<TestObjectToCopy>();
    TestObjectToCopy dummy1 = new TestObjectToCopy("1");
    TestObjectToCopy dummy2 = new TestObjectToCopy("2");
    originalList.add(dummy1);
    originalList.add(dummy2);
    List<TestObjectToCopy> transformedList = CollectionUtilities.transform(
        originalList,
        new ObjectCopyManagerTransformer<TestObjectToCopy>(
            new TestObjectCopyManager(),
            TestObjectToCopy.class));
    assertThat(transformedList.size(), is(2));
    assertThat(transformedList.get(0).getFoo(), is("1"));
    assertThat(transformedList.get(1).getFoo(), is("2"));
    assertThat(transformedList.get(0), not(sameInstance(dummy1)));
    assertThat(transformedList.get(1), not(sameInstance(dummy2)));
  }
}
