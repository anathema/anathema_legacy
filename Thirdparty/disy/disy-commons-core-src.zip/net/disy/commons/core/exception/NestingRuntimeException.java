// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;

import java.io.PrintStream;
import java.io.PrintWriter;

/** @deprecated as of 29.08.2005 (preuss), use {@link java.lang.RuntimeException} instead*/
public class NestingRuntimeException extends RuntimeException {

  private Throwable nestedException;

  public NestingRuntimeException() {
    this(null, null);
  }

  public NestingRuntimeException(String s) {
    this(s, null);
  }

  public NestingRuntimeException(Throwable nestedException) {
    this(null, nestedException);
  }

  public NestingRuntimeException(String message, Throwable nestedException) {
    super(message);
    this.nestedException = nestedException;
  }

  public void printStackTrace() {
    printStackTrace(System.err);
  }

  public void printStackTrace(PrintStream ps) {
    // darf nicht an den PrintWriter weiterleiten, da dann die Ausgaben
    // verschluckt werden. Vermutlich weil der PrintWriter nicht geschlossen
    // wird
    synchronized (ps) {
      super.printStackTrace(ps);
      if (nestedException != null) {
        ps.println("nested Exception:"); //$NON-NLS-1$
        nestedException.printStackTrace(ps);
      }
    }
  }

  public void printStackTrace(PrintWriter pw) {
    synchronized (pw) {
      super.printStackTrace(pw);
      if (nestedException != null) {
        pw.println("nested Exception:"); //$NON-NLS-1$
        nestedException.printStackTrace(pw);
      }
    }
  }
  
  public Throwable getCause() {
    return nestedException;
  }
}