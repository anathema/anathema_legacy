/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.exception;

/**
 * Indicates a problem with a configuration file.
 * 
 * @published
 * @deprecated As of 01.09.2010 (gebhard): Problems in configuration files are problems one has to expect
 * and to deal with. So problems in configuration files should be indicated by checked exceptions
 * like <code>IOException</code> for example. This <code>ConfigurationException</code> is unchecked and
 * should no longer be used for this kind of problems. Please note that exchanging Exceptions has a huge
 * impact on existing APIs. So the <code>ConfigurationException</code> might persist longer than one year
 * (we usually tend to remove deprecated code within one year).
 */
@Deprecated
public class ConfigurationException extends RuntimeException {

  public ConfigurationException() {
    super();
  }

  public ConfigurationException(final String message) {
    super(message);
  }

  public ConfigurationException(final String message, final Throwable cause) {
    super(message, cause);
  }

  public ConfigurationException(final Throwable cause) {
    super(cause);
  }
}