package net.disy.commons.core.exception.test;

import javax.swing.SwingUtilities;

import junit.framework.TestCase;

import net.disy.commons.core.exception.CentralExceptionHandling;

public class CentralExceptionHandlerTest extends TestCase {
  private RuntimeException throwable;
  private MockExceptionHandler mockHandler;

  protected void setUp() throws Exception {
    super.setUp();
    mockHandler = new MockExceptionHandler();
    throwable = new RuntimeException("Exception"); //$NON-NLS-1$
    CentralExceptionHandling.setHandler(mockHandler);
  }

  public void testUnableToCatch() {
    mockHandler.setExpectedThrowable(null);

    Thread thread = new Thread(new Runnable() {
      public void run() {
        throw throwable;
      }
    });

    thread.start();

    while (thread.isAlive()) {
      try {
        Thread.sleep(50);
      }
      catch (InterruptedException e) {
        //nothing to do
      }
    }
    mockHandler.verify();
  }

  public void testThreadGroup() {
    mockHandler.setExpectedThrowable(throwable);

    Thread thread = new Thread(CentralExceptionHandling.createThreadGroup(), new Runnable() {
      public void run() {
        throw throwable;
      }
    });
    thread.start();

    while (thread.isAlive()) {
      try {
        Thread.sleep(50);
      }
      catch (InterruptedException e) {
        //nothing to do
      }
    }

    mockHandler.verify();
  }

  /* see JavaDoc documentation for java.awt.EventDispatchThread
  private boolean handleException(Throwable�thrown) */
  // TODO 24.10.2003 (preuss): wieder einf�hren, sobald zuverl�ssig
  public void _testEventDispatchThread() {
    mockHandler.setExpectedThrowable(throwable);

    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        throw throwable;
      }
    });

    try {
      Thread.sleep(50);
    }
    catch (InterruptedException e) {
      //nothing to do
    }

    mockHandler.verify();
  }
}
