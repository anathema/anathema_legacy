/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.exception.test;

import junit.framework.TestCase;

import net.disy.commons.core.exception.CentralExceptionHandling;

public class CentralExceptionHandlerTest extends TestCase {
  private RuntimeException throwable;
  private MockExceptionHandler mockHandler;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    mockHandler = new MockExceptionHandler();
    throwable = new RuntimeException("Exception"); //$NON-NLS-1$
    CentralExceptionHandling.setHandler(mockHandler);
  }

  public void testCatchesUncaught() throws InterruptedException {
    mockHandler.setExpectedThrowable(throwable);

    final Thread thread = new Thread(new Runnable() {
      @Override
      public void run() {
        throw throwable;
      }
    });

    thread.start();
    thread.join();
    mockHandler.verify();
  }
}