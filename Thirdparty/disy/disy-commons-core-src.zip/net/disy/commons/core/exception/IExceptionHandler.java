package net.disy.commons.core.exception;

/**
 * Common interface for any object able to handle a {@link java.lang.Throwable} object.
 * 
 * @author gebhard
 * @published
 */
public interface IExceptionHandler {
  /**
   * Handles the given {@link Throwable} object. 
   * @param exception the {@link Throwable} object to handle.
   * @published
   */
  public void handle(Throwable exception);
}