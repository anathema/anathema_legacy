package net.disy.commons.core.exception.test;


import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.util.ObjectUtilities;

/**
 * @author gebhard
 */
public class MockExceptionHandler implements IExceptionHandler {
  private Throwable expectedThrowable;
  private Throwable actualThrowable;

  public void setExpectedThrowable(Throwable expectedThrowable) {
    this.expectedThrowable = expectedThrowable;
  }

  public void verify() {
    if (!ObjectUtilities.equals(actualThrowable, expectedThrowable)) {
      throw new RuntimeException(
          "Verification failed\nExpected: " + expectedThrowable + " Actual: " + actualThrowable); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public void handle(Throwable exception) {
    actualThrowable = exception;
  }
}