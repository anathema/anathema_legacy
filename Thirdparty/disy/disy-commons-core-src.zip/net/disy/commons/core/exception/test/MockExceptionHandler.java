/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.exception.test;

import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.util.ObjectUtilities;

/**
 * @author gebhard
 */
public class MockExceptionHandler implements IExceptionHandler {
  private Throwable expectedThrowable;
  private Throwable actualThrowable;

  private final Object lock = new Object();

  public void setExpectedThrowable(final Throwable expectedThrowable) {
    this.expectedThrowable = expectedThrowable;
  }

  public void verify() {
    synchronized (lock) {
      if (!ObjectUtilities.equals(actualThrowable, expectedThrowable)) {
        try {
          lock.wait(5000);
          if (!ObjectUtilities.equals(actualThrowable, expectedThrowable)) {
            verificationFailed();
          }
        }
        catch (final InterruptedException e) {
          verificationFailed();
        }
      }
    }
  }

  private void verificationFailed() {
    final String baseMessage = "Verification failed. Expected: '" //$NON-NLS-1$
        + expectedThrowable
        + "' Actual: '" //$NON-NLS-1$
        + actualThrowable
        + "'."; //$NON-NLS-1$
    if (expectedThrowable != null && actualThrowable == null) {
      throw new RuntimeException(
          baseMessage
              + " For swing exception handlers a possible cause for this is that there already was an exception on the" //$NON-NLS-1$
              + " event dispatch thread before. Please check other tests not to have thrown exceptions."); //$NON-NLS-1$
    }
    throw new RuntimeException(baseMessage);
  }

  @Override
  public void handle(final Throwable exception) {
    synchronized (lock) {
      actualThrowable = exception;
      lock.notifyAll();
    }
  }
}