// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;

/** @published */
//Schmieder, FhG / LfU 8.10.2005
public class UnreachableCodeReachedException extends NestingRuntimeException {

  public UnreachableCodeReachedException() {
    this(null, null);
  }

  public UnreachableCodeReachedException(String s) {
    this(s, null);
  }

  /** @published */
  //Schmieder, FhG / LfU 8.10.2005
  public UnreachableCodeReachedException(Throwable nestedException) {
    this(null, nestedException);
  }

  public UnreachableCodeReachedException(String message, Throwable nestedException) {
    super(message, nestedException);
  }

}