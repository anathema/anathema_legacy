// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;

public class UnreachableCodeReachedException extends NestingRuntimeException {

  public UnreachableCodeReachedException() {
    this(null, null);
  }

  public UnreachableCodeReachedException(String s) {
    this(s, null);
  }

  public UnreachableCodeReachedException(Throwable nestedException) {
    this(null, nestedException);
  }

  public UnreachableCodeReachedException(String message, Throwable nestedException) {
    super(message, nestedException);
  }

}
