//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.exception.test;

import junit.framework.TestCase;

import net.disy.commons.core.exception.NestingRuntimeException;

// NOT_PUBLISHED
public class NestingRuntimeExceptionTest extends TestCase {
 
  public void testGetCause() {
    RuntimeException cause = new RuntimeException();
    NestingRuntimeException exception = new NestingRuntimeException(cause);
    assertSame(cause, exception.getCause());
  }
  
}