package net.disy.commons.core.exception;

public class PrintStackTraceExceptionHandler implements IExceptionHandler {

  public void handle(Throwable exception) {
    exception.printStackTrace();
  }

}