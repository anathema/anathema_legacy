//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;

import net.disy.commons.core.message.IMessage;

// NOT_PUBLISHED
public class MessageException extends Exception {

  private final IMessage message;

  public MessageException(IMessage message) {
    super(message.getText());
    this.message = message;
  }

  public IMessage getMessageObject() {
    return message;
  }

}
