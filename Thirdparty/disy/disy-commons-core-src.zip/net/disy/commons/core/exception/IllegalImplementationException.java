//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;


// NOT_PUBLISHED
public class IllegalImplementationException extends NestingRuntimeException {

  public IllegalImplementationException(String message) {
    super(message);
  }

}
