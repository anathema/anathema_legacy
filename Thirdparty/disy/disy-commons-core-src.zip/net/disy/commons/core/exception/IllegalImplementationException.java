//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.exception;

// NOT_PUBLISHED
public class IllegalImplementationException extends RuntimeException {

  public IllegalImplementationException(String message) {
    super(message);
  }

}
