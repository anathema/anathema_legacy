package net.disy.commons.core.exception;


/**
 * This class is intended only for internal use of the
 * {@link net.disy.commons.core.exception.CentralExceptionHandling}.
 * 
 * @author gebhard
 */
public class InternalAwtExceptionHandler implements IExceptionHandler {
  
  public InternalAwtExceptionHandler(){
    //Necessary for instanciation from the awt eventdispatch thread
  }

  public void handle(Throwable exception) {
    CentralExceptionHandling.getInstance().handle(exception);
  }
}