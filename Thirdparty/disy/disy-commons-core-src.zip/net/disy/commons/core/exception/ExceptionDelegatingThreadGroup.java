package net.disy.commons.core.exception;

/**
 * A {@link java.lang.ThreadGroup} delegating all uncaught {@link java.lang.Throwable}s
 * to the {@link CentralExceptionHandling} singleton.
 * 
 * @author gebhard
 */
public class ExceptionDelegatingThreadGroup extends ThreadGroup {

  public ExceptionDelegatingThreadGroup(String name) {
    super(name);
  }

  public ExceptionDelegatingThreadGroup(ThreadGroup parent, String name){
    super(parent, name);
  }

  public void uncaughtException(Thread t, Throwable e) {
    if (!(e instanceof ThreadDeath)) {
      CentralExceptionHandling.getInstance().handle(e);
    }else
    if (getParent()!=null){
      getParent().uncaughtException(t, e);
    }
  }
}