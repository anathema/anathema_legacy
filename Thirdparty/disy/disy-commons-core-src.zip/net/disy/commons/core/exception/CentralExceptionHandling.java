package net.disy.commons.core.exception;


/**
 * Catches all {@link java.lang.Throwable} objects invoked
 * in AWT event dispatch threads or in Threads attached to a {@link java.lang.ThreadGroup} created
 * using the provided {@link #createThreadGroup()} and {@link #createThreadGroup(String)} methods.
 * The {@link java.lang.Throwable} objects will be delegated to an attached
 * {@link net.disy.commons.core.exception.IExceptionHandler} object, see {@link #setHandler(IExceptionHandler)}.
 * 
 * @author gebhard
 * @published
 */
public class CentralExceptionHandling {

  private static CentralExceptionHandling instance = new CentralExceptionHandling();

  private IExceptionHandler handler;

  private CentralExceptionHandling() {
    attachForEventDispatchExceptionHandling();
  }

  public IExceptionHandler getHandler() {
    return handler;
  }

  /** 
   * Sets the {@link IExceptionHandler} object where any uncaught exception will be delegated to.
   * 
   * @param handler The exception handler to which any uncaught exception will be delegated to.  
   * @published
   */
  public static void setHandler(IExceptionHandler handler) {
    getInstance().handler = handler;
  }

  public static CentralExceptionHandling getInstance() {
    return instance;
  }

  /** 
   * Delegates the given {@link Throwable} object to the attached {@link IExceptionHandler} object.
   */
  public void handle(Throwable exception) {
    if (handler != null) {
      handler.handle(exception);
    }
    else {
      System.err.println("Exception occurred during event dispatching:"); //$NON-NLS-1$
      exception.printStackTrace();
    }
  }

  /** 
   * @see java.awt.EventDispatchThread#handleException(java.lang.Throwable) 
   */
  private void attachForEventDispatchExceptionHandling() {
    System.setProperty("sun.awt.exception.handler", InternalAwtExceptionHandler.class.getName()); //$NON-NLS-1$
  }

  /**
   * Creates a new ThreadGroup that delegates all uncaught Throwables to the IExceptionHandler
   * attached to this {@link CentralExceptionHandling}.
   * 
   * @param name The name for the {@link ThreadGroup}.
   * @return A new {@link ThreadGroup}.
   * @published
   */
  public static ThreadGroup createThreadGroup(String name) {
    return new ExceptionDelegatingThreadGroup(name);
  }

  /**
   * Creates a new ThreadGroup that delegates all uncaught Throwables to the IExceptionHandler
   * attached to this {@link CentralExceptionHandling}.
   *  
   * @return A new {@link ThreadGroup}.
   * @published
   */
  public static ThreadGroup createThreadGroup() {
    return new ExceptionDelegatingThreadGroup("ExceptionHandlingThreadGroup"); //$NON-NLS-1$
  }
}