// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.message;

import net.disy.commons.core.message.Message;

public class DefaultErrorMessage extends Message {

  private static final String DEFAULT_MESSAGE = "Es ist ein Fehler aufgetreten."; //$NON-NLS-1$

  public DefaultErrorMessage(final Throwable throwable, final String message) {
    super("CadenzaWeb", message, throwable); //$NON-NLS-1$
  }

  public DefaultErrorMessage(final Throwable throwable) {
    this(throwable, DEFAULT_MESSAGE);
  }

}
