/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;

import junit.framework.TestCase;
import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;

public class MessageTest extends TestCase {

  public void testNullType() {
    try {
      new Message("title", "message", (MessageType) null); //$NON-NLS-1$ //$NON-NLS-2$
      fail();
    }
    catch (final Exception expected) {
      // expcted
    }
  }

  public void testNullTitleIsLegal() {
    new Message(null, "message", MessageType.ERROR); //$NON-NLS-1$
  }

  public void testNullMessage() {
    try {
      new Message("title", null, MessageType.ERROR); //$NON-NLS-1$
      fail();
    }
    catch (final Exception expected) {
      // expcted
    }
  }

  public void testConvenienceConstructor() {
    final ArrayIndexOutOfBoundsException exception = new ArrayIndexOutOfBoundsException();
    final IMessage message = new Message("title", "message", exception); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("title", message.getTitle()); //$NON-NLS-1$
    assertEquals("message", message.getText()); //$NON-NLS-1$
    assertSame(exception, message.getThrowable());
    assertEquals(MessageType.ERROR, message.getType());
  }

  public void testDetailFromThrowable() throws Exception {
    final Throwable throwable = new Throwable() {
      @Override
      public void printStackTrace(PrintWriter s) {
        s.print("stacktrace"); //$NON-NLS-1$
      }
    };
    assertEquals("stacktrace", new Message("text", throwable).getDetail()); //$NON-NLS-1$//$NON-NLS-2$
  }

  public void testDetailText() throws Exception {
    assertEquals("detail", new Message("text", MessageType.NORMAL, "detail").getDetail()); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
  }

  public void testGetDetailedText() throws Exception {
    assertEquals("text", new Message("text", new Throwable()).getDetailedText()); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("text - detail", new Message("text", MessageType.NORMAL, "detail") //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        .getDetailedText());
  }

  public void testMessageIsSerializable() throws Exception {
    Message alpha = new Message("title", "text", MessageType.NORMAL, new Exception());

    final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    new ObjectOutputStream(bos).writeObject(alpha);

    Message omega = (Message) new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()))
        .readObject();
    assertEquals(alpha, omega);
  }
}