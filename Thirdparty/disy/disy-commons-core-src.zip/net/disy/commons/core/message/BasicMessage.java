// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.message;

import net.disy.commons.core.util.Ensure;
 
/**
 * A basic message object only contains the text and type of a message.
 * @author gebhard
 */
public class BasicMessage implements IBasicMessage {
  private final MessageType type;
  private final String text;

  public BasicMessage() {
    this(""); //$NON-NLS-1$
  }

  public BasicMessage(String text) {
    this(text, MessageType.NORMAL);
  }

  public BasicMessage(String text, MessageType type) {
    Ensure.ensureArgumentNotNull("Text for message may not be null.", text); //$NON-NLS-1$
    Ensure.ensureArgumentNotNull("Type for message may not be null.", type); //$NON-NLS-1$
    this.text = text;
    this.type = type;
  }

  public String getText() {
    return text;
  }

  public MessageType getType() {
    return type;
  }

  public boolean isErrorMessage() {
    return MessageType.ERROR.equals(type);
  }
  
  @Override
  public String toString() {
    return getType() + ": " + getText(); //$NON-NLS-1$
  }
}