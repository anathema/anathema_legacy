/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message.test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import junit.framework.Assert;
import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.MessageType;

import org.junit.Test;

public class BasicMessageTest {

  @Test
  public void testEquals() {
    Assert.assertEquals(new BasicMessage("test"), new BasicMessage("test")); //$NON-NLS-1$ //$NON-NLS-2$
    Assert
        .assertEquals(
            new BasicMessage("test", MessageType.INFORMATION), new BasicMessage("test", MessageType.INFORMATION)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testDifferentNotEquals() {
    net.disy.commons.core.testing.Assert.assertNotEquals(
        new BasicMessage("one"), new BasicMessage("two")); //$NON-NLS-1$ //$NON-NLS-2$
    net.disy.commons.core.testing.Assert.assertNotEquals(
        new BasicMessage("foo", MessageType.ERROR), new BasicMessage("foo", MessageType.QUESTION)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testBasicMessageIsSerializable() throws Exception {
    BasicMessage alpha = new BasicMessage("title", MessageType.NORMAL);

    final ByteArrayOutputStream bos = new ByteArrayOutputStream();
    new ObjectOutputStream(bos).writeObject(alpha);

    BasicMessage omega = (BasicMessage) new ObjectInputStream(new ByteArrayInputStream(
        bos.toByteArray())).readObject();
    Assert.assertEquals(alpha, omega);
  }
}