// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.message;

 
/**
 * Interface for basic message object only contains the text and type of a message.
 * @published
 * @author gebhard
 */
public interface IBasicMessage {

  /** Returns the text of this message, must not return <code>null</code>.
   * @published */
  public String getText();

  /** Returns the type of this message, must not return <code>null</code>.
   * @published */
  public MessageType getType();
  
  /** 
   * @published
   */
  public boolean isErrorMessage();
  

}