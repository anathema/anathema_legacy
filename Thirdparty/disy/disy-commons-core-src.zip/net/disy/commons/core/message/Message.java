/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message;

import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * Default implementation for a message that can be shown using an {@link IMessageIndicator}.
 * 
 * @published
 */
public class Message extends BasicMessage implements IMessage {
  private final Throwable throwable;
  private final String title;
  private final String detailText;

  public static IMessage createWarning(final String message) {
    return new Message(message, MessageType.WARNING);
  }

  private Message(
      final String title,
      final String text,
      final MessageType type,
      final String detailText,
      final Throwable throwable) {
    super(text, type);
    this.throwable = throwable;
    this.title = title;
    this.detailText = detailText;
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   */
  public Message(
      final String title,
      final String text,
      final MessageType type,
      final Throwable throwable) {
    this(title, text, type, getStackTrace(throwable), throwable);
  }

  private static String getStackTrace(final Throwable throwable) {
    if (throwable == null) {
      return null;
    }
    final StringWriter stacktrace = new StringWriter();
    throwable.printStackTrace(new PrintWriter(stacktrace));
    return stacktrace.toString();
  }

  /**
   * Creates a new error message.
   * 
   * @published
   */
  public Message(final String title, final String text, final Throwable throwable) {
    this(title, text, MessageType.ERROR, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   */
  public Message(final String title, final String text, final MessageType type) {
    this(title, text, type, null);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published want to use {@link #Message(String, Throwable)} instead.
   */
  public Message(final String text, final MessageType type, final Throwable throwable) {
    this(null, text, type, throwable);
  }

  /**
   * Creates a new error Message object using the specified parameters.
   * 
   * @published
   */
  public Message(final String text, final Throwable throwable) {
    this(null, text, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   */
  public Message(final String text, final MessageType type) {
    this(text, type, (String) null);
  }

  public Message(final String text, final MessageType messageType, final String detailText) {
    this(null, text, messageType, detailText, null);
  }

  /**
   * Returns the title of this message, or <code>null</code> if there is none.
   * 
   * @deprecated as of 29.10.2003 (preuss), configured per {@link IMessageIndicator}
   * @published
   */
  @Override
  @Deprecated
  public String getTitle() {
    return title;
  }

  @Override
  public Throwable getThrowable() {
    return throwable;
  }

  @Override
  public String getDetail() {
    return detailText;
  }

  @Override
  public String getTextualDescription() {
    return getText() + (throwable == null && detailText != null ? " - " + detailText : ""); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**@deprecated as of 29.06.2010 (eggers, reupke), use {@link #getTextualDescription()} instead.*/
  @Deprecated
  @Override
  public String getDetailedText() {
    return getTextualDescription();
  }

}