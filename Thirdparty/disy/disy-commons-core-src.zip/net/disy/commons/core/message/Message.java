package net.disy.commons.core.message;

import java.io.PrintWriter;
import java.io.StringWriter;


/**
 * Default implementation for a message that can be shown using an
 * {@link IMessageIndicator}.
 * 
 * @published
 */
public class Message extends BasicMessage implements IMessage {
  private final Throwable throwable;
  private final String title;
  private final String detailText;

  private Message(String title,
      String text,
      MessageType type,
      String detailText,
      Throwable throwable) {
    super(text, type);
    this.throwable = throwable;
    this.title = title;
    this.detailText = detailText;
  }

  /** 
   * Creates a new Message object using the specified parameters.
   * @published
   */
  public Message(String title, String text, MessageType type, Throwable throwable) {
    this(title, text, type, getStackTrace(throwable), throwable);
  }

  private static String getStackTrace(Throwable throwable) {
    if (throwable == null) {
      return null;
    }
    StringWriter stacktrace = new StringWriter();
    throwable.printStackTrace(new PrintWriter(stacktrace));
    return stacktrace.toString();
  }

  /**
   * Creates a new error message.
   * @published
   */
  public Message(String title, String text, Throwable throwable) {
    this(title, text, MessageType.ERROR, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * @published
   */
  public Message(String title, String text, MessageType type) {
    this(title, text, type, null);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   * want to use {@link #Message(String, Throwable)} instead.
   */
  public Message(String text, MessageType type, Throwable throwable) {
    this(null, text, type, throwable);
  }

  /**
   * Creates a new error Message object using the specified parameters.
   * 
   * @published
   */
  public Message(String text, Throwable throwable) {
    this(null, text, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   */
  public Message(String text, MessageType type) {
    this(text, type, (String) null);
  }

  public Message(String text, MessageType messageType, String detailText) {
    this(null, text, messageType, detailText, null);
  }

  /** 
   * Returns the title of this message, or <code>null</code> if there is none.
   * @deprecated as of 29.10.2003 (preuss), configured per {@link IMessageIndicator}
   * @published 
   */
  @Deprecated
  public String getTitle() {
    return title;
  }

  public Throwable getThrowable() {
    return throwable;
  }

  public String getDetail() {
    return detailText;
  }

  public String getDetailedText() {
    return getText() + (throwable == null && detailText != null ? " - " + detailText : ""); //$NON-NLS-1$ //$NON-NLS-2$
  }
}