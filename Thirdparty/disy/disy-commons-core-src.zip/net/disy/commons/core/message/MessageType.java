// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.message;

import java.util.ArrayList;
import java.util.List;

/**
 * Constants for specifying the type of a message object. 
 * @author gebhard
 */
public abstract class MessageType {
  //TODO 13.08.2003 (gebhard):i18n durch MessageTypeUi bei Bedarf
  private String name;

  private static List all = new ArrayList();

  /** 
   * Message type for error messages.
   * @published
   */
  public final static MessageType ERROR = new MessageType("Fehler", new Integer(4)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitError(this);
    }
  };
  /** 
   * Message type for warning messages. 
   * @published
   */
  public final static MessageType WARNING = new MessageType("Warnung", new Integer(3)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitWarning(this);
    }
  };
  /** 
   * Message type for information messages. 
   * @published
   */
  public final static MessageType INFORMATION = new MessageType("Information", new Integer(2)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitInformation(this);
    }
  };
  /**
   * Message type for normal messages.
   * @published
   */
  public final static MessageType NORMAL = new MessageType("Normal", new Integer(1)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitNormal(this);
    }
  };

  /** 
   * Message type for question messages. 
   * @published
   */
  public final static net.disy.commons.core.message.MessageType QUESTION = new net.disy.commons.core.message.MessageType(
      "Question", new Integer(0)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitQuestion(this);
    }
  };


  private final Comparable priority;
  
  protected MessageType(String name, Comparable priority) {
    this.name = name;
    this.priority = priority;
    all.add(this);
  }

  public String toString() {
    return name;
  }

  public abstract void accept(IMessageTypeVisitor visitor);

  public static MessageType[] getAll() {
    return (MessageType[]) all.toArray(new MessageType[all.size()]);
  }
  
  public Comparable getPriority() {
    return priority;
  }
}