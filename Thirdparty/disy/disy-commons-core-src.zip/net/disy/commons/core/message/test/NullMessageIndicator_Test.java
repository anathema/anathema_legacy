/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message.test;

import static org.easymock.EasyMock.*;

import net.disy.commons.core.message.NullMessageIndicator;

import org.junit.Before;
import org.junit.Test;

public class NullMessageIndicator_Test {

  private NullMessageIndicator indicator;

  @Before
  public void createIndicator() throws Exception {
    indicator = new NullMessageIndicator();
  }

  @Test
  public void runsRunnable() throws Exception {
    final Runnable runnable = createMock(Runnable.class);
    runnable.run();
    replay(runnable);
    indicator.showMessage(null, runnable);
    verify(runnable);
  }

  @Test
  public void acceptsNullAsRunnable() throws Exception {
    indicator.showMessage(null, null);
  }
}