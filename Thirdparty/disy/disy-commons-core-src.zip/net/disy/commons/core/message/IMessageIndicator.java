package net.disy.commons.core.message;



/**
 * A message indicator describes an object being able to show given messages to the user
 * for example by showing a dialog or by printing the message to the console.
 * 
 * @author gebhard
 * @published
 */
public interface IMessageIndicator {
  
  /** Shows the given message in an appropriate way (for example by opening a dialog in gui systems).
   * @param message the message to show.
   * @published
   */
  public void showMessage(IMessage message);

  /** Shows the given message in an appropriate way (for example by opening a dialog in gui systems)
   * and executes the specified {@link Runnable} afterwards (in gui applications after closing the
   * dialog). 
   * 
   * @param message the message to show.
   * @param runAfterShowing the {@link Runnable} to execute after showing the message.
   * @published
   */
  public void showMessage(IMessage message, Runnable runAfterShowing);
}