/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message;

/**
 * A message indicator describes an object being able to show given messages to the user
 * for example by showing a dialog or by printing the message to the console.
 * 
 * @author gebhard
 * @published
 */
public interface IMessageIndicator extends ISimpleMessageIndicator {

  /** Shows the given message in an appropriate way (for example by opening a dialog in gui systems)
   * and executes the specified {@link Runnable} afterwards (in gui applications after closing the
   * dialog). 
   * 
   * @param message the message to show.
   * @param runAfterShowing the {@link Runnable} to execute after showing the message.
   * @published
   */
  public void showMessage(IMessage message, Runnable runAfterShowing);
}