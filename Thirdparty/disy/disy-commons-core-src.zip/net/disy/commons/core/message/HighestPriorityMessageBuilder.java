//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.message;


// NOT_PUBLISHED
public class HighestPriorityMessageBuilder {

  private IBasicMessage highestPriorityMessage;

  public IBasicMessage getHighestPriorityMessage() {
    return highestPriorityMessage;
  }

  public void addMessage(IBasicMessage message) {
    if (message == null) {
      return;
    }
    if (highestPriorityMessage == null || isHigherPriorityThan(message, highestPriorityMessage)) {
      highestPriorityMessage = message;
    }
  }

  private static boolean isHigherPriorityThan(IBasicMessage message1, IBasicMessage message2) {
    return message1.getType().getPriority().compareTo(message2.getType().getPriority()) > 0;
  }
}