//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.message.test;

import junit.framework.TestCase;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;

// NOT_PUBLISHED
public class HighestPriorityMessageBuilderTest extends TestCase {

  public void testEmpty() {
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    assertNull(builder.getHighestPriorityMessage());
  }

  public void testNullLaterIsAllowed() throws Exception {
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(new BasicMessage("Test")); //$NON-NLS-1$
    builder.addMessage(null);
  }

  public void testOneMessage() {
    IBasicMessage message = new BasicMessage("42"); //$NON-NLS-1$
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message);
    assertSame(message, builder.getHighestPriorityMessage());
  }

  public void testTwoMessagesSamePriority() throws Exception {
    BasicMessage message1 = new BasicMessage("42"); //$NON-NLS-1$
    BasicMessage message2 = new BasicMessage("zweiundvierzig"); //$NON-NLS-1$
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message1);
    builder.addMessage(message2);
    assertSame(message1, builder.getHighestPriorityMessage());
  }

  public void testTwoMessagesDifferentPriority() throws Exception {
    BasicMessage message1 = new BasicMessage("42", MessageType.WARNING); //$NON-NLS-1$
    BasicMessage message2 = new BasicMessage("zweiundvierzig", MessageType.ERROR); //$NON-NLS-1$
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message1);
    builder.addMessage(message2);
    assertSame(message2, builder.getHighestPriorityMessage());
  }
}