/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message.test;

import junit.framework.TestCase;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;

public class HighestPriorityMessageBuilderTest extends TestCase {

  public void testEmpty() {
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    assertNull(builder.getHighestPriorityMessage());
  }

  public void testNullLaterIsAllowed() throws Exception {
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(new BasicMessage("Test")); //$NON-NLS-1$
    builder.addMessage(null);
  }

  public void testOneMessage() {
    final IBasicMessage message = new BasicMessage("42"); //$NON-NLS-1$
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message);
    assertSame(message, builder.getHighestPriorityMessage());
  }

  public void testTwoMessagesSamePriority() throws Exception {
    final BasicMessage message1 = new BasicMessage("42"); //$NON-NLS-1$
    final BasicMessage message2 = new BasicMessage("zweiundvierzig"); //$NON-NLS-1$
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message1);
    builder.addMessage(message2);
    assertSame(message1, builder.getHighestPriorityMessage());
  }

  public void testTwoMessagesDifferentPriority() throws Exception {
    final BasicMessage message1 = new BasicMessage("42", MessageType.WARNING); //$NON-NLS-1$
    final BasicMessage message2 = new BasicMessage("zweiundvierzig", MessageType.ERROR); //$NON-NLS-1$
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(message1);
    builder.addMessage(message2);
    assertSame(message2, builder.getHighestPriorityMessage());
  }
}