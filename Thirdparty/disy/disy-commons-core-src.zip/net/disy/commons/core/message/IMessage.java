/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.message;

/**
 * Interface describing message objects that can be shown to the user by using an
 * {@link net.disy.commons.core.message.IMessageIndicator} object.
 * 
 * @author gebhard
 * @published
 */
public interface IMessage extends IBasicMessage {

  /** 
   * Returns the title of this message, or <code>null</code> if there is none.
   * @deprecated as of 29.10.2003 (preuss), configured per {@link IMessageIndicator}
   * @published 
   */
  @Deprecated
  public String getTitle();

  /** 
   * Returns the Throwable object that has caused this message or <code>null</code> if there is
   * none specified.
   * 
   * @published 
   */
  public Throwable getThrowable();

  public String getDetail();

  /**@deprecated as of 29.06.2010 (eggers, reupke), use {@link #getTextualDescription()} instead.*/
  @Deprecated
  public String getDetailedText();

  public String getTextualDescription();
}