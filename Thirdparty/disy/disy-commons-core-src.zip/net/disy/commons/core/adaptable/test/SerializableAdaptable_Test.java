/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.adaptable.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.io.Serializable;

import net.disy.commons.core.adaptable.SerializableAdaptable;
import net.disy.commons.testing.Assert;

import org.junit.Test;

@SuppressWarnings("nls")
public class SerializableAdaptable_Test {

  private static class TestSerializable implements Serializable {
    protected final String id;

    public TestSerializable(String id) {
      this.id = id;
    }
  }

  @Test
  public void serializesContent() throws Exception {
    SerializableAdaptable adaptable = new SerializableAdaptable();
    adaptable.add(TestSerializable.class, new TestSerializable("id"));
    SerializableAdaptable deserialized = Assert.serializeAndDeserialize(adaptable);
    TestSerializable serializable = deserialized.get(TestSerializable.class);
    assertThat(serializable.id, is("id"));
  }
}