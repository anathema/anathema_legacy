/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.adaptable;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class SerializableAdaptable implements IAdaptable<Serializable>, Serializable {

  private final Map<Class<?>, Object> objectsByClass = new HashMap<Class<?>, Object>();

  @SuppressWarnings("unchecked")
  @Override
  public <T extends Serializable> T get(final Class<T> adapter) {
    if (objectsByClass.containsKey(adapter)) {
      return (T) objectsByClass.get(adapter);
    }
    for (final Class<?> clazz : objectsByClass.keySet()) {
      if (clazz.isAssignableFrom(adapter)) {
        final Object object = objectsByClass.get(clazz);
        if (adapter.isInstance(object)) {
          return (T) object;
        }
      }
    }
    if (adapter.isInstance(this)) {
      return (T) this;
    }
    return null;
  }

  public <T extends Serializable> void add(final Class<T> clazz, final T object) {
    objectsByClass.put(clazz, object);
  }
}