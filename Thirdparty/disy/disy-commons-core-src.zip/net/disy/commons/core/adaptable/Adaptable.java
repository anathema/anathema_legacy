/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.adaptable;

import java.util.HashMap;
import java.util.Map;

import net.disy.commons.core.provider.IProvider;
import net.disy.commons.core.provider.StaticProvider;

public class Adaptable<S> implements IAdaptable<S> {

  private final Map<Class<?>, IProvider<?>> objectProvidersByClass = new HashMap<Class<?>, IProvider<?>>();

  @SuppressWarnings("unchecked")
  @Override
  public <T extends S> T get(final Class<T> adapter) {
    if (objectProvidersByClass.containsKey(adapter)) {
      return (T) objectProvidersByClass.get(adapter).getObject();
    }
    for (final Class<?> clazz : objectProvidersByClass.keySet()) {
      if (clazz.isAssignableFrom(adapter)) {
        final Object object = objectProvidersByClass.get(clazz).getObject();
        if (adapter.isInstance(object)) {
          return (T) object;
        }
      }
    }
    if (adapter.isInstance(this)) {
      return (T) this;
    }
    return null;
  }

  public <T extends S> void add(final Class<T> clazz, final IProvider<T> provider) {
    objectProvidersByClass.put(clazz, provider);
  }

  public <T extends S> void add(final Class<T> clazz, final T object) {
    add(clazz, new StaticProvider<T>(object));
  }
}