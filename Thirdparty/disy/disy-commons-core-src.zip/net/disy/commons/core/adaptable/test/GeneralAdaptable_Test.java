/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.adaptable.test;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;

import net.disy.commons.core.adaptable.GeneralAdaptable;
import net.disy.commons.core.adaptable.IAdaptable;
import net.disy.commons.core.provider.IProvider;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

public class GeneralAdaptable_Test {

  public interface IRoot {
    // nothing to do
  }

  public interface IChild1 extends IRoot {
    // nothing to do
  }

  public interface IChild2 extends IRoot {
    // nothing to do
  }

  private GeneralAdaptable adaptable;
  private IChild1 child1;

  @Before
  public void createEmptyAdaptable() {
    this.child1 = EasyMock.createMock(IChild1.class);
    this.adaptable = new GeneralAdaptable();
    this.adaptable.add(IRoot.class, new IProvider<IRoot>() {
      @Override
      public IRoot getObject() {
        return child1;
      }
    });
  }

  @Test
  public void foreignClassIsNotAdapted() throws Exception {
    assertNull(adaptable.get(String.class));
  }

  @Test
  public void rootClassIsAdaptedWithFirstChildObject() throws Exception {
    assertSame(child1, adaptable.get(IRoot.class));
  }

  @Test
  public void firstChildClassIsAdaptedWithFirstChildObject() throws Exception {
    assertSame(child1, adaptable.get(IChild1.class));
  }

  @Test
  public void secondChildClassIsNotAdapted() throws Exception {
    assertNull(adaptable.get(IChild2.class));
  }

  @Test
  public void firstFittingAdaptableIsUsed() throws Exception {
    final IChild2 child2 = EasyMock.createMock(IChild2.class);
    adaptable.add(IChild2.class, new IProvider<IChild2>() {
      @Override
      public IChild2 getObject() {
        return child2;
      }
    });
    assertSame(child1, adaptable.get(IRoot.class));
  }

  @Test
  public void specificClassIsPreferred() throws Exception {
    final IChild1 otherChild1 = EasyMock.createMock(IChild1.class);
    adaptable.add(IChild1.class, new IProvider<IChild1>() {
      @Override
      public IChild1 getObject() {
        return otherChild1;
      }
    });
    assertSame(otherChild1, adaptable.get(IChild1.class));
  }

  @Test
  public void adaptsToOwnSubclass() throws Exception {
    assertSame(adaptable, adaptable.get(Object.class));
    assertSame(adaptable, adaptable.get(IAdaptable.class));
  }

  @Test
  public void prefersRegisteredClassesToSubclasses() throws Exception {
    final IAdaptable registeredAdaptable = createMock(IAdaptable.class);
    adaptable.add(IAdaptable.class, registeredAdaptable);
    assertSame(registeredAdaptable, adaptable.get(IAdaptable.class));
  }

}