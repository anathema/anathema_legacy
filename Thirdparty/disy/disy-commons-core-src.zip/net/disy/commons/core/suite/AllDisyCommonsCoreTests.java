//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.suite;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllDisyCommonsCoreTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.core.suite"); //$NON-NLS-1$
    //$JUnit-BEGIN$

    //$JUnit-END$
    suite.addTest(net.disy.commons.core.message.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.exception.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.geometry.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.text.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.text.font.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.io.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.model.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.number.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.string.test.AllTests.suite());
    suite.addTest(net.disy.commons.core.util.test.AllTests.suite());
    return suite;
  }
}
