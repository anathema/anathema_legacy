/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ReflectionConstructorInvoker<C> {

  private final Class<? extends C> clazz;
  private final Class<?>[] parameterTypes;

  public ReflectionConstructorInvoker(
      final Class<? extends C> clazz,
      final Class<?>... parameterTypes) {
    this.clazz = clazz;
    this.parameterTypes = parameterTypes;
  }

  public C invoke(final Object... parameters)
      throws NoSuchMethodException,
      IllegalArgumentException,
      InstantiationException,
      IllegalAccessException,
      InvocationTargetException {
    Constructor<? extends C> constructor = this.clazz.getDeclaredConstructor(this.parameterTypes);
    constructor.setAccessible(true);
    return constructor.newInstance(parameters);
  }

}
