// Copyright (c) 2010 by disy Informationssysteme GmbH
package net.disy.commons.core.reflection.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.core.reflection.ReflectionConstructorInvoker;

import org.junit.Test;


public class ReflectionConstructorInvokerTest {

  @Test
  public void testInvoke() throws Throwable {
    assertValide(StringConstructorClass.class.getName(), "Wert"); //$NON-NLS-1$
  }

  public void assertValide(String className, String parameter)
      throws ClassNotFoundException,
      NoSuchMethodException,
      InstantiationException,
      IllegalAccessException,
      InvocationTargetException {
    @SuppressWarnings("unchecked")
    ReflectionConstructorInvoker<Object> invoker = new ReflectionConstructorInvoker<Object>(
        (Class<Object>) Class.forName(className),
        String.class);
    assertThat(invoker.invoke(parameter).toString(), equalTo(parameter));
  }

  public final static class StringConstructorClass {
    private final String parameter;

    public StringConstructorClass(final String parameter) {
      this.parameter = parameter;
    }

    @Override
    public String toString() {
      return parameter;
    }
  }
}
