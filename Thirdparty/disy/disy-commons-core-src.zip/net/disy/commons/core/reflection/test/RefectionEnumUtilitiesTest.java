// Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.core.reflection.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import net.disy.commons.core.reflection.RefectionEnumUtilities;

import org.junit.Test;

// NOT_PUBLISHED
public class RefectionEnumUtilitiesTest {

  private static enum TestEnum1 {
    AAA, BBB, CCC
  }
  private static TestEnum1[] TestEnum1Values = new TestEnum1[]{
      TestEnum1.AAA,
      TestEnum1.BBB,
      TestEnum1.CCC };

  private static enum TestEnum2 {
    DDD, EEE, FFF
  }
  private static TestEnum2[] TestEnum2Values = new TestEnum2[]{
      TestEnum2.DDD,
      TestEnum2.EEE,
      TestEnum2.FFF };

  private static class TestClass {
    // nothing to do
  }

  private static interface TestInterface {
    // nothing to do
  }

  @Test
  public void testIsEnum() {
    assertThat(RefectionEnumUtilities.isEnum(TestEnum1.AAA), is(true));
    assertThat(RefectionEnumUtilities.isEnum(TestEnum1.BBB), is(true));
    assertThat(RefectionEnumUtilities.isEnum(TestEnum1.CCC), is(true));
    assertThat(RefectionEnumUtilities.isEnum(TestEnum2.DDD), is(true));
    assertThat(RefectionEnumUtilities.isEnum(TestEnum2.EEE), is(true));
    assertThat(RefectionEnumUtilities.isEnum(TestEnum2.FFF), is(true));

    assertThat(RefectionEnumUtilities.isEnum(new TestClass()), is(false));
    assertThat(RefectionEnumUtilities.isEnum(new TestInterface() {
      // nothing to do
    }), is(false));
  }

  @Test
  public void testGetEnumConstants() {
    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum1.AAA), is(TestEnum1Values));
    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum1.BBB), is(TestEnum1Values));
    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum1.CCC), is(TestEnum1Values));

    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum2.DDD), is(TestEnum2Values));
    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum2.EEE), is(TestEnum2Values));
    assertThat(RefectionEnumUtilities.getEnumConstants(TestEnum2.FFF), is(TestEnum2Values));
  }

}
