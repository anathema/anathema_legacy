/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class ReflectionMethodInvoker<C, T> {

  private final Class<?> clazz;
  private final String methodeName;
  private final Class<?>[] parameterTypes;

  public ReflectionMethodInvoker(
      final Class<?> clazz,
      final String methodeName,
      final Class<?>... parameterTypes) {
    this.clazz = clazz;
    this.methodeName = methodeName;
    this.parameterTypes = parameterTypes;
  }

  @SuppressWarnings("unchecked")
  public T invoke(final Object object, final Object... parameter)
      throws NoSuchMethodException,
      IllegalAccessException,
      InvocationTargetException {
    final Method method = this.clazz.getDeclaredMethod(this.methodeName, this.parameterTypes);
    method.setAccessible(true);
    return (T) method.invoke(object, parameter);
  }
}
