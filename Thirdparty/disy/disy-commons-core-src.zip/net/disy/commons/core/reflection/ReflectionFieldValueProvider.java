/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.reflection;

import java.lang.reflect.Field;
import java.security.PrivilegedAction;

public class ReflectionFieldValueProvider<T> {

  private final Class<?> clazz;

  public ReflectionFieldValueProvider(final Class<?> clazz) {
    this.clazz = clazz;
  }

  @SuppressWarnings("unchecked")
  public T get(final Object object, final String fieldName) {
    return java.security.AccessController.doPrivileged(new PrivilegedAction<T>() {
      @Override
      public T run() {
        try {
          Field field = ReflectionFieldValueProvider.this.clazz.getDeclaredField(fieldName);
          field.setAccessible(true);
          return (T) field.get(object);
        }
        catch (NoSuchFieldException exception) {
          throw new RuntimeException(exception);
        }
        catch (IllegalAccessException exception) {
          throw new RuntimeException(exception);
        }
      }
    });
  }
}
