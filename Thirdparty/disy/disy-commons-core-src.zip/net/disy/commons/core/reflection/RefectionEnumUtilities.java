// Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.core.reflection;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.security.PrivilegedAction;

// NOT_PUBLISHED
public class RefectionEnumUtilities {
  /** Original from java.lang.Class **/
  private static final int ENUM = 0x00004000;

  /** Alternative zur original Funktion aus Class, weil diese "abgeleitet" Enums nicht mehr als Enums erkennt **/
  public static <T> boolean isEnum(final T value) {
    // An enum must both directly extend java.lang.Enum and have
    // the ENUM bit set; classes for specialized enum constants
    // don't do the former.
    return (value.getClass().getModifiers() & ENUM) != 0 && value instanceof java.lang.Enum;
  }

  /** Alternative zur original Funktion aus Class, weil diese "abgeleitet" Enums nicht mehr als Enums erkennt **/
  @SuppressWarnings("unchecked")
  public static <T> T[] getEnumConstants(final T value) {
    if (!isEnum(value)) {
      return null;
    }
    try {
      final Method valuesMethod = value.getClass().getMethod("values");
      java.security.AccessController.doPrivileged(new PrivilegedAction<Object>() {
        @Override
        public Object run() {
          valuesMethod.setAccessible(true);
          return null;
        }
      });
      final T[] values = (T[]) valuesMethod.invoke(null);
      return (values != null) ? values.clone() : null;
    }
    // These can happen when users concoct enum-like classes
    // that don't comply with the enum spec.
    catch (final InvocationTargetException ex) {
      return null;
    }
    catch (final NoSuchMethodException ex) {
      return null;
    }
    catch (final IllegalAccessException ex) {
      return null;
    }
  }

}
