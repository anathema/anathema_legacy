/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection.test;

import net.disy.commons.core.collection.SoftHashMap;
import net.disy.commons.core.testing.CoreTestCase;

public class SoftHashMapTest extends CoreTestCase {

  public void testEmptyMap() {
    final SoftHashMap<String, Integer> map = new SoftHashMap<String, Integer>();
    assertEquals(0, map.size());
    assertNull(map.get("1")); //$NON-NLS-1$
    assertNull(map.get("42")); //$NON-NLS-1$
    assertEquals(0, map.size());
  }

  public void testPut() {
    final SoftHashMap<String, Integer> map = new SoftHashMap<String, Integer>();
    System.gc();

    //We hope there is no gc between the next thress lines:
    map.put("1", new Integer(2)); //$NON-NLS-1$
    assertEquals(new Integer(2), map.get("1")); //$NON-NLS-1$
    assertEquals(1, map.size());
  }

  public void testRemove() {
    final SoftHashMap<String, Integer> map = new SoftHashMap<String, Integer>();
    map.put("1", new Integer(2)); //$NON-NLS-1$
    map.remove("1"); //$NON-NLS-1$
    assertNull(map.get("1")); //$NON-NLS-1$
    assertEquals(0, map.size());
  }

  public void testClear() {
    final SoftHashMap<String, Integer> map = new SoftHashMap<String, Integer>();
    map.put("1", new Integer(2)); //$NON-NLS-1$
    map.clear();
    assertNull(map.get("1")); //$NON-NLS-1$
    assertEquals(0, map.size());
  }

  public void testCanHandleDoubleSizeOfMaximumHeapSize() {
    final long maxMemoryInBytes = Runtime.getRuntime().maxMemory();
    final int oneMegaByteInBytes = 1024 * 1024;
    final int maxMemoryInMegaBytes = (int) (maxMemoryInBytes / oneMegaByteInBytes);

    final SoftHashMap<Integer, Junk> map = new SoftHashMap<Integer, Junk>();
    for (int i = 0; i < 2 * maxMemoryInMegaBytes; ++i) {
      map.put(new Integer(i), new Junk(oneMegaByteInBytes));
    }
  }

  private final static class Junk {
    private final byte[] data;

    public Junk(final int sizeInBytes) {
      this.data = new byte[sizeInBytes];
    }

    @Override
    public String toString() {
      return String.valueOf(data);
    }
  }
}