/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MultipleValueHashMap<K, V> {

  private final Map<K, List<V>> map = new LinkedHashMap<K, List<V>>();

  public void clear() {
    map.clear();
  }

  public boolean containsKey(final K key) {
    return map.containsKey(key);
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof MultipleValueHashMap)) {
      return false;
    }
    return map.equals(((MultipleValueHashMap<?, ?>) obj).map);
  }

  public Iterator<V> getIterator(final K key) {
    final List<V> list = map.get(key);
    if (list != null) {
      return list.iterator();
    }
    return new NullIterator<V>();
  }

  @Override
  public int hashCode() {
    return map.hashCode();
  }

  public boolean isEmpty() {
    return map.isEmpty();
  }

  public Set<K> keySet() {
    return map.keySet();
  }

  public void add(final K key, final V value) {
    List<V> list = map.get(key);
    if (list == null) {
      list = new ArrayList<V>();
      map.put(key, list);
    }
    list.add(value);
  }

  public List<V> remove(final K key) {
    return map.remove(key);
  }

  public int size() {
    return map.size();
  }

  @Override
  public String toString() {
    return map.toString();
  }

  @SuppressWarnings("unchecked")
  public <T> T[] getArray(final K key, final Class<T> clazz) {
    final List<V> list = getList(key);
    final T[] array = (T[]) Array.newInstance(clazz, list.size());
    return list.toArray(array);
  }

  public List<V> getList(final K key) {
    final List<V> list = map.get(key);
    if (list != null) {
      return list;
    }
    return new ArrayList<V>(0);
  }

  public Iterable<V> getValues(final K key) {
    return getList(key);
  }

  public Object[] getArray(final K key) {
    return getArray(key, Object.class);
  }

  public LinkedHashSet<V> getSet(final K key) {
    return new LinkedHashSet<V>(getList(key));
  }

  public void addAll(final K key, final Collection<V> values) {
    for (final V value : values) {
      add(key, value);
    }
  }

  public void addAll(final MultipleValueHashMap<K, V> other) {
    for (final K key : other.keySet()) {
      addAll(key, other.getList(key));
    }
  }
}