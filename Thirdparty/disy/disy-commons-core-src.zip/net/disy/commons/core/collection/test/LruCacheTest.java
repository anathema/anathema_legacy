/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection.test;

import static junit.framework.Assert.*;
import net.disy.commons.core.collection.LruCache;

import org.junit.Test;

@SuppressWarnings("nls")
public class LruCacheTest {

  @Test
  public void testNewCacheIsEmpty() {
    final LruCache<String, String> cache = new LruCache<String, String>(2);
    assertEquals(0, cache.size());
    assertTrue(cache.isEmpty());
  }

  @Test
  public void testCachesObjects() {
    final LruCache<String, String> cache = new LruCache<String, String>(2);
    cache.put("key1", "value1");
    cache.put("key2", "value2");
    assertEquals("value1", cache.get("key1"));
    assertEquals("value2", cache.get("key2"));
    assertEquals(null, cache.get("key3"));
  }

  @Test
  public void testClearedCacheIsEmpty() {
    final LruCache<String, String> cache = new LruCache<String, String>(2);
    cache.put("key1", "value1");
    cache.put("key2", "value2");
    cache.clear();
    assertEquals(0, cache.size());
    assertTrue(cache.isEmpty());
  }

  @Test
  public void testMaxSizeNotExceededOnPut() {
    final LruCache<String, String> cache = new LruCache<String, String>(2);
    cache.put("key1", "value1");
    cache.put("key2", "value2");
    cache.put("key3", "value3");
    assertEquals(2, cache.size());
  }

  @Test
  public void testThreadSafeCacheNotExceedsMaximumSizeWithMultithreading() {
    final LruCache<String, String> cache = new LruCache<String, String>(10);
    for (int i = 0; i < 1000; ++i) {
      final int number = i;
      new Thread(new Runnable() {
        @Override
        public void run() {
          Thread.yield();
          cache.put("key" + number, "value");
        }
      }).start();
    }
    assertEquals(10, cache.size());
  }
}