/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection;

import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.util.HashMap;
import java.util.Map;

public class SoftHashMap<K, V> {

  /** The internal HashMap that will hold the SoftReference. */
  private final Map<K, SoftReference<V>> map = new HashMap<K, SoftReference<V>>();
  /** Reference queue for cleared SoftReference objects. */
  private final ReferenceQueue<V> queue = new ReferenceQueue<V>();

  public V get(final K key) {
    final SoftReference<V> softReference = map.get(key);
    if (softReference == null) {
      return null;
    }
    final V result = softReference.get();
    if (result == null) {
      map.remove(key);
    }
    return result;
  }

  @SuppressWarnings("unchecked")
  private void processQueue() {
    SoftValue<V> sv;
    while ((sv = (SoftValue<V>) queue.poll()) != null) {
      map.remove(sv.key);
    }
  }

  public void put(final K key, final V value) {
    processQueue();
    map.put(key, new SoftValue<V>(value, queue, key));
  }

  public Object remove(final K key) {
    processQueue();
    return map.remove(key);
  }

  public void clear() {
    map.clear();
  }

  public int size() {
    processQueue();
    return map.size();
  }

  private static class SoftValue<V> extends SoftReference<V> {
    private final Object key;

    private SoftValue(final V k, final ReferenceQueue<V> q, final Object key) {
      super(k, q);
      this.key = key;
    }
  }
}