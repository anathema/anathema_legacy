/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection.test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

import junit.framework.TestCase;

import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.IClosure;

public class CollectionUtilities_RepresentationTest extends TestCase {

  public void testGetRepresentation() throws Exception {
    assertGetRepresentation("[]", new Object[0]); //$NON-NLS-1$
    assertGetRepresentation("[1]", new Object[]{ "1" }); //$NON-NLS-1$ //$NON-NLS-2$
    final Object two = new Object() {
      @Override
      public String toString() {
        return "2"; //$NON-NLS-1$
      }
    };
    assertGetRepresentation("[1,2]", new Object[]{ new Integer(1), two }); //$NON-NLS-1$
  }

  private static void assertGetRepresentation(final String expected, final Object[] list) {
    assertEquals(expected, CollectionUtilities.getRepresentation(Arrays.asList(list)));
  }

  public void testForEachInCollection() throws Exception {
    final Collection<Object> collection = new ArrayList<Object>();
    final Object object = new Object();
    collection.add(object);
    final MockBlock block = new MockBlock();
    CollectionUtilities.forAllDo(collection, block);
    assertSame(object, block.getPerformedElement());
  }

  static class MockBlock implements IClosure<Object> {
    private Object element;

    @Override
    public void execute(final Object newElement) {
      this.element = newElement;
    }

    private Object getPerformedElement() {
      return element;
    }
  }
}