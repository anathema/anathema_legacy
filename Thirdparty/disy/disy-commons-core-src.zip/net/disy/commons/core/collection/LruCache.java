/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class LruCache<K, V> {

  private static final class LruCacheMap<K, V> extends LinkedHashMap<K, V> {

    private final int maxSize;

    public LruCacheMap(final int maxSize) {
      super(maxSize * 4 / 3 + 1, 0.75f, true);
      this.maxSize = maxSize;
    }

    @Override
    protected boolean removeEldestEntry(final Map.Entry<K, V> eldest) {
      return size() > maxSize;
    }
  }

  private final Map<K, V> cache;

  public LruCache(final int maxSize) {
    cache = Collections.synchronizedMap(new LruCacheMap<K, V>(maxSize));
  }

  public V get(K key) {
    return cache.get(key);
  }

  public void clear() {
    cache.clear();
  }

  public boolean contains(K key) {
    return cache.containsKey(key);
  }

  public void put(K key, V value) {
    cache.put(key, value);
  }

  public boolean isEmpty() {
    return cache.isEmpty();
  }

  public int size() {
    return cache.size();
  }
}