/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.collection.test;

import java.util.Iterator;

import net.disy.commons.core.collection.MultipleValueHashMap;
import net.disy.commons.core.testing.CoreTestCase;

public class MultipleValueHashMapTest extends CoreTestCase {

  private static final String VALUE_TWO = "two"; //$NON-NLS-1$
  private static final String VALUE_ONE = "one"; //$NON-NLS-1$
  private static final String KEY = "key"; //$NON-NLS-1$
  private MultipleValueHashMap<String, String> map;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    map = new MultipleValueHashMap<String, String>();
  }

  public void testEquals() throws Exception {
    map.add("key", "value"); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(map, map);
    assertNotEquals(new Object(), map);
    final MultipleValueHashMap<String, String> equalMap = new MultipleValueHashMap<String, String>();
    equalMap.add("key", "value"); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(map, equalMap);
    final MultipleValueHashMap<String, String> differentMap = new MultipleValueHashMap<String, String>();
    differentMap.add("different key", "different value"); //$NON-NLS-1$//$NON-NLS-2$
    assertNotEquals(map, differentMap);
  }

  public void testEmptyMap() throws Exception {
    assertFalse(map.getIterator(KEY).hasNext());
    assertEquals(0, map.getArray(KEY).length);
  }

  public void testGetIterator() throws Exception {
    map.add(KEY, VALUE_ONE);
    map.add(KEY, VALUE_TWO);
    final Iterator<String> iterator = map.getIterator(KEY);
    assertEquals(VALUE_ONE, iterator.next());
    assertEquals(VALUE_TWO, iterator.next());
    assertFalse(iterator.hasNext());
  }

  public void testGetArray() throws Exception {
    map.add(KEY, VALUE_ONE);
    map.add(KEY, VALUE_TWO);
    final String[] array = map.getArray(KEY, String.class);
    assertEquals(2, array.length);
    assertEquals(VALUE_ONE, array[0]);
    assertEquals(VALUE_TWO, array[1]);
  }
}