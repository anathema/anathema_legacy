/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing;

import java.io.IOException;
import java.util.Arrays;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;

public class Serializable extends TypeSafeMatcher<Object> {

  @Override
  public boolean matchesSafely(final Object item) {
    try {
      final Object deserializedObject = Assert.serializeAndDeserialize(item);
      if (item.getClass().isArray()) {
        return Arrays.deepEquals((Object[]) item, (Object[]) deserializedObject);
      }
      return deserializedObject.equals(item);
    }
    catch (final IOException e) {
      return false;
    }
    catch (final ClassNotFoundException e) {
      return false;
    }
  }

  @Override
  public void describeTo(final Description description) {
    description.appendText("an object equalling itself after serialization"); //$NON-NLS-1$
  }

  public static Matcher<Object> serializable() {
    return new Serializable();
  }
}