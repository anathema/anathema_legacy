// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 10.11.2005
package net.disy.commons.core.testing;

// NOT_PUBLISHED
public abstract class AbstractEqualsTestCase extends CoreTestCase {

  protected abstract Object createObjectUnderTest();

  public final void testEqualsBasics() throws Exception {
    assertEqualsAndHashCode(createObjectUnderTest(), createObjectUnderTest());
    assertFalse(createObjectUnderTest().equals(new Object()));
    assertFalse(createObjectUnderTest().equals(null));
  }
}