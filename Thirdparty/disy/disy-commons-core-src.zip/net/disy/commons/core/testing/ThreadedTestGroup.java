/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing;

import junit.framework.AssertionFailedError;
import junit.framework.Test;
import junit.framework.TestResult;

/**
 * This class was copied from JunitPerf by J.Link and modified afterwards
 * 
 * The <code>ThreadedTestGroup</code> is a <code>ThreadGroup</code> that
 * catches and handles exceptions thrown by threads created and started by
 * <code>ThreadedTest</code> instances.
 * <p>
 * If a thread managed by a <code>ThreadedTestGroup</code> throws an uncaught
 * exception, then the exception is added to the current test's results and all
 * other threads are immediately stopped. Caveat: Waiting threads ignore a
 * stop()!
 * 
 * @author Ervin Varga
 * @author <a href="mailto:mike@clarkware.com">Mike Clark </a>
 * @author <a href="http://www.clarkware.com">Clarkware Consulting, Inc. </a>
 * @author <a href="mailto:john.link@gmx.net">Johannes Link </a>
 * 
 * @see java.lang.ThreadGroup
 */

public class ThreadedTestGroup extends ThreadGroup {

  private final Test test;
  private TestResult testResult;

  /**
   * Constructs a <code>ThreadedTestGroup</code> for the specified test.
   * 
   * @param test
   *          Current test.
   */
  public ThreadedTestGroup(final Test test) {
    super("ThreadedTestGroup"); //$NON-NLS-1$
    this.test = test;
  }

  /**
   * Try to interrupt first then stop the stubborn threads
   */
  @SuppressWarnings("deprecation")
  public void interruptThenStop() {
    interrupt();
    if (activeCount() > 0) {
      stop(); // For those threads which won't interrupt
    }
  }

  /**
   * Sets the current test result.
   * 
   * @param result
   *          Test result.
   */
  public void setTestResult(final TestResult result) {
    testResult = result;
  }

  /**
   * Called when a thread in this thread group stops because of an uncaught
   * exception.
   * <p>
   * If the uncaught exception is a <code>ThreadDeath</code>, then it is
   * ignored. If the uncaught exception is a <code>AssertionFailedError</code>,
   * then a failure is added to the current test result. Otherwise, an error is
   * added to the current test result.
   * 
   * @param t
   *          Originating thread.
   * @param e
   *          Uncaught exception.
   */
  @Override
  public void uncaughtException(final Thread t, final Throwable e) {
    if (e instanceof ThreadDeath) {
      return;
    }
    if (e instanceof InterruptedException) {
      return;
    }
    if (e instanceof AssertionFailedError) {
      testResult.addFailure(test, (AssertionFailedError) e);
    }
    else {
      testResult.addError(test, e);
    }
    interruptThenStop();
  }
}