/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import junit.framework.TestCase;
import junit.framework.TestResult;

/**
 * 
 * This class can be used to test the concurrent behaviour of a unit under test.
 */
public abstract class ConcurrentTestCase extends TestCase {
  private TestResult currentResult;
  private ThreadedTestGroup threadGroup;
  private Hashtable<String, ConcurrentTestThread> threads = new Hashtable<String, ConcurrentTestThread>();
  private boolean deadlockDetected = false;
  private Vector<String> checkpoints = new Vector<String>();

  class ConcurrentTestThread extends Thread {
    private volatile boolean hasStarted = false;
    private volatile boolean hasFinished = false;

    ConcurrentTestThread(final ThreadGroup group, final Runnable runnable, final String name) {
      super(group, runnable, name);
    }

    @Override
    public void run() {
      hasStarted = true;
      super.run();
      finishThread(this);
    }
  }

  protected void addThreadAndStartImmediately(final String name, final Runnable runnable) {
    final ConcurrentTestThread thread = addThread(name, runnable);
    startThread(thread);
  }

  protected ConcurrentTestThread addThread(final String name, final Runnable runnable) {
    if (threads.get(name) != null) {
      fail("Thread with name '" + name + "' already exists"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    final ConcurrentTestThread newThread = new ConcurrentTestThread(threadGroup, runnable, name);
    threads.put(name, newThread);
    return newThread;
  }

  public synchronized void checkpoint(final String checkpointName) {
    if (checkpointReached(checkpointName)) {
      throw new CheckpointPassedBeforeException(checkpointName);
    }
    checkpoints.addElement(checkpointName);
    notifyAll();
  }

  public boolean checkpointReached(final String checkpointName) {
    return checkpoints.contains(checkpointName);
  }

  public boolean deadlockDetected() {
    return deadlockDetected;
  }

  private synchronized void finishThread(final ConcurrentTestThread thread) {
    thread.hasFinished = true;
    notifyAll();
  }

  private ConcurrentTestThread getThread(final String threadName) {
    return threads.get(threadName);
  }

  /**
   * Returns true if the thread finished normally, i.e. was not interrupted or
   * stopped
   */
  @SuppressWarnings("null")
  public boolean hasThreadFinished(final String threadName) {
    final ConcurrentTestThread thread = getThread(threadName);
    if (thread == null) {
      fail("Unknown Thread: " + threadName); //$NON-NLS-1$
    }
    return thread.hasFinished;
  }

  @SuppressWarnings("null")
  public boolean hasThreadStarted(final String threadName) {
    final ConcurrentTestThread thread = getThread(threadName);
    if (thread == null) {
      fail("Unknown Thread: " + threadName); //$NON-NLS-1$
    }
    return thread.hasStarted;
  }

  private void interruptAllAliveThreads() {
    threadGroup.interruptThenStop();
  }

  /**
   * Wait till all threads have finished. Wait maximally millisecondsToWait.
   * Should only be called after startThreads().
   */
  protected void joinAllThreads(final long millisecondsToWait) {
    final Enumeration<ConcurrentTestThread> enumeration = threads.elements();
    long remainingMilliseconds = millisecondsToWait;
    while (enumeration.hasMoreElements()) {
      final long before = System.currentTimeMillis();
      final ConcurrentTestThread each = enumeration.nextElement();
      try {
        each.join(remainingMilliseconds);
      }
      catch (final InterruptedException ignored) {
        // nothing to do
      }
      final long spent = System.currentTimeMillis() - before;
      if (millisecondsToWait != 0) {
        remainingMilliseconds = remainingMilliseconds - spent;
        if (remainingMilliseconds <= 0) {
          deadlockDetected = true;
          break;
        }
      }
    }
  }

  public void joinThread(final String threadName) throws InterruptedException {
    joinThread(threadName, 0);
  }

  public void joinThread(final String threadName, final long millisecondsToTimeout)
      throws InterruptedException {
    final ConcurrentTestThread thread = getThread(threadName);
    if (thread == null) {
      fail("Unknown Thread: " + threadName); //$NON-NLS-1$
    }
    else {
      thread.join(millisecondsToTimeout);
    }
  }

  /**
   * Stores the current result to be accessible during the test
   */
  @Override
  public void run(final TestResult result) {
    currentResult = result;
    super.run(result);
  }

  @Override
  protected void setUp() throws Exception {
    threadGroup = new ThreadedTestGroup(this);
    threadGroup.setTestResult(currentResult);
  }

  /**
   * Sleep and ignore interruption
   */
  public void sleep(final long milliseconds) {
    try {
      Thread.sleep(milliseconds);
    }
    catch (final InterruptedException ignored) {
      Thread.currentThread().interrupt();
    }
  }

  /**
   * Run all threads and wait for them to finish without timeout
   */
  protected void startAndJoinAllThreads() {
    startAndJoinThreads(0);
  }

  /**
   * Run all threads and wait for them to finish. Assume deadlock after
   * millisecondsToDeadlock and time out then.
   */
  protected void startAndJoinThreads(final long millisecondsToDeadlock) {
    startThreads();
    joinAllThreads(millisecondsToDeadlock);
  }

  /**
   * Start all threads that haven't been started yet.
   */
  protected void startThreads() {
    final Iterator<ConcurrentTestThread> all = threads.values().iterator();
    while (all.hasNext()) {
      startThread(all.next());
    }
    Thread.yield();
  }

  private void startThread(final ConcurrentTestThread thread) {
    if (thread.isAlive() || thread.isInterrupted()) {
      return;
    }
    thread.start();
    thread.hasStarted = true;
  }

  @Override
  protected void tearDown() throws Exception {
    interruptAllAliveThreads();
    threads = new Hashtable<String, ConcurrentTestThread>();
    checkpoints = new Vector<String>();
    deadlockDetected = false;
    threadGroup = null;
    currentResult = null;
  }

  /**
   * Wait till a checkpoint has been reached by another thread
   */
  public synchronized void waitForCheckpoint(final String checkpointName) {
    while (!checkpointReached(checkpointName)) {
      try {
        wait();
      }
      catch (final InterruptedException ignored) {
        Thread.currentThread().interrupt();
      }
    }
  }

  /**
   * Wait till a thread has regularly finished. This may never happen. see also
   * joinThread(String threadName);
   */
  public synchronized void waitUntilFinished(final String threadName) {
    while (!hasThreadFinished(threadName)) {
      try {
        wait();
      }
      catch (final InterruptedException ignored) {
        Thread.currentThread().interrupt();
      }
    }
  }
}