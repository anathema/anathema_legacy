package net.disy.commons.core.testing;

import net.disy.commons.core.exception.NestingRuntimeException;
import net.disy.commons.core.util.ISimpleBlock;

public abstract class ExceptionConvertingBlock implements ISimpleBlock {

  public final void execute() {
    try {
      executeExceptionThrowing();
    }
    catch (Exception exception) {
      throw new NestingRuntimeException(exception);
    }
  }

  public abstract void executeExceptionThrowing() throws Exception;

}
