// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 07.03.2005
package net.disy.commons.core.testing;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ISimpleBlock;

import org.jmock.core.Constraint;
import org.jmock.core.MockObjectSupportTestCase;

// NOT_PUBLISHED
public class CoreTestCase extends MockObjectSupportTestCase {

  public static void assertMatches(String regexp, String actual) {
    assertHasRegexp(regexp, actual);
  }

  public static void assertHasRegexp(String regexp, String actual) {
    Matcher match = Pattern.compile(regexp, Pattern.MULTILINE | Pattern.DOTALL).matcher(actual);
    boolean found = match.find();
    if (!found) {
      fail("The regexp <" + regexp + "> was not found in '" + actual + "'."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
  }

  public static final void assertThrowsIllegalArgumentException(ISimpleBlock block) {
    assertThrowsException(IllegalArgumentException.class, block);
  }

  public final static void assertThrowsException(
      Class<? extends Exception> exceptionClass,
      ISimpleBlock block) {
    try {
      block.execute();
      fail("expected: " + exceptionClass.getName() + ", actual: no exception thrown"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception thrown) {
      assertIsAssignableFrom(exceptionClass, thrown.getClass());
    }
  }

  public final static void assertThrowsException(
      Class<? extends Exception> exceptionClass,
      ExceptionConvertingBlock block) {
    try {
      block.execute();
      fail("expected: " + exceptionClass.getName() + ", actual: no exception thrown"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception thrown) {
      assertIsAssignableFrom(exceptionClass, thrown.getCause().getClass());
    }
  }

  public void assertIsInstanceOf(Class<?> expectedClass, Object object) {
    assertNotNull(object);
    assertIsAssignableFrom(expectedClass, object.getClass());
  }

  public final static void assertIsAssignableFrom(Class<?> expected, Class<?> actual) {
    assertTrue("expected: " + expected + ", actual: " + actual, expected.isAssignableFrom(actual)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public final static Object assertSerialization(Object object) {
    try {
      Object deserializedObject = serializeAndDeserialize(object);
      if (object.getClass().isArray()) {
        assertEquals("deserialized vs. original", (Object[]) object, (Object[]) deserializedObject); //$NON-NLS-1$
      }
      else {
        assertEquals("deserialized vs. original", object, deserializedObject); //$NON-NLS-1$
      }
      return deserializedObject;
    }
    catch (Exception e) {
      fail("Unable to Serialize object '" + object + "' " + e); //$NON-NLS-1$ //$NON-NLS-2$
      throw new UnreachableCodeReachedException();
    }
  }

  public final static void assertEquals(Object[] expected, Object[] actual) {
    assertEquals(null, expected, actual);
  }

  public final static void assertEquals(String message, Object[] expected, Object[] actual) {
    message = (message == null) ? "" : message + " - "; //$NON-NLS-1$//$NON-NLS-2$
    if (expected == null) {
      assertNull(message + "actual is not null", actual); //$NON-NLS-1$
      return;
    }
    assertNotNull(message + "actual is null", actual); //$NON-NLS-1$
    assertEquals(message + "array lengths", expected.length, actual.length); //$NON-NLS-1$
    for (int i = 0; i < expected.length; ++i) {
      assertEquals(message + "at index " + i, expected[i], actual[i]); //$NON-NLS-1$
    }
  }

  public static final Object serializeAndDeserialize(Object object)
      throws IOException,
      ClassNotFoundException {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    ObjectOutputStream out = new ObjectOutputStream(byteOut);
    out.writeObject(object);
    ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray());
    ObjectInputStream in = new ObjectInputStream(byteIn);
    return in.readObject();
  }

  protected static final void assertEqualsAndHashCode(Object first, Object second) {
    Ensure.ensureArgumentNotNull(first);
    assertEquals(first, second);
    assertEquals(first.hashCode(), second.hashCode());
  }

  public final static void assertNotEquals(Object object1, Object object2) {
    if (object1 == null
        && object2 == null
        || object1 != null
        && object2 != null
        && (object1.equals(object2) || object2.equals(object1))) {
      failEquals(null, object1);
    }
  }

  private static void failEquals(String message, Object expected) {
    fail(format(message, expected));
  }

  public static final String format(String message, Object expected) {
    String formatted = ""; //$NON-NLS-1$
    if (message != null) {
      formatted = message + " "; //$NON-NLS-1$
    }
    return formatted + "expected not equals, but was both:<" + expected + ">"; //$NON-NLS-1$ //$NON-NLS-2$
  }

  public static final void assertEquals(int[] expected, int[] actual) {
    assertEquals(null, expected, actual);
  }

  public static final void assertEquals(String message, int[] expected, int[] actual) {
    if (expected == null) {
      assertNull(message, actual);
      return;
    }
    assertNotNull(message, actual);
    assertEquals(concatMessage(message, "array-length: "), expected.length, actual.length); //$NON-NLS-1$
    for (int i = 0; i < expected.length; ++i) {
      assertEquals(concatMessage(message, "index: " + i), expected[i], actual[i]); //$NON-NLS-1$
    }
  }

  public static final void assertEquals(byte[] expected, byte[] actual) {
    assertEquals(null, expected, actual);
  }

  public static final void assertEquals(String message, byte[] expected, byte[] actual) {
    if (expected == null) {
      assertNull(message, actual);
      return;
    }
    assertNotNull(message, actual);
    assertEquals(concatMessage(message, "array-length: "), expected.length, actual.length); //$NON-NLS-1$
    for (int i = 0; i < expected.length; ++i) {
      assertEquals(concatMessage(message, "index: " + i), expected[i], actual[i]); //$NON-NLS-1$
    }
  }

  public static final void assertEquals(double[] expected, double[] actual) {
    assertEquals(null, expected, actual);
  }

  public static final void assertEquals(double[] expected, double[] actual, double delta) {
    assertEquals(null, expected, actual, delta);
  }

  public static final void assertEquals(String message, double[] expected, double[] actual) {
    assertEquals(message, expected, actual, 0.0);
  }

  private static final void assertEquals(
      String message,
      double[] expected,
      double[] actual,
      double delta) {
    if (expected == null) {
      assertNull(message, actual);
      return;
    }
    assertNotNull(message, actual);
    assertEquals(concatMessage(message, "array-length: "), expected.length, actual.length); //$NON-NLS-1$
    for (int i = 0; i < expected.length; ++i) {
      assertEquals(concatMessage(message, "index: " + i), expected[i], actual[i], delta); //$NON-NLS-1$
    }
  }

  private static String concatMessage(String message, String addition) {
    return (message == null ? "" : message + "; ") + (addition); //$NON-NLS-1$ //$NON-NLS-2$
  }

  protected void assertThat(Object something, Constraint matches) {
    if (!matches.eval(something)) {
      StringBuffer message = new StringBuffer("\nExpected: "); //$NON-NLS-1$
      matches.describeTo(message);
      message.append("\nbut got : ").append(something).append('\n'); //$NON-NLS-1$
      fail(message.toString());
    }
  }

  public static final void assertEquals(double expected, double actual) {
    assertEquals(expected, actual, 0.0);
  }

  public static final void assertEquals(String message, double expected, double actual) {
    assertEquals(message, expected, actual, 0.0);
  }
}