/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing;

import static net.disy.commons.core.testing.TestingMatchers.serializable;
import static net.disy.commons.testing.Assert.assertEqualArrays;
import static net.disy.commons.testing.Assert.assertEqualsWithDelta0;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.io.IOException;

import junit.framework.TestCase;

public abstract class CoreTestCase extends TestCase {

  public final static void assertSerialization(final Object object) {
    assertThat(object, is(serializable()));
  }

  public static final Object serializeAndDeserialize(final Object object)
      throws IOException,
      ClassNotFoundException {
    return net.disy.commons.testing.Assert.serializeAndDeserialize(object);
  }

  public final static void assertNotEquals(final Object object1, final Object object2) {
    net.disy.commons.testing.Assert.assertNotEquals(object1, object2);
  }

  public static final void assertEquals(final int[] expected, final int[] actual) {
    assertEqualArrays(expected, actual);
  }

  public static final void assertEquals(final double[] expected, final double[] actual) {
    assertEqualArrays(expected, actual);
  }

  public static final void assertEquals(final double expected, final double actual) {
    assertEqualsWithDelta0(expected, actual);
  }
}