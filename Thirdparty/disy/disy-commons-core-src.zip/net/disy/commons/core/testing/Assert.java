/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing;

import static org.junit.Assert.*;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IExceptionThrowingBlock;

public class Assert extends net.disy.commons.testing.Assert {

  /**
   * @deprecated as of 20.08.2007 (reupke), use org.junit.Test(expected=...) instead
   */
  @Deprecated
  public static void assertThrowsException(
      final Class<? extends Exception> exceptionClass,
      final IExceptionThrowingBlock<?> block) {
    try {
      block.execute();
      fail("expected: " + exceptionClass.getName() + ", actual: no exception thrown"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (final Throwable thrown) {
      if (!thrown.getClass().isAssignableFrom(exceptionClass)) {
        fail("expected: " + exceptionClass.getName() + ", actual: " + thrown); //$NON-NLS-1$ //$NON-NLS-2$
      }
    }
  }

  public static void assertEqualsAndHashCode(final Object first, final Object second) {
    Ensure.ensureArgumentNotNull(first);
    assertEquals(first, second);
    assertEquals(first.hashCode(), second.hashCode());
  }
}