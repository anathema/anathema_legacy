/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.testing.io;

import static net.disy.commons.core.io.IOUtilities.*;
import static net.disy.commons.core.util.CollectionUtilities.*;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.disy.commons.core.io.AbstractFile;
import net.disy.commons.core.io.IFile;
import net.disy.commons.core.predicate.IPredicate;

@SuppressWarnings("nls")
public class DummyFile extends AbstractFile {

  public static DummyFile CreateExisting(final String name, final byte... content) throws Exception {
    final DummyFile dummyFile = new DummyFile(name);
    dummyFile.create(content);
    return dummyFile;
  }

  public static DummyFile CreateDirectory(final String dirName) {
    final DummyFile dummyFile = new DummyFile(dirName);
    dummyFile.exists = true;
    return dummyFile;
  }

  private boolean exists;
  private byte[] content;
  private final Map<String, IFile> children = new HashMap<String, IFile>();
  private String name;

  public DummyFile(final String name) {
    this.name = name;
  }

  @Override
  public boolean mkDirs() {
    throw new UnsupportedOperationException("Dummy");
  }

  @Deprecated
  @Override
  public IFile[] listFiles(final FileFilter fileFilter) {
    throw new UnsupportedOperationException("Dummy");
  }

  @Override
  public boolean isDirectory() {
    return exists && content == null;
  }

  @Override
  public String getName() {
    return name;
  }

  @Deprecated
  @Override
  public File getFile() {
    throw new UnsupportedOperationException("Dummy");
  }

  @Override
  public IFile getChild(final String child) {
    if (!children.containsKey(child)) {
      children.put(child, new DummyFile(child));
    }
    return children.get(child);
  }

  @Override
  public String getAbsolutePath() {
    return "/d/ummy/" + name;
  }

  @Override
  public boolean exists() {
    return exists;
  }

  @Override
  public Reader createReader() throws FileNotFoundException {
    if (content == null) {
      throw new FileNotFoundException(name);
    }
    return new StringReader(new String(content));
  }

  @Override
  public OutputStream createOutputStream() {
    return new ByteArrayOutputStream() {
      @Override
      public void close() throws IOException {
        super.close();
        create(toByteArray());
      }
    };
  }

  @Override
  public void createNew() throws IOException {
    if (exists()) {
      throw new IOException("File already exists");
    }
    final byte[] newContent = new byte[0];
    create(newContent);
  }

  private void create(final byte[] newContent) {
    content = newContent;
    exists = true;
  }

  @Override
  public InputStream openInputStream() {
    if (content == null) {
      throw new IllegalStateException("File not found " + name);
    }
    return new ByteArrayInputStream(content);
  }

  @Override
  public IFile[] getChildren(final IPredicate<IFile> predicate) {
    final List<IFile> files = filter(children.values(), predicate);
    return files.toArray(new IFile[files.size()]);
  }

  public DummyFile createSubdirectory(final String dirName) {
    final DummyFile directoryFile = DummyFile.CreateDirectory(dirName);
    addChild(directoryFile);
    return directoryFile;
  }

  public DummyFile createExistingChild(final String child, final byte... bytes) throws Exception {
    final DummyFile newFile = CreateExisting(child, bytes);
    addChild(newFile);
    return newFile;
  }

  public void addChild(final DummyFile newFile) {
    children.put(newFile.name, newFile);
  }

  public DummyFile createNonExistingChild(final String child) {
    final DummyFile file = new DummyFile(child);
    addChild(file);
    return file;
  }

  @Override
  public void delete() {
    exists = false;
    content = null;
  }

  @Override
  public void rename(final String newName) {
    name = newName;
  }

  @Override
  public void setContent(InputStream content) throws IOException {
    InputStreamReader contentReader = new InputStreamReader(content);
    create(readString(contentReader).getBytes());
  }
}