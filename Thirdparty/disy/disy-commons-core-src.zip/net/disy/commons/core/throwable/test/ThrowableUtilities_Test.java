/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.throwable.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import net.disy.commons.core.throwable.ThrowableUtilities;

import org.junit.Test;

public class ThrowableUtilities_Test {

  @Test
  public void propagatesRuntimeException() throws Exception {
    final RuntimeException runtimeException = new RuntimeException();
    try {
      ThrowableUtilities.throwAtRuntime(runtimeException);
    }
    catch (final Throwable throwable) {
      assertThat(throwable, is(sameInstance((Throwable) runtimeException)));
    }
  }

  @Test
  public void propagatesError() throws Exception {
    final Error error = new Error();
    try {
      ThrowableUtilities.throwAtRuntime(error);
    }
    catch (final Throwable throwable) {
      assertThat(throwable, is(sameInstance((Throwable) error)));
    }
  }

  @Test
  public void wrappesExceptionIntoRuntimeException() throws Exception {
    final Exception exception = new Exception();
    try {
      ThrowableUtilities.throwAtRuntime(exception);
    }
    catch (final RuntimeException throwable) {
      assertThat(throwable.getCause(), is(sameInstance((Throwable) exception)));
    }
  }
}