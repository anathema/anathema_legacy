/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.progress;

import net.disy.commons.core.util.Ensure;

public class ObservableCancelableAdapter implements IObservableCancelable {

  private final ICancelable cancelable;

  public ObservableCancelableAdapter(ICancelable cancelable) {
    Ensure.ensureArgumentNotNull(cancelable);
    this.cancelable = cancelable;
  }

  @Override
  public boolean isCanceled() {
    return cancelable.isCanceled();
  }

  @Override
  public void addCanceledListener(ICanceledListener listener) {
    if (cancelable instanceof IObservableCancelable) {
      ((IObservableCancelable) cancelable).addCanceledListener(listener);
    }
  }

  @Override
  public void removeCanceledListener(ICanceledListener listener) {
    if (cancelable instanceof IObservableCancelable) {
      ((IObservableCancelable) cancelable).removeCanceledListener(listener);
    }
  }
}