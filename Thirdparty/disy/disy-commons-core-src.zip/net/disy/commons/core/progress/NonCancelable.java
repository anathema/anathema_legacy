/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.progress;

/**
 * @author gebhard
 */
public class NonCancelable implements IObservableCancelable {

  private final static NonCancelable instance = new NonCancelable();

  public static NonCancelable getInstance() {
    return instance;
  }

  private NonCancelable() {
    //nothing to do
  }

  @Override
  public boolean isCanceled() {
    return false;
  }

  @Override
  public void addCanceledListener(final ICanceledListener listener) {
    //nothing to do
  }

  @Override
  public void removeCanceledListener(final ICanceledListener listener) {
    //nothing to do
  }
}