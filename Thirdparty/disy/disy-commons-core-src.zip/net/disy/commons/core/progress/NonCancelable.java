package net.disy.commons.core.progress;

/**
 * @author gebhard
 */
public class NonCancelable implements IObservableCancelable {

  private final static NonCancelable instance = new NonCancelable();

  /** @deprecated As of 27.05.2005 (gebhard), replaced by {@link #getInstance()}*/
  @Deprecated
  public NonCancelable() {
    //nothing to do
  }

  public boolean isCanceled() {
    return false;
  }

  public static NonCancelable getInstance() {
    return instance;
  }

  public void addCanceledListener(ICanceledListener listener) {
    //nothing to do
  }

  public void removeCanceledListener(ICanceledListener listener) {
    //nothing to do
  }
}