package net.disy.commons.core.progress;

public interface IRunnableExecuter {

  public void execute(Runnable runnable);

}