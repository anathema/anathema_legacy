// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;

// NOT_PUBLISHED
public class NullProgressMonitor implements IProgressMonitor {

  private final static NullProgressMonitor instance = new NullProgressMonitor();

  public static NullProgressMonitor getInstance() {
    return instance;
  }

  /** @deprecated As of 10.05.2005 (gebhard), replaced by {@link #getInstance()} */
  @Deprecated
  public NullProgressMonitor() {
    //nothing to do
  }

  public void beginTask(String name, int totalWork) {
    //nothing to do
  }

  public void done() {
    //nothing to do
  }

  public void setCanceled(boolean canceled) {
    //nothing to do
  }

  public void subTask(String name) {
    //nothing to do
  }

  public void worked(int work) {
    //nothing to do
  }

  public boolean isCanceled() {
    return false;
  }

  public void addCanceledListener(ICanceledListener listener) {
    //nothing to do
  }

  public void removeCanceledListener(ICanceledListener listener) {
    //nothing to do
  }
}