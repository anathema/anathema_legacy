/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.progress;

public class NullProgressMonitor implements IProgressMonitor {

  public NullProgressMonitor() {
    //nothing to do
  }

  @Override
  public void beginTask(final String name, final int totalWork) {
    //nothing to do
  }

  @Override
  public void beginTaskWithUnknownTotalWork(final String name) {
    //nothing to do
  }

  @Override
  public void done() {
    //nothing to do
  }

  @Override
  public void setCanceled(final boolean canceled) {
    //nothing to do
  }

  @Override
  public void subTask(final String name) {
    //nothing to do
  }

  @Override
  public void worked(final int work) {
    //nothing to do
  }

  @Override
  public boolean equals(final Object object) {
    return object instanceof NullProgressMonitor;
  }

  @Override
  public int hashCode() {
    return getClass().hashCode();
  }

  public static final IProgressMonitor INSTANCE = new NullProgressMonitor();
}