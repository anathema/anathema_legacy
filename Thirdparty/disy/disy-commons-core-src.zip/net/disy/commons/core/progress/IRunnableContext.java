// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;

import java.lang.reflect.InvocationTargetException;

/**
 * Interface for UI components which can execute a long-running operation in the form of 
 * an {@link net.disy.commons.core.progress.IRunnableWithProgress}. The context
 * is responsible for displaying a progress indicator and Cancel button to the end user while
 * the operation is in progress; the context supplies a progress monitor to be used from code
 * running inside the operation. Note that an {@link IRunnableContext} is not a runnable itself. 
 * 
 * @author gebhard
 */
public interface IRunnableContext {

  /** Runs the given {@link net.disy.commons.core.progress.IRunnableWithProgress}
   * in this context. For example, if this is a ProgressMonitorDialog then the runnable is run
   * using this dialog's progress monitor.
   * 
   * @param cancelable <code>true</code> to enable the cancelation, and <code>false</code> to
   *  make the operation uncancellable
   * @param runnable the runnable to run 
   * @throws InvocationTargetException wraps any exception or error which occurs while running
   * the runnable
   * @throws InterruptedException propagated by the context if the runnable acknowledges
   *  cancelation by throwing this exception. This should not be thrown if cancelable is false.*/
  public void run(boolean cancelable, IRunnableWithProgress runnable)
      throws InterruptedException,
      InvocationTargetException;
}