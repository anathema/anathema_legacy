// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;
 
/**
 * @author gebhard
 * @published
 */
public interface ICancelable {

  /** Returns whether cancelation of current operation has been requested. Long-running
   * operations should poll to see if cancelation has been requested.
   * 
   * @return <code>true</code> if cancellation has been requested, and <code>false</code>
   * otherwise
   * @published */
  public boolean isCanceled();
}