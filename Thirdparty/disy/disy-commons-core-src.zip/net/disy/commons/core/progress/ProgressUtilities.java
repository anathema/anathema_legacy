// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;

import java.io.InterruptedIOException;


// NOT_PUBLISHED
public class ProgressUtilities {
  private ProgressUtilities() {
    //not used
  }

  public static void checkInterrupted(ICancelable cancelable) throws InterruptedException {
    if (cancelable.isCanceled()) {
      throw new InterruptedException();
    }
  }

  public static void checkInterruptedIO(ICancelable cancelable) throws InterruptedIOException {
    if (cancelable.isCanceled()) {
      throw new InterruptedIOException();
    }
  }
}