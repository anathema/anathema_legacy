package net.disy.commons.core.progress;

import net.disy.commons.core.exception.CentralExceptionHandling;

public class DefaultRunnableExecuter implements IRunnableExecuter {

  private static int count = 0;
  private final String threadName;

  public DefaultRunnableExecuter(String threadName) {
    this.threadName = threadName;
  }

  public void execute(Runnable runnable) {
    String name = threadName + "-" + (++count); //$NON-NLS-1$
    Thread thread = new Thread(CentralExceptionHandling.createThreadGroup(name), runnable);
    thread.setName(name);
    thread.start();
  }
}