/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.progress;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.IClosure;

public class DefaultCancelable implements IObservableCancelable {

  private final ListenerList<ICanceledListener> canceledListeners = new ListenerList<ICanceledListener>();
  private boolean canceled = false;

  @Override
  public synchronized void addCanceledListener(final ICanceledListener listener) {
    canceledListeners.add(listener);
  }

  @Override
  public synchronized void removeCanceledListener(final ICanceledListener listener) {
    canceledListeners.remove(listener);
  }

  @Override
  public boolean isCanceled() {
    return canceled;
  }

  public void setCanceled(final boolean canceled) {
    if (this.canceled == canceled) {
      return;
    }
    this.canceled = canceled;
    if (canceled) {
      fireCanceled();
    }
  }

  private void fireCanceled() {
    canceledListeners.forAllDo(new IClosure<ICanceledListener>() {
      @Override
      public void execute(final ICanceledListener listener) {
        listener.canceled();
      }
    });
  }
}