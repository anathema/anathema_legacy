//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class DefaultCancelable implements IObservableCancelable {

  private final Collection canceledListeners = new ArrayList();
  private boolean canceled = false;

  public synchronized void addCanceledListener(ICanceledListener listener) {
    Ensure.ensureNotNull(listener);
    canceledListeners.add(listener);
  }

  public synchronized void removeCanceledListener(ICanceledListener listener) {
    canceledListeners.remove(listener);
  }

  public boolean isCanceled() {
    return canceled;
  }

  public void setCanceled(boolean canceled) {
    if (this.canceled == canceled) {
      return;
    }
    this.canceled = canceled;
    if (canceled) {
      fireCanceled();
    }
  }

  private void fireCanceled() {
    List clonedListeners;
    synchronized (this) {
      clonedListeners = new ArrayList(canceledListeners);
    }
    for (Iterator iter = clonedListeners.iterator(); iter.hasNext();) {
      ICanceledListener listener = (ICanceledListener) iter.next();
      listener.canceled();
    }
  }
}