//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.progress;

import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.ListenerList;

// NOT_PUBLISHED
public class DefaultCancelable implements IObservableCancelable {

  private final ListenerList<ICanceledListener> canceledListeners = new ListenerList<ICanceledListener>();
  private boolean canceled = false;

  public synchronized void addCanceledListener(ICanceledListener listener) {
    canceledListeners.add(listener);
  }

  public synchronized void removeCanceledListener(ICanceledListener listener) {
    canceledListeners.remove(listener);
  }

  public boolean isCanceled() {
    return canceled;
  }

  public void setCanceled(boolean canceled) {
    if (this.canceled == canceled) {
      return;
    }
    this.canceled = canceled;
    if (canceled) {
      fireCanceled();
    }
  }

  private void fireCanceled() {
    canceledListeners.forAllDo(new IListenerClosure<ICanceledListener>() {
      public void execute(ICanceledListener listener) {
        listener.canceled();
      }
    });
  }
}