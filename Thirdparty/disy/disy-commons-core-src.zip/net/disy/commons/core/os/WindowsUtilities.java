/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.os;

import java.io.IOException;

public class WindowsUtilities {
  private static final String SYSTEM_PROPERTY_OS_NAME = "os.name"; //$NON-NLS-1$
  private static final String WINDOWS_NT_COMMAND = "cmd.exe /c "; //$NON-NLS-1$
  private static final String WINDOWS_9X_COMMAND = "command.com /c "; //$NON-NLS-1$

  private static boolean isWindowsNt() {
    final String os = getOsProperty();
    return os.indexOf("nt") > -1 //$NON-NLS-1$
        || os.indexOf("windows 2000") > -1 //$NON-NLS-1$
        || os.indexOf("windows xp") > -1 //$NON-NLS-1$
        || os.indexOf("windows 2003") > -1 //$NON-NLS-1$
        || os.indexOf("vista") > -1 //$NON-NLS-1$
        || os.indexOf("windows 7") > -1; //$NON-NLS-1$
  }

  private static String getOsProperty() {
    return System.getProperty(SYSTEM_PROPERTY_OS_NAME).toLowerCase();
  }

  private static boolean isWindows9x() {
    return getOsProperty().indexOf("windows 9") > -1; //$NON-NLS-1$
  }

  public static boolean isWindows() {
    return isWindowsNt() || isWindows9x();
  }

  public static Process executeMsdosCommand(final String command) throws IOException {
    final Runtime runtime = Runtime.getRuntime();
    if (isWindowsNt()) {
      return runtime.exec(WINDOWS_NT_COMMAND + command);
    }
    if (isWindows9x()) {
      return runtime.exec(WINDOWS_9X_COMMAND + command);
    }
    throw new IllegalStateException("Operating System must be Windows"); //$NON-NLS-1$
  }
}