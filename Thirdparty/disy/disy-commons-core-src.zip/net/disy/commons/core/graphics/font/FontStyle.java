package net.disy.commons.core.graphics.font;

import java.awt.Font;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class FontStyle implements Serializable {
  private String name;
  private final static List ALL = new ArrayList();

  public final static FontStyle PLAIN = new FontStyle("Plain", false, false) {//$NON-NLS-1$
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitPlainFontStyle(this);
    }
  };
  public final static FontStyle ITALIC = new FontStyle("Italic", false, true) {//$NON-NLS-1$
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitItalicFontStyle(this);
    }
  };
  public final static FontStyle BOLD = new FontStyle("Bold", true, false) {//$NON-NLS-1$
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitBoldFontStyle(this);
    }
  };
  public final static FontStyle BOLD_ITALIC = new FontStyle("Bold italic", true, true) {//$NON-NLS-1$
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitBoldItalicFontStyle(this);
    }
  };
  private final boolean bold;
  private final boolean italic;

  private FontStyle(String name, boolean bold, boolean italic) {
    ALL.add(this);
    this.bold = bold;
    this.name = name;
    this.italic = italic;
  }

  public static FontStyle[] getAll() {
    return (FontStyle[]) ALL.toArray(new FontStyle[ALL.size()]);
  }

  public String toString() {
    return name;
  }

  public abstract void accept(IFontStyleVisitor visitor);

  public boolean isItalic() {
    return italic;
  }

  public boolean isBold() {
    return bold;
  }

  public boolean isPlain() {
    return !isBold() && !isItalic();
  }

  public String getName() {
    return name;
  }

  public static FontStyle getByName(String name) {
    for (int index = 0; index < ALL.size(); index++) {
      FontStyle fontStyle = (FontStyle) ALL.get(index);
      if (name.equals(fontStyle.getName())) {
        return fontStyle;
      }
    }
    throw new IllegalArgumentException("No font style defined for name " + name); //$NON-NLS-1$
  }

  protected Object readResolve() {
    return getByName(getName());
  }

  public static FontStyle getFrom(Font font) {
    if (font.isBold() && font.isItalic()) {
      return BOLD_ITALIC;
    }
    if (font.isBold()) {
      return BOLD;
    }
    if (font.isItalic()) {
      return ITALIC;
    }
    return PLAIN;
  }
}