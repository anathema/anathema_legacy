/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.object.test;

import static org.junit.Assert.*;

import java.util.HashSet;
import java.util.Set;

import net.disy.commons.core.object.ObjectPair;

import org.junit.Test;

public class ObjectPairTest {

  @Test
  public void testObjectPairEquals() {
    final Set<ObjectPair<String, String>> set = new HashSet<ObjectPair<String, String>>();

    set.add(aa());
    set.add(ab());
    set.add(an());
    set.add(ba());
    set.add(bb());
    set.add(bn());
    set.add(na());
    set.add(nb());
    set.add(nn());
    assertEquals(9, set.size());

    set.add(aa());
    set.add(ab());
    set.add(an());
    set.add(ba());
    set.add(bb());
    set.add(bn());
    set.add(na());
    set.add(nb());
    set.add(nn());
    assertEquals(9, set.size());

    set.remove(aa());
    set.remove(ab());
    set.remove(an());
    set.remove(ba());
    set.remove(bb());
    set.remove(bn());
    set.remove(na());
    set.remove(nb());
    set.remove(nn());
    assertEquals(0, set.size());
  }

  private static ObjectPair<String, String> aa() {
    return new ObjectPair<String, String>("a", "a"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private static ObjectPair<String, String> ab() {
    return new ObjectPair<String, String>("a", "b"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private static ObjectPair<String, String> an() {
    return new ObjectPair<String, String>("a", null); //$NON-NLS-1$
  }

  private static ObjectPair<String, String> ba() {
    return new ObjectPair<String, String>("b", "a"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private static ObjectPair<String, String> bb() {
    return new ObjectPair<String, String>("b", "b"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private static ObjectPair<String, String> bn() {
    return new ObjectPair<String, String>("b", null); //$NON-NLS-1$
  }

  private static ObjectPair<String, String> na() {
    return new ObjectPair<String, String>(null, "a"); //$NON-NLS-1$
  }

  private static ObjectPair<String, String> nb() {
    return new ObjectPair<String, String>(null, "b"); //$NON-NLS-1$
  }

  private static ObjectPair<String, String> nn() {
    return new ObjectPair<String, String>(null, null);
  }
}