/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.object;

import net.disy.commons.core.util.ObjectUtilities;

public class ObjectPair<T, U> {
  private final T firstObject;
  private final U secondObject;

  public ObjectPair(final T firstObject, final U secondObject) {
    this.firstObject = firstObject;
    this.secondObject = secondObject;
  }

  public final T getFirstObject() {
    return this.firstObject;
  }

  public final U getSecondObject() {
    return this.secondObject;
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof ObjectPair)) {
      return false;
    }
    final ObjectPair<?, ?> other = (ObjectPair<?, ?>) obj;
    return ObjectUtilities.equals(this.firstObject, other.firstObject)
        && ObjectUtilities.equals(this.secondObject, other.secondObject);
  }

  @Override
  public final int hashCode() {
    return ObjectUtilities.getHashCode(this.firstObject, this.secondObject);
  }

  @Override
  public String toString() {
    final StringBuffer sb = new StringBuffer();
    sb.append('(');
    sb.append(this.firstObject);
    sb.append(" . "); //$NON-NLS-1$
    sb.append(this.secondObject);
    sb.append(')');
    return sb.toString();
  }
}