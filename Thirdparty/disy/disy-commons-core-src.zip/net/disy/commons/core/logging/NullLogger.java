//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.logging;

public class NullLogger implements ILogger {

  public void warn(Object message, Throwable throwable) {
    //nothing to do
  }

  public void info(Object message) {
    //  nothing to do
  }

  public void debug(Object message) {
    //  nothing to do
  }

  public boolean isDebugEnabled() {
    return false;
  }

  public void debug(Object message, Throwable throwable) {
    //  nothing to do
  }

  public void info(Throwable throwable) {
    //  nothing to do
  }

  public void info(Object message, Throwable throwable) {
    //  nothing to do
  }

  public void warn(Object message) {
    //  nothing to do
  }

  public void warn(Throwable throwable) {
    //  nothing to do
  }

  public void error(Object message) {
    //  nothing to do
  }

  public void error(Throwable throwable) {
    //  nothing to do
  }

  public void error(Object message, Throwable throwable) {
    //  nothing to do
  }

  public void fatal(Object message) {
    //  nothing to do
  }

  public void fatal(Throwable throwable) {
    //  nothing to do
  }

  public void fatal(Object message, Throwable throwable) {
    //  nothing to do
  }
}