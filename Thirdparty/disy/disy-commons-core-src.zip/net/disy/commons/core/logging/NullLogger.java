//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.logging;

public class NullLogger implements ILogger {

  public void warn(String message, Throwable throwable) {
    //nothing to do
  }

  public void info(String message) {
    //  nothing to do
  }

  public void debug(String message) {
    //  nothing to do
  }

  public boolean isDebugEnabled() {
    return false;
  }

  public void debug(String message, Throwable throwable) {
    //  nothing to do
  }

  public void info(Throwable throwable) {
    //  nothing to do
  }

  public void info(String message, Throwable throwable) {
    //  nothing to do
  }

  public void warn(String message) {
    //  nothing to do
  }

  public void warn(Throwable throwable) {
    //  nothing to do
  }

  public void error(String message) {
    //  nothing to do
  }

  public void error(Throwable throwable) {
    //  nothing to do
  }

  public void error(String message, Throwable throwable) {
    //  nothing to do
  }

  public void fatal(String message) {
    //  nothing to do
  }

  public void fatal(Throwable throwable) {
    //  nothing to do
  }

  public void fatal(String message, Throwable throwable) {
    //  nothing to do
  }
}