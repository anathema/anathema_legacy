// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 13.06.2005
package net.disy.commons.core.logging;

// NOT_PUBLISHED
public interface ILogger {

  public void warn(Object message, Throwable throwable);

  public void info(Object message);

  public void debug(Object message);

  public boolean isDebugEnabled();

  public void debug(Object message, Throwable throwable);

  public void info(Throwable throwable);

  public void info(Object message, Throwable throwable);

  public void warn(Object message);

  public void warn(Throwable throwable);

  public void error(Object message);

  public void error(Throwable throwable);

  public void error(Object message, Throwable throwable);

  public void fatal(Object message);

  public void fatal(Throwable throwable);

  public void fatal(Object message, Throwable throwable);

}
