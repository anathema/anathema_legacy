// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 13.06.2005
package net.disy.commons.core.logging;

// NOT_PUBLISHED
public interface ILogger {

  public void warn(String message, Throwable throwable);

  public void info(String message);

  public void debug(String message);

  public boolean isDebugEnabled();

  public void debug(String message, Throwable throwable);

  public void info(Throwable throwable);

  public void info(String message, Throwable throwable);

  public void warn(String message);

  public void warn(Throwable throwable);

  public void error(String message);

  public void error(Throwable throwable);

  public void error(String message, Throwable throwable);

  public void fatal(String message);

  public void fatal(Throwable throwable);

  public void fatal(String message, Throwable throwable);

}
