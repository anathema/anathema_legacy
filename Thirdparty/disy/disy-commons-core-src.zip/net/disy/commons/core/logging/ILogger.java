/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.logging;

public interface ILogger {

  /** 
   * @return true, falls der Loglevel "debug" aktiv ist, false sonst.
   */
  public boolean isDebugEnabled();

  /** 
   * Gibt den Text mit Loglevel "debug" aus.
   * @param message Text, der ausgegeben werden soll
   */
  public void debug(String message);

  /** 
   * Gibt den Stacktrace des Throwable mit Loglevel "debug" aus.
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void debug(Throwable throwable);

  /** 
   * Gibt den Text und den Stacktrace des Throwable mit Loglevel "debug" aus.
   * @param message Text, der ausgegeben werden soll
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void debug(String message, Throwable throwable);

  /** 
   * Gibt den Text mit Loglevel "info" aus.
   * @param message Text, der ausgegeben werden soll
   */
  public void info(String message);

  /** 
   * Gibt den Stacktrace des Throwable mit Loglevel "info" aus.
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void info(Throwable throwable);

  /** 
   * Gibt den Text und den Stacktrace des Throwable mit Loglevel "info" aus.
   * @param message Text, der ausgegeben werden soll
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void info(String message, Throwable throwable);

  /** 
   * Gibt den Text mit Loglevel "warn" aus.
   * @param message Text, der ausgegeben werden soll
   */
  public void warn(String message);

  /** 
   * Gibt den Stacktrace des Throwable mit Loglevel "warn" aus.
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void warn(Throwable throwable);

  /** 
   * Gibt den Text und den Stacktrace des Throwable mit Loglevel "warn" aus.
   * @param message Text, der ausgegeben werden soll
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void warn(String message, Throwable throwable);

  /** 
   * Gibt den Text mit Loglevel "error" aus.
   * @param message Text, der ausgegeben werden soll
   */
  public void error(String message);

  /** 
   * Gibt den Stacktrace des Throwable mit Loglevel "error" aus.
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void error(Throwable throwable);

  /** 
   * Gibt den Text und den Stacktrace des Throwable mit Loglevel "error" aus.
   * @param message Text, der ausgegeben werden soll
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll 
   */
  public void error(String message, Throwable throwable);

  /** 
   * Gibt den Text mit Loglevel "fatal" aus.
   * @param message Text, der ausgegeben werden soll
   * @deprecated (05.05.2010, reupke) FATAL ist ERROR mit nachfolgendem Programmende. 
   */
  @Deprecated
  public void fatal(String message);

  /** 
   * Gibt den Stacktrace des Throwable mit Loglevel "fatal" aus.
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll
   * @deprecated (05.05.2010, reupke) FATAL ist ERROR mit nachfolgendem Programmende. 
   */
  @Deprecated
  public void fatal(Throwable throwable);

  /** 
   * Gibt den Text und den Stacktrace des Throwable mit Loglevel "fatal" aus.
   * @param message Text, der ausgegeben werden soll
   * @param throwable throwable, deren Stacktrace ausgegeben werden soll
   * @deprecated (05.05.2010, reupke) FATAL ist ERROR mit nachfolgendem Programmende. 
   */
  @Deprecated
  public void fatal(String message, Throwable throwable);
}