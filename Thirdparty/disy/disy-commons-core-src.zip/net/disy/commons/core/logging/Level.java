/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.logging;

/**
 * @deprecated 06.05.2010, reupke: unused in Cadenza, unused in {@link ILogger}. 
 * */
@Deprecated
public enum Level {

  ALL, DEBUG, INFO, WARN, ERROR, FATAL, OFF;

  public boolean includes(final Level otherLevel) {
    return compareTo(otherLevel) < 1;
  }

  public static Level getByName(final String levelName) {
    try {
      return valueOf(levelName.toUpperCase());
    }
    catch (final IllegalArgumentException e) {
      throw new IllegalArgumentException("No logging level for name '" + levelName + "' defined."); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public String getName() {
    return name();
  }
}