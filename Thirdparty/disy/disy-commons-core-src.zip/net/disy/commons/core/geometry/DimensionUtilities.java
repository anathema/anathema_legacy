// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 14.02.2005
package net.disy.commons.core.geometry;

import java.awt.Dimension;

// NOT_PUBLISHED
public class DimensionUtilities {

  private DimensionUtilities() {
    // nothing to do
  }

  public static Dimension fitInto(Dimension content, Dimension container) {
    return fitInto(content.getWidth() / content.getHeight(), container);
  }

  public static Dimension fitInto(double contentRatio, Dimension container) {
    double containerRatio = container.getWidth() / container.getHeight();
    double factor = contentRatio / containerRatio;
    if (factor > 1) {
      factor = 1 / factor;
    }
    if (containerRatio < contentRatio) {
      return new Dimension(container.width, (int) (container.height * factor));
    }
    if (containerRatio > contentRatio) {
      return new Dimension((int) (container.width * factor), container.height);
    }
    return container;
  }
}