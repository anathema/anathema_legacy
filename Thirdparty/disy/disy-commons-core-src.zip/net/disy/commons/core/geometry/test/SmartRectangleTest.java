// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.03.2005
package net.disy.commons.core.geometry.test;

import net.disy.commons.core.geometry.SmartRectangle;
import net.disy.commons.core.testing.CoreTestCase;

// NOT_PUBLISHED
public class SmartRectangleTest extends CoreTestCase {

  public void testTranslated() throws Exception {
    SmartRectangle rectangle = new SmartRectangle(2, 3, 12, 13);
    SmartRectangle translated = rectangle.createTranslated(2, 4);
    assertNotSame(rectangle, translated);
    assertEquals("X Coordinate", 4, translated.x); //$NON-NLS-1$
    assertEquals("Y Coordinate", 7, translated.y); //$NON-NLS-1$
    assertEquals("Width", 12, translated.width); //$NON-NLS-1$
    assertEquals("Height", 13, translated.height); //$NON-NLS-1$
  }
  
  public void testEnlarged() throws Exception {
    SmartRectangle rectangle = new SmartRectangle(2, 3, 12, 13);
    SmartRectangle enlarged = rectangle.createEnlarged(3);
    assertNotSame(rectangle, enlarged);
    assertEquals("X Coordinate", -1, enlarged.x); //$NON-NLS-1$
    assertEquals("Y Coordinate", 0, enlarged.y); //$NON-NLS-1$
    assertEquals("Width", 18, enlarged.width); //$NON-NLS-1$
    assertEquals("Height", 19, enlarged.height); //$NON-NLS-1$
  }
}