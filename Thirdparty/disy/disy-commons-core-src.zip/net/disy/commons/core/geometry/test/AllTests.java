// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.03.2005
package net.disy.commons.core.geometry.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for de.disy.lib.basics.geom.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(SmartRectangleTest.class);
    suite.addTestSuite(SmartPointTest.class);
    //$JUnit-END$
    return suite;
  }
}