//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.geometry;

import java.awt.Dimension;

// NOT_PUBLISHED
public class SmartDimension extends Dimension {

  public SmartDimension() {
    super();
  }

  public SmartDimension(int width, int height) {
    super(width, height);
  }

  public SmartDimension(Dimension d) {
    super(d);
  }

  public SmartDimension resize(int widthDelta, int heightDelta) {
    return new SmartDimension(width + widthDelta, height + heightDelta);
  }

}