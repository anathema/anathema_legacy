//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.geometry;

import java.awt.Point;
import java.awt.Rectangle;

// NOT_PUBLISHED
public class SmartPoint extends Point {

  public SmartPoint(int x, int y) {
    super(x, y);
  }

  public SmartPoint(Point point) {
    super(point);
  }

  public Point getVectorTo(Point point) {
    return new Point(point.x - x, point.y - y);
  }

  public void limitTo(Rectangle limits) {
    x = Math.min(Math.max(x, limits.x), limits.x + limits.width);
    y = Math.min(Math.max(y, limits.y), limits.y + limits.height);
  }

  public void subtract(Point subtrahend) {
    x -= subtrahend.x;
    y -= subtrahend.y;
  }
}