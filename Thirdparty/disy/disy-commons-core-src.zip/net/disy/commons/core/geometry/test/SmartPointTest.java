//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.geometry.test;

import java.awt.Point;
import java.awt.Rectangle;

import net.disy.commons.core.geometry.SmartPoint;
import net.disy.commons.core.testing.CoreTestCase;

// NOT_PUBLISHED
public class SmartPointTest extends CoreTestCase {
  
  public void testSubtract() throws Exception {
    final Point subtrahend = new Point(3,5);
    final SmartPoint smartPoint = new SmartPoint(4,7);
    smartPoint.subtract(subtrahend);
    assertEquals(1.0, smartPoint.getX(), 0.0);
    assertEquals(2.0, smartPoint.getY(), 0.0);
  }
  
  public void testGetVectorTo() throws Exception {
    final SmartPoint smartPoint = new SmartPoint(1,2);
    final Point samePoint = new Point(1,2);
    assertEquals(new Point(0,0), smartPoint.getVectorTo(samePoint));
    assertEquals(new Point(3,4), smartPoint.getVectorTo(new Point(4,6)));
    assertEquals(new Point(2,-2), smartPoint.getVectorTo(new Point(3,0)));
    assertEquals(new Point(-1,-3), smartPoint.getVectorTo(new Point(0,-1)));
    assertEquals(new Point(-2,3), smartPoint.getVectorTo(new Point(-1,5)));
  }

  public void testLimitTo_pointsOnEdgeOrInsideRectangle() throws Exception {
    Rectangle rectangle = new Rectangle(1,2,3,4);
    assertNotChangedByLimit(1, 3, rectangle);
    assertNotChangedByLimit(4, 3,rectangle);
    assertNotChangedByLimit(3, 2,rectangle);
    assertNotChangedByLimit(3, 6,rectangle);
    assertNotChangedByLimit(3, 3,rectangle);
  }
  
  public void testLimitTo_pointsOutsideRectangle() throws Exception {
    Rectangle rectangle = new Rectangle(1,2,3,4);
    assertChangedProperlyByLimit(0, 3, rectangle, 1, 3);
    assertChangedProperlyByLimit(5, 3, rectangle, 4, 3);
    assertChangedProperlyByLimit(3, 1, rectangle, 3, 2);
    assertChangedProperlyByLimit(3, 7, rectangle, 3, 6);
  }

  private void assertNotChangedByLimit(int x, int y, Rectangle rectangle) {
    SmartPoint smartPoint = new SmartPoint(x,y);
    smartPoint.limitTo(rectangle);
    assertEquals(new SmartPoint(x,y), smartPoint);
  }
  
  private void assertChangedProperlyByLimit(int x, int y, Rectangle rectangle, int newX, int newY) {
    SmartPoint smartPoint = new SmartPoint(x,y);
    smartPoint.limitTo(rectangle);
    assertEquals(new SmartPoint(newX, newY), smartPoint);
  }
}
