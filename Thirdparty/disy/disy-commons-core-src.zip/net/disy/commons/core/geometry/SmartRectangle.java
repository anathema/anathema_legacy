// Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.geometry;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;

import net.disy.commons.core.util.Ensure;

public class SmartRectangle extends Rectangle {

  public SmartRectangle(Rectangle rect) {
    this(rect.x, rect.y, rect.width, rect.height);
  }

  public SmartRectangle(Point position, Dimension size) {
    this(position.x, position.y, size.width, size.height);
  }

  public SmartRectangle(int ulx, int uly, int width, int height) {
    super(ulx, uly, width, height);
    Ensure.ensureArgumentTrue("Width <0 : '" + width + "'", width >= 0); //$NON-NLS-1$ //$NON-NLS-2$
    Ensure.ensureArgumentTrue("Height <0 : '" + height + "'", height >= 0); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public int getUlx() {
    return x;
  }

  public int getUly() {
    return y;
  }

  public int getLrx() {
    return x + width;
  }

  public int getLry() {
    return y + height;
  }

  public void correctOrientation() {
    if (width < 0) {
      x = x + width;
      width = Math.abs(width);
    }
    if (height < 0) {
      y = y + height;
      height = Math.abs(height);
    }
  }

  /**
   * Move the box
   *
   * @param dx x coordinate of the moving vector
   * @param dy y coordinate of the moving vectot
   */
  public void setLocation(int dx, int dy) {
    x += dx;
    y += dy;
  }

  /**
   * Test intersection.
   *
   * @param  ulx  upper left x coordinate
   * @param  uly  upper left y coordinate
   * @param  lrx  lower right x coordinate
   * @param  lry  kower right y coordinate
   * @return true or false
   */
  public boolean intersects(int ulx, int uly, int lrx, int lry) {
    return super.intersects(new Rectangle(ulx, uly, lrx - ulx, lry - uly));
  }

  /**
   * Test intersection.
   *
   * @param  b  test box
   * @return true or false
   */
  public boolean intersects(SmartRectangle b) {
    return super.intersects(b);
  }

  /**
   * Checks if the given area is complete inside this area.
   *
   * @param r  given box
   * @return true, false
   */
  public boolean contains(Rectangle r) {
    return ((x <= r.x) && (y <= r.y) && ((x + width) >= (r.x + r.width)) && ((y + height) >= (r.y + r.height)));
  }

  /**
   * Checks if the given point is inside this area expanded
   * with a border width.
   *
   * @param  coordinateX  x coord
   * @param  coordinateY  y coord
   * @param  w  border width
   * @return true, false
   */
  public boolean contains(int coordinateX, int coordinateY, int w) {
    return (new Rectangle(this.x - w, this.y - w, this.width + (2 * w), this.height + (2 * w))).contains(coordinateX,
        coordinateY);
  }

  /**
   * Clip this box against a given display box, the two
   * boxes intersect each other. Otherwise do nothing.
   *
   * @param clip  clip box
   */
  public void clip(SmartRectangle clip) {
    if (intersects(clip)) {
      int ulx, uly, lrx, lry;

      // get edge coordinates
      //
      ulx = getUlx();
      uly = getUly();
      lrx = getLrx();
      lry = getLry();

      // clip over edges
      //
      if (clip.getUlx() > ulx) {
        ulx = clip.getUlx();
      }
      if (clip.getUly() > uly) {
        uly = clip.getUly();
      }
      if (clip.getLrx() < lrx) {
        lrx = clip.getLrx();
      }
      if (clip.getLry() < lry) {
        lry = clip.getLry();
      }

      // update cliped coordiantes
      //
      x = ulx;
      y = uly;
      width = lrx - ulx;
      height = lry - uly;
    }
  }

  public Point getCenter() {
    return new Point((getLrx() + getUlx()) / 2, (getLry() + getUly()) / 2);
  }

  public SmartRectangle minSize(int min) {
    int newWidth = Math.max(min, width);
    int newHeight = Math.max(min, height);
    int newX = x - (newWidth - width) / 2;
    int newY = y - (newHeight - height) / 2;
    return new SmartRectangle(newX, newY, newWidth, newHeight);
  }

  public SmartRectangle createEnlarged(int pixel) {
    return new SmartRectangle(x - pixel, y - pixel, width + 2 * pixel, height + 2 * pixel);
  }

  public SmartRectangle createTranslated(int xTranslation, int yTranslation) {
    return new SmartRectangle(x + xTranslation, y + yTranslation, width, height);
  }

  public SmartPoint getPosition() {
    return new SmartPoint(x, y);
  }

  public SmartRectangle createSmartUnion(SmartRectangle other) {
    Point position = new Point(Math.min(this.x, other.x), Math.min(this.y, other.y));
    int unionWidth = Math.max((int) this.getMaxX(), (int) other.getMaxX()) - position.x;
    int unionHeight = Math.max((int) this.getMaxY(), (int) other.getMaxY()) - position.y;
    return new SmartRectangle(position, new Dimension(unionWidth, unionHeight));
  }
}