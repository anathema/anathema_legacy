/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.string;

import java.util.Collection;

import net.disy.commons.core.util.Ensure;

public class StringConcatenationBuilder implements IStringConcatenationBuilder {

  public static String createConcatenatedString(String separator, Collection<String> values) {
    return createConcatenatedString(separator, values.toArray(new String[values.size()]));
  }

  public static String createConcatenatedString(String separator, String[] values) {
    final StringConcatenationBuilder builder = new StringConcatenationBuilder(separator);
    builder.append(values);
    return builder.getString();
  }

  private final String separator;
  private final StringBuffer stringBuffer = new StringBuffer();
  private boolean appended = false;

  public StringConcatenationBuilder() {
    this(""); //$NON-NLS-1$
  }

  public StringConcatenationBuilder(String separator) {
    Ensure.ensureArgumentNotNull(separator);
    this.separator = separator;
  }

  @Override
  public String getString() {
    return stringBuffer.toString();
  }

  @Override
  public String toString() {
    return getString();
  }

  public void append(int value) {
    append(String.valueOf(value));
  }

  public void append(String[] values) {
    for (String value : values) {
      append(value);
    }
  }

  @Override
  public void append(String value) {
    if (appended) {
      stringBuffer.append(separator);
    }
    else {
      appended = true;
    }
    stringBuffer.append(value);
  }
}