//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.string;

// NOT_PUBLISHED
public class StringConcatenationBuilder {

  public static String createConcatenatedString(String separator, String[] values) {
    StringConcatenationBuilder builder = new StringConcatenationBuilder(separator);
    builder.append(values);
    return builder.getString();
  }

  private final String separator;
  private StringBuffer stringBuffer;

  public StringConcatenationBuilder(String separator) {
    this.separator = separator;
  }

  public String getString() {
    return stringBuffer == null ? "" : stringBuffer.toString(); //$NON-NLS-1$
  }

  public String toString() {
    return getString();
  }

  public void append(int value) {
    append(String.valueOf(value));
  }

  public void append(String value) {
    if (stringBuffer == null) {
      stringBuffer = new StringBuffer();
    }
    else {
      stringBuffer.append(separator);
    }
    stringBuffer.append(value);
  }

  public void append(String[] values) {
    for (int i = 0; i < values.length; i++) {
      append(values[i]);
    }
  }
}