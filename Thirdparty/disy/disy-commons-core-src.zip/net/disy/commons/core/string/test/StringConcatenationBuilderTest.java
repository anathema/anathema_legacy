//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.string.test;

import junit.framework.TestCase;

import net.disy.commons.core.string.StringConcatenationBuilder;

// NOT_PUBLISHED
public class StringConcatenationBuilderTest extends TestCase {

  public void testEmpty() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    assertEquals("", builder.getString()); //$NON-NLS-1$
  }

  public void testSingleString() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append("test"); //$NON-NLS-1$
    assertEquals("test", builder.getString()); //$NON-NLS-1$
  }

  public void testMultipleStrings() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append("test"); //$NON-NLS-1$
    builder.append("42"); //$NON-NLS-1$
    builder.append("foo"); //$NON-NLS-1$
    assertEquals("test|42|foo", builder.getString()); //$NON-NLS-1$
  }

  public void testRespectsSeparator() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("_._"); //$NON-NLS-1$
    builder.append("1"); //$NON-NLS-1$
    builder.append("2"); //$NON-NLS-1$
    assertEquals("1_._2", builder.getString()); //$NON-NLS-1$
  }

  public void testAppendIntegers() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append(1);
    builder.append(2);
    assertEquals("1|2", builder.getString()); //$NON-NLS-1$
  }

  public void testAppendEmptyStringArray() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append(new String[0]); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("", builder.getString()); //$NON-NLS-1$
  }

  public void testAppendStringArray() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append(new String[]{ "1", "2" }); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("1|2", builder.getString()); //$NON-NLS-1$
  }

  public void testAppendEmptyString() {
    StringConcatenationBuilder builder = new StringConcatenationBuilder("|"); //$NON-NLS-1$
    builder.append(""); //$NON-NLS-1$
    builder.append(""); //$NON-NLS-1$
    assertEquals("|", builder.getString()); //$NON-NLS-1$
  }

  public void testCreateConcatenatedString() {
    assertEquals("1|3", StringConcatenationBuilder.createConcatenatedString("|", new String[]{ //$NON-NLS-1$
        "1", //$NON-NLS-1$
            "3" })); //$NON-NLS-1$
    assertEquals("", StringConcatenationBuilder.createConcatenatedString("|", new String[0])); //$NON-NLS-1$
  }
}