//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.string.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.core.string.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(StringConcatenationBuilderTest.class);
    //$JUnit-END$
    return suite;
  }

}
