package net.disy.commons.core.string;


/**
 * Ein Filter, der Strings filtert
 *
 * @author Romano Caserta, DISY Informationssysteme GmbH
 * @version 3.6.99
 */
public interface StringFilter {
  /**
   * �berpr�ft, ob ein String vom Filter akzeptiert wird
   *
   * @param s der zu �berpr�fende String
   * @return ob der String zum Filter pa�t
   */
  public boolean acceptFilterText( String s );
}
