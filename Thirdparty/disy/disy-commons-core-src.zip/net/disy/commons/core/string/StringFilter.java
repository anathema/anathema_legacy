/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.string;

/**
 * Ein Filter, der Strings filtert
 *
 * @author Romano Caserta, DISY Informationssysteme GmbH
 * @version 3.6.99
 */
public interface StringFilter {
  /**
   * Überprüft, ob ein String vom Filter akzeptiert wird
   *
   * @param s der zu überprüfende String
   * @return ob der String zum Filter paßt
   */
  public boolean acceptFilterText(String s);
}
