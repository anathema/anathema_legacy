/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.string;

import java.text.DecimalFormat;
import java.text.ParseException;

import net.disy.commons.core.number.DecimalFormatBuilder;
import net.disy.commons.core.object.ConversionException;
import net.disy.commons.core.object.IObjectToObjectConverter;

public final class StringToIntegerConverter implements IObjectToObjectConverter<String, Integer> {
  final private DecimalFormat format;

  public StringToIntegerConverter(char decimalSeparator, char groupingSeparator) {
    this.format = new DecimalFormatBuilder()
        .setDecimalSeparator(decimalSeparator)
        .setGroupingSeparator(groupingSeparator)
        .build();
  }

  @Override
  public Integer convert(String string) throws ConversionException {
    try {
      if (string == null) {
        return null;
      }
      return format.parse(string).intValue();
    }
    catch (ParseException exception) {
      throw new ConversionException(exception.getLocalizedMessage(), exception);
    }
  }
}
