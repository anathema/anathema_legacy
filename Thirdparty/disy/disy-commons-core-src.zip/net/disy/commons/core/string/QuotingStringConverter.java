//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.string;


// NOT_PUBLISHED
public class QuotingStringConverter implements IStringConverter {
  public String convert(String text) {
    return '"' + text + '"';
  }
}