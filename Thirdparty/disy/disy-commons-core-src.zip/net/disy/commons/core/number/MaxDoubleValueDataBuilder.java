/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number;

import net.disy.commons.core.util.Ensure;

public class MaxDoubleValueDataBuilder<T> {
  private final IDoubleValueGetter<T> valueGetter;
  private T maxData;

  public MaxDoubleValueDataBuilder(final IDoubleValueGetter<T> valueGetter) {
    Ensure.ensureArgumentNotNull(valueGetter);
    this.valueGetter = valueGetter;
  }

  public T getMaxData() {
    return maxData;
  }

  public double getMaxValue() {
    return maxData == null ? Double.NaN : valueGetter.getValue(maxData);
  }

  public void addData(final T data) {
    if (this.maxData == null || valueGetter.getValue(data) > valueGetter.getValue(maxData)) {
      this.maxData = data;
    }
  }
}
