/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number.test;

import junit.framework.TestCase;

import net.disy.commons.core.number.MinMaxDoubleValueBuilder;

public class MinMaxDoubleValueBuildertest extends TestCase {

  public void testEmptyBuilder() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    assertTrue(Double.isNaN(builder.getMinimum(Double.NaN)));
    assertTrue(Double.isNaN(builder.getMaximum(Double.NaN)));
  }

  public void testEmptyBuilderRespectsFallBacks() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    assertEquals(42.2, builder.getMinimum(42.2), 0.0);
    assertEquals(11.1, builder.getMaximum(11.1), 0.0);
  }

  public void testBuilderRespectsAddedValue() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    builder.add(13.4);
    assertEquals(13.4, builder.getMinimum(Double.NaN), 0.0);
    assertEquals(13.4, builder.getMaximum(Double.NaN), 0.0);
  }

  public void testBuilderWithAddedValueIgnoresFallBackValue() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    builder.add(13.4);
    assertEquals(13.4, builder.getMinimum(0.0), 0.0);
    assertEquals(13.4, builder.getMinimum(20.0), 0.0);
    assertEquals(13.4, builder.getMaximum(0.0), 0.0);
    assertEquals(13.4, builder.getMaximum(20.0), 0.0);
  }

  public void testBuilderRespectsMultipleAddedValues() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    builder.add(12.1);
    builder.add(10.3);
    builder.add(62.8);
    assertEquals(10.3, builder.getMinimum(Double.NaN), 0.0);
    assertEquals(62.8, builder.getMaximum(Double.NaN), 0.0);
  }

  public void testBuilderIgnoresNaNValues() {
    final MinMaxDoubleValueBuilder builder = new MinMaxDoubleValueBuilder();
    builder.add(12.1);
    builder.add(10.3);
    builder.add(62.8);
    builder.add(Double.NaN);
    assertEquals(10.3, builder.getMinimum(Double.NaN), 0.0);
    assertEquals(62.8, builder.getMaximum(Double.NaN), 0.0);
  }
}