/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number;

public class MinMaxDoubleValueBuilder implements IDoubleValueAddable {

  private double minValue = Double.NaN;
  private double maxValue = Double.NaN;

  public double getMaximum(final double fallBackValue) {
    if (Double.isNaN(maxValue)) {
      return fallBackValue;
    }
    return maxValue;
  }

  public double getMinimum(final double fallBackValue) {
    if (Double.isNaN(minValue)) {
      return fallBackValue;
    }
    return minValue;
  }

  @Override
  public void add(final double value) {
    minValue = value < minValue || Double.isNaN(minValue) ? value : minValue;
    maxValue = value > maxValue || Double.isNaN(maxValue) ? value : maxValue;
  }
}