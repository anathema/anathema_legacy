//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.number;

// NOT_PUBLISHED
public class MinMaxDoubleValueBuilder implements IDoubleValueAddable {

  private double minValue = Double.NaN;
  private double maxValue = Double.NaN;

  public double getMaximum(double fallBackValue) {
    if (Double.isNaN(maxValue)) {
      return fallBackValue;
    }
    return maxValue;
  }

  public double getMinimum(double fallBackValue) {
    if (Double.isNaN(minValue)) {
      return fallBackValue;
    }
    return minValue;
  }

  public void add(double value) {
    minValue = value < minValue || Double.isNaN(minValue) ? value : minValue;
    maxValue = value > maxValue || Double.isNaN(maxValue) ? value : maxValue;
  }
}