/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number.test;

import net.disy.commons.core.number.MaxLongValueBuilder;
import net.disy.commons.core.testing.CoreTestCase;

public class MaxLongValueBuilderTest extends CoreTestCase {

  public void testCreateWithInitialValue() {
    final MaxLongValueBuilder builder = new MaxLongValueBuilder(0);
    assertEquals(0, builder.getMaximum());

    final MaxLongValueBuilder builder2 = new MaxLongValueBuilder(3);
    assertEquals(3, builder2.getMaximum());
  }

  public void testBuildMaximum() {
    final MaxLongValueBuilder builder = new MaxLongValueBuilder(0);
    builder.add(10);
    builder.add(12);
    builder.add(4);
    assertEquals(12, builder.getMaximum());
  }

  public void testBuildMaximumWithDefault() {
    final MaxLongValueBuilder builder = new MaxLongValueBuilder(30);
    builder.add(10);
    builder.add(12);
    builder.add(4);
    assertEquals(30, builder.getMaximum());
  }
}