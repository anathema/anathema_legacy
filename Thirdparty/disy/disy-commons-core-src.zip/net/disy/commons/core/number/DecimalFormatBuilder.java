/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;

public class DecimalFormatBuilder {

  final private static DecimalFormatSymbols defaultSymbols = new DecimalFormatSymbols();
  private char groupingSeparator = defaultSymbols.getGroupingSeparator();
  private char decimalSeparator = defaultSymbols.getDecimalSeparator();

  public DecimalFormatBuilder setDecimalSeparator(char decimalSeparator) {
    this.decimalSeparator = decimalSeparator;
    return this;
  }

  public DecimalFormatBuilder setGroupingSeparator(char groupingSeparator) {
    this.groupingSeparator = groupingSeparator;
    return this;
  }

  public DecimalFormat build() {
    final DecimalFormat format = new DecimalFormat();
    final DecimalFormatSymbols symbols = new DecimalFormatSymbols();
    symbols.setGroupingSeparator(groupingSeparator);
    symbols.setDecimalSeparator(decimalSeparator);
    return format;
  }

}
