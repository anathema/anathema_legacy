//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.number;

// NOT_PUBLISHED
public class MaxIntegerValueBuilder {

  private int maxValue;

  public MaxIntegerValueBuilder(int startValue) {
    this.maxValue = startValue;
  }

  public int getMaximum() {
    return maxValue;
  }

  public void add(int value) {
    maxValue = value > maxValue ? value : maxValue;
  }
}