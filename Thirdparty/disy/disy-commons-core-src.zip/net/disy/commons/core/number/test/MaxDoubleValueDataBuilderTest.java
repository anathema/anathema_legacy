/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import net.disy.commons.core.number.IDoubleValueGetter;
import net.disy.commons.core.number.MaxDoubleValueDataBuilder;

import org.junit.Before;
import org.junit.Test;

public class MaxDoubleValueDataBuilderTest {
  private MaxDoubleValueDataBuilder<Integer> builder;

  @Before
  public void setup() {
    builder = new MaxDoubleValueDataBuilder<Integer>(new IDoubleValueGetter<Integer>() {
      @Override
      public double getValue(final Integer data) {
        return new Double(data);
      }
    });
  }

  @Test
  public void empty() {
    assertEquals(null, builder.getMaxData());
    assertThat(builder.getMaxValue(), is(Double.NaN));
  }

  @Test
  public void singleData() {
    builder.addData(new Integer(5));
    assertEquals(new Integer(5), builder.getMaxData());
    assertThat(builder.getMaxValue(), is(5d));
  }

  @Test
  public void multipleData() {
    builder.addData(new Integer(7));
    builder.addData(new Integer(5));
    assertEquals(new Integer(7), builder.getMaxData());
    assertThat(builder.getMaxValue(), is(7d));
  }
}
