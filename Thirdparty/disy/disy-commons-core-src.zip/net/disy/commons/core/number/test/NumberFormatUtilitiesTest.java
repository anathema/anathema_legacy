// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 16.12.2005
package net.disy.commons.core.number.test;

import net.disy.commons.core.number.NumberFormatUtilities;
import net.disy.commons.core.testing.CoreTestCase;

// NOT_PUBLISHED
public class NumberFormatUtilitiesTest extends CoreTestCase {

  public void testIsLegalDecimalFormatPattern() throws Exception {
    assertTrue(NumberFormatUtilities.isLegalDecimalFormatPattern("0.0")); //$NON-NLS-1$
    assertTrue(NumberFormatUtilities.isLegalDecimalFormatPattern("")); //$NON-NLS-1$
    assertFalse(NumberFormatUtilities.isLegalDecimalFormatPattern("0.0.0")); //$NON-NLS-1$
  }
}