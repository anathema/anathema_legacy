//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.number.test;

import net.disy.commons.core.number.MaxIntegerValueBuilder;
import net.disy.commons.core.testing.CoreTestCase;

// NOT_PUBLISHED
public class MaxIntegerValueBuilderTest extends CoreTestCase {

  public void testCreateWithInitialValue() {
    MaxIntegerValueBuilder builder = new MaxIntegerValueBuilder(0);
    assertEquals(0, builder.getMaximum());

    MaxIntegerValueBuilder builder2 = new MaxIntegerValueBuilder(3);
    assertEquals(3, builder2.getMaximum());
  }

  public void testBuildMaximum() {
    MaxIntegerValueBuilder builder = new MaxIntegerValueBuilder(0);
    builder.add(10);
    builder.add(12);
    builder.add(4);
    assertEquals(12, builder.getMaximum());
  }

  public void testBuildMaximumWithDefault() {
    MaxIntegerValueBuilder builder = new MaxIntegerValueBuilder(30);
    builder.add(10);
    builder.add(12);
    builder.add(4);
    assertEquals(30, builder.getMaximum());
  }
}