/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import net.disy.commons.core.number.MinMaxIntValueBuilder;

import org.junit.Before;
import org.junit.Test;

public class MinMaxIntValueBuilder_EmptyTest {

  private MinMaxIntValueBuilder builder;

  @Before
  public void createEmptyBuilder() throws Exception {
    builder = new MinMaxIntValueBuilder();
  }

  @Test(expected = IllegalStateException.class)
  public void throwsExceptionOnGetMaximum() throws Exception {
    builder.getMaximum();
  }

  @Test(expected = IllegalStateException.class)
  public void throwsExceptionOnGetMinimum() throws Exception {
    builder.getMinimum();
  }

  @Test
  public void doesNotHaveValues() throws Exception {
    assertThat(builder.hasValues(), is(false));
  }

  @Test
  public void returnsFallbackValueOnGetMinimumWithFallback() throws Exception {
    assertThat(builder.getMinimum(2), is(2));
  }

  @Test
  public void returnsFallbackValueOnGetMaximumWithFallback() throws Exception {
    assertThat(builder.getMaximum(3), is(3));
  }
}