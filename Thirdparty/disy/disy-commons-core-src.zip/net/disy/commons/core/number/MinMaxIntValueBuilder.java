/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number;

public class MinMaxIntValueBuilder {

  private double minValue = Double.NaN;
  private double maxValue = Double.NaN;

  public int getMaximum() {
    if (!hasValues()) {
      throw new IllegalStateException("No max value defined."); //$NON-NLS-1$
    }
    return (int) maxValue;
  }

  public int getMaximum(final int fallBackValue) {
    if (!hasValues()) {
      return fallBackValue;
    }
    return (int) maxValue;
  }

  public int getMinimum() {
    if (!hasValues()) {
      throw new IllegalStateException("No min value defined."); //$NON-NLS-1$
    }
    return (int) minValue;
  }

  public int getMinimum(final int fallBackValue) {
    if (!hasValues()) {
      return fallBackValue;
    }
    return (int) minValue;
  }

  public boolean hasValues() {
    return !Double.isNaN(maxValue);
  }

  public void add(final int value) {
    minValue = value < minValue || Double.isNaN(minValue) ? value : minValue;
    maxValue = value > maxValue || Double.isNaN(maxValue) ? value : maxValue;
  }
}