// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 16.12.2005
package net.disy.commons.core.number;

import java.text.DecimalFormat;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

// NOT_PUBLISHED
public class NumberFormatUtilities {
  
  private NumberFormatUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static boolean isLegalDecimalFormatPattern(String pattern) {
    try {
      new DecimalFormat(pattern);
      return true;
    }
    catch (Exception exception) {
      return false;
    }
  }
}