/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.number;

public class AverageBuilder {

  private double average = 0.0;
  private int valueCount = 0;

  public void add(final Number number) {
    if (number == null) {
      return;
    }
    add(number.doubleValue());
  }

  public void add(final double value) {
    ++valueCount;
    average = (average * (valueCount - 1) + value) / valueCount;
  }

  public Number getAsNumber() {
    return valueCount == 0 ? null : new Double(average);
  }

  public double getAsDouble() {
    return average;
  }
}