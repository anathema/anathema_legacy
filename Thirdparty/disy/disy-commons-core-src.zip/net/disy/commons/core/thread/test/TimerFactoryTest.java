/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.thread.test;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.exception.NullExceptionHandler;
import net.disy.commons.core.provider.StaticProvider;
import net.disy.commons.core.testing.ConcurrentTestCase;
import net.disy.commons.core.thread.ITimer;
import net.disy.commons.core.thread.ITimerTask;
import net.disy.commons.core.thread.TimerFactory;

public class TimerFactoryTest extends ConcurrentTestCase {

  public void testRunsTasks() {
    final ITimer timer = TimerFactory.createTimer("test"); //$NON-NLS-1$
    timer.schedule(new ITimerTask() {
      @Override
      public void run() {
        checkpoint("task1"); //$NON-NLS-1$
      }
    }, 0);
    waitForCheckpoint("task1"); //$NON-NLS-1$
    timer.schedule(new ITimerTask() {
      @Override
      public void run() {
        checkpoint("task2"); //$NON-NLS-1$
      }
    }, 0);
    waitForCheckpoint("task2"); //$NON-NLS-1$
  }

  public void testForwardsExceptionsToExceptionHandler() {
    final RuntimeException exception = new RuntimeException();
    final List<Throwable> caughtThrowables = new ArrayList<Throwable>();
    final IExceptionHandler exceptionHandler = new IExceptionHandler() {
      @Override
      public void handle(Throwable throwable) {
        caughtThrowables.add(throwable);
        checkpoint("throwable caught"); //$NON-NLS-1$
      }
    };
    final ITimer timer = TimerFactory.createTimer("test", new StaticProvider<IExceptionHandler>( //$NON-NLS-1$
        exceptionHandler));
    timer.schedule(new ITimerTask() {
      @Override
      public void run() {
        throw exception;
      }
    }, 0);
    waitForCheckpoint("throwable caught"); //$NON-NLS-1$
    assertEquals(1, caughtThrowables.size());
    assertSame(exception, caughtThrowables.get(0));
  }

  public void testRunsTasksAfterThrowableCaught() {
    final ITimer timer = TimerFactory.createTimer(
        "test", new StaticProvider<IExceptionHandler>(new NullExceptionHandler())); //$NON-NLS-1$
    timer.schedule(new ITimerTask() {
      @Override
      public void run() {
        throw new RuntimeException();
      }
    }, 0);
    timer.schedule(new ITimerTask() {
      @Override
      public void run() {
        checkpoint("task"); //$NON-NLS-1$
      }
    }, 0);
    waitForCheckpoint("task"); //$NON-NLS-1$
  }
}