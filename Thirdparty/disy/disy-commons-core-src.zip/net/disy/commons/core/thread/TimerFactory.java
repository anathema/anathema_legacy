/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.thread;

import java.util.Timer;
import java.util.TimerTask;

import net.disy.commons.core.exception.CentralExceptionHandling;
import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.provider.IProvider;
import net.disy.commons.core.util.Ensure;

public class TimerFactory {

  public static ITimer createTimer(final String threadName) {
    final IProvider<IExceptionHandler> exceptionHandlerProvider = new IProvider<IExceptionHandler>() {
      @Override
      public IExceptionHandler getObject() {
        return CentralExceptionHandling.getInstance().getHandler();
      }
    };
    return createTimer(threadName, exceptionHandlerProvider);
  }

  public static ITimer createTimer(
      final String threadName,
      final IProvider<IExceptionHandler> exceptionHandlerProvider) {
    Ensure.ensureArgumentNotNull(threadName);
    Ensure.ensureArgumentNotNull(exceptionHandlerProvider);
    final Timer timer = new Timer(threadName, true);
    return new ITimer() {
      @Override
      public void schedule(final ITimerTask timerTask, final long delay) {
        Ensure.ensureArgumentNotNull(timerTask);
        final TimerTask sunTask = new TimerTask() {
          @Override
          public void run() {
            try {
              timerTask.run();
            }
            catch (Throwable t) {
              final IExceptionHandler exceptionHandler = exceptionHandlerProvider.getObject();
              exceptionHandler.handle(t);
            }
          }
        };
        timer.schedule(sunTask, delay);
      }

      @Override
      public void cancel() {
        timer.cancel();
      }
    };
  }
}