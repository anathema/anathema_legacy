//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.thread;

import java.util.Timer;
import java.util.TimerTask;

// NOT_PUBLISHED
public class TimerFactory {

  public static Timer createTimer(boolean isDaemon, final String threadName) {
    Timer timer = new Timer(isDaemon);
    //Naming a timer thread works from JDK1.5 on, until then we use this workaround:
    timer.schedule(new TimerTask() {
      @Override
      public void run() {
        Thread.currentThread().setName(threadName);
      }
    }, 0);
    return timer;
  }
}