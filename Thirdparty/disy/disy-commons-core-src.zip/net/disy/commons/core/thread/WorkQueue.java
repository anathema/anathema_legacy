/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.thread;

import java.util.LinkedList;
import java.util.concurrent.Executors;

import net.disy.commons.core.logging.ILogger;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;

/**
 * http://www-106.ibm.com/developerworks/java/library/j-jtp0730.html
 * @deprecated as of 20.07.2011 (beck), use {@link Executors} instead
 */
@Deprecated
public class WorkQueue implements IWorkQueue {

  private final ILogger logger;
  private static final String SHUTDOWN_MESSAGE = "Shutting down, will not accept any more work."; //$NON-NLS-1$

  private final LinkedList<Runnable> queue;
  private final String queueName;
  private final int priority;
  private final boolean asDaemon;
  private final int threadCount;

  private ThreadGroup threadGroup;
  private boolean acceptingWork = true;
  private int activeWorkersCount;

  private final Condition workQueueFinished;
  private final BooleanModel busyModel = new BooleanModel();
  private final ListenerList<IWorkQueueListener> listeners = new ListenerList<IWorkQueueListener>();

  //private int queueSizeWarnThreshold = -1;

  public WorkQueue(final ILogger logger, final String queueName, final int threadCount) {
    this(logger, queueName, threadCount, false);
  }

  public WorkQueue(
      final ILogger logger,
      final String queueName,
      final int threadCount,
      final boolean asDaemon) {
    this(logger, queueName, threadCount, asDaemon, Thread.NORM_PRIORITY, false);
  }

  public WorkQueue(
      final ILogger logger,
      final String queueName,
      final int threadCount,
      final boolean asDaemon,
      final int priority,
      final boolean startLater) {
    Ensure.ensureArgumentNotNull(logger);
    workQueueFinished = new Condition(logger, false);
    this.logger = logger;
    this.queueName = queueName;
    this.threadCount = threadCount;
    this.asDaemon = asDaemon;
    this.priority = priority;
    queue = new LinkedList<Runnable>();
    if (startLater) {
      return;
    }
    start();
  }

  public void start() {
    Ensure.ensureNull("Working queue " + queueName + " already started.", threadGroup); //$NON-NLS-1$ //$NON-NLS-2$
    threadGroup = new ThreadGroup(queueName);
    threadGroup.setDaemon(asDaemon);
    logger.info("WorkQueue launching : " + queueName + " \tThreadCount: " + threadCount); //$NON-NLS-1$ //$NON-NLS-2$
    for (int i = 0; i < threadCount; i++) {
      final PoolWorker poolWorker = new PoolWorker(threadGroup, queueName + "-T-" + i); //$NON-NLS-1$
      poolWorker.setPriority(priority);
      poolWorker.start();
    }
  }

  /**
   * Reiht ein Runnable in eine Warteschlange ein und bringt diesen durch einen der PoolWorker
   * asynchron zur Ausfuehrung, sobald dieser am Anfang der Warteschlange steht. Die Methode kehrt
   * sofort zurueck.
   *
   * @param r Runnable, der ausgefuehrt asynchron werden soll
   * @throws IllegalStateException, wenn mittels stopAcceptingWork() die WorkQueue abgebaut werden
   *             sollte
   */
  @Override
  public void execute(final Runnable r) throws IllegalStateException {
    if (acceptingWork) {
      synchronized (queue) {
        queue.addLast(r);
        final int queueSize = queue.size();
        if (logger.isDebugEnabled()) {
          logger.debug(queueName + ": enqueued Runnable[" //$NON-NLS-1$
              + r.toString()
              + "]. Current size of queue: " //$NON-NLS-1$
              + queueSize);
        }
        //        if(queueSize == queueSizeWarnThreshold) {
        //          logger.warn(queueName + ": Size of queue for workqueue exceeds threshold: " + queueSize); //$NON-NLS-1$
        //        }
        queue.notify();
      }
      fireWaitingJobsCountChangedEvent();
    }
    else {
      throw new IllegalStateException(SHUTDOWN_MESSAGE);
    }
  }

  /**
   * Vehindert, dass weitere Runnable in die Queue eingereicht werden koennen. Die Queue wird aber
   * erst abgearbeitet, bevor die Threads abgebaut werden
   */
  public final void stopAcceptingWork() {
    acceptingWork = false;
    logger.info(SHUTDOWN_MESSAGE);
    synchronized (queue) {
      // Alle wartenden Threads benachrichtigen
      // Falls Queue empty: -> alle beenden sich
      // Ansonsten:
      // a) Ein Thread bekommt zu tun, wird fertig, schaut nach ob empty
      // a1) empty -> beenden
      // a2) sonst
      queue.notifyAll();
    }
  }

  public void waitForWorkQueueFinished(final long timeout) throws InterruptedException {
    workQueueFinished.waitForTrue(timeout);
  }

  private synchronized void workStarted() {
    activeWorkersCount++;
    updateBusyModel();
    fireWaitingJobsCountChangedEvent();
  }

  private void fireWaitingJobsCountChangedEvent() {
    synchronized (queue) {
      listeners.forAllDo(new IClosure<IWorkQueueListener>() {
        @Override
        public void execute(final IWorkQueueListener listener) {
          listener.waitingJobsCountChanged(queue.size());
        }
      });
    }
  }

  private synchronized void workStopped() {
    activeWorkersCount--;
    //logger.info("activeWorkers: " + activeWorkersCount); //$NON-NLS-1$
    updateBusyModel();
    checkWorkQueueFinished();
  }

  private synchronized void checkWorkQueueFinished() {
    if (acceptingWork == false) {
      if (activeWorkersCount == 0 && queue.isEmpty()) {
        workQueueFinished.setTrue();
      }
    }
  }

  //  public void setQueueSizeWarnThreshold(int queueSizeWarnThreshold) {
  //    logger.debug(queueName + ": Set queueSizeWarnThreshold to: " + queueSizeWarnThreshold); //$NON-NLS-1$
  //    this.queueSizeWarnThreshold = queueSizeWarnThreshold;
  //  }

  private class PoolWorker extends Thread {

    private PoolWorker(final ThreadGroup threadGroup, final String threadName) {
      super(threadGroup, threadName);
      // sven[2005-02-28] neuer Thread erbt NICHT den Daemon-Status seiner Gruppe
      // sondern den des Erzeugenden Threads!
      final boolean asDeamon = threadGroup.isDaemon();
      setDaemon(asDeamon);
    }

    @Override
    public void run() {
      Runnable r;

      while (true) {
        synchronized (queue) {
          while (queue.isEmpty()) {
            try {
              if (acceptingWork) {
                // Ein PoolWorker wird nur warten, wenn es gerade nichts zu tun gibt
                //und das auch nicht wieder passieren kann
                queue.wait();
              }
              else {
                logger.debug(getName() + ": Ending PoolWorker"); //$NON-NLS-1$
                checkWorkQueueFinished();
                return;
              }
            }
            catch (final InterruptedException ignored) {
              //nothing to do
            }
          }

          r = queue.removeFirst();
          final int queueSize = queue.size();
          if (logger.isDebugEnabled()) {
            logger.debug(getName()
                + ": dequeued Runnable[" + r.toString() + "]. Current size of queue: " + queueSize); //$NON-NLS-1$ //$NON-NLS-2$
          }
        }

        // If we don't catch RuntimeException,
        // the pool could leak threads
        try {
          workStarted();
          r.run();
        }
        catch (final Throwable e) {
          logger.error(e);
        }
        finally {
          workStopped();
        }
      }
    }
  }

  private synchronized void updateBusyModel() {
    busyModel.setValue(activeWorkersCount > 0);
    listeners.forAllDo(new IClosure<IWorkQueueListener>() {
      @Override
      public void execute(final IWorkQueueListener listener) {
        listener.activeWorkersCountChanged(activeWorkersCount);
      }
    });
  }

  public BooleanModel getBusyModel() {
    return busyModel;
  }

  public void addListener(final IWorkQueueListener listener) {
    listeners.add(listener);
  }

  public void removeListener(final IWorkQueueListener listener) {
    listeners.remove(listener);
  }
}