package net.disy.commons.core.thread;

import java.util.LinkedList;

import net.disy.commons.core.exception.CentralExceptionHandling;
import net.disy.commons.core.logging.ILogger;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;

/**
 * http://www-106.ibm.com/developerworks/java/library/j-jtp0730.html
 */
public class WorkQueue implements IWorkQueue {

  //TODO NOW (behrens) 24.06.2005: loggen scheint mit disy-Logging nicht zu gehen!
  private final ILogger logger;
  private static final String shutdownMessage = "Shutting down, will not accept any more work."; //$NON-NLS-1$

  private final LinkedList<Runnable> queue;
  private final String queueName;
  private final int priority;
  private final boolean asDaemon;
  private final int threadCount;

  private ThreadGroup threadGroup;
  private boolean acceptingWork = true;
  private int activeWorkersCount;

  private final Condition workQueueFinished;
  private final BooleanModel busyModel = new BooleanModel();

  //private int queueSizeWarnThreshold = -1;

  public WorkQueue(ILogger logger, String queueName, int threadCount) {
    this(logger, queueName, threadCount, false);
  }

  public WorkQueue(ILogger logger, String queueName, int threadCount, boolean asDaemon) {
    this(logger, queueName, threadCount, asDaemon, Thread.NORM_PRIORITY, false);
  }

  public WorkQueue(
      ILogger logger,
      String queueName,
      int threadCount,
      boolean asDaemon,
      int priority,
      boolean startLater) {
    Ensure.ensureArgumentNotNull(logger);
    workQueueFinished = new Condition(logger, false);
    this.logger = logger;
    this.queueName = queueName;
    this.threadCount = threadCount;
    this.asDaemon = asDaemon;
    this.priority = priority;
    queue = new LinkedList<Runnable>();
    if (startLater) {
      return;
    }
    start();
  }

  public void start() {
    Ensure.ensureNull("Working queue " + queueName + " already started.", threadGroup); //$NON-NLS-1$ //$NON-NLS-2$
    threadGroup = CentralExceptionHandling.createThreadGroup(this.queueName);
    threadGroup.setDaemon(this.asDaemon);
    logger.info("WorkQueue launching : " + this.queueName + " \tThreadCount: " + threadCount); //$NON-NLS-1$ //$NON-NLS-2$
    for (int i = 0; i < this.threadCount; i++) {
      PoolWorker poolWorker = new PoolWorker(threadGroup, this.queueName + "-T-" + i); //$NON-NLS-1$
      poolWorker.setPriority(this.priority);
      poolWorker.start();
    }
  }

  /**
   * Reiht ein Runnable in eine Warteschlange ein und 
   * bringt diesen durch einen der PoolWorker asynchron zur Ausfuehrung, 
   * sobald dieser am Anfang der Warteschlange steht.
   * Die Methode kehrt sofort zurueck.
   * 
   * @param r Runnable, der ausgefuehrt asynchron werden soll
   * @throws IllegalStateException, wenn mittels stopAcceptingWork() die WorkQueue abgebaut werden sollte
   */
  public void execute(Runnable r) throws IllegalStateException {
    if (acceptingWork) {
      synchronized (queue) {
        queue.addLast(r);
        int queueSize = queue.size();
        if (logger.isDebugEnabled()) {
          logger.debug(queueName + ": enqueued Runnable[" //$NON-NLS-1$
              + r.getClass().getName()
              + "]. Current size of queue: " //$NON-NLS-1$
              + queueSize);
        }
        //        if(queueSize == queueSizeWarnThreshold) {
        //          logger.warn(queueName + ": Size of queue for workqueue exceeds threshold: " + queueSize); //$NON-NLS-1$
        //        }
        queue.notify();
      }
    }
    else {
      throw new IllegalStateException(shutdownMessage);
    }
  }

  /** 
   * Vehindert, dass weitere Runnable in die Queue eingereicht werden koennen. 
   * Die Queue wird aber erst abgearbeitet, bevor die Threads abgebaut werden
   */
  public final void stopAcceptingWork() {
    acceptingWork = false;
    logger.info(shutdownMessage);
    synchronized (queue) {
      // Alle wartenden Threads benachrichtigen
      // Falls Queue empty: -> alle beenden sich
      // Ansonsten:
      // a) Ein Thread bekommt zu tun, wird fertig, schaut nach ob empty
      // a1) empty -> beenden
      // a2) sonst
      queue.notifyAll();
    }
  }

  public void waitForWorkQueueFinished(long timeout) throws InterruptedException {
    workQueueFinished.waitForTrue(timeout);
  }

  private synchronized void workStarted() {
    activeWorkersCount++;
    updateBusyModel();
    //logger.info("activeWorkers: " + activeWorkersCount); //$NON-NLS-1$
  }

  private synchronized void workStopped() {
    activeWorkersCount--;
    //logger.info("activeWorkers: " + activeWorkersCount); //$NON-NLS-1$
    updateBusyModel();
    checkWorkQueueFinished();
  }

  private synchronized void checkWorkQueueFinished() {
    if (acceptingWork == false) {
      if (activeWorkersCount == 0 && queue.isEmpty()) {
        workQueueFinished.setTrue();
      }
    }
  }

  //  public void setQueueSizeWarnThreshold(int queueSizeWarnThreshold) {
  //    logger.debug(queueName + ": Set queueSizeWarnThreshold to: " + queueSizeWarnThreshold); //$NON-NLS-1$
  //    this.queueSizeWarnThreshold = queueSizeWarnThreshold;
  //  }

  private class PoolWorker extends Thread {

    private PoolWorker(ThreadGroup threadGroup, String threadName) {
      super(threadGroup, threadName);
      // sven[2005-02-28] neuer Thread erbt NICHT den Daemon-Status seiner Gruppe
      // sondern den des Erzeugenden Threads!
      boolean asDeamon = threadGroup.isDaemon();
      setDaemon(asDeamon);
    }

    @Override
    public void run() {
      Runnable r;

      while (true) {
        synchronized (queue) {
          while (queue.isEmpty()) {
            try {
              if (acceptingWork) {
                // Ein PoolWorker wird nur warten, wenn es gerade nichts zu tun gibt 
                //und das auch nicht wieder passieren kann
                queue.wait();
              }
              else {
                logger.debug(getName() + ": Ending PoolWorker"); //$NON-NLS-1$
                checkWorkQueueFinished();
                return;
              }
            }
            catch (InterruptedException ignored) {
              //nothing to do
            }
          }

          r = queue.removeFirst();
          int queueSize = queue.size();
          if (logger.isDebugEnabled()) {
            logger
                .debug(getName()
                    + ": dequeued Runnable[" + r.getClass().getName() + "]. Current size of queue: " + queueSize); //$NON-NLS-1$ //$NON-NLS-2$
          }
        }

        // If we don't catch RuntimeException, 
        // the pool could leak threads
        try {
          workStarted();
          r.run();
        }
        catch (Throwable e) {
          logger.error(e.getMessage(), e);
        }
        finally {
          workStopped();
        }
      }
    }
  }

  private void updateBusyModel() {
    busyModel.setValue(activeWorkersCount > 0);
  }

  public BooleanModel getBusyModel() {
    return busyModel;
  }
}