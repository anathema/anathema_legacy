//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.thread;

// NOT_PUBLISHED
public interface IWorkQueue {

  /**
   * Reiht ein Runnable in eine Warteschlange ein und 
   * bringt diesen durch einen der PoolWorker asynchron zur Ausfuehrung, 
   * sobald dieser am Anfang der Warteschlange steht.
   * Die Methode kehrt sofort zurueck.
   * 
   * @param r Runnable, der ausgefuehrt asynchron werden soll
   * @throws IllegalStateException, wenn mittels stopAcceptingWork() die WorkQueue abgebaut werden sollte
   */
  void execute(Runnable r) throws IllegalStateException;

}