/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.thread;

public interface IWorkQueue {

  /**
   * Reiht ein Runnable in eine Warteschlange ein und 
   * bringt diesen durch einen der PoolWorker asynchron zur Ausfuehrung, 
   * sobald dieser am Anfang der Warteschlange steht.
   * Die Methode kehrt sofort zurueck.
   * 
   * @param r Runnable, der ausgefuehrt asynchron werden soll
   * @throws IllegalStateException, wenn mittels stopAcceptingWork() die WorkQueue abgebaut werden sollte
   */
  void execute(Runnable r) throws IllegalStateException;

}