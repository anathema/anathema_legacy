package net.disy.commons.core.thread;

import net.disy.commons.core.logging.ILogger;
import net.disy.commons.core.util.Ensure;

/**
 * Condition is able to wait for a condition to become true.
 * <p>
 * <p>
 * Created: Thu Aug 19 12:59:57 1999
 * <p>
 * @author Marcus Briesen
 * <p>
 * <p>
 */
public class Condition {
  //TODO 15.06.2005 (behrens): replace by Java 5 util.concurrent
  private final ILogger logger;

  private boolean isTrue;

  public Condition(ILogger logger, boolean b) {
    Ensure.ensureArgumentNotNull(logger);
    this.logger = logger;
    isTrue = b;
  }

  public synchronized boolean isTrue() {
    return isTrue;
  }

  public synchronized void setFalse() {
    logger.debug("setting condition to false");
    isTrue = false;
  }

  public synchronized void setTrue() {
    logger.debug("setting condition to true");
    isTrue = true;
    notifyAll();
  }

  public synchronized void releaseAll() {
    notifyAll();
    logger.debug("released all");
  }

  public synchronized void releaseOne() {
    notify();
    logger.debug("released one");
  }

  public synchronized void waitForTrue(long timeout) throws InterruptedException {
    if (!isTrue) {
      logger.debug("waiting to become true");
      wait(timeout);
    }
    if (isTrue) {
      logger.debug("now true");
    }
    else {
      logger.warn("timed out, condition is still false!");
    }
  }

  public synchronized void waitForTrue() throws InterruptedException {
    waitForTrue(0);
  }
} // Condition
