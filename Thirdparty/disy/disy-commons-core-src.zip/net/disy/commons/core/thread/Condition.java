/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.thread;

import net.disy.commons.core.logging.ILogger;
import net.disy.commons.core.util.Ensure;

/**
 * Condition is able to wait for a condition to become true.
 */
public class Condition {
  private final ILogger logger;
  private boolean value;

  public Condition(final ILogger logger, final boolean value) {
    Ensure.ensureArgumentNotNull(logger);
    this.logger = logger;
    this.value = value;
  }

  public synchronized boolean isTrue() {
    return value;
  }

  public synchronized void setFalse() {
    logger.debug("setting condition to false"); //$NON-NLS-1$
    value = false;
  }

  public synchronized void setTrue() {
    logger.debug("setting condition to true"); //$NON-NLS-1$
    value = true;
    notifyAll();
  }

  public synchronized void releaseAll() {
    notifyAll();
    logger.debug("released all"); //$NON-NLS-1$
  }

  public synchronized void releaseOne() {
    notify();
    logger.debug("released one"); //$NON-NLS-1$
  }

  public synchronized void waitForTrue(final long waitTime) throws InterruptedException {
    if (!value) {
      logger.debug("waiting to become true"); //$NON-NLS-1$
      wait(waitTime);
    }
    if (value) {
      logger.debug("now true"); //$NON-NLS-1$
    }
    else {
      logger.debug("wait time expired, condition is still false, do not wait for true."); //$NON-NLS-1$
    }
  }

  public synchronized void waitForTrue() throws InterruptedException {
    waitForTrue(0);
  }
}