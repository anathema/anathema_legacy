/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.text;

import java.util.List;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.util.Ensure;

public class SuggestionResult<T> {

  private final List<T> items;
  private final IMessage optionalStateMessage;

  public SuggestionResult(final List<T> items) {
    this(items, null);
  }

  public SuggestionResult(final List<T> items, final IMessage optionalStateMessage) {
    Ensure.ensureArgumentNotNull(items);
    this.items = items;
    this.optionalStateMessage = optionalStateMessage;
  }

  public List<T> getItems() {
    return items;
  }

  public IMessage getOptionalStateMessage() {
    return optionalStateMessage;
  }
}