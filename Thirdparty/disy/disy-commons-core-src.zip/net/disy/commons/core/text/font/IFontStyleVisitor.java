package net.disy.commons.core.text.font;


/**
 * @author Markus
 */
public interface IFontStyleVisitor {
  public void visitPlainFontStyle(FontStyle fontStyle);
  public void visitBoldFontStyle(FontStyle fontStyle);
  public void visitItalicFontStyle(FontStyle fontStyle);
  public void visitBoldItalicFontStyle(FontStyle fontStyle);
}