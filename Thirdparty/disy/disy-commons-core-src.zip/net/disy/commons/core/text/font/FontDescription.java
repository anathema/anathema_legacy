/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.text.font;

import net.disy.commons.core.util.Ensure;

/**
 * @published
 */
// Groovy-Skript
public class FontDescription {

  private String fontFamilyName;
  private FontStyle fontStyle;
  private int fontSize;

  /**
   * @published
   */
  // Groovy-Skript
  public FontDescription(final String fontFamilyName, final FontStyle fontStyle, final int fontSize) {
    Ensure.ensureArgumentNotNull(fontFamilyName);
    Ensure.ensureArgumentNotNull(fontStyle);
    this.fontFamilyName = fontFamilyName;
    this.fontStyle = fontStyle;
    this.fontSize = fontSize;
  }

  public final String getFontFamilyName() {
    return fontFamilyName;
  }

  public final int getFontSize() {
    return fontSize;
  }

  public final FontStyle getFontStyle() {
    return fontStyle;
  }

  /** @deprecated As of 30.07.2009 (gebhard), replaced by {@link #deriveWithFontFamilyName(String)}
   * in order to have immutable FontDescription objects. */
  @Deprecated
  public void setFontFamilyName(final String fontFamilyName) {
    this.fontFamilyName = fontFamilyName;
  }

  public FontDescription deriveWithFontFamilyName(final String newFontFamilyName) {
    return new FontDescription(newFontFamilyName, this.fontStyle, this.fontSize);
  }

  /** @deprecated As of 30.07.2009 (gebhard), replaced by {@link #deriveWithFontSize(int)}
  * in order to have immutable FontDescription objects. */
  @Deprecated
  public final void setFontSize(final int fontSize) {
    this.fontSize = fontSize;
  }

  public FontDescription deriveWithFontSize(final int newFontSize) {
    return new FontDescription(this.fontFamilyName, this.fontStyle, newFontSize);
  }

  /** @deprecated As of 30.07.2009 (gebhard), replaced by {@link #deriveWithFontStyleize(int)}
  * in order to have immutable FontDescription objects. */
  @Deprecated
  public final void setFontStyle(final FontStyle fontStyle) {
    this.fontStyle = fontStyle;
  }

  public FontDescription deriveWithFontStyle(final FontStyle newFontStyle) {
    return new FontDescription(this.fontFamilyName, newFontStyle, this.fontSize);
  }

  @Override
  public boolean equals(final Object object) {
    if (!(object instanceof FontDescription)) {
      return false;
    }
    final FontDescription other = (FontDescription) object;
    return other.fontFamilyName.equals(fontFamilyName)
        && other.fontSize == fontSize
        && other.fontStyle == fontStyle;
  }

  @Override
  public int hashCode() {
    return 31 * (fontFamilyName.hashCode() + 31 * fontSize) + fontStyle.hashCode();
  }

  @Override
  public String toString() {
    return getClass().getName() + "{" + fontFamilyName + ", " + fontSize + ", " + fontStyle + "}"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
  }
}