//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.text.font;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class FontDescription {

  private String fontFamilyName;
  private FontStyle fontStyle;
  private int fontSize;

  public FontDescription(String fontFamilyName, FontStyle fontStyle, int fontSize) {
    Ensure.ensureArgumentNotNull(fontFamilyName);
    Ensure.ensureArgumentNotNull(fontStyle);
    this.fontFamilyName = fontFamilyName;
    this.fontStyle = fontStyle;
    this.fontSize = fontSize;
  }

  public final String getFontFamilyName() {
    return fontFamilyName;
  }

  public final int getFontSize() {
    return fontSize;
  }

  public final FontStyle getFontStyle() {
    return fontStyle;
  }

  public void setFontFamilyName(String fontFamilyName) {
    this.fontFamilyName = fontFamilyName;
  }

  public final void setFontSize(int fontSize) {
    this.fontSize = fontSize;
  }

  public final void setFontStyle(FontStyle fontStyle) {
    this.fontStyle = fontStyle;
  }

  @Override
  public boolean equals(Object object) {
    if (!(object instanceof FontDescription)) {
      return false;
    }
    FontDescription other = (FontDescription) object;
    return other.fontFamilyName.equals(fontFamilyName)
        && other.fontSize == fontSize
        && other.fontStyle == fontStyle;
  }

  @Override
  public int hashCode() {
    return 31 * (fontFamilyName.hashCode() + 31 * fontSize) + fontStyle.hashCode();
  }

  @Override
  public String toString() {
    return getClass().getName() + "{" + fontFamilyName + ", " + fontSize + ", " + fontStyle + "}"; //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$
  }
}