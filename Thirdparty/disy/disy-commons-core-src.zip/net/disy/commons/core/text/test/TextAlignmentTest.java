/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.text.test;

import java.util.Arrays;
import java.util.List;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.text.ITextAlignmentVisitor;
import net.disy.commons.core.text.TextAlignment;

import org.easymock.EasyMock;

public class TextAlignmentTest extends CoreTestCase {

  public void testGetAll() throws Exception {
    final List<TextAlignment> allAlignments = Arrays.asList(TextAlignment.getAll());
    assertEquals(3, allAlignments.size());
    assertTrue(allAlignments.contains(TextAlignment.CENTER));
    assertTrue(allAlignments.contains(TextAlignment.LEFT));
    assertTrue(allAlignments.contains(TextAlignment.RIGHT));
  }

  public void testSerialization() throws Exception {
    final TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      assertSerialization(allAlignments[index]);
    }
  }

  public void testGetBySwingValue() throws Exception {
    final TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      final TextAlignment align = allAlignments[index];
      assertSame(align, TextAlignment.getBySwingValue(align.getSwingValue()));
    }
  }

  public void testGetByDescription() throws Exception {
    final TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      final TextAlignment align = allAlignments[index];
      assertSame(align, TextAlignment.getById(align.getId()));
    }
  }

  public void testGetByCaseInsensitiveDescription() throws Exception {
    final TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      final TextAlignment align = allAlignments[index];
      final String description = align.getId();
      assertSame(align, TextAlignment.getByCaseInsensitiveId(description.toUpperCase()));
      assertSame(align, TextAlignment.getByCaseInsensitiveId(description.toLowerCase()));
    }
  }

  public void testAccept() throws Exception {
    final ITextAlignmentVisitor visitor = EasyMock.createStrictMock(ITextAlignmentVisitor.class);
    visitor.visitCenter(TextAlignment.CENTER);
    visitor.visitLeft(TextAlignment.LEFT);
    visitor.visitRight(TextAlignment.RIGHT);
    EasyMock.replay(visitor);
    TextAlignment.CENTER.accept(visitor);
    TextAlignment.LEFT.accept(visitor);
    TextAlignment.RIGHT.accept(visitor);
    EasyMock.verify(visitor);
  }
}