// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 24.06.2004
package net.disy.commons.core.text.test;

import java.util.Arrays;
import java.util.List;


import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.text.ITextAlignmentVisitor;
import net.disy.commons.core.text.TextAlignment;

import org.easymock.MockControl;

// NOT_PUBLISHED
public class TextAlignmentTest extends CoreTestCase {

  public void testGetAll() throws Exception {
    List<TextAlignment> allAlignments = Arrays.asList(TextAlignment.getAll());
    assertEquals(3, allAlignments.size());
    assertTrue(allAlignments.contains(TextAlignment.CENTER));
    assertTrue(allAlignments.contains(TextAlignment.LEFT));
    assertTrue(allAlignments.contains(TextAlignment.RIGHT));
  }

  public void testSerialization() throws Exception {
    TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      assertSerialization(allAlignments[index]);
    }
  }

  public void testGetBySwingValue() throws Exception {
    TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      TextAlignment align = allAlignments[index];
      assertSame(align, TextAlignment.getBySwingValue(align.getSwingValue()));
    }
  }
  
  public void testGetByDescription() throws Exception {
    TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      TextAlignment align = allAlignments[index];
      assertSame(align, TextAlignment.getByDescription(align.getDescription()));
    }
  }
  
  public void testGetByCaseInsensitiveDescription() throws Exception {
    TextAlignment[] allAlignments = TextAlignment.getAll();
    for (int index = 0; index < allAlignments.length; index++) {
      TextAlignment align = allAlignments[index];
      String description = align.getDescription();
      assertSame(align, TextAlignment.getByCaseInsensitiveDescription(description.toUpperCase()));
      assertSame(align, TextAlignment.getByCaseInsensitiveDescription(description.toLowerCase()));
    }
  }
  
  public void testAccept() throws Exception {
    MockControl control = MockControl.createStrictControl(ITextAlignmentVisitor.class);
    ITextAlignmentVisitor visitor = (ITextAlignmentVisitor) control.getMock();
    visitor.visitCenter(TextAlignment.CENTER);
    visitor.visitLeft(TextAlignment.LEFT);
    visitor.visitRight(TextAlignment.RIGHT);
    control.replay();
    TextAlignment.CENTER.accept(visitor);
    TextAlignment.LEFT.accept(visitor);
    TextAlignment.RIGHT.accept(visitor);
    control.verify();
  }
}