// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 07.03.2005
package net.disy.commons.core.text.font.test;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.text.font.FontStyle;
import net.disy.commons.core.util.ISimpleBlock;

// NOT_PUBLISHED
public class FontStyleTest extends CoreTestCase {

  public void testGetByName() {
    FontStyle[] allFontStyles = FontStyle.getAll();
    for (int index = 0; index < allFontStyles.length; index++) {
      FontStyle fontStyle = allFontStyles[index];
      assertSame(fontStyle, FontStyle.getByName(fontStyle.getName()));
    }
    assertThrowsException(IllegalArgumentException.class, new ISimpleBlock() {
      public void execute() {
        FontStyle.getByName("Illegal"); //$NON-NLS-1$
      }
    });
  }

  public void testSerialization() throws Exception {
    FontStyle[] allFontStyles = FontStyle.getAll();
    for (int index = 0; index < allFontStyles.length; index++) {
      FontStyle fontStyle = allFontStyles[index];
      assertSame(fontStyle, FontStyle.getByName(fontStyle.getName()));
    }
  }
}