// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 07.03.2005
package net.disy.commons.core.text.font.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.core.graphics.font.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(FontStyleTest.class);
    //$JUnit-END$
    return suite;
  }
}
