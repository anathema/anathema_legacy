// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 24.06.2004
package net.disy.commons.core.text;

// NOT_PUBLISHED
public interface ITextAlignmentVisitor {

  public void visitCenter(TextAlignment visitedAlign);
  
  public void visitLeft(TextAlignment visitedAlign);
  
  public void visitRight(TextAlignment visitedAlign);
  
}
