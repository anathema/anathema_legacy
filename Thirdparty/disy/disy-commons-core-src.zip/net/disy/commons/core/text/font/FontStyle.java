/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.text.font;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.ObjectUtilities;

/**
 * @published
 */
// Groovy-Skript
public enum FontStyle {

  /**
   * @published
   */
  // Groovy-Skript
  PLAIN("Plain") {//$NON-NLS-1$
    @Override
    public void accept(final IFontStyleVisitor visitor) {
      visitor.visitPlainFontStyle(this);
    }
  },
  /**
   * @published
   */
  // Groovy-Skript
  ITALIC("Italic", FontStyleProperty.ITALICS) {//$NON-NLS-1$
    @Override
    public void accept(final IFontStyleVisitor visitor) {
      visitor.visitItalicFontStyle(this);
    }
  },
  /**
   * @published
   */
  // Groovy-Skript
  BOLD("Bold", FontStyleProperty.BOLD) {//$NON-NLS-1$
    @Override
    public void accept(final IFontStyleVisitor visitor) {
      visitor.visitBoldFontStyle(this);
    }
  },
  /**
   * @published
   */
  // Groovy-Skript
  BOLD_ITALIC("Bold italic", FontStyleProperty.BOLD, FontStyleProperty.ITALICS) {//$NON-NLS-1$
    @Override
    public void accept(final IFontStyleVisitor visitor) {
      visitor.visitBoldItalicFontStyle(this);
    }
  };

  private final String name;
  private final Set<FontStyleProperty> properties;

  private FontStyle(final String name, final FontStyleProperty... properties) {
    this.name = name;
    this.properties = new HashSet<FontStyleProperty>(Arrays.asList(properties));
  }

  public abstract void accept(IFontStyleVisitor visitor);

  public boolean isItalic() {
    return properties.contains(FontStyleProperty.ITALICS);
  }

  public boolean isBold() {
    return properties.contains(FontStyleProperty.BOLD);
  }

  public boolean isPlain() {
    return !isBold() && !isItalic();
  }

  public String getName() {
    return name;
  }

  public static FontStyle getByName(final String name) {
    for (final FontStyle fontStyle : values()) {
      if (name.equals(fontStyle.getName())) {
        return fontStyle;
      }
    }
    throw new IllegalArgumentException("No font style defined for name " + name); //$NON-NLS-1$
  }

  public static boolean nameExists(final String name) {
    for (final FontStyle fontStyle : values()) {
      if (ObjectUtilities.equals(name, fontStyle.getName())) {
        return true;
      }
    }
    return false;
  }

  public static FontStyle getStyle(final boolean isBold, final boolean isItalic) {
    final Set<FontStyleProperty> properties = new HashSet<FontStyleProperty>();
    if (isBold) {
      properties.add(FontStyleProperty.BOLD);
    }
    if (isItalic) {
      properties.add(FontStyleProperty.ITALICS);
    }
    return getStyle(properties);
  }

  public static FontStyle getStyle(final Set<FontStyleProperty> properties) {
    for (final FontStyle style : values()) {
      if (style.properties.equals(properties)) {
        return style;
      }
    }
    throw new UnreachableCodeReachedException("(ip)"); //$NON-NLS-1$
  }

  public FontStyle derive(final FontStyleProperty fontStyle, final boolean enabled) {
    final HashSet<FontStyleProperty> newProperties = new HashSet<FontStyleProperty>(properties);
    if (enabled) {
      newProperties.add(fontStyle);
    }
    else {
      newProperties.remove(fontStyle);
    }
    return getStyle(newProperties);
  }

  public boolean isEnabled(final FontStyleProperty fontStyle) {
    return properties.contains(fontStyle);
  }

}