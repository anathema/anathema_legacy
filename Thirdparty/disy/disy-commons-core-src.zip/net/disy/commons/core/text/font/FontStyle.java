package net.disy.commons.core.text.font;

import java.awt.Font;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.util.ObjectUtilities;

public abstract class FontStyle implements Serializable {
  private String name;
  private final static List<FontStyle> ALL = new ArrayList<FontStyle>();

  public final static FontStyle PLAIN = new FontStyle("Plain", false, false) {//$NON-NLS-1$
    @Override
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitPlainFontStyle(this);
    }
  };
  public final static FontStyle ITALIC = new FontStyle("Italic", false, true) {//$NON-NLS-1$
    @Override
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitItalicFontStyle(this);
    }
  };
  public final static FontStyle BOLD = new FontStyle("Bold", true, false) {//$NON-NLS-1$
    @Override
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitBoldFontStyle(this);
    }
  };
  public final static FontStyle BOLD_ITALIC = new FontStyle("Bold italic", true, true) {//$NON-NLS-1$
    @Override
    public void accept(IFontStyleVisitor visitor) {
      visitor.visitBoldItalicFontStyle(this);
    }
  };
  private final boolean bold;
  private final boolean italic;

  private FontStyle(String name, boolean bold, boolean italic) {
    ALL.add(this);
    this.bold = bold;
    this.name = name;
    this.italic = italic;
  }

  public static FontStyle[] getAll() {
    return ALL.toArray(new FontStyle[ALL.size()]);
  }

  @Override
  public String toString() {
    return name;
  }

  public abstract void accept(IFontStyleVisitor visitor);

  public boolean isItalic() {
    return italic;
  }

  public boolean isBold() {
    return bold;
  }

  public boolean isPlain() {
    return !isBold() && !isItalic();
  }

  public String getName() {
    return name;
  }

  public static FontStyle getByName(String name) {
    for (FontStyle fontStyle : ALL) {
      if (name.equals(fontStyle.getName())) {
        return fontStyle;
      }
    }
    throw new IllegalArgumentException("No font style defined for name " + name); //$NON-NLS-1$
  }

  public static boolean nameExists(String name) {
    for (FontStyle fontStyle : ALL) {
      if (ObjectUtilities.equals(name, fontStyle.getName())) {
        return true;
      }
    }
    return false;
  }

  protected Object readResolve() {
    return getByName(getName());
  }

  public static FontStyle getFrom(Font font) {
    return getStyle(font.isBold(), font.isItalic());
  }

  public static FontStyle getStyle(boolean isBold, boolean isItalic) {
    if (isBold && isItalic) {
      return BOLD_ITALIC;
    }
    if (isBold) {
      return BOLD;
    }
    if (isItalic) {
      return ITALIC;
    }
    return PLAIN;
  }
}