// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 24.06.2004
package net.disy.commons.core.text;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingConstants;

// NOT_PUBLISHED
public abstract class TextAlignment implements Serializable {

  private static final List<TextAlignment> ALL = new ArrayList<TextAlignment>();
  public static final TextAlignment CENTER = new TextAlignment("Center", SwingConstants.CENTER) { //$NON-NLS-1$
    public void accept(ITextAlignmentVisitor visitor) {
      visitor.visitCenter(this);
    }
  };
  public static final TextAlignment LEFT = new TextAlignment("Left", SwingConstants.LEFT) { //$NON-NLS-1$
    public void accept(ITextAlignmentVisitor visitor) {
      visitor.visitLeft(this);
    }
  };
  public static final TextAlignment RIGHT = new TextAlignment("Right", SwingConstants.RIGHT) { //$NON-NLS-1$
    public void accept(ITextAlignmentVisitor visitor) {
      visitor.visitRight(this);
    }
  };

  private final String description;
  private final int swingConstant;

  private TextAlignment(String description, int swingConstant) {
    this.description = description;
    this.swingConstant = swingConstant;
    ALL.add(this);
  }

  public int getSwingValue() {
    return swingConstant;
  }

  public String toString() {
    return description;
  }

  public abstract void accept(ITextAlignmentVisitor visitor);

  public static TextAlignment[] getAll() {
    return ALL.toArray(new TextAlignment[ALL.size()]);
  }

  public static TextAlignment getBySwingValue(int swingValue) {
    for (TextAlignment alignment : ALL) {
      if (alignment.getSwingValue() == swingValue) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment for swingValue " + swingValue + " defined"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  protected Object readResolve() {
    return getBySwingValue(getSwingValue());
  }

  public static TextAlignment getByDescription(String description) {
    for (TextAlignment alignment : ALL) {
      if (alignment.getDescription().equals(description)) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment defined for description " + description); //$NON-NLS-1$
  }

  public static TextAlignment getByCaseInsensitiveDescription(String description) {
    String lowerCasedDescription = description.toLowerCase();
    for (TextAlignment alignment : ALL) {
      if (alignment.getDescription().toLowerCase().equals(lowerCasedDescription)) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment defined for description " + description); //$NON-NLS-1$
  }

  public String getDescription() {
    return description;
  }
}