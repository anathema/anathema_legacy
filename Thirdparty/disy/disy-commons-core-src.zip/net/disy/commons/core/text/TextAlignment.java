/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.text;

/**
 * @published
 */
// Groovy-Skript
public enum TextAlignment {
  /**
   * @published
   */
  // Groovy-Skript
  CENTER("Center", 0) { //$NON-NLS-1$
    @Override
    public void accept(final ITextAlignmentVisitor visitor) {
      visitor.visitCenter(this);
    }
  },
  /**
   * @published
   */
  // Groovy-Skript
  LEFT("Left", 2) { //$NON-NLS-1$
    @Override
    public void accept(final ITextAlignmentVisitor visitor) {
      visitor.visitLeft(this);
    }
  },
  /**
   * @published
   */
  // Groovy-Skript
  RIGHT("Right", 4) { //$NON-NLS-1$
    @Override
    public void accept(final ITextAlignmentVisitor visitor) {
      visitor.visitRight(this);
    }
  };

  private final String description;
  private final int swingValue;

  private TextAlignment(final String description, final int swingValue) {
    this.description = description;
    this.swingValue = swingValue;
  }

  /** @deprecated As of 06.05.2009 (gebhard), replaced by {@link #getSwingValue()} */
  @Deprecated
  public int getIdValue() {
    return getSwingValue();
  }

  public int getSwingValue() {
    return swingValue;
  }

  @Override
  public String toString() {
    return description;
  }

  public abstract void accept(ITextAlignmentVisitor visitor);

  public static TextAlignment[] getAll() {
    return values();
  }

  /** @deprecated As of 06.05.2009 (gebhard), replaced by {@link #getBySwingValue(int)} */
  @Deprecated
  public static TextAlignment getByIdValue(final int swingValue) {
    return getBySwingValue(swingValue);
  }

  public static TextAlignment getBySwingValue(final int swingValue) {
    for (final TextAlignment alignment : TextAlignment.getAll()) {
      if (alignment.swingValue == swingValue) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment for swingValue " + swingValue + " defined"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /** @deprecated As of 06.05.2009 (gebhard), replaced by {@link #getById(String)} */
  @Deprecated
  public static TextAlignment getByDescription(final String description) {
    return getById(description);
  }

  public static TextAlignment getById(final String id) {
    for (final TextAlignment alignment : values()) {
      if (alignment.description.equals(id)) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment defined for description " + id); //$NON-NLS-1$
  }

  /** @deprecated As of 06.05.2009 (gebhard), replaced by {@link #getByCaseInsensitiveId(String)} */
  @Deprecated
  public static TextAlignment getByCaseInsensitiveDescription(final String description) {
    return getByCaseInsensitiveId(description);
  }

  public static TextAlignment getByCaseInsensitiveId(final String id) {
    final String lowerCasedDescription = id.toLowerCase();
    for (final TextAlignment alignment : values()) {
      if (alignment.description.toLowerCase().equals(lowerCasedDescription)) {
        return alignment;
      }
    }
    throw new IllegalArgumentException("No TextAlignment defined for id " + id); //$NON-NLS-1$
  }

  public String getId() {
    return description;
  }

  /** @deprecated As of 06.05.2009 (gebhard), replaced by {@link #getId()} */
  @Deprecated
  public String getDescription() {
    return getId();
  }
}