// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 24.06.2004
package net.disy.commons.core.text.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for de.disy.lib.basics.text.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(TextAlignmentTest.class);
    //$JUnit-END$
    return suite;
  }
}