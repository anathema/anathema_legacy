/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.DisjunctiveCombinationBooleanModel;

import org.junit.Test;

public class DisjunctiveCombinationBooleanModelTest {

  @Test
  public void testTrueTrueEqualsTrue() {
    final boolean result = new DisjunctiveCombinationBooleanModel(
        new BooleanModel(true),
        new BooleanModel(true)).getValue();
    assertTrue(result);
  }

  @Test
  public void testTrueFalseEqualsTrue() {
    final boolean result = new DisjunctiveCombinationBooleanModel(
        new BooleanModel(true),
        new BooleanModel(false)).getValue();
    assertTrue(result);
  }

  @Test
  public void testFalseTrueEqualsTrue() {
    final boolean result = new DisjunctiveCombinationBooleanModel(
        new BooleanModel(false),
        new BooleanModel(true)).getValue();
    assertTrue(result);
  }

  @Test
  public void testFalseFalseEqualsFalse() {
    final boolean result = new DisjunctiveCombinationBooleanModel(
        new BooleanModel(false),
        new BooleanModel(false)).getValue();
    assertFalse(result);
  }
}
