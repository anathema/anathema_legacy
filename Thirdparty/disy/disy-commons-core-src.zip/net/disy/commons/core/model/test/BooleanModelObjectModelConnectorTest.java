/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import static org.junit.Assert.*;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.BooleanModelObjectModelConnector;
import net.disy.commons.core.model.ObjectModel;

import org.junit.Before;
import org.junit.Test;

public class BooleanModelObjectModelConnectorTest {

  private BooleanModelObjectModelConnector<String> booleanModelObjectModelConnector;
  private ObjectModel<String> objectModel;
  private BooleanModel booleanModel;

  @Before
  public void setup() throws Exception {
    objectModel = new ObjectModel<String>();
    booleanModelObjectModelConnector = new BooleanModelObjectModelConnector<String>(
        objectModel,
        "empty"); //$NON-NLS-1$
    booleanModel = new BooleanModel(false);
  }

  @Test
  public void initialValueIsEmptyValue() throws Exception {
    assertEquals("empty", objectModel.getValue()); //$NON-NLS-1$
  }

  @Test
  public void objectModelChangesWhenBooleanModelChanges() throws Exception {
    booleanModelObjectModelConnector.connect(booleanModel, "active"); //$NON-NLS-1$
    booleanModel.setValue(true);
    assertEquals("active", objectModel.getValue()); //$NON-NLS-1$
  }

  @Test
  public void objectModelIsEmptyWhenBooleanModelChangesBackToFalse() throws Exception {
    booleanModelObjectModelConnector.connect(booleanModel, "active"); //$NON-NLS-1$
    booleanModel.setValue(true);
    booleanModel.setValue(false);
    assertEquals("empty", objectModel.getValue()); //$NON-NLS-1$
  }

  @Test
  public void objectModelReflectsInitialBooolenModelValue() throws Exception {
    booleanModel.setValue(true);
    booleanModelObjectModelConnector.connect(booleanModel, "active"); //$NON-NLS-1$
    assertEquals("active", objectModel.getValue()); //$NON-NLS-1$
  }

  @Test
  public void booleanModelChangesWhenObjectModelChanges() throws Exception {
    booleanModelObjectModelConnector.connect(booleanModel, "active"); //$NON-NLS-1$
    objectModel.setValue("active"); //$NON-NLS-1$
    assertTrue(booleanModel.getValue());
  }

  @Test
  public void objectModelChangesWhenSecondBooleanModelChanges() throws Exception {
    final BooleanModel booleanModel2 = new BooleanModel(false);
    booleanModelObjectModelConnector.connect(booleanModel, "active"); //$NON-NLS-1$
    booleanModelObjectModelConnector.connect(booleanModel2, "active2"); //$NON-NLS-1$
    assertEquals("empty", objectModel.getValue()); //$NON-NLS-1$
    booleanModel.setValue(true);
    assertEquals("active", objectModel.getValue()); //$NON-NLS-1$
    assertFalse(booleanModel2.getValue());
    booleanModel2.setValue(true);
    assertEquals("active2", objectModel.getValue()); //$NON-NLS-1$
    assertFalse(booleanModel.getValue());
    booleanModel2.setValue(false);
    assertEquals("empty", objectModel.getValue()); //$NON-NLS-1$
    assertFalse(booleanModel.getValue());
  }
}
