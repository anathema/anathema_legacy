//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import javax.swing.event.ChangeListener;

// NOT_PUBLISHED
public interface IChangeableModel {

  public void addChangeListener(ChangeListener listener);

  public void removeChangeListener(ChangeListener listener);
  
}
