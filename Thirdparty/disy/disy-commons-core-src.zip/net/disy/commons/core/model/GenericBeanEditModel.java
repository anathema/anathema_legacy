/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import java.util.LinkedList;
import java.util.List;

import net.disy.commons.core.copyable.IObjectCopyManager;

public class GenericBeanEditModel<T> implements IBeanEditModel<T> {

  private final T originalBean;

  private T beanUnderEdit;

  private final IObjectCopyManager<T> copyManager;

  private final Class<? extends T> beanClass;

  private boolean isEditing;

  private final List<IBeanEditModelChangeListener<T>> listeners = new LinkedList<IBeanEditModelChangeListener<T>>();

  public GenericBeanEditModel(
      T bean,
      Class<? extends T> beanClass,
      IObjectCopyManager<T> copyManager) {
    this.beanClass = beanClass;
    this.originalBean = bean;
    this.beanUnderEdit = null;
    this.copyManager = copyManager;
    isEditing = false;
  }

  private T createCopy() {
    try {
      T beanCopy = beanClass.newInstance();
      copyManager.copy(originalBean, beanCopy);
      return beanCopy;
    }
    catch (InstantiationException e) {
      throw new RuntimeException(e);
    }
    catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }

  @Override
  public void addBeanEditChangeListener(IBeanEditModelChangeListener<T> listener) {
    listeners.add(listener);
  }

  @Override
  public void removeBeanEditChangeListener(IBeanEditModelChangeListener<T> listener) {
    listeners.remove(listener);
  }

  @Override
  public void commit() {
    if (!isEditing) {
      throw new IllegalStateException("Called commit but not yet editing");
    }
    if (!copyManager.hasChanged(beanUnderEdit, originalBean)) {
      isEditing = false;
      for (IBeanEditModelChangeListener<T> listener : listeners) {
        listener.modelCommittedNoChanges(this);
      }
      return;
    }
    copyManager.copy(beanUnderEdit, originalBean);
    isEditing = false;
    for (IBeanEditModelChangeListener<T> listener : listeners) {
      listener.modelCommittedWithChanges(this);
    }
  }

  @Override
  public void rollback() {
    if (!isEditing) {
      throw new IllegalStateException("Called rollback but not yet  editing");
    }
    copyManager.copy(originalBean, beanUnderEdit);
    isEditing = false;
    for (IBeanEditModelChangeListener<T> listener : listeners) {
      listener.modelRolledBack(this);
    }
  }

  @Override
  public boolean isDirty() {
    if (isEditing) {
      return copyManager.hasChanged(beanUnderEdit, originalBean);
    }
    return false;
  }

  @Override
  public T getValue() {
    if (isEditing) {
      return beanUnderEdit;
    }
    else {
      return originalBean;
    }
  }

  //  @Override
  //  public void markAsDeleted() {
  //    for (IBeanEditModelChangeListener<T> listener : listeners) {
  //      listener.beanDeleted(getValue());
  //    }
  //  }

  @Override
  public void beginEditing() {
    if (isEditing) {
      throw new IllegalStateException("Called beginEditing but already editing");
    }
    isEditing = true;
    beanUnderEdit = createCopy();
    initGuiModels();
  }

  /**
   * Overwrite this method if you need GUI-specific models
   */
  protected void initGuiModels() {
    //do nothing

  }

  @Override
  public boolean isEditing() {
    return isEditing;
  }

}
