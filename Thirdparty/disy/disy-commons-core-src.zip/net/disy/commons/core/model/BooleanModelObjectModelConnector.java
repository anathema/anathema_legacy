/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import java.util.ArrayList;
import java.util.Collection;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.ObjectUtilities;

public class BooleanModelObjectModelConnector<T> {

  private final ObjectModel<T> objectModel;
  private final T emptyValue;
  private final Collection<BooleanModel> modelList = new ArrayList<BooleanModel>();

  public BooleanModelObjectModelConnector(final ObjectModel<T> objectModel, final T emptyValue) {
    this.objectModel = objectModel;
    this.emptyValue = emptyValue;
    objectModel.setValue(emptyValue);
  }

  public void connect(final BooleanModel booleanModel, final T value) {
    updateObjectModel(booleanModel, value);
    booleanModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateObjectModel(booleanModel, value);
      }
    });
    objectModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateBooleanModel(booleanModel, value);
      }
    });
    modelList.add(booleanModel);
  }

  private void updateBooleanModel(final BooleanModel booleanModel, final T value) {
    booleanModel.setValue(ObjectUtilities.equals(objectModel.getValue(), value));
  }

  private void updateObjectModel(final BooleanModel booleanModel, final T value) {
    if (booleanModel.getValue()) {
      objectModel.setValue(value);
    }
    else {
      boolean modelListContainsTrueModel = false;
      for (final BooleanModel model : modelList) {
        if (model.getValue()) {
          modelListContainsTrueModel = true;
        }
      }
      if (!modelListContainsTrueModel) {
        objectModel.setValue(emptyValue);
      }
    }
  }
}
