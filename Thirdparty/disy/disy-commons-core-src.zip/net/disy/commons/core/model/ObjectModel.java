// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 25.08.2005
package net.disy.commons.core.model;

import net.disy.commons.core.util.ObjectUtilities;

// NOT_PUBLISHED
public class ObjectModel<T> extends AbstractChangeableModel {

  private T value;

  public ObjectModel() {
    this(null);
  }

  public ObjectModel(T value) {
    this.value = value;
  }

  public T getValue() {
    synchronized (getMutex()) {
      return value;
    }
  }

  public void setValue(T value) {
    synchronized (getMutex()) {
      if (ObjectUtilities.equals(this.value, value)) {
        return;
      }
      this.value = value;
      fireChangeEvent();
    }
  }
}