package net.disy.commons.core.model;

public class BooleanModel extends AbstractChangeableModel {

  private boolean value;

  public BooleanModel() {
    this(false);
  }

  public BooleanModel(boolean value) {
    this.value = value;
  }

  public boolean getValue() {
    return value;
  }

  public void setValue(boolean selected) {
    if (this.value == selected) {
      return;
    }
    this.value = selected;
    fireChangeEvent();
  }
}