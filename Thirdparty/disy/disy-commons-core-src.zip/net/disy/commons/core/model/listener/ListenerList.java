//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ListenerList {
  private final List listeners;

  public ListenerList() {
    this(new ArrayList());
  }

  private ListenerList(List listeners) {
    Ensure.ensureArgumentNotNull(listeners);
    this.listeners = listeners;
  }

  public synchronized void add(Object listener) {
    Ensure.ensureArgumentNotNull(listener);
    listeners.add(listener);
  }

  public synchronized void remove(Object listener) {
    listeners.remove(listener);
  }

  public void forAllDo(IListenerClosure closure) {
    Collection clone;
    synchronized (this) {
      clone = new ArrayList(listeners);
    }
    for (Iterator it = clone.iterator(); it.hasNext();) {
      closure.execute(it.next());
    }
  }

  public synchronized ListenerList getClone() {
    return new ListenerList(new ArrayList(listeners));
  }

  public synchronized boolean contains(Object listener) {
    return listeners.contains(listener);
  }
}