//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ListenerList<L> {
  private final List<L> listeners;

  public ListenerList() {
    this(new ArrayList<L>());
  }

  private ListenerList(List<L> listeners) {
    Ensure.ensureArgumentNotNull(listeners);
    this.listeners = listeners;
  }

  public synchronized void add(L listener) {
    Ensure.ensureArgumentNotNull(listener);
    listeners.add(listener);
  }

  public synchronized void remove(L listener) {
    listeners.remove(listener);
  }

  public void forAllDo(IListenerClosure<L> closure) {
    Collection<L> cloneList;
    synchronized (this) {
      cloneList = new ArrayList<L>(listeners);
    }
    for (L listener : cloneList) {
      closure.execute(listener);
    }
  }

  public synchronized ListenerList<L> getClone() {
    return new ListenerList<L>(new ArrayList<L>(listeners));
  }

  public synchronized boolean contains(L listener) {
    return listeners.contains(listener);
  }

  public synchronized void clear() {
    listeners.clear();
  }

  public synchronized boolean isEmpty() {
    return listeners.isEmpty();
  }

  public synchronized int getSize() {
    return listeners.size();
  }
}