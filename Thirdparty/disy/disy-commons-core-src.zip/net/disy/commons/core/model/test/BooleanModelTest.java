/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.SimpleBlock;

public class BooleanModelTest extends AbstractChangeableModelTestCase {

  private BooleanModel model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new BooleanModel();
  }

  public void testCreate() {
    assertFalse(model.getValue());
  }

  public void testSetSelected() {
    model.setValue(true);
    assertTrue(model.getValue());
    model.setValue(false);
    assertFalse(model.getValue());
  }

  public void testFiresChangeEventOnChange() {
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setValue(true);
      }
    });
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setValue(false);
      }
    });
  }

  public void testFiresNoChangeEventOnNoChange() {
    assertFiresChangeEvents(model, 0, new SimpleBlock() {
      @Override
      public void execute() {
        model.setValue(false);
      }
    });
    model.setValue(true);
    assertFiresChangeEvents(model, 0, new SimpleBlock() {
      @Override
      public void execute() {
        model.setValue(true);
      }
    });
  }
}