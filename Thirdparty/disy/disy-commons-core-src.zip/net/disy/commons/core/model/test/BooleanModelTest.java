//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.test;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.ISimpleBlock;

// NOT_PUBLISHED
public class BooleanModelTest extends AbstractChangeableModelTestCase {

  private BooleanModel model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new BooleanModel();
  }

  public void testCreate() {
    assertFalse(model.getValue());
  }

  public void testSetSelected() {
    model.setValue(true);
    assertTrue(model.getValue());
    model.setValue(false);
    assertFalse(model.getValue());
  }

  public void testFiresChangeEventOnChange() {
    assertFiresChangeEvents(model, 1, new ISimpleBlock() {
      public void execute() {
        model.setValue(true);
      }
    });
    assertFiresChangeEvents(model, 1, new ISimpleBlock() {
      public void execute() {
        model.setValue(false);
      }
    });
  }

  public void testFiresNoChangeEventOnNoChange() {
    assertFiresChangeEvents(model, 0, new ISimpleBlock() {
      public void execute() {
        model.setValue(false);
      }
    });
    model.setValue(true);
    assertFiresChangeEvents(model, 0, new ISimpleBlock() {
      public void execute() {
        model.setValue(true);
      }
    });
  }
}