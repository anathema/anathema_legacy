/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ObjectSetModel<T> extends AbstractChangeableModel implements IObjectSetModel<T> {

  private final Set<T> set = Collections.synchronizedSet(new HashSet<T>());

  @Override
  public void add(final T... items) {
    if (this.set.addAll(Arrays.asList(items))) {
      fireChangeEvent();
    }
  }

  @Override
  public void clear() {
    if (set.isEmpty()) {
      this.set.clear();
      fireChangeEvent();
    }
  }

  @Override
  public void remove(final T... items) {
    if (this.set.removeAll(Arrays.asList(items))) {
      fireChangeEvent();
    }
  }

  @Override
  public boolean isEmpty() {
    return set.isEmpty();
  }
}