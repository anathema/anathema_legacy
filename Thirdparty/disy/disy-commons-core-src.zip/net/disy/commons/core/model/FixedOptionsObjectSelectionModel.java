// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;

//NOT_PUBLISHED
public class FixedOptionsObjectSelectionModel<T> extends ObjectSelectionModel<T> {
  private final T[] allValues;

  public FixedOptionsObjectSelectionModel(T[] allValues) {
    this.allValues = allValues;
  }

  public void setSelectedValues(T[] values) {
    Set<T> newValues = new HashSet<T>(Arrays.asList(values));
    if (newValues.equals(this.getSelectedValuesSet())) {
      return;
    }
    this.getSelectedValuesSet().clear();
    this.getSelectedValuesSet().addAll(newValues);
    fireChangeEvent();
  }

  public T getFirstSelectedValue() {
    return ArrayUtilities.getFirst(allValues, getPredicate());
  }

  public T[] getSelectedValues() {
    return ArrayUtilities.filter(allValues, getPredicate());
  }

  private IPredicate<T> getPredicate() {
    return new IPredicate<T>() {
      public boolean evaluate(T input) {
        return getSelectedValuesSet().contains(input);
      }
    };
  }

  public int[] getSelectedIndices() {
    return ArrayUtilities.getIndices(getSelectedValues(), allValues);
  }
}