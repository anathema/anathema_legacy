/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.Ensure;

public class FixedOptionsObjectSelectionModel<T> extends ObjectSelectionModel<T> {
  private final List<T> allValues;

  public FixedOptionsObjectSelectionModel(final T[] allValues) {
    this(Arrays.asList(allValues));
  }

  public FixedOptionsObjectSelectionModel(final List<T> allValues) {
    Ensure.ensureArgumentNotNull(allValues);
    this.allValues = allValues;
  }

  public void setSelectedValue(final T value) {
    if (value == null) {
      clearSelection();
      return;
    }
    final Set<T> selectedValuesSet = getSelectedValuesSet();
    if (selectedValuesSet.size() == 1 && selectedValuesSet.contains(value)) {
      return;
    }
    selectedValuesSet.clear();
    selectedValuesSet.add(value);
    fireChangeEvent();
  }

  public void clearSelection() {
    final Set<T> selectedValuesSet = getSelectedValuesSet();
    if (selectedValuesSet.size() == 0) {
      return;
    }
    getSelectedValuesSet().clear();
    fireChangeEvent();
  }

  public void setSelectedValues(final T[] values) {
    setSelectedValues(new HashSet<T>(Arrays.asList(values)));
  }

  public void setSelectedValues(final Set<T> newValues) {
    if (newValues.equals(getSelectedValuesSet())) {
      return;
    }
    getSelectedValuesSet().clear();
    getSelectedValuesSet().addAll(newValues);
    fireChangeEvent();
  }

  public T getFirstSelectedValue() {
    return CollectionUtilities.getFirst(allValues, getPredicate());
  }

  public List<T> getSelectedValues() {
    return CollectionUtilities.filter(allValues, getPredicate());
  }

  private IPredicate<T> getPredicate() {
    return new IPredicate<T>() {
      @Override
      public boolean evaluate(final T input) {
        return getSelectedValuesSet().contains(input);
      }
    };
  }

  public int[] getSelectedIndices() {
    return CollectionUtilities.getIndices(getSelectedValues(), allValues);
  }

  @SuppressWarnings("unchecked")
  public T[] getAllValues() {
    return (T[]) allValues.toArray();
  }
}