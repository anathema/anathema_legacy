// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model.test;


import net.disy.commons.core.model.StringSelectionModel;
import net.disy.commons.core.util.IBlock;

//NOT_PUBLISHED
public class StringSelectionModelTest extends AbstractChangeableModelTestCase {
  private StringSelectionModel model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new StringSelectionModel();
  }
  
  public void testEmpty() throws Exception {
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }
  
  public void testSingleSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    assertTrue(model.isSelected("string")); //$NON-NLS-1$
    assertFalse(model.isSelected("foo")); //$NON-NLS-1$
  }
  
  public void testDeSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    model.setSelected("string", false); //$NON-NLS-1$
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }
  
  public void testFiresEvent() throws Exception {
    assertFiresChangeEvents(model, 1, new IBlock() {
      public void execute(Object each) {
        model.setSelected("string", true); //$NON-NLS-1$
      }
    });
    assertFiresChangeEvents(model, 1, new IBlock() {
      public void execute(Object each) {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }
  
  public void testNoChangeNoEvent() throws Exception {
    assertFiresChangeEvents(model, 0, new IBlock() {
      public void execute(Object each) {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }
}