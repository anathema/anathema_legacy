// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import java.util.HashSet;
import java.util.Set;

//NOT_PUBLISHED
public class StringSelectionModel extends AbstractChangeableModel {

  private final Set selectedValues = new HashSet();

  public void setSelected(String string, boolean selected) {
    if (selected == isSelected(string)) {
      return;
    }

    if (selected) {
      selectedValues.add(string);
    }
    else {
      selectedValues.remove(string);
    }

    fireChangeEvent();
  }

  public boolean isSelected(String string) {
    return selectedValues.contains(string);
  }
}