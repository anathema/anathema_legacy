/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import net.disy.commons.core.copyable.IObjectCopyManager;
import net.disy.commons.core.model.GenericBeanEditModel;
import net.disy.commons.core.model.IBeanEditModelChangeListener;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class GenericBeanEditModelTest {

  private TestBean bean;
  private GenericBeanEditModel<TestBean> model;
  private IBeanEditModelChangeListener<TestBean> listenerMock;
  private TestBean guiBean;

  public static class TestBean {
    private int testfield1;
    private int testfield2;
  }

  /** copies and compares only testfield1.
   */
  public class TestCopyManager implements IObjectCopyManager<TestBean> {

    @Override
    public void copy(TestBean source, TestBean target) {
      target.testfield1 = source.testfield1;

    }

    @Override
    public boolean hasChanged(TestBean source, TestBean target) {
      return source.testfield1 != target.testfield1;
    }

  }

  @Before
  @SuppressWarnings("unchecked")
  public void setUp() {
    bean = new TestBean();
    bean.testfield1 = 1;
    bean.testfield2 = 2;
    model = new GenericBeanEditModel<TestBean>(bean, TestBean.class, new TestCopyManager());
    listenerMock = mock(IBeanEditModelChangeListener.class);
    model.addBeanEditChangeListener(listenerMock);
    guiBean = model.getValue();
  }

  @Test
  public void sameBeanInstanceBeforeEditing() {
    //not yet editing, same instance
    assertSame(bean, guiBean);
    assertFalse(model.isEditing());
    assertFalse(model.isDirty());
  }

  @Test
  public void notCopiedFieldIsNotChanged() {

    // change field that is ignored my CopyManager and check that nothing happens
    model.beginEditing();
    assertTrue(model.isEditing());
    guiBean = model.getValue();
    assertNotSame(bean, guiBean);
    assertEquals(1, guiBean.testfield1);
    assertEquals(0, guiBean.testfield2);
    guiBean.testfield2 = 200;
    assertFalse(model.isDirty());
    model.commit();
    assertFalse(model.isEditing());
    Mockito.verify(listenerMock, Mockito.never()).modelRolledBack(model);
    Mockito.verify(listenerMock, Mockito.never()).modelCommittedWithChanges(model);
    Mockito.verify(listenerMock, Mockito.only()).modelCommittedNoChanges(model);

  }

  @Test
  public void copyiedFieldIsChanged() {
    // change field that is addressed my CopyManager and test if the listener is signaled an the bean is changed
    model.beginEditing();
    assertTrue(model.isEditing());
    guiBean = model.getValue();
    assertEquals(1, bean.testfield1);
    assertEquals(2, bean.testfield2);
    guiBean.testfield1 = 100;
    assertTrue(model.isDirty());
    model.commit();
    assertFalse(model.isEditing());
    Mockito.verify(listenerMock, Mockito.never()).modelRolledBack(model);
    Mockito.verify(listenerMock, Mockito.only()).modelCommittedWithChanges(model);
    Mockito.verify(listenerMock, Mockito.never()).modelCommittedNoChanges(model);
    //    Mockito.verify(listenerMock, Mockito.atLeastOnce()).modelCommittedWithChanges(
    //        any(TestBean.class));
    assertEquals(100, bean.testfield1);
    assertEquals(2, bean.testfield2);
  }

  @Test
  public void unchangedCopiedFieldIsHandled() {
    // change field that is addressed my CopyManager, change back to itrs original value
    // and test if the correct listener is signaled
    model.beginEditing();
    assertTrue(model.isEditing());
    guiBean = model.getValue();
    assertEquals(1, bean.testfield1);
    assertEquals(2, bean.testfield2);
    guiBean.testfield1 = 100;
    assertTrue(model.isDirty());
    guiBean.testfield1 = 1;
    assertFalse(model.isDirty());
    model.commit();
    assertFalse(model.isEditing());
    Mockito.verify(listenerMock, Mockito.never()).modelRolledBack(model);
    Mockito.verify(listenerMock, Mockito.never()).modelCommittedWithChanges(model);
    Mockito.verify(listenerMock, Mockito.only()).modelCommittedNoChanges(model);
    //    Mockito.verify(listenerMock, Mockito.atLeastOnce()).modelCommittedWithChanges(
    //        any(TestBean.class));
    assertEquals(1, bean.testfield1);
    assertEquals(2, bean.testfield2);
  }

}
