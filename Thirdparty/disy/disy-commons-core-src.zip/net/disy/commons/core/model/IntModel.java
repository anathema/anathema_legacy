//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

// NOT_PUBLISHED
public class IntModel extends AbstractChangeableModel {

  private int value;

  public IntModel() {
    this(0);
  }

  public IntModel(int value) {
    this.value = value;
  }

  public int getValue() {
    return value;
  }

  public void setValue(int value) {
    if (this.value == value) {
      return;
    }
    this.value = value;
    fireChangeEvent();
  }
}