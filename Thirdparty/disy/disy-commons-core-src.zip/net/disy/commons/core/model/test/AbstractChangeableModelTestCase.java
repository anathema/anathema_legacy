//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.model.test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.ISimpleBlock;

import com.mockobjects.ExpectationCounter;
import com.mockobjects.MockObject;

// NOT_PUBLISHED
public abstract class AbstractChangeableModelTestCase extends CoreTestCase {

  protected final void assertFiresChangeEvents(
      IChangeableModel model,
      int expectedCalls,
      ISimpleBlock closure) {
    CountingChangeListener countingChangeListener = new CountingChangeListener(expectedCalls);
    model.addChangeListener(countingChangeListener);
    closure.execute();
    countingChangeListener.verify();
    model.removeChangeListener(countingChangeListener);
  }

  private static class CountingChangeListener extends MockObject implements ChangeListener {
    private ExpectationCounter stateChangedCalls = new ExpectationCounter(
        "calls to stateChanged(ChangeEvent)"); //$NON-NLS-1$

    public CountingChangeListener(int expectedCalls) {
      stateChangedCalls.setExpected(expectedCalls);
    }

    public void stateChanged(ChangeEvent e) {
      stateChangedCalls.inc();
    }
  }

  protected final void assertChangeListenerCount(
      AbstractChangeableModel model,
      int expectedChangeListenerCount) {
    assertEquals("Wrong number of ChangeListeners in model.", expectedChangeListenerCount, model //$NON-NLS-1$
        .getChangeListenerCount());
  }
}