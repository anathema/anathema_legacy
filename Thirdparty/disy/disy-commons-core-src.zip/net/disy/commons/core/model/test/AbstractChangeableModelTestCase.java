/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import static org.easymock.EasyMock.*;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.IExceptionThrowingBlock;

public abstract class AbstractChangeableModelTestCase extends CoreTestCase {

  protected final void assertFiresChangeEvents(
      final IChangeableModel model,
      final int expectedCalls,
      final IExceptionThrowingBlock<RuntimeException> closure) {
    final IChangeListener changeListener = createStrictMock(IChangeListener.class);
    if (expectedCalls > 0) {
      changeListener.stateChanged();
      expectLastCall().times(expectedCalls);
    }
    replay(changeListener);
    model.addChangeListener(changeListener);
    closure.execute();
    verify(changeListener);
    model.removeChangeListener(changeListener);
  }

  public final static void assertChangeListenerCount(
      final AbstractChangeableModel model,
      final int expectedChangeListenerCount) {
    assertEquals("Wrong number of ChangeListeners in model.", expectedChangeListenerCount, model //$NON-NLS-1$
        .getChangeListenerCount());
  }
}