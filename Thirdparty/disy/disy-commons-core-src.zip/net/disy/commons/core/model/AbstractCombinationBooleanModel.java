/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;

public abstract class AbstractCombinationBooleanModel implements IBooleanModel {

  private final IBooleanModel firstModel;
  private final IBooleanModel secondModel;

  public AbstractCombinationBooleanModel(
      final IBooleanModel firstModel,
      final IBooleanModel secondModel) {
    Ensure.ensureArgumentNotNull(firstModel);
    Ensure.ensureArgumentNotNull(secondModel);
    this.firstModel = firstModel;
    this.secondModel = secondModel;

  }

  @Override
  public boolean getValue() {
    final boolean firstValue = firstModel.getValue();
    final boolean secondValue = secondModel.getValue();
    return combine(firstValue, secondValue);
  }

  protected abstract boolean combine(final boolean firstValue, final boolean secondValue);

  @Override
  public void addChangeListener(final IChangeListener listener) {
    firstModel.addChangeListener(listener);
    secondModel.addChangeListener(listener);
  }

  @Override
  public void removeChangeListener(final IChangeListener listener) {
    firstModel.removeChangeListener(listener);
    secondModel.removeChangeListener(listener);
  }

}
