//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class WeakListenerList {

  private final List weakListeners;

  public WeakListenerList() {
    this(new ArrayList());
  }

  private WeakListenerList(List weakListeners) {
    Ensure.ensureArgumentNotNull(weakListeners);
    this.weakListeners = weakListeners;
  }

  public synchronized void add(Object listener) {
    Ensure.ensureArgumentNotNull(listener);
    WeakReference weakListener = new WeakReference(listener);
    weakListeners.add(weakListener);
  }

  public synchronized void remove(Object listener) {
    Ensure.ensureArgumentNotNull(listener);
    for (Iterator iter = weakListeners.iterator(); iter.hasNext();) {
      WeakReference weakListener = (WeakReference) iter.next();
      Object currentListener = weakListener.get();
      if (currentListener == null) {
        iter.remove();
      }
      else {
        if (currentListener == listener) {
          iter.remove();
          return;
        }
      }
    }
    //Ignore quietly, that this listener was not in this list
  }

  public void forAllDo(IListenerClosure closure) {
    List activeListeners;
    synchronized (this) {
      activeListeners = new ArrayList(weakListeners.size());
      for (Iterator iter = weakListeners.iterator(); iter.hasNext();) {
        WeakReference weakListener = (WeakReference) iter.next();
        Object currentListener = weakListener.get();
        if (currentListener == null) {
          iter.remove();
        }
        else {
          activeListeners.add(currentListener);
        }
      }
    }
    for (Iterator iter = activeListeners.iterator(); iter.hasNext();) {
      Object element = iter.next();
      closure.execute(element);
    }
  }

  public synchronized WeakListenerList getClone() {
    return new WeakListenerList(new ArrayList(weakListeners));
  }
}