//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class WeakListenerList<L> {

  private final List<WeakReference<L>> weakListeners;

  public WeakListenerList() {
    this(new ArrayList<WeakReference<L>>());
  }

  private WeakListenerList(List<WeakReference<L>> weakListeners) {
    Ensure.ensureArgumentNotNull(weakListeners);
    this.weakListeners = weakListeners;
  }

  public synchronized void add(L listener) {
    Ensure.ensureArgumentNotNull(listener);
    WeakReference<L> weakListener = new WeakReference<L>(listener);
    weakListeners.add(weakListener);
  }

  public synchronized void remove(Object listener) {
    Ensure.ensureArgumentNotNull(listener);
    for (Iterator<WeakReference<L>> iter = weakListeners.iterator(); iter.hasNext();) {
      WeakReference<L> weakListener = iter.next();
      Object currentListener = weakListener.get();
      if (currentListener == null) {
        iter.remove();
      }
      else {
        if (currentListener == listener) {
          iter.remove();
          return;
        }
      }
    }
    //Ignore quietly, that this listener was not in this list
  }

  public void forAllDo(IListenerClosure<L> closure) {
    ArrayList<L> activeListeners;
    synchronized (this) {
      activeListeners = new ArrayList<L>(weakListeners.size());
      for (Iterator<WeakReference<L>> iter = weakListeners.iterator(); iter.hasNext();) {
        L currentListener = iter.next().get();
        if (currentListener == null) {
          iter.remove();
        }
        else {
          activeListeners.add(currentListener);
        }
      }
    }
    for (L element : activeListeners) {
      closure.execute(element);
    }
  }

  public synchronized WeakListenerList<L> getClone() {
    return new WeakListenerList<L>(new ArrayList<WeakReference<L>>(weakListeners));
  }
}