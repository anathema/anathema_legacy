/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.listener;

import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;

public class WeakListenerList<L> {

  private final List<WeakReference<L>> weakListeners;

  public WeakListenerList() {
    this(new ArrayList<WeakReference<L>>());
  }

  private WeakListenerList(final List<WeakReference<L>> weakListeners) {
    Ensure.ensureArgumentNotNull(weakListeners);
    this.weakListeners = weakListeners;
  }

  public synchronized void add(final L listener) {
    Ensure.ensureArgumentNotNull(listener);
    final WeakReference<L> weakListener = new WeakReference<L>(listener);
    weakListeners.add(weakListener);
  }

  public synchronized void remove(final Object listener) {
    Ensure.ensureArgumentNotNull(listener);
    for (final Iterator<WeakReference<L>> iter = weakListeners.iterator(); iter.hasNext();) {
      final WeakReference<L> weakListener = iter.next();
      final Object currentListener = weakListener.get();
      if (currentListener == null) {
        iter.remove();
      }
      else {
        if (currentListener == listener) {
          iter.remove();
          return;
        }
      }
    }
    //Ignore quietly, that this listener was not in this list
  }

  public void forAllDo(final IClosure<L> closure) {
    ArrayList<L> activeListeners;
    synchronized (this) {
      activeListeners = new ArrayList<L>(weakListeners.size());
      for (final Iterator<WeakReference<L>> iter = weakListeners.iterator(); iter.hasNext();) {
        final L currentListener = iter.next().get();
        if (currentListener == null) {
          iter.remove();
        }
        else {
          activeListeners.add(currentListener);
        }
      }
    }
    for (final L element : activeListeners) {
      closure.execute(element);
    }
  }

  public synchronized WeakListenerList<L> getClone() {
    return new WeakListenerList<L>(new ArrayList<WeakReference<L>>(weakListeners));
  }
}