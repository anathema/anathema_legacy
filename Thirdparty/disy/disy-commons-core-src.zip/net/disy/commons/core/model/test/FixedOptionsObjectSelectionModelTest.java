/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.core.util.SimpleBlock;

public class FixedOptionsObjectSelectionModelTest extends AbstractChangeableModelTestCase {

  private FixedOptionsObjectSelectionModel<String> model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new FixedOptionsObjectSelectionModel<String>(new String[]{ "Red", "Black" }); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testSetSelectedValue() {
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelectedValue("Red"); //$NON-NLS-1$
      }
    });
    assertEquals("Red", model.getFirstSelectedValue()); //$NON-NLS-1$
    assertEquals(1, model.getSelectedValues().size());

    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelectedValue("Black"); //$NON-NLS-1$
      }
    });
    assertSame("Black", model.getFirstSelectedValue()); //$NON-NLS-1$
    assertEquals(1, model.getSelectedValues().size());
  }

  public void testSetSelectedValueFiresNoEventOnNoChange() {
    model.setSelectedValue("Red"); //$NON-NLS-1$
    assertFiresChangeEvents(model, 0, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelectedValue("Red"); //$NON-NLS-1$
      }
    });
  }

  public void testSetSelectedValueToNull() {
    assertFiresChangeEvents(model, 0, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelectedValue(null);
      }
    });
    assertNull(model.getFirstSelectedValue());
  }

  public void testSetSelectedValueToNullFiresChangeEvent() {
    model.setSelectedValue("Red"); //$NON-NLS-1$
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelectedValue(null);
      }
    });
    assertNull(model.getFirstSelectedValue());
  }
}