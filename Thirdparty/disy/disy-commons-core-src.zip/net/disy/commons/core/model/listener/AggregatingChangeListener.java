/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.listener;

import net.disy.commons.core.util.IBlock;

public class AggregatingChangeListener implements IChangeListener {
  private boolean changed = false;

  @Override
  public synchronized void stateChanged() {
    changed = true;
  }

  public synchronized void executeIfChanged(IBlock block) {
    if (checkAndClearChangedState()) {
      block.execute();
    }
  }

  public synchronized boolean checkAndClearChangedState() {
    boolean oldChanged = changed;
    changed = false;
    return oldChanged;
  }
}
