// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model.test;


import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.core.util.ISimpleBlock;

//NOT_PUBLISHED
public class ObjectSelectionModelTest extends AbstractChangeableModelTestCase {
  private ObjectSelectionModel<String> model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new ObjectSelectionModel<String>();
  }
  
  public void testEmpty() throws Exception {
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }
  
  public void testSingleSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    assertTrue(model.isSelected("string")); //$NON-NLS-1$
    assertFalse(model.isSelected("foo")); //$NON-NLS-1$
  }
  
  public void testDeSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    model.setSelected("string", false); //$NON-NLS-1$
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }
  
  public void testFiresEvent() throws Exception {
    assertFiresChangeEvents(model, 1, new ISimpleBlock() {
      public void execute() {
        model.setSelected("string", true); //$NON-NLS-1$
      }
    });
    assertFiresChangeEvents(model, 1, new ISimpleBlock() {
      public void execute() {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }
  
  public void testNoChangeNoEvent() throws Exception {
    assertFiresChangeEvents(model, 0, new ISimpleBlock() {
      public void execute() {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }
}