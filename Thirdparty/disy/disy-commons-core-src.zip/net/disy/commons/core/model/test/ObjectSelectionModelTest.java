/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.core.util.SimpleBlock;

public class ObjectSelectionModelTest extends AbstractChangeableModelTestCase {
  private ObjectSelectionModel<String> model;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    model = new ObjectSelectionModel<String>();
  }

  public void testEmpty() throws Exception {
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }

  public void testSingleSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    assertTrue(model.isSelected("string")); //$NON-NLS-1$
    assertFalse(model.isSelected("foo")); //$NON-NLS-1$
  }

  public void testDeSelection() throws Exception {
    model.setSelected("string", true); //$NON-NLS-1$
    model.setSelected("string", false); //$NON-NLS-1$
    assertFalse(model.isSelected("string")); //$NON-NLS-1$
  }

  public void testFiresEvent() throws Exception {
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelected("string", true); //$NON-NLS-1$
      }
    });
    assertFiresChangeEvents(model, 1, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }

  public void testNoChangeNoEvent() throws Exception {
    assertFiresChangeEvents(model, 0, new SimpleBlock() {
      @Override
      public void execute() {
        model.setSelected("string", false); //$NON-NLS-1$
      }
    });
  }
}