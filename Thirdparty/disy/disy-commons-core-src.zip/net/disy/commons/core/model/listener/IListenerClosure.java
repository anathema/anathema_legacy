//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

// NOT_PUBLISHED
public interface IListenerClosure {
  public void execute(Object input);
}