//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.model.listener;

// NOT_PUBLISHED
public interface IListenerClosure<L> {
  public void execute(L listener);
}