//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.ListenerList;

// NOT_PUBLISHED
public abstract class AbstractChangeableModel implements Cloneable, IChangeableModel {

  private transient ListenerList listeners = new ListenerList();

  protected Object clone() {
    try {
      AbstractChangeableModel clone = (AbstractChangeableModel) super.clone();
      clone.listeners = new ListenerList();
      return clone;
    }
    catch (CloneNotSupportedException e) {
      throw new UnreachableCodeReachedException(e);
    }
  }

  public void addChangeListener(ChangeListener listener) {
    listeners.add(listener);
  }

  public void removeChangeListener(ChangeListener listener) {
    listeners.remove(listener);
  }

  protected void fireChangeEvent() {
    final ChangeEvent event = new ChangeEvent(this);
    listeners.forAllDo(new IListenerClosure() {
      public void execute(Object input) {
        ChangeListener listener = (ChangeListener) input;
        listener.stateChanged(event);
      }
    });
  }
}