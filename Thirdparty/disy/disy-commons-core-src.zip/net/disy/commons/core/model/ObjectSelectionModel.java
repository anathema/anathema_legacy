// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import java.util.HashSet;
import java.util.Set;

//NOT_PUBLISHED
public class ObjectSelectionModel<T> extends AbstractChangeableModel {

  private final Set<T> selectedValues = new HashSet<T>();

  public final void setSelected(T value, boolean selected) {
    if (selected == isSelected(value)) {
      return;
    }
    if (selected) {
      selectedValues.add(value);
    }
    else {
      selectedValues.remove(value);
    }
    fireChangeEvent();
  }

  public final boolean isSelected(T value) {
    return selectedValues.contains(value);
  }

  protected Set<T> getSelectedValuesSet() {
    return selectedValues;
  }
  
}