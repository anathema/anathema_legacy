/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class ObjectSelectionModel<T> extends AbstractChangeableModel {

  private final Set<T> selectedValues = new HashSet<T>();

  public final void setSelected(final T value, final boolean selected) {
    if (selected == isSelected(value)) {
      return;
    }
    if (selected) {
      selectedValues.add(value);
    }
    else {
      selectedValues.remove(value);
    }
    fireChangeEvent();
  }

  public final boolean isSelected(final T value) {
    return selectedValues.contains(value);
  }

  protected Set<T> getSelectedValuesSet() {
    return selectedValues;
  }

  public boolean isEmpty() {
    return selectedValues.isEmpty();
  }

  public Set<T> getAsSet() {
    return Collections.unmodifiableSet(getSelectedValuesSet());
  }

  public void clear() {
    selectedValues.clear();
    fireChangeEvent();
  }
}