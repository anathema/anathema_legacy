// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.model;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;

//NOT_PUBLISHED
public class ObjectSelectionModel extends AbstractChangeableModel {
  private final Object[] allValues;
  private Set values = new HashSet();
  
  public ObjectSelectionModel(Object[] allValues) {
    this.allValues = allValues;
  }

  public void setValues(Object[] values) {
    HashSet newValues = new HashSet(Arrays.asList(values));
    if (newValues.equals(this.values)) {
      return;
    }
    
    this.values = newValues;
    fireChangeEvent();
  }

  public Object getFirstValue() {
    return ArrayUtilities.getFirst(allValues, getPredicate());
  }

  public Object[] getValues() {
    return ArrayUtilities.filter(allValues, getPredicate());
  }

  private IPredicate getPredicate() {
    return new IPredicate() {
      public boolean evaluate(Object input) {
        return values.contains(input);
      }
    };
  }

  public int[] getSelectedIndices() {
    return ArrayUtilities.getIndices(getValues(), allValues);
  }
}