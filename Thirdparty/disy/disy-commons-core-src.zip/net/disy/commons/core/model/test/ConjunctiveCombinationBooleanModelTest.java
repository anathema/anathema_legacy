/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.model.test;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.ConjunctiveCombinationBooleanModel;
import net.disy.commons.core.model.IBooleanModel;
import net.disy.commons.core.util.SimpleBlock;

import org.junit.Test;

public class ConjunctiveCombinationBooleanModelTest extends AbstractChangeableModelTestCase {

  @Test
  public void testTrueTrueEqualsTrue() {
    final boolean result = new ConjunctiveCombinationBooleanModel(
        new BooleanModel(true),
        new BooleanModel(true)).getValue();
    assertTrue(result);
  }

  @Test
  public void testTrueFalseEqualsFalse() {
    final boolean result = new ConjunctiveCombinationBooleanModel(
        new BooleanModel(true),
        new BooleanModel(false)).getValue();
    assertFalse(result);
  }

  @Test
  public void testFalseTrueEqualsFalse() {
    final boolean result = new ConjunctiveCombinationBooleanModel(
        new BooleanModel(false),
        new BooleanModel(true)).getValue();
    assertFalse(result);
  }

  @Test
  public void testFalseFalseEqualsFalse() {
    final boolean result = new ConjunctiveCombinationBooleanModel(
        new BooleanModel(false),
        new BooleanModel(false)).getValue();
    assertFalse(result);
  }

  @Test
  public void testFireChangeEvent() {
    final BooleanModel firstModel = new BooleanModel();
    final BooleanModel secondModel = new BooleanModel();
    final IBooleanModel combinationModel = new ConjunctiveCombinationBooleanModel(
        firstModel,
        secondModel);
    assertFiresChangeEvents(combinationModel, 2, new SimpleBlock() {

      @Override
      public void execute() throws RuntimeException {
        firstModel.setValue(true);
        secondModel.setValue(true);
      }
    });
  }
}
