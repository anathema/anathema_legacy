// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 25.08.2005
package net.disy.commons.core.model;

// NOT_PUBLISHED
public class StringModel extends ObjectModel<String> {

  public StringModel() {
    this(null);
  }

  public StringModel(String value) {
    super(value);
  }
}