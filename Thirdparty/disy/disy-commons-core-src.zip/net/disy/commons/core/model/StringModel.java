// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 25.08.2005
package net.disy.commons.core.model;

import net.disy.commons.core.util.ObjectUtilities;

// NOT_PUBLISHED
public class StringModel extends AbstractChangeableModel {

  private String value;

  public StringModel() {
    this(null);
  }

  public StringModel(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    if (ObjectUtilities.equals(this.value, value)) {
      return;
    }
    this.value = value;
    fireChangeEvent();
  }
}