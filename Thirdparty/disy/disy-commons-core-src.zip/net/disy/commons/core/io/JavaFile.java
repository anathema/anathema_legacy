/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ITransformer;

public class JavaFile extends AbstractFile {

  public static final class PredicateFileFilter implements FileFilter {
    private final IPredicate<IFile> predicate;

    public PredicateFileFilter(final IPredicate<IFile> predicate) {
      this.predicate = predicate;
    }

    @Override
    public boolean accept(final File pathname) {
      return predicate.evaluate(new JavaFile(pathname));
    }
  }

  private final File file;

  public JavaFile(final File file) {
    Ensure.ensureNotNull("Cannot wrap around null.", file); //$NON-NLS-1$
    this.file = file;
  }

  @Override
  @Deprecated
  public File getFile() {
    return file;
  }

  @Override
  public String toString() {
    return file.getAbsolutePath();
  }

  @Override
  public boolean mkDirs() {
    return file.mkdirs();
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof JavaFile)) {
      return false;
    }
    return ((JavaFile) obj).file.equals(file);
  }

  @Override
  public int hashCode() {
    return file.hashCode() * 3;
  }

  @Override
  public boolean exists() {
    return file.exists();
  }

  @Override
  public IFile getChild(final String child) {
    final File childFile = new File(getFile(), child);
    return new JavaFile(childFile);
  }

  @Override
  public IFile[] getChildren(final IPredicate<IFile> predicate) {
    return listFiles(new PredicateFileFilter(predicate));
  }

  @Override
  public String getAbsolutePath() {
    return file.getAbsolutePath();
  }

  @Override
  public String getName() {
    return file.getName();
  }

  @Deprecated
  @Override
  public IFile[] listFiles(final FileFilter fileFilter) {
    final File[] files = file.listFiles(fileFilter);
    if (files == null) {
      return new IFile[0];
    }
    return ArrayUtilities.transform(files, IFile.class, new ITransformer<File, IFile>() {
      @Override
      public IFile transform(final File input) {
        return new JavaFile(input);
      }
    });
  }

  @Override
  public boolean isDirectory() {
    return file.isDirectory();
  }

  @Override
  public OutputStream createOutputStream() throws FileNotFoundException {
    return new FileOutputStream(file);
  }

  @Override
  public Reader createReader() throws FileNotFoundException {
    return new FileReader(file);
  }

  @Override
  public void createNew() throws IOException {
    if (!file.getParentFile().exists()) {
      file.getParentFile().mkdirs();
    }
    file.createNewFile();
  }

  @Override
  public InputStream openInputStream() throws FileNotFoundException {
    return new FileInputStream(file);
  }

  @Override
  public void delete() {
    file.delete();
  }

  @Override
  public void rename(final String newName) {
    file.renameTo(new File(file.getParent(), newName));
  }

  @Override
  public void setContent(InputStream content) throws IOException {
    OutputStream outputStream = null;
    try {
      outputStream = createOutputStream();
      IOUtilities.copyStream(content, outputStream);
    }
    finally {
      IOUtilities.close(outputStream);
    }
  }
}