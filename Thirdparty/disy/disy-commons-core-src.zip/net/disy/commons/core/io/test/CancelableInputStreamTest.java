/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InterruptedIOException;

import net.disy.commons.core.io.CancelableInputStream;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.NonCancelable;
import net.disy.commons.core.testing.CoreTestCase;

public class CancelableInputStreamTest extends CoreTestCase {

  public void testReadUncanceled() throws IOException {
    final ByteArrayInputStream stream = new ByteArrayInputStream(new byte[]{
        9,
        8,
        7,
        6,
        5,
        4,
        3,
        2,
        1 });
    final CancelableInputStream inputStream = new CancelableInputStream(
        NonCancelable.getInstance(),
        stream);
    assertEquals(9, inputStream.read());
    final byte[] bytes = new byte[2];
    inputStream.read(bytes);
    assertEquals(8, bytes[0]);
    assertEquals(7, bytes[1]);
    inputStream.skip(1);
    assertEquals(5, inputStream.read());
  }

  public void testReadCanceled() throws IOException {
    final ByteArrayInputStream stream = new ByteArrayInputStream(new byte[]{
        9,
        8,
        7,
        6,
        5,
        4,
        3,
        2,
        1 });
    final CancelableInputStream inputStream = new CancelableInputStream(new ICancelable() {
      @Override
      public boolean isCanceled() {
        return true;
      }
    }, stream);
    try {
      inputStream.read();
      fail();
    }
    catch (final InterruptedIOException expected) {
      //expected
    }
    try {
      inputStream.skip(2);
      fail();
    }
    catch (final InterruptedIOException expected) {
      //expected
    }
    try {
      inputStream.read(new byte[2]);
      fail();
    }
    catch (final InterruptedIOException expected) {
      //expected
    }
  }
}