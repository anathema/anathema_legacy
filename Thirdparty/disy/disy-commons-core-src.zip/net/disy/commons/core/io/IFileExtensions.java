/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

public interface IFileExtensions {

  public static final String BMP = "bmp"; //$NON-NLS-1$
  public static final String DBF = "dbf"; //$NON-NLS-1$
  public static final String JAR = "jar"; //$NON-NLS-1$
  public static final String JPEG = "jpeg"; //$NON-NLS-1$
  public static final String JPG = "jpg"; //$NON-NLS-1$
  public static final String KEY = "key"; //$NON-NLS-1$
  public static final String GIF = "gif"; //$NON-NLS-1$
  public static final String MAP = "map"; //$NON-NLS-1$
  public static final String MDB = "mdb"; //$NON-NLS-1$
  public static final String PDF = "pdf"; //$NON-NLS-1$
  public static final String PNG = "png"; //$NON-NLS-1$
  public static final String PRJ = "prj"; //$NON-NLS-1$
  public static final String SHP = "shp"; //$NON-NLS-1$
  public static final String SHX = "shx"; //$NON-NLS-1$
  public static final String TIF = "tif"; //$NON-NLS-1$
  public static final String TIFF = "tiff"; //$NON-NLS-1$
  public static final String ZIP = "zip"; //$NON-NLS-1$

}
