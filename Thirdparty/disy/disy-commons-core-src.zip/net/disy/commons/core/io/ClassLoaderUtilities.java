/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.jar.Attributes;
import java.util.jar.JarInputStream;
import java.util.jar.Manifest;

import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.ITransformer;

public class ClassLoaderUtilities {

  private static Map<URI, Manifest> manifests = new HashMap<URI, Manifest>();

  public static void addToClassPath(final ClassLoader classLoader, final String name)
      throws IOException {
    addToClassPath(classLoader, new File(name));
  }

  public static void addToClassPath(final ClassLoader classLoader, final File path)
      throws IOException {
    if (path.isDirectory()) {
      final File[] files = listJarFiles(path);
      if (files.length != 0) {
        for (final File file : files) {
          addToClassPath(classLoader, file);
        }
        return;
      }
    }
    addToClassPath(classLoader, path.toURI().toURL());
  }

  private static File[] listJarFiles(final File path) {
    final File[] files = path.listFiles(new FileFilter() {

      @Override
      public boolean accept(final File file) {
        if (file.isDirectory()) {
          return false;
        }
        final String extension = FileUtilities.getExtension(file);
        return IFileExtensions.JAR.equalsIgnoreCase(extension)
            || IFileExtensions.ZIP.equalsIgnoreCase(extension);
      }
    });
    return files;
  }

  @SuppressWarnings("unchecked")
  public static void addToClassPath(final ClassLoader classLoader, final URL url)
      throws IOException {
    if (!(classLoader instanceof URLClassLoader)) {
      throw new IOException("Error, could not add URL to system classloader"); //$NON-NLS-1$
    }
    final URLClassLoader sysloader = (URLClassLoader) classLoader;
    final Class sysclass = URLClassLoader.class;
    try {
      final Class[] parameters = new Class[]{ URL.class };
      final Method method = sysclass.getDeclaredMethod("addURL", parameters); //$NON-NLS-1$
      method.setAccessible(true);
      method.invoke(sysloader, new Object[]{ url });
    }
    catch (final Throwable t) {
      throw new IOException("Error, could not add URL to system classloader", t); //$NON-NLS-1$
    }
  }

  public static String getClassPath(final ClassLoader classLoader) {
    final URI[] classPathList = getClassPathUris(classLoader);
    String classPath = ""; //$NON-NLS-1$
    for (final URI url : classPathList) {
      classPath += " " + url.toString(); //$NON-NLS-1$
    }
    return classPath;
  }

  public static Manifest getManifest(final URI uri) {
    if (uri == null) {
      return null;
    }
    Manifest manifest;
    if ((manifest = manifests.get(uri)) != null) {
      return manifest;
    }
    InputStream inputStream = null;
    try {
      inputStream = uri.toURL().openStream();
      final JarInputStream jarInputStream = new JarInputStream(inputStream);
      if ((manifest = jarInputStream.getManifest()) != null) {
        manifests.put(uri, manifest);
      }
      return manifest;
    }
    catch (final IOException exception) {
      return null;
    }
    finally {
      IOUtilities.close(inputStream);
    }
  }

  public static URI[] getLibraries(final Manifest manifest, final String parent) {
    final String classPath = getClassPath(manifest);
    if (classPath == null) {
      return new URI[0];
    }
    final List<URI> urls = new ArrayList<URI>();
    final StringTokenizer stringTokenizer = new StringTokenizer(classPath, " "); //$NON-NLS-1$
    while (stringTokenizer.hasMoreTokens()) {
      final String string = stringTokenizer.nextToken();
      try {
        final URI uri = new URI(string);
        if (!uri.isAbsolute()) {
          try {
            final File file = new File(new File(parent == null
                ? System.getProperty("user.dir") : parent), string); //$NON-NLS-1$
            urls.add(file.getCanonicalFile().toURI());
          }
          catch (final IOException exception) {
            urls.add(new URI(string));
          }
          continue;
        }
        if ("file".equalsIgnoreCase(uri.getScheme())) { //$NON-NLS-1$
          try {
            urls.add(new File(uri).getCanonicalFile().toURI());
          }
          catch (final IOException exception) {
            urls.add(new URI(string));
          }
          continue;
        }
        urls.add(uri);
      }
      catch (final URISyntaxException e) {
        // nothing to do
      }
    }
    return urls.toArray(new URI[urls.size()]);
  }

  private static String getClassPath(final Manifest manifest) {
    if (manifest == null) {
      return null;
    }
    final Attributes attributes = manifest.getMainAttributes();
    final String classPath = attributes.getValue("Class-Path"); //$NON-NLS-1$
    if (classPath == null) {
      return null;
    }
    return classPath;
  }

  public static URI[] getClassPathUris(final ClassLoader classLoader) {
    if (!(classLoader instanceof URLClassLoader)) {
      return new URI[0];
    }
    final URLClassLoader sysloader = (URLClassLoader) classLoader;
    final URI[] classPathList = ArrayUtilities.transform(
        sysloader.getURLs(),
        URI.class,
        new ITransformer<URL, URI>() {

          @Override
          public URI transform(final URL input) {
            try {
              return input.toURI();
            }
            catch (final URISyntaxException exception) {
              return null;
            }
          }
        });
    return classPathList;
  }

  public static URI[] getLibraries(final ClassLoader classLoader) {
    final URI[] classPathUrls = getClassPathUris(classLoader);
    if (classPathUrls.length == 0) {
      return classPathUrls;
    }
    final List<URI> libraryList = new ArrayList<URI>();
    for (final URI url : classPathUrls) {
      final String string = url.toString();
      final int length = string.length();
      if (string.substring(length - 4 < 0 ? 0 : length - 4, length).equalsIgnoreCase(
          "." + IFileExtensions.JAR)) { //$NON-NLS-1$
        libraryList.add(url);
      }
    }
    final List<URI> subLibraryList = new ArrayList<URI>();
    for (final URI uri : libraryList) {
      final Manifest manifest = getManifest(uri);
      if (manifest == null) {
        continue;
      }
      final URI[] classPaths = getLibraries(manifest, getParent(uri));
      for (final URI classPath : classPaths) {
        if (libraryList.contains(classPath)) {
          continue;
        }
        if (classPath.isAbsolute()
            && "file".equalsIgnoreCase(classPath.getScheme()) && !new File(classPath).exists()) { //$NON-NLS-1$
          continue;
        }
        subLibraryList.add(classPath);
      }
    }
    libraryList.addAll(subLibraryList);
    return libraryList.toArray(new URI[libraryList.size()]);
  }

  public static String getParent(final URI uri) {
    if (UriUtilities.isFile(uri)) {
      return new File(uri).getParent();
    }
    return null;
  }
}
