/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import static java.text.MessageFormat.format;
import static net.disy.commons.core.util.StringUtilities.endsWithIgnoreCase;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.regex.Pattern;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;

public class FileUtilities {

  private static IFileSystem fileSystem = new JavaFileSystem();

  protected FileUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static void deleteFileOrDirectory(final File file) throws IOException {
    if (!file.exists()) {
      return;
    }
    if (file.isDirectory()) {
      final File[] files = file.listFiles();
      for (final File file2 : files) {
        deleteFileOrDirectory(file2);
      }
    }
    if (!file.delete()) {
      throw new IOException("delete failed for file '" + file.getAbsolutePath() + "'"); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static String getExtension(final File file) {
    return getExtension(file.getName());
  }

  /**
   * Get extension from filename. ie
   *
   * <pre>
   *  foo.txt --&gt; &quot;txt&quot; a\b\c.jpg --&gt; &quot;jpg&quot; a\b\c --&gt; &quot;&quot; *
   * </pre>
   *
   * @param filename the filename
   * @return the extension of filename or "" if none
   */
  public static String getExtension(final String filename) {
    final int lastDot = filename.lastIndexOf('.');
    return lastDot >= 0 ? filename.substring(lastDot + 1) : ""; //$NON-NLS-1$
  }

  public static File addExtension(final File file, final String extension) {
    return new File(addExtension(file.getPath(), extension));
  }

  public static File changeExtensionTo(File file, String extension) {
    return addExtension(getWithoutExtension(file), extension);
  }

  public static String addExtension(final String fileName, final String fileNameExtension) {
    String extension = fileNameExtension;
    if (!extension.startsWith(".")) { //$NON-NLS-1$
      extension = "." + extension; //$NON-NLS-1$
    }
    if (!endsWithIgnoreCase(fileName, extension)) {
      return fileName + extension;
    }
    return fileName;
  }

  public static File createTempFile(final String prefix, final String postfix, final File directory)
      throws IOException {
    final JavaFile parentDirectory = directory == null ? null : new JavaFile(directory);
    return ((JavaFile) createTempFile(prefix, postfix, parentDirectory)).getFile();
  }

  public static IFile createTempFile(
      final String prefix,
      final String postfix,
      final IFile parentDirectory) throws IOException {
    IFile directory = parentDirectory;
    if (directory == null) {
      directory = fileSystem.getDefaultTempDir();
    }
    if (!directory.exists()) {
      final boolean directoriesCreated = directory.mkDirs();
      if (!directoriesCreated) {
        if (!directory.equals(fileSystem.getDefaultTempDir())) {
          try {
            return createTempFile(prefix, postfix, (IFile) null);
          }
          catch (final IOException e) {
            throw new IOException(
                "Could not create full path for temporary file: " + directory + '/' + prefix + '.' + postfix); //$NON-NLS-1$
          }
        }
        throw new IOException("Could not create temporary directory at: " + directory); //$NON-NLS-1$
      }
    }
    try {
      return fileSystem.createTempFile(prefix, postfix, directory);
    }
    catch (final IOException exception) {
      // workaround für nicht aussagekräftige IOExceptions von Sun (z.B. "permission denied" unter
      // Linux)
      throw new IOException(format("Could not create temp file in {0}: {1}", directory, exception //$NON-NLS-1$
          .getMessage()), exception);
    }
  }

  public static void setFileSystem(final IFileSystem fileSystem) {
    FileUtilities.fileSystem = fileSystem;
  }

  public static File createFileNameSuggestion(
      final IWorkingDirectoryProvider workingDirectoryProvider,
      final String fileName,
      final String fileExtension) {
    Ensure.ensureArgumentNotNull(workingDirectoryProvider);
    Ensure.ensureArgumentNotNull(fileName);
    Ensure.ensureArgumentNotNull(fileExtension);
    final File workingDirectory = workingDirectoryProvider.getWorkingDirectory();
    final File directory = workingDirectory == null ? new File(".") : workingDirectory; //$NON-NLS-1$
    return createNonExistingFile(directory, fileName, fileExtension);
  }

  public static File createNonExistingFile(
      final File directory,
      final String fileName,
      final String fileExtension) {
    Ensure.ensureArgumentNotNull(directory);
    Ensure.ensureArgumentNotNull(fileName);
    Ensure.ensureArgumentNotNull(fileExtension);
    File file = new File(directory, fileName + fileExtension);
    int index = 1;
    while (file.exists()) {
      file = new File(directory, fileName + index + fileExtension);
      ++index;
    }
    return file;
  }

  public static File getTempDir() {
    return fileSystem.getDefaultTempDir().getFile();
  }

  public static void createFileParent(final String fileName) throws IOException {
    createFileParent(new File(fileName));
  }

  private static void createFileParent(final File file) throws IOException {
    final File canonicalFile = file.getCanonicalFile();
    final File parent = canonicalFile.getParentFile();
    if (!parent.exists()) {
      parent.mkdirs();
    }
  }

  public static File getWithoutExtension(final File file) {
    final String fileName = file.getName();
    if (!fileName.contains(".")) { //$NON-NLS-1$
      return file;
    }
    final File parentFile = file.getParentFile();
    return new File(parentFile, fileName.substring(0, fileName.lastIndexOf("."))); //$NON-NLS-1$
  }

  public static String getFileName(final String path) {
    final int lastSlash = path.lastIndexOf("/"); //$NON-NLS-1$
    final int lastBackSlash = path.lastIndexOf("\\"); //$NON-NLS-1$
    final int lastColon = path.lastIndexOf(":"); //$NON-NLS-1$

    final int beginFileName = Math.max(Math.max(lastSlash, lastBackSlash), lastColon) + 1;
    return path.substring(beginFileName, path.length());
  }

  public static String createSystemNeutralPath(String path) {
    return path.replaceAll(Pattern.quote("\\"), "/"); //$NON-NLS-1$//$NON-NLS-2$
  }

  public static String getFileNameWithoutExtension(final String fileName) {
    final String extension = getExtension(fileName);
    if (extension.isEmpty()) {
      return fileName;
    }
    return fileName.substring(0, fileName.length() - extension.length() - 1);
  }

  public static boolean isReadable(final File file) {
    return file != null && file.canRead();
  }

  /** @deprecated as of 16.06.2010 (preuss), use {@link UrlUtilities#createUrl(URL, String)} instead */
  @Deprecated
  public static URL createUrl(URL baseUrl, String fileName) {
    return UrlUtilities.createUrl(baseUrl, fileName);
  }

  /**
   * Convert from a <code>URL</code> to a <code>File</code>.
   *
   * @param url File URL.
   * @return The equivalent <code>File</code> object, or <code>null</code> if the URL's protocol is
   *         not <code>file</code>
   */
  public static File toFile(URL url) {
    if (!UrlUtilities.isFileUrl(url)) {
      throw new IllegalArgumentException("URL \"" + url + "\" is no file URL"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    String filename;
    try {
      filename = URLDecoder.decode(url.getFile().replace('/', File.separatorChar), "UTF-8"); //$NON-NLS-1$
    }
    catch (final UnsupportedEncodingException e) {
      throw new UnreachableCodeReachedException("(ip)", e); //$NON-NLS-1$
    }
    final String authorization = url.getAuthority();
    if (authorization == null) {
      return new File(filename);
    }
    final String fileSeperator = String.valueOf(File.separatorChar);
    return new File(fileSeperator + fileSeperator + authorization + filename);
  }

  public static URL toUrl(File file) {
    try {
      return file.toURI().toURL();
    }
    catch (MalformedURLException e) {
      throw new UnreachableCodeReachedException(e);
    }
  }
}