/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.core.util.Ensure;

public class CancelableInputStream extends FilterInputStream {
  private final ICancelable cancelable;

  public CancelableInputStream(final ICancelable cancelable, final InputStream inputStream) {
    super(inputStream);
    Ensure.ensureArgumentNotNull(cancelable);
    this.cancelable = cancelable;
  }

  @Override
  public int read() throws IOException {
    ProgressUtilities.checkInterruptedIO(cancelable);
    return super.read();
  }

  @Override
  public int available() throws IOException {
    ProgressUtilities.checkInterruptedIO(cancelable);
    return super.available();
  }

  @Override
  public int read(final byte[] b) throws IOException {
    ProgressUtilities.checkInterruptedIO(cancelable);
    return super.read(b);
  }

  @Override
  public int read(final byte[] b, final int off, final int len) throws IOException {
    ProgressUtilities.checkInterruptedIO(cancelable);
    return super.read(b, off, len);
  }

  @Override
  public long skip(final long n) throws IOException {
    ProgressUtilities.checkInterruptedIO(cancelable);
    return super.skip(n);
  }
}