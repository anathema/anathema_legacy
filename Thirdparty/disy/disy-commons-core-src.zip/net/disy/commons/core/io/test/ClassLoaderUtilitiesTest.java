/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import java.io.File;
import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

import net.disy.commons.core.io.ClassLoaderUtilities;
import net.disy.commons.core.util.ArrayUtilities;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class ClassLoaderUtilitiesTest {

  private final class Contains<T> extends BaseMatcher<T> {

    private final T[] array;

    public Contains(final T[] array) {
      this.array = array;
    }

    @Override
    public void describeTo(final Description arg0) {
      // nothing to do
    }

    @Override
    public boolean matches(final Object value) {
      return ArrayUtilities.containsValue(this.array, value);
    }
  }

  private File jarFile;
  private File jarFolder;
  private URI jarFileUri;

  @Before
  public void setup() {
    this.jarFile = DummyJarProvider.getJar();
    this.jarFolder = this.jarFile.getParentFile();
    this.jarFileUri = this.jarFile.toURI();
  }

  @Test
  public void manifest() throws Exception {
    final Manifest manifest = createManifest(this.jarFileUri);
    assertTrue(manifest != null);
  }

  private Manifest createManifest(final URI manifestUri) {
    return ClassLoaderUtilities.getManifest(manifestUri);
  }

  private Manifest createManifest() {
    final Manifest manifest = new Manifest();
    final Attributes attributes = manifest.getMainAttributes();
    attributes.put(new Attributes.Name("Class-Path"), "lib/harry.jar lib/hirsch.jar"); //$NON-NLS-1$ //$NON-NLS-2$
    return manifest;
  }

  @Test
  public void libraries() throws Exception {
    final Manifest manifest = createManifest();
    final URI[] libraries = ClassLoaderUtilities.getLibraries(manifest, this.jarFolder.toString());
    assertTrue(libraries.length == 2);
    assertTrue("file".equals(libraries[0].getScheme())); //$NON-NLS-1$
  }

  @Test
  public void getParent() throws Exception {
    assertEquals(
        File.separator + "parent", ClassLoaderUtilities.getParent(new URI("file:/parent/child"))); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(null, ClassLoaderUtilities.getParent(new URI("parent/child"))); //$NON-NLS-1$ 
    assertEquals(null, ClassLoaderUtilities.getParent(new URI("http:/parent/child"))); //$NON-NLS-1$ 
  }

  @Test
  public void addFileToClassPath() throws IOException {
    final ClassLoader classLoader = new URLClassLoader(new URL[0]);
    ClassLoaderUtilities.addToClassPath(classLoader, this.jarFile);
    assertThat(this.jarFileUri, new Contains<URI>(ClassLoaderUtilities.getLibraries(classLoader)));
  }

  @Test
  public void addFolderToClassPath() throws IOException {
    final ClassLoader classLoader = new URLClassLoader(new URL[0]);
    ClassLoaderUtilities.addToClassPath(classLoader, this.jarFolder);
    final URI[] libraries = ClassLoaderUtilities.getLibraries(classLoader);
    assertThat(new File(this.jarFolder, "test.jar").toURI(), new Contains<URI>(libraries)); //$NON-NLS-1$
  }
}
