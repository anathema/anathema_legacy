/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;

import net.disy.commons.core.util.Ensure;

public class UriUtilities {

  public static boolean isFile(final URI uri) {
    try {
      return uri != null && new File(uri) != null;
    }
    catch (final IllegalArgumentException exception) {
      return false;
    }
  }

  public static URI changeExtensionTo(URI uri, String extension) throws URISyntaxException {
    final File pathFile = FileUtilities.changeExtensionTo(new File(uri.getPath()), extension);
    String path = pathFile == null ? "" : pathFile.getAbsolutePath(); //$NON-NLS-1$
    path = FileUtilities.createSystemNeutralPath(path);
    if (!path.startsWith("/")) { //$NON-NLS-1$
      path = "/" + path; //$NON-NLS-1$
    }
    return new URI(
        uri.getScheme(),
        uri.getUserInfo(),
        uri.getHost(),
        uri.getPort(),
        path,
        uri.getQuery(),
        uri.getFragment());
  }

  public static URI getWithoutExtension(final URI uri) throws URISyntaxException {
    String orgPath = uri.toString();
    String fileName = FileUtilities.getFileName(orgPath);
    String path = orgPath.substring(0, orgPath.length() - fileName.length());
    String fileWithOutExtension = FileUtilities.getFileNameWithoutExtension(fileName);
    return new URI(path + fileWithOutExtension);
  }

  public static boolean isAccessible(final URI uri) {
    Ensure.ensureArgumentNotNull(uri);
    try {
      if (isFile(uri)) {
        return FileUtilities.isReadable(new File(uri));
      }
      if (uri.getScheme() == null) {
        return FileUtilities.isReadable(new File(uri.getPath()));
      }
      return UrlUtilities.isAccessible(uri.toURL());
    }
    catch (final Throwable throwable) {
      return false;
    }
  }

  public static URI create(String string) throws URISyntaxException {
    final URI uri = new URI(FileUtilities.createSystemNeutralPath(string));
    if (uri.getScheme() != null) {
      return uri;
    }
    return new File(string).toURI();
  }

  public static URI adaptUserInfo(URI uri, String userInfo) throws URISyntaxException {
    return new URI(
        uri.getScheme(),
        userInfo,
        uri.getHost(),
        uri.getPort(),
        uri.getPath(),
        uri.getQuery(),
        uri.getFragment());
  }
}
