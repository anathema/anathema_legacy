/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

import net.disy.commons.core.io.FileUtilities;
import net.disy.commons.core.io.UrlUtilities;

import org.junit.Test;

@SuppressWarnings("nls")
public class UrlUtilitiesTest {
  private static final String URL_WITH_AUTHENTICATION = "http://user:pass@www.disy.net"; //$NON-NLS-1$

  @Test
  public void removeExtension() {
    final String externalForm = "http://www.disy.net/test"; //$NON-NLS-1$
    assertEquals(externalForm, UrlUtilities.removeExtension(externalForm));
    assertEquals(externalForm, UrlUtilities.removeExtension(externalForm + ".pdf")); //$NON-NLS-1$
  }

  @Test
  public void hasExtension() throws Exception {
    assertFalse(UrlUtilities.hasExtension("http://www.disy.net/test")); //$NON-NLS-1$
    assertTrue(UrlUtilities.hasExtension("http://www.disy.net/test.pdf")); //$NON-NLS-1$
  }

  @Test
  public void getPathWithoutProtocol() throws IOException {
    assertEquals(
        "www.disy.net", UrlUtilities.getPathWithoutProtocol(new URL("http://www.disy.net"))); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("bla.foo.bar", UrlUtilities.getPathWithoutProtocol(new URL("http://bla.foo.bar"))); //$NON-NLS-1$ //$NON-NLS-2$

    final File file = File.createTempFile("temp", ".tmp"); //$NON-NLS-1$ //$NON-NLS-2$
    try {
      assertEquals(file.getAbsolutePath(), UrlUtilities.getPathWithoutProtocol(file.toURL()));
    }
    finally {
      file.delete();
    }
  }

  @Test
  public void urlContainsAuthentication() throws Exception {
    assertFalse(UrlUtilities.containsAuthentication("www.disy.net")); //$NON-NLS-1$
    assertFalse(UrlUtilities.containsAuthentication("http://www.disy.net")); //$NON-NLS-1$
    assertFalse(UrlUtilities.containsAuthentication("http://pass@www.disy.net")); //$NON-NLS-1$
    assertFalse(UrlUtilities.containsAuthentication("http://:pass@www.disy.net")); //$NON-NLS-1$
    assertFalse(UrlUtilities.containsAuthentication("http://user:@www.disy.net")); //$NON-NLS-1$
    assertTrue(UrlUtilities.containsAuthentication(URL_WITH_AUTHENTICATION));
  }

  @Test
  public void getUsernameFromUrl() throws Exception {
    assertThat(UrlUtilities.getUserName(URL_WITH_AUTHENTICATION), is("user")); //$NON-NLS-1$
    assertThat(UrlUtilities.getUserName(URL_WITH_AUTHENTICATION), is(not("pass"))); //$NON-NLS-1$
  }

  @Test
  public void getPasswordFromUrl() throws Exception {
    assertThat(UrlUtilities.getPassword(URL_WITH_AUTHENTICATION), is("pass")); //$NON-NLS-1$
    assertThat(UrlUtilities.getPassword(URL_WITH_AUTHENTICATION), is(not("user"))); //$NON-NLS-1$
  }

  @Test
  public void fantasyUrlDoesNotExist() throws Exception {
    assertThat(UrlUtilities.exists(FileUtilities.toUrl(new File("C:/nichtda/"))), is(false)); //$NON-NLS-1$
    assertThat(UrlUtilities.exists(new URL("http://theUrlOfMyDreams:8080")), is(false)); //$NON-NLS-1$
  }

  @Test
  public void realUrlDoesNotExist() throws Exception {
    final File tempFile = File.createTempFile("egal", "is"); //$NON-NLS-1$ //$NON-NLS-2$
    tempFile.deleteOnExit();
    assertThat(UrlUtilities.exists(FileUtilities.toUrl(tempFile)), is(true));
  }

  @Test
  public void releasesHandleOnFile() throws Exception {
    final File tempFile = File.createTempFile("egal", "is"); //$NON-NLS-1$ //$NON-NLS-2$
    UrlUtilities.exists(FileUtilities.toUrl(tempFile));
    assertThat(tempFile.delete(), is(true));
  }

  @Test
  public void isFile() throws Throwable {
    assertTrue(UrlUtilities.isFile(new URL("file:/c:/test/test.dat"))); //$NON-NLS-1$
    assertFalse(UrlUtilities.isFile(null));
    assertFalse(UrlUtilities.isFile(new URL("http://test/test.dat"))); //$NON-NLS-1$
  }

  @Test
  public void stripJSessionId() throws Throwable {
    assertEquals(
        "http://disy.net/foo/bar",
        UrlUtilities.stripJSessionId("http://disy.net/foo/bar;jsessionid=hfdsjkhfsjkdh"));
    assertEquals("http://disy.net/foo/bar", UrlUtilities.stripJSessionId("http://disy.net/foo/bar"));
    assertEquals(
        "http://disy.net/foo/bar?foo=bar",
        UrlUtilities.stripJSessionId("http://disy.net/foo/bar;jsessionid=hfdsjkhfsjkdh?foo=bar"));
    assertEquals(
        "http://disy.net/foo/bar?foo=bar",
        UrlUtilities.stripJSessionId("http://disy.net/foo/bar?foo=bar"));
  }

  @Test
  public void testConcatPath() throws MalformedURLException, URISyntaxException {
    assertEquals(
        new URL("http://host/path/file"),
        UrlUtilities.concatPath(new URL("http://host/path"), "/file"));
    assertEquals(
        new URL("http://host/path/file"),
        UrlUtilities.concatPath(new URL("http://host/path/"), "/file"));
    assertEquals(
        new URL("http://host/path/file"),
        UrlUtilities.concatPath(new URL("http://host/path/"), "file"));
    assertEquals(
        new URL("http://host/path/file"),
        UrlUtilities.concatPath(new URL("http://host/path"), "file"));
    assertEquals(
        new URL("http://host/path/file?foo=bar"),
        UrlUtilities.concatPath(new URL("http://host/path?foo=bar"), "file"));
  }
}