/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import net.disy.commons.core.io.FileUtilities;
import net.disy.commons.core.io.IFile;
import net.disy.commons.core.io.IFileSystem;
import net.disy.commons.core.os.WindowsUtilities;

import org.easymock.EasyMock;
import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("nls")
public class FileUtilities_Test {

  private IFile file;
  private IFileSystem fileSystem;

  @Before
  public void initFilesystem() throws Exception {
    fileSystem = EasyMock.createMock(IFileSystem.class);
    FileUtilities.setFileSystem(fileSystem);
  }

  @Before
  public void createFile() {
    file = EasyMock.createMock(IFile.class);
  }

  @Test
  public void testGetFileName() {
    assertThat(FileUtilities.getFileName("test.fdfe.dees.dde.de"), //$NON-NLS-1$
        equalTo("test.fdfe.dees.dde.de")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("test"), //$NON-NLS-1$
        equalTo("test")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("test.dat"), //$NON-NLS-1$
        equalTo("test.dat")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("http:test.dat"), //$NON-NLS-1$
        equalTo("test.dat")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("http:./.././test.dat"), //$NON-NLS-1$
        equalTo("test.dat")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("./.././test.dat"), //$NON-NLS-1$
        equalTo("test.dat")); //$NON-NLS-1$
    assertThat(FileUtilities.getFileName("./.././test"), //$NON-NLS-1$
        equalTo("test")); //$NON-NLS-1$
  }

  @Test
  public void tempFileCreatedInSpecifiedExistingDirectory() throws Exception {
    final IFile directory = EasyMock.createNiceMock(IFile.class);
    expect(directory.mkDirs()).andReturn(true);
    EasyMock.expect(fileSystem.createTempFile("prefix", "postfix", directory)).andReturn(file);
    EasyMock.replay(fileSystem, directory, file);
    final IFile tempFile = FileUtilities.createTempFile("prefix", "postfix", directory);
    EasyMock.verify(fileSystem, directory, file);
    assertSame(file, tempFile);
  }

  @Test
  public void tempFileCreatedInDefaultDirectoryIfDirectoryNull() throws Exception {
    final IFile directory = EasyMock.createNiceMock(IFile.class);
    expect(directory.mkDirs()).andReturn(true);
    EasyMock.expect(fileSystem.getDefaultTempDir()).andReturn(directory);
    EasyMock.expect(fileSystem.createTempFile("prefix", "postfix", directory)).andReturn(file);
    EasyMock.replay(fileSystem, file, directory);
    final IFile tempFile = FileUtilities.createTempFile("prefix", "postfix", (IFile) null);
    EasyMock.verify(fileSystem, file, directory);
    assertSame(file, tempFile);
  }

  @Test
  public void specifiedTempDirCreatedIfNonexistent() throws Exception {
    final IFile directory = EasyMock.createMock(IFile.class);
    EasyMock.expect(fileSystem.createTempFile("prefix", "postfix", directory)).andStubReturn(file);
    expect(directory.exists()).andReturn(false);
    expect(directory.mkDirs()).andReturn(true);
    EasyMock.replay(fileSystem, directory, file);
    FileUtilities.createTempFile("prefix", "postfix", directory);
    EasyMock.verify(fileSystem, directory, file);
  }

  @Test
  public void defaultTempDirCreatedIfNonexistent() throws Exception {
    final IFile directory = EasyMock.createMock(IFile.class);
    EasyMock.expect(fileSystem.getDefaultTempDir()).andReturn(directory);
    EasyMock.expect(fileSystem.createTempFile("prefix", "postfix", directory)).andStubReturn(file);
    expect(directory.exists()).andReturn(false);
    expect(directory.mkDirs()).andReturn(true);
    EasyMock.replay(fileSystem, directory, file);
    FileUtilities.createTempFile("prefix", "postfix", (IFile) null);
    EasyMock.verify(fileSystem, directory, file);
  }

  @Test
  public void returnsTempDir() throws Exception {
    final IFile directory = EasyMock.createMock(IFile.class);
    EasyMock.expect(fileSystem.getDefaultTempDir()).andReturn(directory);
    final File tempDir = new File(".");
    EasyMock.expect(directory.getFile()).andReturn(tempDir);
    EasyMock.replay(fileSystem, directory);
    assertThat(FileUtilities.getTempDir(), is(tempDir));
  }

  @Test
  public void throwsNoExceptionIfTempFileParentDirectoryAlreadyExists() throws Exception {
    expect(file.exists()).andReturn(true);
    expect(fileSystem.createTempFile("x", "y", file)).andReturn(null);
    replay(file, fileSystem);
    FileUtilities.createTempFile("x", "y", file);
  }

  @Test
  public void writesToStandardTempDirIfCreationOfTempDirFails() throws Exception {
    final IFile directory = EasyMock.createMock(IFile.class);
    expect(file.exists()).andReturn(false);
    expect(file.mkDirs()).andReturn(false);
    expect(fileSystem.getDefaultTempDir()).andReturn(directory).anyTimes();
    expect(directory.exists()).andReturn(true);
    expect(fileSystem.createTempFile("x", "y", directory)).andReturn(null);
    replay(file, fileSystem, directory);
    FileUtilities.createTempFile("x", "y", file);
    verify(fileSystem);
  }

  @Test(expected = IOException.class)
  public void throwsIOExceptionIfParentDirectoryCouldNotBeCreatedAndWritingToTempDirFails()
      throws Exception {
    final IFile directory = EasyMock.createMock(IFile.class);
    expect(file.exists()).andReturn(false);
    expect(file.mkDirs()).andReturn(false);
    expect(fileSystem.getDefaultTempDir()).andReturn(directory).anyTimes();
    expect(directory.exists()).andReturn(false);
    expect(directory.mkDirs()).andReturn(false);
    replay(file, fileSystem, directory);
    FileUtilities.createTempFile("x", "y", file);
  }

  @Test(expected = IOException.class)
  public void throwsIOExceptionStatingPathIfParentDirectoryCouldNotBeCreatedAndWritingToTempDirFails()
      throws Exception {
    final IFile directory = EasyMock.createMock("Narf", IFile.class);
    expect(directory.exists()).andReturn(false);
    expect(directory.mkDirs()).andReturn(false);
    expect(fileSystem.getDefaultTempDir()).andReturn(file).anyTimes();
    expect(file.exists()).andReturn(false);
    expect(file.mkDirs()).andReturn(false);
    replay(file, fileSystem, directory);
    try {
      FileUtilities.createTempFile("x", "y", directory);
    }
    catch (final IOException e) {
      assertTrue(e.getMessage().contains(directory.toString()));
      throw e;
    }
  }

  @Test
  public void testGetWithoutExtensionForFile() {
    assertThat(FileUtilities.getWithoutExtension(new File("")), equalTo(new File("")));
    assertThat(FileUtilities.getWithoutExtension(new File("test.html")), equalTo(new File("test")));
    assertThat(FileUtilities.getWithoutExtension(new File("/test/test.html")), equalTo(new File(
        "/test/test")));
  }

  @Test
  public void testGetWithoutExtension() {
    assertThat(FileUtilities.getFileNameWithoutExtension(""), equalTo(""));
    assertThat(FileUtilities.getFileNameWithoutExtension("test.html"), equalTo("test"));
    assertThat(FileUtilities.getFileNameWithoutExtension("/test/test.html"), equalTo("/test/test"));
  }

  @Test
  public void testWindowsToFile() throws IOException {
    Assume.assumeThat(WindowsUtilities.isWindows(), is(true));
    assertEquals(
        new File("E:/misc/test.gis"),
        FileUtilities.toFile(new URL("file:/E:/misc/test.gis")));
  }

  @Test
  public void testUnixToFile() throws IOException {
    Assume.assumeThat(WindowsUtilities.isWindows(), is(false));
    assertEquals(
        new File("/home/misc/test.gis"),
        FileUtilities.toFile(new URL("file:/home/misc/test.gis")));
  }

  @Test
  public void convertsNetworkPath() throws Exception {
    assertEquals(new File("//oslo/gis/"), FileUtilities.toFile(new URL("file://oslo/gis/")));
  }

  @Test
  public void toFileDecodesSpecialCharacters() throws Exception {
    assertEquals(
        new File("Dokumente und Einstellungen"),
        FileUtilities.toFile(new URL("file:Dokumente%20und%20Einstellungen")));
  }

  @Test
  public void doesNotAddExtensionIfItAlreadyExistsWithADifferentCase() throws Exception {
    assertThat(FileUtilities.addExtension("han.SEL", "sel"), is("han.SEL"));
  }
}