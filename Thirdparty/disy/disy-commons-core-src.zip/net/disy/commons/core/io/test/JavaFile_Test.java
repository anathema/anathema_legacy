/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertThat;

import java.io.File;
import java.io.IOException;

import net.disy.commons.core.io.JavaFile;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("nls")
public class JavaFile_Test {

  private File file;

  @Before
  public void createFile() throws IOException {
    file = File.createTempFile("test", null); //$NON-NLS-1$
  }

  @Test
  public void fileExistsIfFileExists() throws Exception {
    assertThat(new JavaFile(file).exists(), is(true));
  }

  @Test
  public void fileDoesNotExistIfFileDoesNotExist() throws Exception {
    file.delete();
    assertThat(new JavaFile(file).exists(), is(false));
  }

  @Test
  public void returnsFile() throws Exception {
    assertThat(new JavaFile(file).getFile(), is(file));
  }

  @Test
  public void equalsForEqualFile() throws Exception {
    assertThat(new JavaFile(file), is(new JavaFile(file)));
  }

  @Test
  public void doesNotEqualForDifferentFile() throws Exception {
    assertThat(new JavaFile(file), is(not(new JavaFile(File.createTempFile("test2", null))))); //$NON-NLS-1$
  }

  @Test
  public void doesNotEqualObject() throws Exception {
    assertThat(new Object(), is(not((Object) new JavaFile(file))));
  }

  @Test
  public void hasNoExtensionIfFileHasNone() throws Exception {
    assertThat(new JavaFile(file).hasExtension("sel"), is(false));
  }

  @Test
  public void hasExtensionIfFileHasExtension() throws Exception {
    File extendedFile = File.createTempFile("test", ".sel");
    assertThat(new JavaFile(extendedFile).hasExtension("sel"), is(true));
  }

  @Test
  public void hasExtensionRegardlessOfDot() throws Exception {
    File extendedFile = File.createTempFile("test", ".sel");
    assertThat(new JavaFile(extendedFile).hasExtension(".sel"), is(true));
  }

  @Test
  public void hasNoExtensionIfFileJustEndsWithString() throws Exception {
    File extendedFile = File.createTempFile("test", "sel");
    assertThat(new JavaFile(extendedFile).hasExtension(".sel"), is(false));
  }

  @After
  public void deleteFile() {
    file.delete();
  }
}