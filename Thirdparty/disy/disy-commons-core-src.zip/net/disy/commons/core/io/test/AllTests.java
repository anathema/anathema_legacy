//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.io.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.core.io.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(IOUtilitiesTest.class);
    suite.addTestSuite(CancelableInputStreamTest.class);
    //$JUnit-END$
    return suite;
  }

}
