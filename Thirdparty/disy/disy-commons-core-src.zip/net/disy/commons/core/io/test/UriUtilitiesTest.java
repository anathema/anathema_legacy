/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;

import net.disy.commons.core.io.UriUtilities;

import org.junit.Test;

public class UriUtilitiesTest {

  @Test
  public void testGetWithoutExtension() throws URISyntaxException, MalformedURLException {
    assertThat(UriUtilities.getWithoutExtension(new URI("http:test.dat")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("http:test")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("http:/c:/test/test.dat")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("http:/c:/test/test")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("file:/c:/test/test.dat")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("file:/c:/test/test")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("file:/.././../test/test")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("file:/.././../test/test")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("http:././../test/te%20st")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("http:././../test/te%20st")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("file:././../test/te%20st")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("file:././../test/te%20st")); //$NON-NLS-1$
    assertThat(UriUtilities.getWithoutExtension(new URI("file:././../test/test")) //$NON-NLS-1$
        .toURL()
        .toExternalForm(), equalTo("file:././../test/test")); //$NON-NLS-1$
    assertThat(
        UriUtilities
            .getWithoutExtension(new URI("file:../GIS_GISterm/config/clientlog.properties")) //$NON-NLS-1$
            .toURL()
            .toExternalForm(),
        equalTo("file:../GIS_GISterm/config/clientlog")); //$NON-NLS-1$
    assertThat(
        UriUtilities
            .getWithoutExtension(
                new URI(
                    "file:/C:/Dokumente%20und%20Einstellungen/53_e_tb.LUBW/Eigene%20Dateien/shapefile")) //$NON-NLS-1$
            .toURL()
            .toExternalForm(),
        equalTo("file:/C:/Dokumente%20und%20Einstellungen/53_e_tb.LUBW/Eigene%20Dateien/shapefile")); //$NON-NLS-1$

  }

  @Test
  public void testIsFile() throws URISyntaxException {
    assertTrue(UriUtilities.isFile(new URI("file:/c:/test/test.dat"))); //$NON-NLS-1$
    assertFalse(UriUtilities.isFile(new URI("/test/test.dat"))); //$NON-NLS-1$
    assertFalse(UriUtilities.isFile(null));
    assertFalse(UriUtilities.isFile(new URI("http://test/test.dat"))); //$NON-NLS-1$
  }
}