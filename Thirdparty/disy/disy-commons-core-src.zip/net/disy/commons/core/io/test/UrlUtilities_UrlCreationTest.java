/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.net.URL;

import net.disy.commons.core.io.UrlUtilities;

import org.junit.Test;

@SuppressWarnings("nls")
public class UrlUtilities_UrlCreationTest {

  @Test
  public void appendsSimpleFileNameToBaseUrl() throws Exception {
    assertThat(UrlUtilities.createUrl(new URL("http://test/foo"), "bar"), is(new URL(
        "http://test/foo/bar")));
    assertThat(UrlUtilities.createUrl(new URL("http://test/foo/"), "bar"), is(new URL(
        "http://test/foo/bar")));
  }

  @Test
  public void startsAtRootForNonRelativeFileName() throws Exception {
    final URL baseUrl = new URL("http://test/foo/michael");
    assertThat(UrlUtilities.createUrl(baseUrl, "/bar"), is(new URL("http://test/bar")));
  }

  @Test
  public void choosesFileNameIfItIsUrl() throws Exception {
    final URL baseUrl = new URL("http://test/foo");
    assertThat(UrlUtilities.createUrl(baseUrl, "http://test2/foo"), is(new URL("http://test2/foo")));
    assertThat(UrlUtilities.createUrl(baseUrl, "file:../test"), is(new URL("file:../test")));
  }

  @Test
  public void appendsSimpleFileNameToFileUrl() throws Exception {
    assertThat(UrlUtilities.createUrl(new URL("file:../test"), "bar"), is(new URL(
        "file:../test/bar")));
  }

  @Test
  public void encodesUrlRelevantCharactersFromFileName() throws Exception {
    assertThat(UrlUtilities.createUrl(new URL("http://test"), "foo#bar"), is(new URL(
        "http://test/foo%23bar")));
  }

  @Test
  public void doesNotEncodeFilenameIfFileProtocol() throws Exception {
    assertThat(UrlUtilities.createUrl(new URL("file://test"), "fü bär"), is(new URL(
        "file://test/fü bär")));
  }

  @Test
  public void preservesDirectorySeparatorsFromFileName() throws Exception {
    assertThat(UrlUtilities.createUrl(new URL("http://test"), "foo/bar"), is(new URL(
        "http://test/foo/bar")));
    assertThat(UrlUtilities.createUrl(new URL("http://test"), "foo\\bar"), is(new URL(
        "http://test/foo/bar")));
  }
}