/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.File;
import java.io.FileFilter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;

import net.disy.commons.core.predicate.IPredicate;

public interface IFile {

  /** @see File#exists() */
  public boolean exists();

  public String getAbsolutePath();

  public IFile getChild(String child);

  public String getName();

  public boolean isDirectory();

  /** @deprecated As of 22.06.2009 (sieroux), use {@link #getChildren(IPredicate)} instead */
  @Deprecated
  public IFile[] listFiles(FileFilter fileFilter);

  public IFile[] getChildren(IPredicate<IFile> predicate);

  /** @see File#mkdirs() */
  public boolean mkDirs();

  public void createNew() throws IOException;

  public Reader createReader() throws FileNotFoundException;

  public OutputStream createOutputStream() throws FileNotFoundException;

  /** @deprecated As of 22.06.2009 (sieroux), replaced by appropriate abstraction */
  @Deprecated
  public File getFile();

  public InputStream openInputStream() throws FileNotFoundException;

  public boolean hasExtension(String extension);

  public void delete();

  public void rename(String newName);

  public void setContent(InputStream content) throws IOException;
}