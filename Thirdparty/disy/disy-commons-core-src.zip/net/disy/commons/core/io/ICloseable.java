// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.io;

import java.io.IOException;

//NOT_PUBLISHED
public interface ICloseable {

  public void close() throws IOException;

}
