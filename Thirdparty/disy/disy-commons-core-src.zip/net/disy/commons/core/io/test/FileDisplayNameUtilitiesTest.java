/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io.test;

import net.disy.commons.core.io.FileDisplayNameUtilities;
import net.disy.commons.core.testing.CoreTestCase;

public class FileDisplayNameUtilitiesTest extends CoreTestCase {

  public void test() {
    assertEquals("name.txt", FileDisplayNameUtilities.createShortenedFileName("name.txt", 20)); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(
        "C:/fold.../name.txt", FileDisplayNameUtilities.createShortenedFileName("C:/folder1/folder2/folder3/name.txt", 19)); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(
        "C:/folde.../name.txt", FileDisplayNameUtilities.createShortenedFileName("C:/folder1/folder2/folder3/name.txt", 20)); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(
        "C:/folder.../name.txt", FileDisplayNameUtilities.createShortenedFileName("C:/folder1/folder2/folder3/name.txt", 21)); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(
        "/usr/fol.../name.txt", FileDisplayNameUtilities.createShortenedFileName("/usr/folder1/folder2/folder3/name.txt", 20)); //$NON-NLS-1$//$NON-NLS-2$
    assertEquals(
        "C:\\u...\\filename.txt", FileDisplayNameUtilities.createShortenedFileName("C:\\usr\\folder1\\folder2\\folder3\\filename.txt", 20)); //$NON-NLS-1$//$NON-NLS-2$
  }
}