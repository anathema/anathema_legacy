//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.io;

import java.io.File;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.ObjectUtilities;

/**
 * @author Markus Gebhard
 */
public class FileModel extends AbstractChangeableModel {

  private File file;

  public void setFile(File file) {
    if (ObjectUtilities.equals(this.file, file)) {
      return;
    }
    this.file = file;
    fireChangeEvent();
  }

  public File getFile() {
    return file;
  }
}