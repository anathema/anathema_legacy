//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.io;

import java.io.File;

import net.disy.commons.core.model.ObjectModel;

/**
 * @author Markus Gebhard
 */
public class FileModel extends ObjectModel<File> {
  // nothing to do
}