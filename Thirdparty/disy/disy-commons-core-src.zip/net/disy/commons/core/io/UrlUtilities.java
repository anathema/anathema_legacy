/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import static net.disy.commons.core.util.ArrayUtilities.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.net.UnknownHostException;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ITransformer;
import net.disy.commons.core.util.StringUtilities;

public class UrlUtilities {

  /**
   * @deprecated Use UTF-8 for URL encoding. 
   */
  @Deprecated
  public static final String ENCODING_ISO_8859_1 = "ISO-8859-1"; //$NON-NLS-1$
  public static final String ENCODING_UTF_8 = "UTF-8"; //$NON-NLS-1$

  public static boolean isAccessible(final URL url) {
    InputStream openStream = null;
    try {
      if (UriUtilities.isFile(url.toURI())) {
        return FileUtilities.isReadable(new File(url.toURI()));
      }
      openStream = url.openStream();
      return true;
    }
    catch (final Throwable throwable) {
      return false;
    }
    finally {
      IOUtilities.close(openStream);
    }
  }

  public static boolean isFile(final URL url) {
    try {
      return UriUtilities.isFile(url.toURI());
    }
    catch (final Throwable exception) {
      return false;
    }
  }

  public static final String PROTOCOL_HTTP = "http"; //$NON-NLS-1$
  public static final String PROTOCOL_FILE = "file"; //$NON-NLS-1$

  private UrlUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static void checkUrlExists(final String urlString) throws IOException {
    InputStream stream = null;
    try {
      stream = new URL(urlString).openStream();
    }
    finally {
      IOUtilities.close(stream);
    }
  }

  public static boolean isFileUrl(final URL url) {
    return url.getProtocol().equals(PROTOCOL_FILE);
  }

  public static boolean isHttpUrl(final URL url) {
    return url.getProtocol().equals(PROTOCOL_HTTP);
  }

  public static boolean isFileOrHttpUrl(final URL url) {
    return isFileUrl(url) || isHttpUrl(url);
  }

  public static boolean representsFileUrl(final String urlString) {
    return urlString.startsWith(PROTOCOL_FILE + ":"); //$NON-NLS-1$
  }

  public static boolean representsHttpUrl(final String urlString) {
    return urlString.startsWith(PROTOCOL_HTTP + ":"); //$NON-NLS-1$
  }

  public static String removeExtension(final String externalForm) {
    if (!hasExtension(externalForm)) {
      return externalForm;
    }
    int pointIndex = externalForm.lastIndexOf('.');
    return externalForm.substring(0, pointIndex);
  }

  public static boolean hasExtension(final String externalForm) {
    final int pointIndex = externalForm.lastIndexOf('.');
    final int slashIndex = externalForm.lastIndexOf('/');
    return pointIndex > 0 && pointIndex > slashIndex;
  }

  public static URL getParent(final URL url) throws MalformedURLException {
    final String path = url.toExternalForm();
    return new URL(path.substring(0, path.lastIndexOf('/') + 1));
  }

  public static boolean isDirectory(final URL url) {
    return url.getPath().endsWith("/"); //$NON-NLS-1$
  }

  public static String getFileName(final URL url) {
    String path = url.getPath();
    if (path.endsWith("/")) { //$NON-NLS-1$
      path = path.substring(0, path.length() - 1);
    }

    return path.substring(path.lastIndexOf('/') + 1);
  }

  public static String getContentAsString(final URL url, final String encoding) throws IOException {
    Ensure.ensureArgumentNotNull(url);
    InputStream inputStream = null;
    try {
      final URLConnection connection = url.openConnection();
      inputStream = connection.getInputStream();
      return IOUtilities.toString(inputStream, encoding);
    }
    finally {
      IOUtilities.close(inputStream);
    }
  }

  public static String getPathWithoutProtocol(final URL url) {
    final String urlString = url.toExternalForm();
    if (isHttpUrl(url)) {
      return urlString.substring(7);
    }
    if (isFileUrl(url)) {
      return FileUtilities.toFile(url).getAbsolutePath();
    }
    throw new UnsupportedOperationException("Protocol not supported: " + url.getProtocol()); //$NON-NLS-1$
  }

  public static boolean isHttpUrl(final String string) {
    return string.startsWith(PROTOCOL_HTTP);
  }

  public static boolean isFileUrl(final String string) {
    return string.startsWith(PROTOCOL_FILE);
  }

  public static boolean containsAuthentication(final String url) {
    if (isHttpUrl(url)) {
      final String[] urlParts = url.split("@"); //$NON-NLS-1$
      if (urlParts.length == 2) {
        final String authenticationString = urlParts[0].substring(7);
        final String[] authenticationParts = authenticationString.split(":"); //$NON-NLS-1$
        return authenticationParts.length == 2
            && !StringUtilities.isNullOrEmpty(authenticationParts[0])
            && !StringUtilities.isNullOrEmpty(authenticationParts[1]);
      }
    }
    return false;
  }

  private static String[] getAuthenticationString(final String url) {
    final String[] urlParts = url.split("@"); //$NON-NLS-1$
    final String authenticationString = urlParts[0].substring(7);
    final String[] authenticationParts = authenticationString.split(":"); //$NON-NLS-1$
    return authenticationParts;
  }

  public static String getUserName(final String url) {
    if (containsAuthentication(url)) {
      final String[] authenticationParts = getAuthenticationString(url);
      return authenticationParts[0];
    }
    return null;
  }

  public static String getPassword(final String url) {
    if (containsAuthentication(url)) {
      final String[] authenticationParts = getAuthenticationString(url);
      return authenticationParts[1];
    }
    return null;
  }

  public static boolean exists(final URL configUrl) throws IOException {
    InputStream openStream = null;
    try {
      openStream = configUrl.openStream();
    }
    catch (final FileNotFoundException e) {
      return false;
    }
    catch (final UnknownHostException e) {
      return false;
    }
    finally {
      IOUtilities.close(openStream);
    }
    return true;
  }

  public static String stripJSessionId(final String url) {
    final String strippedUrl = url.replaceAll(";jsessionid=[^?]*", ""); //$NON-NLS-1$ //$NON-NLS-2$
    return strippedUrl;
  }

  public static URL createUrl(String baseUrlString, String fileName) throws MalformedURLException {
    Ensure.ensureArgumentNotNull(baseUrlString);
    Ensure.ensureArgumentNotNull(fileName);
    return createUrl(new URL(baseUrlString), fileName);
  }

  public static URL createUrl(URL baseUrl, String fileName) {
    Ensure.ensureArgumentNotNull(baseUrl);
    Ensure.ensureArgumentNotNull(fileName);
    try {
      URL url = baseUrl.getPath().endsWith("/") ? baseUrl : new URL(baseUrl.toString() + "/"); //$NON-NLS-1$ //$NON-NLS-2$
      if (isFileUrl(fileName) || isHttpUrl(fileName) || isFileUrl(url)) {
        return new URL(url, fileName);
      }
      String encodedFileName = UrlUtilities.createEncodedFileName(fileName);
      return new URL(url, encodedFileName);
    }
    catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }

  /*
   *  difference between createUrl and concatPath 
   *  
   *  "http://host/path/file" = concatPath("http://host/path", "/file");
   *  "http://host/file"      = createUrl ("http://host/path", "/file");
   *  
   *  "http://host/path/file" = concatPath("http://host/path/", "/file");
   *  "http://host/file"      = createUrl ("http://host/path/", "/file");
   *  
   *  "http://host/path/file" = concatPath("http://host/path", "file");
   *  "http://host/path/file" = createUrl ("http://host/path", "file");
   *  
   *  "http://host/path/file" = concatPath("http://host/path/", "file");
   *  "http://host/path/file" = createUrl ("http://host/path/", "file");
   */

  public static URL concatPath(final URL url, final String filename)
      throws MalformedURLException,
      URISyntaxException {
    return new URI(
        url.getProtocol(),
        url.getUserInfo(),
        url.getHost(),
        url.getPort(),
        StringUtilities.concat(url.getPath(), filename, '/'),
        url.getQuery(),
        null).toURL();
  }

  private static String createEncodedFileName(final String fileName) {
    if (fileName.isEmpty()) {
      return fileName;
    }
    final String[] tokens = fileName.split("/|\\\\"); //$NON-NLS-1$
    final String[] encodedTokens = transform(
        tokens,
        String.class,
        new ITransformer<String, String>() {
          @Override
          public String transform(final String input) {
            try {
              return URLEncoder.encode(input, ENCODING_UTF_8);
            }
            catch (final UnsupportedEncodingException e) {
              throw new RuntimeException(e);
            }
          }
        });
    final StringBuffer buffer = new StringBuffer();
    buffer.append(encodedTokens[0]);
    for (int index = 1; index < tokens.length; index++) {
      buffer.append("/"); //$NON-NLS-1$
      buffer.append(encodedTokens[index]);
    }
    return buffer.toString();
  }

  public static URI toUri(URL url) throws URISyntaxException {
    if (!isFileUrl(url)) {
      return url.toURI();
    }
    return FileUtilities.toFile(url).toURI();
  }
}