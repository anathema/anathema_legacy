/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import net.disy.commons.core.util.Ensure;

/**Ein Inputstream, der einen Beobachter über die Anzahl der gelesenen Bytes informiert.
 * 
 * Verwendung:
 *   private static void downloadLogFile(final IProgressMonitor monitor, ...) {
       monitor.subTask("Downloading logfile");
       int length = ...
       monitor.beginTask("Downloading Logfile...", length);
       IBytesReadHandler bytesReadHandler = new IBytesReadHandler() {
       public void handleBytesRead(long byteCount, long totalByteCount) {
          monitor.subTask("Downloading logfile, " + IOUtilities.byteCountToDisplaySize(totalByteCount) + " read.");
          monitor.worked((int) byteCount);
       }
     };
     ProgressInputStream progressInputStream = new ProgressInputStream(fileInputStream, bytesReadHandler);
     ...
   }
 * */
//Wird von Markus Gebhard in Privatprojekten verwendet
public class ProgressInputStream extends FilterInputStream {
  private long bytesRead = 0;
  private final IBytesReadHandler handler;

  public ProgressInputStream(final InputStream in, final IBytesReadHandler handler) {
    super(in);
    Ensure.ensureArgumentNotNull(handler);
    this.handler = handler;
  }

  @Override
  public int read() throws IOException {
    final int result = super.read();
    if (result != -1) {
      logBytesRead(1);
    }
    return result;
  }

  private void logBytesRead(final long byteCount) {
    if (byteCount == -1) {
      return;
    }
    bytesRead += byteCount;
    handler.handleBytesRead(byteCount, bytesRead);
  }

  @Override
  public int read(final byte[] b) throws IOException {
    final int byteCount = super.read(b);
    logBytesRead(byteCount);
    return byteCount;
  }

  @Override
  public int read(final byte[] b, final int off, final int len) throws IOException {
    final int byteCount = super.read(b, off, len);
    logBytesRead(byteCount);
    return byteCount;
  }

  @Override
  public long skip(final long n) throws IOException {
    final long byteCount = super.skip(n);
    logBytesRead(byteCount);
    return byteCount;
  }
}