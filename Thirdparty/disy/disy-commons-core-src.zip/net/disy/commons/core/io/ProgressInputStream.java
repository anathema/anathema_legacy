// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.io;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ProgressInputStream extends FilterInputStream {
  private long bytesRead = 0;
  private final IBytesReadHandler handler;

  public ProgressInputStream(InputStream in, IBytesReadHandler handler) {
    super(in);
    Ensure.ensureArgumentNotNull(handler);
    this.handler = handler;
  }

  @Override
  public int read() throws IOException {
    int result = super.read();
    if (result != -1) {
      logBytesRead(1);
    }
    return result;
  }

  private void logBytesRead(long byteCount) {
    if (byteCount == -1) {
      return;
    }
    bytesRead += byteCount;
    handler.handleBytesRead(byteCount, bytesRead);
  }

  @Override
  public int read(byte[] b) throws IOException {
    int byteCount = super.read(b);
    logBytesRead(byteCount);
    return byteCount;
  }

  @Override
  public int read(byte[] b, int off, int len) throws IOException {
    int byteCount = super.read(b, off, len);
    logBytesRead(byteCount);
    return byteCount;
  }

  @Override
  public long skip(long n) throws IOException {
    long byteCount = super.skip(n);
    logBytesRead(byteCount);
    return byteCount;
  }
}