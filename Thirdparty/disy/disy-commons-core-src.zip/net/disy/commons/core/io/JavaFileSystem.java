/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.File;
import java.io.IOException;

public class JavaFileSystem implements IFileSystem {

  @Override
  public IFile createTempFile(String prefix, String postfix, IFile directory) throws IOException {
    File file = File.createTempFile(prefix, postfix, ((JavaFile) directory).getFile());
    file.deleteOnExit();
    return new JavaFile(file);
  }

  @Override
  public IFile getDefaultTempDir() {
    return new JavaFile(new File(System.getProperty("java.io.tmpdir"))); //$NON-NLS-1$
  }
}