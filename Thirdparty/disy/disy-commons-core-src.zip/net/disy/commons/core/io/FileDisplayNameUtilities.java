/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileDisplayNameUtilities {

  private final static Pattern WINDOWS_FILE_NAME_PATTERN = Pattern
      .compile("(.*?:[/|\\\\])(.*)([/|\\\\].*)"); //$NON-NLS-1$
  private final static Pattern UNIX_FILE_NAME_PATTERN = Pattern.compile("(/.*?/)(.*)(/.*)"); //$NON-NLS-1$

  public static String createShortenedFileName(final String fileName, final int maxLength) {
    if (fileName.length() <= maxLength) {
      return fileName;
    }
    final Matcher windowsMatcher = WINDOWS_FILE_NAME_PATTERN.matcher(fileName);
    if (windowsMatcher.matches()) {
      final String prefix = windowsMatcher.group(1);
      final String interior = windowsMatcher.group(2);
      final String postfix = windowsMatcher.group(3);
      return concatenateShortenedName(prefix, interior, postfix, maxLength);
    }
    final Matcher unixMatcher = UNIX_FILE_NAME_PATTERN.matcher(fileName);
    if (unixMatcher.matches()) {
      final String prefix = unixMatcher.group(1);
      final String interior = unixMatcher.group(2);
      final String postfix = unixMatcher.group(3);
      return concatenateShortenedName(prefix, interior, postfix, maxLength);
    }

    return fileName;
  }

  private static String concatenateShortenedName(
      final String prefix,
      final String interior,
      final String postfix,
      final int maxLength) {
    final String ellipsis = "..."; //$NON-NLS-1$

    final int fixLength = prefix.length() + ellipsis.length() + postfix.length();
    String interiorAddition = ""; //$NON-NLS-1$
    if (fixLength < maxLength) {
      interiorAddition = interior.substring(0, maxLength - fixLength);
    }
    return prefix + interiorAddition + ellipsis + postfix;
  }
}