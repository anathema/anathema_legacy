/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.io;

import java.io.ByteArrayInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.Socket;
import java.text.DecimalFormat;

public class IOUtilities {

  private static final DecimalFormat DECIMAL_FORMAT_3 = new DecimalFormat("000"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_2_1 = new DecimalFormat("00.0"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_1_2 = new DecimalFormat("0.00"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_1_3 = new DecimalFormat("0.000"); //$NON-NLS-1$

  public static final long ONE_KB = 1024;

  public static final long ONE_MB = ONE_KB * ONE_KB;

  public static final long ONE_GB = ONE_KB * ONE_MB;

  public static void close(final Closeable closeable) {
    if (closeable != null) {
      try {
        closeable.close();
      }
      catch (final IOException exception) {
        // Silent
      }
    }
  }

  public static String readString(final Reader reader) throws IOException {
    final StringBuffer buffer = new StringBuffer();
    final char[] buf = new char[1024];
    int numChars = 0;
    while ((numChars = reader.read(buf)) > 0) {
      buffer.append(buf, 0, numChars);
    }
    return buffer.toString();
  }

  public static void copyStream(final InputStream in, final OutputStream out) throws IOException {
    copyStream(in, out, 4096);
  }

  public static void copyStream(final InputStream in, final OutputStream out, final int bufferSize)
      throws IOException {
    final byte[] buffer = new byte[bufferSize];
    int numChars;
    while ((numChars = in.read(buffer)) > 0) {
      out.write(buffer, 0, numChars);
    }
  }

  public static void copyStream(final Reader reader, final Writer writer) throws IOException {
    copyStream(reader, writer, 4096);
  }

  public static void copyStream(final Reader in, final Writer out, final int bufferSize)
      throws IOException {
    final char[] buffer = new char[bufferSize];
    int numChars;
    while ((numChars = in.read(buffer)) > 0) {
      out.write(buffer, 0, numChars);
    }
  }

  public static InputStream toInputStream(final String input) {
    return new ByteArrayInputStream(input.getBytes());
  }

  public static String toString(final InputStream inputStream, final String encoding)
      throws IOException {
    final InputStreamReader reader = encoding == null
        ? new InputStreamReader(inputStream)
        : new InputStreamReader(inputStream, encoding);
    final StringWriter writer = new StringWriter();
    copyStream(reader, writer);
    return writer.toString();
  }

  /**
   * Returns a human-readable version of the given size in bytes.
   *
   * @param size The number of bytes.
   * @return A human-readable display value including units.
   */
  public static final String byteCountToDisplaySize(final long size) {
    if (size / ONE_GB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_GB) + " GB"; //$NON-NLS-1$
    }
    else if (size / ONE_MB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_MB) + " MB"; //$NON-NLS-1$
    }
    else if (size / ONE_KB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_KB) + " KB"; //$NON-NLS-1$
    }
    else {
      return size + " bytes"; //$NON-NLS-1$
    }
  }

  private static final String asThreeSignificantCiffersString(final double value) {
    if (value < 1.0) {
      return DECIMAL_FORMAT_1_3.format(value);
    }
    if (value < 10.0) {
      return DECIMAL_FORMAT_1_2.format(value);
    }
    if (value < 100.0) {
      return DECIMAL_FORMAT_2_1.format(value);
    }
    return DECIMAL_FORMAT_3.format(value);
  }

  public static void withWriter(final File file, final IWriterClosure closure) throws IOException {
    withWriter(new FileWriter(file), closure);
  }

  private static void withWriter(final Writer writer, final IWriterClosure closure)
      throws IOException {
    try {
      closure.execute(writer);
    }
    finally {
      close(writer);
    }
  }

  public static void withInputStream(final File file, final IInputStreamClosure closure)
      throws IOException {
    withInputStream(new FileInputStream(file), closure);
  }

  public static void withInputStream(
      final InputStream inputStream,
      final IInputStreamClosure closure) throws IOException {
    try {
      closure.execute(inputStream);
    }
    finally {
      close(inputStream);
    }
  }

  private static Thread createInputStreamConsumerThread(final InputStream inputStream) {
    final Runnable runnable = new Runnable() {
      @Override
      public void run() {
        try {
          while (inputStream.read() > -1) {
            // nothing to do
          }
        }
        catch (final IOException e) {
          throw new RuntimeException(e);
        }
      }
    };
    final Thread thread = new Thread(runnable);
    thread.start();
    return thread;
  }

  public static void close(final Socket socket) {
    if (socket != null) {
      try {
        socket.close();
      }
      catch (final IOException exception) {
        // nothing to do
      }
    }
  }

  public static void executeCommand(final String command) throws IOException {
    final Process process = Runtime.getRuntime().exec(command);
    process.getOutputStream().close();
    createInputStreamConsumerThread(process.getInputStream());
    createInputStreamConsumerThread(process.getErrorStream());
  }
}