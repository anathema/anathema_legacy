// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 12.01.2005
package net.disy.commons.core.io;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.text.DecimalFormat;

// NOT_PUBLISHED
public class IOUtilities {

  private static final DecimalFormat DECIMAL_FORMAT_3 = new DecimalFormat("000"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_2_1 = new DecimalFormat("00.0"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_1_2 = new DecimalFormat("0.00"); //$NON-NLS-1$

  private static final DecimalFormat DECIMAL_FORMAT_1_3 = new DecimalFormat("0.000"); //$NON-NLS-1$

  public static final long ONE_KB = 1024;

  public static final long ONE_MB = ONE_KB * ONE_KB;

  public static final long ONE_GB = ONE_KB * ONE_MB;

  private IOUtilities() {
    // will not be instantiated
  }

  public static void close(OutputStream stream) {
    if (stream != null) {
      try {
        stream.close();
      }
      catch (IOException exception) {
        // Silent
      }
    }
  }

  public static void close(InputStream stream) {
    if (stream != null) {
      try {
        stream.close();
      }
      catch (IOException exception) {
        // Silent
      }
    }
  }

  public static void close(Reader reader) {
    if (reader != null) {
      try {
        reader.close();
      }
      catch (IOException exception) {
        // Silent
      }
    }
  }

  public static void close(Writer writer) {
    if (writer != null) {
      try {
        writer.close();
      }
      catch (IOException exception) {
        // Silent
      }
    }
  }

  public static String readString(Reader reader) throws IOException {
    StringBuffer buffer = new StringBuffer();
    char[] buf = new char[1024];
    int numChars = 0;
    while ((numChars = reader.read(buf)) > 0) {
      buffer.append(buf, 0, numChars);
    }
    return buffer.toString();
  }

  public static void copyStream(InputStream in, OutputStream out) throws IOException {
    copyStream(in, out, 4096);
  }

  public static void copyStream(InputStream in, OutputStream out, int bufferSize)
      throws IOException {
    byte[] buffer = new byte[bufferSize];
    int numChars;
    while ((numChars = in.read(buffer)) > 0) {
      out.write(buffer, 0, numChars);
    }
  }

  public static void copyStream(Reader reader, Writer writer) throws IOException {
    copyStream(reader, writer, 4096);
  }

  public static void copyStream(Reader in, Writer out, int bufferSize) throws IOException {
    char[] buffer = new char[bufferSize];
    int numChars;
    while ((numChars = in.read(buffer)) > 0) {
      out.write(buffer, 0, numChars);
    }
  }

  public static InputStream toInputStream(String input) {
    return new ByteArrayInputStream(input.getBytes());
  }

  /**
   * Returns a human-readable version of the given size in bytes.
   *
   * @param size The number of bytes.
   * @return  A human-readable display value including units.
   */
  public static final String byteCountToDisplaySize(long size) {
    if (size / ONE_GB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_GB) + " GB"; //$NON-NLS-1$
    }
    else if (size / ONE_MB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_MB) + " MB"; //$NON-NLS-1$
    }
    else if (size / ONE_KB > 0) {
      return asThreeSignificantCiffersString((double) size / ONE_KB) + " KB"; //$NON-NLS-1$
    }
    else {
      return size + " bytes"; //$NON-NLS-1$
    }
  }

  private static final String asThreeSignificantCiffersString(double value) {
    if (value < 1.0) {
      return DECIMAL_FORMAT_1_3.format(value);
    }
    if (value < 10.0) {
      return DECIMAL_FORMAT_1_2.format(value);
    }
    if (value < 100.0) {
      return DECIMAL_FORMAT_2_1.format(value);
    }
    return DECIMAL_FORMAT_3.format(value);
  }
}