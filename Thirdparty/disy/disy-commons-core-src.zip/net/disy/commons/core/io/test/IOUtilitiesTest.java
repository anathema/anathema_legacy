//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.io.test;

import java.text.DecimalFormat;

import net.disy.commons.core.io.IOUtilities;
import net.disy.commons.core.testing.CoreTestCase;

// NOT_PUBLISHED
public class IOUtilitiesTest extends CoreTestCase {

  public void testByteCountToDisplaySize() {
    assertEquals("0 bytes", IOUtilities.byteCountToDisplaySize(0)); //$NON-NLS-1$
    assertEquals("10 bytes", IOUtilities.byteCountToDisplaySize(10)); //$NON-NLS-1$
    assertEquals("313 bytes", IOUtilities.byteCountToDisplaySize(313)); //$NON-NLS-1$
    assertEquals(
        new DecimalFormat("0.00").format(1.5) + " KB", IOUtilities.byteCountToDisplaySize(1536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("00.0").format(11.3) + " KB", IOUtilities.byteCountToDisplaySize(11536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("000").format(207) + " KB", IOUtilities.byteCountToDisplaySize(211536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("0.00").format(3.06) + " MB", IOUtilities.byteCountToDisplaySize(3211536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("00.0").format(50.7) + " MB", IOUtilities.byteCountToDisplaySize(53211536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("000").format(623) + " MB", IOUtilities.byteCountToDisplaySize(653211536)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(
        new DecimalFormat("0.00").format(7.13) + " GB", IOUtilities.byteCountToDisplaySize(7653211536l)); //$NON-NLS-1$ //$NON-NLS-2$
  }
}