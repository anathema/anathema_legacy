/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.predicate.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import net.disy.commons.core.predicate.ObjectEqualsPredicate;

import org.junit.Test;

public class ObjectEqualsPredicateTest {

  @Test
  public void predicateWithNullValueEvaluesNullTrue() throws Exception {
    assertThat(new ObjectEqualsPredicate<Object>(null).evaluate(null), is(true));
  }

  @Test
  public void equalStringsEvaluateToTrue() throws Exception {
    assertThat(new ObjectEqualsPredicate<String>("TheString").evaluate("TheString"), is(true)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void inequalStringsEvaluateToFalse() throws Exception {
    assertThat(new ObjectEqualsPredicate<String>("TheString").evaluate("OtherString"), is(false)); //$NON-NLS-1$ //$NON-NLS-2$
  }
}