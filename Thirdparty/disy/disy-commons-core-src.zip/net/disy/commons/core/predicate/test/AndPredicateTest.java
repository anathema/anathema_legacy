/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.predicate.test;

import static org.junit.Assert.*;

import net.disy.commons.core.predicate.AcceptAllPredicate;
import net.disy.commons.core.predicate.AcceptNothingPredicate;
import net.disy.commons.core.predicate.AndPredicate;

import org.junit.Before;
import org.junit.Test;

public class AndPredicateTest {

  private AndPredicate<Object> allPredicate;

  @Before
  public void createAllPredicate() {
    this.allPredicate = new AndPredicate<Object>();
  }

  @Test
  public void emptyAllPredicateEvaluatesToTrue() throws Exception {
    assertTrue(allPredicate.evaluate(null));
  }

  @Test
  public void withRejectingPredicateEvaluatesToFalse() throws Exception {
    allPredicate.addPredicate(new AcceptAllPredicate<Object>());
    allPredicate.addPredicate(new AcceptNothingPredicate<Object>());
    assertFalse(allPredicate.evaluate(null));
  }

  @Test
  public void withOnlyAcceptingPredicatesEvaluatesToTrue() throws Exception {
    allPredicate.addPredicate(new AcceptAllPredicate<Object>());
    allPredicate.addPredicate(new AcceptAllPredicate<Object>());
    assertTrue(allPredicate.evaluate(null));
  }
}