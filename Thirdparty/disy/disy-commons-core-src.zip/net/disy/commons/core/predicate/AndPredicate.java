/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.predicate;

import java.util.ArrayList;
import java.util.List;

public class AndPredicate<T> implements IPredicate<T> {

  private final List<IPredicate<T>> allPredicates = new ArrayList<IPredicate<T>>();

  public AndPredicate(final IPredicate<T>... predicates) {
    for (final IPredicate<T> predicate : predicates) {
      addPredicate(predicate);
    }
  }

  @Override
  public boolean evaluate(final T value) {
    for (final IPredicate<T> predicate : allPredicates) {
      if (!predicate.evaluate(value)) {
        return false;
      }
    }
    return true;
  }

  public void addPredicate(final IPredicate<T> predicate) {
    allPredicates.add(predicate);
  }
}