//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.predicate;


// NOT_PUBLISHED
public class AcceptAllPredicate implements IPredicate {

  public boolean evaluate(Object value) {
    return true;
  }
}