/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.predicate.test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import net.disy.commons.core.predicate.AndCheck;
import net.disy.commons.core.predicate.ICheck;

import org.junit.Test;

public class AndCheck_Test {

  @Test
  public void forwardsCallsToSingleCheck() throws Exception {
    ICheck check = createRejectedCheck();
    new AndCheck(check).isConfirmed();
    verify(check).isConfirmed();
  }

  @Test
  public void forwardsCallsToAllChecks() throws Exception {
    ICheck check1 = createRejectedCheck();
    ICheck check2 = createRejectedCheck();
    new AndCheck(check1, check2).isConfirmed();
    verify(check1).isConfirmed();
    verify(check2).isConfirmed();
  }

  @Test
  public void isConfirmedIfAllChecksAreConfirmed() throws Exception {
    ICheck check1 = createConfirmedCheck();
    ICheck check2 = createConfirmedCheck();
    boolean confirmed = new AndCheck(check1, check2).isConfirmed();
    assertThat(confirmed, is(true));
  }

  @Test
  public void isNotConfirmedIfSingleCheckIsNotConfirmed() throws Exception {
    ICheck check1 = createConfirmedCheck();
    ICheck check2 = createRejectedCheck();
    boolean confirmed = new AndCheck(check1, check2).isConfirmed();
    assertThat(confirmed, is(false));
  }
  
  @Test
  public void isTrueWithoutChecks() throws Exception {
    boolean confirmed = new AndCheck().isConfirmed();
    assertThat(confirmed, is(true));
  }

  private ICheck createRejectedCheck() {
    return mock(ICheck.class);
  }

  private ICheck createConfirmedCheck() {
    ICheck check = mock(ICheck.class);
    when(check.isConfirmed()).thenReturn(true);
    return check;
  }

}