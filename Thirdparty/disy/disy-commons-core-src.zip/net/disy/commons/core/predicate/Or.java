/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.predicate;

import net.disy.commons.core.util.Ensure;

public class Or<T> implements IPredicate<T> {

  public static <T> Or<T> For(final IPredicate<T> first, final IPredicate<T> second) {
    return new Or<T>(first, second);
  }

  private final IPredicate<T> first;
  private final IPredicate<T> second;

  public Or(final IPredicate<T> first, final IPredicate<T> second) {
    Ensure.ensureArgumentNotNull(first);
    Ensure.ensureArgumentNotNull(second);
    this.second = second;
    this.first = first;
  }

  @Override
  public boolean evaluate(final T value) {
    return first.evaluate(value) || second.equals(value);
  }
}