// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.predicate;

//NOT_PUBLISHED
public interface IPredicate<T> {

  public boolean evaluate(T value);

}