/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped;

import java.util.ArrayList;
import java.util.Arrays;

import net.disy.commons.core.util.Ensure;

public class PredefinedOrderGroupHandler<T> implements IGroupHandler<T> {

  private final ArrayList<T> allGroups = new ArrayList<T>();
  private T beforeInsertPosition;

  public PredefinedOrderGroupHandler(final T... predefinedGroups) {
    allGroups.addAll(Arrays.asList(predefinedGroups));
  }

  @Override
  public void addGroup(final T groupId) {
    if (allGroups.contains(groupId)) {
      return;
    }
    if (beforeInsertPosition == null) {
      allGroups.add(groupId);
    }
    else {
      allGroups.add(allGroups.indexOf(beforeInsertPosition), groupId);
    }
  }

  @Override
  public Iterable<T> getGroupsInDisplayOrder() {
    return allGroups;
  }

  public void setGroupInsertPositionBefore(final T beforeInsertPosition) {
    Ensure.ensureArgumentTrue("unknown group: " + beforeInsertPosition, allGroups //$NON-NLS-1$
        .contains(beforeInsertPosition));
    this.beforeInsertPosition = beforeInsertPosition;
  }
}