/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.easymock.EasyMock.*;
import net.disy.commons.core.grouped.IGroupHandler;
import net.disy.commons.core.grouped.IStructuredItemAddable;
import net.disy.commons.core.grouped.OrderRetainingGroupHandler;
import net.disy.commons.core.grouped.SeparatorGroupItemStructureBuilder;

import org.junit.Before;
import org.junit.Test;

public class SeparatorGroupItemStructureBuilderTest {

  private IStructuredItemAddable<Object> addableMock;
  private IGroupHandler<String> groupHandler;
  private SeparatorGroupItemStructureBuilder<String, Object> structureBuilder;

  @SuppressWarnings("unchecked")
  @Before
  public void createAddable() throws Exception {
    addableMock = createStrictMock(IStructuredItemAddable.class);
  }

  @Before
  public void createStructureBuilder() throws Exception {
    groupHandler = new OrderRetainingGroupHandler<String>();
    structureBuilder = new SeparatorGroupItemStructureBuilder<String, Object>(groupHandler);
  }

  @Test
  public void addsSeparatorBetweenGroups() throws Exception {
    addableMock.add("first"); //$NON-NLS-1$
    addableMock.addSeparator();
    addableMock.add("second"); //$NON-NLS-1$
    replay(addableMock);
    structureBuilder.add("firstGroup", "first"); //$NON-NLS-1$ //$NON-NLS-2$
    structureBuilder.add("secondGroup", "second"); //$NON-NLS-1$ //$NON-NLS-2$
    structureBuilder.addAllItemsTo(addableMock);
    verify(addableMock);
  }

  @Test
  public void addsNoSeparaterAfterEmptyGroup() throws Exception {
    addableMock.add("first"); //$NON-NLS-1$
    replay(addableMock);
    groupHandler.addGroup("empty"); //$NON-NLS-1$
    structureBuilder.add("firstGroup", "first"); //$NON-NLS-1$ //$NON-NLS-2$
    structureBuilder.addAllItemsTo(addableMock);
    verify(addableMock);
  }

  @Test
  public void addsNoSeparatorIfLastGroupIsEmpty() throws Exception {
    addableMock.add("first"); //$NON-NLS-1$
    replay(addableMock);
    groupHandler.addGroup("firstGroup"); //$NON-NLS-1$
    groupHandler.addGroup("empty"); //$NON-NLS-1$
    structureBuilder.add("firstGroup", "first"); //$NON-NLS-1$ //$NON-NLS-2$
    structureBuilder.addAllItemsTo(addableMock);
    verify(addableMock);
  }
}