/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.Iterator;

import net.disy.commons.core.grouped.PredefinedOrderGroupHandler;

import org.junit.Before;
import org.junit.Test;

public class PredefinedOrderGroupHandlerTest {

  private PredefinedOrderGroupHandler<String> handler;

  @Before
  public void createHandler() throws Exception {
    handler = new PredefinedOrderGroupHandler<String>("one", "two"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void respectsPredefinedOrder() throws Exception {
    assertHasGroups("one", "two"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void addsNewGroupAtEndWithoutInsertPosition() throws Exception {
    handler.addGroup("custom"); //$NON-NLS-1$
    assertHasGroups("one", "two", "custom"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  @Test
  public void respectsSpecifiedInsertPositionForNewGroups() throws Exception {
    handler.setGroupInsertPositionBefore("two"); //$NON-NLS-1$
    handler.addGroup("custom"); //$NON-NLS-1$
    assertHasGroups("one", "custom", "two"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  @Test
  public void doesNotAddExistingGroup() throws Exception {
    handler.addGroup("one"); //$NON-NLS-1$
    assertHasGroups("one", "two"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private void assertHasGroups(final String... groups) {
    final Iterator<String> iterator = handler.getGroupsInDisplayOrder().iterator();
    for (final String nextGroup : groups) {
      assertThat(iterator.next(), is(nextGroup));
    }
    assertFalse(iterator.hasNext());
  }
}