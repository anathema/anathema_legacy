/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.junit.Assert.*;

import java.util.Iterator;

import net.disy.commons.core.grouped.IGroupHandler;
import net.disy.commons.core.grouped.OrderRetainingGroupHandler;

import org.junit.Test;

public class OrderRetainingGroupHandlerTest {

  @Test
  public void stringsAreSortedAccordingToAdditionOrder() throws Exception {
    final IGroupHandler<String> handler = new OrderRetainingGroupHandler<String>();
    handler.addGroup("b"); //$NON-NLS-1$
    handler.addGroup("a"); //$NON-NLS-1$
    final Iterator<String> groupsInDisplayOrder = handler.getGroupsInDisplayOrder().iterator();
    assertEquals("b", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertEquals("a", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertFalse(groupsInDisplayOrder.hasNext());
  }

  @Test
  public void groupsAreAddedOnlyOnce() throws Exception {
    final IGroupHandler<String> handler = new OrderRetainingGroupHandler<String>();
    handler.addGroup("a"); //$NON-NLS-1$
    handler.addGroup("a"); //$NON-NLS-1$
    final Iterator<String> groupsInDisplayOrder = handler.getGroupsInDisplayOrder().iterator();
    assertEquals("a", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertFalse(groupsInDisplayOrder.hasNext());
  }

  @Test
  public void orderIsDeterminedByFirstOccurence() throws Exception {
    final IGroupHandler<String> handler = new OrderRetainingGroupHandler<String>();
    handler.addGroup("b"); //$NON-NLS-1$
    handler.addGroup("a"); //$NON-NLS-1$
    handler.addGroup("b"); //$NON-NLS-1$
    final Iterator<String> groupsInDisplayOrder = handler.getGroupsInDisplayOrder().iterator();
    assertEquals("b", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertEquals("a", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertFalse(groupsInDisplayOrder.hasNext());
  }
}