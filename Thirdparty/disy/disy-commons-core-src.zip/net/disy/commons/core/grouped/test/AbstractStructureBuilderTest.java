/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import net.disy.commons.core.grouped.ComparableGroupHandler;
import net.disy.commons.core.grouped.IStructuredItemAddable;
import net.disy.commons.core.grouped.SeparatorGroupItemStructureBuilder;

import org.easymock.EasyMock;
import org.junit.Before;

public abstract class AbstractStructureBuilderTest {

  protected SeparatorGroupItemStructureBuilder<String, Object> builder;
  protected IStructuredItemAddable<Object> addable;

  @Before
  public void createBuilder() {
    builder = new SeparatorGroupItemStructureBuilder<String, Object>(
        new ComparableGroupHandler<String>());
  }

  @SuppressWarnings("unchecked")
  @Before
  public void createStructureAddableMock() {
    addable = EasyMock.createMock(IStructuredItemAddable.class);
  }

  protected final void assertConfiguredAddition() {
    EasyMock.replay(addable);
    builder.addAllItemsTo(addable);
    EasyMock.verify(addable);
  }
}