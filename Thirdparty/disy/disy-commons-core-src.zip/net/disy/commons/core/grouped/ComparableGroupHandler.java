/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ComparableGroupHandler<G extends Comparable<G>> implements IGroupHandler<G> {

  private final List<G> groups = new ArrayList<G>();

  @Override
  public void addGroup(final G groupId) {
    if (!groups.contains(groupId)) {
      groups.add(groupId);
    }
  }

  @Override
  public Iterable<G> getGroupsInDisplayOrder() {
    Collections.sort(groups);
    return groups;
  }
}