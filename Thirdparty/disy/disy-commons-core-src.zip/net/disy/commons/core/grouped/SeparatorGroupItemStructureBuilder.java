/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped;

import java.util.Iterator;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.IterableUtilities;

public class SeparatorGroupItemStructureBuilder<G, I> extends GroupItemStructureBuilder<G, I>
    implements
    IGroupItemStructureBuilder<I> {
  public SeparatorGroupItemStructureBuilder() {
    super();
  }

  public SeparatorGroupItemStructureBuilder(final IGroupHandler<G> groupHandler) {
    super(groupHandler);
  }

  @Override
  public void addAllItemsTo(final IStructuredItemAddable<I> addable) {
    Iterable<G> groups = IterableUtilities.filter(getGroups(), new IPredicate<G>() {

      @Override
      public boolean evaluate(G value) {
        return getGroupItems(value).iterator().hasNext();
      }

    });
    Iterator<G> groupsIterator = groups.iterator();
    while (groupsIterator.hasNext()) {
      G group = groupsIterator.next();
      for (final I item : getGroupItems(group)) {
        addable.add(item);
      }
      if (groupsIterator.hasNext()) {
        addable.addSeparator();
      }
    }
  }
}