/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped;

import net.disy.commons.core.collection.MultipleValueHashMap;
import net.disy.commons.core.util.Ensure;

public class GroupItemStructureBuilder<G, I> {
  private final MultipleValueHashMap<G, I> itemsByGroupId = new MultipleValueHashMap<G, I>();
  private final IGroupHandler<G> groupHandler;

  public GroupItemStructureBuilder() {
    this(new OrderRetainingGroupHandler<G>());
  }

  public GroupItemStructureBuilder(final IGroupHandler<G> groupHandler) {
    this.groupHandler = groupHandler;
  }

  public Iterable<I> getGroupItems(final G group) {
    return itemsByGroupId.getList(group);
  }

  public Iterable<G> getGroups() {
    return groupHandler.getGroupsInDisplayOrder();
  }

  public void add(final IGroupedItem<G, I> menuItem) {
    add(menuItem.getGroupId(), menuItem.getItem());
  }

  public void add(final G groupId, final I item) {
    Ensure.ensureArgumentNotNull(item);
    Ensure.ensureArgumentNotNull(groupId);
    groupHandler.addGroup(groupId);
    itemsByGroupId.add(groupId, item);
  }

  public boolean isEmpty() {
    return itemsByGroupId.isEmpty();
  }

}
