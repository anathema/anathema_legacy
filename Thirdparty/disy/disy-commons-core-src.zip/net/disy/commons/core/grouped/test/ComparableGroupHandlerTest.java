/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.junit.Assert.*;

import java.util.Iterator;

import net.disy.commons.core.grouped.ComparableGroupHandler;
import net.disy.commons.core.grouped.IGroupHandler;

import org.junit.Test;

public class ComparableGroupHandlerTest {

  @Test
  public void stringsAreSortedAlphabetically() throws Exception {
    IGroupHandler<String> handler = new ComparableGroupHandler<String>();
    handler.addGroup("b"); //$NON-NLS-1$
    handler.addGroup("a"); //$NON-NLS-1$
    Iterator<String> groupsInDisplayOrder = handler.getGroupsInDisplayOrder().iterator();
    assertEquals("a", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertEquals("b", groupsInDisplayOrder.next()); //$NON-NLS-1$
    assertFalse(groupsInDisplayOrder.hasNext());
  }
}