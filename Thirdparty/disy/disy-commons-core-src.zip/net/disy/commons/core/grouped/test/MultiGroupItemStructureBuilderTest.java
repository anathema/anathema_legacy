/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class MultiGroupItemStructureBuilderTest extends AbstractStructureBuilderTest {
  private static final String KEY1 = "Key1"; //$NON-NLS-1$
  private static final String KEY2 = "Key2"; //$NON-NLS-1$
  private Object item11;
  private Object item12;
  private Object item21;

  @Before
  public void fillBuilder() {
    item11 = new Object();
    item12 = new Object();
    item21 = new Object();
    builder.add(KEY1, item11);
    builder.add(KEY1, item12);
    builder.add(KEY2, item21);
  }

  @Test
  public void isNotEmpty() throws Exception {
    assertFalse(builder.isEmpty());
  }

  @Test
  public void addsBothItemsWithoutSeparator() throws Exception {
    addable.add(item11);
    addable.add(item12);
    addable.addSeparator();
    addable.add(item21);
    assertConfiguredAddition();
  }
}