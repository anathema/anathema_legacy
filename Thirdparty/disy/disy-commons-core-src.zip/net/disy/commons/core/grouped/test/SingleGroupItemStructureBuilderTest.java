/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.grouped.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class SingleGroupItemStructureBuilderTest extends AbstractStructureBuilderTest {
  private static final String KEY = "Key"; //$NON-NLS-1$
  private Object item1;
  private Object item2;

  @Before
  public void fillBuilder() {
    item1 = new Object();
    item2 = new Object();
    builder.add(KEY, item1);
    builder.add(KEY, item2);
  }

  @Test
  public void isNotEmpty() throws Exception {
    assertFalse(builder.isEmpty());
  }

  @Test
  public void addsBothItemsWithoutSeparator() throws Exception {
    addable.add(item1);
    addable.add(item2);
    assertConfiguredAddition();
  }
}