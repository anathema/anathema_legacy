/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.asynchronous;

import java.util.concurrent.Executor;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.progress.DefaultCancelable;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.core.util.Ensure;

public class AsynchronousDroppingJobProcessor<T> {

  private final IJobProcessor<T> processor;

  private final Executor executor = new ThreadPoolExecutor(
      0,
      1,
      2,
      TimeUnit.SECONDS,
      new LinkedBlockingDeque<Runnable>());
  private final BooleanModel busyModel = new BooleanModel(false);

  private DefaultCancelable currentJobCancelable;

  private final IExceptionHandler exceptionHandler;

  public AsynchronousDroppingJobProcessor(
      final IJobProcessor<T> processor,
      final IExceptionHandler exceptionHandler) {
    Ensure.ensureArgumentNotNull(processor);
    Ensure.ensureArgumentNotNull(exceptionHandler);
    this.processor = processor;
    this.exceptionHandler = exceptionHandler;
  }

  public void startJob(final T job) {
    final Runnable runnable;
    synchronized (this) {
      if (currentJobCancelable != null) {
        currentJobCancelable.setCanceled(true);
      }
      currentJobCancelable = new DefaultCancelable();
      final ICancelable cancelable = currentJobCancelable;

      runnable = new Runnable() {
        @Override
        public void run() {
          busyModel.setValue(true);
          try {
            ProgressUtilities.checkInterrupted(cancelable);
            processor.process(cancelable, job);
            busyModel.setValue(false);
          }
          catch (final InterruptedException e) {
            busyModel.setValue(false);
          }
          catch (final Throwable e) {
            busyModel.setValue(false);
            exceptionHandler.handle(e);
          }
        }
      };
    }
    executor.execute(runnable);
  }

  public BooleanModel getBusyModel() {
    return busyModel;
  }

  public void cancelCurrentJob() {
    synchronized (this) {
      if (currentJobCancelable != null) {
        currentJobCancelable.setCanceled(true);
      }
      currentJobCancelable = null;
    }
  }
}