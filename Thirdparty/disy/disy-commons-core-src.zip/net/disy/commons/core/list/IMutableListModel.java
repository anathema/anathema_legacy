/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.list;

import java.util.Collection;

public interface IMutableListModel<T> extends IListModel<T> {

  public void clear();

  public void add(T item);

  public void add(T item, int index);

  public void add(T[] items);

  public void add(Collection<T> items);

  public void remove(T item);

  public void remove(Collection<T> items);

  public void removeItemAt(int index);

  public void replace(T oldItem, T newItem);

  public void setItem(T value, int index);

  public void moveValueUp(int rowIndex);

  public void moveValueDown(int rowIndex);

}