//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.list;

import net.disy.commons.core.model.IChangeableModel;

// NOT_PUBLISHED
public interface IListModel<T> extends IChangeableModel {

  public int size();

  public T getValue(int index);

}
