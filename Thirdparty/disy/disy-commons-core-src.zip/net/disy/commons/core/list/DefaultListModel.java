/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.ObjectUtilities;

public class DefaultListModel<T> extends AbstractChangeableModel implements IMutableListModel<T> {

  protected final List<T> items = new ArrayList<T>();

  public DefaultListModel() {
    //nothing to do
  }

  public DefaultListModel(final T... items) {
    this.items.addAll(Arrays.asList(items));
  }

  public DefaultListModel(final Collection<T> items) {
    this.items.addAll(items);
  }

  @Override
  public void add(final T item) {
    items.add(item);
    fireChangeEvent();
  }

  @Override
  public void add(final T item, final int index) {
    items.add(index, item);
    fireChangeEvent();
  }

  @Override
  public void add(final T[] allItems) {
    add(Arrays.asList(allItems));
  }

  @Override
  public void add(final Collection<T> allItems) {
    this.items.addAll(allItems);
    fireChangeEvent();
  }

  @Override
  public void clear() {
    this.items.clear();
    fireChangeEvent();
  }

  @Override
  public int getItemCount() {
    return items.size();
  }

  @Override
  public T getItem(final int index) {
    return items.get(index);
  }

  @Override
  public void remove(final T item) {
    items.remove(item);
    fireChangeEvent();
  }

  @Override
  public void remove(Collection<T> itemsToRemove) {
    this.items.removeAll(itemsToRemove);
    fireChangeEvent();
  }

  @Override
  public void replace(final T oldItem, final T newItem) {
    if (ObjectUtilities.equals(oldItem, newItem)) {
      return;
    }

    final int index = items.indexOf(oldItem);
    if (index == -1) {
      return;
    }

    setItem(newItem, index);
  }

  @Override
  public void setItem(final T item, final int index) {
    if (ObjectUtilities.equals(item, getItem(index))) {
      return;
    }
    items.set(index, item);
    fireChangeEvent();
  }

  @Override
  public List<T> getItemList() {
    return new ArrayList<T>(items);
  }

  @Override
  public void removeItemAt(final int index) {
    items.remove(index);
    fireChangeEvent();
  }

  @Override
  public void moveValueDown(final int index) {
    final T firstElement = items.get(index - 1);
    final T secondElement = items.get(index);
    items.set(index - 1, secondElement);
    items.set(index, firstElement);
    fireChangeEvent();
  }

  @Override
  public void moveValueUp(final int index) {
    final T firstElement = items.get(index);
    final T secondElement = items.get(index + 1);
    items.set(index, secondElement);
    items.set(index + 1, firstElement);
    fireChangeEvent();
  }

  public void setItems(final T[] items) {
    this.items.clear();
    this.items.addAll(Arrays.asList(items));
    fireChangeEvent();
  }

  @Override
  public int indexOf(Object selectedValue) {
    return items.indexOf(selectedValue);
  }

}