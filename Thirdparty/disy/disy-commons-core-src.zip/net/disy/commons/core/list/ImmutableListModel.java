/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.list;

import java.util.Arrays;
import java.util.List;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IBlock;

public class ImmutableListModel<T> implements IListModel<T> {
  private final T[] objects;

  public ImmutableListModel(final T[] objects) {
    this.objects = objects;
    Ensure.ensureArgumentNotNull(objects);
  }

  @Override
  public int getItemCount() {
    return objects.length;
  }

  @Override
  public T getItem(final int index) {
    return objects[index];
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    // nothing to do
  }

  @Override
  public void removeChangeListener(final IChangeListener listener) {
    // nothing to do
  }

  @Override
  public List<T> getItemList() {
    return Arrays.asList(objects);
  }

  @Override
  public int indexOf(Object selectedValue) {
    return getItemList().indexOf(selectedValue);
  }

  @Override
  public void doThreadSafe(IBlock block) {
    block.execute();
  }
}