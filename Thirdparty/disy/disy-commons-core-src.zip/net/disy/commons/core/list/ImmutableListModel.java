//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.list;

import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ImmutableListModel<T> implements IListModel<T> {
  private final T[] objects;

  public ImmutableListModel(T[] objects) {
    this.objects = objects;
    Ensure.ensureArgumentNotNull(objects);
  }

  public int size() {
    return objects.length;
  }

  public T getValue(int index) {
    return objects[index];
  }

  public void addChangeListener(ChangeListener listener) {
    // nothing to do
  }

  public void removeChangeListener(ChangeListener listener) {
    // nothing to do
  }

}
