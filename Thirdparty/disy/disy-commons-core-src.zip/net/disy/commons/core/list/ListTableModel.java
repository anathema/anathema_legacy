//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.list;

import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ListTableModel<T> extends AbstractTableModel {

  private final IListModel<T> listModel;
  private final String[] columnNames;

  public ListTableModel(IListModel<T> listModel, String[] columnNames) {
    Ensure.ensureArgumentNotNull(listModel);
    Ensure.ensureArgumentNotNull(columnNames);
    this.columnNames = columnNames;
    this.listModel = listModel;
    listModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        //Bugfix (gebhard) 13.04.2006: Deadlock in FilterableListTable by firing events outside EDT 
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            fireTableDataChanged();
          }
        });
      }
    });
  }

  public int getRowCount() {
    return listModel.size();
  }

  public int getColumnCount() {
    return columnNames.length;
  }

  @Override
  public String getColumnName(int column) {
    return columnNames[column];
  }

  public T getValueAt(int rowIndex, int columnIndex) {
    return listModel.getValue(rowIndex);
  }
}