/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

public class ClosureUtilities {

  public static <I, O, E extends Throwable> IInteruptableFunction<I, O, E> wrap(
      IExceptionThrowingFunctionClosure<I, O, E> closure) {
    return new ExceptionThrowingFunctionClosureToInteruptableFunctionClosureWrapper<I, O, E>(
        closure);
  }

  public static <I, E extends Throwable> IInteruptableClosure<I, E> wrap(
      IExceptionThrowingClosure<I, E> closure) {
    return new ExceptionThrowingClosureToInteruptableClosureWrapper<I, E>(closure);
  }
}
