//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.core.util.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(ObjectUtilitiesTest.class);
    suite.addTestSuite(CollectionUtilitiesTest.class);
    suite.addTestSuite(EnsureTest.class);
    suite.addTestSuite(ArrayUtilitiesTest.class);
    suite.addTestSuite(StringUtilitiesTest.class);
    suite.addTestSuite(StringBufferUtilitiesTest.class);
    suite.addTestSuite(DateUtilitiesTest.class);
    //$JUnit-END$
    return suite;
  }
}
