/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import net.disy.commons.core.util.DateUtilities;

import junit.framework.TestCase;

public class DateUtilitiesTest extends TestCase {

  private final int year = 2005;
  private final int month = 8;
  private final int day = 9;
  private final int hour = 16;
  private final int minutes = 27;
  private final int seconds = 12;
  private Calendar calendarForDateCreation;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    calendarForDateCreation = Calendar.getInstance();
    calendarForDateCreation.set(year, month, day, hour, minutes, seconds);
  }

  public void testToCalenderNormalDate() throws Exception {
    final Date date = calendarForDateCreation.getTime();
    final Calendar calendar = DateUtilities.toCalendar(date);
    assertHasExpectedDate(calendar);
    assertHasExpectedTime(calendar);
    assertTrue(calendar instanceof GregorianCalendar);
  }

  public void testToCalenderSqlDate() throws Exception {
    final java.sql.Date date = new java.sql.Date(calendarForDateCreation.getTime().getTime());
    final Calendar calendar = DateUtilities.toCalendar(date);
    assertHasExpectedDate(calendar);
    assertTrue(calendar instanceof GregorianCalendar);
  }

  public void testAddToNormalDate() throws Exception {
    final Date date = calendarForDateCreation.getTime();
    final Class<?> dateType = java.util.Date.class;
    assertIncreasedCorrectly(date, Calendar.YEAR, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.MONTH, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.DATE, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.HOUR, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.MINUTE, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.SECOND, 2, dateType);
  }

  public void testAddToSqlDate() throws Exception {
    final java.sql.Date date = new java.sql.Date(calendarForDateCreation.getTime().getTime());
    final Class<?> dateType = java.sql.Date.class;
    assertIncreasedCorrectly(date, Calendar.YEAR, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.MONTH, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.DATE, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.HOUR, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.MINUTE, 2, dateType);
    assertIncreasedCorrectly(date, Calendar.SECOND, 2, dateType);
  }

  private void assertIncreasedCorrectly(
      final Date date,
      final int field,
      final int value,
      final Class<?> expectedDateType) {
    final Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(field, calendar.get(field) + value);
    final Date expectedDate = calendar.getTime();
    final Date increasedDate = DateUtilities.add(date, field, 2);
    assertEquals(expectedDate, increasedDate);
    assertEquals(expectedDateType, increasedDate.getClass());
  }

  private void assertHasExpectedDate(final Calendar calendar) {
    assertEquals(year, calendar.get(Calendar.YEAR));
    assertEquals(month, calendar.get(Calendar.MONTH));
    assertEquals(day, calendar.get(Calendar.DATE));
  }

  private void assertHasExpectedTime(final Calendar calendar) {
    assertEquals(hour, calendar.get(Calendar.HOUR_OF_DAY));
    assertEquals(minutes, calendar.get(Calendar.MINUTE));
    assertEquals(seconds, calendar.get(Calendar.SECOND));
  }
}
