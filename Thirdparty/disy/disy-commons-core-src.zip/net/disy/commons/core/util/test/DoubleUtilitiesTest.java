/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.junit.Assert.*;
import net.disy.commons.core.util.DoubleUtilities;

import org.junit.Test;

public class DoubleUtilitiesTest {

  @Test
  public void testIsNullOrUndefined() {
    assertTrue(DoubleUtilities.isNullOrUndefined(null));
    assertTrue(DoubleUtilities.isNullOrUndefined(Double.NaN));
    assertTrue(DoubleUtilities.isNullOrUndefined(Double.POSITIVE_INFINITY));
    assertTrue(DoubleUtilities.isNullOrUndefined(Double.NEGATIVE_INFINITY));
    assertFalse(DoubleUtilities.isNullOrUndefined(0d));
    assertFalse(DoubleUtilities.isNullOrUndefined(Double.MAX_VALUE));
    assertFalse(DoubleUtilities.isNullOrUndefined(Double.MIN_VALUE));
    assertFalse(DoubleUtilities.isNullOrUndefined(Double.MIN_NORMAL));
  }
}
