// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

//NOT_PUBLISHED
public interface IKeyProvider<T, U> {

  public T getKey(U object);

}
