package net.disy.commons.core.util;

public interface IBlock {
  public void execute(Object each);
}
