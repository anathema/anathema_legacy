/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.util.HashMap;
import java.util.Map;

import net.disy.commons.core.predicate.IPredicate;

public class MapUtilities {

  public static <V, K> Map<K, V> filter(final Map<K, V> map, final IPredicate<K> predicate) {
    final Map<K, V> result = new HashMap<K, V>();
    for (final K key : map.keySet()) {
      if (predicate.evaluate(key)) {
        result.put(key, map.get(key));
      }
    }
    return result;
  }

  public static <V, K> Map<K, V> transform(
      final Iterable<V> values,
      final ITransformer<V, K> transformer) {
    final Map<K, V> result = new HashMap<K, V>();
    for (V value : values) {
      result.put(transformer.transform(value), value);
    }
    return result;
  }

}
