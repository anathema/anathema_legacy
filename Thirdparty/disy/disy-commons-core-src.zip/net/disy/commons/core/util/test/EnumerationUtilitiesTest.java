/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;

import java.util.Enumeration;

import net.disy.commons.core.util.EnumerationUtilities;

import org.junit.Test;

public class EnumerationUtilitiesTest {

  @Test
  public void getAsString_emptyEnumeration() throws Exception {
    final Enumeration<Integer> enumeration = createMock(Enumeration.class);
    expect(enumeration.hasMoreElements()).andReturn(false);
    replay(enumeration);
    assertEquals("{}", EnumerationUtilities.getAsString(enumeration)); //$NON-NLS-1$
    verify(enumeration);
  }

  @Test
  public void getAsString_twoElementsInEnumeration() throws Exception {
    final Enumeration<Integer> enumeration = createMock(Enumeration.class);
    expect(enumeration.hasMoreElements()).andReturn(true).times(2);
    expect(enumeration.hasMoreElements()).andReturn(false);
    expect(enumeration.nextElement()).andReturn(12);
    expect(enumeration.nextElement()).andReturn(34);
    replay(enumeration);
    assertEquals("{12, 34}", EnumerationUtilities.getAsString(enumeration)); //$NON-NLS-1$
    verify(enumeration);
  }

}
