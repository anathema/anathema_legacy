/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.util.Arrays;

public class ObjectUtilities {

  public final static boolean equals(Object[] o1, Object[] o2) {
    if (o1 == null && o2 == null) {
      return true;
    }
    if (o1 == null || o2 == null || o1.length != o2.length) {
      return false;
    }
    for (int i = 0; i < o1.length; ++i) {
      if (!equals(o1[i], o2[i])) {
        return false;
      }
    }
    return true;
  }

  public final static boolean equals(Object o1, Object o2) {
    return (o1 == null && o2 == null) || (o1 != null && o1.equals(o2));
  }

  public final static boolean equalsIgnoreCase(String s1, String s2) {
    return (s1 == null && s2 == null) || (s1 != null && s1.equalsIgnoreCase(s2));
  }

  /**
   * Returns the hashCode from Object o or 1 if o==null.
   */
  public final static int getHashCode(Object... objects) {
    if (objects.length == 1) {
      return hashCode(objects[0]);
    }
    return Arrays.hashCode(objects);
  }

  private final static int hashCode(Object object) {
    return (object == null) ? 1 : object.hashCode();
  }

  public static int getHashCode(boolean value) {
    return value ? Boolean.TRUE.hashCode() : Boolean.FALSE.hashCode();
  }

  public static int getHashCode(double value) {
    return hashCode(Double.valueOf(value));
  }

  public static int getHashCode(long value) {
    return hashCode(Long.valueOf(value));
  }

  public static boolean equals(double d1, double d2) {
    return d1 == d2 || Double.isNaN(d1) && Double.isNaN(d2);
  }

  public static boolean equals(float f1, float f2) {
    return f1 == f2 || Float.isNaN(f1) && Float.isNaN(f2);
  }

  public static String toString(Object object) {
    return object == null ? null : object.toString();
  }

  public static boolean toStringEquals(Object value1, Object value2) {
    return equals(toString(value1), toString(value2));
  }

  public static <T extends Comparable<? super T>> int compare(T c1, T c2) {
    if (c1 == null && c2 == null) {
      return 0;
    }
    if (c1 == null) {
      return -1;
    }
    if (c2 == null) {
      return 1;
    }
    return c1.compareTo(c2);
  }

  public static Object[] toArray(Object... objects) {
    return objects;
  }
}