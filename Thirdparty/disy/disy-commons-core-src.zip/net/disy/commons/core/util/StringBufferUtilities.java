// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 30.11.2005
package net.disy.commons.core.util;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

// NOT_PUBLISHED
public class StringBufferUtilities {

  private StringBufferUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static void append(StringBuffer buffer, char character, int count) {
    Ensure.ensureArgumentTrue("Positive number of characters must be appended.", count >= 0); //$NON-NLS-1$
    for (int index = 0; index < count; index++) {
      buffer.append(character);
    }
  }
}