// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

//NOT_PUBLISHED
public interface ITransformer<I, O> {
  public O transform(I input);
}
