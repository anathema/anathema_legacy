// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 30.11.2005
package net.disy.commons.core.util.test;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.ISimpleBlock;
import net.disy.commons.core.util.StringBufferUtilities;

// NOT_PUBLISHED
public class StringBufferUtilitiesTest extends CoreTestCase {

  public void testAppendCharacters() throws Exception {
    StringBuffer buffer = new StringBuffer("test"); //$NON-NLS-1$
    StringBufferUtilities.append(buffer, 'X', 3);
    assertEquals("testXXX", buffer.toString()); //$NON-NLS-1$
  }

  public void testAppendNoCharacters() throws Exception {
    assertThrowsException(IllegalArgumentException.class, new ISimpleBlock() {
      public void execute() {
        StringBufferUtilities.append(new StringBuffer(), 'X', -3);
      }
    });
  }
}