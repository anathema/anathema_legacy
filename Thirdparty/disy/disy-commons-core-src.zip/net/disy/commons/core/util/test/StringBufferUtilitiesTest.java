/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.junit.Assert.*;

import net.disy.commons.core.util.StringBufferUtilities;

import org.junit.Test;

public class StringBufferUtilitiesTest {

  @Test
  public void testAppendCharacters() throws Exception {
    final StringBuffer buffer = new StringBuffer("test"); //$NON-NLS-1$
    StringBufferUtilities.append(buffer, 'X', 3);
    assertEquals("testXXX", buffer.toString()); //$NON-NLS-1$
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAppendNoCharacters() throws Exception {
    StringBufferUtilities.append(new StringBuffer(), 'X', -3);
  }
}