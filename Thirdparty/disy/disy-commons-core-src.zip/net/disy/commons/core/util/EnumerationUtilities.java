/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Vector;

public class EnumerationUtilities {

  public static String getAsString(final Enumeration<?> enumeration) {
    final StringBuffer buffer = new StringBuffer("{"); //$NON-NLS-1$
    while (enumeration.hasMoreElements()) {
      buffer.append(enumeration.nextElement());
      buffer.append(", "); //$NON-NLS-1$
    }
    if (buffer.length() > 1) {
      buffer.delete(buffer.length() - 2, buffer.length());
    }
    buffer.append("}"); //$NON-NLS-1$
    return buffer.toString();
  }

  public static <T> T[] toArray(final Enumeration<T> items, final Class<T> itemClass) {
    final List<T> itemList = new ArrayList<T>();
    while (items.hasMoreElements()) {
      itemList.add(items.nextElement());
    }

    return itemList.toArray((T[]) Array.newInstance(itemClass, itemList.size()));
  }

  public static <I, O> Enumeration<O> transform(
      Enumeration<I> inputs,
      ITransformer<I, O> transformer) {
    Vector<O> outputs = new Vector<O>();
    while (inputs.hasMoreElements()) {
      outputs.add(transformer.transform(inputs.nextElement()));
    }
    return outputs.elements();
  }
}
