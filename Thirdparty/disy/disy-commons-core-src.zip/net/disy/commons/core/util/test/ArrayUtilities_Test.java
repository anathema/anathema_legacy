/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.List;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;

import org.junit.Test;

@SuppressWarnings("nls")
public class ArrayUtilities_Test {

  @Test
  public void testMin() throws Exception {
    assertEquals(Integer.MAX_VALUE, ArrayUtilities.min(new int[0]));
    assertEquals(7, ArrayUtilities.min(new int[]{ 7 }));
    assertEquals(7, ArrayUtilities.min(new int[]{ 10, 7, 89 }));
  }

  @Test
  public void testConcatEmptyArrays() throws Exception {
    final String[] mergedArray = ArrayUtilities.concat(String.class, new String[0], new String[0]);
    assertEquals(0, mergedArray.length);
  }

  @Test
  public void testConcatLeftArrayEmpty() throws Exception {
    final String[] mergedArray = ArrayUtilities.concat(
        String.class,
        new String[0],
        new String[]{ "a" }); //$NON-NLS-1$
    assertEquals(1, mergedArray.length);
    assertEquals("a", mergedArray[0]); //$NON-NLS-1$
  }

  @Test
  public void testConcatRightArrayEmpty() throws Exception {
    final String[] mergedArray = ArrayUtilities.concat(
        String.class,
        new String[]{ "a" }, new String[0]); //$NON-NLS-1$
    assertEquals(1, mergedArray.length);
    assertEquals("a", mergedArray[0]); //$NON-NLS-1$
  }

  @Test
  public void testConcatArraysWithSuperType() {
    final Number[] concat = ArrayUtilities.concat(
        Number.class,
        new Integer[]{ new Integer(1) },
        new Double[]{ new Double(42.2) });
    assertArrayEquals(new Number[]{ new Integer(1), new Double(42.2) }, concat);
  }

  @Test
  public void testConcatArrayWithSingleObject() {
    final Number[] concat = ArrayUtilities.concat(
        Number.class,
        new Integer[]{ new Integer(1) },
        new Double(42.2));
    assertArrayEquals(new Number[]{ new Integer(1), new Double(42.2) }, concat);
  }

  @Test
  public void testConcatSingleObjectWithArray() {
    final Number[] concat = ArrayUtilities.concat(
        new Double(42.2),
        new Integer[]{ new Integer(1) },
        Number.class);
    assertArrayEquals(new Number[]{ new Double(42.2), new Integer(1) }, concat);
  }

  @Test
  public void subarrayArrayClass() throws Exception {
    final String[] originalArray = new String[]{ "first" }; //$NON-NLS-1$
    final String[] subArray = ArrayUtilities.subArray(originalArray, 0, 0);
    assertEquals(String[].class, subArray.getClass());
  }

  @Test
  public void subarrayWithSameStartAndEndIndex() throws Exception {
    final String[] originalArray = new String[]{ "first", "second", "third" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final String[] subArray = ArrayUtilities.subArray(originalArray, 0, 0);
    assertArrayEquals(new String[0], subArray);
    assertEquals(String[].class, subArray.getClass());
  }

  @Test
  public void subarrayWholeArray() throws Exception {
    final String[] originalArray = new String[]{ "first", "second", "third" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final String[] subArray = ArrayUtilities.subArray(originalArray, 0, 3);
    assertArrayEquals(originalArray, subArray);
  }

  @Test
  public void subarrayInBetween() throws Exception {
    final String[] originalArray = new String[]{ "first", "second", "third", "forth" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    final String[] subArray = ArrayUtilities.subArray(originalArray, 1, 3);
    assertArrayEquals(new String[]{ "second", "third" }, subArray); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void getFirstIfAnyOnEmpty() {
    assertNull(ArrayUtilities.getFirstIfAny(new String[0]));
  }

  @Test
  public void getFirstIfAnyOnSingleElement() {
    assertEquals("a", ArrayUtilities.getFirstIfAny(new String[]{ "a" })); //$NON-NLS-1$//$NON-NLS-2$
  }

  @Test
  public void getFirstIfAnyOnMultipleElements() {
    assertEquals("b", ArrayUtilities.getFirstIfAny(new String[]{ "b", "a" })); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$
  }

  @Test
  public void reverse() {
    assertArrayEquals(new String[]{ "a" }, ArrayUtilities.reverse(new String[]{ "a" })); //$NON-NLS-1$//$NON-NLS-2$
    assertArrayEquals(new String[]{ "b", "a" }, ArrayUtilities.reverse(new String[]{ "a", "b" })); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$
    assertArrayEquals(
        new String[]{ "c", "b", null, "a" }, ArrayUtilities.reverse(new String[]{ "a", null, "b", "c" })); //$NON-NLS-1$//$NON-NLS-2$ //$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$
  }

  @Test
  public void getFirstReturnsNullIfNoneFound() throws Exception {
    assertNull(ArrayUtilities.getFirst(new String[]{ "foo" }, new IPredicate<String>() { //$NON-NLS-1$
          @Override
          public boolean evaluate(final String value) {
            return false;
          }
        }));
  }

  @Test
  public void getFirstReturnsNotFoundValueIfNoneFound() throws Exception {
    assertEquals("bar", ArrayUtilities.getFirst(new String[]{ "foo" }, new IPredicate<String>() { //$NON-NLS-1$ //$NON-NLS-2$
          @Override
          public boolean evaluate(final String value) {
            return false;
          }
        },
        "bar")); //$NON-NLS-1$
  }

  @Test
  public void getSharedSuperTypeForSameClass() {
    assertEquals(String.class, ArrayUtilities.getSharedSuperType(String.class, String.class));
  }

  @Test
  public void getSharedSuperTypeForCommonSuperclass() {
    assertEquals(Number.class, ArrayUtilities.getSharedSuperType(Double.class, Integer.class));
  }

  @Test
  public void toCharPrimitive() {
    assertArrayEquals(new char[0], ArrayUtilities.toPrimitive(new Character[]{}));
    assertArrayEquals(
        new char[]{ 'a' },
        ArrayUtilities.toPrimitive(new Character[]{ new Character('a') }));
    assertArrayEquals(
        new char[]{ 'b', 'a' },
        ArrayUtilities.toPrimitive(new Character[]{ new Character('b'), new Character('a') }));
  }

  @Test
  public void toLongPrimitive() {
    assertArrayEquals(new long[0], ArrayUtilities.toPrimitive(new Long[]{}));
    assertArrayEquals(
        new long[]{ Long.MAX_VALUE },
        ArrayUtilities.toPrimitive(new Long[]{ Long.valueOf(Long.MAX_VALUE) }));
    assertArrayEquals(
        new long[]{ Long.MAX_VALUE, Long.MIN_VALUE },
        ArrayUtilities.toPrimitive(new Long[]{
            Long.valueOf(Long.MAX_VALUE),
            Long.valueOf(Long.MIN_VALUE) }));
  }

  @Test
  public void toIntPrimitive() {
    assertArrayEquals(new int[0], ArrayUtilities.toPrimitive(new Integer[]{}));
    assertArrayEquals(
        new int[]{ Integer.MAX_VALUE },
        ArrayUtilities.toPrimitive(new Integer[]{ Integer.valueOf(Integer.MAX_VALUE) }));
    assertArrayEquals(
        new int[]{ Integer.MAX_VALUE, Integer.MIN_VALUE },
        ArrayUtilities.toPrimitive(new Integer[]{
            Integer.valueOf(Integer.MAX_VALUE),
            Integer.valueOf(Integer.MIN_VALUE) }));
  }

  @Test
  public void representsNullArrayAsNull() throws Exception {
    assertEquals(null, net.disy.commons.core.util.ArrayUtilities.getRepresentation((Object[]) null));
  }

  @Test
  public void testGetRepresentationFromObjectArray() {
    assertEquals("[]", net.disy.commons.core.util.ArrayUtilities.getRepresentation(new Object[]{}));
    assertEquals(
        "[a]",
        net.disy.commons.core.util.ArrayUtilities.getRepresentation(new Object[]{ "a" }));
    assertEquals(
        "[b,c]",
        net.disy.commons.core.util.ArrayUtilities.getRepresentation(new Object[]{ "b", "c" }));
    assertEquals(
        "[b,[c,d]]",
        net.disy.commons.core.util.ArrayUtilities.getRepresentation(new Object[]{
            "b",
            new Object[]{ "c", "d" } }));
  }

  @Test
  public void testIsNotEmpty() {
    assertFalse(net.disy.commons.core.util.ArrayUtilities.isNotEmpty(null));
    assertFalse(net.disy.commons.core.util.ArrayUtilities.isNotEmpty(new String[0]));
    assertTrue(net.disy.commons.core.util.ArrayUtilities.isNotEmpty(new Integer[]{ 12, 356 }));
  }

  @Test
  public void segmentizeToOne() {
    Object[] values = new Object[]{ 0, 1, 2, 3, 4, 5, 6, 7, 9, 10 };
    List<Object[]> segments = ArrayUtilities.segmentize(values, 10, Object[].class);
    assertThat(segments.size(), equalTo(1));
    assertThat(segments.get(0), equalTo(values));
  }

  @Test
  public void segmentizeToTwo() {
    Object[] values = new Object[]{ 0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 0, 1, 2, 3, 4, 5 };
    Object[] maxSizeSegment = new Object[]{ 0, 1, 2, 3, 4, 5, 6, 7, 9, 10 };
    Object[] restSegment = new Object[]{ 0, 1, 2, 3, 4, 5 };
    List<Object[]> segments = ArrayUtilities.segmentize(values, 10, Object[].class);
    assertThat(segments.size(), equalTo(2));
    assertThat(segments.get(0), equalTo(maxSizeSegment));
    assertThat(segments.get(1), equalTo(restSegment));
  }
}