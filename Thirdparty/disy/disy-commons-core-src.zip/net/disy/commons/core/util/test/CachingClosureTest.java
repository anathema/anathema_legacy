/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import net.disy.commons.core.util.CachingClosure;
import net.disy.commons.core.util.IReturningClosure;

import org.junit.Before;
import org.junit.Test;

@SuppressWarnings({ "unchecked", "nls" })
public class CachingClosureTest {
  private IReturningClosure<String, IOException> closure;
  private CachingClosure<String, IOException> cachingClosure;

  @Before
  public void init() {
    closure = mock(IReturningClosure.class);
    cachingClosure = new CachingClosure<String, IOException>(closure);
  }

  @Test
  public void returnsResultFromClosureMethod() throws Exception {
    when(closure.execute()).thenReturn("foo");
    assertThat(cachingClosure.execute(), is("foo"));
  }

  @Test
  public void callsClosureMethodOnlyOnce() throws Exception {
    when(closure.execute()).thenReturn("foo");
    assertThat(cachingClosure.execute(), is("foo"));
    assertThat(cachingClosure.execute(), is("foo"));
    verify(closure, times(1)).execute();
  }

  @Test
  public void callsClosureMethodOnlyOnceOnNullValue() throws Exception {
    when(closure.execute()).thenReturn(null);
    assertThat(cachingClosure.execute(), is(nullValue()));
    assertThat(cachingClosure.execute(), is(nullValue()));
    verify(closure, times(1)).execute();
  }

  @Test
  public void callsClosureMethodOnlyOnceButRethrowsExceptionOnException() throws Exception {
    when(closure.execute()).thenThrow(new IOException());
    try {
      cachingClosure.execute();
      fail();
    }
    catch (IOException expexted) {
      // nothing to do
    }
    try {
      cachingClosure.execute();
      fail();
    }
    catch (IOException expexted) {
      // nothing to do
    }
  }

  @Test
  public void callsClosureAgainOnReset() throws Exception {
    when(closure.execute()).thenReturn("foo");
    assertThat(cachingClosure.execute(), is("foo"));
    cachingClosure.reset();
    assertThat(cachingClosure.execute(), is("foo"));
    verify(closure, times(2)).execute();
  }

}
