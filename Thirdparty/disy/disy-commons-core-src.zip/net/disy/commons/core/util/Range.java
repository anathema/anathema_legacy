/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.util.Set;
import java.util.TreeSet;

/**
 * Utility class representing an integer interval.
 * 
 * @author Sandra Sieroux
 */
public class Range {

  private final int lowerBound;
  private final int upperBound;

  public Range(final int lowerBound, final int upperBound) {
    if (lowerBound > upperBound) {
      throw new IllegalArgumentException("LowerBound may not be less than upperBound: " //$NON-NLS-1$
          + lowerBound
          + " " //$NON-NLS-1$
          + upperBound);
    }
    this.lowerBound = lowerBound;
    this.upperBound = upperBound;
  }

  public int getLowerBound() {
    return lowerBound;
  }

  public int getUpperBound() {
    return upperBound;
  }

  public boolean contains(final int value) {
    return value >= lowerBound && value <= upperBound;
  }

  public Set<String> getStringSet() {
    final Set<String> content = new TreeSet<String>();
    for (int value = lowerBound; value <= upperBound; value++) {
      content.add(String.valueOf(value));
    }
    return content;
  }

  @Override
  public String toString() {
    return "Range[" + getLowerBound() + "," + getUpperBound() + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  public int getWidth() {
    return getUpperBound() - getLowerBound();
  }
}