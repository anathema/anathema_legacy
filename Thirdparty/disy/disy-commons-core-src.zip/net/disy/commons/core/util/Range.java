package net.disy.commons.core.util;

import java.util.Set;
import java.util.TreeSet;

/**
 * Utility class representing an integer interval.
 * 
 * @author Sandra Sieroux
 */
public class Range {
  
  private int lowerBound;
  private int upperBound;

  public Range(int lowerBound, int upperBound) {
    this.lowerBound = lowerBound;
    this.upperBound = upperBound;
  }
  
  public int getLowerBound() {
    return lowerBound;
  }

  public int getUpperBound() {
    return upperBound;
  }
  
  public boolean contains(int value) {
    return value >= lowerBound && value <= upperBound;
  }
  
  public Set getStringSet() {
    Set content = new TreeSet();
    for (int value = lowerBound; value <= upperBound; value++) {
      content.add(String.valueOf(value));
    }
    return content;
  }
  
  public String toString() {
    return "Range[" + getLowerBound() + "," + getUpperBound() + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
  
  public int getWidth() {
    return getUpperBound() - getLowerBound();
  }
  
}
