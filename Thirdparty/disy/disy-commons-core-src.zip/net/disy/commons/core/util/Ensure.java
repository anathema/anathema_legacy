// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Arrays;
import java.util.Map;

/**
 * Provides convenient methods for checking contract parameters.
 */
public class Ensure {

  /** @deprecated As of 16.02.2005 (gebhard) */
  @Deprecated
  protected Ensure() {
    //no instance available
  }

  public static void ensureNotNull(String message, Object object) {
    ensureTrue(message, object != null);
  }

  public static void ensureArgumentNotNull(String message, Object object)
      throws IllegalArgumentException {
    ensureArgumentTrue(message, object != null);
  }

  public static void ensureNotNull(Object object) {
    ensureNotNull("Object must not be null", object); //$NON-NLS-1$
  }

  public static void ensureArgumentNotNull(Object object) throws IllegalArgumentException {
    ensureArgumentNotNull("Object must not be null", object); //$NON-NLS-1$
  }

  /**
   * @deprecated as of 29.06.2004 (sieroux), use {@link #ensureFalse(String, boolean)} instead
   */
  @Deprecated
  public static void ensureFalse(boolean state) {
    ensureTrue("boolean must be false", !state); //$NON-NLS-1$
  }

  public static void ensureFalse(String message, boolean state) {
    ensureTrue(message, !state);
  }

  /**
   * @deprecated as of 29.06.2004 (sieroux), use {@link #ensureTrue(String, boolean)} instead
   */
  @Deprecated
  public static void ensureTrue(boolean state) {
    ensureTrue("boolean must be true", state); //$NON-NLS-1$
  }

  /**
   * @deprecated as of 29.06.2004 (sieroux), use {@link #ensureArgumentTrue(String, boolean)} instead
   */
  @Deprecated
  public static void ensureArgumentTrue(boolean state) throws IllegalArgumentException {
    ensureArgumentTrue("boolean must be true", state); //$NON-NLS-1$
  }

  public static void ensureTrue(String message, boolean state) {
    if (!state) {
      throw new ContractFailedException(message);
    }
  }

  public static void ensureArgumentTrue(String message, boolean state)
      throws IllegalArgumentException {
    if (!state) {
      throw new IllegalArgumentException(message);
    }
  }

  public static void ensureArgumentEquals(String message, Object expected, Object argument) {
    ensureArgumentTrue(message, ObjectUtilities.equals(expected, argument));
  }

  public static void ensureArgumentEquals(String message, int expected, int argument) {
    ensureArgumentTrue(message, expected == argument);
  }

  public static void ensureArrayIndex(int index, int minIndex, int maxIndex) {
    if (index < minIndex) {
      throw new ArrayIndexOutOfBoundsException(index + " < " + minIndex); //$NON-NLS-1$
    }
    else if (index > maxIndex) {
      throw new ArrayIndexOutOfBoundsException(index + " > " + maxIndex); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentFalse(String message, boolean argumentState) {
    ensureArgumentTrue(message, !argumentState);
  }

  public static void ensureArgumentArrayContentsNotNull(Object[] arguments) {
    ensureArgumentArrayContentsNotNull("Array contents must not be null", arguments); //$NON-NLS-1$
  }

  public static void ensureArgumentArrayContentsNotNull(String message, Object[] arguments) {
    if (arguments == null) {
      return;
    }
    for (int i = 0; i < arguments.length; i++) {
      ensureArgumentNotNull(message, arguments[i]);
    }
  }

  public static void ensureValueWithin(double value, double minValue, double maxValue) {
    if (value < minValue) {
      throw new IllegalArgumentException(value + " < " + minValue); //$NON-NLS-1$
    }
    else if (value > maxValue) {
      throw new ArrayIndexOutOfBoundsException(value + " > " + maxValue); //$NON-NLS-1$
    }
  }

  public static void ensureEqual(Object obj1, Object obj2) {
    if (!ObjectUtilities.equals(obj1, obj2)) {
      throw new ContractFailedException("The Objects " + obj1 + " and " + obj2 + " are not equal."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
  }

  /**
   * @deprecated as of 29.06.2004 (sieroux), use {@link #ensureArgumentFalse(String, boolean)} instead
   */
  @Deprecated
  public static void ensureArgumentFalse(boolean argumentState) {
    ensureArgumentTrue(!argumentState);
  }

  public static void ensureArgumentEquals(int expected, int actual) {
    ensureArgumentEquals("", expected, actual); //$NON-NLS-1$
  }

  public static void ensureArgumentInstanceOf(Object value, Class expectedClass) {
    ensureArgumentNotNull(value);
    if (!expectedClass.isInstance(value)) {
      throw new IllegalArgumentException("Illegal class '" + value.getClass() + "'"); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static void ensureClassAssignableFrom(Class<?> providedClass, Class<?> expectedClass) {
    ensureArgumentNotNull(providedClass);
    if (!expectedClass.isAssignableFrom(providedClass)) {
      throw new IllegalArgumentException(
          "Illegal class: expected class '" + expectedClass.getName() + "' is not assignable from provided class '" + providedClass + '\''); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static void ensureNull(Object object) {
    ensureTrue("Object must be null, was " + object, object == null); //$NON-NLS-1$
  }

  public static void ensureArgumentIndexInBounds(int index, Range range) {
    if (!range.contains(index)) {
      throw new IllegalArgumentException(index + " not within " + range); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentArrayContains(Object[] array, Object value) {
    ensureArgumentTrue(Arrays.asList(array).contains(value));
  }

  public static void ensureArgumentArrayContains(String message, Object[] array, Object value) {
    ensureArgumentTrue(message, Arrays.asList(array).contains(value));
  }

  public static void ensureArgumentNull(String message, Object value) {
    if (value != null) {
      throw new IllegalArgumentException(message);
    }
  }

  public static void ensureNull(String message, Object value) {
    if (value != null) {
      throw new ContractFailedException(message);
    }
  }

  public static void ensureEqual(long expected, long actual) {
    ensureTrue("expected " + expected + ", was " + actual, expected == actual); //$NON-NLS-1$ //$NON-NLS-2$
  }
  
  public static void ensureArgumentNotNullOrTrimmedEmpty(String argumentValue) {
    ensureArgumentNotNullOrTrimmedEmpty("Argument", argumentValue); //$NON-NLS-1$
  }

  public static void ensureArgumentNotNullOrTrimmedEmpty(String argumentName, String argumentValue) {
    if (argumentValue == null) {
      String message = argumentName + " must not be null"; //$NON-NLS-1$
      throw new IllegalArgumentException(message);
    }
    
    if(argumentValue.trim().length() == 0) {
      String message = argumentName + " must not be trimmed empty"; //$NON-NLS-1$ 
      throw new IllegalArgumentException(message);      
    }
  }

  public static void ensureArgumentNotEmpty(Map map) {
    if(map.isEmpty()) {
      throw new IllegalArgumentException("Map must not be empty."); //$NON-NLS-1$
    }
  }
}