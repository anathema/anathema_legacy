/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import static java.text.MessageFormat.*;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Provides convenient methods for checking contract parameters.
 */
public class Ensure {

  public static void ensureNotNull(final String message, final Object object) {
    ensureTrue(message, object != null);
  }

  public static void ensureArgumentNotNull(final String message, final Object object)
      throws IllegalArgumentException {
    ensureArgumentTrue(message, object != null);
  }

  public static void ensureNotNull(final Object object) {
    ensureNotNull("Object must not be null", object); //$NON-NLS-1$
  }

  public static void ensureArgumentNotNull(final Object object) throws IllegalArgumentException {
    ensureArgumentNotNull("Object must not be null", object); //$NON-NLS-1$
  }

  public static void ensureFalse(final String message, final boolean state) {
    ensureTrue(message, !state);
  }

  public static void ensureTrue(final String message, final boolean state) {
    if (!state) {
      throw new ContractFailedException(message);
    }
  }

  public static void ensureArgumentTrue(final String message, final boolean state)
      throws IllegalArgumentException {
    if (!state) {
      throw new IllegalArgumentException(message);
    }
  }

  public static void ensureArgumentEquals(
      final String message,
      final Object expected,
      final Object argument) {
    ensureArgumentTrue(message, ObjectUtilities.equals(expected, argument));
  }

  public static void ensureArgumentEquals(
      final String message,
      final int expected,
      final int argument) {
    ensureArgumentTrue(message, expected == argument);
  }

  public static void ensureArrayIndex(final int index, final int minIndex, final int maxIndex) {
    if (index < minIndex) {
      throw new ArrayIndexOutOfBoundsException(index + " < " + minIndex); //$NON-NLS-1$
    }
    else if (index > maxIndex) {
      throw new ArrayIndexOutOfBoundsException(index + " > " + maxIndex); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentFalse(final String message, final boolean argumentState) {
    ensureArgumentTrue(message, !argumentState);
  }

  public static void ensureArgumentArrayContentsNotNull(final Object[] arguments) {
    if (arguments == null) {
      return;
    }
    final String message = "Array contents must not be null"; //$NON-NLS-1$
    for (int i = 0; i < arguments.length; i++) {
      ensureArgumentNotNull(message + " at index " + i + " (0.." + (arguments.length - 1) + ')', //$NON-NLS-1$ //$NON-NLS-2$
          arguments[i]);
    }
  }

  public static void ensureValueWithin(
      final double value,
      final double minValue,
      final double maxValue) {
    if (value < minValue) {
      throw new IllegalArgumentException(value + " < " + minValue); //$NON-NLS-1$
    }
    else if (value > maxValue) {
      throw new ArrayIndexOutOfBoundsException(value + " > " + maxValue); //$NON-NLS-1$
    }
  }

  public static void ensureEqual(final Object obj1, final Object obj2) {
    if (!ObjectUtilities.equals(obj1, obj2)) {
      throw new ContractFailedException("The Objects " + obj1 + " and " + obj2 + " are not equal."); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    }
  }

  public static void ensureArgumentEquals(final int expected, final int actual) {
    ensureArgumentEquals(format("expected {0}, actual {1}", expected, actual), expected, actual); //$NON-NLS-1$
  }

  public static void ensureArgumentInstanceOf(final Object value, final Class<?> expectedClass) {
    ensureArgumentNotNull(value);
    if (!expectedClass.isInstance(value)) {
      throw new IllegalArgumentException(format(
          "Illegal class {0} - expected an instance of {1}",
          value.getClass(),
          expectedClass));
    }
  }

  public static void ensureClassAssignableFrom(
      final Class<?> providedClass,
      final Class<?> expectedClass) {
    ensureArgumentNotNull(providedClass);
    if (!expectedClass.isAssignableFrom(providedClass)) {
      throw new IllegalArgumentException(
          "Illegal class: expected class '" + expectedClass.getName() + "' is not assignable from provided class '" + providedClass + '\''); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static void ensureNull(final Object object) {
    ensureTrue("Object must be null, was " + object, object == null); //$NON-NLS-1$
  }

  public static void ensureArgumentIndexInBounds(final int index, final Range range) {
    if (!range.contains(index)) {
      throw new IllegalArgumentException(index + " not within " + range); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentArrayContains(final Object[] array, final Object value) {
    ensureArgumentTrue("Array does not contain " + value, Arrays.asList(array).contains(value)); //$NON-NLS-1$
  }

  public static void ensureArgumentArrayContains(
      final String message,
      final Object[] array,
      final Object value) {
    ensureArgumentTrue(message, Arrays.asList(array).contains(value));
  }

  public static void ensureArgumentNull(final String message, final Object value) {
    if (value != null) {
      throw new IllegalArgumentException(message);
    }
  }

  public static void ensureNull(final String message, final Object value) {
    if (value != null) {
      throw new ContractFailedException(message);
    }
  }

  public static void ensureEqual(final long expected, final long actual) {
    ensureTrue("expected " + expected + ", was " + actual, expected == actual); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public static void ensureArgumentNotNullOrTrimmedEmpty(final String argumentValue) {
    ensureArgumentNotNullOrTrimmedEmpty("Argument", argumentValue); //$NON-NLS-1$
  }

  public static void ensureArgumentNotNullOrTrimmedEmpty(
      final String argumentName,
      final String argumentValue) {
    if (argumentValue == null) {
      final String message = argumentName + " must not be null"; //$NON-NLS-1$
      throw new IllegalArgumentException(message);
    }
    if (argumentValue.trim().length() == 0) {
      final String message = argumentName + " must not be trimmed empty"; //$NON-NLS-1$
      throw new IllegalArgumentException(message);
    }
  }

  public static void ensureArgumentNotEmpty(final Map<?, ?> map) {
    if (map.isEmpty()) {
      throw new IllegalArgumentException("Map must not be empty."); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentNotNullOrEmpty(final Collection<?> list) {
    ensureArgumentNotNull(list);
    if (list.isEmpty()) {
      throw new IllegalArgumentException("Collection must not be empty."); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentNotNullOrEmpty(String message, final Collection<?> list) {
    ensureArgumentNotNull(message, list);
    if (list.isEmpty()) {
      throw new IllegalArgumentException(message + " must not be empty."); //$NON-NLS-1$
    }
  }

  public static <T> void ensureArgumentNotNullOrEmpty(final T[] array) {
    ensureArgumentNotNull(array);
    if (array.length == 0) {
      throw new IllegalArgumentException("Array must not be empty."); //$NON-NLS-1$
    }
  }

  public static void ensureArgumentNotNullOrEmpty(int[] array) {
    ensureArgumentNotNull(array);
    if (array.length == 0) {
      throw new IllegalArgumentException("Array must not be empty."); //$NON-NLS-1$
    }
  }

  public static <T> void ensureArgumentNotNullOrEmptyOrNullElements(final T[] array) {
    ensureArgumentNotNullOrEmpty(array);
    for (int index = 0; index < array.length; index++) {
      final T element = array[index];
      if (element == null) {
        throw new IllegalArgumentException(MessageFormat.format(
            "Array element [{0}] must not be null.", index)); //$NON-NLS-1$
      }
    }
  }

  public static <T> void ensureArgumentNotNullOrEmptyOrNullElements(final Collection<T> collection) {
    ensureArgumentNotNullOrEmpty(collection);

    int index = 0;
    for (T element : collection) {
      if (element == null) {
        throw new IllegalArgumentException(MessageFormat.format(
            "Array element [{0}] must not be null.", index)); //$NON-NLS-1$
      }
      index++;
    }
  }

  public static <T> void ensureArgumentNotNullOrNullElements(final T[] array) {
    ensureArgumentNotNull(array);
    for (int index = 0; index < array.length; index++) {
      final T element = array[index];
      if (element == null) {
        throw new IllegalArgumentException(MessageFormat.format(
            "Array element [{0}] must not be null.", index)); //$NON-NLS-1$
      }
    }
  }

  public static void ensureArgumentDoesNotMatch(String pathString, Pattern pattern) {
    ensureArgumentDoesNotMatch("Found illegal pattern in String: {0}", pathString, pattern); //$NON-NLS-1$ 
  }

  public static void ensureArgumentDoesNotMatch(String message, String pathString, Pattern pattern) {
    ensureArgumentNotNull(message);
    ensureArgumentNotNull(pattern);
    ensureArgumentNotNullOrTrimmedEmpty(pathString);
    Matcher matcher = pattern.matcher(pathString);
    if (matcher.find()) {
      throw new IllegalArgumentException(MessageFormat.format(message, pathString));
    }
  }
}