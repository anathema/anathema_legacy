// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 28.11.2005
package net.disy.commons.core.util.test;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.ArrayUtilities;

// NOT_PUBLISHED
public class ArrayUtilitiesTest extends CoreTestCase {

  public void testMin() throws Exception {
    assertEquals(Integer.MAX_VALUE, ArrayUtilities.min(new int[0]));
    assertEquals(7, ArrayUtilities.min(new int[]{ 7 }));
    assertEquals(7, ArrayUtilities.min(new int[]{ 10, 7, 89 }));
  }
  
  public void testConcatEmptyArrays() throws Exception {
    Object[] mergedArray = ArrayUtilities.concat(new String[0], new String[0]);
    assertEquals(0, mergedArray.length);
    assertEquals(String[].class, mergedArray.getClass());
  }

  public void testConcatLeftArrayEmpty() throws Exception {
    Object[] mergedArray = ArrayUtilities.concat(new String[0], new String[]{ "a" }); //$NON-NLS-1$
    assertEquals(1, mergedArray.length);
    assertEquals("a", mergedArray[0]); //$NON-NLS-1$
    assertEquals(String[].class, mergedArray.getClass());
  }

  public void testConcatRightArrayEmpty() throws Exception {
    Object[] mergedArray = ArrayUtilities.concat(new String[]{ "a" }, new String[0]); //$NON-NLS-1$
    assertEquals(1, mergedArray.length);
    assertEquals("a", mergedArray[0]); //$NON-NLS-1$
    assertEquals(String[].class, mergedArray.getClass());
  }

  public void testConcatNonEmptyArrays() throws Exception {
    Object[] mergedArray = ArrayUtilities.concat(new String[]{ "a" }, new String[]{ "b" }); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(2, mergedArray.length);
    assertEquals("a", mergedArray[0]); //$NON-NLS-1$
    assertEquals("b", mergedArray[1]); //$NON-NLS-1$
    assertEquals(String[].class, mergedArray.getClass());
  }

  public void testConcatNullArray() throws Exception {
    Object[] array = new Object[]{ new Object() };
    assertEquals(array, ArrayUtilities.concat(array, null));
  }
}