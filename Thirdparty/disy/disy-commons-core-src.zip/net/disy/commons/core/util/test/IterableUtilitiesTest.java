/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.disy.commons.core.util.IterableUtilities;

import org.junit.Test;

public class IterableUtilitiesTest {

  private static final String VALUE = "VALUE"; //$NON-NLS-1$
  private static final String OTHERVALUE = "OTHERVALUE"; //$NON-NLS-1$

  @Test
  public void containsValue() {
    assertThat(
        IterableUtilities.containsValue(Arrays.asList(new String[]{ VALUE }), VALUE),
        is(true));
  }

  @Test
  public void containsValueInValues() {
    assertThat(IterableUtilities.containsValue(
        Arrays.asList(new String[]{ OTHERVALUE, VALUE }),
        VALUE), is(true));
  }

  @Test
  public void containsValueNot() {
    assertThat(
        IterableUtilities.containsValue(Arrays.asList(new String[]{ OTHERVALUE }), VALUE),
        is(false));
  }

  @Test
  public void containsValueNotInEmptyList() {
    assertThat(IterableUtilities.containsValue(new ArrayList<String>(), VALUE), is(false));
  }

  @Test
  public void containsValueNull() throws Exception {
    assertThat(
        IterableUtilities.containsValue(Arrays.asList(new String[]{ null }), (String) null),
        is(true));
  }

  @Test
  public void toArray() throws Exception {
    String[] array = new String[]{ OTHERVALUE, VALUE };
    final List<String> list = Arrays.asList(new String[]{ OTHERVALUE, VALUE });
    assertThat(IterableUtilities.toArray(list, String.class), equalTo(array));
  }

  @Test
  public void toArrayEmptyList() throws Exception {
    final List<String> list = Arrays.asList(new String[]{});
    assertThat(IterableUtilities.toArray(list, String.class), equalTo(new String[]{}));
  }
}
