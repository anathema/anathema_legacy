/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;
import net.disy.commons.core.util.ArrayUtilities;

import org.junit.Test;

public class ArrayUtilities_Contains_Test {

  @Test
  public void containsValueNull() throws Exception {
    assertThat(ArrayUtilities.containsValue(new String[]{ null }, (String) null), is(true));
  }
}
