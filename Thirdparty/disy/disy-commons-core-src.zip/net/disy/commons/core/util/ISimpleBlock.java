package net.disy.commons.core.util;

public interface ISimpleBlock {

  public abstract void execute();

}
