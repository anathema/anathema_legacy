// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

//NOT_PUBLISHED
public class StringUtilities {

  public static boolean isNullOrEmpty(String text) {
    return text == null || text.length() == 0;
  }

  public static boolean startsWithIgnoreCase(final String string, final String startString) {
    if (string.length() < startString.length()) {
      return false;
    }
    return string.substring(0, startString.length()).equalsIgnoreCase(startString);
  }

  public static boolean isNullOrTrimEmpty(String text) {
    return text == null || text.trim().length() == 0;
  }
  
  public final static String toUpperCase(String string) {
    return string == null? null: string.toUpperCase();
  }

  public static String trim(String string) {
    return string == null? null: string.trim();
  }
}