/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.text.MessageFormat;
import java.util.HashSet;
import java.util.Set;
import java.util.StringTokenizer;

public class StringUtilities {

  public static boolean isNullOrEmpty(final String text) {
    return text == null || text.length() == 0;
  }

  public static boolean startsWithIgnoreCase(final String string, final String startString) {
    if (string == null || string.length() < startString.length()) {
      return false;
    }
    return string.substring(0, startString.length()).equalsIgnoreCase(startString);
  }

  public static boolean endsWithIgnoreCase(final String string, final String endString) {
    if (string == null || string.length() < endString.length()) {
      return false;
    }
    return string.substring(string.length() - endString.length()).equalsIgnoreCase(endString);
  }

  public static boolean isNullOrTrimmedEmpty(final String text) {
    return text == null || text.trim().length() == 0;
  }

  public final static String toUpperCase(final String string) {
    return string == null ? null : string.toUpperCase();
  }

  public final static String toLowerCase(final String string) {
    return string == null ? null : string.toLowerCase();
  }

  public static String trim(final String string) {
    return string == null ? null : string.trim();
  }

  public static String getDefaultIfEmpty(final String value, final String defaultValue) {
    return (isNullOrTrimmedEmpty(value) ? defaultValue : value);
  }

  public static int length(final String value) {
    if (value == null) {
      return -1;
    }
    return value.length();
  }

  public static boolean containsValueIgnoreCase(final String value, final String... strings) {
    for (final String string : strings) {
      if (value.equalsIgnoreCase(string)) {
        return true;
      }
    }
    return false;
  }

  public static String trimToMaxLength(final String string, final int maxLength) {
    return string == null || maxLength < 0 ? null : string.substring(
        0,
        Math.min(string.length(), maxLength));
  }

  public static String removeAllFromSuffix(String string, char value) {
    int counter = 0;
    for (int i = string.length(); i > 0; i--) {
      if (string.charAt(i - 1) != value) {
        break;
      }
      counter++;
    }
    return string.substring(0, string.length() - counter);
  }

  public static String removeAllFromPrefix(String string, char value) {
    int counter = 0;
    for (char b : StringUtilities.toChars(string)) {
      if (b != value) {
        break;
      }
      counter++;
    }
    return counter == 0 ? string : string.substring(counter);
  }

  public static char[] toChars(String string) {
    char[] chars = new char[string.length()];
    string.getChars(0, string.length(), chars, 0);
    return chars;
  }

  public static String concat(String codebase, String href, char separator) {
    if (isNullOrTrimmedEmpty(codebase)) {
      return href;
    }
    return MessageFormat.format("{0}{1}{2}", //$NON-NLS-1$
        removeAllFromSuffix(codebase, separator),
        separator,
        removeAllFromPrefix(href, separator));
  }

  public static String getFirstToken(String value, String delimiter) {
    if (value == null) {
      return null;
    }
    StringTokenizer tokenizer = new StringTokenizer(value, delimiter);
    if (tokenizer.hasMoreTokens()) {
      return tokenizer.nextToken();
    }
    return value;
  }

  public static String getLastToken(String value, String delimiter) {
    if (value == null) {
      return null;
    }
    StringTokenizer tokenizer = new StringTokenizer(value, delimiter);
    String name = value;
    while (tokenizer.hasMoreTokens()) {
      name = tokenizer.nextToken();
    }
    return name;
  }

  public static Set<String> asSet(String string, String separator) {
    final HashSet<String> set = new HashSet<String>();
    if (string == null) {
      return set;
    }
    StringTokenizer tokenizer = new StringTokenizer(string, separator);
    while (tokenizer.hasMoreTokens()) {
      set.add(tokenizer.nextToken());
    }
    return set;
  }

  public static boolean isInteger(String value) {
    if (isNullOrEmpty(value)) {
      return false;
    }
    return value.trim().matches("(\\+|-)?\\s*[0-9]+"); //$NON-NLS-1$
  }

}