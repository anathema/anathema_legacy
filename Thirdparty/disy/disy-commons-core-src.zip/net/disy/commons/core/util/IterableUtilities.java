/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import net.disy.commons.core.predicate.IPredicate;

public class IterableUtilities {

  public static <T> boolean containsValue(final Iterable<T> values, final T value) {
    for (T object : values) {
      if (ObjectUtilities.equals(value, object)) {
        return true;
      }
    }
    return false;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] toArray(final Iterable<T> values, final Class<T> clazz) {
    Collection<T> list = asCollection(values);
    return list.toArray((T[]) Array.newInstance(clazz, list.size()));
  }

  public static <T> T[] toSortedArray(Iterable<T> outputFormats, Class<T> clazz) {
    T[] array = toArray(outputFormats, clazz);
    Arrays.sort(array);
    return array;
  }

  public static <T> Collection<T> asCollection(final Iterable<T> values) {
    return asList(values);
  }

  public static <T> List<T> asList(final Iterable<T> values) {
    List<T> collection = new ArrayList<T>();
    for (T value : values) {
      collection.add(value);
    }
    return collection;
  }

  public static <T> Iterable<T> asIterable(final T... values) {
    return Arrays.asList(values);
  }

  public static <T> Iterable<T> concat(final Iterable<T>... iterables) {
    final Collection<T> collection = new ArrayList<T>();
    for (final Iterable<T> iterable : iterables) {
      collection.addAll(asCollection(iterable));
    }
    return collection;
  }

  public static <T> Iterable<T> concat(final T value, final Iterable<T> iterable) {
    return concat(asIterable(value), iterable);
  }

  public static <T> Iterable<T> concat(final Iterable<T> iterable, final T value) {
    return concat(iterable, asIterable(value));
  }

  public static <T> T getFirst(final Iterable<T> values, final IPredicate<T> predicate) {
    for (T value : values) {
      if (predicate.evaluate(value)) {
        return value;
      }
    }
    return null;
  }

  public static <T> Iterable<T> filter(final Iterable<T> values, final IPredicate<T> predicate) {
    List<T> filteredValues = new ArrayList<T>();
    for (T value : values) {
      if (predicate.evaluate(value)) {
        filteredValues.add(value);
      }
    }
    return filteredValues;
  }

  public static <T> boolean fulfills(final Iterable<T> values, final IPredicate<T> predicate) {
    for (final T element : values) {
      if (!predicate.evaluate(element)) {
        return false;
      }
    }
    return true;
  }

  public static <I, O> Iterable<O> convert(Iterable<I> iterable, ITransformer<I, O> transformer) {
    return convert(iterable.iterator(), transformer);
  }

  public static <I, O> Iterable<O> convert(Iterator<I> iterator, ITransformer<I, O> transformer) {
    List<O> result = new ArrayList<O>();
    while (iterator.hasNext()) {
      result.add(transformer.transform(iterator.next()));
    }
    return result;
  }
}
