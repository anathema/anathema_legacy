/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.util.Date;

public class DateRange {

  private final Date firstDay;
  private final Date lastDay;

  public static DateRange year(final int year) {
    final Date firstDay = DateUtilities.createDate(year, 1, 1);
    final Date lastDay = DateUtilities.createDate(year, 12, 31);
    return new DateRange(firstDay, lastDay);
  }

  public DateRange(final Date firstDay, final Date lastDay) {
    this.firstDay = firstDay;
    this.lastDay = lastDay;
  }

  public Date getFirstDay() {
    return firstDay;
  }

  public Date getLastDay() {
    return lastDay;
  }

}