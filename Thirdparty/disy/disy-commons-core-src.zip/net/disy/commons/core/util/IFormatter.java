package net.disy.commons.core.util;

public interface IFormatter<T> {
  public String format(T item);
}
