//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.disy.commons.core.predicate.IPredicate;

// NOT_PUBLISHED
public class ArrayUtilities {
  public static Object[] filter(Object[] array, final IPredicate predicate) {
    final List selected = new ArrayList();
    forAllDo(array, new IClosure() {
      public void execute(Object input) {
        if (predicate.evaluate(input)) {
          selected.add(input);
        }
      }
    });
    Object[] newArray = (Object[]) Array.newInstance(array.getClass().getComponentType(), selected
        .size());
    return selected.toArray(newArray);
  }

  public static void forAllDo(Object[] array, IClosure closure) {
    CollectionUtilities.forAllDo(Arrays.asList(array), closure);
  }

  public static Object[] concat(Object[] array1, Object[] array2) {
    if (array2 == null) {
      return array1;
    }
    Object[] mergedArray = (Object[]) Array.newInstance(
        array1.getClass().getComponentType(),
        array1.length + array2.length);
    System.arraycopy(array1, 0, mergedArray, 0, array1.length);
    System.arraycopy(array2, 0, mergedArray, array1.length, array2.length);
    return mergedArray;
  }

  public static Object[] concat(Object[] array, Object object) {
    return concat(array, new Object[]{ object });
  }

  public static Map createMap(Object[] objects, IKeyProvider keyProvider) {
    Map map = new HashMap();
    for (int index = 0; index < objects.length; index++) {
      map.put(keyProvider.getKey(objects[index]), objects[index]);
    }

    return map;
  }

  public static int min(int[] values) {
    int min = Integer.MAX_VALUE;
    for (int index = 0; index < values.length; index++) {
      if (values[index] < min) {
        min = values[index];
      }
    }

    return min;
  }

  public static int[] toPrimitive(Integer[] integerArray) {
    int[] intArray = new int[integerArray.length];
    for (int index = 0; index < intArray.length; index++) {
      intArray[index] = integerArray[index].intValue();
    }
    return intArray;
  }

  public static boolean contains(Object[] array, Object value) {
    if (value == null) {
      return false;
    }
    for (int index = 0; index < array.length; index++) {
      if (value.equals(array[index])) {
        return true;
      }
    }
    return false;
  }

  public static int[] getIndices(Object[] values, Object[] allValues) {
    int[] indices = new int[values.length];
    List allValuesList = Arrays.asList(allValues);
    for (int i = 0; i < values.length; i++) {
      indices[i] = allValuesList.indexOf(values[i]);
    }
    
    return indices;
  }

  public static Object getFirst(Object[] array, IPredicate predicate) {
    for (int index = 0; index < array.length; index++) {
      if (predicate.evaluate(array[index])) {
        return array[index];
      }
    }

    return null;
  }

}
