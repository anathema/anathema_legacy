//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.disy.commons.core.predicate.IPredicate;

// NOT_PUBLISHED
public class ArrayUtilities {
  @SuppressWarnings("unchecked")
  public static <T> T[] filter(T[] array, final IPredicate<T> predicate) {
    final List<T> selected = new ArrayList<T>();
    forAllDo(array, new IClosure<T>() {
      public void execute(T input) {
        if (predicate.evaluate(input)) {
          selected.add(input);
        }
      }
    });
    T[] newArray = (T[]) Array.newInstance(array.getClass().getComponentType(), selected.size());
    return selected.toArray(newArray);
  }

  public static <T> void forAllDo(T[] array, IClosure<T> closure) {
    CollectionUtilities.forAllDo(Arrays.asList(array), closure);
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] concat(T[] array1, T[] array2) {
    if (array2 == null) {
      return array1;
    }
    T[] mergedArray = (T[]) Array.newInstance(array1.getClass().getComponentType(), array1.length
        + array2.length);
    System.arraycopy(array1, 0, mergedArray, 0, array1.length);
    System.arraycopy(array2, 0, mergedArray, array1.length, array2.length);
    return mergedArray;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] concat(T[] array, T object) {
    return (T[]) concat(array, new Object[]{ object });
  }

  public static <T, U> Map<T, U> createMap(U[] objects, IKeyProvider<T, U> keyProvider) {
    Map<T, U> map = new HashMap<T, U>();
    for (int index = 0; index < objects.length; index++) {
      map.put(keyProvider.getKey(objects[index]), objects[index]);
    }

    return map;
  }

  public static int min(int[] values) {
    int min = Integer.MAX_VALUE;
    for (int index = 0; index < values.length; index++) {
      if (values[index] < min) {
        min = values[index];
      }
    }

    return min;
  }

  public static int[] toPrimitive(Integer[] integerArray) {
    int[] intArray = new int[integerArray.length];
    for (int index = 0; index < intArray.length; index++) {
      intArray[index] = integerArray[index];
    }
    return intArray;
  }

  public static <T> boolean contains(T[] array, T value) {
    if (value == null) {
      return false;
    }
    for (int index = 0; index < array.length; index++) {
      if (value.equals(array[index])) {
        return true;
      }
    }
    return false;
  }

  public static <T> int[] getIndices(T[] values, T[] allValues) {
    int[] indices = new int[values.length];
    List<T> allValuesList = Arrays.asList(allValues);
    for (int i = 0; i < values.length; i++) {
      indices[i] = allValuesList.indexOf(values[i]);
    }
    return indices;
  }

  public static <T> T getFirst(T[] array, IPredicate<T> predicate) {
    for (int index = 0; index < array.length; index++) {
      if (predicate.evaluate(array[index])) {
        return array[index];
      }
    }

    return null;
  }

  @SuppressWarnings("unchecked")
  public static <I, O> O[] transform(I[] array, Class<O> clazz, ITransformer<I, O> transformer) {
    O[] transformed = (O[]) Array.newInstance(clazz, array.length);
    for (int i = 0; i < array.length; i++) {
      transformed[i] = transformer.transform(array[i]);
    }
    return transformed;
  }

  public static <I, O> O[] transform(I[] array, Class<O> clazz) {
    return transform(array, clazz, new ITransformer<I, O>() {
      @SuppressWarnings("unchecked")
      public O transform(I input) {
        return (O) input;
      }
    });
  }

}
