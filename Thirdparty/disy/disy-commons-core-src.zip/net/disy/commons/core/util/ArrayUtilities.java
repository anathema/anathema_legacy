/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import static java.lang.reflect.Array.*;
import static java.text.MessageFormat.*;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.string.StringConcatenationBuilder;

public class ArrayUtilities {
  @SuppressWarnings("unchecked")
  public static <T> T[] filter(final T[] array, final IPredicate<T> predicate) {
    final List<T> selected = new ArrayList<T>();
    for (final T element : array) {
      if (predicate.evaluate(element)) {
        selected.add(element);
      }
    }
    final T[] newArray = (T[]) newInstance(array.getClass().getComponentType(), selected.size());
    return selected.toArray(newArray);
  }

  @SuppressWarnings("boxing")
  public static <T, E extends Exception> T getSingleRequired(
      final T[] array,
      final IPredicate<T> predicate,
      final E e) throws E {
    final T[] found = filter(array, predicate);
    if (found.length != 1) {
      e.initCause(new IllegalStateException(format("{0} objects found.", found.length))); //$NON-NLS-1$
      throw e;
    }

    return found[0];
  }

  public static <T> void forAllDo(final T[] array, final IClosure<T> closure) {
    for (final T element : array) {
      closure.execute(element);
    }
  }

  public static Class<?> getSharedSuperType(
      final Class<?> componentType1,
      final Class<?> componentType2) {
    if (componentType1.isAssignableFrom(componentType2)) {
      return componentType1;
    }
    if (componentType2.isAssignableFrom(componentType1)) {
      return componentType2;
    }
    return getSharedSuperType(componentType1.getSuperclass(), componentType2);
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] concat(final T object, final T[] array2, final Class<T> clazz) {
    final T[] array1 = (T[]) Array.newInstance(clazz, 1);
    array1[0] = object;
    return concat(clazz, array1, array2);
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] concat(final Class<T> clazz, final T[] array1, final T... array2) {
    if (array2 == null) {
      return array1;
    }
    if (array1 == null) {
      return array2;
    }
    final T[] mergedArray = (T[]) Array.newInstance(clazz, array1.length + array2.length);
    System.arraycopy(array1, 0, mergedArray, 0, array1.length);
    System.arraycopy(array2, 0, mergedArray, array1.length, array2.length);
    return mergedArray;
  }

  public static <T, U> Map<T, U> createMap(final U[] objects, final IKeyProvider<T, U> keyProvider) {
    final Map<T, U> map = new HashMap<T, U>();
    for (final U object : objects) {
      map.put(keyProvider.getKey(object), object);
    }

    return map;
  }

  public static int min(final int[] values) {
    int min = Integer.MAX_VALUE;
    for (final int value : values) {
      if (value < min) {
        min = value;
      }
    }
    return min;
  }

  public static int max(final int[] values) {
    int max = Integer.MIN_VALUE;
    for (final int value : values) {
      if (value > max) {
        max = value;
      }
    }
    return max;
  }

  public static double min(final double[] values) {
    double min = Double.MAX_VALUE;
    for (final double value : values) {
      if (value < min) {
        min = value;
      }
    }
    return min;
  }

  public static double max(final double[] values) {
    double max = Double.NEGATIVE_INFINITY;
    for (final double value : values) {
      if (value > max) {
        max = value;
      }
    }
    return max;
  }

  public static int[] toPrimitive(final Integer[] integerArray) {
    final int[] intArray = new int[integerArray.length];
    for (int index = 0; index < intArray.length; index++) {
      intArray[index] = integerArray[index].intValue();
    }
    return intArray;
  }

  public static long[] toPrimitive(final Long[] longs) {
    final long[] longArray = new long[longs.length];
    for (int index = 0; index < longArray.length; index++) {
      longArray[index] = longs[index].longValue();
    }
    return longArray;
  }

  public static double[] toPrimitive(final Double[] doubles) {
    final double[] doubleArray = new double[doubles.length];
    for (int index = 0; index < doubleArray.length; index++) {
      doubleArray[index] = doubles[index].doubleValue();
    }
    return doubleArray;
  }

  public static char[] toPrimitive(final Character[] characterArray) {
    final char[] charArray = new char[characterArray.length];
    for (int index = 0; index < charArray.length; index++) {
      charArray[index] = characterArray[index].charValue();
    }
    return charArray;
  }

  public static <T> boolean containsValue(final T[] array, final T value) {
    return contains(array, new IPredicate<T>() {
      @Override
      public boolean evaluate(final T actualValue) {
        return ObjectUtilities.equals(value, actualValue);
      }
    });
  }

  public static <T> boolean contains(final T[] array, final IPredicate<T> predicate) {

    for (final T element : array) {
      if (predicate.evaluate(element)) {
        return true;
      }
    }
    return false;
  }

  public static <T> int[] getIndices(final T[] values, final T[] allValues) {
    final int[] indices = new int[values.length];
    final List<T> allValuesList = Arrays.asList(allValues);
    for (int i = 0; i < values.length; i++) {
      indices[i] = allValuesList.indexOf(values[i]);
    }
    return indices;
  }

  public static <T> T getFirst(final T[] array, final IPredicate<T> predicate) {
    final T notFoundValue = null;
    return getFirst(array, predicate, notFoundValue);
  }

  public static <T> T getFirst(final T[] array, final IPredicate<T> predicate, final T notFoundValue) {
    for (final T element : array) {
      if (predicate.evaluate(element)) {
        return element;
      }
    }
    return notFoundValue;
  }

  @SuppressWarnings("unchecked")
  public static <I, O> O[] transform(
      final I[] array,
      final Class<? super O> clazz,
      final ITransformer<I, O> transformer) {
    final O[] transformed = (O[]) Array.newInstance(clazz, array.length);
    for (int i = 0; i < array.length; i++) {
      transformed[i] = transformer.transform(array[i]);
    }
    return transformed;
  }

  public static <I, O> O[] transform(final I[] array, final Class<O> clazz) {
    return transform(array, clazz, new CastingTransformer<I, O>());
  }

  public static int indexOf(final byte[] buffer, final int value) {
    for (int i = 0; i < buffer.length; i++) {
      if (buffer[i] == value) {
        return i;
      }
    }

    return -1;
  }

  public static <T> int[] indicesOf(final T[] values, final IPredicate<T> predicate) {
    final List<Integer> indices = new ArrayList<Integer>();
    for (int i = 0; i < values.length; i++) {
      if (predicate.evaluate(values[i])) {
        indices.add(new Integer(i));
      }
    }
    final int[] intIndices = new int[indices.size()];
    for (int i = 0; i < indices.size(); i++) {
      intIndices[i] = indices.get(i).intValue();
    }
    return intIndices;
  }

  public static String[] toStrings(final int[] values) {
    final String[] strings = new String[values.length];
    for (int i = 0; i < values.length; i++) {
      strings[i] = String.valueOf(values[i]);
    }
    return strings;
  }

  public static String[] toStrings(final long[] values) {
    final String[] strings = new String[values.length];
    for (int i = 0; i < values.length; i++) {
      strings[i] = String.valueOf(values[i]);
    }
    return strings;
  }

  public static <T> int indexOf(final T[] values, final IPredicate<T> predicate) {
    for (int i = 0; i < values.length; i++) {
      if (predicate.evaluate(values[i])) {
        return i;
      }
    }
    return -1;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] subArray(final T[] array, final int startIndex) {
    Ensure.ensureArgumentIndexInBounds(startIndex, new Range(0, array.length));
    final int newLength = array.length - startIndex;
    final T[] subArray = (T[]) Array.newInstance(array.getClass().getComponentType(), newLength);
    System.arraycopy(array, startIndex, subArray, 0, newLength);
    return subArray;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] subArray(final T[] array, final int startIndex, final int endIndex) {
    Ensure.ensureArgumentIndexInBounds(startIndex, new Range(0, array.length));
    Ensure.ensureArgumentIndexInBounds(endIndex, new Range(0, array.length));
    Ensure.ensureTrue("EndIndex must be at least startIndex.", endIndex >= startIndex); //$NON-NLS-1$
    final int newLength = endIndex - startIndex;
    final T[] subArray = (T[]) Array.newInstance(array.getClass().getComponentType(), newLength);
    System.arraycopy(array, startIndex, subArray, 0, newLength);
    return subArray;
  }

  public static <T> T getFirstIfAny(final T[] values) {
    return values.length == 0 ? null : values[0];
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] reverse(final T[] values) {
    final T[] revertedValues = (T[]) Array.newInstance(
        values.getClass().getComponentType(),
        values.length);
    for (int i = 0; i < revertedValues.length; ++i) {
      revertedValues[i] = values[values.length - i - 1];
    }
    return revertedValues;
  }

  public static String getRepresentation(final long[] array) {
    return getRepresentation(array, "[", ",", "]"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

  public static <T> String getRepresentation(final T[] array) {
    if (array == null) {
      return null;
    }
    return CollectionUtilities.getRepresentation(Arrays.asList(array));
  }

  public static <T> String getRepresentation(final T[] array, final String separator) {
    return getRepresentation(array, "", separator, ""); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public static String getRepresentation(
      final long[] array,
      final String prefix,
      final String separator,
      final String postfix) {
    if (array == null) {
      return null;
    }
    final StringConcatenationBuilder builder = new StringConcatenationBuilder(separator);
    for (final long value : array) {
      builder.append(String.valueOf(value));
    }
    return prefix + builder.getString() + postfix;
  }

  public static <T> String getRepresentation(
      final T[] array,
      final String prefix,
      final String separator,
      final String postfix) {
    if (array == null) {
      return null;
    }
    return CollectionUtilities.getRepresentation(Arrays.asList(array), prefix, separator, postfix);
  }

  public static <T> String getRepresentation(
      final T[] array,
      final String prefix,
      final String separator,
      final String postfix,
      final IFormatter<T> formatter) {
    if (array == null) {
      return null;
    }
    return CollectionUtilities.getRepresentation(
        Arrays.asList(array),
        prefix,
        separator,
        postfix,
        formatter);
  }

  public static <T, U extends T> U[] filterClass(final T[] array, final Class<U> clazz) {
    final T[] filteredArray = filter(array, new IPredicate<T>() {
      @Override
      public boolean evaluate(final T object) {
        return clazz.isAssignableFrom(object.getClass());
      }
    });
    return transform(filteredArray, clazz, new ITransformer<T, U>() {
      @Override
      @SuppressWarnings("unchecked")
      public U transform(final T input) {
        return (U) input;
      }
    });
  }

  /**
   * @deprecated As of 15.12.2008 (bartels), replaced by {@link
   *             CollectionUtilities#toArray(Iterable, Class)}
   */
  @Deprecated
  @SuppressWarnings("unchecked")
  public static <T> T[] toArray(final Iterable<T> items, final Class<T> itemClass) {
    final List<T> itemList = new ArrayList<T>();
    for (final T item : items) {
      itemList.add(item);
    }
    return itemList.toArray((T[]) Array.newInstance(itemClass, itemList.size()));
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] concat(final Class<T> componentClass, final T[]... arrays) {
    int size = 0;
    for (final T[] array : arrays) {
      size += array.length;
    }
    final T[] concat = (T[]) Array.newInstance(componentClass, size);
    int pos = 0;
    for (final T[] array : arrays) {
      System.arraycopy(array, 0, concat, pos, array.length);
      pos += array.length;
    }
    return concat;
  }

  public static boolean[] repeat(final boolean value, final int length) {
    final boolean[] b = new boolean[length];
    Arrays.fill(b, value);
    return b;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] repeat(final Class<T> clazz, final T value, final int length) {
    final T[] array = (T[]) Array.newInstance(clazz, length);
    Arrays.fill(array, value);
    return array;
  }

  public static int indexOfMaximalElement(final double[] array) {

    double max = Double.NEGATIVE_INFINITY;
    int maxIndex = -1;
    for (int index = 0; index < array.length; index++) {
      final double value = array[index];
      if (value > max) {
        max = value;
        maxIndex = index;
      }
    }
    return maxIndex;
  }

  public static int indexOfMinimalElement(final double[] array) {
    final double maximalElement = ArrayUtilities.min(array);
    if (array == null) {
      return -1;
    }
    for (int i = 0; i < array.length; i++) {
      if (maximalElement == array[i]) {
        return i;
      }
    }
    throw new UnreachableCodeReachedException();
  }

  public static <T> boolean containsSame(final T[] values, final T[] others) {
    Arrays.sort(values);
    Arrays.sort(others);
    return Arrays.equals(values, others);
  }

  public static <T> boolean isNotEmpty(T[] array) {
    return array != null && array.length > 0;
  }

  public static <T> boolean isNullOrEmpty(T[] array) {
    return !isNotEmpty(array);
  }

  public static <T> List<T[]> segmentize(T[] values, int maximumSegmentSize, Class<T[]> clazz) {
    int restSegmentSize = values.length % maximumSegmentSize;
    int numberOfmaximumSizeSegments = values.length / maximumSegmentSize;
    int to = 0;
    final List<T[]> segments = new ArrayList<T[]>();
    for (int i = 0; i < numberOfmaximumSizeSegments; ++i) {
      int from = to;
      to = to + maximumSegmentSize;
      segments.add(Arrays.copyOfRange(values, from, to, clazz));
    }
    if (restSegmentSize > 0) {
      int from = to;
      to = to + restSegmentSize;
      segments.add(Arrays.copyOfRange(values, from, to, clazz));
    }
    return segments;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] merge(T[] array1, T[] array2, Class<T> itemClass) {
    final HashSet<T> mergedValues = new HashSet<T>();
    for (T value : array1) {
      mergedValues.add(value);
    }

    for (T value : array2) {
      mergedValues.add(value);
    }

    return mergedValues.toArray((T[]) Array.newInstance(itemClass, mergedValues.size()));
  }
}