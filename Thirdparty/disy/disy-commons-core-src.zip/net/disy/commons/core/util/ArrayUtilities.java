//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// NOT_PUBLISHED
public class ArrayUtilities {
  public static Object[] filter(Object[] array, final IPredicate predicate) {
    final List selected = new ArrayList();
    forAllDo(array, new IClosure() {
      public void execute(Object input) {
        if (predicate.evaluate(input)) {
          selected.add(input);
        }
      }
    });
    Object[] newArray = (Object[]) Array.newInstance(array.getClass().getComponentType(), selected
        .size());
    return selected.toArray(newArray);
  }

  public static void forAllDo(Object[] array, IClosure closure) {
    CollectionUtilities.forAllDo(Arrays.asList(array), closure);
  }


}
