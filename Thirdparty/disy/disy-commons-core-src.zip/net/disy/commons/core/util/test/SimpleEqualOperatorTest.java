/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.math.BigInteger;

import net.disy.commons.core.util.SimpleEqualOperator;

import org.junit.Test;

public class SimpleEqualOperatorTest {

  @SuppressWarnings("nls")
  @Test
  public void test() {
    assertTrue(SimpleEqualOperator.areEquals("ja", "ja"));
    assertTrue(SimpleEqualOperator.areEquals("", ""));
    assertTrue(!SimpleEqualOperator.areEquals("ja", "jA"));
    assertTrue(!SimpleEqualOperator.areEquals("ja", null));
    assertTrue(!SimpleEqualOperator.areEquals(null, ""));
    assertTrue(!SimpleEqualOperator.areEquals(null, null));

    assertTrue(SimpleEqualOperator.areEquals(2.41412d, 2.41412d));
    assertTrue(!SimpleEqualOperator.areEquals(2.41412d, 2.414121d));

    assertTrue(SimpleEqualOperator.areEquals(2.41412f, 2.41412f));
    assertTrue(!SimpleEqualOperator.areEquals(2.41412f, 2.414121f));

    assertTrue(SimpleEqualOperator.areEquals(2.41412d, 2.41412f));
    assertTrue(!SimpleEqualOperator.areEquals(2.41412d, 2.414121f));

    assertTrue(SimpleEqualOperator.areEquals("2.41412", 2.41412f));
    assertTrue(!SimpleEqualOperator.areEquals("2.41412", 2.414121f));

    assertTrue(SimpleEqualOperator.areEquals("2", 2f));
    assertTrue(SimpleEqualOperator.areEquals("2", 2d));
    assertTrue(SimpleEqualOperator.areEquals("2", new BigDecimal(2d)));
    assertTrue(SimpleEqualOperator.areEquals("2", 2l));
    assertTrue(SimpleEqualOperator.areEquals("2", 2.0));
    assertTrue(SimpleEqualOperator.areEquals("22", 22));

    assertTrue(SimpleEqualOperator.areEquals(2.323d, new BigDecimal(2.323d)));
    assertTrue(SimpleEqualOperator.areEquals(2, new BigDecimal(2d)));
    assertTrue(SimpleEqualOperator.areEquals(2.323f, new BigDecimal(2.323d)));
    assertTrue(SimpleEqualOperator.areEquals(new BigInteger("2"), new BigDecimal(2d)));
    assertTrue(SimpleEqualOperator.areEquals(BigInteger.valueOf(2l), new BigDecimal(2d)));
  }

}
