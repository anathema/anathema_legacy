/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import java.util.regex.Pattern;

import net.disy.commons.core.util.Ensure;

import org.junit.Test;

public class EnsureTest {

  @Test(expected = RuntimeException.class)
  public void testTrue() {
    Ensure.ensureTrue("Message", true); //$NON-NLS-1$
    Ensure.ensureTrue("Message", false); //$NON-NLS-1$
  }

  @Test(expected = IllegalArgumentException.class)
  public void testArgumentTrue() {
    Ensure.ensureArgumentTrue("Message", true); //$NON-NLS-1$
    Ensure.ensureArgumentTrue("Message", false); //$NON-NLS-1$
  }

  @Test(expected = RuntimeException.class)
  public void testFalse() {
    Ensure.ensureFalse("Message", false); //$NON-NLS-1$
    Ensure.ensureFalse("Message", true); //$NON-NLS-1$
  }

  @Test(expected = IllegalArgumentException.class)
  public void testArgumentFalse() {
    Ensure.ensureArgumentFalse("Message", false); //$NON-NLS-1$
    Ensure.ensureArgumentFalse("Message", true); //$NON-NLS-1$
  }

  @Test(expected = RuntimeException.class)
  public void testNotNull() {
    Ensure.ensureNotNull(new Object());
    Ensure.ensureNotNull(null);
  }

  @Test(expected = RuntimeException.class)
  public void testArgumentNotNull() {
    Ensure.ensureArgumentNotNull(new Object());
    Ensure.ensureArgumentNotNull(null);
  }

  @Test(expected = RuntimeException.class)
  public void testArrayIndex() {
    Ensure.ensureArrayIndex(0, 0, 1);
    Ensure.ensureArrayIndex(1, 0, 1);
    Ensure.ensureArrayIndex(-1, 0, 1);
  }

  @Test(expected = RuntimeException.class)
  public void testArrayIndexOutOfBounds() throws Exception {
    Ensure.ensureArrayIndex(2, 0, 1);
  }

  @Test(expected = RuntimeException.class)
  public void testArgumentNotNullOrEmptyTrimmed() {
    Ensure.ensureArgumentNotNullOrTrimmedEmpty("a"); //$NON-NLS-1$
    Ensure.ensureArgumentNotNullOrTrimmedEmpty(""); //$NON-NLS-1$
  }

  @Test(expected = RuntimeException.class)
  public void testArgumentNotNullOrTrimmedEmptyEncountersNull() throws Exception {
    Ensure.ensureArgumentNotNullOrTrimmedEmpty(null);
  }

  @Test(expected = RuntimeException.class)
  public void testArgumentNotNullOrTrimmedEmptyEncountersEmpty() throws Exception {
    Ensure.ensureArgumentNotNullOrTrimmedEmpty(" "); //$NON-NLS-1$
  }

  @Test(expected = IllegalArgumentException.class)
  public void testMatchPattern() throws Exception {
    Pattern pattern = Pattern.compile("(:(?!(/|\\\\)))"); //$NON-NLS-1$
    Ensure.ensureArgumentDoesNotMatch("file:C", pattern); //$NON-NLS-1$
  }

  @Test
  public void testNotMatchPattern() throws Exception {
    Pattern pattern = Pattern.compile("(:(?!(/|\\\\)))"); //$NON-NLS-1$
    Ensure.ensureArgumentDoesNotMatch("file:/C", pattern); //$NON-NLS-1$
    Ensure.ensureArgumentDoesNotMatch("file:\\C", pattern); //$NON-NLS-1$
  }
}