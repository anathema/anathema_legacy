// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.util.test;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ISimpleBlock;

public class EnsureTest extends CoreTestCase {

  public void testTrue() {
    Ensure.ensureTrue(true);
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureTrue(false);
      }
    });
  }

  public void testArgumentTrue() {
    Ensure.ensureArgumentTrue(true);
    assertThrowsException(IllegalArgumentException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentTrue(false);
      }
    });
  }

  public void testFalse() {
    Ensure.ensureFalse(false);
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureFalse(true);
      }
    });
  }

  public void testArgumentFalse() {
    Ensure.ensureArgumentFalse(false);
    assertThrowsException(IllegalArgumentException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentFalse(true);
      }
    });
  }

  public void testNotNull() {
    Ensure.ensureNotNull(new Object());
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureNotNull(null);
      }
    });
  }

  public void testArgumentNotNull() {
    Ensure.ensureArgumentNotNull(new Object());
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentNotNull(null);
      }
    });
  }

  public void testArrayIndex() {
    Ensure.ensureArrayIndex(0, 0, 1);
    Ensure.ensureArrayIndex(1, 0, 1);
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArrayIndex(-1, 0, 1);
      }
    });
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArrayIndex(2, 0, 1);
      }
    });
  }

  public void testArgumentNotNullOrEmptyTrimmed() {
    Ensure.ensureArgumentNotNullOrTrimmedEmpty("a"); //$NON-NLS-1$
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentNotNullOrTrimmedEmpty(""); //$NON-NLS-1$
      }
    });
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentNotNullOrTrimmedEmpty(null);
      }
    });
    assertThrowsException(RuntimeException.class, new ISimpleBlock() {
      public void execute() {
        Ensure.ensureArgumentNotNullOrTrimmedEmpty(" "); //$NON-NLS-1$
      }
    });
  }

}