/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.math.BigDecimal;

public class SimpleEqualOperator {

  public static final double DOUBLE_TOLERANCE = 0.0000001;

  public static boolean areEquals(Object o1, Object o2) {
    if (o1 == null || o2 == null) {
      return false;
    }
    if (o1 instanceof Number && o2 instanceof Number) {
      final Number number1 = (Number) o1;
      final Number number2 = (Number) o2;
      final Class<? extends Number> firstClass = number1.getClass();
      if (firstClass == o2.getClass()) {
        return ((Comparable) o1).compareTo(o2) == 0;
      }
      return Math.abs(number1.doubleValue() - number2.doubleValue()) < DOUBLE_TOLERANCE;
    }
    final String string1 = convertToString(o1);
    final String string2 = convertToString(o2);
    return string1.equals(string2);
  }

  private static String convertToString(Object o) {
    if (isFloatNumber(o)) {
      Number number = (Number) o;
      if (Math.abs(number.longValue() - number.doubleValue()) < DOUBLE_TOLERANCE) {
        return String.valueOf(number.longValue());
      }
    }
    return String.valueOf(o);
  }

  private static boolean isFloatNumber(Object o) {
    return o instanceof Double || o instanceof Float || o instanceof BigDecimal;
  }

}