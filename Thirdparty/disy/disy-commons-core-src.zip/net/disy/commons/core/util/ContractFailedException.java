// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

/**
 * Exception that is thrown if the contract of method was not fullfilled.
 */
public class ContractFailedException extends RuntimeException {

  public ContractFailedException(String message) {
    super(message);
  }

}
