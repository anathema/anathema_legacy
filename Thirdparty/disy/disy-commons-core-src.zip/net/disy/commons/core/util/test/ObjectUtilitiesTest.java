/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.junit.Assert.*;
import net.disy.commons.core.util.ObjectUtilities;

import org.junit.Test;

public class ObjectUtilitiesTest {

  @Test
  public void testNullObjectEquals() {
    assertTrue(ObjectUtilities.equals((Object) null, (Object) null));
  }

  @Test
  public void testSameObjectEquals() {
    final Object o = new Object();
    assertTrue(ObjectUtilities.equals(o, o));
  }

  @Test
  public void testEqualObjectsEquals() {
    assertTrue(ObjectUtilities.equals("a", "a")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testStringsEqualIgnoreCase() {
    assertTrue(ObjectUtilities.equalsIgnoreCase("A", "a")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testNonEqualObjectsNotEquals() {
    assertFalse(ObjectUtilities.equals("b", "a")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testSameArrayEquals() {
    final Object[] o = new Object[]{ new Object() };
    assertTrue(ObjectUtilities.equals(o, o));
  }

  @Test
  public void testEqualArraysEquals() {
    final Object[] o1 = new Object[]{ "a", new Integer(1), null }; //$NON-NLS-1$
    final Object[] o2 = new Object[]{ "a", new Integer(1), null }; //$NON-NLS-1$
    assertTrue(ObjectUtilities.equals(o1, o2));
  }

  @Test
  public void testNonEqualArraysNotEquals() {
    final Object[] o1 = new Object[]{ "a", new Integer(1), null }; //$NON-NLS-1$
    final Object[] o2 = new Object[]{ "a", new Integer(2), null }; //$NON-NLS-1$
    assertFalse(ObjectUtilities.equals(o1, o2));
  }

  @Test
  public void testNaNDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.NaN, Double.NaN));
  }

  @Test
  public void testMaxDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.MAX_VALUE, Double.MAX_VALUE));
  }

  @Test
  public void testMinDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.MIN_VALUE, Double.MIN_VALUE));
  }

  @Test
  public void testNegativeInfinityDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
  }

  @Test
  public void testPositiveInfinityDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
  }

  @Test
  public void testSameDoubleEquals() {
    assertTrue(ObjectUtilities.equals(4.2, 4.2));
  }

  @Test
  public void testNonEqualDoubleNotEquals() {
    assertFalse(ObjectUtilities.equals(1.0, 4.2));
  }

  @Test
  public void testNaNFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.NaN, Float.NaN));
  }

  @Test
  public void testMaxFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.MAX_VALUE, Float.MAX_VALUE));
  }

  @Test
  public void testMinFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.MIN_VALUE, Float.MIN_VALUE));
  }

  @Test
  public void testNegativeInfinityFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY));
  }

  @Test
  public void testPositiveInfinityFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY));
  }

  @Test
  public void testSameFloatEquals() {
    assertTrue(ObjectUtilities.equals(4.2f, 4.2f));
  }

  @Test
  public void testNonEqualFloatNotEquals() {
    assertFalse(ObjectUtilities.equals(1.0f, 4.2f));
  }

  @Test
  public void testToString() {
    assertEquals(null, ObjectUtilities.toString(null));
    assertEquals("a", ObjectUtilities.toString("a")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("1", ObjectUtilities.toString(new Integer(1))); //$NON-NLS-1$
  }

  @Test
  public void testToStringEquals() {
    assertTrue(ObjectUtilities.toStringEquals("1", new Integer(1))); //$NON-NLS-1$
    assertFalse(ObjectUtilities.toStringEquals("2", new Integer(1))); //$NON-NLS-1$
    assertFalse(ObjectUtilities.toStringEquals(null, new Integer(1)));
    assertFalse(ObjectUtilities.toStringEquals(new Integer(1), null));
    assertTrue(ObjectUtilities.toStringEquals(null, null));
  }
}