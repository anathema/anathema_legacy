/**
 * @author gebhard@disy.net
 */
package net.disy.commons.core.util.test;

import junit.framework.TestCase;

import net.disy.commons.core.util.ObjectUtilities;

public class ObjectUtilitiesTest extends TestCase {

  // ----------- Object -------------

  public void testNullObjectEquals() {
    assertTrue(ObjectUtilities.equals(null, null));
  }

  public void testSameObjectEquals() {
    Object o = new Object();
    assertTrue(ObjectUtilities.equals(o, o));
  }

  public void testEqualObjectsEquals() {
    assertTrue(ObjectUtilities.equals("a", "a"));
  }

  public void testNonEqualObjectsNotEquals() {
    assertFalse(ObjectUtilities.equals("b", "a"));
  }

  // ----------- Array -------------

  public void testSameArrayEquals() {
    Object[] o = new Object[]{ new Object() };
    assertTrue(ObjectUtilities.equals(o, o));
  }

  public void testEqualArraysEquals() {
    Object[] o1 = new Object[]{ "a", new Integer(1), null};
    Object[] o2 = new Object[]{ "a", new Integer(1), null};
    assertTrue(ObjectUtilities.equals(o1, o2));
  }

  public void testNonEqualArraysNotEquals() {
    Object[] o1 = new Object[]{ "a", new Integer(1), null};
    Object[] o2 = new Object[]{ "a", new Integer(2), null};
    assertFalse(ObjectUtilities.equals(o1, o2));
  }

  // ----------- Double -------------

  public void testNaNDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.NaN, Double.NaN));
  }

  public void testMaxDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.MAX_VALUE, Double.MAX_VALUE));
  }

  public void testMinDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.MIN_VALUE, Double.MIN_VALUE));
  }

  public void testNegativeInfinityDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
  }

  public void testPositiveInfinityDoubleEquals() {
    assertTrue(ObjectUtilities.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
  }

  public void testSameDoubleEquals() {
    assertTrue(ObjectUtilities.equals(4.2, 4.2));
  }

  public void testNonEqualDoubleNotEquals() {
    assertFalse(ObjectUtilities.equals(1.0, 4.2));
  }

  // ----------- Float -------------

  public void testNaNFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.NaN, Float.NaN));
  }

  public void testMaxFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.MAX_VALUE, Float.MAX_VALUE));
  }

  public void testMinFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.MIN_VALUE, Float.MIN_VALUE));
  }

  public void testNegativeInfinityFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.NEGATIVE_INFINITY, Float.NEGATIVE_INFINITY));
  }

  public void testPositiveInfinityFloatEquals() {
    assertTrue(ObjectUtilities.equals(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY));
  }

  public void testSameFloatEquals() {
    assertTrue(ObjectUtilities.equals(4.2f, 4.2f));
  }

  public void testNonEqualFloatNotEquals() {
    assertFalse(ObjectUtilities.equals(1.0f, 4.2f));
  }

  // ----------- toString -------------

  public void testToString() {
    assertEquals(null, ObjectUtilities.toString(null));
    assertEquals("a", ObjectUtilities.toString("a"));
    assertEquals("1", ObjectUtilities.toString(new Integer(1)));
  }

  // ----------- toStringEquals -------------

  public void testToStringEquals() {
    assertTrue(ObjectUtilities.toStringEquals("1", new Integer(1)));
    assertFalse(ObjectUtilities.toStringEquals("2", new Integer(1)));
    assertFalse(ObjectUtilities.toStringEquals(null, new Integer(1)));
    assertFalse(ObjectUtilities.toStringEquals(new Integer(1), null));
    assertTrue(ObjectUtilities.toStringEquals(null, null));
  }
}