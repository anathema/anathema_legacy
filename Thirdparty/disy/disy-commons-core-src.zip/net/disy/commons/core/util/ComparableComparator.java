// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Comparator;

//NOT_PUBLISHED
public class ComparableComparator implements Comparator {

  public int compare(Object o1, Object o2) {
    return ((Comparable) o1).compareTo(o2);
  }

}
