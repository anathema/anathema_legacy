// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Comparator;

//NOT_PUBLISHED
public class ComparableComparator<T extends Comparable<T>> implements Comparator<T> {

  public int compare(T o1, T o2) {
    return o1.compareTo(o2);
  }

}
