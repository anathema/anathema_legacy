/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateUtilities {

  public static Date createDate(final int year, final int month, final int day) {
    Ensure.ensureArgumentTrue("Illegal value for month: " + month, month >= 1); //$NON-NLS-1$
    Ensure.ensureArgumentTrue("Illegal value for month: " + month, month <= 12); //$NON-NLS-1$
    return new GregorianCalendar(year, month - 1, day).getTime();
  }

  public static boolean isValidDateFormatOrNull(final String dateFormat) {
    if (dateFormat == null) {
      return true;
    }
    try {
      new SimpleDateFormat(dateFormat);
      return true;
    }
    catch (final Exception e) {
      return false;
    }
  }

  public static Calendar toCalendar(final Date date) {
    final Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    return calendar;
  }

  public static Date add(final Date date, final int field, final int value) {
    if (date instanceof java.sql.Date) {
      return add((java.sql.Date) date, field, value);
    }
    final Calendar calendar = toCalendar(date);
    calendar.add(field, value);
    return calendar.getTime();
  }

  public static java.sql.Date add(final java.sql.Date date, final int field, final int value) {
    final Calendar calendar = toCalendar(date);
    calendar.add(field, value);
    return new java.sql.Date(calendar.getTime().getTime());
  }

  public static int getYear(final Date date) {
    return toCalendar(date).get(Calendar.YEAR);
  }
}