// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util.test;

import java.util.ArrayList;
import java.util.List;

import junit.framework.TestCase;

import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.ComparableComparator;

//NOT_PUBLISHED
public class CollectionUtilitiesTest extends TestCase {
  public void testInsertIntoSortedListEmpty() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 1);
  }

  public void testInsertIntoSortedListOneElementFirst() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(1));
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 2);
  }

  public void testInsertIntoSortedListOneElementLast() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    CollectionUtilities.insertIntoSortedList(list, 1, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 2);
  }

  public void testInsertIntoSortedListTwoElementsFirst() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(1));
    list.add(new Integer(2));
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  public void testInsertIntoSortedListTwoElementsLast() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    list.add(new Integer(1));
    CollectionUtilities.insertIntoSortedList(list, 2, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  public void testInsertIntoSortedListTwoElementsMiddle() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    list.add(new Integer(2));
    CollectionUtilities.insertIntoSortedList(list, 1, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  public void testInsertIntoSortedListEqualElementLast() throws Exception {
    List<Integer> list = new ArrayList<Integer>();
    list.add(0);
    Integer integer = new Integer(0);
    CollectionUtilities.insertIntoSortedList(list, integer, new ComparableComparator<Integer>());
    assertEquals(2, list.size());
    assertEquals(integer, list.get(0));
    assertNotSame(integer, list.get(0));
    assertEquals(integer, list.get(1));
    assertSame(integer, list.get(1));
  }

  public void assertAscendingIntList(List<Integer> list, int expectedSize) throws Exception {
    assertEquals(expectedSize, list.size());
    for (int i = 0; i < list.size(); i++) {
      assertEquals(new Integer(i), list.get(i));
    }
  }
}
