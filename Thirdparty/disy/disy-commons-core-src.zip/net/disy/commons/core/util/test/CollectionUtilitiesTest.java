/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import junit.framework.AssertionFailedError;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.ComparableComparator;
import net.disy.commons.core.util.ITransformer;

import org.junit.Test;

public class CollectionUtilitiesTest {

  @Test
  public void testInsertIntoSortedListEmpty() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 1);
  }

  @Test
  public void testInsertIntoSortedListOneElementFirst() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(1));
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 2);
  }

  @Test
  public void testInsertIntoSortedListOneElementLast() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    CollectionUtilities.insertIntoSortedList(list, 1, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 2);
  }

  @Test
  public void testInsertIntoSortedListTwoElementsFirst() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(1));
    list.add(new Integer(2));
    CollectionUtilities.insertIntoSortedList(list, 0, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  @Test
  public void testInsertIntoSortedListTwoElementsLast() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    list.add(new Integer(1));
    CollectionUtilities.insertIntoSortedList(list, 2, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  @Test
  public void testInsertIntoSortedListTwoElementsMiddle() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(new Integer(0));
    list.add(new Integer(2));
    CollectionUtilities.insertIntoSortedList(list, 1, new ComparableComparator<Integer>());
    assertAscendingIntList(list, 3);
  }

  @Test
  public void testInsertIntoSortedListEqualElementLast() throws Exception {
    final List<Integer> list = new ArrayList<Integer>();
    list.add(0);
    final Integer integer = new Integer(0);
    CollectionUtilities.insertIntoSortedList(list, integer, new ComparableComparator<Integer>());
    assertEquals(2, list.size());
    assertEquals(integer, list.get(0));
    assertNotSame(integer, list.get(0));
    assertEquals(integer, list.get(1));
    assertSame(integer, list.get(1));
  }

  @Test
  public void emptyListIsTransformedToEmptyList() throws Exception {
    final ArrayList<Integer> input = new ArrayList<Integer>();
    assertEquals(
        new ArrayList<Double>(),
        CollectionUtilities.transform(input, new ITransformer<Integer, Double>() {
          @Override
          public Double transform(final Integer object) {
            throw new AssertionFailedError("Should not be called for empty list"); //$NON-NLS-1$
          }
        }));
  }

  @Test
  public void oneElementListIsTransformed() throws Exception {
    final ArrayList<Integer> input = new ArrayList<Integer>();
    input.add(Integer.valueOf(1));
    final ArrayList<Double> expected = new ArrayList<Double>();
    expected.add(Double.valueOf(1.5));
    assertEquals(
        expected,
        CollectionUtilities.transform(input, new ITransformer<Integer, Double>() {
          @Override
          public Double transform(final Integer object) {
            return object + 0.5;
          }
        }));
  }

  @SuppressWarnings("unchecked")
  @Test
  public void concat() throws Exception {
    final List<String> firstList = createList("Hasä"); //$NON-NLS-1$
    final List<String> secondList = createList("Tigger"); //$NON-NLS-1$
    final List<String> concatList = CollectionUtilities.concat(firstList, secondList);
    assertEquals(2, concatList.size());
    assertEquals("Hasä", concatList.get(0)); //$NON-NLS-1$
    assertEquals("Tigger", concatList.get(1)); //$NON-NLS-1$
  }

  private List<String> createList(final String... values) {
    return Arrays.asList(values);
  }

  public void assertAscendingIntList(final List<Integer> list, final int expectedSize)
      throws Exception {
    assertEquals(expectedSize, list.size());
    for (int i = 0; i < list.size(); i++) {
      assertEquals(new Integer(i), list.get(i));
    }
  }

  @Test
  public void minMaxOfEmptyListIsNull() throws Exception {
    final List<Integer> list = Collections.emptyList();
    assertNull(CollectionUtilities.min(list));
    assertNull(CollectionUtilities.max(list));
  }

  @Test
  public void minMaxOfSignletonListIsElement() throws Exception {
    final List<Integer> list = Collections.singletonList(1);
    assertEquals(new Integer(1), CollectionUtilities.min(list));
    assertEquals(new Integer(1), CollectionUtilities.max(list));
  }

  @Test
  public void minMaxOfTwoElements() throws Exception {
    final List<Integer> list = Arrays.asList(new Integer[]{ 1, 2 });
    assertEquals(new Integer(1), CollectionUtilities.min(list));
    assertEquals(new Integer(2), CollectionUtilities.max(list));
  }

  @Test
  public void minMaxOfCollectionContainingNullIsOtherElement() throws Exception {
    final List<Integer> list = Arrays.asList(new Integer[]{ null, 2 });
    assertEquals(new Integer(2), CollectionUtilities.min(list));
    assertEquals(new Integer(2), CollectionUtilities.max(list));
  }

  @Test
  public void minMaxOfCollectionContainingNullOnlyIsNull() throws Exception {
    final List<Integer> list = Arrays.asList(new Integer[]{ null, null });
    assertNull(CollectionUtilities.min(list));
    assertNull(CollectionUtilities.max(list));
  }

  @Test
  public void minMaxOfCollectionContainingTwoNullsAndOtherElementIsOtherElement() throws Exception {
    final List<Integer> list = Arrays.asList(new Integer[]{ null, null, 1 });
    assertEquals(new Integer(1), CollectionUtilities.min(list));
    assertEquals(new Integer(1), CollectionUtilities.max(list));
  }

  @Test
  public void testToArray() {
    final List<Integer> list = new ArrayList<Integer>();
    String[] strings = CollectionUtilities.toArray(
        list,
        String.class,
        new ITransformer<Integer, String>() {
          @Override
          public String transform(final Integer input) {
            return String.valueOf(input);
          }
        });
    assertEquals(0, strings.length);
    list.add(Integer.valueOf(0));
    strings = CollectionUtilities.toArray(list, String.class, new ITransformer<Integer, String>() {
      @Override
      public String transform(final Integer input) {
        return String.valueOf(input);
      }
    });
    assertEquals(1, strings.length);
    assertEquals("0", strings[0]); //$NON-NLS-1$
  }

  @Test
  public void toPrimitiveIntegerArray() throws Exception {
    final ArrayList<Integer> list = new ArrayList<Integer>();
    list.add(1);
    list.add(3);
    final int[] resultArray = CollectionUtilities.toPrimitiveIntArray(list);
    assertThat(resultArray.length, is(2));
    assertThat(resultArray[0], is(1));
    assertThat(resultArray[1], is(3));
  }

  @Test
  public void testEquals() {
    List<Boolean> c1 = null;
    List<Boolean> c2 = null;
    assertTrue(CollectionUtilities.equals(c1, c2));
    c1 = new ArrayList<Boolean>();
    assertFalse(CollectionUtilities.equals(c1, c2));
    assertFalse(CollectionUtilities.equals(c2, c1));
    c2 = new ArrayList<Boolean>();
    assertTrue(CollectionUtilities.equals(c1, c2));
    c1.add(Boolean.FALSE);
    assertFalse(CollectionUtilities.equals(c1, c2));
    c2.add(Boolean.FALSE);
    assertTrue(CollectionUtilities.equals(c1, c2));
    c1.add(Boolean.TRUE);
    c2.add(Boolean.FALSE);
    assertFalse(CollectionUtilities.equals(c1, c2));
  }

  @Test
  public void testHasAnySameEntry() {
    final String eins = "eins";
    final String zwei = "zwei";
    final String drei = "drei";
    final List<String> collection = createList(eins, zwei);
    assertTrue(CollectionUtilities.hasAnySameEntry(collection, createList(eins, drei)));
    assertFalse(CollectionUtilities.hasAnySameEntry(collection, createList(drei)));
    assertFalse(CollectionUtilities.hasAnySameEntry(collection, new ArrayList<String>()));
  }

  @Test
  public void testSubCollection() {
    final String eins = "eins";
    final String zwei = "zwei";
    final String drei = "drei";
    final String vier = "vier";
    List<String> list = createList(eins, zwei, drei, vier);
    Collection<String> subCollection = CollectionUtilities.subCollection(list, 2);
    assertThat(subCollection.size(), equalTo(2));
    assertThat(subCollection.iterator().next(), equalTo("drei"));
  }

}
