/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import net.disy.commons.core.util.StringUtilities;

import org.junit.Test;

public class StringUtilitiesTest {

  @Test
  public void startsWithIgnoreCase() {
    assertFalse(StringUtilities.startsWithIgnoreCase(null, "start")); //$NON-NLS-1$
    assertFalse(StringUtilities.startsWithIgnoreCase("", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertFalse(StringUtilities.startsWithIgnoreCase("foo", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("start", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("sTaRt", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("starten", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("warten", "war")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("foo", "")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void endsWithIgnoreCase() {
    assertFalse(StringUtilities.endsWithIgnoreCase(null, "start")); //$NON-NLS-1$
    assertFalse(StringUtilities.endsWithIgnoreCase("", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertFalse(StringUtilities.endsWithIgnoreCase("foo", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.endsWithIgnoreCase("start", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.endsWithIgnoreCase("sTaRt", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.endsWithIgnoreCase("restart", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.endsWithIgnoreCase("foo", "")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void isNullOrEmpty() {
    assertTrue(StringUtilities.isNullOrEmpty(null));
    assertTrue(StringUtilities.isNullOrEmpty("")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("f")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("foo")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("bar")); //$NON-NLS-1$
  }

  @Test
  public void getDefaultIfEmpty() {
    final String value = "value"; //$NON-NLS-1$
    final String defaultValue = "default"; //$NON-NLS-1$
    assertEquals(StringUtilities.getDefaultIfEmpty(value, defaultValue), value);
    assertEquals(StringUtilities.getDefaultIfEmpty(null, defaultValue), defaultValue);
    assertEquals(StringUtilities.getDefaultIfEmpty("", defaultValue), defaultValue); //$NON-NLS-1$
    assertEquals(StringUtilities.getDefaultIfEmpty(" ", defaultValue), defaultValue); //$NON-NLS-1$
  }

  @Test
  public void lenght() {
    assertThat(-1, equalTo(StringUtilities.length(null)));
    assertThat(0, equalTo(StringUtilities.length(""))); //$NON-NLS-1$
    assertThat(3, equalTo(StringUtilities.length("012"))); //$NON-NLS-1$
  }

  @Test
  public void trimToMaxLength() {
    assertNull(StringUtilities.trimToMaxLength(null, 1));
    assertNull(StringUtilities.trimToMaxLength("Hello", -1)); //$NON-NLS-1$
    assertThat("Hello W", equalTo(StringUtilities.trimToMaxLength("Hello World", 7))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("Hello World", equalTo(StringUtilities.trimToMaxLength("Hello World", 15))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("", equalTo(StringUtilities.trimToMaxLength("Hello World", 0))); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testRemoveAllFromSuffix() {
    assertThat("Hello", equalTo(StringUtilities.removeAllFromSuffix("Hello", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("Hello", equalTo(StringUtilities.removeAllFromSuffix("Hello/", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("Hello", equalTo(StringUtilities.removeAllFromSuffix("Hello///", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testRemoveAllFromPrefix() {
    assertThat("Hello", equalTo(StringUtilities.removeAllFromPrefix("Hello", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("Hello", equalTo(StringUtilities.removeAllFromPrefix("/Hello", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat("Hello", equalTo(StringUtilities.removeAllFromPrefix("///Hello", '/'))); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testIsInteger() {
    assertTrue(StringUtilities.isInteger("345345")); //$NON-NLS-1$
    assertTrue(StringUtilities.isInteger("+345345")); //$NON-NLS-1$
    assertTrue(StringUtilities.isInteger("-345345")); //$NON-NLS-1$
    assertTrue(StringUtilities.isInteger(" -345345 ")); //$NON-NLS-1$
    assertTrue(StringUtilities.isInteger(" - 345345 ")); //$NON-NLS-1$
    assertFalse(StringUtilities.isInteger(null));
    assertFalse(StringUtilities.isInteger("")); //$NON-NLS-1$
    assertFalse(StringUtilities.isInteger("A")); //$NON-NLS-1$
    assertFalse(StringUtilities.isInteger("A345345")); //$NON-NLS-1$
    assertFalse(StringUtilities.isInteger("345345A")); //$NON-NLS-1$
    assertFalse(StringUtilities.isInteger("345A345")); //$NON-NLS-1$
  }
}