//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util.test;

import junit.framework.TestCase;

import net.disy.commons.core.util.StringUtilities;

// NOT_PUBLISHED
public class StringUtilitiesTest extends TestCase {

  public void testStartsWithIgnoreCase() {
    assertFalse(StringUtilities.startsWithIgnoreCase("", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertFalse(StringUtilities.startsWithIgnoreCase("foo", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("start", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("sTaRt", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("starten", "start")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("warten", "war")); //$NON-NLS-1$ //$NON-NLS-2$
    assertTrue(StringUtilities.startsWithIgnoreCase("foo", "")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testIsNullOrEmpty() {
    assertTrue(StringUtilities.isNullOrEmpty(null));
    assertTrue(StringUtilities.isNullOrEmpty("")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("f")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("foo")); //$NON-NLS-1$
    assertFalse(StringUtilities.isNullOrEmpty("bar")); //$NON-NLS-1$
  }
}