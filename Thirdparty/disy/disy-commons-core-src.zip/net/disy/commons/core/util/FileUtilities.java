// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.io.File;
import java.io.IOException;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

//NOT_PUBLISHED
public class FileUtilities {
  private FileUtilities() {
    throw new UnreachableCodeReachedException();
  }
  
  public static void deleteFileOrDirectory(File file) throws IOException {
    if (!file.exists()) {
      return;
    }
    
    if (file.isDirectory()) {
      File[] files = file.listFiles();
      for (int index = 0; index < files.length; index++) {
        deleteFileOrDirectory(files[index]);
      }
    }
    
    if (!file.delete()) {
      throw new IOException("delete failed for file '" + file.getAbsolutePath() + "'"); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }
}
