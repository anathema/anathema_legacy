// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.io.File;
import java.io.IOException;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

//NOT_PUBLISHED
public class FileUtilities {

  protected FileUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static void deleteFileOrDirectory(File file) throws IOException {
    if (!file.exists()) {
      return;
    }

    if (file.isDirectory()) {
      File[] files = file.listFiles();
      for (int index = 0; index < files.length; index++) {
        deleteFileOrDirectory(files[index]);
      }
    }

    if (!file.delete()) {
      throw new IOException("delete failed for file '" + file.getAbsolutePath() + "'"); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static String getExtension(File file) {
    return getExtension(file.getName());
  }

  /**
   * Get extension from filename. ie
   * 
   * <pre>
   *  foo.txt --> "txt" a\b\c.jpg --> "jpg" a\b\c --> "" *</pre>
   * 
   * @param filename the filename
   * @return the extension of filename or "" if none
   * @deprecated As of 11.01.2006 (gebhard), replaced by {@link #getExtension(File)}
   */
  public static String getExtension(final String filename) {
    int lastDot = filename.lastIndexOf('.');
    return lastDot >= 0 ? filename.substring(lastDot + 1) : ""; //$NON-NLS-1$
  }

  public static File addExtension(File file, String extension) {
    return new File(addExtension(file.getPath(), extension));
  }

  public static String addExtension(String fileName, String extension) {
    if (!extension.startsWith(".")) { //$NON-NLS-1$
      extension = "." + extension; //$NON-NLS-1$
    }
    if (!fileName.endsWith(extension)) {
      return fileName + extension;
    }
    return fileName;
  }
}