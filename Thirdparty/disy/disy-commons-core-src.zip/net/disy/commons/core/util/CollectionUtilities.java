//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

// NOT_PUBLISHED
public class CollectionUtilities {
  public static void forAllDo(Collection collection, IClosure closure) {
    Ensure.ensureArgumentNotNull(collection);
    Ensure.ensureArgumentNotNull(closure);
    for (Iterator iter = collection.iterator(); iter.hasNext();) {
      closure.execute(iter.next());
    }
  }

  public static void insertIntoSortedList(List list, Object item, Comparator comparator) {
    insertIntoSortedList(list, item, comparator, 0, list.size());
  }

  private static void insertIntoSortedList(
      List list,
      Object item,
      Comparator comparator,
      int startIndex,
      int endIndex) {
    if (startIndex == endIndex) {
      list.add(startIndex, item);
      return;
    }

    int middleIndex = (startIndex + endIndex) / 2;
    Object middleItem = list.get(middleIndex);
    if (comparator.compare(item, middleItem) < 0) {
      insertIntoSortedList(list, item, comparator, startIndex, middleIndex);
    }
    else {
      insertIntoSortedList(list, item, comparator, middleIndex + 1, endIndex);
    }
  }
}
