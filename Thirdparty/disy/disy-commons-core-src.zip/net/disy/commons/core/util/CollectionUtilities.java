//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Collection;
import java.util.Comparator;
import java.util.List;

import net.disy.commons.core.predicate.IPredicate;

// NOT_PUBLISHED
public class CollectionUtilities {
  public static <T> void forAllDo(Collection<T> collection, IClosure<T> closure) {
    Ensure.ensureArgumentNotNull(collection);
    Ensure.ensureArgumentNotNull(closure);
    for (T element : collection) {
      closure.execute(element);
    }
  }

  public static <T> void insertIntoSortedList(List<T> list, T item, Comparator<T> comparator) {
    insertIntoSortedList(list, item, comparator, 0, list.size());
  }

  private static <T> void insertIntoSortedList(
      List<T> list,
      T item,
      Comparator<T> comparator,
      int startIndex,
      int endIndex) {
    if (startIndex == endIndex) {
      list.add(startIndex, item);
      return;
    }

    int middleIndex = (startIndex + endIndex) / 2;
    T middleItem = list.get(middleIndex);
    if (comparator.compare(item, middleItem) < 0) {
      insertIntoSortedList(list, item, comparator, startIndex, middleIndex);
    }
    else {
      insertIntoSortedList(list, item, comparator, middleIndex + 1, endIndex);
    }
  }

  public static <T> T find(Collection<T> collection, IPredicate<T> predicate) {
    if (collection != null && predicate != null) {
      for (T item : collection) {
        if (predicate.evaluate(item)) {
          return item;
        }
      }
    }
    return null;
  }

  public static <E> void forEach(Collection<E> collection, IClosure<E> block) {
    if (collection == null) {
      return;
    }
    for (E element : collection) {
      block.execute(element);
    }
  }

}
