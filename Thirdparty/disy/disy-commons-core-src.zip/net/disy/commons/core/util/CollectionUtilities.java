//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.core.util;

import java.util.Collection;
import java.util.Iterator;

// NOT_PUBLISHED
public class CollectionUtilities {
  public static void forAllDo(Collection collection, IClosure closure) {
    Ensure.ensureArgumentNotNull(collection);
    Ensure.ensureArgumentNotNull(closure);
    for (Iterator iter = collection.iterator(); iter.hasNext();) {
      closure.execute(iter.next());
    }
  }
}
