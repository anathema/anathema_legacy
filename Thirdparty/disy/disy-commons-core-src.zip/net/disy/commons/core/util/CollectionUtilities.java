/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.util;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.provider.IProvider;
import net.disy.commons.core.string.StringConcatenationBuilder;

public class CollectionUtilities {

  public static <T> void insertIntoSortedList(
      final List<T> list,
      final T item,
      final Comparator<T> comparator) {
    insertIntoSortedList(list, item, comparator, 0, list.size());
  }

  private static <T> void insertIntoSortedList(
      final List<T> list,
      final T item,
      final Comparator<T> comparator,
      final int startIndex,
      final int endIndex) {
    if (startIndex == endIndex) {
      list.add(startIndex, item);
      return;
    }

    final int middleIndex = (startIndex + endIndex) / 2;
    final T middleItem = list.get(middleIndex);
    if (comparator.compare(item, middleItem) < 0) {
      insertIntoSortedList(list, item, comparator, startIndex, middleIndex);
    }
    else {
      insertIntoSortedList(list, item, comparator, middleIndex + 1, endIndex);
    }
  }

  public static <T> void forAllDo(final Collection<T> collection, final IClosure<T> closure) {
    Ensure.ensureArgumentNotNull(collection);
    Ensure.ensureArgumentNotNull(closure);
    for (final T element : collection) {
      closure.execute(element);
    }
  }

  @SuppressWarnings("unchecked")
  public static <T> void addCasted(final Collection<T> valuesSet, final Object object) {
    valuesSet.add((T) object);
  }

  @SuppressWarnings("unchecked")
  public static <B> B[] toArray(final Collection<B> collection, final Class<B> clazz) {
    return collection.toArray((B[]) Array.newInstance(clazz, collection.size()));
  }

  public static int[] toPrimitiveIntArray(final Collection<Integer> collection) {
    final int[] result = new int[collection.size()];
    int index = 0;
    for (final Integer integer : collection) {
      if (integer == null) {
        throw new IllegalArgumentException();
      }
      result[index++] = integer.intValue();
    }
    return result;
  }

  public static double[] toPrimitiveDoubleArray(final Collection<Double> collection) {
    final double[] result = new double[collection.size()];
    int index = 0;
    for (final Double integer : collection) {
      if (integer == null) {
        throw new IllegalArgumentException();
      }
      result[index++] = integer.doubleValue();
    }
    return result;
  }

  public static <I, O> O[] toArray(
      final Iterable<I> iterable,
      final Class<O> clazz,
      final ITransformer<I, O> transformer) {
    final List<O> result = new ArrayList<O>();
    for (final I item : iterable) {
      result.add(transformer.transform(item));
    }
    return toArray(result, clazz);
  }

  public static <I> I[] toArray(final Iterable<I> iterable, final Class<I> clazz) {
    final List<I> result = new ArrayList<I>();
    for (final I item : iterable) {
      result.add(item);
    }
    return toArray(result, clazz);
  }

  public static <I, O> List<O> transform(
      final Iterable<I> input,
      final ITransformer<? super I, ? extends O> transformer) {
    final List<O> outputList = new ArrayList<O>();
    for (final I inputElement : input) {
      outputList.add(transformer.transform(inputElement));
    }
    return outputList;
  }

  public static <I, O, T extends Throwable> List<O> transform(
      final Iterable<I> input,
      final IExceptionThrowingTransformer<? super I, ? extends O, T> transformer) throws T {
    final List<O> outputList = new ArrayList<O>();
    for (final I inputElement : input) {
      outputList.add(transformer.transform(inputElement));
    }
    return outputList;
  }

  public static <T> boolean contains(
      final Iterable<? extends T> iterable,
      final IPredicate<T> predicate) {
    for (final T value : iterable) {
      if (predicate.evaluate(value)) {
        return true;
      }
    }
    return false;
  }

  public static <T> T getFirst(final Iterable<? extends T> iterable, final IPredicate<T> predicate) {
    return getFirst(iterable, predicate, new NullProvider<T>());
  }

  public static <T> T getFirst(
      final Iterable<? extends T> iterable,
      final IPredicate<T> predicate,
      final IProvider<T> fallback) {
    if (iterable != null && predicate != null) {
      for (final T item : iterable) {
        if (predicate.evaluate(item)) {
          return item;
        }
      }
    }
    return fallback.getObject();
  }

  public static <T> List<T> filter(
      final Iterable<? extends T> iterable,
      final IPredicate<T> predicate) {
    final List<T> values = new ArrayList<T>();
    if (iterable != null && predicate != null) {
      for (final T item : iterable) {
        if (predicate.evaluate(item)) {
          values.add(item);
        }
      }
    }
    return values;
  }

  public static <T> List<T> copy(final Iterable<? extends T> iterable) {
    final List<T> values = new ArrayList<T>();
    if (iterable != null) {
      for (final T item : iterable) {
        values.add(item);
      }
    }
    return values;
  }

  public static <T> List<T> concat(final Collection<T>... collections) {
    final ArrayList<T> concatList = new ArrayList<T>();
    for (final Collection<T> collection : collections) {
      concatList.addAll(collection);
    }
    return concatList;
  }

  public static <T> List<T> concat(final Collection<T> collection, final T... elements) {
    final ArrayList<T> concatList = new ArrayList<T>();
    concatList.addAll(collection);
    for (final T element : elements) {
      concatList.add(element);
    }
    return concatList;
  }

  public static <T extends Comparable<? super T>> T min(final Iterable<? extends T> collection) {
    final List<T> filteredList = filter(collection, new NonNullPredicate<T>());
    return filteredList.isEmpty() ? null : Collections.min(filteredList);
  }

  public static <T> T min(final Iterable<? extends T> collection, Comparator<T> comparator) {
    final List<T> filteredList = filter(collection, new NonNullPredicate<T>());
    return filteredList.isEmpty() ? null : Collections.min(filteredList, comparator);
  }

  public static <T extends Comparable<? super T>> T max(final Iterable<? extends T> collection) {
    final List<T> filteredList = filter(collection, new NonNullPredicate<T>());
    return filteredList.isEmpty() ? null : Collections.max(filteredList);
  }

  public static <T> T max(final Iterable<? extends T> collection, Comparator<T> comparator) {
    final List<T> filteredList = filter(collection, new NonNullPredicate<T>());
    return filteredList.isEmpty() ? null : Collections.max(filteredList, comparator);
  }

  @SuppressWarnings("nls")
  public static String getRepresentation(final Iterable<?> iterable) {
    return getRepresentation(iterable, "[", ",", "]");
  }

  public static <T> String getRepresentation(
      final Iterable<T> iterable,
      final String prefix,
      final String separator,
      final String postfix) {
    return getRepresentation(iterable, prefix, separator, postfix, new IFormatter<T>() {
      @Override
      public String format(final T value) {
        if (value instanceof Object[]) {
          return ArrayUtilities.getRepresentation((Object[]) value);
        }

        return String.valueOf(value);
      }
    });
  }

  public static <T> String getRepresentation(
      final Iterable<T> iterable,
      final String prefix,
      final String separator,
      final String postfix,
      final IFormatter<T> formatter) {
    if (iterable == null) {
      return null;
    }
    final StringConcatenationBuilder builder = new StringConcatenationBuilder(separator);
    for (final T value : iterable) {
      builder.append(formatter.format(value));
    }
    return prefix + builder.getString() + postfix;
  }

  public final static <T> boolean equals(final Collection<T> i1, final Collection<T> i2) {
    return ObjectUtilities.equals(
        i1 == null ? null : i1.toArray(),
        i2 == null ? null : i2.toArray());
  }

  public static <T> int indexOf(final List<T> values, final IPredicate<T> predicate) {
    for (int i = 0; i < values.size(); i++) {
      if (predicate.evaluate(values.get(i))) {
        return i;
      }
    }
    return -1;
  }

  public static <T> int count(final List<T> values, final IPredicate<T> predicate) {
    int count = 0;
    for (final T value : values) {
      if (predicate.evaluate(value)) {
        count++;
      }
    }
    return count;
  }

  public static <T> int[] indicesOf(final List<T> values, final IPredicate<T> predicate) {
    final List<Integer> indices = new ArrayList<Integer>();
    for (int i = 0; i < values.size(); i++) {
      if (predicate.evaluate(values.get(i))) {
        indices.add(i);
      }
    }
    return ArrayUtilities.toPrimitive(indices.toArray(new Integer[indices.size()]));
  }

  public static <T> int[] getIndices(final List<T> values, final List<T> allValues) {
    final int[] indices = new int[values.size()];
    for (int i = 0; i < values.size(); i++) {
      indices[i] = allValues.indexOf(values.get(i));
    }
    return indices;
  }

  public static <T> boolean hasAnySameEntry(
      final Collection<T> collection,
      final Collection<T> other) {
    if (other.isEmpty()) {
      return false;
    }
    for (final T entry : collection) {
      if (contains(other, new IPredicate<T>() {

        @Override
        public boolean evaluate(final T value) {
          return entry == value;
        }
      })) {
        return true;
      }
    }
    return false;
  }

  public static <T> boolean containsDuplicates(final Collection<T> values) {
    return values.size() > new HashSet<T>(values).size();
  }

  public static <T> int indexOf(final Iterable<T> values, final IPredicate<T> predicate) {
    int counter = 0;
    for (final T value : values) {
      if (predicate.evaluate(value)) {
        return counter;
      }
      counter++;
    }
    return -1;
  }

  public static <T> Set<T> createSet(final T... elements) {
    final HashSet<T> set = new HashSet<T>();
    Collections.addAll(set, elements);
    return set;
  }

  public static <T> List<T> createList(final T... elements) {
    final List<T> list = new ArrayList<T>();
    Collections.addAll(list, elements);
    return list;
  }

  public static <T> Collection<T> subCollection(final List<T> list, final int startIndex) {
    int counter = 0;
    final List<T> sublist = new ArrayList<T>();
    for (final T value : list) {
      if (counter >= startIndex) {
        sublist.add(value);
      }
      counter++;
    }
    return sublist;
  }

  public static <T> boolean haveSameElements(
      final Collection<T> firstCollection,
      final Collection<T> secondCollection) {
    if (firstCollection == secondCollection) {
      return true;
    }
    if (firstCollection == null || secondCollection == null) {
      return false;
    }
    return firstCollection.containsAll(secondCollection)
        && secondCollection.containsAll(firstCollection);
  }

  @Deprecated
  /**
   * @deprecated as of 06.07.2011 (ekramer), use isNullOrEmpty instead
   */
  public static boolean isNotEmtpy(final Collection<?> collection) {
    return !isNullOrEmpty(collection);
  }

  public static boolean isNullOrEmpty(final Collection<?> collection) {
    return collection == null || collection.size() == 0;
  }
}