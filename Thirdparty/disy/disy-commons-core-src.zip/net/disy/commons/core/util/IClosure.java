package net.disy.commons.core.util;

public interface IClosure<T> {
  public void execute(T each);
}
