/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.date.test;

import static junit.framework.Assert.*;

import net.disy.commons.core.date.DateConfiguration;

import org.junit.Test;

public class DateConfigurationTest {

  @Test
  public void yyyyMMdd() throws Exception {
    final DateConfiguration configuration = new DateConfiguration("yyyMMdd"); //$NON-NLS-1$
    assertTrue(configuration.isDateEnabled());
    assertTrue(configuration.isDayEnabled());
    assertTrue(configuration.isMonthEnabled());
    assertTrue(configuration.isYearEnabled());
    assertFalse(configuration.isTimeEnabled());
    assertFalse(configuration.isHourEnabled());
    assertFalse(configuration.isMinuteEnabled());
    assertFalse(configuration.isSecondEnabled());
  }
}