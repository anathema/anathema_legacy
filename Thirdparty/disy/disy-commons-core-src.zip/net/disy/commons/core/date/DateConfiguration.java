/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.core.date;

import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.StringTokenizer;

public class DateConfiguration implements IDateConfiguration, IDateParser {

  private static final String DATE_FORMAT_COMMENT_DELIMITER = "'"; //$NON-NLS-1$
  private static final String DEFAULT_PATTERN = "dd.MM.yyyy HH:mm:ss"; //$NON-NLS-1$
  private final String pattern;
  private final boolean yearEnabled;
  private final boolean monthEnabled;
  private final boolean dayEnabled;
  private final boolean hourEnabled;
  private final boolean minuteEnabled;
  private final boolean secondEnabled;

  public DateConfiguration() {
    this(null);
  }

  public DateConfiguration(final String pattern) {
    this.pattern = pattern == null ? DEFAULT_PATTERN : pattern;
    try {
      createDateFormat();
    }
    catch (IllegalArgumentException iaex) {
      throw new IllegalArgumentException(MessageFormat.format(
          "Invalid date pattern [{0}].",
          pattern), iaex);
    }
    final String pureDateFormatPattern = getPureDateFormat(this.pattern);
    this.yearEnabled = containsAnyChar(pureDateFormatPattern, "y"); //$NON-NLS-1$
    this.monthEnabled = containsAnyChar(pureDateFormatPattern, "MDw"); //$NON-NLS-1$
    this.dayEnabled = containsAnyChar(pureDateFormatPattern, "dDEFwW"); //$NON-NLS-1$
    this.hourEnabled = containsAnyChar(pureDateFormatPattern, "hHkKa"); //$NON-NLS-1$
    this.minuteEnabled = containsAnyChar(pureDateFormatPattern, "m"); //$NON-NLS-1$
    this.secondEnabled = containsAnyChar(pureDateFormatPattern, "s"); //$NON-NLS-1$
  }

  @Override
  public String getFormatPattern() {
    return pattern;
  }

  @Override
  public boolean isYearEnabled() {
    return yearEnabled;
  }

  @Override
  public boolean isDayEnabled() {
    return dayEnabled;
  }

  @Override
  public boolean isMonthEnabled() {
    return monthEnabled;
  }

  @Override
  public boolean isHourEnabled() {
    return hourEnabled;
  }

  @Override
  public boolean isMinuteEnabled() {
    return minuteEnabled;
  }

  @Override
  public boolean isSecondEnabled() {
    return secondEnabled;
  }

  private boolean containsAnyChar(String s, String chars) {
    int len = chars.length();
    for (int i = 0; i < len; i++) {
      if (s.indexOf(chars.charAt(i)) >= 0) {
        return true;
      }
    }
    return false;
  }

  private String getPureDateFormat(String dateFormatPattern) {
    //Strip non-date format related substrings (in apostrophs)
    StringTokenizer st = new StringTokenizer(dateFormatPattern, DATE_FORMAT_COMMENT_DELIMITER, true);
    StringBuffer sb = new StringBuffer();
    boolean outsideComment = true;
    while (st.hasMoreTokens()) {
      String token = st.nextToken();
      if (token.equals(DATE_FORMAT_COMMENT_DELIMITER)) {
        outsideComment = !outsideComment;
      }
      else if (outsideComment) {
        sb.append(token);
      }
    }
    return sb.toString();
  }

  @Override
  public boolean isDateEnabled() {
    return isYearEnabled() || isMonthEnabled() || isDayEnabled();
  }

  @Override
  public boolean isTimeEnabled() {
    return isHourEnabled() || isMinuteEnabled() || isSecondEnabled();
  }

  @Override
  public String formatDate(Date time) {
    return createDateFormat().format(time);
  }

  @Override
  public Date parseDate(String dateString) throws ParseException {
    return dateString == null ? null : createDateFormat().parse(dateString);
  }

  private DateFormat createDateFormat() throws IllegalArgumentException {
    return new SimpleDateFormat(getFormatPattern());
  }

}