/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import net.disy.commons.swing.action.ActionGroupId;
import net.disy.commons.swing.action.ActionGroupMenuBuilder;
import net.disy.commons.swing.action.SmartAction;

import org.junit.Test;

public class ActionGroupMenuBuilderTest {

  @Test
  public void testEmpty() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    final JPopupMenu popupMenu = builder.createPopupMenu();
    assertTrue(builder.isEmpty());
    assertEquals(0, popupMenu.getComponentCount());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddNullAction() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(ActionGroupId.EDIT, (Action) null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddNullGroupAndNullAction() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(null, (Action) null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testAddNullGroup() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(null, new SmartAction() {
      @Override
      protected void execute(final Component parentComponent) {
        //nothing to do            
      }
    });
  }

  @Test
  public void testAddSingleAction() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(ActionGroupId.EXECUTE, new SmartAction("test") { //$NON-NLS-1$
          @Override
          protected void execute(final Component parentComponent) {
            //nothing to do            
          }
        });
    assertFalse(builder.isEmpty());
    final JPopupMenu popupMenu = builder.createPopupMenu();
    assertEquals(1, popupMenu.getComponentCount());
    assertEquals("test", ((JMenuItem) popupMenu.getComponent(0)).getText()); //$NON-NLS-1$
  }

  @Test
  public void testAddTwoActionsSameGroupId() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(ActionGroupId.EXECUTE, createDummyAction("test1")); //$NON-NLS-1$
    builder.add(ActionGroupId.EXECUTE, createDummyAction("test2")); //$NON-NLS-1$
    final JPopupMenu popupMenu = builder.createPopupMenu();
    assertEquals(2, popupMenu.getComponentCount());
    assertEquals("test1", ((JMenuItem) popupMenu.getComponent(0)).getText()); //$NON-NLS-1$
    assertEquals("test2", ((JMenuItem) popupMenu.getComponent(1)).getText()); //$NON-NLS-1$
  }

  @Test
  public void testAddTwoActionsDifferentGroupId() {
    final ActionGroupMenuBuilder builder = new ActionGroupMenuBuilder();
    builder.add(ActionGroupId.PROPERTIES, createDummyAction("test2")); //$NON-NLS-1$
    builder.add(ActionGroupId.EDIT, createDummyAction("test1")); //$NON-NLS-1$
    final JPopupMenu popupMenu = builder.createPopupMenu();
    assertEquals(3, popupMenu.getComponentCount());
    assertEquals("test1", ((JMenuItem) popupMenu.getComponent(0)).getText()); //$NON-NLS-1$
    org.junit.Assert.assertThat(
        popupMenu.getComponent(1),
        is(instanceOf(JPopupMenu.Separator.class)));
    assertEquals("test2", ((JMenuItem) popupMenu.getComponent(2)).getText()); //$NON-NLS-1$
  }

  private SmartAction createDummyAction(final String actionName) {
    return new SmartAction(actionName) {
      @Override
      protected void execute(final Component parentComponent) {
        //nothing to do            
      }
    };
  }
}