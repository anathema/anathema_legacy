/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.demo;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.icon.SwingIcons;
import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;

public class SmartToggleActionDemo extends SwingDemoCase {

  @Demo
  public void demo() {
    final BooleanModel model = new BooleanModel();
    model.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        System.out.println("Model changed to " + model.getValue()); //$NON-NLS-1$
      }
    });
    SmartToggleAction smartToggleAction = new SmartToggleAction(model, SwingIcons
        .getFileViewHardDriveIcon());
    show(ActionWidgetFactory.createToggleButton(smartToggleAction));
  }
}
