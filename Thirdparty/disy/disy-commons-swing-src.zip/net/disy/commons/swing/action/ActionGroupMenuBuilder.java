/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import net.disy.commons.core.grouped.ComparableGroupHandler;
import net.disy.commons.core.grouped.SeparatorGroupItemStructureBuilder;
import net.disy.commons.core.grouped.IGroupedItem;
import net.disy.commons.core.grouped.IStructuredItemAddable;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.grouped.MenuItemAddable;
import net.disy.commons.swing.action.grouped.PopupMenuItemAddable;

public class ActionGroupMenuBuilder {

  private static final class GroupedItemWrapper implements IGroupedItem<ActionGroupId, JMenuItem> {
    private final GroupedMenuItem menuItem;

    private GroupedItemWrapper(final GroupedMenuItem menuItem) {
      this.menuItem = menuItem;
    }

    @Override
    public ActionGroupId getGroupId() {
      return menuItem.getActionGroupId();
    }

    @Override
    public JMenuItem getItem() {
      return menuItem.getMenuItem();
    }
  }

  private final SeparatorGroupItemStructureBuilder<ActionGroupId, JMenuItem> structureBuilder = new SeparatorGroupItemStructureBuilder<ActionGroupId, JMenuItem>(
      new ComparableGroupHandler<ActionGroupId>());

  public JPopupMenu createPopupMenu() {
    final JPopupMenu menu = new JPopupMenu();
    addAllItemsPriorized(new PopupMenuItemAddable(menu));
    return menu;
  }

  public JMenu createMenu(final IActionConfiguration menuConfiguration) {
    final JMenu menu = new JMenu(new SmartAction(menuConfiguration) {
      @Override
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    });
    addAllItemsPriorized(new MenuItemAddable(menu));
    return menu;
  }

  private void addAllItemsPriorized(final IStructuredItemAddable<JMenuItem> addable) {
    structureBuilder.addAllItemsTo(addable);
  }

  public void add(final ActionGroupId groupId, final Action action) {
    add(new GroupedMenuItem(action, groupId));
  }

  public void add(final ActionGroupId groupId, final JMenuItem menuItem) {
    add(new GroupedMenuItem(menuItem, groupId));
  }

  public void add(final GroupedMenuItem menuItem) {
    Ensure.ensureArgumentNotNull(menuItem);
    structureBuilder.add(new GroupedItemWrapper(menuItem));
  }

  public void add(final GroupedMenuItem[] menuItems) {
    Ensure.ensureArgumentNotNull(menuItems);
    Ensure.ensureArgumentArrayContentsNotNull(menuItems);
    for (final GroupedMenuItem menuItem : menuItems) {
      structureBuilder.add(new GroupedItemWrapper(menuItem));
    }
  }

  public boolean isEmpty() {
    return structureBuilder.isEmpty();
  }
}