/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action;

import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.Action;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;

public class DisableableProxyAction extends AbstractAction implements IActionProxy {

  private final Action action;
  private boolean enabled = true;

  public DisableableProxyAction(final Action action) {
    Ensure.ensureArgumentNotNull(action);
    this.action = action;
    action.addPropertyChangeListener(new PropertyChangeListener() {
      @Override
      public void propertyChange(final PropertyChangeEvent evt) {
        firePropertyChange(evt.getPropertyName(), evt.getOldValue(), evt.getNewValue());
      }
    });
  }

  @Override
  public boolean isEnabled() {
    return enabled && action.isEnabled();
  }

  @Override
  public void setEnabled(final boolean enabled) {
    if (this.enabled == enabled) {
      return;
    }
    this.enabled = enabled;
    firePropertyChange("enabled", //$NON-NLS-1$
        Boolean.valueOf(!isEnabled()),
        Boolean.valueOf(isEnabled()));
  }

  @Override
  public void actionPerformed(final ActionEvent e) {
    action.actionPerformed(e);
  }

  @Override
  public Object getValue(final String key) {
    return action.getValue(key);
  }

  @Override
  public void putValue(final String key, final Object newValue) {
    action.putValue(key, newValue);
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof DisableableProxyAction)) {
      return false;
    }
    DisableableProxyAction other = (DisableableProxyAction) obj;
    return ObjectUtilities.equals(other.action, action) && enabled == other.enabled;
  }

  @Override
  public int hashCode() {
    return ObjectUtilities.getHashCode(action);
  }

  @Override
  public Action getOriginalAction() {
    return action;
  }
}