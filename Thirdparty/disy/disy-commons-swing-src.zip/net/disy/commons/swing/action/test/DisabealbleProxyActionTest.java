/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.test;

import static org.junit.Assert.*;

import javax.swing.Action;

import net.disy.commons.core.testing.Assert;
import net.disy.commons.swing.action.DisableableProxyAction;
import net.disy.commons.swing.action.demo.DummySmartAction;

import org.junit.Before;
import org.junit.Test;

public class DisabealbleProxyActionTest {

  private Action action;
  private DisableableProxyAction proxyAction;

  @Before
  public void createProxyAction() throws Exception {
    action = new DummySmartAction();
    proxyAction = new DisableableProxyAction(action);
  }

  @Test
  public void notEqualsSomeObject() throws Exception {
    Assert.assertNotEquals(proxyAction, new Object());
  }

  @Test
  public void isEnabled() throws Exception {
    assertTrue(proxyAction.isEnabled());
  }

  @Test
  public void equalsWithSameDelegateBothEnabled() throws Exception {
    DisableableProxyAction other = new DisableableProxyAction(action);
    other.setEnabled(proxyAction.isEnabled());
    assertEquals(proxyAction, other);
  }

  @Test
  public void doesNotEqualsProxyActionWithSameDelegateAndOtherEnabledState() throws Exception {
    DisableableProxyAction other = new DisableableProxyAction(action);
    other.setEnabled(!proxyAction.isEnabled());
    Assert.assertNotEquals(proxyAction, other);
  }
}