// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 07.02.2006
package net.disy.commons.swing.action.demo;

import java.awt.Component;

import javax.swing.Icon;

import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;

// NOT_PUBLISHED
public class DummySmartAction extends SmartAction {

  public DummySmartAction() {
    super();
  }

  public DummySmartAction(String name) {
    super(name);
  }

  public DummySmartAction(String name, Icon icon) {
    super(name, icon);
  }

  public DummySmartAction(Icon icon) {
    super(icon);
  }

  public DummySmartAction(IActionConfiguration configuration) {
    super(configuration);
  }

  @Override
  protected final void execute(Component parentComponent) {
    // nothing to do
  }
}