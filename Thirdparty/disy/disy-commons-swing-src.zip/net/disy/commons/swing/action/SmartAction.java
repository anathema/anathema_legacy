package net.disy.commons.swing.action;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.KeyStroke;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.GuiUtilities;

/**
 * @author Markus Gebhard
 */
public abstract class SmartAction extends AbstractAction implements Action {

  private Component explicitParentComponent;
  private Icon icon;
  private Icon disabledIcon;

  public SmartAction() {
    this(new ActionConfiguration());
  }

  public SmartAction(String name) {
    this(new ActionConfiguration(name, null));
  }

  public SmartAction(String name, Icon icon) {
    this(new ActionConfiguration(name, icon));
  }

  public SmartAction(Icon icon) {
    this(null, icon);
  }

  public SmartAction(IActionConfiguration configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    setName(configuration.getName());
    setIcon(configuration.getIcon());
    setToolTipText(configuration.getToolTipText());
    addPropertyChangeListener(new PropertyChangeListener() {
      public void propertyChange(PropertyChangeEvent evt) {
        if ("enabled".equals(evt.getPropertyName())) { //$NON-NLS-1$
          updateIcon();
        }
      }
    });
  }

  public IActionConfiguration getActionConfiguration() {
    return new ActionConfiguration(getName(), getIcon(), getToolTipText());
  }

  /** For Tree/Table/...CellEditors the parentComponent cannot be determined from the ActionEvent.
   * So you can set an explicit parentComponent here. */
  //TODO 20.01.2006 (gebhard): Verify if this is still necessary with JDK >= 1.5
  public void setExplicitParentComponent(Component explicitParentComponent) {
    this.explicitParentComponent = explicitParentComponent;
  }

  /**
   * Sets the name of the action - may include the mnemonic character but must
   * not contain line delimiters. Mnemonics are indicated by an '&' that causes
   * the next character to be the mnemonic. When the user presses a key
   * sequence that matches the mnemonic, a selection event occurs. On most
   * platforms, the mnemonic appears underlined but may be emphasised in a
   * platform specific manner. The mnemonic indicator character '&' can be
   * escaped by doubling it in the string, causing a single '&' to be
   * displayed.
   */
  public void setName(String name) {
    if (name != null) {
      int index = -1;
      boolean found = false;
      do {
        ++index;
        index = name.indexOf('&', index);
        if (index != -1 && index + 1 < name.length()) {
          if (name.charAt(index + 1) == '&') {
            name = name.substring(0, index) + name.substring(index + 1);
          }
          else {
            found = true;
            break;
          }
        }
      } while (index != -1 && index + 1 < name.length());
      if (found) {
        char mnemonic = name.charAt(index + 1);
        setMnemonic(mnemonic);
        name = name.substring(0, index) + name.substring(index + 1);
      }
    }
    putValue(Action.NAME, name);
  }

  public final void actionPerformed(ActionEvent e) {
    Component parentComponent = explicitParentComponent == null ? GuiUtilities
        .getWindowForComponent(e) : explicitParentComponent;
    execute(parentComponent);
  }

  /** Called from the action when being invoked by the user. The given parentComponeent can
   * be used as parent for any dialogs shown in this method.
   * 
   * @param parentComponent A parent component from which the action was invoked. Can be used
   * as parent for new dialogs.
   */
  protected abstract void execute(Component parentComponent);

  public final void setMnemonic(int keyCode) {
    putValue(MNEMONIC_KEY, new Integer(keyCode));
  }

  public final void setMnemonic(char character) {
    char ch = Character.toUpperCase(character);
    if (!isLetter(ch) && !isDigit(ch)) {
      throw new IllegalArgumentException("Unsupported mnemonic character'" + character + "'."); //$NON-NLS-1$ //$NON-NLS-2$
    }
    setMnemonic((int) ch);
  }

  public final void setAcceleratorKey(KeyStroke keyStroke) {
    putValue(ACCELERATOR_KEY, keyStroke);
  }

  private static boolean isDigit(char ch) {
    return ch >= '0' && ch <= '9';
  }

  private static boolean isLetter(char ch) {
    return ch >= 'A' && ch <= 'Z';
  }

  public final String getName() {
    return (String) getValue(Action.NAME);
  }

  public final void setIcon(Icon icon) {
    this.icon = icon;
    updateIcon();
  }

  private void updateIcon() {
    if (!isEnabled()) {
      if (disabledIcon != null) {
        putValue(SMALL_ICON, disabledIcon);
      }
      else {
        putValue(SMALL_ICON, icon);
      }
      return;
    }
    if (icon != null) {
      putValue(SMALL_ICON, icon);
    }
  }

  public void setDisabledIcon(Icon disabledIcon) {
    //Workaround for JButtons to paint disabled Icons as disabled on their own, when the icon is
    //an instance of ImageIcon.
    if (disabledIcon instanceof ImageIcon) {
      disabledIcon = new ProxyIcon(disabledIcon);
    }
    this.disabledIcon = disabledIcon;
    updateIcon();
  }

  public final void setToolTipText(String shortDescription) {
    putValue(Action.SHORT_DESCRIPTION, shortDescription);
  }

  public final String getToolTipText() {
    return (String) getValue(Action.SHORT_DESCRIPTION);
  }

  public final Icon getIcon() {
    return (Icon) getValue(Action.SMALL_ICON);
  }

  private final static class ProxyIcon implements Icon {
    private final Icon icon;

    public ProxyIcon(Icon icon) {
      this.icon = icon;
    }

    public void paintIcon(Component c, Graphics g, int x, int y) {
      icon.paintIcon(c, g, x, y);
    }

    public int getIconWidth() {
      return icon.getIconWidth();
    }

    public int getIconHeight() {
      return icon.getIconHeight();
    }
  }
}