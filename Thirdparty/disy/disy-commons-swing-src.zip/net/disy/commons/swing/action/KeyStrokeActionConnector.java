/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action;

import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JComponent;
import javax.swing.KeyStroke;

public class KeyStrokeActionConnector {

  public static void connect(JComponent component, Action action, String keyStrokeString) {
    connect(component, action, KeyStroke.getKeyStroke(keyStrokeString));
  }

  private static void connect(
      JComponent component,
      Action action,
      String actionKey,
      KeyStroke keyStroke) {
    InputMap inputMap = component.getInputMap();
    inputMap.put(keyStroke, actionKey);
    ActionMap actionMap = component.getActionMap();
    actionMap.put(actionKey, action);
  }

  public static void connect(JComponent component, Action action, KeyStroke keyStroke) {
    String actionKey = "ModifierBasedKeyStrokeActionKey" + keyStroke.getKeyCode() + "-" + keyStroke.getModifiers(); //$NON-NLS-1$ //$NON-NLS-2$
    connect(component, action, actionKey, keyStroke);
  }
}