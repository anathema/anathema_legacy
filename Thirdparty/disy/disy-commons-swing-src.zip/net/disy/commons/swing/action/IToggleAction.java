//Copyright (c) 2003-2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.action;

import javax.swing.Action;

/**
 * @author behrens
 * @deprecated As of 28.06.2005 (gebhard), replaced by {@link net.disy.commons.swing.action.SmartToggleAction}
 */
@Deprecated
public interface IToggleAction extends Action {
  public static final String PROPERTY_NAME_SELECT = "select"; //$NON-NLS-1$

  public boolean isSelected();

  public void setSelected(boolean selected);
}