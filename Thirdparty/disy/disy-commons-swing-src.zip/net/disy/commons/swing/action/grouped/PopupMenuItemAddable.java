/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.grouped;

import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import net.disy.commons.core.grouped.IStructuredItemAddable;

public final class PopupMenuItemAddable implements IStructuredItemAddable<JMenuItem> {
  private final JPopupMenu menu;

  public PopupMenuItemAddable(final JPopupMenu menu) {
    this.menu = menu;
  }

  @Override
  public void addSeparator() {
    menu.addSeparator();
  }

  @Override
  public void add(final JMenuItem item) {
    menu.add(item);
  }
}