/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.demo;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import org.junit.runner.RunWith;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.icon.IconImageIcon;
import net.disy.commons.swing.icon.test.IconTestUtilities;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class SmartActionDemo extends SwingDemoCase {

  private static final boolean ENABLED = true;
  private static final boolean DISABLED = false;

  public void demoWithNormalIconOnly() {
    final SmartAction iconAction1 = createAction(IconTestUtilities.createExampleIcon(), ENABLED);
    final SmartAction iconAction2 = createAction(IconTestUtilities.createExampleIcon(), DISABLED);
    final SmartAction imageIconAction1 = createAction(createImageIcon(), ENABLED);
    final SmartAction imageIconAction2 = createAction(createImageIcon(), DISABLED);
    show(iconAction1, iconAction2, imageIconAction1, imageIconAction2);
  }

  private SmartAction createAction(final Icon icon, final boolean enabled) {
    final SmartAction action = createEmptySmartAction();
    action.setIcon(icon);
    action.setEnabled(enabled);
    return action;
  }

  private ImageIcon createImageIcon() {
    final Icon icon = IconTestUtilities.createExampleIcon();
    return new IconImageIcon(icon);
  }

  private void show(
      final SmartAction iconAction1,
      final SmartAction iconAction2,
      final SmartAction imageIconAction1,
      final SmartAction imageIconAction2) {
    final JCheckBox checkBox = new JCheckBox("enabled", iconAction1.isEnabled()); //$NON-NLS-1$
    checkBox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        iconAction1.setEnabled(checkBox.isSelected());
        imageIconAction1.setEnabled(checkBox.isSelected());
      }
    });
    final JPanel buttonPanel = new JPanel(new GridDialogLayout(3, true));
    buttonPanel.add(new JLabel("Icons:"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    buttonPanel.add(new JButton(iconAction1));
    buttonPanel.add(new JButton(iconAction2));
    buttonPanel.add(new JLabel("ImageIcons:"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    buttonPanel.add(new JButton(imageIconAction1));
    buttonPanel.add(new JButton(imageIconAction2));

    final JPanel menuItemPanel = new JPanel(new GridDialogLayout(3, true));
    menuItemPanel.add(new JLabel("Icons:"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    menuItemPanel.add(new JMenuItem(iconAction1));
    menuItemPanel.add(new JMenuItem(iconAction2));
    menuItemPanel.add(new JLabel("ImageIcons:"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    menuItemPanel.add(new JMenuItem(imageIconAction1));
    menuItemPanel.add(new JMenuItem(imageIconAction2));

    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.add(new JLabel("Buttons:")); //$NON-NLS-1$
    panel.add(buttonPanel);
    panel.add(new JLabel("Menu Items:")); //$NON-NLS-1$
    panel.add(menuItemPanel);
    panel.add(checkBox);
    show(panel);
  }

  private SmartAction createEmptySmartAction() {
    final SmartAction action = new SmartAction("Action") { //$NON-NLS-1$
      @Override
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    };
    return action;
  }
}