package net.disy.commons.swing.action.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JPanel;

import net.disy.commons.swing.action.SmartAction;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class SmartActionDemo extends SwingDemoCase {

  public void demoWithNormalIconOnly() {
    SmartAction action = createEmptySmartAction();
    action.setIcon(createIcon(Color.BLACK));
    show(action);
  }

  public void demoWithDisabledIcon() {
    final SmartAction action = createEmptySmartAction();
    action.setIcon(createIcon(Color.BLACK));
    action.setDisabledIcon(createIcon(Color.GRAY));
    show(action);
  }

  private void show(final SmartAction action) {
    final JCheckBox checkBox = new JCheckBox("enabled"); //$NON-NLS-1$
    checkBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        action.setEnabled(checkBox.isSelected());
      }
    });
    JPanel panel = new JPanel();
    panel.add(checkBox);
    panel.add(new JButton(action));
    show(panel);
  }

  private SmartAction createEmptySmartAction() {
    SmartAction action = new SmartAction() {
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    };
    return action;
  }

  private Icon createIcon(final Color color) {
    return new Icon() {
      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.drawRect(x + 2, y + 2, 10, 10);
      }

      public int getIconWidth() {
        return 16;
      }

      public int getIconHeight() {
        return 16;
      }
    };
  }
}