/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action;

import javax.swing.Action;
import javax.swing.JMenuItem;

import net.disy.commons.core.util.Ensure;

/** @published */
//Framework-Doku
public class GroupedMenuItem {

  public static final GroupedMenuItem NO_ITEM = null;
  private final ActionGroupId actionGroupId;
  private final JMenuItem menuItem;

  /** @published */
  //Framework-Doku
  public GroupedMenuItem(final Action action, final ActionGroupId actionGroupId) {
    this(new JMenuItem(getEnsuredNotNull(action)), actionGroupId);
  }

  private static Action getEnsuredNotNull(final Action action) {
    Ensure.ensureArgumentNotNull(action);
    return action;
  }

  public GroupedMenuItem(final JMenuItem menuItem, final ActionGroupId actionGroupId) {
    Ensure.ensureArgumentNotNull(menuItem);
    Ensure.ensureArgumentNotNull(actionGroupId);
    this.menuItem = menuItem;
    this.actionGroupId = actionGroupId;
  }

  public ActionGroupId getActionGroupId() {
    return actionGroupId;
  }

  public JMenuItem getMenuItem() {
    return menuItem;
  }
}