package net.disy.commons.swing.action;

import java.awt.Component;

public final class NullAction extends SmartAction {
  @Override
  protected void execute(Component parentComponent) {
    // nothing to do
  }
}