//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.action;

import javax.swing.Icon;

// NOT_PUBLISHED
public class ActionConfiguration implements IActionConfiguration {

  private final String name;
  private final Icon icon;
  private final String toolTipText;

  public ActionConfiguration() {
    this(null, null);
  }

  public ActionConfiguration(String name) {
    this(name, null);
  }

  public ActionConfiguration(Icon icon) {
    this(null, icon);
  }

  public ActionConfiguration(String name, Icon icon) {
    this(name, icon, null);
  }

  public ActionConfiguration(String name, Icon icon, String toolTipText) {
    this.name = name;
    this.icon = icon;
    this.toolTipText = toolTipText;
  }

  public Icon getIcon() {
    return icon;
  }

  public String getName() {
    return name;
  }

  public String getToolTipText() {
    return toolTipText;
  }
}