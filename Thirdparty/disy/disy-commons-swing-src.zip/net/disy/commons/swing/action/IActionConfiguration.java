//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.action;

import javax.swing.Icon;

// NOT_PUBLISHED
public interface IActionConfiguration {

  public Icon getIcon();

  public String getName();

  public String getToolTipText();

}