package net.disy.commons.swing.action;

import java.awt.Component;

import javax.swing.Icon;

import net.disy.commons.core.model.BooleanModel;

public class SmartToggleAction extends SmartAction {

  private final BooleanModel model;

  public SmartToggleAction(BooleanModel model) {
    super();
    this.model = model;
  }

  public SmartToggleAction(BooleanModel model, String name) {
    super(name);
    this.model = model;
  }

  public SmartToggleAction(BooleanModel model, Icon icon) {
    super(icon);
    this.model = model;
  }

  public SmartToggleAction(BooleanModel model, String name, Icon icon) {
    super(name, icon);
    this.model = model;
  }

  public BooleanModel getSelectionModel() {
    return model;
  }

  @Override
  protected void execute(Component parentComponent) {
    model.setValue(!model.getValue());
  }
}