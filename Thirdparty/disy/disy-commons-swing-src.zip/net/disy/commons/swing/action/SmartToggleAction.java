/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action;

import java.awt.Component;

import javax.swing.Icon;

import net.disy.commons.core.model.IModifiableBooleanModel;

public class SmartToggleAction extends SmartAction {

  private final IModifiableBooleanModel model;

  public SmartToggleAction(final IModifiableBooleanModel model) {
    super();
    this.model = model;
  }

  public SmartToggleAction(final IModifiableBooleanModel model, final String name) {
    super(name);
    this.model = model;
  }

  public SmartToggleAction(final IModifiableBooleanModel model, final Icon icon) {
    super(icon);
    this.model = model;
  }

  public SmartToggleAction(final IModifiableBooleanModel model, final String name, final Icon icon) {
    super(name, icon);
    this.model = model;
  }

  public IModifiableBooleanModel getSelectionModel() {
    return model;
  }

  @Override
  protected void execute(final Component parentComponent) {
    model.setValue(!model.getValue());
  }
}