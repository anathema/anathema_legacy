/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.test;

import static org.junit.Assert.*;

import javax.swing.Icon;

import net.disy.commons.core.testing.Assert;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.icon.CommonIcons;

import org.junit.Before;
import org.junit.Test;

public class ActionConfigurationTest {

  private ActionConfiguration configuration;

  @Before
  public void createConfiguration() throws Exception {
    this.configuration = new ActionConfiguration("name", CommonIcons.DELETE, "tooltipp"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void equalsActionConfigurationWithSameConfiguration() throws Exception {
    String name = configuration.getName();
    Icon icon = configuration.getIcon();
    String toolTip = configuration.getToolTipText();
    assertEquals(configuration, new ActionConfiguration(name, icon, toolTip));
  }

  @Test
  public void notEqualsConfigurationWithOtherName() throws Exception {
    Icon icon = configuration.getIcon();
    String toolTip = configuration.getToolTipText();
    Assert.assertNotEquals(configuration, new ActionConfiguration("otherName", icon, toolTip)); //$NON-NLS-1$
  }

  @Test
  public void notEqualsConfigurationWithOtherTooltip() throws Exception {
    String name = configuration.getName();
    Icon icon = configuration.getIcon();
    Assert.assertNotEquals(configuration, new ActionConfiguration(name, icon, "tooltipText")); //$NON-NLS-1$
  }

  @Test
  public void notEqualsConfigurationWithOtherIcon() throws Exception {
    String name = configuration.getName();
    String toolTip = configuration.getToolTipText();
    Assert.assertNotEquals(configuration, new ActionConfiguration(
        name,
        CommonIcons.PRINTER,
        toolTip));
  }
}