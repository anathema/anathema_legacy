package net.disy.commons.swing.action;

import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JToggleButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ActionWidgetFactory {

  public static JToggleButton createToggleButton(final SmartToggleAction action) {
    final JToggleButton button = new JToggleButton(action);
    button.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        button.setSelected(action.getSelectionModel().getValue());
      }
    });
    return button;
  }

  public static JMenuItem createToggleMenuItem(final SmartToggleAction action) {
    final JCheckBoxMenuItem menuItem = new JCheckBoxMenuItem(action);
    menuItem.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        menuItem.setSelected(action.getSelectionModel().getValue());
      }
    });
    return menuItem;
  }

  public static JCheckBox createCheckBox(final SmartToggleAction action) {
    final JCheckBox checkBox = new JCheckBox(action);
    checkBox.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        checkBox.setSelected(action.getSelectionModel().getValue());
      }
    });
    return checkBox;
  }

  public static JButton createButton(final SmartAction action) {
    final JButton button = new JButton(action);
    button.setMargin(getInsets(action.getActionConfiguration()));
    button.setFocusPainted(isFocusPainted(action.getActionConfiguration()));
    return button;
  }

  private static Insets getInsets(IActionConfiguration configuration) {
    return isIconOnly(configuration) ? new Insets(0, 0, 0, 0) : null;
  }

  private static boolean isIconOnly(IActionConfiguration configuration) {
    return configuration.getIcon() != null && configuration.getName() == null;
  }

  private static boolean isFocusPainted(IActionConfiguration configuration) {
    return !isIconOnly(configuration);
  }
}