package net.disy.commons.swing.action;

import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenuItem;
import javax.swing.JToggleButton;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ActionWidgetFactory {

  public static JToggleButton createToggleButton(final SmartToggleAction action) {
    final JToggleButton button = new JToggleButton(action);
    button.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        button.setSelected(action.getSelectionModel().getValue());
      }
    });
    return button;
  }

  public static JMenuItem createToggleMenuItem(final SmartToggleAction action) {
    final JCheckBoxMenuItem menuItem = new JCheckBoxMenuItem(action);
    menuItem.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        menuItem.setSelected(action.getSelectionModel().getValue());
      }
    });
    return menuItem;
  }

  public static JCheckBox createCheckBox(final SmartToggleAction action) {
    final JCheckBox checkBox = new JCheckBox(action);
    checkBox.setSelected(action.getSelectionModel().getValue());
    action.getSelectionModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        checkBox.setSelected(action.getSelectionModel().getValue());
      }
    });
    return checkBox;
  }
}