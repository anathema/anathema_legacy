/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.action.test;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import junit.framework.AssertionFailedError;
import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.icon.EmptyIcon;
import net.disy.commons.swing.icon.test.IconTestUtilities;

import org.junit.Before;
import org.junit.Test;

public class SmartActionTest {

  private SmartAction action;

  @Before
  public void setUp() throws Exception {
    action = new SmartAction("test") { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        //does nothing
      }
    };
  }

  @Test
  public void testCreateDefault() {
    final SmartAction smartAction = new SmartAction() {
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertNull(smartAction.getName());
    assertNull(smartAction.getValue(Action.NAME));
    assertNull(smartAction.getIcon());
    assertNull(smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test
  public void testCreateByName() {
    final SmartAction smartAction = new SmartAction("testName") { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("testName", smartAction.getName()); //$NON-NLS-1$
    assertEquals("testName", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("testName", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    assertNull(smartAction.getIcon());
    assertNull(smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test
  public void testCreateByIcon() {
    final Icon icon = EmptyIcon.DEFAULT_ICON;
    final SmartAction smartAction = new SmartAction(icon) {
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertNull(smartAction.getName());
    assertNull(smartAction.getValue(Action.NAME));
    IconTestUtilities.assertIconEquals(icon, smartAction.getIcon());
    IconTestUtilities.assertIconEquals(icon, smartAction.getActionConfiguration().getIcon());
    IconTestUtilities.assertIconEquals(icon, (Icon) smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test
  public void testCreateByNameAndIcon() {
    final Icon icon = EmptyIcon.DEFAULT_ICON;
    final SmartAction smartAction = new SmartAction("name", icon) { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    IconTestUtilities.assertIconEquals(icon, smartAction.getIcon());
    IconTestUtilities.assertIconEquals(icon, smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    IconTestUtilities.assertIconEquals(icon, (Icon) smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testCreateIllegal() {
    new SmartAction((ActionConfiguration) null) {
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
  }

  @Test
  public void testCreateByConfiguration() {
    final Icon icon = EmptyIcon.DEFAULT_ICON;
    final SmartAction smartAction = new SmartAction(new ActionConfiguration("name", icon)) { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    IconTestUtilities.assertIconEquals(smartAction.getIcon(), icon);
    IconTestUtilities.assertIconEquals(icon, smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    IconTestUtilities.assertIconEquals(icon, (Icon) smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test
  public void testCreateByConfigurationWithToolTipText() {
    final Icon icon = EmptyIcon.DEFAULT_ICON;
    final SmartAction smartAction = new SmartAction(new ActionConfiguration("name", icon, "tool")) { //$NON-NLS-1$ //$NON-NLS-2$
      @Override
      protected void execute(final Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    IconTestUtilities.assertIconEquals(icon, smartAction.getIcon());
    assertEquals("tool", smartAction.getToolTipText()); //$NON-NLS-1$
    assertEquals("tool", smartAction.getActionConfiguration().getToolTipText()); //$NON-NLS-1$
    IconTestUtilities.assertIconEquals(icon, (Icon) smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  @Test
  public void testSetMnemonic() {
    action.setMnemonic(KeyEvent.VK_A);
    assertEquals(new Integer(KeyEvent.VK_A), action.getValue(Action.MNEMONIC_KEY));
  }

  @Test
  public void testSetMnemonicCharacter() {
    assertSetMnemonicCharacter(KeyEvent.VK_A, 'a');
    assertSetMnemonicCharacter(KeyEvent.VK_U, 'U');
    assertSetMnemonicCharacter(KeyEvent.VK_1, '1');
  }

  @Test
  public void testImplementationPreconditions() {
    //if they fail we have to change the mapping from char to KeyEvent.VK_...
    assertEquals(KeyEvent.VK_0, '0');
    assertEquals(KeyEvent.VK_9, '9');
    assertEquals(KeyEvent.VK_A, 'A');
    assertEquals(KeyEvent.VK_Z, 'Z');
  }

  private void assertSetMnemonicCharacter(final int expectedKeyCode, final char character) {
    action.setMnemonic(character);
    assertEquals(new Integer(expectedKeyCode), action.getValue(Action.MNEMONIC_KEY));
  }

  @Test
  public void testSetMnemonicInsideName() {
    assertSetNameSetsMnemonic("name", KeyEvent.VK_N, "&name"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_A, "n&ame"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_M, "na&me"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_E, "nam&e"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testSetNameWithoutMnemonicInsideName() {
    assertSetNameWithoutMnemonic("n&ame", "n&&ame"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("&name", "&&name"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("nam&&e", "nam&&&&e"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("name&", "name&&"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testSetMnemonicInsideNameWithEscapedAmpersands() {
    assertSetNameSetsMnemonic("nam&e", KeyEvent.VK_E, "nam&&&e"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private void assertSetNameWithoutMnemonic(
      final String expectedName,
      final String nameWithoutMnemonic) {
    action.setName(nameWithoutMnemonic);
    assertEquals(expectedName, action.getName());
    assertNull(action.getValue(Action.MNEMONIC_KEY));
  }

  private void assertSetNameSetsMnemonic(
      final String expectedName,
      final int expectedKeyCode,
      final String nameWithMnemonic) {
    action.setName(nameWithMnemonic);
    assertEquals(new Integer(expectedKeyCode), action.getValue(Action.MNEMONIC_KEY));
    assertEquals(expectedName, action.getName());
  }

  @Test
  //Bugfix (gebhard, lohaus) 28.08.2006: Disabled-Action wird in JMenuItem ohne Icon gezeichnet => Immer in ImageIcon verpacken  
  public void testConvertsIconToImageIconForSwing() {
    final SmartAction smartAction = new SmartAction(createIcon()) {
      @Override
      protected void execute(final Component parentComponent) {
        //nothing to do
      }
    };
    org.junit.Assert.assertThat(smartAction.getIcon(), is(instanceOf(ImageIcon.class)));
  }

  @Test
  public void testObservableIconSupported() {
    final ColorModel colorModel = new ColorModel(Color.BLUE);
    class ObservableIcon extends AbstractChangeableModel implements Icon {
      @Override
      public int getIconHeight() {
        return 10;
      }

      @Override
      public int getIconWidth() {
        return 10;
      }

      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        g.setColor(colorModel.getColor());
        g.fillRect(x, y, 10, 10);
      }

      @Override
      public void fireChangeEvent() {
        super.fireChangeEvent();
      }
    }
    final ObservableIcon icon = new ObservableIcon();
    final SmartAction smartAction = new SmartAction(icon) {
      @Override
      protected void execute(final Component parentComponent) {
        // nothing to do
      }
    };
    final JButton button = new JButton(smartAction);
    button.setBounds(0, 0, 10, 10);
    final BufferedImage image = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
    button.paint(image.createGraphics());
    assertContainsColor(Color.BLUE, image);
    colorModel.setColor(Color.CYAN);
    icon.fireChangeEvent();
    button.paint(image.getGraphics());
    assertContainsColor(Color.CYAN, image);
  }

  private void assertContainsColor(final Color expectedColor, final BufferedImage image) {
    for (int x = 0; x < image.getWidth(); x++) {
      for (int y = 0; y < image.getHeight(); y++) {
        if (image.getRGB(x, y) == expectedColor.getRGB()) {
          return;
        }
      }
    }
    throw new AssertionFailedError("color not found: " + expectedColor); //$NON-NLS-1$
  }

  private Icon createIcon() {
    return new Icon() {
      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        //nothing to do
      }

      @Override
      public int getIconWidth() {
        return 20;
      }

      @Override
      public int getIconHeight() {
        return 21;
      }
    };
  }

  @Test
  public void allowsUUmlautAsMnemonic() throws Exception {
    new SmartAction("&Ühü") { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        // nothing to do
      }
    };
  }
}