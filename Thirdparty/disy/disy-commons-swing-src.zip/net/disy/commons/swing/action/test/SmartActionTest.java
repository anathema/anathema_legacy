package net.disy.commons.swing.action.test;

import java.awt.Component;
import java.awt.event.KeyEvent;

import javax.swing.Action;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.ISimpleBlock;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.icon.EmptyIcon;

/**
 * @author Markus Gebhard
 */
public class SmartActionTest extends CoreTestCase {

  private SmartAction action;

  @Override
  protected void setUp() throws Exception {
    action = new SmartAction("test") { //$NON-NLS-1$
      @Override
      protected void execute(Component parentComponent) {
        //does nothing
      }
    };
  }

  public void testCreateDefault() {
    SmartAction smartAction = new SmartAction() {
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertNull(smartAction.getName());
    assertNull(smartAction.getValue(Action.NAME));
    assertNull(smartAction.getIcon());
    assertNull(smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testCreateByName() {
    SmartAction smartAction = new SmartAction("testName") { //$NON-NLS-1$
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("testName", smartAction.getName()); //$NON-NLS-1$
    assertEquals("testName", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("testName", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    assertNull(smartAction.getIcon());
    assertNull(smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testCreateByIcon() {
    final EmptyIcon icon = EmptyIcon.DEFAULT_ICON;
    SmartAction smartAction = new SmartAction(icon) {
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertNull(smartAction.getName());
    assertNull(smartAction.getValue(Action.NAME));
    assertSame(icon, smartAction.getIcon());
    assertSame(icon, smartAction.getActionConfiguration().getIcon());
    assertSame(icon, smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testCreateByNameAndIcon() {
    final EmptyIcon icon = EmptyIcon.DEFAULT_ICON;
    SmartAction smartAction = new SmartAction("name", icon) { //$NON-NLS-1$
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    assertSame(icon, smartAction.getIcon());
    assertSame(icon, smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertSame(icon, smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testCreateIllegal() {
    assertThrowsIllegalArgumentException(new ISimpleBlock() {
      public void execute() {
        new SmartAction((ActionConfiguration) null) {
          @Override
          protected void execute(Component parentComponent) {
            throw new UnsupportedOperationException();
          }
        };
      }
    });
  }

  public void testCreateByConfiguration() {
    final EmptyIcon icon = EmptyIcon.DEFAULT_ICON;
    SmartAction smartAction = new SmartAction(new ActionConfiguration("name", icon)) { //$NON-NLS-1$
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    assertSame(icon, smartAction.getIcon());
    assertSame(icon, smartAction.getActionConfiguration().getIcon());
    assertNull(smartAction.getToolTipText());
    assertNull(smartAction.getActionConfiguration().getToolTipText());
    assertSame(icon, smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testCreateByConfigurationWithToolTipText() {
    final EmptyIcon icon = EmptyIcon.DEFAULT_ICON;
    SmartAction smartAction = new SmartAction(new ActionConfiguration("name", icon, "tool")) { //$NON-NLS-1$ //$NON-NLS-2$
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    };
    assertEquals("name", smartAction.getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getActionConfiguration().getName()); //$NON-NLS-1$
    assertEquals("name", smartAction.getValue(Action.NAME)); //$NON-NLS-1$
    assertSame(icon, smartAction.getIcon());
    assertEquals("tool", smartAction.getToolTipText()); //$NON-NLS-1$
    assertEquals("tool", smartAction.getActionConfiguration().getToolTipText()); //$NON-NLS-1$
    assertSame(icon, smartAction.getValue(Action.SMALL_ICON));
    assertNull(smartAction.getValue(Action.MNEMONIC_KEY));
    assertTrue(smartAction.isEnabled());
  }

  public void testSetMnemonic() {
    action.setMnemonic(KeyEvent.VK_A);
    assertEquals(new Integer(KeyEvent.VK_A), action.getValue(Action.MNEMONIC_KEY));
  }

  public void testSetMnemonicCharacter() {
    assertSetMnemonicCharacter(KeyEvent.VK_A, 'a');
    assertSetMnemonicCharacter(KeyEvent.VK_U, 'U');
    assertSetMnemonicCharacter(KeyEvent.VK_1, '1');
  }

  public void testImplementationPreconditions() {
    //if they fail we have to change the mapping from char to KeyEvent.VK_...
    assertEquals(KeyEvent.VK_0, '0');
    assertEquals(KeyEvent.VK_9, '9');
    assertEquals(KeyEvent.VK_A, 'A');
    assertEquals(KeyEvent.VK_Z, 'Z');
  }

  private void assertSetMnemonicCharacter(int expectedKeyCode, char character) {
    action.setMnemonic(character);
    assertEquals(new Integer(expectedKeyCode), action.getValue(Action.MNEMONIC_KEY));
  }

  public void testSetMnemonicInsideName() {
    assertSetNameSetsMnemonic("name", KeyEvent.VK_N, "&name"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_A, "n&ame"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_M, "na&me"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameSetsMnemonic("name", KeyEvent.VK_E, "nam&e"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testSetNameWithoutMnemonicInsideName() {
    assertSetNameWithoutMnemonic("n&ame", "n&&ame"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("&name", "&&name"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("nam&&e", "nam&&&&e"); //$NON-NLS-1$ //$NON-NLS-2$
    assertSetNameWithoutMnemonic("name&", "name&&"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testSetMnemonicInsideNameWithEscapedAmpersands() {
    assertSetNameSetsMnemonic("nam&e", KeyEvent.VK_E, "nam&&&e"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private void assertSetNameWithoutMnemonic(String expectedName, String nameWithoutMnemonic) {
    action.setName(nameWithoutMnemonic);
    assertEquals(expectedName, action.getName());
    assertNull(action.getValue(Action.MNEMONIC_KEY));
  }

  private void assertSetNameSetsMnemonic(
      String expectedName,
      int expectedKeyCode,
      String nameWithMnemonic) {
    action.setName(nameWithMnemonic);
    assertEquals(new Integer(expectedKeyCode), action.getValue(Action.MNEMONIC_KEY));
    assertEquals(expectedName, action.getName());
  }
}