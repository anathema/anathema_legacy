package net.disy.commons.swing.showhide;

import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;

public class ShowHideButton {

  private final static Icon HIDE_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "showhide/hide_arrows.gif"); //$NON-NLS-1$
  private final static Icon SHOW_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "showhide/show_arrows.gif"); //$NON-NLS-1$

  private final JButton button;
  private final BooleanModel model;
  private final String hideToolTipText;
  private final String showToolTipText;

  public ShowHideButton(final BooleanModel model) {
    this(model, null, null);
  }

  public ShowHideButton(final BooleanModel model, String hideToolTipText, String showToolTipText) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    this.showToolTipText = showToolTipText;
    this.hideToolTipText = hideToolTipText;

    button = new JButton();
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        model.setValue(!model.getValue());
      }
    });
    button.setFocusPainted(false);
    button.setPreferredSize(new Dimension(17, 17));
    button.setMargin(new Insets(0, 0, 0, 0));
    button.setBorder(new EmptyBorder(4, 4, 4, 4));
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateView();
      }
    });
    updateView();
  }

  private void updateView() {
    button.setIcon(model.getValue() ? HIDE_ICON : SHOW_ICON);
    button.setToolTipText(model.getValue() ? hideToolTipText : showToolTipText);
  }

  public JComponent getContent() {
    return button;
  }
}