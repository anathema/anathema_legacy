/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.showhide.demo;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.showhide.ShowHideButton;
import net.disy.commons.swing.showhide.ShowHideContentPanel;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class ShowHideContentPanelDemo extends SwingDemoCase {

  public void demo() {
    final BooleanModel model = new BooleanModel(true);
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(new ShowHideButton(model).getContent(), BorderLayout.NORTH);
    panel
        .add(
            new ShowHideContentPanel(model, new JLabel("Hideable content")).getContent(), BorderLayout.CENTER); //$NON-NLS-1$
    show(panel);
  }
}