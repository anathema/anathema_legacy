package net.disy.commons.swing.showhide.demo;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.showhide.ShowHideButton;
import net.disy.commons.swing.showhide.ShowHideContentPanel;

import de.jdemo.extensions.SwingDemoCase;

public class ShowHideContentPanelDemo extends SwingDemoCase {

  public void demo() {
    final BooleanModel model = new BooleanModel(true);
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(new ShowHideButton(model).getContent(), BorderLayout.NORTH);
    panel.add(new ShowHideContentPanel(model, new JLabel("Hideable content")).getContent(), BorderLayout.CENTER); //$NON-NLS-1$
    show(panel);
  }

}