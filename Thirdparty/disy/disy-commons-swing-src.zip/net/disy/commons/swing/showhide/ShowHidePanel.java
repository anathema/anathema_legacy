package net.disy.commons.swing.showhide;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;

public class ShowHidePanel {

  private JLabel label;
  private final JComponent content;

  public ShowHidePanel(BooleanModel model, String label, JComponent hideableContent) {
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(createTitle(model, label), BorderLayout.NORTH);
    final ShowHideContentPanel showHideContentPanel = new ShowHideContentPanel(model, hideableContent);
    showHideContentPanel.setBorder(new EmptyBorder(4, 18, 4, 4));
    panel.add(showHideContentPanel.getContent(), BorderLayout.CENTER);
    this.content = panel;
  }

  private JComponent createTitle(final BooleanModel model, String labelText) {
    JPanel panel = new JPanel(new GridDialogLayout(2, false, 0, 0));
    panel.add(new ShowHideButton(model).getContent());
    label = new JLabel(labelText);
    label.setFont(label.getFont().deriveFont(Font.BOLD));
    label.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        model.setValue(!model.getValue());
      }
    });
    panel.add(label);
    return panel;
  }

  public JComponent getContent() {
    return content;
  }

  public void setColor(Color color) {
    label.setForeground(color);
  }
}