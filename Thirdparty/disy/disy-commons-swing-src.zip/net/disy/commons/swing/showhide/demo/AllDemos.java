//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.showhide.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.showhide.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(ShowHideButtonDemo.class));
    suite.addDemo(new DemoSuite(ShowHidePanelDemo.class));
    suite.addDemo(new DemoSuite(ShowHideContentPanelDemo.class));
    //$JDemo-END$
    return suite;
  }

}
