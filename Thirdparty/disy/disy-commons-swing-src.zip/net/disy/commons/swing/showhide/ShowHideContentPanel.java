/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.showhide;

import java.awt.GridLayout;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.Border;
import net.disy.commons.core.model.listener.IChangeListener;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;

public class ShowHideContentPanel {

  private final JPanel panel;
  private final BooleanModel model;
  private final JComponent hideableContent;
  private Border border;

  public ShowHideContentPanel(final BooleanModel model, final JComponent hideableContent) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(hideableContent);
    this.hideableContent = hideableContent;
    this.model = model;
    panel = new JPanel(new GridLayout(1, 1));
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateHideableContentVisible();
      }
    });
    updateHideableContentVisible();
  }

  private void updateHideableContentVisible() {
    if (model.getValue() == (panel.getComponentCount() == 1)) {
      return;
    }
    panel.removeAll();
    if (model.getValue()) {
      panel.add(hideableContent);
    }
    updateBorder();
    panel.revalidate();
    panel.doLayout();
    panel.repaint();
  }

  public JComponent getContent() {
    return panel;
  }

  public void setBorder(final Border border) {
    this.border = border;
    updateBorder();
  }

  private void updateBorder() {
    panel.setBorder(model.getValue() ? border : null);
  }
}