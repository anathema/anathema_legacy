package net.disy.commons.swing.showhide;

import java.awt.GridLayout;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;

public class ShowHideContentPanel {

  private final JPanel panel;
  private final BooleanModel model;
  private final JComponent hideableContent;
  private Border border;

  public ShowHideContentPanel(BooleanModel model, JComponent hideableContent) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(hideableContent);
    this.hideableContent = hideableContent;
    this.model = model;
    panel = new JPanel(new GridLayout(1, 1));
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateHideableContentVisible();
      }
    });
    updateHideableContentVisible();
  }

  private void updateHideableContentVisible() {
    if (model.getValue() == (panel.getComponentCount() == 1)) {
      return;
    }
    panel.removeAll();
    if (model.getValue()) {
      panel.add(hideableContent);
    }
    updateBorder();
    panel.revalidate();
    panel.doLayout();
    panel.repaint();
  }

  public JComponent getContent() {
    return panel;
  }

  public void setBorder(Border border) {
    this.border = border;
    updateBorder();
  }

  private void updateBorder() {
    panel.setBorder(model.getValue() ? border : null);
  }
}