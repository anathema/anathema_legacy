/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.showhide.demo;

import org.junit.runner.RunWith;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.showhide.ShowHideButton;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class ShowHideButtonDemo extends SwingDemoCase {

  public void demo() {
    show(new ShowHideButton(new BooleanModel()).getContent());
  }

  public void demoShowHideButtonWithToolTips() {
    show(new ShowHideButton(new BooleanModel(), "Hide foo", "Show foo").getContent()); //$NON-NLS-1$ //$NON-NLS-2$
  }
}