package net.disy.commons.swing.showhide.demo;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.showhide.ShowHideButton;

import de.jdemo.extensions.SwingDemoCase;

public class ShowHideButtonDemo extends SwingDemoCase {

  public void demo() {
    show(new ShowHideButton(new BooleanModel()).getContent());
  }

  public void demoShowHideButtonWithToolTips() {
    show(new ShowHideButton(new BooleanModel(), "Hide foo", "Show foo").getContent()); //$NON-NLS-1$ //$NON-NLS-2$
  }
}