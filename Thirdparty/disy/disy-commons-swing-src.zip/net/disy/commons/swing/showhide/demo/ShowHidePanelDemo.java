/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.showhide.demo;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.showhide.ShowHidePanel;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class ShowHidePanelDemo extends SwingDemoCase {

  public void demo() {
    final ShowHidePanel panel1 = new ShowHidePanel(
        new BooleanModel(true),
        "Label 1", new JLabel("Content 1")); //$NON-NLS-1$ //$NON-NLS-2$
    final ShowHidePanel panel2 = new ShowHidePanel(
        new BooleanModel(false),
        "Label 2", new JLabel("Content 2")); //$NON-NLS-1$ //$NON-NLS-2$
    final ShowHidePanel panel3 = new ShowHidePanel(
        new BooleanModel(false),
        "Label 3", new JLabel("Content 3")); //$NON-NLS-1$ //$NON-NLS-2$

    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.add(panel1.getContent());
    panel.add(panel2.getContent());
    panel.add(panel3.getContent());
    show(new JScrollPane(panel));
  }
}