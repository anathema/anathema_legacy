//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.cardlayout.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.cardlayout.CardPanel;
import net.disy.commons.swing.cardlayout.CardPanelKey;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class CardPanelDemo extends SwingDemoCase {

  public void demo() {
    final CardPanel cardPanel = new CardPanel();
    CardPanelKey key1 = new CardPanelKey();
    CardPanelKey key2 = new CardPanelKey();
    CardPanelKey key3 = new CardPanelKey();
    cardPanel.add(new JLabel("Content 1"), key1); //$NON-NLS-1$
    cardPanel.add(new JLabel("Content 2"), key2); //$NON-NLS-1$
    cardPanel.add(new JLabel("Content 3"), key3); //$NON-NLS-1$

    final JComboBox comboBox = new JComboBox(new Object[]{ key1, key2, key3 });
    comboBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        cardPanel.setSelectedSubPanel((CardPanelKey) comboBox.getSelectedItem());
      }
    });

    JPanel topPanel = new JPanel();
    topPanel.add(new JLabel("Selected Page:")); //$NON-NLS-1$
    topPanel.add(comboBox);

    JPanel panel = new JPanel(new BorderLayout());
    panel.add(topPanel, BorderLayout.NORTH);
    panel.add(cardPanel.getContent(), BorderLayout.SOUTH);
    show(panel);
  }
}