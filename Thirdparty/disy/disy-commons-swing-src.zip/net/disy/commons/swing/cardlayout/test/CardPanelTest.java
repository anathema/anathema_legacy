//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.cardlayout.test;

import javax.swing.JLabel;
import javax.swing.JPanel;

import junit.framework.TestCase;

import net.disy.commons.swing.cardlayout.CardPanel;
import net.disy.commons.swing.cardlayout.CardPanelKey;

// NOT_PUBLISHED
public class CardPanelTest extends TestCase {

  public void testCreate() {
    JPanel content = (JPanel) new CardPanel().getContent();
    assertEquals(0, content.getComponentCount());
  }

  public void testIllegalAdd() {
    CardPanel cardPanel = new CardPanel();
    try {
      cardPanel.add(new JLabel(), null);
      fail();
    }
    catch (IllegalArgumentException e) {
      //expected
    }
    try {
      cardPanel.add(null, new CardPanelKey());
      fail();
    }
    catch (IllegalArgumentException e) {
      //expected
    }
  }

  public void testAdd() {
    CardPanel cardPanel = new CardPanel();
    JLabel label = new JLabel();
    cardPanel.add(label, new CardPanelKey());
    JPanel content = (JPanel) cardPanel.getContent();
    assertEquals(1, content.getComponentCount());
    assertSame(label, content.getComponent(0));
  }

  public void testMultipleAdd() {
    CardPanel cardPanel = new CardPanel();
    JLabel label1 = new JLabel();
    cardPanel.add(label1, new CardPanelKey());
    JLabel label2 = new JLabel();
    cardPanel.add(label2, new CardPanelKey());
    JPanel content = (JPanel) cardPanel.getContent();
    assertEquals(2, content.getComponentCount());
    assertSame(label1, content.getComponent(0));
    assertSame(label2, content.getComponent(1));
  }

  public void testSetSelectedPanel() {
    CardPanel cardPanel = new CardPanel();
    JLabel label1 = new JLabel();
    CardPanelKey key1 = new CardPanelKey();
    cardPanel.add(label1, key1);
    JLabel label2 = new JLabel();
    CardPanelKey key2 = new CardPanelKey();
    cardPanel.add(label2, key2);

    cardPanel.setSelectedSubPanel(key1);
    assertTrue(label1.isVisible());
    assertFalse(label2.isVisible());

    cardPanel.setSelectedSubPanel(key2);
    assertFalse(label1.isVisible());
    assertTrue(label2.isVisible());
  }

}