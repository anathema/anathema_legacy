//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.cardlayout.test;

import junit.framework.TestCase;

import net.disy.commons.swing.cardlayout.CardPanelKey;

// NOT_PUBLISHED
public class CardPanelKeyTest extends TestCase {

  public void testIllegalCreate() {
    try {
      new CardPanelKey(null);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testCreateDefault() {
    CardPanelKey key = new CardPanelKey();
    assertNotNull(key.getId());
  }

  public void testCreateByString() {
    assertEquals("id42", new CardPanelKey("id42").getId()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testDefaultCreatedEquals() {
    CardPanelKey key = new CardPanelKey();
    assertEquals(key, key);
    assertFalse(new CardPanelKey().equals(key));
  }

  public void testByIdCreatedEquals() {
    assertEquals(new CardPanelKey("id42"), new CardPanelKey("id42")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(new CardPanelKey("1"), new CardPanelKey("1")); //$NON-NLS-1$ //$NON-NLS-2$
    assertFalse(new CardPanelKey("1").equals(new CardPanelKey("2"))); //$NON-NLS-1$ //$NON-NLS-2$
  }
}