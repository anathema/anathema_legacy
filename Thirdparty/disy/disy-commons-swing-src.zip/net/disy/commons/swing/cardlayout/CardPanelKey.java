//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.cardlayout;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class CardPanelKey {

  private static int idCounter = 0;

  private static String createNewId() {
    int id;
    synchronized (CardPanelKey.class) {
      id = idCounter++;
    }
    return String.valueOf(id);
  }

  private final String id;

  public CardPanelKey() {
    this(createNewId());
  }

  public CardPanelKey(String id) {
    Ensure.ensureArgumentNotNull(id);
    this.id = id;
  }

  @Override
  public boolean equals(Object obj) {
    if (!(obj instanceof CardPanelKey)) {
      return false;
    }
    CardPanelKey other = (CardPanelKey) obj;
    return other.id.equals(id);
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return "CardPanelKey{" + id + "}"; //$NON-NLS-1$ //$NON-NLS-2$
  }
}