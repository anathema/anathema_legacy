//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.cardlayout;

import java.awt.CardLayout;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class CardPanel {

  private final CardLayout cardLayout;
  private final JPanel panel;

  public CardPanel() {
    cardLayout = new CardLayout();
    panel = new JPanel(cardLayout);
  }

  public void add(JComponent subPanel, CardPanelKey key) {
    Ensure.ensureArgumentNotNull(subPanel);
    Ensure.ensureArgumentNotNull(key);
    panel.add(subPanel, key.getId());
  }

  public void setSelectedSubPanel(CardPanelKey key) {
    cardLayout.show(panel, key.getId());
  }

  public JComponent getContent() {
    return panel;
  }
}