/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormatSymbols;
import java.util.Calendar;

import javax.swing.JComboBox;
import javax.swing.JComponent;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;

public class SmartMonthChooser {

  private final JComboBox comboBox;
  private final ObjectModel<Calendar> model;
  private final ItemListener comboBoxListener = new ItemListener() {
    @Override
    public void itemStateChanged(ItemEvent iEvt) {
      int selectedMonth = comboBox.getSelectedIndex();
      Calendar newCalendar = (Calendar) model.getValue().clone();
      newCalendar.set(Calendar.MONTH, selectedMonth);
      model.setValue(newCalendar);
    }
  };
  private final IChangeListener modelListener = new IChangeListener() {
    @Override
    public void stateChanged() {
      updateComboBox();
    }
  };

  public SmartMonthChooser(final ObjectModel<Calendar> model) {
    this.model = model;
    String[] months = new DateFormatSymbols().getMonths();
    months = ArrayUtilities.filter(months, new IPredicate<String>() {
      @Override
      public boolean evaluate(final String value) {
        return value.trim().length() > 0;
      }
    });
    comboBox = new JComboBox(months);
    comboBox.addItemListener(comboBoxListener);
    model.addChangeListener(modelListener);
    updateComboBox();
  }

  private int getMonth() {
    return model.getValue().get(Calendar.MONTH);
  }

  public JComponent getContent() {
    return comboBox;
  }

  private void updateComboBox() {
    comboBox.setSelectedIndex(getMonth());
  }
}