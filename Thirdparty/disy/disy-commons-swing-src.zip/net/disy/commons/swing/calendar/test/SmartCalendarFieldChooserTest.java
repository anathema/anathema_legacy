/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar.test;

import static junit.framework.Assert.*;

import java.util.Calendar;
import java.util.GregorianCalendar;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.calendar.SmartCalendarFieldChooser;

import org.junit.Test;

public class SmartCalendarFieldChooserTest {

  @Test
  public void initializationDoesNotChangeModel() throws Exception {
    final ObjectModel<Calendar> model = new ObjectModel<Calendar>(
        new GregorianCalendar(2006, 8, 11));
    SmartCalendarFieldChooser.createYearChooser(model);
    assertEquals(2006, model.getValue().get(Calendar.YEAR));
    assertEquals(8, model.getValue().get(Calendar.MONTH));
    assertEquals(11, model.getValue().get(Calendar.DAY_OF_MONTH));
  }
}