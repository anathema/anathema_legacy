/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;

public class SmartDayChooser {
  private static String[] createDayNames() {
    return new DateFormatSymbols().getShortWeekdays();
  }
  private final JPanel content = new JPanel(new GridLayout(7, 7));
  private final JButton days[];
  private JButton selectedDay;
  private Color oldDayBackground;
  private final String dayNames[];
  private final ObjectModel<Calendar> model;
  private final Calendar today = new GregorianCalendar();

  public SmartDayChooser(final ObjectModel<Calendar> model) {
    this.model = model;
    this.dayNames = createDayNames();
    this.model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        drawDays();
      }
    });
    days = new JButton[49];
    selectedDay = null;

    for (int rowIndex = 0; rowIndex < 7; rowIndex++) {
      for (int columnIndex = 0; columnIndex < 7; columnIndex++) {
        final int buttonIndex = columnIndex + 7 * rowIndex;
        days[buttonIndex] = rowIndex == 0 ? createHeaderButton() : createDayButton();
        days[buttonIndex].setMargin(new Insets(0, 0, 0, 0));
        days[buttonIndex].setFocusPainted(false);
        content.add(days[buttonIndex]);
      }
    }
    init();
    updateCalendar(model.getValue().get(Calendar.DAY_OF_MONTH));
  }

  private JButton createDayButton() {
    final JButton button = new JButton("x"); //$NON-NLS-1$
    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        final JButton sourceButton = (JButton) e.getSource();
        final int day = (new Integer(sourceButton.getText())).intValue();
        updateCalendar(day);
      }
    });
    return button;
  }

  private JButton createHeaderButton() {
    final JButton button = new JButton() {
      @Override
      public void addMouseListener(final MouseListener l) {
        //Listener not supported
      }
    };
    button.setBackground(new Color(200, 200, 255));
    return button;
  }

  private void drawDays() {
    final Calendar tmpCalendar = (Calendar) model.getValue().clone();
    final int firstDayOfWeek = tmpCalendar.getFirstDayOfWeek();
    tmpCalendar.set(Calendar.DAY_OF_MONTH, 1);

    int firstDay = tmpCalendar.get(Calendar.DAY_OF_WEEK) - firstDayOfWeek;
    if (firstDay < 0) {
      firstDay += 7;
    }

    int i;

    for (i = 0; i < firstDay; i++) {
      days[i + 7].setVisible(false);
      days[i + 7].setText(""); //$NON-NLS-1$
    }

    tmpCalendar.add(Calendar.MONTH, 1);
    final Date firstDayInNextMonth = tmpCalendar.getTime();
    tmpCalendar.add(Calendar.MONTH, -1);

    Date day = tmpCalendar.getTime();
    int n = 0;
    final Color foreground = content.getForeground();
    while (day.before(firstDayInNextMonth)) {
      days[i + n + 7].setText(Integer.toString(n + 1));
      days[i + n + 7].setVisible(true);
      if (tmpCalendar.get(Calendar.DAY_OF_YEAR) == today.get(Calendar.DAY_OF_YEAR)
          && tmpCalendar.get(Calendar.YEAR) == today.get(Calendar.YEAR)) {
        days[i + n + 7].setForeground(Color.red);
      }
      else {
        days[i + n + 7].setForeground(foreground);
      }

      if (n + 1 == this.model.getValue().get(Calendar.DAY_OF_MONTH)) {
        days[i + n + 7].setBackground(Color.gray);
        selectedDay = days[i + n + 7];
      }
      else {
        days[i + n + 7].setBackground(oldDayBackground);
      }

      n++;
      tmpCalendar.add(Calendar.DATE, 1);
      day = tmpCalendar.getTime();
    }

    for (int k = n + i + 7; k < 49; k++) {
      days[k].setVisible(false);
      days[k].setText(""); //$NON-NLS-1$
    }
  }

  public JComponent getContent() {
    return content;
  }

  private void init() {
    final int firstDayOfWeek = model.getValue().getFirstDayOfWeek();
    int day = firstDayOfWeek;
    for (int dayInWeek = 0; dayInWeek < 7; dayInWeek++) {
      days[dayInWeek].setText(dayNames[day]);
      if (day == 1) {
        days[dayInWeek].setForeground(Color.red);
      }
      else {
        days[dayInWeek].setForeground(Color.blue);
      }

      if (day < 7) {
        day++;
      }
      else {
        day -= 6;
      }
    }
    oldDayBackground = (new JButton()).getBackground();
    drawDays();
  }

  private void updateCalendar(int monthDay) {
    final Calendar temporaryCalendar = (Calendar) model.getValue().clone();
    temporaryCalendar.set(Calendar.DAY_OF_MONTH, 1);
    temporaryCalendar.add(Calendar.MONTH, 1);
    temporaryCalendar.add(Calendar.DATE, -1);
    final int maxDaysInMonth = temporaryCalendar.get(Calendar.DATE);
    if (monthDay > maxDaysInMonth) {
      monthDay = maxDaysInMonth;
    }

    if (selectedDay != null) {
      selectedDay.setBackground(oldDayBackground);
      selectedDay.repaint(); // Bug: needed for Swing 1.0.3
    }

    for (int i = 7; i < 49; i++) {
      if (days[i].getText().equals(Integer.toString(monthDay))) {
        selectedDay = days[i];
        selectedDay.setBackground(Color.gray);
        break;
      }
    }
    final Calendar newCalendar = (Calendar) model.getValue().clone();
    newCalendar.set(Calendar.DAY_OF_MONTH, monthDay);
    model.setValue(newCalendar);
  }
}