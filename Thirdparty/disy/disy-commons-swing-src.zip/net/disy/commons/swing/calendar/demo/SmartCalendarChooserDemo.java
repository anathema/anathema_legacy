/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar.demo;

import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.runner.RunWith;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.calendar.SmartCalendarFieldChooser;
import net.disy.commons.swing.calendar.SmartDayChooser;
import net.disy.commons.swing.calendar.SmartMonthChooser;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class SmartCalendarChooserDemo extends SwingDemoCase {

  public void demoSmartMonthChooserForToday() throws Exception {
    show(new SmartMonthChooser(createTodaysCalendarModel()).getContent());
  }

  public void demoSmartYearChooserForToday() throws Exception {
    show(SmartCalendarFieldChooser.createYearChooser(createTodaysCalendarModel()).getContent());
  }

  public void demoSmartDayChooserForToday() throws Exception {
    show(new SmartDayChooser(createTodaysCalendarModel()).getContent());
  }

  public void demoSmartDayChooserForFirstJanuaryOf2000() throws Exception {
    final ObjectModel<Calendar> model = new ObjectModel<Calendar>(new GregorianCalendar(2000, 0, 1));
    show(new SmartDayChooser(model).getContent());
  }

  private ObjectModel<Calendar> createTodaysCalendarModel() {
    return new ObjectModel<Calendar>(new GregorianCalendar());
  }
}