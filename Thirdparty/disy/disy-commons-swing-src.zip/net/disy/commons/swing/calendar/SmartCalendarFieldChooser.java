/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar;

import java.util.Calendar;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;

public class SmartCalendarFieldChooser {

  public static SmartCalendarFieldChooser createSecondChooser(final ObjectModel<Calendar> model) {
    return new SmartCalendarFieldChooser(
        model,
        Calendar.SECOND,
        new SpinnerNumberModel(0, 0, 59, 1));
  }

  public static SmartCalendarFieldChooser createMinuteChooser(final ObjectModel<Calendar> model) {
    return new SmartCalendarFieldChooser(
        model,
        Calendar.MINUTE,
        new SpinnerNumberModel(0, 0, 59, 1));
  }

  public static SmartCalendarFieldChooser createHourChooser(final ObjectModel<Calendar> model) {
    return new SmartCalendarFieldChooser(model, Calendar.HOUR, new SpinnerNumberModel(0, 0, 23, 1));
  }

  public static SmartCalendarFieldChooser createYearChooser(final ObjectModel<Calendar> model) {
    return new SmartCalendarFieldChooser(model, Calendar.YEAR);
  }

  private final JSpinner spinner;
  private final ObjectModel<Calendar> model;
  private final int calendarField;
  private final ChangeListener modelListener = new ChangeListener() {
    @Override
    public void stateChanged(ChangeEvent changeEvent) {
      int selectedValue = getSpinnerModel().getNumber().intValue();
      Calendar newCalendar = (Calendar) model.getValue().clone();
      newCalendar.set(calendarField, selectedValue);
      model.setValue(newCalendar);
    }
  };
  private final IChangeListener spinnerListener = new IChangeListener() {
    @Override
    public void stateChanged() {
      updateSpinner();
    }
  };

  private SmartCalendarFieldChooser(final ObjectModel<Calendar> model, final int calendarField) {
    this(model, calendarField, new SpinnerNumberModel());
  }

  private SmartCalendarFieldChooser(
      final ObjectModel<Calendar> model,
      final int calendarField,
      final SpinnerNumberModel spinnerModel) {
    this.spinner = new JSpinner(spinnerModel);
    this.model = model;
    this.calendarField = calendarField;
    model.addChangeListener(spinnerListener);
    getSpinnerModel().addChangeListener(modelListener);
    spinner.setEditor(new JSpinner.NumberEditor(spinner, "#####")); //$NON-NLS-1$
    updateSpinner();
  }

  public JComponent getContent() {
    return spinner;
  }

  private void updateSpinner() {
    final SpinnerNumberModel numberModel = getSpinnerModel();
    numberModel.setValue(getYear());
    numberModel.setMinimum(model.getValue().getMinimum(calendarField));
    numberModel.setMaximum(model.getValue().getMaximum(calendarField));
  }

  private int getYear() {
    return model.getValue().get(calendarField);
  }

  private SpinnerNumberModel getSpinnerModel() {
    return (SpinnerNumberModel) spinner.getModel();
  }
}