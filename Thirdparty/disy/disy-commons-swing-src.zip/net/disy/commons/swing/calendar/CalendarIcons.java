/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.calendar;

import javax.swing.Icon;

import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;

public class CalendarIcons {

  public static final Icon DATE_ICON = getImageIcon("date.gif"); //$NON-NLS-1$

  private static Icon getImageIcon(final String name) {
    return DisyCommonsSwingImageProvider.getInstance().getImageIcon("date/" + name); //$NON-NLS-1$
  }
}
