// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 29.03.2006
package net.disy.commons.swing.widgetfactory;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.ObjectUtilities;

// NOT_PUBLISHED
public class ObjectWidgetFactory {

  private ObjectWidgetFactory() {
    throw new UnreachableCodeReachedException();
  }

  public static <T> JComboBox createComboBox(final ObjectModel<T> objectModel, T[] values) {
    final JComboBox widget = new JComboBox(values);
    objectModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        Object value = objectModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getSelectedItem())) {
          widget.setSelectedItem(value);
        }
      }
    });
    widget.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        objectModel.setValue((T) widget.getSelectedItem());
      }
    });
    widget.setSelectedItem(objectModel.getValue());
    return widget;
  }
}