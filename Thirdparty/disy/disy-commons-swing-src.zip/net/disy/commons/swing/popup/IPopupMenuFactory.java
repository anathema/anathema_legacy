//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.popup;

import javax.swing.JPopupMenu;

// NOT_PUBLISHED
public interface IPopupMenuFactory {
  
  /** @return A popupmenu to show or <code>null</code> if none. */
  public JPopupMenu createPopupMenu();
}