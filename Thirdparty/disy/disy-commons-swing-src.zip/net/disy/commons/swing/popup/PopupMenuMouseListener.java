// Copyright (c) 1998 by IPF.
package net.disy.commons.swing.popup;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JPopupMenu;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.GuiUtilities;

/**
 * A PopupMouser is a trigger object that handles a JPopupMenu.
 * 
 * @author Claus Hofmann
 */
public class PopupMenuMouseListener extends MouseAdapter {

  private boolean upperLeft = false;
  private IPopupMenuFactory popupMenuFactory;

  /** @deprecated As of 24.06.2004 (gebhard), replaced by {@link #PopupMenuMouseListener(IPopupMenuFactory)}*/
  @Deprecated
  public PopupMenuMouseListener(JPopupMenu popup) {
    this(new StaticPopupMenuFactory(popup));
  }

  public PopupMenuMouseListener(IPopupMenuFactory popupMenuFactory) {
    Ensure.ensureArgumentNotNull(popupMenuFactory);
    this.popupMenuFactory = popupMenuFactory;
  }

  /**
   * Show the popup menu at the upper left corner of the parent component.
   * 
   * @param upperLeft show at the upper left corner?
   */
  public void setUpperLeftCorner(boolean upperLeft) {
    this.upperLeft = upperLeft;
  }

  /**
   * Is the popup menu at the upper left corner of the parent component?
   */
  public boolean isUpperLeftCorner() {
    return upperLeft;
  }

  @Override
  public void mouseReleased(MouseEvent e) {
    if (e.isPopupTrigger()) {
      if (!upperLeft) {
        show(e.getComponent(), e.getX(), e.getY());
      }
      else {
        Component c = e.getComponent();
        Dimension d = c.getSize();
        show(c, 0, d.height);
      }
    }
  }

  @Override
  public void mousePressed(MouseEvent e) {
    if (e.isPopupTrigger()) {
      if (!upperLeft) {
        show(e.getComponent(), e.getX(), e.getY());
      }
      else {
        Component c = e.getComponent();
        Dimension d = c.getSize();
        show(c, 0, d.height);
      }
    }
  }

  private void show(Component component, int x, int y) {
    JPopupMenu popup = popupMenuFactory.createPopupMenu();
    if (popup == null) {
      return;
    }
    GuiUtilities.showFitToScreen(popup, (JComponent) component, x, y);
  }
}