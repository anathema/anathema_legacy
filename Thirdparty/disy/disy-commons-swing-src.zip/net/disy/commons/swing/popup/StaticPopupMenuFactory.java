/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.popup;

import javax.swing.JPopupMenu;

/**
 * @deprecated As of 30.06.2009, this class is used only in GISterm 3D. Will be moved there after
 *             grace period.
 */
@Deprecated
public class StaticPopupMenuFactory implements IPopupMenuFactory {

  private final JPopupMenu popup;

  public StaticPopupMenuFactory(final JPopupMenu popup) {
    this.popup = popup;
  }

  @Override
  public JPopupMenu createPopupMenu() {
    return popup;
  }
}