//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.popup;

import javax.swing.JPopupMenu;


// NOT_PUBLISHED
public class StaticPopupMenuFactory implements IPopupMenuFactory {

  private final JPopupMenu popup;

  public StaticPopupMenuFactory(JPopupMenu popup) {
    this.popup = popup;
  }

  public JPopupMenu createPopupMenu() {
    return popup;
  }
}