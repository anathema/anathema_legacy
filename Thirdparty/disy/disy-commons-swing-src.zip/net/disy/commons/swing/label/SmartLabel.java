/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.label;

import javax.swing.JComponent;
import javax.swing.JLabel;

import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.label.internal.MnemonicLabel;
import net.disy.commons.swing.label.internal.MnemonicLabelParser;

public class SmartLabel extends JLabel {

  public SmartLabel(final String label, final IComponentContainer componentContainer) {
    this(label, componentContainer.getContent());
  }

  public SmartLabel(final String label) {
    this(label, (JComponent) null);
  }

  public SmartLabel(final String label, final JComponent forComponent) {
    setText(label);
    if (forComponent != null) {
      setLabelFor(forComponent);
    }
  }

  @Override
  public void setText(final String text) {
    final MnemonicLabel mnemonicLabel = MnemonicLabelParser.parse(text);
    if (mnemonicLabel.getMnemonicCharacter() != null) {
      setDisplayedMnemonic(mnemonicLabel.getMnemonicCharacter().charValue());
    }
    super.setText(mnemonicLabel.getPlainText());
  }
}