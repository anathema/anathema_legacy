/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.label.internal.test;

import static org.junit.Assert.*;

import net.disy.commons.swing.label.internal.MnemonicLabel;
import net.disy.commons.swing.label.internal.MnemonicLabelParser;

import org.junit.Test;

public class MnemonicLabelParserTest {

  @Test
  public void testParsesOrdinarayText() {
    final MnemonicLabel label = MnemonicLabelParser.parse("text"); //$NON-NLS-1$
    assertNull(label.getMnemonicCharacter());
    assertEquals("text", label.getPlainText()); //$NON-NLS-1$
  }

  @Test
  public void testParsesMenmonicCharacter() {
    final MnemonicLabel label = MnemonicLabelParser.parse("t&ext"); //$NON-NLS-1$
    assertEquals(new Character('e'), label.getMnemonicCharacter());
    assertEquals("text", label.getPlainText()); //$NON-NLS-1$
  }
}