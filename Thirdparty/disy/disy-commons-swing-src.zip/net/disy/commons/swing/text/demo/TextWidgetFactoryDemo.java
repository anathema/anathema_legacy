/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text.demo;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JTextField;

import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.text.ClearTextFieldButton;
import net.disy.commons.swing.text.TextWidgetFactory;
import de.jdemo.extensions.SwingDemoCase;

@SuppressWarnings("nls")
public class TextWidgetFactoryDemo extends SwingDemoCase {

  public void demoInternalWrappedTextField() {
    final JTextField textField = new JTextField(14);
    final JLabel westComponent = new JLabel(MessageTypeUi.errorIcon);
    show(TextWidgetFactory.createInternalComponentWrappedTextFieldComponent(
        westComponent,
        textField,
        new ClearTextFieldButton(textField, "Clear")));
  }

  public void demoInternalWrappedTextFieldWithOtherComponents() {
    final JTextField textField = new JTextField(14);
    final JLabel westComponent = new JLabel(MessageTypeUi.errorIcon);
    final JComponent component = TextWidgetFactory
        .createInternalComponentWrappedTextFieldComponent(
            westComponent,
            textField,
            new ClearTextFieldButton(textField, "Clear"));
    show(new JComponent[]{ new JButton("Button"), component, new JTextField(4) }, new FlowLayout()); //$NON-NLS-1$
  }
}