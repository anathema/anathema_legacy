/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JTextField;

import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.icon.CommonIcons;

public final class ClearTextFieldButton extends JButton {
  private final JTextField textField;

  public ClearTextFieldButton(final JTextField textField, final String toolTipText) {
    this(textField, toolTipText, new IClearTextFieldHandler() {

      @Override
      public void clear() {
        textField.setText(""); //$NON-NLS-1$
        textField.requestFocus();
      }
    });
  }

  public ClearTextFieldButton(
      final JTextField textField,
      final String toolTipText,
      final IClearTextFieldHandler clearHandler) {
    super(new SmartAction(CommonIcons.DELETE) {
      @Override
      protected void execute(final Component parentComponent) {
        clearHandler.clear();
      }
    });

    setPreferredSize(new Dimension(getIcon().getIconWidth() + 2, getIcon().getIconHeight() + 2));
    setBorderPainted(false);
    setBackground(SwingColors.getTextAreaBackgroundColor());
    setFocusPainted(false);
    setFocusable(false);
    setToolTipText(toolTipText);
    this.textField = textField;

    textField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        updateEnabled();
      }
    });
    updateEnabled();
  }

  private void updateEnabled() {
    setEnabled(!StringUtilities.isNullOrEmpty(textField.getText()));
  }
}