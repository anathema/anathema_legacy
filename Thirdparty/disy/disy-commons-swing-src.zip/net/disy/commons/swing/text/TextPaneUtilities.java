//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.text;

import javax.swing.JTextPane;
import javax.swing.SwingUtilities;

// NOT_PUBLISHED
public class TextPaneUtilities {

  public static void setTextAndScrollToFirstLine(final JTextPane textPane, final String text) {
    textPane.setText(text);
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        textPane.setCaretPosition(0);
      }
    });
  }

}