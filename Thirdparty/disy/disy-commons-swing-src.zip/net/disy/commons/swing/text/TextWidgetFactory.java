// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 25.08.2005
package net.disy.commons.swing.text;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPasswordField;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.IntModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.textfield.IntegerField;

// NOT_PUBLISHED
public class TextWidgetFactory {

  private static final int DEFAULT_COLUMN_COUNT = 25;

  private TextWidgetFactory() {
    throw new UnreachableCodeReachedException();
  }

  public static JTextField createTextField(final ObjectModel<String> stringModel) {
    return createTextField(stringModel, DEFAULT_COLUMN_COUNT);
  }

  public static JTextField createTextField(final ObjectModel<String> stringModel, int columnCount) {
    final JTextField widget = new JTextField(columnCount);
    return connect(stringModel, widget);
  }

  private static JTextField connect(final ObjectModel<String> stringModel, final JTextField widget) {
    stringModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        String value = stringModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getText())) {
          widget.setText(value);
        }
      }
    });
    widget.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        stringModel.setValue(widget.getText());
      }
    });
    widget.setText(stringModel.getValue());
    return widget;
  }


  public static JPasswordField createPasswordField(ObjectModel<String> model) {
    JPasswordField passwordField = new JPasswordField(DEFAULT_COLUMN_COUNT);
    connect(model, passwordField);
    return passwordField;
  }

  public static JComboBox createComboBox(final ObjectModel<String> stringModel, String[] values) {
    final JComboBox widget = new JComboBox(values);
    stringModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        String value = stringModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getSelectedItem())) {
          widget.setSelectedItem(value);
        }
      }
    });
    widget.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        stringModel.setValue((String) widget.getSelectedItem());
      }
    });
    widget.setSelectedItem(stringModel.getValue());
    return widget;
  }

  /** @deprecated As of 13.02.2006 (gebhard), use a {@link JSpinner} instead of a JTextField! */
  @Deprecated
  public static JTextField createTextField(final IntModel intModel) {
    final IntegerField widget = new IntegerField();
    intModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        int value = intModel.getValue();
        if (value != widget.getInt()) {
          widget.setInt(value);
        }
      }
    });
    widget.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        intModel.setValue(widget.getInt());
      }
    });
    widget.setInt(intModel.getValue());
    return widget;
  }
}