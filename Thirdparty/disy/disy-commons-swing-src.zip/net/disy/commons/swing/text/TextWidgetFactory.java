/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.util.Calendar;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicBorders;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.IntModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.textfield.IntegerField;

public class TextWidgetFactory {

  private static final int DEFAULT_COLUMN_COUNT = 25;

  private TextWidgetFactory() {
    throw new UnreachableCodeReachedException();
  }

  public static JTextField createTextField(final IObjectModel<String> stringModel) {
    return createTextField(stringModel, DEFAULT_COLUMN_COUNT);
  }

  public static JTextField createTextField(
      final IObjectModel<String> stringModel,
      final int columnCount) {
    final JTextField widget = new JTextField(columnCount);
    return connect(stringModel, widget);
  }

  private static JTextField connect(final IObjectModel<String> stringModel, final JTextField widget) {
    stringModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        final String value = stringModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getText())) {
          widget.setText(value);
        }
      }
    });
    widget.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        stringModel.setValue(widget.getText());
      }
    });
    widget.setText(stringModel.getValue());
    return widget;
  }

  public static JPasswordField createPasswordField(final ObjectModel<String> model) {
    final JPasswordField passwordField = new JPasswordField(DEFAULT_COLUMN_COUNT);
    connect(model, passwordField);
    return passwordField;
  }

  public static JComboBox createComboBox(
      final ObjectModel<String> stringModel,
      final String[] values) {
    final JComboBox widget = new JComboBox(values);
    stringModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        final String value = stringModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getSelectedItem())) {
          widget.setSelectedItem(value);
        }
      }
    });
    widget.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        stringModel.setValue((String) widget.getSelectedItem());
      }
    });
    widget.setSelectedItem(stringModel.getValue());
    return widget;
  }

  public static JTextField createTextField(final IntModel intModel) {
    final IntegerField widget = new IntegerField();
    intModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        final int value = intModel.getValue();
        if (value != widget.getInt()) {
          widget.setInt(value);
        }
      }
    });
    widget.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        intModel.setValue(widget.getInt());
      }
    });
    widget.setInt(intModel.getValue());
    return widget;
  }

  public static JFormattedTextField createUneditableDateWidget(
      final ObjectModel<Calendar> model,
      final DateFormat format) {
    final JFormattedTextField widget = new JFormattedTextField(format);
    widget.setValue(model.getValue().getTime());
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        widget.setValue(model.getValue().getTime());
      }
    });
    widget.setEditable(false);
    return widget;
  }

  public static JComponent createInternalComponentWrappedTextFieldComponent(
      final JComponent optionalWestComponent,
      final JTextField textField,
      final JComponent optionalEastComponent) {
    final int spacing = LayoutUtilities.getDpiAdjusted(3);
    textField.setBorder(new EmptyBorder(0, spacing, 0, spacing));
    final JPanel panel = new JPanel(new GridDialogLayout((optionalWestComponent == null ? 0 : 1)
        + 1
        + (optionalEastComponent == null ? 0 : 1), false)) {
      @Override
      public void requestFocus() {
        textField.requestFocus();
      }
    };
    panel.setBackground(SwingColors.getTextAreaBackgroundColor());
    if (optionalWestComponent != null) {
      panel.add(optionalWestComponent);
    }
    panel.add(textField, GridDialogLayoutData.FILL_HORIZONTAL);
    if (optionalEastComponent != null) {
      panel.add(optionalEastComponent, GridDialogLayoutData.RIGHT);
    }
    panel.setBorder(BasicBorders.getTextFieldBorder());
    return panel;
  }
}