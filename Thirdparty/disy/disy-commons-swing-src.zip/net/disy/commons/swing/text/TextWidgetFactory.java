// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 25.08.2005
package net.disy.commons.swing.text;

import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.StringModel;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;

// NOT_PUBLISHED
public class TextWidgetFactory {

  private TextWidgetFactory() {
    throw new UnreachableCodeReachedException();
  }
  
  public static JTextField createTextField(final StringModel stringModel) {
    final JTextField widget = new JTextField();
    stringModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        String value = stringModel.getValue();
        if (!ObjectUtilities.equals(value, widget.getText())) {
          widget.setText(value);
        }
      }
    });
    widget.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      protected void documentChanged() {
        stringModel.setValue(widget.getText());
      }
    });
    widget.setText(stringModel.getValue());
    return widget;
  }
}