/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text.alignment;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JToggleButton;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.text.TextAlignment;
import net.disy.commons.swing.model.TextAlignmentModel;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.text.TextActionResources;

public class TextAlignmentPanel {

  private static final Map<TextAlignment, Icon> ICONS = new HashMap<TextAlignment, Icon>() {
    {
      put(TextAlignment.LEFT, TextActionResources.ALIGN_LEFT);
      put(TextAlignment.CENTER, TextActionResources.ALIGN_CENTER);
      put(TextAlignment.RIGHT, TextActionResources.ALIGN_RIGHT);
    }
  };
  private static final Map<TextAlignment, String> LABELS = new HashMap<TextAlignment, String>() {
    {
      put(TextAlignment.LEFT, DisyCommonsSwingMessages.getString("TextAlignmentPanel.Left")); //$NON-NLS-1$
      put(TextAlignment.CENTER, DisyCommonsSwingMessages.getString("TextAlignmentPanel.Center")); //$NON-NLS-1$
      put(TextAlignment.RIGHT, DisyCommonsSwingMessages.getString("TextAlignmentPanel.Right")); //$NON-NLS-1$
    }
  };

  private JToggleButton createToggleButton(final TextAlignment textAlignment) {
    final Icon icon = ICONS.get(textAlignment);
    final String toolTip = LABELS.get(textAlignment);
    final JToggleButton toggleButton = new JToggleButton(toolTip, icon);
    toggleButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        alignmentModel.setTextAlignment(textAlignment);
      }
    });
    alignmentModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        if (alignmentModel.getTextAlignment() == textAlignment) {
          toggleButton.setSelected(true);
        }
      }
    });
    buttonGroup.add(toggleButton);
    toggleButton.setSelected(alignmentModel.getTextAlignment() == textAlignment);
    return toggleButton;
  }

  private final ButtonGroup buttonGroup = new ButtonGroup();
  private JComponent[] content;
  private final TextAlignmentModel alignmentModel;

  public TextAlignmentPanel(final TextAlignmentModel alignmentModel) {
    this.alignmentModel = alignmentModel;
  }

  public JComponent[] getComponents() {
    if (content == null) {
      content = createContent();
    }
    return content;
  }

  private JComponent[] createContent() {
    return new JComponent[]{
        createToggleButton(TextAlignment.LEFT),
        createToggleButton(TextAlignment.CENTER),
        createToggleButton(TextAlignment.RIGHT) };
  }
}