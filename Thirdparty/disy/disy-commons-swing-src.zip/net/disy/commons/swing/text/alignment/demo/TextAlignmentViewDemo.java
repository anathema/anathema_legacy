/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text.alignment.demo;

import net.disy.commons.core.text.TextAlignment;
import net.disy.commons.swing.model.TextAlignmentModel;
import net.disy.commons.swing.text.alignment.TextAlignmentPanel;
import net.disy.commons.swing.toolbar.ToolBarBuilder;

import de.jdemo.extensions.SwingDemoCase;

public class TextAlignmentViewDemo extends SwingDemoCase {

  public void demoTextAlignmentView() throws Exception {
    final TextAlignmentPanel view = new TextAlignmentPanel(new TextAlignmentModel(
        TextAlignment.CENTER));
    final ToolBarBuilder builder = new ToolBarBuilder();
    builder.add(view.getComponents());
    show(builder.createToolBar());
  }
}