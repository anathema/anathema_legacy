/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.text.alignment.test;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.text.TextAlignment;
import net.disy.commons.swing.model.TextAlignmentModel;

import org.easymock.EasyMock;

public class TextAlignmentModelTest extends CoreTestCase {

  private IChangeListener listener;

  @Override
  protected void setUp() throws Exception {
    listener = EasyMock.createStrictMock(IChangeListener.class);
  }

  public void testCreate() {
    final TextAlignmentModel model = new TextAlignmentModel(TextAlignment.LEFT);
    assertEquals(TextAlignment.LEFT, model.getTextAlignment());
  }

  public void testSet() {
    final TextAlignmentModel model = new TextAlignmentModel(TextAlignment.LEFT);
    model.setTextAlignment(TextAlignment.RIGHT);
    assertEquals(TextAlignment.RIGHT, model.getTextAlignment());
  }

  public void testNotifiesListenerOnChange() {
    final TextAlignmentModel model = new TextAlignmentModel(TextAlignment.LEFT);
    listener.stateChanged();
    EasyMock.replay(listener);
    model.addChangeListener(listener);
    model.setTextAlignment(TextAlignment.RIGHT);
    EasyMock.verify(listener);
  }

  public void testRemoveListener() {
    final TextAlignmentModel model = new TextAlignmentModel(TextAlignment.LEFT);
    EasyMock.replay(listener);
    model.addChangeListener(listener);
    model.removeChangeListener(listener);
    model.setTextAlignment(TextAlignment.RIGHT);
    EasyMock.verify(listener);
  }

  public void testNoNotificationOnNoChange() {
    final TextAlignmentModel model = new TextAlignmentModel(TextAlignment.LEFT);
    EasyMock.replay(listener);
    model.addChangeListener(listener);
    model.setTextAlignment(TextAlignment.LEFT);
    EasyMock.verify(listener);
  }
}