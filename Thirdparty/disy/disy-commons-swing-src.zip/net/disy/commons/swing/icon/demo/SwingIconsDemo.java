//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon.demo;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.swing.icon.SwingIcons;

// NOT_PUBLISHED
public class SwingIconsDemo extends AbstractIconResourcesDemo {

  public void demo() throws IllegalAccessException, InvocationTargetException {
    showStaticIcons(SwingIcons.class);
  }
}