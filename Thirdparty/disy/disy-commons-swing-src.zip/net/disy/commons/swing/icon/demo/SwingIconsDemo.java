//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon.demo;

import net.disy.commons.swing.icon.SwingIcons;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SwingIconsDemo extends SwingDemoCase {

  public void demoOptionPaneErrorIcon() {
    show(SwingIcons.getOptionPaneErrorIcon());
  }

  public void demoOptionPaneInformationIcon() {
    show(SwingIcons.getOptionPaneInformationIcon());
  }

  public void demoOptionPaneWarningIcon() {
    show(SwingIcons.getOptionPaneWarningIcon());
  }

  public void demoTreeClosedIcon() {
    show(SwingIcons.getTreeClosedIcon());
  }

  public void demoTreeLeafIcon() {
    show(SwingIcons.getTreeLeafIcon());
  }

  public void demoTreeOpenIcon() {
    show(SwingIcons.getTreeOpenIcon());
  }

  public void demoFileViewComputerIcon() {
    show(SwingIcons.getFileViewComputerIcon());
  }

  public void demoFileViewDirectoryIcon() {
    show(SwingIcons.getFileViewDirectoryIcon());
  }

  public void demoFileViewFileIcon() {
    show(SwingIcons.getFileViewFileIcon());
  }

  public void demoFileViewFloppyDriveIcon() {
    show(SwingIcons.getFileViewFloppyDriveIcon());
  }

  public void demoFileViewHardDriveIcon() {
    show(SwingIcons.getFileViewHardDriveIcon());
  }

  public void demoFileViewNewFolderIcon() {
    show(SwingIcons.getFileViewNewFolderIcon());
  }

  public void demoFileViewUpFolderIcon() {
    show(SwingIcons.getFileViewUpFolderIcon());
  }

  public void demoInternalFrameCloseIcon() {
    show(SwingIcons.getInternalFrameCloseIcon());
  }

  public void demoInternalFrameIcon() {
    show(SwingIcons.getInternalFrameIcon());
  }

  public void demoInternalFrameIconifyIcon() {
    show(SwingIcons.getInternalFrameIconifyIcon());
  }

  public void demoInternalFrameMaximizeIcon() {
    show(SwingIcons.getInternalFrameMaximizeIcon());
  }

  public void demoInternalFrameMinimizeIcon() {
    show(SwingIcons.getInternalFrameMinimizeIcon());
  }
}