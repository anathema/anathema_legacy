// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon;

import javax.swing.Icon;

import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;

//NOT_PUBLISHED
public class CommonIcons {

  public static final Icon DELETE = getImageIcon("delete.gif"); //$NON-NLS-1$
  public static final Icon REFRESH = getImageIcon("refresh.gif"); //$NON-NLS-1$

  private static Icon getImageIcon(String name) {
    return DisyCommonsSwingImageProvider.getInstance().getImageIcon("common/" + name); //$NON-NLS-1$
  }
}
