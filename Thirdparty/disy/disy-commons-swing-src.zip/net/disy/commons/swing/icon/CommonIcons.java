/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon;

import javax.swing.Icon;

import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.resources.IIconResources;

public class CommonIcons implements IIconResources {

  public static final Icon DELETE = getImageIcon("common/delete.gif"); //$NON-NLS-1$
  public static final Icon DELETE_ALL = getImageIcon("common/delete_all.gif"); //$NON-NLS-1$
  public static final Icon REFRESH = getImageIcon("common/refresh.gif"); //$NON-NLS-1$
  public static final Icon PRINTER = getImageIcon("common/printer.gif"); //$NON-NLS-1$
  public static final Icon FOLDER = getImageIcon("file/folder.gif"); //$NON-NLS-1$
  public static final Icon FOLDER_NEW = getImageIcon("file/new_folder.gif"); //$NON-NLS-1$
  public static final Icon FOLDER_UP = getImageIcon("file/up_folder.gif"); //$NON-NLS-1$

  public static final Icon REFRESH_ANIMATION = DisyCommonsSwingImageProvider
      .getInstance()
      .getAnimatedImageIcon("common/refresh_animation.gif"); //$NON-NLS-1$

  private static Icon getImageIcon(final String name) {
    return DisyCommonsSwingImageProvider.getInstance().getImageIcon(name);
  }
}