/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon.test;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.Icon;

import junit.framework.Assert;

import net.disy.commons.swing.icon.util.IconUtilities;

public class IconTestUtilities {

  private static void assureIconContentEquals(final Icon expectedIcon, final Icon actualIcon) {
    final BufferedImage expectedImage = IconUtilities.createBufferedImage(expectedIcon);
    final BufferedImage actualImage = IconUtilities.createBufferedImage(actualIcon);
    assertImageEquals(expectedImage, actualImage);
  }

  public static void assertImageEquals(
      final BufferedImage expectedImage,
      final BufferedImage actualImage) {
    assertSameSize(expectedImage, actualImage);
    for (int x = actualImage.getMinX(); x < actualImage.getWidth(); x++) {
      for (int y = actualImage.getMinY(); y < actualImage.getHeight(); y++) {
        Assert.assertEquals(expectedImage.getRGB(x, y), actualImage.getRGB(x, y));
      }
    }
  }

  private static void assureIconDimensionEquals(final Icon expectedIcon, final Icon actualIcon) {
    Assert.assertEquals(expectedIcon.getIconHeight(), actualIcon.getIconHeight());
    Assert.assertEquals(expectedIcon.getIconWidth(), actualIcon.getIconWidth());
  }

  public static void assertIconEquals(final Icon expectedIcon, final Icon actualIcon) {
    if (actualIcon == null) {
      Assert.assertNull(expectedIcon);
      return;
    }
    Assert.assertNotNull(expectedIcon);
    assureIconDimensionEquals(expectedIcon, actualIcon);
    assureIconContentEquals(expectedIcon, actualIcon);
  }

  public static Icon createExampleIcon() {
    return new Icon() {
      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        final Graphics graphics = g.create();

        graphics.setColor(Color.BLACK);
        graphics.drawRect(x + 2, y + 2, 10, 10);

        graphics.setColor(Color.RED);
        graphics.drawRect(x + 3, y + 3, 8, 8);

        graphics.setColor(Color.BLUE);
        graphics.fillRect(x + 5, y + 5, 5, 5);

        graphics.dispose();
      }

      @Override
      public int getIconWidth() {
        return 16;
      }

      @Override
      public int getIconHeight() {
        return 16;
      }
    };
  }

  public static final void assertSameSize(final BufferedImage expected, final BufferedImage actual) {
    Assert.assertEquals(expected.getWidth(), actual.getWidth());
    Assert.assertEquals(expected.getHeight(), actual.getHeight());
  }
}