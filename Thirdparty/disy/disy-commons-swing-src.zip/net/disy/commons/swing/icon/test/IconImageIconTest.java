/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon.test;

import javax.swing.Icon;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.icon.IconImageIcon;

public class IconImageIconTest extends CoreTestCase {

  private IconImageIcon imageIcon;
  private Icon icon;

  @Override
  protected void setUp() throws Exception {
    icon = IconTestUtilities.createExampleIcon();
    imageIcon = new IconImageIcon(icon);
  }

  public void testIconEquals() {
    IconTestUtilities.assertIconEquals(icon, imageIcon);
  }

}
