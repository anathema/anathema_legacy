//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon;

import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.Icon;

import net.disy.commons.swing.graphics.ColorFilterGraphics;

// NOT_PUBLISHED
public class DisabledIconDecorator implements Icon {

  private final Icon icon;

  public DisabledIconDecorator(Icon icon) {
    this.icon = icon;
  }

  public int getIconHeight() {
    return icon.getIconHeight();
  }

  public int getIconWidth() {
    return icon.getIconWidth();
  }

  public void paintIcon(Component c, Graphics g, int x, int y) {
    ColorFilterGraphics disabledGraphics = new ColorFilterGraphics((Graphics2D) g, c);
    icon.paintIcon(c, disabledGraphics, x, y);
  }

}
