package net.disy.commons.swing.icon.demo;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractIconResourcesDemo extends SwingDemoCase {

  protected final void showStaticIcons(Class class1) throws IllegalAccessException, InvocationTargetException {
    Field[] fields = class1.getFields();
    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < fields.length; ++i) {
      final Field field = fields[i];
      if (isStaticIconField(field)) {
        Icon icon = (Icon) field.get(null);
        panel.add(new JLabel(getSimpleClassName(class1) + '.' + field.getName(), icon, SwingConstants.LEFT));
      }
    }
    Method[] methods = class1.getMethods();
    for (int i = 0; i < methods.length; ++i) {
      final Method method = methods[i];
      if (isStaticIconMethod(method)) {
        Icon icon = (Icon) method.invoke(null, null);
        panel.add(new JLabel(
            getSimpleClassName(class1) + '.' + method.getName() + "()", icon, SwingConstants.LEFT)); //$NON-NLS-1$
      }
    }
    show(new JScrollPane(panel));
  }

  private boolean isStaticIconMethod(Method method) {
    if (!Modifier.isStatic(method.getModifiers())) {
      return false;
    }
    return (Icon.class.isAssignableFrom(method.getReturnType()));
  }

  private final static boolean isStaticIconField(final Field field) {
    if (!Modifier.isStatic(field.getModifiers())) {
      return false;
    }
    return (Icon.class.isAssignableFrom(field.getType()));
  }

  private final static String getSimpleClassName(Class class1) {
    String className = class1.getName();
    int index = className.lastIndexOf('.');
    return className.substring(index + 1);
  }
}