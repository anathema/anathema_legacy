/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon.demo;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Map;
import java.util.Map.Entry;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractIconResourcesDemo extends SwingDemoCase {

  private static final int COLUMN_COUNT = 3;

  protected final void showStaticIcons(final Class<?> class1) {
    try {
      final JPanel panel = new JPanel(new GridDialogLayout(COLUMN_COUNT, false));
      addLabel(panel, "Class: " + getSimpleClassName(class1)); //$NON-NLS-1$
      addFields(class1, panel);
      addMethods(class1, panel);
      show(new JScrollPane(panel));
    }
    catch (final InvocationTargetException e) {
      throw new RuntimeException("Unable to access icon field/method", e); //$NON-NLS-1$
    }
    catch (final IllegalAccessException e) {
      throw new RuntimeException("Unable to access icon field/method", e); //$NON-NLS-1$
    }
  }

  private void addMethods(final Class<?> class1, final JPanel panel)
      throws IllegalAccessException,
      InvocationTargetException {
    final Method[] methods = class1.getMethods();

    final Method[] iconMethods = ArrayUtilities.filter(methods, new IPredicate<Method>() {
      @Override
      public boolean evaluate(final Method method) {
        return isStaticIconMethod(method) || isStaticIconMapMethod(method);
      }
    });
    if (iconMethods.length == 0) {
      return;
    }
    addLabel(panel, " - Methods - "); //$NON-NLS-1$
    for (final Method method : iconMethods) {
      if (isStaticIconMethod(method)) {
        addIcon(panel, (Icon) method.invoke(null), method.getName() + "()");//$NON-NLS-1$
      }
      else if (isStaticIconMapMethod(method)) {
        addLabel(panel, "Method: " + method.getName() + "()"); //$NON-NLS-1$ //$NON-NLS-2$
        @SuppressWarnings("unchecked")
        final Map<String, Icon> icons = (Map<String, Icon>) method.invoke(null);
        for (final Entry<String, Icon> icon : icons.entrySet()) {
          addIcon(panel, icon.getValue(), icon.getKey());
        }
      }
    }
  }

  private void addFields(final Class<?> class1, final JPanel panel) throws IllegalAccessException {
    final Field[] fields = class1.getFields();
    final Field[] iconFields = ArrayUtilities.filter(fields, new IPredicate<Field>() {
      @Override
      public boolean evaluate(final Field field) {
        return isStaticIconField(field);
      }
    });
    if (iconFields.length == 0) {
      return;
    }
    addLabel(panel, " - Fields - "); //$NON-NLS-1$
    for (final Field field : iconFields) {
      addIcon(panel, (Icon) field.get(null), field.getName());
    }
  }

  private boolean isStaticIconMethod(final Method method) {
    if (!Modifier.isStatic(method.getModifiers())) {
      return false;
    }
    return method.getParameterTypes().length == 0
        && Icon.class.isAssignableFrom(method.getReturnType());
  }

  private boolean isStaticIconMapMethod(final Method method) {
    if (!Modifier.isStatic(method.getModifiers())) {
      return false;
    }
    if (method.getParameterTypes().length != 0) {
      return false;
    }
    if (!Map.class.isAssignableFrom(method.getReturnType())) {
      return false;
    }
    final Type type = method.getGenericReturnType();
    if (!(type instanceof ParameterizedType)) {
      return false;
    }
    final ParameterizedType pt = (ParameterizedType) type;
    if (pt.getActualTypeArguments().length != 2) {
      return false;
    }
    if (!String.class.isAssignableFrom((Class<?>) pt.getActualTypeArguments()[0])) {
      return false;
    }
    if (!Icon.class.isAssignableFrom((Class<?>) pt.getActualTypeArguments()[1])) {
      return false;
    }
    return true;
  }

  private final static boolean isStaticIconField(final Field field) {
    if (!Modifier.isStatic(field.getModifiers())) {
      return false;
    }
    return Icon.class.isAssignableFrom(field.getType());
  }

  private final static String getSimpleClassName(final Class<?> class1) {
    final String className = class1.getName();
    final int index = className.lastIndexOf('.');
    return className.substring(index + 1);
  }

  private void addIcon(final JPanel panel, final Icon icon, final String text) {
    panel.add(new JLabel(icon));
    panel.add(createSelectableLabel(text));
    panel.add(new JLabel(icon.getIconWidth() + "x" + icon.getIconHeight())); //$NON-NLS-1$
  }

  private void addLabel(final JPanel panel, final String text) {
    panel.add(
        createSelectableLabel(text),
        new GridDialogLayoutData().setHorizontalSpan(COLUMN_COUNT));
  }

  private JTextField createSelectableLabel(final String text) {
    final JTextField textField = new JTextField(text, text.length() + 1);
    textField.setEditable(false);
    textField.setBorder(null);
    return textField;
  }
}