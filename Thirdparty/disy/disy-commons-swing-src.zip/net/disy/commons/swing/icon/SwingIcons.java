/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon;

import javax.swing.Icon;
import javax.swing.UIManager;

public class SwingIcons {

  public static Icon getOptionPaneErrorIcon() {
    return UIManager.getIcon("OptionPane.errorIcon"); //$NON-NLS-1$
  }

  public static Icon getOptionPaneWarningIcon() {
    return UIManager.getIcon("OptionPane.warningIcon"); //$NON-NLS-1$
  }

  public static Icon getOptionPaneInformationIcon() {
    return UIManager.getIcon("OptionPane.informationIcon"); //$NON-NLS-1$
  }

  public static Icon getOptionPaneQuestionIcon() {
    return UIManager.getIcon("OptionPane.questionIcon"); //$NON-NLS-1$
  }

  public static Icon getTreeLeafIcon() {
    return UIManager.getIcon("Tree.leafIcon"); //$NON-NLS-1$
  }

  public static Icon getTreeClosedIcon() {
    final Icon icon = UIManager.getIcon("Tree.closedIcon"); //$NON-NLS-1$
    return icon == null ? getFileViewDirectoryIcon() : icon;
  }

  public static Icon getTreeOpenIcon() {
    return UIManager.getIcon("Tree.openIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewDirectoryIcon() {
    return UIManager.getIcon("FileView.directoryIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewFileIcon() {
    return UIManager.getIcon("FileView.fileIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewComputerIcon() {
    return UIManager.getIcon("FileView.computerIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewHardDriveIcon() {
    return UIManager.getIcon("FileView.hardDriveIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewFloppyDriveIcon() {
    return UIManager.getIcon("FileView.floppyDriveIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewNewFolderIcon() {
    final Icon icon = UIManager.getIcon("FileView.newFolderIcon"); //$NON-NLS-1$
    return (icon == null) ? CommonIcons.FOLDER_NEW : icon;
  }

  public static Icon getFileViewUpFolderIcon() {
    final Icon icon = UIManager.getIcon("FileView.upFolderIcon"); //$NON-NLS-1$
    return (icon == null) ? CommonIcons.FOLDER_UP : icon;
  }

  //TODO 15.01.2008 (gebhard): internal frame icons sometimes cannot be used in other contexts. E.g.
  //the metal L&F returns icons, that cast their component to an AbstractButton (code taken from the
  // package javax.swing.plaf.metal):
  //  private static class IFIcon extends IconUIResource {
  //    private Icon pressed;
  //
  //    public IFIcon(Icon normal, Icon pressed) {
  //        super(normal);
  //        this.pressed = pressed;
  //    }
  //
  //    public void paintIcon(Component c, Graphics g, int x, int y) {
  //        ButtonModel model = ((AbstractButton)c).getModel();
  //        if (model.isPressed() && model.isArmed()) {
  //            pressed.paintIcon(c, g, x, y);
  //        } else {
  //            super.paintIcon(c, g, x, y);
  //        }
  //    }
  //}
  //  public static Icon getInternalFrameMaximizeIcon() {
  //    return UIManager.getIcon("InternalFrame.maximizeIcon"); //$NON-NLS-1$
  //  }
  //
  //  public static Icon getInternalFrameMinimizeIcon() {
  //    return UIManager.getIcon("InternalFrame.minimizeIcon"); //$NON-NLS-1$
  //  }
  //
  //  public static Icon getInternalFrameIconifyIcon() {
  //    return UIManager.getIcon("InternalFrame.iconifyIcon"); //$NON-NLS-1$
  //  }
  //
  //  public static Icon getInternalFrameCloseIcon() {
  //    return UIManager.getIcon("InternalFrame.closeIcon"); //$NON-NLS-1$
  //  }
  //
  //  public static Icon getInternalFrameIcon() {
  //    return UIManager.getIcon("InternalFrame.icon"); //$NON-NLS-1$
  //  }
}