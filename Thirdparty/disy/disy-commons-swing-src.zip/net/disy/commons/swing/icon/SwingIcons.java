//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon;

import javax.swing.Icon;
import javax.swing.UIManager;

import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;

// NOT_PUBLISHED
public class SwingIcons {

  private static final Icon FALLBACK_NEW_FOLDER_ICON = DisyCommonsSwingImageProvider
      .getInstance()
      .getImageIcon("file/new_folder.gif"); //$NON-NLS-1$

  private static final Icon FALLBACK_UP_FOLDER_ICON = DisyCommonsSwingImageProvider
      .getInstance()
      .getImageIcon("file/up_folder.gif"); //$NON-NLS-1$

  public static Icon getOptionPaneErrorIcon() {
    return UIManager.getIcon("OptionPane.errorIcon"); //$NON-NLS-1$
  }

  public static Icon getOptionPaneWarningIcon() {
    return UIManager.getIcon("OptionPane.warningIcon"); //$NON-NLS-1$
  }

  public static Icon getOptionPaneInformationIcon() {
    return UIManager.getIcon("OptionPane.informationIcon"); //$NON-NLS-1$
  }

  public static Icon getTreeLeafIcon() {
    return UIManager.getIcon("Tree.leafIcon"); //$NON-NLS-1$
  }

  public static Icon getTreeClosedIcon() {
    return UIManager.getIcon("Tree.closedIcon"); //$NON-NLS-1$
  }

  public static Icon getTreeOpenIcon() {
    return UIManager.getIcon("Tree.openIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewDirectoryIcon() {
    return UIManager.getIcon("FileView.directoryIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewFileIcon() {
    return UIManager.getIcon("FileView.fileIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewComputerIcon() {
    return UIManager.getIcon("FileView.computerIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewHardDriveIcon() {
    return UIManager.getIcon("FileView.hardDriveIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewFloppyDriveIcon() {
    return UIManager.getIcon("FileView.floppyDriveIcon"); //$NON-NLS-1$
  }

  public static Icon getFileViewNewFolderIcon() {
    final Icon icon = UIManager.getIcon("FileView.newFolderIcon"); //$NON-NLS-1$
    return (icon == null) ? FALLBACK_NEW_FOLDER_ICON : icon;
  }

  public static Icon getFileViewUpFolderIcon() {
    final Icon icon = UIManager.getIcon("FileView.upFolderIcon"); //$NON-NLS-1$
    return (icon == null) ? FALLBACK_UP_FOLDER_ICON : icon;
  }

  public static Icon getInternalFrameMaximizeIcon() {
    return UIManager.getIcon("InternalFrame.maximizeIcon"); //$NON-NLS-1$
  }

  public static Icon getInternalFrameMinimizeIcon() {
    return UIManager.getIcon("InternalFrame.minimizeIcon"); //$NON-NLS-1$
  }

  public static Icon getInternalFrameIconifyIcon() {
    return UIManager.getIcon("InternalFrame.iconifyIcon"); //$NON-NLS-1$
  }

  public static Icon getInternalFrameCloseIcon() {
    return UIManager.getIcon("InternalFrame.closeIcon"); //$NON-NLS-1$
  }

  public static Icon getInternalFrameIcon() {
    return UIManager.getIcon("InternalFrame.icon"); //$NON-NLS-1$
  }
}