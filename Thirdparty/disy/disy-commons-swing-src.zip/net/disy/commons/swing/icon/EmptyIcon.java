// Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.icon;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.Icon;

// NOT_PUBLISHED
public class EmptyIcon implements Icon {
  private Dimension size;

  public EmptyIcon() {
    this(new Dimension(0, 0));
  }

  public EmptyIcon(Dimension size) {
    this.size = size;
  }

  public int getIconHeight() {
    return size.height;
  }

  public int getIconWidth() {
    return size.width;
  }

  public void paintIcon(Component c, Graphics g, int x, int y) {
    //nothing to do
  }
}
