package net.disy.commons.swing.icon;

import java.awt.Component;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;

import net.disy.commons.core.util.Ensure;

/**
 * @author Markus Gebhard
 */
public class AggregatedIcon implements Icon {

  public static Icon createDecoratedIcon(Icon baseIcon, Icon decoratingIcon) {
    AggregatedIcon icon = new AggregatedIcon(baseIcon);
    icon.addDecorationIcon(decoratingIcon);
    return icon;
  }

  private final List /*<Icon>*/decorations = new ArrayList();
  private final Icon baseIcon;

  public AggregatedIcon(Icon baseIcon) {
    Ensure.ensureArgumentNotNull(baseIcon);
    this.baseIcon = baseIcon;
  }

  public void paintIcon(Component c, Graphics g, int x, int y) {
    baseIcon.paintIcon(c, g, x, y);
    for (int i = 0; i < decorations.size(); ++i) {
      ((Icon) decorations.get(i)).paintIcon(c, g, x, y);
    }
  }

  public int getIconWidth() {
    int width = baseIcon.getIconWidth();
    for (int i = 0; i < decorations.size(); ++i) {
      if (((Icon) decorations.get(i)).getIconWidth() > width) {
        width = ((Icon) decorations.get(i)).getIconWidth();
      }
    }
    return width;
  }

  public int getIconHeight() {
    int height = baseIcon.getIconHeight();
    for (int i = 0; i < decorations.size(); ++i) {
      if (((Icon) decorations.get(i)).getIconHeight() > height) {
        height = ((Icon) decorations.get(i)).getIconHeight();
      }
    }
    return height;
  }

  public void addDecorationIcon(Icon icon) {
    if (icon == null) {
      return;
    }
    decorations.add(icon);
  }
}