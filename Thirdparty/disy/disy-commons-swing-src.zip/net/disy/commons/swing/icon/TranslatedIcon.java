/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.icon;

import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.core.util.Ensure;

public class TranslatedIcon implements Icon {

  private final Icon icon;
  private final int dx;
  private final int dy;

  public TranslatedIcon(final Icon icon, final int dx, final int dy) {
    Ensure.ensureArgumentNotNull(icon);
    this.icon = icon;
    this.dx = dx;
    this.dy = dy;
  }

  @Override
  public int getIconHeight() {
    return icon.getIconHeight() + dy;
  }

  @Override
  public int getIconWidth() {
    return icon.getIconHeight() + dx;
  }

  @Override
  public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
    icon.paintIcon(c, g, x + dx, y + dy);
  }
}