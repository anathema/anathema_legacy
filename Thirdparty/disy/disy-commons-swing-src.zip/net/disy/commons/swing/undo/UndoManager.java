/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.model.AbstractChangeableModel;

public class UndoManager<T> extends AbstractChangeableModel {

  private final IUndoStateManager<T> stateManager;
  private T currentState;
  private final List<T> undoStates = new ArrayList<T>();
  private final List<T> redoStates = new ArrayList<T>();

  public UndoManager(final IUndoStateManager<T> stateManager) {
    this.stateManager = stateManager;
    reset();
  }

  public void reset() {
    currentState = stateManager.getState();
    undoStates.clear();
    redoStates.clear();
    fireChangeEvent();
  }

  public boolean isUndoPossible() {
    return !undoStates.isEmpty();
  }

  public boolean isRedoPossible() {
    return !redoStates.isEmpty();
  }

  public void addUndoPoint() {
    undoStates.add(currentState);
    currentState = stateManager.getState();
    redoStates.clear();
    fireChangeEvent();
  }

  public void undo() {
    moveState(undoStates, redoStates);
  }

  public void redo() {
    moveState(redoStates, undoStates);
  }

  private void moveState(final List<T> from, final List<T> to) {
    to.add(currentState);
    int lastFromIndex = from.size() - 1;
    currentState = from.get(lastFromIndex);
    stateManager.setState(currentState);
    from.remove(lastFromIndex);
    fireChangeEvent();
  }
}