/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo.demo;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.toolbar.ToolBarBuilder;
import net.disy.commons.swing.undo.IUndoStateManager;
import net.disy.commons.swing.undo.RedoAction;
import net.disy.commons.swing.undo.UndoAction;
import net.disy.commons.swing.undo.UndoManager;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class UndoRedoDemo extends SwingDemoCase {
  public void demo() throws Exception {
    final JTextField textField = new JTextField(16);
    final JPanel panel = new JPanel(new BorderLayout());
    final ToolBarBuilder toolBarBuilder = new ToolBarBuilder();
    final UndoManager<String> undoManager = new UndoManager<String>(
        new IUndoStateManager<String>() {
          @Override
          public void setState(final String state) {
            textField.setText(state);
          }

          @Override
          public String getState() {
            return textField.getText();
          }
        });
    toolBarBuilder.add(new UndoAction(undoManager));
    toolBarBuilder.add(new RedoAction(undoManager));
    panel.add(toolBarBuilder.createToolBar(), BorderLayout.NORTH);
    panel.add(textField, BorderLayout.CENTER);
    final SmartAction addUndoPointAction = new SmartAction("Schritt Setzen") { //$NON-NLS-1$
      @Override
      protected void execute(final Component parentComponent) {
        undoManager.addUndoPoint();
      }
    };
    panel.add(new JButton(addUndoPointAction), BorderLayout.SOUTH);

    show(panel);
  }
}
