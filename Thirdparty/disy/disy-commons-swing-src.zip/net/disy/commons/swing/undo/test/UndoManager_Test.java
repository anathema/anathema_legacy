/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo.test;

import static org.junit.Assert.*;

import net.disy.commons.swing.undo.IUndoStateManager;
import net.disy.commons.swing.undo.UndoManager;

import org.junit.Before;
import org.junit.Test;

public class UndoManager_Test {
  private UndoManager<String> undoManager;
  private IUndoStateManager<String> stateManager;

  @Before
  public void setUp() {
    stateManager = new TestStateManager();
    stateManager.setState("initial"); //$NON-NLS-1$
    undoManager = new UndoManager<String>(stateManager);
  }

  @Test
  public void undoSecondStep() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("second"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    assertEquals("first", stateManager.getState()); //$NON-NLS-1$
    assertTrue(undoManager.isUndoPossible());
    assertTrue(undoManager.isRedoPossible());
  }

  @Test
  public void undoTwoSteps() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("second"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    undoManager.undo();
    assertEquals("initial", stateManager.getState()); //$NON-NLS-1$
    assertFalse(undoManager.isUndoPossible());
    assertTrue(undoManager.isRedoPossible());
  }

  @Test
  public void redoSecondStep() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("second"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    undoManager.redo();
    assertEquals("second", stateManager.getState()); //$NON-NLS-1$
    assertTrue(undoManager.isUndoPossible());
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void redoFirstStep() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("second"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    undoManager.undo();
    undoManager.redo();
    assertEquals("first", stateManager.getState()); //$NON-NLS-1$
    assertTrue(undoManager.isUndoPossible());
    assertTrue(undoManager.isRedoPossible());
  }

  @Test
  public void redoTwoSteps() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("second"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    undoManager.undo();
    undoManager.redo();
    undoManager.redo();
    assertEquals("second", stateManager.getState()); //$NON-NLS-1$
    assertTrue(undoManager.isUndoPossible());
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void undoSingleStepWithStepAfterwards() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    stateManager.setState("new"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    assertTrue(undoManager.isUndoPossible());
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void stepAfterReset() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("reset"); //$NON-NLS-1$
    undoManager.reset();
    stateManager.setState("newFirst"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    assertTrue(undoManager.isUndoPossible());
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void undoAfterReset() throws Exception {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    stateManager.setState("reset"); //$NON-NLS-1$
    undoManager.reset();
    stateManager.setState("newFirst"); //$NON-NLS-1$
    undoManager.addUndoPoint();
    undoManager.undo();
    assertEquals("reset", stateManager.getState()); //$NON-NLS-1$
    assertFalse(undoManager.isUndoPossible());
    assertTrue(undoManager.isRedoPossible());
  }
}