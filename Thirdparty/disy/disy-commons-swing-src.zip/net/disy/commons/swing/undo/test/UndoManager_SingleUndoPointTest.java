/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.model.listener.testing.ChangeListenerObjectMother;
import net.disy.commons.swing.undo.IUndoStateManager;
import net.disy.commons.swing.undo.UndoManager;

import org.junit.Before;
import org.junit.Test;

@SuppressWarnings("nls")
public class UndoManager_SingleUndoPointTest {
  private static final String FOLLOW_UP_STATE = "followup";
  private static final String INITIAL_STATE = "initial";
  private UndoManager<String> undoManager;
  private IUndoStateManager<String> stateManager;
  private IChangeListener notifiedListener;

  @Before
  public void createManagerWithOneSingleUndoneUndoPoint() {
    stateManager = new TestStateManager();
    stateManager.setState(INITIAL_STATE);
    undoManager = new UndoManager<String>(stateManager);
    stateManager.setState(FOLLOW_UP_STATE);
    undoManager.addUndoPoint();
  }

  @Before
  public void createNotifiedListener() throws Exception {
    notifiedListener = ChangeListenerObjectMother.createNotifiedMock();
  }

  @Test
  public void undoSetsStateManagerToInitialState() throws Exception {
    undoManager.undo();
    assertThat(INITIAL_STATE, is(stateManager.getState()));
  }

  @Test
  public void undoMakesUndoImpossible() throws Exception {
    undoManager.undo();
    assertThat(undoManager.isUndoPossible(), is(false));
  }

  @Test
  public void undoMakesRedoPossible() throws Exception {
    undoManager.undo();
    assertThat(undoManager.isRedoPossible(), is(true));
  }

  @Test
  public void redoBecomesImpossibleWithRedo() throws Exception {
    undoManager.undo();
    undoManager.redo();
    assertThat(undoManager.isRedoPossible(), is(false));
  }

  @Test
  public void redoSetsFollowupState() throws Exception {
    undoManager.undo();
    undoManager.redo();
    assertThat(stateManager.getState(), is(FOLLOW_UP_STATE));
  }

  @Test
  public void undoReactivatesWithRedo() throws Exception {
    undoManager.undo();
    undoManager.redo();
    assertThat(undoManager.isUndoPossible(), is(true));
  }

  @Test
  public void undoNotifiesListener() throws Exception {
    undoManager.addChangeListener(notifiedListener);
    undoManager.undo();
    verify(notifiedListener);
  }

  @Test
  public void redoNotifiesListener() throws Exception {
    undoManager.undo();
    undoManager.addChangeListener(notifiedListener);
    undoManager.redo();
    verify(notifiedListener);
  }

  @Test
  public void undoIsNotPossibleAfterReset() throws Exception {
    undoManager.reset();
    assertThat(undoManager.isUndoPossible(), is(false));
  }

  @Test
  public void redoIsNotPossibleAfterReset() throws Exception {
    undoManager.undo();
    undoManager.reset();
    assertThat(undoManager.isRedoPossible(), is(false));
  }
}