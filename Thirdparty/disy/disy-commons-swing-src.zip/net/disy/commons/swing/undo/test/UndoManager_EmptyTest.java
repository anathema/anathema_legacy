/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo.test;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.model.listener.testing.ChangeListenerObjectMother;
import net.disy.commons.swing.undo.IUndoStateManager;
import net.disy.commons.swing.undo.UndoManager;

import org.junit.Before;
import org.junit.Test;

public class UndoManager_EmptyTest {
  private UndoManager<String> undoManager;
  private IUndoStateManager<String> stateManager;

  @Before
  public void setUp() {
    stateManager = new TestStateManager();
    stateManager.setState("initial"); //$NON-NLS-1$
    undoManager = new UndoManager<String>(stateManager);
  }

  @Test
  public void undoIsNotPossible() throws Exception {
    assertFalse(undoManager.isUndoPossible());
  }

  @Test
  public void redoIsNotPossible() throws Exception {
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void undoBecomesPossibleWithAdditionOfUndoPoint() throws Exception {
    addUndoPoint();
    assertTrue(undoManager.isUndoPossible());
    assertFalse(undoManager.isRedoPossible());
  }

  @Test
  public void reRemainsImpossibleWithAdditionOfUndoPoint() throws Exception {
    addUndoPoint();
    assertFalse(undoManager.isRedoPossible());
  }

  private void addUndoPoint() {
    stateManager.setState("first"); //$NON-NLS-1$
    undoManager.addUndoPoint();
  }

  @Test
  public void notifiesListenerOnReset() throws Exception {
    IChangeListener listener = ChangeListenerObjectMother.createNotifiedMock();
    undoManager.addChangeListener(listener);
    undoManager.reset();
    verify(listener);
  }
}