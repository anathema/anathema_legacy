/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.undo;

import java.awt.Component;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.resources.DisyCommonsSwingIconResources;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class UndoAction extends SmartAction {
  private final UndoManager<?> undoManager;

  public UndoAction(final UndoManager<?> undoManager) {
    super(DisyCommonsSwingMessages.getString("UndoAction.name"), DisyCommonsSwingIconResources.UNDO); //$NON-NLS-1$
    this.undoManager = undoManager;
    undoManager.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateEnabled();
      }
    });
    updateEnabled();
  }

  private void updateEnabled() {
    setEnabled(undoManager.isUndoPossible());
  }

  @Override
  protected void execute(final Component parentComponent) {
    undoManager.undo();
  }
}