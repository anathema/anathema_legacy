/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import javax.swing.Action;

import net.disy.commons.core.grouped.IGroupedItem;

public class GroupedToolBarItem implements IGroupedItem<String, Action> {

  private final String groupId;
  private final Action action;

  public GroupedToolBarItem(final String groupId, final Action action) {
    this.groupId = groupId;
    this.action = action;
  }

  @Override
  public String getGroupId() {
    return groupId;
  }

  @Override
  public Action getItem() {
    return action;
  }
}
