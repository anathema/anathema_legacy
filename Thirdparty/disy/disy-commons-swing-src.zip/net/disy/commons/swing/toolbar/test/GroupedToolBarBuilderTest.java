/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JToolBar;

import net.disy.commons.swing.component.VerticalLine;
import net.disy.commons.swing.toolbar.GroupedToolBarBuilder;

import org.junit.Test;

public class GroupedToolBarBuilderTest {

  @Test
  public void buttonIsCreatedForAction() throws Exception {
    final Action action = createNiceMock(Action.class);
    replay(action);
    final JToolBar actualToolBar = new GroupedToolBarBuilder().add("eins", action).createToolBar(); //$NON-NLS-1$
    assertThat(actualToolBar.getComponentCount(), is(1));
    assertThat(actualToolBar.getComponent(0), is(instanceOf(JButton.class)));
    assertThat(((JButton) actualToolBar.getComponent(0)).getAction(), is(action));
    verify(action);
  }

  @Test
  public void twoItemsForSameGroup() throws Exception {
    final Action action1 = createNiceMock(Action.class);
    final Action action2 = createNiceMock(Action.class);
    replay(action1, action2);
    final JToolBar actualToolBar = new GroupedToolBarBuilder()
        .add("eins", action1).add("eins", action2).createToolBar(); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat(actualToolBar.getComponentCount(), is(2));
    assertThat(actualToolBar.getComponent(0), is(instanceOf(JButton.class)));
    assertThat(actualToolBar.getComponent(1), is(instanceOf(JButton.class)));
    verify(action1, action2);
  }

  @Test
  public void differentGroupsSeparated() throws Exception {
    final Action action1 = createNiceMock(Action.class);
    final Action action2 = createNiceMock(Action.class);
    replay(action1, action2);
    final JToolBar actualToolBar = new GroupedToolBarBuilder()
        .add("eins", action1).add("zwei", action2).createToolBar(); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat(actualToolBar.getComponentCount(), is(3));
    assertThat(actualToolBar.getComponent(0), is(instanceOf(JButton.class)));
    assertThat(actualToolBar.getComponent(1), is(instanceOf(VerticalLine.class)));
    assertThat(actualToolBar.getComponent(2), is(instanceOf(JButton.class)));
    verify(action1, action2);
  }

  @Test
  public void itemsForExistingGroupAddedAtLastIndexOfGroupNotToolBar() throws Exception {
    final Action action1 = createNiceMock(Action.class);
    final Action action2 = createNiceMock(Action.class);
    final Action action3 = createNiceMock(Action.class);
    replay(action1, action2, action3);
    final JToolBar actualToolBar = new GroupedToolBarBuilder()
        .add("eins", action1).add("zwei", action2).add("eins", action3).createToolBar(); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    assertThat(actualToolBar.getComponentCount(), is(4));
    assertThat(actualToolBar.getComponent(0), is(instanceOf(JButton.class)));
    assertThat(((JButton) actualToolBar.getComponent(0)).getAction(), is(action1));
    assertThat(actualToolBar.getComponent(1), is(instanceOf(JButton.class)));
    assertThat(((JButton) actualToolBar.getComponent(1)).getAction(), is(action3));
    assertThat(actualToolBar.getComponent(2), is(instanceOf(VerticalLine.class)));
    assertThat(actualToolBar.getComponent(3), is(instanceOf(JButton.class)));
    assertThat(((JButton) actualToolBar.getComponent(3)).getAction(), is(action2));
    verify(action1, action2, action3);
  }
}