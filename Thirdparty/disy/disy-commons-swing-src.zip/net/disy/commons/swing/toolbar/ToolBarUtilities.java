/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.SwingConstants;

import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.component.VerticalLine;
import net.disy.commons.swing.layout.util.LayoutDirection;
import net.disy.commons.swing.widgets.HorizontalLine;

public class ToolBarUtilities {

  public static final Insets TOOLBAR_MARGIN = new Insets(1, 1, 1, 1);
  private static final Insets TOOLBAR_BUTTON_MARGIN = new Insets(1, 1, 1, 1);

  public static AbstractButton createToolBarButton(final Action action) {
    return createToolBarButton(action, new DefaultToolBarButtonConfiguration());
  }

  public static AbstractButton createToolBarButton(
      final Action action,
      final IToolBarButtonConfiguration configuration) {
    final AbstractButton button;
    if (action instanceof SmartToggleAction) {
      button = ActionWidgetFactory.createToggleButton((SmartToggleAction) action);
    }
    else {
      button = new JButton();
    }
    button.setAction(action);
    configureToolBarButton(button, configuration);
    return button;
  }

  public static void configureToolBarButton(final AbstractButton button) {
    configureToolBarButton(button, new DefaultToolBarButtonConfiguration());
  }

  public static void configureToolBarButton(
      final AbstractButton button,
      final IToolBarButtonConfiguration configuration) {
    button.setFocusPainted(configuration.isFocusPainted());
    button.setMargin(TOOLBAR_BUTTON_MARGIN);

    if (button.getToolTipText() == null) {
      button.setToolTipText(button.getText());
    }
    if (button.getIcon() != null) {
      button.setText(null);
    }
  }

  public static JToolBar createEmptyToolBar() {
    return createEmptyToolBar(LayoutDirection.HORIZONTAL);
  }

  public static JToolBar createEmptyToolBar(final IToolBarConfiguration configuration) {
    final JToolBar toolBar = createEmptyToolBar(configuration.getOrientation());
    toolBar.setFloatable(configuration.isFloatable());
    toolBar.setRollover(configuration.isRolloverEffectEnabled());
    return toolBar;
  }

  public static JToolBar createEmptyToolBar(final LayoutDirection orientation) {
    final int swingOrientation = getSwingConstant(orientation);
    final JToolBar toolBar = new JToolBar(swingOrientation) {
      @Override
      public Component add(final Component c) {
        if (c instanceof JToolBar) {
          final JToolBar addedToolBar = (JToolBar) c;
          addedToolBar.setBorder(BorderFactory.createEmptyBorder());
          addedToolBar.setMargin(new Insets(0, 0, 0, 0));
          addedToolBar.putClientProperty("Plastic.is3D", Boolean.valueOf(false)); //$NON-NLS-1$
          addedToolBar.setOpaque(false);
        }
        return super.add(c);
      }

      @Override
      public void addSeparator() {
        switch (orientation) {
          case HORIZONTAL:
            super.add(new VerticalLine());
            return;
          case VERTICAL:
            super.add(new HorizontalLine());
            return;
          default:
            throw new RuntimeException("Unsupported orientation " + orientation); //$NON-NLS-1$
        }
      }
    };
    //Don't use Toolbar's original layout: It does not lay out the panel correctly when we add a button later
    if (orientation == LayoutDirection.HORIZONTAL) {
      toolBar.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
    }

    setToolBarProperties(toolBar);

    return toolBar;
  }

  private static int getSwingConstant(final LayoutDirection orientation) {
    switch (orientation) {
      case HORIZONTAL:
        return SwingConstants.HORIZONTAL;
      case VERTICAL:
        return SwingConstants.VERTICAL;
      default:
        throw new RuntimeException("Unsupported orientation " + orientation); //$NON-NLS-1$
    }
  }

  public static void setToolBarProperties(final JToolBar toolBar) {
    toolBar.setFloatable(false);
    toolBar.setOpaque(false);
    toolBar.setMargin(TOOLBAR_MARGIN);
    toolBar.setRollover(true);
  }

  public static void addToolBarButton(final JToolBar toolBar, final Action action) {
    toolBar.add(createToolBarButton(action));
  }
}