//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.toolbar;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Insets;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JToolBar;

import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.IToggleAction;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.button.ToggleActionButton;
import net.disy.commons.swing.component.VerticalLine;

// NOT_PUBLISHED
public class ToolBarUtilities {

  public static final Insets TOOLBAR_MARGIN = new Insets(1, 1, 1, 1);
  private static final Insets TOOLBAR_BUTTON_MARGIN = new Insets(1, 1, 1, 1);

  public static AbstractButton createToolBarButton(Action action) {
    final AbstractButton button;
    if (action instanceof SmartToggleAction) {
      button = ActionWidgetFactory.createToggleButton((SmartToggleAction) action);
    }
    else if (action instanceof IToggleAction) {
      button = new ToggleActionButton();
    }
    else {
      button = new JButton();
    }
    button.setAction(action);
    configureToolBarButton(button);
    return button;
  }

  public static void configureToolBarButton(AbstractButton button) {
    button.setFocusPainted(false);
    button.setMargin(TOOLBAR_BUTTON_MARGIN);

    if (button.getToolTipText() == null) {
      button.setToolTipText(button.getText());
    }
    if (button.getIcon() != null) {
      button.setText(null);
    }
  }

  public static JToolBar createEmptyToolBar() {
    JToolBar toolBar = new JToolBar() {
      @Override
      public Component add(Component c) {
        if (c instanceof JToolBar) {
          JToolBar addedToolBar = (JToolBar) c;
          addedToolBar.setBorder(BorderFactory.createEmptyBorder());
          addedToolBar.setMargin(new Insets(0, 0, 0, 0));
          addedToolBar.putClientProperty("Plastic.is3D", Boolean.valueOf(false)); //$NON-NLS-1$
          addedToolBar.setOpaque(false);
        }
        return super.add(c);
      }

      @Override
      public void addSeparator() {
        super.add(new VerticalLine());
      }
    };
    //Don't use Toolbar's original layout: It does not lay out the panel correctly when we add a button later 
    toolBar.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));

    setToolBarProperties(toolBar);

    return toolBar;
  }

  public static void setToolBarProperties(JToolBar toolBar) {
    toolBar.setFloatable(false);
    toolBar.setOpaque(false);
    toolBar.setMargin(TOOLBAR_MARGIN);
    //toolBar.setRollover(true); // erst ab JDK 1.4
    toolBar.putClientProperty("JToolBar.isRollover", Boolean.TRUE); //$NON-NLS-1$
    //toolBar.putClientProperty("Plastic.is3D", Boolean.valueOf(is3D)); //$NON-NLS-1$
  }

  public static void addToolBarButton(JToolBar toolBar, Action action) {
    toolBar.add(createToolBarButton(action));
  }

}
