//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.toolbar;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JToolBar;

// NOT_PUBLISHED
public class ToolBarBuilder {

  private JToolBar toolBar = ToolBarUtilities.createEmptyToolBar();

  public ToolBarBuilder() {
    // nothing to do
  }
  
  public ToolBarBuilder(boolean floatable) {
    toolBar.setFloatable(floatable);
  }

  public void add(Action action) {
    ToolBarUtilities.addToolBarButton(toolBar, action);
  }

  public void add(Action action, String tooltip) {
    AbstractButton button = ToolBarUtilities.createToolBarButton(action);
    button.setToolTipText(tooltip);
    toolBar.add(button);
  }

  public void add(Action[] actions) {
    for (int i = 0; i < actions.length; i++) {
      add(actions[i]);
    }
  }

  public void add(Component component) {
    if (component instanceof AbstractButton) {
      ToolBarUtilities.configureToolBarButton((AbstractButton) component);
    }
    toolBar.add(component);
  }

  public void add(Component[] components) {
    for (int i = 0; i < components.length; i++) {
      add(components[i]);
    }
  }

  public void addSeparator() {
    toolBar.addSeparator();
  }

  public void addSeparator(Dimension size) {
    toolBar.addSeparator(size);
  }

  public JToolBar getToolBar() {
    return toolBar;
  }

}