/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JToolBar;

public class ToolBarBuilder {

  private final JToolBar toolBar;

  public ToolBarBuilder() {
    this(new ToolBarConfiguration());
  }

  public ToolBarBuilder(final boolean floatable) {
    this(new ToolBarConfiguration(floatable));
  }

  /** @deprecated As of 18.04.2009 (Markus Gebhard), replaced by {@link #ToolBarBuilder(IToolBarConfiguration)}.
   * Only the builder should know what component to build. */
  @Deprecated
  public ToolBarBuilder(final JToolBar toolbar) {
    this.toolBar = toolbar;
  }

  public ToolBarBuilder(final IToolBarConfiguration configuration) {
    this(ToolBarUtilities.createEmptyToolBar(configuration));
  }

  public ToolBarBuilder add(final Action action) {
    ToolBarUtilities.addToolBarButton(toolBar, action);
    return this;
  }

  public ToolBarBuilder add(final Action[] actions) {
    for (int i = 0; i < actions.length; i++) {
      add(actions[i]);
    }
    return this;
  }

  public ToolBarBuilder add(final Component... components) {
    for (final Component component : components) {
      if (component instanceof AbstractButton) {
        ToolBarUtilities.configureToolBarButton((AbstractButton) component);
      }
      toolBar.add(component);
    }
    return this;
  }

  public ToolBarBuilder add(final IToolBarItem item) {
    item.addTo(this);
    return this;
  }

  public ToolBarBuilder addSeparator() {
    toolBar.addSeparator();
    return this;
  }

  public ToolBarBuilder addSeparator(final Dimension size) {
    toolBar.addSeparator(size);
    return this;
  }

  /** @deprecated As of 18.04.2009 (Markus Gebhard), replaced by {@link #createToolBar()} */
  @Deprecated
  public JToolBar getToolBar() {
    return toolBar;
  }

  public JToolBar createToolBar() {
    return toolBar;
  }
}