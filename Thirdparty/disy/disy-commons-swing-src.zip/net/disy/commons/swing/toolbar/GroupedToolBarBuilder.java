/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JToolBar;

import net.disy.commons.core.grouped.IGroupedItem;
import net.disy.commons.core.grouped.IStructuredItemAddable;
import net.disy.commons.core.grouped.SeparatorGroupItemStructureBuilder;
import net.disy.commons.core.util.Ensure;

public class GroupedToolBarBuilder implements IGroupedActionContainer {

  private final SeparatorGroupItemStructureBuilder<String, AbstractButton> structureBuilder = new SeparatorGroupItemStructureBuilder<String, AbstractButton>();
  private final IToolBarConfiguration configuration;

  public GroupedToolBarBuilder() {
    this(new ToolBarConfiguration());
  }

  public GroupedToolBarBuilder(final IToolBarConfiguration configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
  }

  @Override
  public IGroupedActionContainer add(IGroupedItem<String, Action> item) {
    add(item.getGroupId(), item.getItem());
    return this;
  }

  @Override
  public GroupedToolBarBuilder add(final String groupId, final Action action) {
    add(groupId, ToolBarUtilities.createToolBarButton(action));
    return this;
  }

  @Override
  public IGroupedActionContainer add(final String groupId, final AbstractButton button) {
    structureBuilder.add(groupId, button);
    return this;
  }

  /** @deprecated As of 21.04.2009 (Markus Gebhard), replaced by {@link #createToolBar()} */
  @Deprecated
  public JToolBar getToolBar() {
    return createToolBar();
  }

  public JToolBar createToolBar() {
    final JToolBar toolBar = ToolBarUtilities.createEmptyToolBar(configuration);
    structureBuilder.addAllItemsTo(new IStructuredItemAddable<AbstractButton>() {
      @Override
      public void add(final AbstractButton item) {
        toolBar.add(item);
      }

      @Override
      public void addSeparator() {
        toolBar.addSeparator();
      }
    });
    return toolBar;
  }
}