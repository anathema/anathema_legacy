package net.disy.commons.swing.toolbar;

import javax.swing.AbstractButton;
import javax.swing.Action;

import net.disy.commons.core.grouped.IGroupedItem;

public interface IGroupedActionContainer {

  public IGroupedActionContainer add(IGroupedItem<String, Action> item);

  public IGroupedActionContainer add(String groupId, Action action);

  public IGroupedActionContainer add(String groupId, AbstractButton button);
}