/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import javax.swing.Action;

import net.disy.commons.core.grouped.IStructuredItemAddable;

public class ToolbarBuilderActionAddable implements IStructuredItemAddable<Action> {

  private final ToolBarBuilder builder;

  public ToolbarBuilderActionAddable(final ToolBarBuilder builder) {
    this.builder = builder;
  }

  @Override
  public void addSeparator() {
    builder.addSeparator();
  }

  @Override
  public void add(final Action item) {
    builder.add(item);
  }
}