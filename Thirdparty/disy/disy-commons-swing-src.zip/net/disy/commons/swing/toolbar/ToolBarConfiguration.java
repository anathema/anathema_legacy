/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.layout.util.LayoutDirection;

public class ToolBarConfiguration implements IToolBarConfiguration {

  private boolean floatable;
  private LayoutDirection orientation;
  private boolean rolloverEffectEnabled = true;

  public ToolBarConfiguration() {
    this(false);
  }

  public ToolBarConfiguration(final boolean floatable) {
    this(LayoutDirection.HORIZONTAL, floatable);
  }

  public ToolBarConfiguration(final LayoutDirection orientation, final boolean floatable) {
    Ensure.ensureArgumentNotNull(orientation);
    this.orientation = orientation;
    this.floatable = floatable;
  }

  @Override
  public boolean isFloatable() {
    return floatable;
  }

  public ToolBarConfiguration setFloatable(final boolean floatable) {
    this.floatable = floatable;
    return this;
  }

  @Override
  public LayoutDirection getOrientation() {
    return orientation;
  }

  public ToolBarConfiguration setOrientation(final LayoutDirection orientation) {
    Ensure.ensureArgumentNotNull(orientation);
    this.orientation = orientation;
    return this;
  }

  @Override
  public boolean isRolloverEffectEnabled() {
    return rolloverEffectEnabled;
  }

  public ToolBarConfiguration setRolloverEffectEnabled(final boolean rolloverEffectEnabled) {
    this.rolloverEffectEnabled = rolloverEffectEnabled;
    return this;
  }
}