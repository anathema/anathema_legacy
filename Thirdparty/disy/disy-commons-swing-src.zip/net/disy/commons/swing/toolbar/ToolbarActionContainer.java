/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import javax.swing.AbstractButton;
import javax.swing.Action;

import net.disy.commons.core.grouped.IGroupedItem;

public class ToolbarActionContainer implements IGroupedActionContainer {

  private final ToolBarBuilder builder;

  public ToolbarActionContainer(ToolBarBuilder builder) {
    this.builder = builder;
  }

  @Override
  public IGroupedActionContainer add(IGroupedItem<String, Action> item) {
    builder.add(item.getItem());
    return this;
  }

  @Override
  public IGroupedActionContainer add(String groupId, Action action) {
    builder.add(action);
    return this;
  }

  @Override
  public IGroupedActionContainer add(String groupId, AbstractButton button) {
    builder.add(button);
    return this;
  }
}