/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar.test;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import javax.swing.AbstractButton;
import javax.swing.Action;

import net.disy.commons.core.grouped.IGroupedItem;
import net.disy.commons.swing.toolbar.IGroupedActionContainer;
import net.disy.commons.swing.toolbar.ToolBarBuilder;
import net.disy.commons.swing.toolbar.ToolbarActionContainer;

import org.junit.Test;

@SuppressWarnings({ "nls", "unchecked" })
public class ToolbarActionContainer_Test {
  private final ToolBarBuilder mock = mock(ToolBarBuilder.class);
  private final IGroupedActionContainer builder = new ToolbarActionContainer(mock);

  @Test
  public void returnsSelfAfterAdditionOfItem() throws Exception {
    IGroupedItem<String, Action> item = mock(IGroupedItem.class);
    IGroupedActionContainer container = builder.add(item);
    assertThat(container, is(sameInstance(builder)));
  }

  @Test
  public void returnsSelfAfterAdditionOfAction() throws Exception {
    Action item = mock(Action.class);
    IGroupedActionContainer container = builder.add("x", item);
    assertThat(container, is(sameInstance(builder)));
  }

  @Test
  public void returnsSelfAfterAdditionOfButton() throws Exception {
    AbstractButton item = mock(AbstractButton.class);
    IGroupedActionContainer container = builder.add("x", item);
    assertThat(container, is(sameInstance(builder)));
  }

  @Test
  public void addsActionFromItemToBuilder() throws Exception {
    IGroupedItem<String, Action> item = mock(IGroupedItem.class);
    Action action = mock(Action.class);
    when(item.getItem()).thenReturn(action);
    builder.add(item);
    verify(mock).add(action);
  }

  @Test
  public void addsActionToBuilder() throws Exception {
    Action item = mock(Action.class);
    builder.add("x", item);
    verify(mock).add(item);
  }

  @Test
  public void addsButtonToBuilder() throws Exception {
    AbstractButton item = mock(AbstractButton.class);
    builder.add("x", item);
    verify(mock).add(item);
  }
}