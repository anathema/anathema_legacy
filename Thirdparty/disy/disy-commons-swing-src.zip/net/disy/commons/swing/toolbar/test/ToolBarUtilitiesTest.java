/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar.test;

import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.awt.Component;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JToggleButton;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.toolbar.ToolBarUtilities;

import org.junit.Test;

public class ToolBarUtilitiesTest {

  @Test
  public void testCreatesToggleButtonForSmartToggleAction() {
    final AbstractButton button = ToolBarUtilities.createToolBarButton(new SmartToggleAction(
        new BooleanModel()));
    assertThat(button, is(instanceOf(JToggleButton.class)));
  }

  @Test
  public void testCreatesJButtonForSmartAction() {
    final AbstractButton button = ToolBarUtilities.createToolBarButton(new SmartAction() {
      @Override
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    });
    assertThat(button, is(instanceOf(JButton.class)));
  }
}