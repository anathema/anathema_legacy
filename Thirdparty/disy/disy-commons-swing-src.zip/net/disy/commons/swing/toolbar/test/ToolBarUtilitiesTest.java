//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.toolbar.test;

import java.awt.Component;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JToggleButton;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.toolbar.ToolBarUtilities;

// NOT_PUBLISHED
public class ToolBarUtilitiesTest extends CoreTestCase {

  public void testCreatesToggleButtonForSmartToggleAction() {
    AbstractButton button = ToolBarUtilities.createToolBarButton(new SmartToggleAction(
        new BooleanModel()));
    assertIsInstanceOf(JToggleButton.class, button);
  }

  public void testCreatesJButtonForSmartAction() {
    AbstractButton button = ToolBarUtilities.createToolBarButton(new SmartAction() {
      protected void execute(Component parentComponent) {
        throw new UnsupportedOperationException();
      }
    });
    assertIsInstanceOf(JButton.class, button);
  }
}