/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.toolbar;

import javax.swing.Action;
import javax.swing.JComponent;

import net.disy.commons.core.grouped.IGroupHandler;
import net.disy.commons.core.grouped.SeparatorGroupItemStructureBuilder;

public class ToolBarGroupItemStructureBuilder<G>
    extends
    SeparatorGroupItemStructureBuilder<G, IToolBarItem> {
  public ToolBarGroupItemStructureBuilder() {
    super();
  }

  public ToolBarGroupItemStructureBuilder(final IGroupHandler<G> groupHandler) {
    super(groupHandler);
  }

  public void add(final G groupId, final Action action) {
    add(groupId, new ActionToolBarItem(action));
  }

  public void add(final G groupId, final JComponent component) {
    add(groupId, new ComponentToolBarItem(component));
  }
}