/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dispose;

import java.beans.PropertyChangeListener;

import net.disy.commons.swing.events.IPropertyControl;

public class PropertyDisposable implements IDisposable {

  private final IPropertyControl properties;
  private final PropertyChangeListener listener;

  public PropertyDisposable(IPropertyControl properties, PropertyChangeListener listener) {
    this.properties = properties;
    this.listener = listener;
  }

  @Override
  public void dispose() {
    properties.removePropertyChangeListener(listener);
  }
}