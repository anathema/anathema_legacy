/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dispose;

import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;

public class ChangableModelListenerDisposable implements IDisposable {

  private final IChangeableModel model;
  private final IChangeListener listener;

  public ChangableModelListenerDisposable(IChangeableModel model, IChangeListener listener) {
    this.model = model;
    this.listener = listener;
  }

  @Override
  public void dispose() {
    model.removeChangeListener(listener);
  }
}