//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.ui;

import javax.swing.Icon;


// NOT_PUBLISHED
public class DefaultObjectUi implements IObjectUi {

  public Icon getIcon(Object value) {
    return null;
  }

  public String getLabel(Object value) {
    if (value == null) {
      return null;
    }
    return value.toString();
  }
}