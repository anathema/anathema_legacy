/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractObjectUiDemoCase<T> extends SwingDemoCase {

  protected final void show(final IObjectUi<T> objectUi, final T... values) {
    final JComboBox list = new JComboBox(values);
    list.setRenderer(new ObjectUiListCellRenderer(objectUi));
    final JScrollPane scrollPane = new JScrollPane(list);
    final JPanel panel = new JPanel(new BorderLayout());
    final JCheckBox enabledCheckbox = new JCheckBox("enabled"); //$NON-NLS-1$
    enabledCheckbox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        list.setEnabled(enabledCheckbox.isSelected());
      }
    });
    enabledCheckbox.setSelected(true);
    panel.add(enabledCheckbox, BorderLayout.NORTH);
    panel.add(scrollPane, BorderLayout.CENTER);
    show(panel);
  }

}