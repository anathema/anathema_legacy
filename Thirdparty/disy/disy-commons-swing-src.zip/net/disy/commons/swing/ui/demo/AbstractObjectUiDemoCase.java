//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.ui.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public abstract class AbstractObjectUiDemoCase extends SwingDemoCase {

  protected final void show(Object[] values, IObjectUi objectUi) {
    final JComboBox list = new JComboBox(values);
    list.setRenderer(new ObjectUiListCellRenderer(objectUi));
    JScrollPane scrollPane = new JScrollPane(list);
    JPanel panel = new JPanel(new BorderLayout());
    final JCheckBox enabledCheckbox = new JCheckBox("enabled"); //$NON-NLS-1$
    enabledCheckbox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        list.setEnabled(enabledCheckbox.isSelected());
      }
    });
    enabledCheckbox.setSelected(true);
    panel.add(enabledCheckbox, BorderLayout.NORTH);
    panel.add(scrollPane, BorderLayout.CENTER);
    show(panel);
  }

}