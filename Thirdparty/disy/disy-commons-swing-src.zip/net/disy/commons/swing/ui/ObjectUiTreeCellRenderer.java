/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;

public class ObjectUiTreeCellRenderer extends DefaultTreeCellRenderer {
  private final IObjectUi objectUi;

  public ObjectUiTreeCellRenderer(final IObjectUi objectUi) {
    Ensure.ensureArgumentNotNull(objectUi);
    this.objectUi = objectUi;
  }

  @Override
  public Component getTreeCellRendererComponent(
      final JTree tree,
      final Object value,
      final boolean isSelected,
      final boolean expanded,
      final boolean leaf,
      final int row,
      final boolean hasFocus) {
    super.getTreeCellRendererComponent(tree, value, isSelected, expanded, leaf, row, hasFocus);
    final Icon icon = objectUi.getIcon(value);
    if (icon != null) {
      setIcon(icon);
    }
    setText(objectUi.getLabel(value));
    final String toolTipText = objectUi.getToolTipText(value);
    setToolTipText(StringUtilities.isNullOrEmpty(toolTipText) ? null : toolTipText);
    return this;
  }
}