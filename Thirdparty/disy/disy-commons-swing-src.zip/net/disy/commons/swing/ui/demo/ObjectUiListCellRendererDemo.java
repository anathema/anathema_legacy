/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui.demo;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JList;

import net.disy.commons.swing.ui.ObjectUiListCellRenderer;
import net.disy.commons.swing.ui.ToStringUi;

public final class ObjectUiListCellRendererDemo extends AbstractObjectUiDemoCase<String> {

  private DefaultComboBoxModel getComboBoxModel() {
    final String[] values = new String[]{ "", "test", "Text" };
    return new DefaultComboBoxModel(values);
  }

  public void demo() throws Exception {
    final JList combobox = new JList(getComboBoxModel());
    combobox.setCellRenderer(new ObjectUiListCellRenderer(new ToStringUi<Object>()));
    show(combobox);
  }
}