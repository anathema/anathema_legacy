/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui;

import javax.swing.Icon;

import net.disy.commons.core.util.Ensure;

public abstract class DelegatingObjectUi<T, U> extends AbstractObjectUi<T> {
  private final IObjectUi<U> delegate;

  public DelegatingObjectUi(final IObjectUi<U> delegate) {
    Ensure.ensureArgumentNotNull(delegate);
    this.delegate = delegate;
  }

  @Override
  public Icon getIcon(final T value) {
    return value == null ? null : delegate.getIcon(getDelegatingValue(value));
  }

  protected abstract U getDelegatingValue(T value);

  @Override
  public String getLabel(final T value) {
    return value == null ? null : delegate.getLabel(getDelegatingValue(value));
  }

  @Override
  public String getToolTipText(final T value) {
    return value == null ? null : delegate.getToolTipText(getDelegatingValue(value));
  }
}