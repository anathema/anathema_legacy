//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.ui.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class ObjectUiDemo extends AbstractObjectUiDemoCase {

  private static final class DemoDotUi implements IObjectUi {
    public String getLabel(Object value) {
      return "label " + value; //$NON-NLS-1$
    }

    public Icon getIcon(Object value) {
      return new Icon() {
        public void paintIcon(Component c, Graphics g, int x, int y) {
          g.setColor(Color.RED);
          g.drawOval(x, y, 10, 10);
        }
    
        public int getIconWidth() {
          return 10;
        }
    
        public int getIconHeight() {
          return 10;
        }
      };
    }
  }

  public void demo() throws Exception {
    show(new String[]{ "1", "2" }, new DemoDotUi());  //$NON-NLS-1$//$NON-NLS-2$
  }

}
