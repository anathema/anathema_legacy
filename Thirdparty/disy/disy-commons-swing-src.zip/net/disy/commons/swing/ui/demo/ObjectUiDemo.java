/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.swing.ui.AbstractObjectUi;

public final class ObjectUiDemo extends AbstractObjectUiDemoCase<String> {

  private static final class DemoDotUi extends AbstractObjectUi<String> {
    @Override
    public String getLabel(final String value) {
      return "label " + value; //$NON-NLS-1$
    }

    @Override
    public Icon getIcon(final String value) {
      return new Icon() {
        @Override
        public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
          g.setColor(Color.RED);
          g.drawOval(x, y, 10, 10);
        }

        @Override
        public int getIconWidth() {
          return 10;
        }

        @Override
        public int getIconHeight() {
          return 10;
        }
      };
    }
  }

  public void demo() throws Exception {
    show(new DemoDotUi(), new String[]{ "1", "2" }); //$NON-NLS-1$//$NON-NLS-2$
  }
}