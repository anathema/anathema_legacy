//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.ui;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ObjectUiTableCellRenderer extends DefaultTableCellRenderer {
  private final IObjectUi objectUi;

  public ObjectUiTableCellRenderer(IObjectUi objectUi) {
    Ensure.ensureArgumentNotNull(objectUi);
    this.objectUi = objectUi;
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    Icon icon = objectUi.getIcon(value);
    setIcon(icon);
    setText(objectUi.getLabel(value));
    return this;
  }

}
