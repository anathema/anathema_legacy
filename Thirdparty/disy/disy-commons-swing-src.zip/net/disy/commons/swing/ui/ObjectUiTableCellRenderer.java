/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.ui;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;

public class ObjectUiTableCellRenderer<T> extends DefaultTableCellRenderer {
  private final IObjectUi<T> objectUi;
  private final int alignment;
  private final boolean showText;

  public ObjectUiTableCellRenderer(final IObjectUi<T> objectUi) {
    this(objectUi, SwingConstants.LEFT, true);
  }

  public ObjectUiTableCellRenderer(
      final IObjectUi<T> objectUi,
      final int alignment,
      final boolean showText) {
    Ensure.ensureArgumentNotNull(objectUi);
    this.objectUi = objectUi;
    this.alignment = alignment;
    this.showText = showText;
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    final T object = getObject(value);
    setIcon(objectUi.getIcon(object));
    setText(showText ? objectUi.getLabel(object) : null);
    final String toolTipText = objectUi.getToolTipText(object);
    setToolTipText(StringUtilities.isNullOrEmpty(toolTipText) ? null : toolTipText);
    setHorizontalAlignment(alignment);
    return this;
  }

  @SuppressWarnings("unchecked")
  protected T getObject(final Object value) {
    return (T) value;
  }

  public IObjectUi<T> getObjectUi() {
    return objectUi;
  }
}