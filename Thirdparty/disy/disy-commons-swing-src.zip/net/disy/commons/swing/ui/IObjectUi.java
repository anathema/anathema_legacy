package net.disy.commons.swing.ui;

import javax.swing.Icon;

/**
 * @author Markus Gebhard
 */
public interface IObjectUi {
 
  public Icon getIcon(Object value);

  public String getLabel(Object value);
  
}