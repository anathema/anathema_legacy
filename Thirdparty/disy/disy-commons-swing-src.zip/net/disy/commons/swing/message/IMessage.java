package net.disy.commons.swing.message;

/**
 * Interface describing message objects that can be shown to the user by using an
 * {@link net.disy.commons.swing.message.IMessageIndicator} object.
 * 
 * @author gebhard
 * @published
 */
public interface IMessage extends IBasicMessage {

  /** 
   * Returns the title of this message, or <code>null</code> if there is none.
   * @published 
   */
  public String getTitle();

  /** 
   * Returns the Throwable object that has caused this message or <code>null</code> if there is
   * none specified.
   * 
   * @published 
   */
  public Throwable getThrowable();

  public String getDetail();

  public String getDetailedText();
}