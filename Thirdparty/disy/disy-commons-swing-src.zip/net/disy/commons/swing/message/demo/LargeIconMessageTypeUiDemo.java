/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.message.demo;

import org.junit.runner.RunWith;

import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.message.LargeIconMessageTypeUi;
import net.disy.commons.swing.ui.demo.AbstractObjectUiDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class LargeIconMessageTypeUiDemo extends AbstractObjectUiDemoCase<MessageType> {

  public void demo() {
    show(new LargeIconMessageTypeUi(), MessageType.getAll());
  }
}