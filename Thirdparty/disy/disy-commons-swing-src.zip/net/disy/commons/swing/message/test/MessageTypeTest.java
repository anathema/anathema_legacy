package net.disy.commons.swing.message.test;

import junit.framework.TestCase;

import net.disy.commons.swing.message.MessageType;

/**
 * @author gebhard
 */
public class MessageTypeTest extends TestCase {

  public void testEquals() {
    assertEquals(MessageType.ERROR, MessageType.ERROR);
    assertEquals(MessageType.WARNING, MessageType.WARNING);
    assertEquals(MessageType.INFORMATION, MessageType.INFORMATION);
    assertEquals(MessageType.NORMAL, MessageType.NORMAL);
  }

  public void testNotEquals() {
    assertFalse(MessageType.ERROR.equals(MessageType.WARNING));
    assertFalse(MessageType.WARNING.equals(MessageType.INFORMATION));
    assertFalse(MessageType.ERROR.equals(MessageType.INFORMATION));
    assertFalse(MessageType.NORMAL.equals(MessageType.ERROR));
  }
}