//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.message.demo;

import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.ui.demo.AbstractObjectUiDemoCase;

// NOT_PUBLISHED
public class MessageTypeUiDemo extends AbstractObjectUiDemoCase {

  public void demo() {
    show(MessageType.getAll(), MessageTypeUi.getInstance());
  }

}