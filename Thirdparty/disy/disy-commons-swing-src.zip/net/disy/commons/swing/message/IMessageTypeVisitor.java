// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.message;
 
/**
 * @author gebhard
 */
public interface IMessageTypeVisitor {

  public void visitError(MessageType type);

  public void visitNormal(MessageType type);

  public void visitWarning(MessageType type);

  public void visitInformation(MessageType type);

}
