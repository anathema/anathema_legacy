package net.disy.commons.swing.message;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.message.IMessageIndicator;
import net.disy.commons.core.message.MessageType;

/**
 * Default implementation for a message that can be shown using an
 * {@link IMessageIndicator}.
 * 
 * @published
 * @deprecated As of 24.10.2005 (gebhard), replaced by {@link net.disy.commons.core.message.Message}
 */
@Deprecated
public class Message extends net.disy.commons.core.message.Message implements IMessage {

  /** 
   * Creates a new Message object using the specified parameters.
   * @published
   */
  public Message(String title, String text, MessageType type, Throwable throwable) {
    super(title, text, type, throwable);
  }

  /**
   * Creates a new error message.
   * @published
   */
  public Message(String title, String text, Throwable throwable) {
    super(title, text, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * @published
   */
  public Message(String title, String text, MessageType type) {
    super(title, text, type);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   * want to use {@link #Message(String, Throwable)} instead.
   */
  public Message(String text, MessageType type, Throwable throwable) {
    super(text, type, throwable);
  }

  /**
   * Creates a new error Message object using the specified parameters.
   * 
   * @published
   */
  public Message(String text, Throwable throwable) {
    super(text, throwable);
  }

  /**
   * Creates a new Message object using the specified parameters.
   * 
   * @published
   */
  public Message(String text, MessageType type) {
    super(text, type);
  }

  public Message(String text, MessageType messageType, String detailText) {
    super(text, messageType, detailText);
  }
}