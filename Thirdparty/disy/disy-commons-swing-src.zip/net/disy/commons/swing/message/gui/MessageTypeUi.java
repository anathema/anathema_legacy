// Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.message.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.SystemColor;

import javax.swing.Icon;

import net.disy.commons.swing.icon.EmptyIcon;
import net.disy.commons.swing.icon.SwingIcons;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.message.IMessageTypeVisitor;
import net.disy.commons.swing.message.MessageType;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

// NOT_PUBLISHED
public class MessageTypeUi {
  public static final Icon errorIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/error.gif"); //$NON-NLS-1$
  public static final Icon warningIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/warning.gif"); //$NON-NLS-1$
  public static final Icon infoIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/info.gif"); //$NON-NLS-1$
  public static final Icon normalIcon = new EmptyIcon(new Dimension(16, 16));

  public static Icon getIcon(MessageType type) {
    final Icon[] icon = new Icon[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        icon[0] = SwingIcons.getOptionPaneErrorIcon();
      }

      public void visitNormal(MessageType visitedType) {
        icon[0] = new EmptyIcon();
      }

      public void visitWarning(MessageType visitedType) {
        icon[0] =SwingIcons.getOptionPaneWarningIcon(); 
      }

      public void visitInformation(MessageType visitedType) {
        icon[0] =  SwingIcons.getOptionPaneInformationIcon();
      }
    });
    return icon[0];
  }

  public static Icon getSmallIcon(MessageType type) {
    final Icon[] icon = new Icon[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        icon[0] = errorIcon;
      }

      public void visitNormal(MessageType visitedType) {
        icon[0] = normalIcon;
      }

      public void visitWarning(MessageType visitedType) {
        icon[0] = warningIcon;
      }

      public void visitInformation(MessageType visitedType) {
        icon[0] = infoIcon;
      }
    });
    return icon[0];
  }

  public static Color getColor(MessageType type) {
    final Color[] color = new Color[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        color[0] = Color.red;
      }

      public void visitNormal(MessageType visitedType) {
        color[0] = SystemColor.textText;
      }

      public void visitWarning(MessageType visitedType) {
        color[0] = SystemColor.textText;
      }

      public void visitInformation(MessageType visitedType) {
        color[0] = SystemColor.textText;
      }
    });
    return color[0];
  }

  public static String getLabel(MessageType type) {
    final String[] label = new String[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitInformation(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.information.label"); //$NON-NLS-1$
      }

      public void visitWarning(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.warning.label"); //$NON-NLS-1$
      }

      public void visitNormal(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.normal.label"); //$NON-NLS-1$
      }

      public void visitError(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.error.label"); //$NON-NLS-1$
      }
    });
    return label[0];
  }

  private MessageTypeUi() {
    //no instance available
  }
}