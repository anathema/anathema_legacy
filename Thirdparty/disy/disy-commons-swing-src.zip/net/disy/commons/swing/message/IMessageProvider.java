// Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.message;

import javax.swing.event.ChangeListener;

//NOT_PUBLISHED
public interface IMessageProvider {

  public IBasicMessage getDefaultMessage();

  public IBasicMessage getCurrentMessage();

  public void addChangeListener(ChangeListener listener);

}
