// Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.message;

import java.awt.Color;

import javax.swing.Icon;

import net.disy.commons.core.message.IMessageTypeVisitor;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.icon.EmptyIcon;
import net.disy.commons.swing.icon.SwingIcons;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class MessageTypeUi implements IObjectUi {
  public static final Icon errorIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/error.gif"); //$NON-NLS-1$
  public static final Icon warningIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/warning.gif"); //$NON-NLS-1$
  public static final Icon infoIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/info.gif"); //$NON-NLS-1$
  public static final Icon normalIcon = EmptyIcon.DEFAULT_ICON;
  public static final Icon questionIcon = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "message/small/question.gif"); //$NON-NLS-1$

  private static MessageTypeUi instance = new MessageTypeUi();

  public static Icon getIcon(MessageType type) {
    final Icon[] icon = new Icon[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        icon[0] = SwingIcons.getOptionPaneErrorIcon();
      }

      public void visitNormal(MessageType visitedType) {
        icon[0] = new EmptyIcon();
      }

      public void visitWarning(MessageType visitedType) {
        icon[0] = SwingIcons.getOptionPaneWarningIcon();
      }

      public void visitInformation(MessageType visitedType) {
        icon[0] = SwingIcons.getOptionPaneInformationIcon();
      }

      public void visitQuestion(MessageType visitedType) {
        icon[0] = SwingIcons.getOptionPaneQuestionIcon();
      }
    });
    return icon[0];
  }

  public static Icon getSmallIcon(MessageType type) {
    final Icon[] icon = new Icon[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        icon[0] = errorIcon;
      }

      public void visitNormal(MessageType visitedType) {
        icon[0] = normalIcon;
      }

      public void visitWarning(MessageType visitedType) {
        icon[0] = warningIcon;
      }

      public void visitInformation(MessageType visitedType) {
        icon[0] = infoIcon;
      }

      public void visitQuestion(MessageType visitedType) {
        icon[0] = questionIcon;
      }
    });
    return icon[0];
  }

  public static Color getColor(MessageType type) {
    final Color[] color = new Color[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitError(MessageType visitedType) {
        color[0] = Color.red;
      }

      public void visitNormal(MessageType visitedType) {
        color[0] = SwingColors.getTextAreaForegroundColor();
      }

      public void visitWarning(MessageType visitedType) {
        color[0] = SwingColors.getTextAreaForegroundColor();
      }

      public void visitInformation(MessageType visitedType) {
        color[0] = SwingColors.getTextAreaForegroundColor();
      }

      public void visitQuestion(MessageType visitedType) {
        color[0] = SwingColors.getTextAreaForegroundColor();
      }
    });
    return color[0];
  }

  public static String getLabel(MessageType type) {
    final String[] label = new String[1];
    type.accept(new IMessageTypeVisitor() {
      public void visitInformation(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.information.label"); //$NON-NLS-1$
      }

      public void visitWarning(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.warning.label"); //$NON-NLS-1$
      }

      public void visitNormal(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.normal.label"); //$NON-NLS-1$
      }

      public void visitError(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.error.label"); //$NON-NLS-1$
      }

      public void visitQuestion(MessageType visitedType) {
        label[0] = DisyCommonsSwingMessages.getString("MessageTypeUi.question.label"); //$NON-NLS-1$
      }
    });
    return label[0];
  }

  private MessageTypeUi() {
    //no instance available
  }

  public static MessageTypeUi getInstance() {
    return instance;
  }

  public Icon getIcon(Object value) {
    return getSmallIcon((MessageType) value);
  }

  public String getLabel(Object value) {
    return getLabel((MessageType) value);
  }
}