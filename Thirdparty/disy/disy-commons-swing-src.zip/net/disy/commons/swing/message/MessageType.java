// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.message;

import net.disy.commons.core.message.IMessageTypeVisitor;

/**
 * Constants for specifying the type of a message object. 
 * @author gebhard
 * @deprecated As of 24.10.2005 (gebhard), replaced by {@link net.disy.commons.core.message.MessageType}
 */
public final class MessageType {

  /** 
   * Message type for error messages.
   * @published
   */
  public final static net.disy.commons.core.message.MessageType ERROR = new net.disy.commons.core.message.MessageType(
      "Fehler", new Integer(4)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitError(this);
    }
  };
  /** 
   * Message type for warning messages. 
   * @published
   */
  public final static net.disy.commons.core.message.MessageType WARNING = new net.disy.commons.core.message.MessageType(
      "Warnung", new Integer(3)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitWarning(this);
    }
  };
  /** 
   * Message type for information messages. 
   * @published
   */
  public final static net.disy.commons.core.message.MessageType INFORMATION = new net.disy.commons.core.message.MessageType(
      "Information", new Integer(2)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitInformation(this);
    }
  };

  /**
   * Message type for normal messages.
   * @published
   */
  public final static net.disy.commons.core.message.MessageType NORMAL = new net.disy.commons.core.message.MessageType(
      "Normal", new Integer(1)) { //$NON-NLS-1$
    public void accept(IMessageTypeVisitor visitor) {
      visitor.visitNormal(this);
    }
  };
}