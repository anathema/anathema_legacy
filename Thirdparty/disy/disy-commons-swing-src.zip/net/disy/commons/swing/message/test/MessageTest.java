package net.disy.commons.swing.message.test;

import java.io.PrintWriter;

import junit.framework.TestCase;

import net.disy.commons.swing.message.IMessage;
import net.disy.commons.swing.message.Message;
import net.disy.commons.swing.message.MessageType;

public class MessageTest extends TestCase {

  public void testNullType() {
    try {
      new Message("title", "message", (MessageType) null); //$NON-NLS-1$ //$NON-NLS-2$
      fail();
    }
    catch (Exception expected) {
      // expcted
    }
  }

  public void testNullTitleIsLegal() {
    new Message(null, "message", MessageType.ERROR); //$NON-NLS-1$
  }

  public void testNullMessage() {
    try {
      new Message("title", null, MessageType.ERROR); //$NON-NLS-1$
      fail();
    }
    catch (Exception expected) {
      // expcted
    }
  }

  public void testConvenienceConstructor() {
    ArrayIndexOutOfBoundsException exception = new ArrayIndexOutOfBoundsException();
    IMessage message = new Message("title", "message", exception); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("title", message.getTitle()); //$NON-NLS-1$
    assertEquals("message", message.getText()); //$NON-NLS-1$
    assertSame(exception, message.getThrowable());
    assertEquals(MessageType.ERROR, message.getType());
  }

  public void testDetailFromThrowable() throws Exception {
    Throwable throwable = new Throwable() {
      public void printStackTrace(PrintWriter s) {
        s.print("stacktrace"); //$NON-NLS-1$
      }
    };
    assertEquals("stacktrace", new Message("text", throwable).getDetail()); //$NON-NLS-1$//$NON-NLS-2$
  }

  public void testDetailText() throws Exception {
    assertEquals("detail", new Message("text", MessageType.NORMAL, "detail").getDetail()); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$
  }

  public void testGetDetailedText() throws Exception {
    assertEquals("text", new Message("text", new Throwable()).getDetailedText()); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("text - detail", new Message("text", MessageType.NORMAL, "detail") //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        .getDetailedText());
  }
}