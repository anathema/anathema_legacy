package net.disy.commons.swing.textfield;

import java.text.NumberFormat;
import java.text.ParseException;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.string.StringFilter;
import net.disy.commons.swing.events.CheckInputValidListener;

/**
 * Ein Textfeld, das der Eingabe von doubles dient
 */
public class DoubleField extends FilteredTextField {

  private final NumberFormat format;

  /**
   * Erzeugt ein DoubleField
   */
  public DoubleField() {
    this(0);
  }

  /**
   * Erzeugt ein DoubleField mit einer Spaltenanzahl
   *
   * @param cols die Anzahl Spalten
   */
  public DoubleField(int cols) {
    this(cols, 0.0);
  }

  public DoubleField(int columnCount, double value) {
    this(columnCount, value, null);
  }

  public DoubleField(int columnCount, double value, NumberFormat format) {
    super(new DoubleFilter(format), getValueText(value, format), columnCount);
    this.format = format;
  }

  /**
   * Holt den Double-Wert
   */
  public double getValue() {
    if (isInvalidContent()) {
      return 0.0;
    }
    try {
      return format != null ? format.parse(getText()).doubleValue() : Double.parseDouble(getText());
    }
    catch (Exception e) {
      throw new UnreachableCodeReachedException(e);
    }
  }

  private boolean isInvalidContent() {
    String text = getText();
    return text.equals("") || text.equals("-"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  /**
   * Setzt den Double-Wert
   *
   * @param value der Double-Wert
   */
  public void setValue(double value) {
    if (getValue() == value) {
      return;
    }
    setText(getValueText(value, format));
  }

  private static String getValueText(double value, NumberFormat numberFormat) {
    return numberFormat != null ? numberFormat.format(value) : String.valueOf(value);
  }

  public static class DoubleFilter implements StringFilter {
    private final NumberFormat format;

    public DoubleFilter(NumberFormat format) {
      this.format = format;
    }

    public boolean acceptFilterText(String text) {
      try {
        if (!text.equals("") && !text.equals("-")) { //$NON-NLS-1$//$NON-NLS-2$
          if (format == null) {
            Double.valueOf(text).doubleValue();
          }
          else {
            format.parse(text);
          }
        }
        return true;
      }
      catch (NumberFormatException e) {
        return false;
      }
      catch (ParseException e) {
        return false;
      }
    }
  }

  public void addCheckInputValidListener(CheckInputValidListener checkInputValidListener) {
    getDocument().addDocumentListener(checkInputValidListener);
  }
}