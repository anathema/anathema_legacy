/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.NumberFormat;
import java.text.ParseException;

import javax.swing.JComponent;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.event.DocumentListener;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.string.StringFilter;
import net.disy.commons.swing.events.ICheckInputValidListener;

public class DoubleField {

  public static DoubleField getDoubleField(final Component component) {
    if (!(component instanceof InternalComponent)) {
      return null;
    }
    return ((InternalComponent) component).doubleField;
  }

  private static class InternalComponent extends FilteredTextField {

    private DoubleField doubleField;

    public InternalComponent(final DoubleFilter doubleFilter, final String valueText, final int columnCount) {
      super(doubleFilter, valueText, columnCount);
    }
  }

  private final NumberFormat format;
  protected final InternalComponent textField;

  /**
   * Erzeugt ein DoubleField
   */
  public DoubleField() {
    this(0);
  }

  /**
   * Erzeugt ein DoubleField mit einer Spaltenanzahl
   *
   * @param cols die Anzahl Spalten
   */
  public DoubleField(final int cols) {
    this(cols, 0.0);
  }

  public DoubleField(final int columnCount, final double value) {
    this(columnCount, value, createDefaultFormat());
  }

  private static NumberFormat createDefaultFormat() {
    NumberFormat format = NumberFormat.getNumberInstance();
    format = (NumberFormat) format.clone();
    format.setMinimumFractionDigits(Math.max(1, format.getMinimumFractionDigits()));
    return format;
  }

  public DoubleField(final int columnCount, final double value, final NumberFormat format) {
    textField = new InternalComponent(new DoubleFilter(format), getValueText(value, format), columnCount);
    textField.setHorizontalAlignment(SwingConstants.RIGHT);
    addFocusListener(new FocusAdapter() {
      @Override
      public void focusLost(final FocusEvent e) {
        setText(getValueText(getValue(), format));
      }
    });
    this.format = format;
    textField.doubleField = this;
  }

  /**
   * Holt den Double-Wert
   */
  public double getValue() {
    if (isInvalidContent()) {
      return 0.0;
    }
    try {
      return format != null ? format.parse(getText()).doubleValue() : Double.parseDouble(getText());
    }
    catch (final Exception e) {
      throw new UnreachableCodeReachedException(e);
    }
  }

  public Double getDoubleValue() {
    return isInvalidContent() ? null : new Double(getValue());
  }

  public boolean isInvalidContent() {
    final String text = getText();
    return text.length() == 0 || text.equals("-"); //$NON-NLS-1$
  }

  private String getText() {
    return textField.getText();
  }

  public void setValue(final double value) {
    if (getValue() == value) {
      return;
    }
    setText(getValueText(value, format));
  }

  public void setValue(final Double value) {
    if (value == null) {
      if (isInvalidContent()) {
        return;
      }
      setText(""); //$NON-NLS-1$
      return;
    }
    if (getValue() == value.doubleValue()) {
      return;
    }
    setText(getValueText(value.doubleValue(), format));
  }

  private void setText(final String text) {
    textField.setText(text);
  }

  private static String getValueText(final double value, final NumberFormat numberFormat) {
    return numberFormat != null ? numberFormat.format(value) : String.valueOf(value);
  }

  public static class DoubleFilter implements StringFilter {
    private final NumberFormat format;

    public DoubleFilter(final NumberFormat format) {
      this.format = format;
    }

    @Override
    public boolean acceptFilterText(final String text) {
      try {
        if (text.length() != 0 && !text.equals("-")) { //$NON-NLS-1$
          if (format == null) {
            Double.valueOf(text).doubleValue();
          }
          else {
            format.parse(text);
          }
        }
        return true;
      }
      catch (final NumberFormatException e) {
        return false;
      }
      catch (final ParseException e) {
        return false;
      }
    }
  }

  public void addCheckInputValidListener(final ICheckInputValidListener listener) {
    addDocumentListener(listener);
  }

  public void setLeftAligned() {
    textField.setHorizontalAlignment(SwingConstants.LEFT);
  }

  public JComponent getContent() {
    return textField;
  }

  public void requestFocus() {
    textField.requestFocus();
  }

  public void addActionListener(final ActionListener actionListener) {
    textField.addActionListener(actionListener);
  }

  public void addFocusListener(final FocusListener focusListener) {
    this.textField.addFocusListener(focusListener);
  }

  public void addDocumentListener(final DocumentListener documentListener) {
    textField.getDocument().addDocumentListener(documentListener);
  }

  public void setForeground(final Color color) {
    textField.setForeground(color);
  }

  public void setBackground(final Color color) {
    textField.setBackground(color);
  }

  public void setBorder(final Border border) {
    textField.setBorder(border);
  }

  public void setEnabled(final boolean enabled) {
    textField.setEditable(enabled);
  }

  public String getFormattedDouble() {
    return textField.getText();
  }

  public void clear() {
    textField.setText(""); //$NON-NLS-1$
  }

  public void selectAll() {
    textField.selectAll();
  }
}