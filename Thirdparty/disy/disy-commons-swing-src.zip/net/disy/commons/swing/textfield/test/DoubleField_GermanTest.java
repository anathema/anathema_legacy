/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

import java.awt.Component;
import java.awt.event.FocusEvent;
import java.lang.reflect.Method;
import java.util.Locale;

import javax.swing.JTextField;

import net.disy.commons.swing.textfield.DoubleField;

import org.junit.Before;
import org.junit.Test;

public class DoubleField_GermanTest {

  private TestDoubleField field;

  private static final class TestDoubleField extends DoubleField {

    public void processFocusEvent(final FocusEvent e) {
      try {
        final Method method = Component.class.getDeclaredMethod("processFocusEvent", //$NON-NLS-1$
            FocusEvent.class);
        method.setAccessible(true);
        method.invoke(textField, e);
      }
      catch (final Throwable throwable) {
        throw new RuntimeException(throwable);
      }
    }
  }

  @Before
  public void setGermanLocale() throws Exception {
    Locale.setDefault(Locale.GERMAN);
    field = new TestDoubleField();
  }

  @Test
  public void testSettingZeroWhenEmpty() {
    assertEquals(0.0, field.getValue(), 0.0);
    field.setValue(0.0);
    assertEquals("0,0", getTextField().getText()); //$NON-NLS-1$
  }

  //Initiale Darstellung muss 0.0 sein, da sonst wechselweise entweder
  // - Nachträgliches Setzen auf 0.0 oder
  // - Löschen des Textfelds mit Model-View
  //nicht klappt. mg,rc
  @Test
  public void defaultsTo0dot0() {
    assertEquals("0,0", getTextField(new DoubleField()).getText()); //$NON-NLS-1$
  }

  @Test
  public void renders1dot1As11() throws Exception {
    getTextField().setText("1.1"); //$NON-NLS-1$
    field.processFocusEvent(new FocusEvent(field.getContent(), FocusEvent.FOCUS_LOST));
    assertThat(field.getValue(), is(11d));
  }

  @Test
  public void rerendersTextContentAfterFocusIsLost() throws Exception {
    getTextField().setText("1.1"); //$NON-NLS-1$
    field.processFocusEvent(new FocusEvent(field.getContent(), FocusEvent.FOCUS_LOST));
    assertThat(getTextField().getText(), is("11,0")); //$NON-NLS-1$
  }

  private JTextField getTextField() {
    return getTextField(field);
  }

  private JTextField getTextField(final DoubleField doubleField) {
    return (JTextField) doubleField.getContent();
  }
}