/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield.test;

import static org.junit.Assert.*;

import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import javax.swing.JTextField;

import net.disy.commons.swing.textfield.DoubleField;

import org.junit.Before;
import org.junit.Test;

public class DoubleField_EnglishTest {

  @Before
  public void setEnglishLocale() throws Exception {
    Locale.setDefault(Locale.ENGLISH);
  }

  @Test
  public void testSettingZeroWhenEmpty() {
    final DoubleField field = new DoubleField();
    assertEquals(0.0, field.getValue(), 0.0);
    field.setValue(0.0);
    assertEquals("0.0", getText(field)); //$NON-NLS-1$
  }

  private String getText(final DoubleField field) {
    return ((JTextField) field.getContent()).getText();
  }

  @Test
  public void testInitialValue() throws Exception {
    assertEquals("1.0", getText(new DoubleField(10, 1.0))); //$NON-NLS-1$
  }

  //Initiale Darstellung muss 0.0 sein, da sonst wechselweise entweder 
  // - Nachträgliches Setzen auf 0.0 oder
  // - Löschen des Textfelds mit Model-View
  //nicht klappt. mg,rc
  @Test
  public void testDefaultValueIs0dot0() {
    assertEquals("0.0", getText(new DoubleField())); //$NON-NLS-1$
  }

  @Test
  public void testNumberFormat() throws Exception {
    final DoubleField field = new DoubleField(10, 1.0, new DecimalFormat(
        "#.00", new DecimalFormatSymbols(Locale.ENGLISH))); //$NON-NLS-1$
    assertEquals("1.00", getText(field)); //$NON-NLS-1$
  }
}