/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield;

import javax.swing.JComponent;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;

public class DoubleModelTextField implements IComponentContainer {

  private final ObjectModel<Double> model;
  private final DoubleField doubleField;

  public DoubleModelTextField(final int columnCount, final ObjectModel<Double> model) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    this.doubleField = new DoubleField(columnCount);
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateDoubleField();
      }
    });
    updateDoubleField();
    doubleField.addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        model.setValue(doubleField.getDoubleValue());
      }
    });
  }

  private void updateDoubleField() {
    final Double value = model.getValue();
    doubleField.setValue(value);
  }

  @Override
  public JComponent getContent() {
    return doubleField.getContent();
  }

  public void requestFocus() {
    doubleField.requestFocus();
  }

  public void setEnabled(final boolean enabled) {
    doubleField.setEnabled(enabled);
  }
}