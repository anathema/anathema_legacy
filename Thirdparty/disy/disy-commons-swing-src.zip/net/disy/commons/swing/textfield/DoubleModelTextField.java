//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.textfield;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;

// NOT_PUBLISHED
public class DoubleModelTextField implements IComponentContainer {

  private final ObjectModel<Double> model;
  private final DoubleField doubleField;

  public DoubleModelTextField(int columnCount, final ObjectModel<Double> model) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    this.doubleField = new DoubleField(columnCount);
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateDoubleField();
      }
    });
    updateDoubleField();
    doubleField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        model.setValue(doubleField.getDoubleValue());
      }
    });
  }

  private void updateDoubleField() {
    Double value = model.getValue();
    doubleField.setValue(value);
  }

  public JComponent getContent() {
    return doubleField;
  }
}