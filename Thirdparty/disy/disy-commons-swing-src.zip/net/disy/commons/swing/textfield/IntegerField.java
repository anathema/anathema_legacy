/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield;

import javax.swing.SwingConstants;

import net.disy.commons.core.string.StringFilter;

/** @deprecated As of 28.10.2005 (gebhard), replaced by {@link javax.swing.JSpinner} */
@Deprecated
public class IntegerField extends FilteredTextField {

  public IntegerField() {
    this(0);
  }

  public IntegerField(final int columnCount) {
    super(new IntegerFilter(), columnCount);
    setHorizontalAlignment(SwingConstants.RIGHT);
  }

  public IntegerField(final int value, final int columnCount) {
    super(new IntegerFilter(), String.valueOf(value), columnCount);
    setHorizontalAlignment(SwingConstants.RIGHT);
  }

  public int getInt() {
    final String text = getText();
    if (isEmpty(text)) {
      return 0;
    }
    return Integer.parseInt(text);
  }

  private static boolean isEmpty(final String text) {
    return text.equals("") || text.equals("-"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void setInt(final int value) {
    setText(String.valueOf(value));
  }

  public static class IntegerFilter implements StringFilter {
    @Override
    public boolean acceptFilterText(final String text) {
      try {
        if (!isEmpty(text)) {
          Integer.valueOf(text).intValue();
        }
        return true;
      }
      catch (final NumberFormatException e) {
        return false;
      }
    }
  }
}