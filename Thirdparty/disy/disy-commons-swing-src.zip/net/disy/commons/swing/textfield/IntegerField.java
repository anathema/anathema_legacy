package net.disy.commons.swing.textfield;


import net.disy.commons.core.string.StringFilter;

/** @deprecated As of 28.10.2005 (gebhard), replaced by {@link javax.swing.JSpinner} */
public class IntegerField extends FilteredTextField {

  public IntegerField() {
    this(0);
  }

  public IntegerField(int columnCount) {
    super(new IntegerFilter(), columnCount);
  }

  public IntegerField(int value, int columnCount) {
    super(new IntegerFilter(), String.valueOf(value), columnCount);
  }

  public int getInt() {
    String text = getText();
    if (isEmpty(text)) {
      return 0;
    }
    return Integer.parseInt(text);
  }

  private static boolean isEmpty(String text) {
    return text.equals("") || text.equals("-"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void setInt(int value) {
    setText(String.valueOf(value));
  }

  public static class IntegerFilter implements StringFilter {
    public boolean acceptFilterText(String text) {
      try {
        if (!isEmpty(text)) {
          Integer.valueOf(text).intValue();
        }
        return true;
      }
      catch (NumberFormatException e) {
        return false;
      }
    }
  }
}