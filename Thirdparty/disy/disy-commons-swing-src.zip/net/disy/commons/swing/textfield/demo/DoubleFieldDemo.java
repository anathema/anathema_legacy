/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield.demo;

import java.util.Locale;

import net.disy.commons.swing.textfield.DoubleField;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class DoubleFieldDemo extends SwingDemoCase {

  @Demo
  public void demoWithoutNumberFormatAndGermanLocale() {
    Locale.setDefault(Locale.GERMANY);
    show(new DoubleField().getContent());
  }

  @Demo
  public void demoWithoutNumberFormatAndEnglishLocale() {
    Locale.setDefault(Locale.ENGLISH);
    show(new DoubleField().getContent());
  }
}