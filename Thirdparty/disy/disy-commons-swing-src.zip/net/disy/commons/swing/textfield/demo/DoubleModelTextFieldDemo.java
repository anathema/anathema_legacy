/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield.demo;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JPanel;

import org.junit.runner.RunWith;

import net.disy.commons.core.model.listener.IChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.textfield.DoubleModelTextField;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class DoubleModelTextFieldDemo extends SwingDemoCase {

  public void demo() {
    final ObjectModel<Double> model = new ObjectModel<Double>();

    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JLabel("DoubleModelTextField:")); //$NON-NLS-1$
    panel.add(new DoubleModelTextField(12, model).getContent());
    panel.add(new JLabel("DoubleModelLabel:")); //$NON-NLS-1$
    panel.add(new DoubleModelLabel(model).getContent());
    show(panel);
  }

  private class DoubleModelLabel {
    private final JLabel label;

    public DoubleModelLabel(final ObjectModel<Double> model) {
      label = new JLabel();
      model.addChangeListener(new IChangeListener() {
        @Override
        public void stateChanged() {
          updateLabel(model);
        }
      });
      updateLabel(model);
    }

    public Component getContent() {
      return label;
    }

    private void updateLabel(final ObjectModel<Double> model) {
      label.setText(String.valueOf(model.getValue()));
    }
  }
}