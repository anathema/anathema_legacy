//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.textfield.demo;

import java.awt.Component;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.textfield.DoubleModelTextField;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class DoubleModelTextFieldDemo extends SwingDemoCase {

  public void demo() {
    final ObjectModel<Double> model = new ObjectModel<Double>();

    JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JLabel("DoubleModelTextField:")); //$NON-NLS-1$
    panel.add(new DoubleModelTextField(12, model).getContent());
    panel.add(new JLabel("DoubleModelLabel:")); //$NON-NLS-1$
    panel.add(new DoubleModelLabel(model).getContent());
    show(panel);
  }

  private class DoubleModelLabel {
    private final JLabel label;

    public DoubleModelLabel(final ObjectModel<Double> model) {
      label = new JLabel();
      model.addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          updateLabel(model);
        }
      });
      updateLabel(model);
    }

    public Component getContent() {
      return label;
    }

    private void updateLabel(ObjectModel<Double> model) {
      label.setText(String.valueOf(model.getValue()));
    }
  }
}