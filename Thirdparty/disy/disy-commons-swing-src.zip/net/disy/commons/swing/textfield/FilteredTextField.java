/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.textfield;

import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

import net.disy.commons.core.string.StringFilter;

/**
 * Ein TextField, das den eingegebenen Text während der Eingabe gegen einen StringFilter prüft.
 *
 * @author Romano Caserta, DISY Informationssysteme GmbH
 * @version 3.6.99
 */
public class FilteredTextField extends JTextField {
  /**
   * Konstruktor mit einem StringFilter als Argument
   *
   * @param filter der anzuwendende StringFilter
   */
  public FilteredTextField(final StringFilter filter) {
    super();
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter und einem Text als Argumente
   *
   * @param filter der anzuwendende StringFilter
   * @param text   der Text
   */
  public FilteredTextField(final StringFilter filter, final String text) {
    super(text);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter und der Spaltenanzahl als Argumente
   *
   * @param filter  der anzuwendende StringFilter
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(final StringFilter filter, final int cols) {
    super(cols);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter, einem Text und der Spaltenanzahl als Argumente
   *
   * @param filter  der anzuwendende StringFilter
   * @param text    der Text
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(final StringFilter filter, final String text, final int cols) {
    super(text, cols);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter, einem Text, der Spaltenanzahl und einem Model als Argumente
   *
   * @param doc     das FilteredDocument
   * @param filter  der anzuwendende StringFilter
   * @param text    der Text
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(
      final StringFilter filter,
      final FilteredDocument doc,
      final String text,
      final int cols) {
    super(doc, text, cols);
    setFilter(filter);
  }

  /**
   * Setzt den Filter. Der Filter sollte einen Leerstring akzeptieren.
   *
   * @param filter der StringFilter
   */
  public void setFilter(final StringFilter filter) {
    ((FilteredDocument) getDocument()).setFilter(filter);
  }

  /**
   * Liefert das Model zurück, das defaultmäßig verwendet wird
   *
   * @return das FilteredDocument
   */
  @Override
  protected Document createDefaultModel() {
    return new FilteredDocument();
  }

  /**
   * Das zugehörige Model
   */
  public static class FilteredDocument extends PlainDocument {
    private StringFilter filter = null;

    /**
     * Der Konstruktor ohne Argumente
     */
    public FilteredDocument() {
      super();
    }

    /**
     * Setzt den Filter. Der Filter sollte einen Leerstring akzeptieren.
     *
     * @param filter der StringFilter
     */
    public void setFilter(final StringFilter filter) {
      this.filter = filter;
      try {
        if (filter != null && !filter.acceptFilterText(this.getText(0, getLength()))) {
          Toolkit.getDefaultToolkit().beep();
          super.remove(0, getLength());
        }
      }
      catch (final BadLocationException e) {
        e.printStackTrace();
      }
    }

    /**
     * Fügt einen String nur dann ein, wenn der neue Text vom Filter akzeptiert wird. 
     *
     * @param offs der Offset, an dem eingefügt werden soll
     * @param str  der einzufügende String
     * @param a    das AttributeSet
     */
    @Override
    public void insertString(final int offs, final String str, final AttributeSet a)
        throws BadLocationException {
      if (filter == null || str == null) {
        super.insertString(offs, str, a);
      }
      else {
        try {
          final String text = this.getText(0, getLength());
          final String newText = text.substring(0, offs) + str + text.substring(offs);
          if (filter.acceptFilterText(newText)) {
            super.insertString(offs, str, a);
          }
          else {
            Toolkit.getDefaultToolkit().beep();
          }
        }
        catch (final BadLocationException e) {
          e.printStackTrace();
        }
      }
    }

    /**
     * Entfernt einen Teil aus dem Text nur dann, wenn der neue Text vom Filter akzeptiert wird.
     *
     * @param offs die Stelle, an der Text entfernt werden soll
     * @param len  die Anzahl zu entfernender Zeichen
     */
    @Override
    public void remove(final int offs, final int len) throws BadLocationException {
      if (filter == null || len == 0) {
        super.remove(offs, len);
      }
      else {
        try {
          final String text = this.getText(0, getLength());
          final String newText = text.substring(0, offs) + text.substring(offs + len);
          if (filter.acceptFilterText(newText)) {
            super.remove(offs, len);
          }
          else {
            Toolkit.getDefaultToolkit().beep();
          }
        }
        catch (final BadLocationException e) {
          e.printStackTrace();
        }
      }
    }
  }
}
