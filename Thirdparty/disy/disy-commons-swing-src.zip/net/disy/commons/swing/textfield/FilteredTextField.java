package net.disy.commons.swing.textfield;

import java.awt.Toolkit;

import javax.swing.JTextField;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.PlainDocument;

import net.disy.commons.core.string.StringFilter;

/**
 * Ein TextField, das den eingegebenen Text w�hrend der Eingabe gegen einen StringFilter pr�ft.
 *
 * @author Romano Caserta, DISY Informationssysteme GmbH
 * @version 3.6.99
 */
public class FilteredTextField extends JTextField {
  /**
   * Konstruktor mit einem StringFilter als Argument
   *
   * @param filter der anzuwendende StringFilter
   */
  public FilteredTextField(StringFilter filter) {
    super();
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter und einem Text als Argumente
   *
   * @param filter der anzuwendende StringFilter
   * @param text   der Text
   */
  public FilteredTextField(StringFilter filter, String text) {
    super(text);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter und der Spaltenanzahl als Argumente
   *
   * @param filter  der anzuwendende StringFilter
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(StringFilter filter, int cols) {
    super(cols);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter, einem Text und der Spaltenanzahl als Argumente
   *
   * @param filter  der anzuwendende StringFilter
   * @param text    der Text
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(StringFilter filter, String text, int cols) {
    super(text, cols);
    setFilter(filter);
  }

  /**
   * Konstruktor mit einem StringFilter, einem Text, der Spaltenanzahl und einem Model als Argumente
   *
   * @param doc     das FilteredDocument
   * @param filter  der anzuwendende StringFilter
   * @param text    der Text
   * @param cols die Anzahl Spalten
   */
  public FilteredTextField(StringFilter filter, FilteredDocument doc, String text, int cols) {
    super(doc, text, cols);
    setFilter(filter);
  }

  /**
   * Setzt den Filter. Der Filter sollte einen Leerstring akzeptieren.
   *
   * @param filter der StringFilter
   */
  public void setFilter(StringFilter filter) {
    ((FilteredDocument) getDocument()).setFilter(filter);
  }

  /**
   * Liefert das Model zur�ck, das defaultm��ig verwendet wird
   *
   * @return das FilteredDocument
   */
  @Override
  protected Document createDefaultModel() {
    return new FilteredDocument();
  }

  /**
   * Das zugeh�rige Model
   */
  public static class FilteredDocument extends PlainDocument {
    private StringFilter filter = null;

    /**
     * Der Konstruktor ohne Argumente
     */
    public FilteredDocument() {
      super();
    }

    /**
     * Setzt den Filter. Der Filter sollte einen Leerstring akzeptieren.
     *
     * @param filter der StringFilter
     */
    public void setFilter(StringFilter filter) {
      this.filter = filter;
      try {
        if (filter != null && !filter.acceptFilterText(this.getText(0, getLength()))) {
          Toolkit.getDefaultToolkit().beep();
          super.remove(0, getLength());
        }
      }
      catch (BadLocationException e) {
        e.printStackTrace();
      }
    }

    /**
     * F�gt einen String nur dann ein, wenn der neue Text vom Filter akzeptiert wird. 
     *
     * @param offs der Offset, an dem eingef�gt werden soll
     * @param str  der einzuf�gende String
     * @param a    das AttributeSet
     */
    @Override
    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
      if (filter == null || str == null) {
        super.insertString(offs, str, a);
      }
      else {
        try {
          String text = this.getText(0, getLength());
          String newText = text.substring(0, offs) + str + text.substring(offs);
          if (filter.acceptFilterText(newText)) {
            super.insertString(offs, str, a);
          }
          else {
            Toolkit.getDefaultToolkit().beep();
          }
        }
        catch (BadLocationException e) {
          e.printStackTrace();
        }
      }
    }

    /**
     * Entfernt einen Teil aus dem Text nur dann, wenn der neue Text vom Filter akzeptiert wird.
     *
     * @param offs die Stelle, an der Text entfernt werden soll
     * @param len  die Anzahl zu entfernender Zeichen
     */
    @Override
    public void remove(int offs, int len) throws BadLocationException {
      if (filter == null || len == 0) {
        super.remove(offs, len);
      }
      else {
        try {
          String text = this.getText(0, getLength());
          String newText = text.substring(0, offs) + text.substring(offs + len);
          if (filter.acceptFilterText(newText)) {
            super.remove(offs, len);
          }
          else {
            Toolkit.getDefaultToolkit().beep();
          }
        }
        catch (BadLocationException e) {
          e.printStackTrace();
        }
      }
    }
  }
}
