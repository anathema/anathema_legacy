/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.util.ToggleComponentEnabler;

public class SelectableChangeComponentBuilder {

  private final JPanel container = new JPanel(new GridDialogLayout(3, false));

  public SelectableChangeComponentBuilder() {
    container.setBorder(LayoutUtilities.getDefaultEmptyBorder());
  }

  public void addRow(final IComponentContainer view, final BooleanModel booleanModel) {
    final JCheckBox changeBox = addCheckBox(booleanModel, GridAlignment.BEGINNING);
    addViewContent(view, 2);
    ToggleComponentEnabler.connect(changeBox, new JComponent[]{ view.getContent() });
  }

  private void addViewContent(final IComponentContainer view, final int horizontalSpan) {
    final GridDialogLayoutData componentData = new GridDialogLayoutData();
    componentData.setHorizontalSpan(horizontalSpan);
    componentData.setGrabExcessHorizontalSpace(true);
    container.add(view.getContent(), componentData);
  }

  public void addRow(final ILabelledView view, final BooleanModel booleanModel) {
    final JCheckBox changeBox = addCheckBox(booleanModel, GridAlignment.CENTER);
    container.add(view.getLabel(), GridDialogLayoutData.RIGHT);
    addViewContent(view, 1);
    ToggleComponentEnabler.connect(
        changeBox,
        new JComponent[]{ view.getLabel(), view.getContent() });
  }

  private JCheckBox addCheckBox(
      final BooleanModel booleanModel,
      final GridAlignment verticalAlignment) {
    final JCheckBox changeBox = ActionWidgetFactory.createCheckBox(new SmartToggleAction(
        booleanModel));
    changeBox.setToolTipText(DisyCommonsSwingMessages
        .getString("SelectableChangeComponentBuilder.changeTooltip")); //$NON-NLS-1$
    final GridDialogLayoutData data = new GridDialogLayoutData();
    data.setVerticalAlignment(verticalAlignment);
    container.add(changeBox, data);
    return changeBox;
  }

  public JComponent getContent() {
    return container;
  }
}