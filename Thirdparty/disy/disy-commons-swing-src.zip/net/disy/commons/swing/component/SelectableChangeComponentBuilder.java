// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 15.09.2005
package net.disy.commons.swing.component;

import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.util.ToggleComponentEnabler;

// NOT_PUBLISHED
public class SelectableChangeComponentBuilder {

  private JPanel container = new JPanel(new GridDialogLayout(3, false));

  public SelectableChangeComponentBuilder() {
    container.setBorder(LayoutUtilities.getDefaultEmptyBorder());
  }

  public void addRow(IView view, BooleanModel booleanModel) {
    JCheckBox changeBox = addCheckBox(booleanModel, GridAlignment.BEGINNING);
    addViewContent(view, 2);
    ToggleComponentEnabler.connect(changeBox, new Component[]{ view.getComponent() });
  }

  private void addViewContent(IView view, int horizontalSpan) {
    GridDialogLayoutData componentData = new GridDialogLayoutData();
    componentData.setHorizontalSpan(horizontalSpan);
    componentData.setGrabExcessHorizontalSpace(true);
    container.add(view.getComponent(), componentData);
  }

  public void addRow(ILabelledView view, BooleanModel booleanModel) {
    JCheckBox changeBox = addCheckBox(booleanModel, GridAlignment.CENTER);
    container.add(view.getLabel(), GridDialogLayoutData.RIGHT);
    addViewContent(view, 1);
    ToggleComponentEnabler.connect(
        changeBox,
        new Component[]{ view.getLabel(), view.getComponent() });
  }

  private JCheckBox addCheckBox(BooleanModel booleanModel, GridAlignment verticalAlignment) {
    JCheckBox changeBox = ActionWidgetFactory.createCheckBox(new SmartToggleAction(booleanModel));
    changeBox.setToolTipText(DisyCommonsSwingMessages
        .getString("SelectableChangeComponentBuilder.changeTooltip")); //$NON-NLS-1$
    GridDialogLayoutData data = new GridDialogLayoutData();
    data.setVerticalAlignment(verticalAlignment);
    container.add(changeBox, data);
    return changeBox;
  }

  public JComponent getContent() {
    return container;
  }
}