// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 15.09.2005
package net.disy.commons.swing.component;

import javax.swing.JComponent;

// NOT_PUBLISHED
public interface IView {

  public JComponent getComponent();
}