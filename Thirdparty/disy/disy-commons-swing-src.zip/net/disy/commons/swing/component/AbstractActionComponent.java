//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.ListenerList;

// NOT_PUBLISHED
public abstract class AbstractActionComponent {

  private ListenerList<ActionListener> actionListeners = new ListenerList<ActionListener>();

  public void addActionListener(ActionListener listener) {
    actionListeners.add(listener);
  }

  public void removeActionListener(ActionListener listener) {
    actionListeners.remove(listener);
  }

  protected void fireActionEvent() {
    final ActionEvent event = new ActionEvent(this, 0, null);
    actionListeners.forAllDo(new IListenerClosure<ActionListener>() {
      public void execute(ActionListener listener) {
        listener.actionPerformed(event);
      }
    });
  }
}