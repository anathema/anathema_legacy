/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.IClosure;

public abstract class AbstractActionComponent {

  private final ListenerList<ActionListener> actionListeners = new ListenerList<ActionListener>();

  public void addActionListener(final ActionListener listener) {
    actionListeners.add(listener);
  }

  public void removeActionListener(final ActionListener listener) {
    actionListeners.remove(listener);
  }

  protected void fireActionEvent() {
    final ActionEvent event = new ActionEvent(this, 0, null);
    actionListeners.forAllDo(new IClosure<ActionListener>() {
      @Override
      public void execute(final ActionListener listener) {
        listener.actionPerformed(event);
      }
    });
  }
}