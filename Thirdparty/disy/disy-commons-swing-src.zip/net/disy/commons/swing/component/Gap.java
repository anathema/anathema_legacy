/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import java.awt.Dimension;

import javax.swing.JComponent;

public class Gap extends JComponent {

  private Dimension preferredSize;

  /**
   * Creates an empty Component with the given size as preferred size.
   * 
   * @see #Gap(Dimension)
   */
  public Gap(final int preferredWidth, final int preferredHeight) {
    this(new Dimension(preferredWidth, preferredHeight));
  }

  /**
   * Creates an empty Component with the given size as preferred size.
   * 
   * @see #Gap()
   */
  public Gap(final Dimension preferredSize) {
    super();
    this.preferredSize = preferredSize;
  }

  /**
   * Creates an empty Component with default size.
   * 
   * @see #Gap(Dimension)
   */
  public Gap() {
    super();
  }

  @Override
  public Dimension getPreferredSize() {
    if (preferredSize == null) {
      return super.getPreferredSize();
    }
    return preferredSize;
  }
}