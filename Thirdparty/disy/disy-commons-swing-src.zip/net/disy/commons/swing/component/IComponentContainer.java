package net.disy.commons.swing.component;

import javax.swing.JComponent;

public interface IComponentContainer {
  public JComponent getContent();
}
