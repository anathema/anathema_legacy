/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component.tristate.demo;

import org.junit.runner.RunWith;

import net.disy.commons.swing.component.tristate.TriState;
import net.disy.commons.swing.component.tristate.TristateCheckBox;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class TristateCheckBoxDemo extends SwingDemoCase {

  public void demoNotCareStateSelected() throws Exception {
    show(new TristateCheckBox("Tristate checkbox", TriState.SELECTED, true)); //$NON-NLS-1$
  }

  public void demoNotCareStateDeselected() throws Exception {
    show(new TristateCheckBox("Tristate checkbox", TriState.SELECTED, false)); //$NON-NLS-1$
  }
}