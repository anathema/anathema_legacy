// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;

//NOT_PUBLISHED
public class LabeledDialogComponent implements IDialogComponent {

  private final String label;
  private final JComponent component;

  public LabeledDialogComponent(String label, JComponent component) {
    this.label = label;
    this.component = component;
  }

  public int getColumnCount() {
    return 2;
  }

  public void fillInto(JPanel panel, int columnCount) {
    panel.add(new JLabel(label), GridDialogLayoutData.DEFAULT);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalSpan(columnCount - 1);
    layoutData.setGrabExcessHorizontalSpace(true);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    panel.add(component);
  }

}
