/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;

public class LabeledDialogComponent implements IDialogComponent {

  private final String label;
  private final JComponent component;

  public LabeledDialogComponent(final String label, final JComponent component) {
    this.label = label;
    this.component = component;
  }

  @Override
  public int getColumnCount() {
    return 2;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    panel.add(new JLabel(label), IGridDialogLayoutData.DEFAULT);
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalSpan(columnCount - 1);
    layoutData.setGrabExcessHorizontalSpace(true);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    panel.add(component);
  }

}
