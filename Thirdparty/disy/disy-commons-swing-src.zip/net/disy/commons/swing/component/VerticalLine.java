// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

import net.disy.commons.swing.color.SwingColors;

/** 
 * A horizontal line that can be used for visual structuring of gui layouts. 
 */
public class VerticalLine extends JComponent {

  private static final Dimension SIZE = new Dimension(7, 18);

  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  public Dimension getMaximumSize() {
    return getPreferredSize();
  }

  public Dimension getPreferredSize() {
    return SIZE;
  }

  public void paintComponent(Graphics g) {
    int height = getSize().height;

    int gap = (height - 18) / 2;
    final int x = 3;

    g.setColor(SwingColors.getControlLtHighlightColor());
    g.drawLine(x + 1, gap, x + 1, height - gap);

    g.setColor(SwingColors.getControlShadowColor());
    g.drawLine(x, gap, x, height - gap);
    g.drawLine(x + 1, gap, x + 1, gap);
  }
}