/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

import net.disy.commons.swing.color.SwingColors;

/** 
 * A horizontal line that can be used for visual structuring of gui layouts. 
 */
public class VerticalLine extends JComponent {

  private static final Dimension SIZE = new Dimension(7, 18);

  @Override
  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  @Override
  public Dimension getMaximumSize() {
    return getPreferredSize();
  }

  @Override
  public Dimension getPreferredSize() {
    return SIZE;
  }

  @Override
  public void paintComponent(final Graphics g) {
    final int height = getSize().height;

    final int gap = (height - 18) / 2;
    final int x = 3;

    g.setColor(SwingColors.getControlLtHighlightColor());
    g.drawLine(x + 1, gap, x + 1, height - gap);

    g.setColor(SwingColors.getControlShadowColor());
    g.drawLine(x, gap, x, height - gap);
    g.drawLine(x + 1, gap, x + 1, gap);
  }
}