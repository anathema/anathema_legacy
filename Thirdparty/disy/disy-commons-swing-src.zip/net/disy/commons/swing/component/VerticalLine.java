// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.SystemColor;

import javax.swing.JComponent;

/** 
 * A horizontal line that can be used for visual structuring of gui layouts. 
 */
public class VerticalLine extends JComponent {

  private static final Dimension SIZE = new Dimension(7, 18);

  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  public Dimension getMaximumSize() {
    return getPreferredSize();
  }

  public Dimension getPreferredSize() {
    return SIZE;
  }

  public void paintComponent(Graphics g) {
    int height = getSize().height;

    int gap = (height - 18) / 2;
    g.setColor(SystemColor.controlShadow);
    g.drawLine(3, gap, 3, height - gap);
    g.setColor(SystemColor.controlLtHighlight);
    g.drawLine(4, gap, 4, height - gap);
  }
}