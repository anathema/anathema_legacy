//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

// NOT_PUBLISHED
public interface IDisposableComponentContainer extends IComponentContainer {
  
  public void dispose();

}
