/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component;

import java.awt.BorderLayout;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.swing.toolbar.ToolBarUtilities;

public class ButtonizedComponent implements IComponentContainer {

  private final JPanel panel;
  private final AbstractButton button;
  private final JComponent component;

  public ButtonizedComponent(final Action action, final JComponent component) {
    this.component = component;
    panel = new JPanel(new BorderLayout(0, 0));
    button = ToolBarUtilities.createToolBarButton(action);
    panel.add(button, BorderLayout.WEST);
    panel.add(component, BorderLayout.CENTER);
  }

  @Override
  public JComponent getContent() {
    return panel;
  }

  public void setEnabled(final boolean enabled) {
    button.setEnabled(enabled);
    component.setEnabled(enabled);
  }

  public void setButtonVisible(final boolean visible) {
    button.setVisible(visible);
  }
}