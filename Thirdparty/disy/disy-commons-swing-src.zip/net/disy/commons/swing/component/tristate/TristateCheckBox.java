/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.component.tristate;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.AbstractAction;
import javax.swing.ActionMap;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeListener;
import javax.swing.plaf.ActionMapUIResource;

/**
 * Maintenance tip - There were some tricks to getting this code working:
 * 
 * 1. You have to overwite addMouseListener() to do nothing
 * 2. You have to add a mouse event on mousePressed by calling super.addMouseListener()
 * 3. You have to replace the UIActionMap for the keyboard event "pressed" with your own one.
 * 4. You have to remove the UIActionMap for the keyboard event "released".
 * 5. You have to grab focus when the next state is entered, otherwise clicking on the component 
 *    won't get the focus.
 * 6. You have to make a TristateDecorator as a button model that wraps the original button model
 *    and does state management.
 */
public class TristateCheckBox extends JCheckBox {
  private final TristateDecorator model;

  public TristateCheckBox(
      final String text,
      final Icon icon,
      final TriState initial,
      final boolean notCareState) {
    super(text, icon);
    // Add a listener for when the mouse is pressed
    super.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        grabFocus();
        model.nextState();
      }
    });
    // Reset the keyboard action map
    final ActionMap map = new ActionMapUIResource();
    map.put("pressed", new AbstractAction() { //$NON-NLS-1$
          @Override
          public void actionPerformed(final ActionEvent e) {
            grabFocus();
            model.nextState();
          }
        });
    map.put("released", null); //$NON-NLS-1$
    SwingUtilities.replaceUIActionMap(this, map);
    // set the model to the adapted model
    model = new TristateDecorator(getModel(), notCareState);
    setModel(model);
    setState(initial);
  }

  public TristateCheckBox(final String text, final TriState initial, final boolean notCareState) {
    this(text, null, initial, notCareState);
  }

  public TristateCheckBox(final String text, final boolean notCareState) {
    this(text, TriState.DONT_CARE, notCareState);
  }

  public TristateCheckBox(final boolean notCareState) {
    this(null, notCareState);
  }

  /** No one may add mouse listeners, not even Swing! */
  @Override
  public void addMouseListener(final MouseListener l) {
    // nothing to do
  }

  /**
   * Set the new state to either SELECTED, NOT_SELECTED or DONT_CARE.  If state == null, it is
   *  treated as DONT_CARE.
   */
  public void setState(final TriState state) {
    model.setState(state);
  }

  /** Return the current state, which is determined by the selection status of the model. */
  public TriState getState() {
    return model.getState();
  }

  @Override
  public void setSelected(final boolean b) {
    if (b) {
      setState(TriState.SELECTED);
    }
    else {
      setState(TriState.NOT_SELECTED);
    }
  }

  private class TristateDecorator implements ButtonModel {
    private final ButtonModel other;
    private final boolean notCareSelection;

    private TristateDecorator(final ButtonModel other, final boolean notCareSelection) {
      this.other = other;
      this.notCareSelection = notCareSelection;
    }

    private void setState(final TriState state) {
      if (state == TriState.NOT_SELECTED) {
        other.setArmed(false);
        setPressed(false);
        setSelected(false);
      }
      else if (state == TriState.SELECTED) {
        other.setArmed(false);
        setPressed(false);
        setSelected(true);
      }
      else { // either "null" or DONT_CARE
        other.setArmed(true);
        setPressed(true);
        setSelected(notCareSelection);
      }
    }

    /**
     * The current state is embedded in the selection / armed
     * state of the model.
     * 
     * We return the SELECTED state when the checkbox is selected
     * but not armed, DONT_CARE state when the checkbox is
     * selected and armed (grey) and NOT_SELECTED when the
     * checkbox is deselected.
     */
    private TriState getState() {
      if (isArmed()) {
        return TriState.DONT_CARE;
      }
      if (isSelected() && !isArmed()) {
        // normal black tick
        return TriState.SELECTED;
      }
      // normal deselected
      return TriState.NOT_SELECTED;
    }

    /** We rotate between NOT_SELECTED, SELECTED and DONT_CARE.*/
    private void nextState() {
      final TriState current = getState();
      if (current == TriState.NOT_SELECTED) {
        setState(TriState.SELECTED);
      }
      else if (current == TriState.SELECTED) {
        setState(TriState.DONT_CARE);
      }
      else if (current == TriState.DONT_CARE) {
        setState(TriState.NOT_SELECTED);
      }
    }

    /** Filter: No one may change the armed status except us. */
    @Override
    public void setArmed(final boolean b) {
      // nothing to do
    }

    /** We disable focusing on the component when it is not
     * enabled. */
    @Override
    public void setEnabled(final boolean b) {
      setFocusable(b);
      other.setEnabled(b);
    }

    /** All these methods simply delegate to the "other" model
     * that is being decorated. */
    @Override
    public boolean isArmed() {
      return other.isArmed();
    }

    @Override
    public boolean isSelected() {
      return other.isSelected();
    }

    @Override
    public boolean isEnabled() {
      return other.isEnabled();
    }

    @Override
    public boolean isPressed() {
      return other.isPressed();
    }

    @Override
    public boolean isRollover() {
      return other.isRollover();
    }

    @Override
    public void setSelected(final boolean b) {
      other.setSelected(b);
    }

    @Override
    public void setPressed(final boolean b) {
      other.setPressed(b);
    }

    @Override
    public void setRollover(final boolean b) {
      other.setRollover(b);
    }

    @Override
    public void setMnemonic(final int key) {
      other.setMnemonic(key);
    }

    @Override
    public int getMnemonic() {
      return other.getMnemonic();
    }

    @Override
    public void setActionCommand(final String s) {
      other.setActionCommand(s);
    }

    @Override
    public String getActionCommand() {
      return other.getActionCommand();
    }

    @Override
    public void setGroup(final ButtonGroup group) {
      other.setGroup(group);
    }

    @Override
    public void addActionListener(final ActionListener l) {
      other.addActionListener(l);
    }

    @Override
    public void removeActionListener(final ActionListener l) {
      other.removeActionListener(l);
    }

    @Override
    public void addItemListener(final ItemListener l) {
      other.addItemListener(l);
    }

    @Override
    public void removeItemListener(final ItemListener l) {
      other.removeItemListener(l);
    }

    @Override
    public void addChangeListener(final ChangeListener l) {
      other.addChangeListener(l);
    }

    @Override
    public void removeChangeListener(final ChangeListener l) {
      other.removeChangeListener(l);
    }

    @Override
    public Object[] getSelectedObjects() {
      return other.getSelectedObjects();
    }
  }
}