// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import javax.swing.JComponent;

import net.disy.commons.swing.layout.grid.GridDialogPanel;
import net.disy.commons.swing.layout.grid.IDialogComponent;

/**
 * @deprecated As of 05.12.2005 (gebhard), replaced by {@link IDialogComponent} and {@link GridDialogPanel}
 * Interface of a simple view, that consists only of a label and a simple preference component.
 */
@Deprecated
public interface ILabelledView extends IComponentContainer {

  public JComponent getLabel();
}