// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.component;

import javax.swing.JComponent;

/**
 * Interface of a simple view, that consists only of a label and a simple preference component.
 */
public interface ILabelledView extends IView {

  public JComponent getLabel();
}