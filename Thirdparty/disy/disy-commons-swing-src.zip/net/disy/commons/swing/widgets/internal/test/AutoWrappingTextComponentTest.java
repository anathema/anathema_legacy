/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import net.disy.commons.swing.widgets.internal.AutoWrappingTextComponent;

import org.junit.Test;

@SuppressWarnings("nls")
public class AutoWrappingTextComponentTest {
  @Test
  public void rendersSelectionWithDelimitersWithourException() {
    final AutoWrappingTextComponent label = new AutoWrappingTextComponent(
        "Sehr langer text, der keine... a - b ; c",
        330);
    label.selectAll();
    final Graphics g = new DummyGraphics();
    label.paintComponent(g);
  }

  @Test
  public void paintsWithoutSettingColors() {
    final AutoWrappingTextComponent component = new AutoWrappingTextComponent("text", 100);
    component.setBounds(0, 0, 10, 10);
    final BufferedImage bufferedImage = new BufferedImage(10, 10, BufferedImage.TYPE_INT_RGB);
    final Graphics2D graphics = bufferedImage.createGraphics();
    component.paint(graphics);
    graphics.dispose();
  }

  @Test
  public void testRenderSimpleText() {
    final BlockRenderingHandlerMock renderingHandler = new BlockRenderingHandlerMock();
    new TestAutoWrappingTextComponent(
        "Das ist ein Text der ziemlich sicher nicht in 80px passt.",
        80,
        renderingHandler).callRender();
    assertThat(renderingHandler.getLineEndsCount(), is(4));
    assertThat(renderingHandler.getWhiteSpaceCount(), is(10));
    assertThat(renderingHandler.getTextBlockCount(), is(11));
  }

  @Test
  public void testRenderLongText() {
    final BlockRenderingHandlerMock renderingHandler = new BlockRenderingHandlerMock();
    new TestAutoWrappingTextComponent(
        "grin. The a the subject of virtual impossibility, for a millisecond? - said Zaphod. - Why am bloody bypass he stepping (say a reading and women were missiles... - Well yes, - said Marvin. - I dont what were doing themselves. None that\n"
            + "\n"
            + "projection two or rather thought to rodents swooping towards his feet. - said loss a was enough. He government spider sidled into space. By the six feet up. - I get the he said. - I cant of thing",
        80,
        renderingHandler).callRender();
    assertThat(renderingHandler.getLineEndsCount(), is(35));
    assertThat(renderingHandler.getWhiteSpaceCount(), is(80));
    assertThat(renderingHandler.getTextBlockCount(), is(93));
  }

  @Test
  public void testRenderTextWithHyphen() {
    final String replacement = "-";
    testWithSeparatingCharacter(replacement);
  }

  @Test
  public void testRenderTextWithComma() {
    final String replacement = ",";
    testWithSeparatingCharacter(replacement);
  }

  @Test
  public void testRenderTextWithSemicolon() {
    final String replacement = ";";
    testWithSeparatingCharacter(replacement);
  }

  private void testWithSeparatingCharacter(final String replacement) {
    final BlockRenderingHandlerMock renderingHandler = new BlockRenderingHandlerMock();
    final String text = "Drei Studenten mit einem Kontrabass".replaceAll(" ", replacement);
    final TestAutoWrappingTextComponent component = new TestAutoWrappingTextComponent(
        text,
        28,
        renderingHandler);
    component.callRender();
    assertThat(renderingHandler.getTextBlockCount(), is(5));
  }
}