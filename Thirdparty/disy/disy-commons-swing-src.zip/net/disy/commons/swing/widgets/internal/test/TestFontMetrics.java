/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import java.awt.FontMetrics;

public class TestFontMetrics extends FontMetrics {

  private static final int CHARACTER_HEIGHT = 8;
  private static final int CHARACTER_WIDTH = 5;

  public TestFontMetrics() {
    super(null);
  }

  @Override
  public int stringWidth(String str) {
    return str.length() * CHARACTER_WIDTH;
  }

  @Override
  public int getHeight() {
    return CHARACTER_HEIGHT;
  }

}
