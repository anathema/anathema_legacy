/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.test;

import java.awt.Dimension;

import javax.swing.JLabel;

import junit.framework.TestCase;

import net.disy.commons.swing.widgets.AutoWrappingLabel;

public class AutoWrappingLabelTest extends TestCase {

  private static final String LARGE_TEXT = "Ich bin ziemlich ausschweifend, in dem was ich der Welt zu sagen. " //$NON-NLS-1$
      + "Doch die Welt lebt ohnehin zu sehr in Hektik. " //$NON-NLS-1$
      + "Gönnen wir uns also die Muße die es braucht, um diese Zeilen zu lesen."; //$NON-NLS-1$

  public void testGetInitialSizeConsidersContent() {
    final Dimension smallSize = new AutoWrappingLabel("bla").getContent().getPreferredSize(); //$NON-NLS-1$
    assertTrue(smallSize.width > 5);
    assertTrue(smallSize.height > 5);
    assertTrue(smallSize.height < 30);
    final Dimension largeSize = new AutoWrappingLabel(LARGE_TEXT).getContent().getPreferredSize();
    assertTrue(largeSize.width > 5);
    assertTrue(largeSize.height > 30);
    assertTrue(largeSize.height < 100);
  }

  public void testDefaultBackground() throws Exception {
    assertEquals(new JLabel().getBackground(), new AutoWrappingLabel().getContent().getBackground());
  }

  public void testAutoExpandIfWidthTooSmall() {
    int initialWidth = 15;
    AutoWrappingLabel croppedLabel = new AutoWrappingLabel(LARGE_TEXT, initialWidth);
    int croppedWidth = croppedLabel.getCroppedWidth();
    assertTrue(croppedWidth > 0);
    AutoWrappingLabel resizedLabel = new AutoWrappingLabel(LARGE_TEXT, initialWidth + croppedWidth);
    assertEquals(0, resizedLabel.getCroppedWidth());
    assertTrue(resizedLabel.getContent().getPreferredSize().height <= croppedLabel
        .getContent()
        .getPreferredSize().height);
  }

  public void testAutoExpandCorrectSizeTaken() {
    int initialWidth = 15;

    int preferredWidth = getPreferredWidthForAutoWrappingText(LARGE_TEXT, initialWidth);
    assertTrue(preferredWidth > initialWidth);

    assertEquals(preferredWidth, getPreferredWidthForAutoWrappingText(LARGE_TEXT, preferredWidth));

    int moreThanEnoughWidth = preferredWidth + 20;
    assertEquals(moreThanEnoughWidth, getPreferredWidthForAutoWrappingText(
        LARGE_TEXT,
        moreThanEnoughWidth));
  }

  private int getPreferredWidthForAutoWrappingText(String text, int initialWidth) {
    AutoWrappingLabel label = new AutoWrappingLabel(text, initialWidth);
    Dimension preferredSize = label.getContent().getPreferredSize();
    return preferredSize.width;
  }
}