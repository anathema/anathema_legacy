//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets.test;

import java.awt.Dimension;

import javax.swing.JLabel;

import junit.framework.TestCase;

import net.disy.commons.swing.widgets.AutoWrappingLabel;

// NOT_PUBLISHED
public class AutoWrappingLabelTest extends TestCase {

  private static final String LARGE_TEXT = "Ich bin ziemlich ausschweifend, in dem was ich der Welt zu sagen. " //$NON-NLS-1$
      + "Doch die Welt lebt ohnehin zu sehr in Hektik. " //$NON-NLS-1$
      + "G�nnen wir uns also die Mu�e die es braucht, um diese Zeilen zu lesen."; //$NON-NLS-1$

  public void testGetInitialSizeConsidersContent() {
    Dimension smallSize = new AutoWrappingLabel("bla").getContent().getPreferredSize(); //$NON-NLS-1$
    assertTrue(smallSize.width > 5);
    assertTrue(smallSize.height > 5);
    assertTrue(smallSize.height < 30);
    Dimension largeSize = new AutoWrappingLabel(LARGE_TEXT).getContent().getPreferredSize(); //$NON-NLS-1$
    assertTrue(largeSize.width > 5);
    assertTrue(largeSize.height > 30);
    assertTrue(largeSize.height < 100);
  }
  
  public void testDefaultBackground() throws Exception {
    assertEquals(new JLabel().getBackground(), new AutoWrappingLabel().getContent().getBackground());
  }
}