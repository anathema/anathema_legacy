/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import net.disy.commons.swing.widgets.internal.TextBlock;
import net.disy.commons.swing.widgets.internal.TextBlockDelimiter;

import org.junit.Test;

public class TextBlockTest {
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate1() {
    new TextBlock(null, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate2() {
    new TextBlock(null, TextBlockDelimiter.END_OF_TEXT);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate3() {
    new TextBlock("text", null); //$NON-NLS-1$
  }

  @Test
  public void testCreate() {
    assertEquals(
        TextBlockDelimiter.END_OF_TEXT,
        new TextBlock("", TextBlockDelimiter.END_OF_TEXT).delimiter); //$NON-NLS-1$
    assertEquals(
        TextBlockDelimiter.NEWLINE,
        new TextBlock("", TextBlockDelimiter.NEWLINE).delimiter); //$NON-NLS-1$

    assertEquals("", new TextBlock("", TextBlockDelimiter.NEWLINE).text); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("abc", new TextBlock("abc", TextBlockDelimiter.NEWLINE).text); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testSameEquals() {
    final TextBlock textBlock = new TextBlock("abc", TextBlockDelimiter.NEWLINE); //$NON-NLS-1$
    assertEquals(textBlock, textBlock);
  }

  @Test
  public void testEqualEquals() {
    assertEquals(
        new TextBlock("abc", TextBlockDelimiter.NEWLINE), new TextBlock("abc", TextBlockDelimiter.NEWLINE)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testDifferentNotEquals() {
    assertThat(
        new TextBlock("abc", TextBlockDelimiter.NEWLINE), is(not(equalTo(new TextBlock("def", TextBlockDelimiter.NEWLINE))))); //$NON-NLS-1$ //$NON-NLS-2$
    assertThat(
        new TextBlock("abc", TextBlockDelimiter.NEWLINE), is(not(equalTo(new TextBlock("abc", TextBlockDelimiter.SPACE))))); //$NON-NLS-1$ //$NON-NLS-2$
  }
}