/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;
import net.disy.commons.swing.widgets.internal.TextPosition;

import org.junit.Test;

public class TextPositionTest {

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate() {
    new TextPosition(-1, 0);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate2() {
    new TextPosition(0, -1);
  }

  @Test
  public void testCreate() {
    assertEquals(1, new TextPosition(1, 3).getBlockIndex());
    assertEquals(2, new TextPosition(2, 3).getBlockIndex());
    assertEquals(1, new TextPosition(3, 1).getIndexInBlock());
    assertEquals(2, new TextPosition(3, 2).getIndexInBlock());
  }

  @Test
  public void testSameEquals() {
    final TextPosition textPosition = new TextPosition(1, 3);
    assertEquals(textPosition, textPosition);
  }

  @Test
  public void testEqualEquals() {
    assertEquals(new TextPosition(1, 3), new TextPosition(1, 3));
    assertEquals(new TextPosition(2, 1), new TextPosition(2, 1));
  }

  @Test
  public void testDifferentNotEquals() {
    assertThat(new TextPosition(2, 3), is(not(equalTo(new TextPosition(1, 3)))));
    assertThat(new TextPosition(1, 4), is(not(equalTo(new TextPosition(1, 3)))));
    assertThat(new TextPosition(2, 4), is(not(equalTo(new TextPosition(1, 3)))));
  }
}