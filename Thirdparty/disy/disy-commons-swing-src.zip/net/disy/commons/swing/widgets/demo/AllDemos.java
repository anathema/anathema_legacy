// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;
 
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for de.disy.lib.gui.component.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(AutoWrappingLabelDemo.class));
    suite.addDemo(new DemoSuite(HorizontalLineDemo.class));
    //$JDemo-END$
    return suite;
  }
}
