/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import static org.junit.Assert.*;
import net.disy.commons.swing.widgets.internal.TextPosition;
import net.disy.commons.swing.widgets.internal.TextSelection;

import org.junit.Test;

public class TextSelectionTest {

  @Test
  public void testCreateSingleBlockSelectionInCorrectOrder() {
    final TextSelection selection = TextSelection.createSelection(
        new TextPosition(0, 0),
        new TextPosition(0, 2));
    assertEquals(new TextPosition(0, 0), selection.startPosition);
    assertEquals(new TextPosition(0, 2), selection.endPosition);
  }

  @Test
  public void testCreateSingleBlockSelectionInIncorrectOrder() {
    final TextSelection selection = TextSelection.createSelection(
        new TextPosition(5, 3),
        new TextPosition(5, 1));
    assertEquals(new TextPosition(5, 1), selection.startPosition);
    assertEquals(new TextPosition(5, 3), selection.endPosition);
  }

  @Test
  public void testCreateMultiBlockSelectionInCorrectOrder() {
    final TextSelection selection = TextSelection.createSelection(
        new TextPosition(0, 0),
        new TextPosition(2, 1));
    assertEquals(new TextPosition(0, 0), selection.startPosition);
    assertEquals(new TextPosition(2, 1), selection.endPosition);
  }

  @Test
  public void testCreateMultiBlockSelectionInIncorrectOrder() {
    final TextSelection selection = TextSelection.createSelection(
        new TextPosition(3, 1),
        new TextPosition(2, 1));
    assertEquals(new TextPosition(2, 1), selection.startPosition);
    assertEquals(new TextPosition(3, 1), selection.endPosition);
  }

  @Test
  public void testCreateZeroSizeSelection() {
    final TextSelection selection = TextSelection.createSelection(
        new TextPosition(1, 1),
        new TextPosition(1, 1));
    assertEquals(new TextPosition(1, 1), selection.startPosition);
    assertEquals(new TextPosition(1, 1), selection.endPosition);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate() {
    TextSelection.createSelection(null, new TextPosition(1, 1));
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate2() {
    TextSelection.createSelection(null, null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreate3() {
    TextSelection.createSelection(new TextPosition(1, 1), null);
  }

}