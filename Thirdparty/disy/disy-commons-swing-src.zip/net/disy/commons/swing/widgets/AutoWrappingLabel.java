// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.text.BreakIterator;
import java.util.StringTokenizer;

import javax.swing.JComponent;
import javax.swing.JTextArea;

import net.disy.commons.swing.laf.LookAndFeelUtilities;

/**
 * Component similar to JLabel but automatically wrapping text (uses JTextArea).
 * @author gebhard
 */
public class AutoWrappingLabel {

  private final static int INITIAL_WIDTH = 330;
  private final JTextArea textArea;

  public AutoWrappingLabel() {
    this(""); //$NON-NLS-1$
  }

  public AutoWrappingLabel(String text) {
    this(text, INITIAL_WIDTH);
  }

  public AutoWrappingLabel(String text, final int width) {
    textArea = new JTextArea(text) {
      @Override
      public Dimension getMinimumSize() {
        return getPreferredSize();
      }

      @Override
      public Dimension getPreferredSize() {
        FontMetrics fontMetrics = getFontMetrics(getFont());
        int lineCount = getLineCount(width, fontMetrics);
        //+1 is Bugfix for some L&Fs which crop the last text pixel otherwise
        return new Dimension(width, (fontMetrics.getHeight() * (lineCount)) + 1);
      }

      private int getLineCount(final int layoutWidth, FontMetrics fontMetrics) {
        StringTokenizer tokenizer = new StringTokenizer(getText(), "\n", true); //$NON-NLS-1$
        int lineCount = 0;
        boolean wasContentBefore = false;
        while (tokenizer.hasMoreTokens()) {
          String token = tokenizer.nextToken();
          if (token.length() == 1 && token.charAt(0) == '\n') {
            if (!wasContentBefore) {
              ++lineCount;
            }
            wasContentBefore = false;
          }
          else {
            lineCount += getLineCount(token, fontMetrics, layoutWidth);
            wasContentBefore = true;
          }
        }
        return lineCount;
      }

      private final int getLineCount(String text, FontMetrics fontMetrics, int layoutWidth) {
        BreakIterator breaker = BreakIterator.getLineInstance();
        breaker.setText(text);
        int lineCount = 1;
        int currStart = breaker.first();
        int currEnd = breaker.next();
        while (currEnd != java.text.BreakIterator.DONE) {
          if (fontMetrics.stringWidth(text.substring(currStart, currEnd)) >= layoutWidth) {
            //Break the text at the last position, unless it's the same as this one,
            // then we'll just have to draw off the end.
            int currPrior = breaker.previous();
            if (currPrior != currStart) {
              currEnd = currPrior;
            }
            else {
              breaker.next();
            }
            ++lineCount;
            currStart = currEnd;
          }
          currEnd = breaker.next();
        }
        return lineCount;
      }
    };
    textArea.setLineWrap(true);
    textArea.setWrapStyleWord(true);
    textArea.setEditable(false);
    LookAndFeelUtilities.installColorsAndFont(textArea, LookAndFeelUtilities.COMPONENT_TYPE_LABEL);
  }

  public void setFont(Font font) {
    textArea.setFont(font);
  }

  public Font getFont() {
    return textArea.getFont();
  }

  public JComponent getContent() {
    return textArea;
  }

  public void setForeground(Color color) {
    textArea.setForeground(color);
  }

  public void setBackground(Color color) {
    textArea.setBackground(color);
  }

  public void setText(String text) {
    textArea.setText(text);
  }

  public void setOpaque(boolean opaque) {
    textArea.setOpaque(opaque);
  }

  public void setVisible(boolean visible) {
    textArea.setVisible(visible);
  }
}