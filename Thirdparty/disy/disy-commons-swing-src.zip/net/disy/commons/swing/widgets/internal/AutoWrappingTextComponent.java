/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal;

import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.provider.IProvider;
import net.disy.commons.core.text.TextAlignment;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.SwingColors;

public class AutoWrappingTextComponent extends JComponent {

  private final int width;
  private final TextContent content = new TextContent();
  private final ObjectModel<TextSelection> selectionModel = new ObjectModel<TextSelection>();
  private TextAlignment textAlignment = TextAlignment.LEFT;

  public AutoWrappingTextComponent(final String text, final int width) {
    Ensure.ensureArgumentNotNull(text);
    this.width = width;
    setForeground(SwingColors.getTextAreaForegroundColor());
    setBackground(SwingColors.getTextAreaBackgroundColor());
    content.setTextBlocks(TextBlockFactory.createTextBlocks(text));
    setOpaque(true);
    final MouseAdapter mouseListener = new MouseAdapter() {
      private TextPosition startPosition;

      @Override
      public void mouseReleased(final MouseEvent e) {
        if (!isEnabled()) {
          return;
        }
        final TextPosition position = getTextPositionAt(e.getPoint());
        if (position == null) {
          startPosition = null;
          return;
        }
        if (startPosition == null) {
          return;
        }
        selectionModel.setValue(TextSelection.createSelection(startPosition, position));
      }

      @Override
      public void mousePressed(final MouseEvent e) {
        if (!isEnabled()) {
          return;
        }
        clearSelection();
        final TextPosition position = getTextPositionAt(e.getPoint());
        startPosition = position;
        requestFocus();
      }

      @Override
      public void mouseDragged(final MouseEvent e) {
        if (!isEnabled()) {
          return;
        }
        final TextPosition position = getTextPositionAt(e.getPoint());
        if (position == null) {
          return;
        }
        if (startPosition == null) {
          return;
        }
        selectionModel.setValue(TextSelection.createSelection(startPosition, position));
      }

      private TextPosition getTextPositionAt(final Point point) {
        final FontMetrics metrics = getFontMetrics(getFont());
        final TextPositionFindingHandler finder = new TextPositionFindingHandler(metrics, point);
        render(metrics, getWidth(), finder);
        final TextPosition textPosition = finder.getTextPosition();
        if (textPosition == null) {
          if (point.y < 0) {
            return new TextPosition(0, 0);
          }
          return content.getLastTextPosition();
        }
        return textPosition;
      }
    };
    addMouseListener(mouseListener);
    addMouseMotionListener(mouseListener);
    selectionModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        repaint();
      }
    });
    addKeyListener(new TextComponentKeyListener(content, selectionModel, new IProvider<Toolkit>() {
      @Override
      public Toolkit getObject() {
        return getToolkit();
      }
    }));
  }

  @Override
  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  public void setTextAlignment(final TextAlignment textAlignment) {
    this.textAlignment = textAlignment;
  }

  @Override
  public Dimension getPreferredSize() {
    final FontMetrics fontMetrics = getFontMetrics(getFont());
    LineCountingAndMaxWidthCalculatingRenderingHandler handler = new LineCountingAndMaxWidthCalculatingRenderingHandler(
        fontMetrics);
    render(fontMetrics, width, handler);
    final int preferredSizeWidth = Math.max(handler.getMaxLineWidth(), width);
    if (preferredSizeWidth > width) {
      handler = new LineCountingAndMaxWidthCalculatingRenderingHandler(fontMetrics);
      render(fontMetrics, preferredSizeWidth, handler);
    }
    final int lineCount = handler.getLineCount();
    return new Dimension(preferredSizeWidth, (fontMetrics.getHeight() * lineCount));
  }

  @Override
  public void paintComponent(final Graphics g) {
    if (isOpaque()) {
      g.setColor(getBackground());
      g.fillRect(0, 0, getWidth(), getHeight());
    }
    g.setFont(getFont());
    final FontMetrics metrics = g.getFontMetrics();
    render(metrics, getWidth(), new TextGraphicsRenderingHandler(g, getForeground()));
  }

  protected void render(
      final FontMetrics metrics,
      final int layoutWidth,
      final IBlockRenderingHandler blockRenderer) {
    final LineBuffer lineBuffer = new LineBuffer(
        metrics,
        layoutWidth,
        blockRenderer,
        textAlignment,
        selectionModel);
    final int xOffset = 0;
    int x = xOffset;
    for (int blockIndex = 0; blockIndex < content.getBlockCount(); ++blockIndex) {
      final TextBlock block = content.getBlock(blockIndex);
      final int spaceLeft = layoutWidth - x;
      final int blockWidth = metrics.stringWidth(block.text);
      final boolean fits = spaceLeft >= blockWidth;
      if (!fits && blockIndex > 0) {
        lineBuffer.handleAutoLineBreak();
        x = xOffset;
      }
      lineBuffer.add(block, blockWidth);
      x += blockWidth;
      final TextBlockDelimiter delimiter = block.delimiter;
      if (delimiter.isNewLine()) {
        lineBuffer.handleNewLine();
        x = xOffset;
      }
      else {
        x += delimiter.calculateWidth(metrics);
      }
    }
  }

  public void setText(final String text) {
    clearSelection();
    content.setTextBlocks(TextBlockFactory.createTextBlocks(text));
    invalidate();
    repaint();
  }

  public ObjectModel<TextSelection> getSelectionModel() {
    return selectionModel;
  }

  private void clearSelection() {
    selectionModel.setValue(null);
  }

  public void selectAll() {
    final TextPosition start = new TextPosition(0, 0);
    final TextPosition end = content.getLastTextPosition();
    selectionModel.setValue(TextSelection.createSelection(start, end));
  }
}