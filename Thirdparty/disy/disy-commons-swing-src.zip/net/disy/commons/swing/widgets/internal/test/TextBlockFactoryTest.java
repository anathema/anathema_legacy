/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import net.disy.commons.swing.widgets.internal.TextBlock;
import net.disy.commons.swing.widgets.internal.TextBlockDelimiter;
import net.disy.commons.swing.widgets.internal.TextBlockFactory;

import org.junit.Test;

public class TextBlockFactoryTest {
  @Test(expected = IllegalArgumentException.class)
  public void testIllegalCreateTextBlocks() {
    TextBlockFactory.createTextBlocks(null);
  }

  @Test
  public void testCreateEmpty() {
    assertCreatesTextsBlocks("", new TextBlock[0]); //$NON-NLS-1$
  }

  @Test
  public void testCreateSimpleBlock() {
    assertCreatesTextsBlocks("42", new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$ //$NON-NLS-2$
    assertCreatesTextsBlocks("1", new TextBlock("1", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  @Test
  public void testCreateSimpleBlockWithNonBreakingSpace() {
    assertCreatesTextsBlocks("42" + (char) 160 + "1", //$NON-NLS-1$ //$NON-NLS-2$
        new TextBlock("42" + (char) 160 + "1", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$//$NON-NLS-2$
  }

  @Test
  public void testCreateSpacedBlocks() {
    assertCreatesTextsBlocks("1 42", //$NON-NLS-1$
        new TextBlock("1", TextBlockDelimiter.SPACE), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testCreateTabbedBlocks() {
    assertCreatesTextsBlocks("1\t42", //$NON-NLS-1$
        new TextBlock("1", TextBlockDelimiter.TAB), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testCreateNewLinedBlocks() {
    assertCreatesTextsBlocks("1\n42", //$NON-NLS-1$
        new TextBlock("1", TextBlockDelimiter.NEWLINE), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testCreateMultiNewLinedBlocks() {
    assertCreatesTextsBlocks("1\n\n42", //$NON-NLS-1$
        new TextBlock("1", TextBlockDelimiter.NEWLINE), //$NON-NLS-1$
        new TextBlock("", TextBlockDelimiter.NEWLINE), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testCreateCommaBlocks() {
    assertCreatesTextsBlocks("1, 42", //$NON-NLS-1$
        new TextBlock("1,", TextBlockDelimiter.COMMA), //$NON-NLS-1$
        new TextBlock("", TextBlockDelimiter.SPACE), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testHyphenBlocks() {
    assertCreatesTextsBlocks("1-42", //$NON-NLS-1$
        new TextBlock("1-", TextBlockDelimiter.HYPHEN), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testSemicolonBlocks() {
    assertCreatesTextsBlocks("1;42", //$NON-NLS-1$
        new TextBlock("1;", TextBlockDelimiter.SEMICOLON), //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndSpaceAsLastCharacter() {
    assertCreatesTextsBlocks("42 ", //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithBlockAndTwoSpacesAsLastCharacters() {
    assertCreatesTextsBlocks("42  ", //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.SPACE), //$NON-NLS-1$
        new TextBlock("", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndHyphenAsLastCharacter() {
    assertCreatesTextsBlocks("42-", //$NON-NLS-1$
        new TextBlock("42-", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithBlockAndTwoHyphensAsLastCharacters() {
    assertCreatesTextsBlocks("42--", //$NON-NLS-1$
        new TextBlock("42-", TextBlockDelimiter.HYPHEN), //$NON-NLS-1$
        new TextBlock("-", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndSemicolonAsLastCharacter() {
    assertCreatesTextsBlocks("42;", //$NON-NLS-1$
        new TextBlock("42;", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndTabAsLastCharacter() {
    assertCreatesTextsBlocks("42\t", //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndCommaAsLastCharacter() {
    assertCreatesTextsBlocks("42,", //$NON-NLS-1$
        new TextBlock("42,", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  @Test
  public void testTextWithOneBlockAndNewLineAsLastCharacter() {
    assertCreatesTextsBlocks("42\n", //$NON-NLS-1$
        new TextBlock("42", TextBlockDelimiter.END_OF_TEXT)); //$NON-NLS-1$
  }

  private void assertCreatesTextsBlocks(final String text, final TextBlock... textBlocks) {
    final List<TextBlock> blocks = TextBlockFactory.createTextBlocks(text);
    assertEquals(Arrays.asList(textBlocks), blocks);
  }
}