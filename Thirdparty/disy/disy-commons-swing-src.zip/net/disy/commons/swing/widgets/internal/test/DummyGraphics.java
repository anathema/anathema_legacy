/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.test;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class DummyGraphics extends Graphics {

  private Font font;

  @Override
  public Graphics create() {
    throw new UnsupportedOperationException();
  }

  @Override
  public void translate(final int x, final int y) {
    throw new UnsupportedOperationException();
  }

  @Override
  public Color getColor() {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setColor(final Color c) {
    //nothing to do
  }

  @Override
  public void setPaintMode() {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setXORMode(final Color c1) {
    throw new UnsupportedOperationException();
  }

  @Override
  public Font getFont() {
    return font;
  }

  @Override
  public void setFont(final Font font) {
    this.font = font;
  }

  @Override
  public FontMetrics getFontMetrics(final Font f) {
    return new DummyFontMetrics(f);
  }

  @Override
  public Rectangle getClipBounds() {
    throw new UnsupportedOperationException();
  }

  @Override
  public void clipRect(final int x, final int y, final int width, final int height) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setClip(final int x, final int y, final int width, final int height) {
    throw new UnsupportedOperationException();
  }

  @Override
  public Shape getClip() {
    throw new UnsupportedOperationException();
  }

  @Override
  public void setClip(final Shape clip) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void copyArea(
      final int x,
      final int y,
      final int width,
      final int height,
      final int dx,
      final int dy) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawLine(final int x1, final int y1, final int x2, final int y2) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void fillRect(final int x, final int y, final int width, final int height) {
    //nothing to do
  }

  @Override
  public void clearRect(final int x, final int y, final int width, final int height) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawRoundRect(
      final int x,
      final int y,
      final int width,
      final int height,
      final int arcWidth,
      final int arcHeight) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void fillRoundRect(
      final int x,
      final int y,
      final int width,
      final int height,
      final int arcWidth,
      final int arcHeight) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawOval(final int x, final int y, final int width, final int height) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void fillOval(final int x, final int y, final int width, final int height) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawArc(
      final int x,
      final int y,
      final int width,
      final int height,
      final int startAngle,
      final int arcAngle) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void fillArc(
      final int x,
      final int y,
      final int width,
      final int height,
      final int startAngle,
      final int arcAngle) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawPolyline(final int[] xPoints, final int[] yPoints, final int nPoints) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawPolygon(final int[] xPoints, final int[] yPoints, final int nPoints) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void fillPolygon(final int[] xPoints, final int[] yPoints, final int nPoints) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void drawString(final String str, final int x, final int y) {
    //nothing to do
  }

  @Override
  public void drawString(final AttributedCharacterIterator iterator, final int x, final int y) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(final Image img, final int x, final int y, final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(
      final Image img,
      final int x,
      final int y,
      final int width,
      final int height,
      final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(
      final Image img,
      final int x,
      final int y,
      final Color bgcolor,
      final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(
      final Image img,
      final int x,
      final int y,
      final int width,
      final int height,
      final Color bgcolor,
      final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(
      final Image img,
      final int dx1,
      final int dy1,
      final int dx2,
      final int dy2,
      final int sx1,
      final int sy1,
      final int sx2,
      final int sy2,
      final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public boolean drawImage(
      final Image img,
      final int dx1,
      final int dy1,
      final int dx2,
      final int dy2,
      final int sx1,
      final int sy1,
      final int sx2,
      final int sy2,
      final Color bgcolor,
      final ImageObserver observer) {
    throw new UnsupportedOperationException();
  }

  @Override
  public void dispose() {
    throw new UnsupportedOperationException();
  }
}