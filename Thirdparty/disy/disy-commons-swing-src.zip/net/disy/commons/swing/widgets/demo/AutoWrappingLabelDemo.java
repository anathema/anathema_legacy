/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.demo;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.text.TextAlignment;
import net.disy.commons.swing.widgets.AutoWrappingLabel;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class AutoWrappingLabelDemo extends SwingDemoCase {
  private static final String LONG_TEXT = "Sehr langer text, der keine Zeilenumbrüche beinhaltet. Wo und wann wird er umgebrochen? Sehen wir uns doch mal dieses Beispiel an. Und - wer hätte das gedacht? Auch nach einem Semikolon; Foo."; //$NON-NLS-1$

  public void demoWithSelection() {
    final AutoWrappingLabel label = new AutoWrappingLabel(
        "Sehr langer text, der keine... a - b ; c");
    label.selectAll();
    show(label.getContent());
  }

  public void demoAutoWrappingLabel() {
    final AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);
    show(label.getContent());
  }

  public void demoAutoWrappingLabelDisabled() {
    final AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);
    label.setEnabled(false);
    show(label.getContent());
  }

  public void demoAutoWrappingLabelWithLineBreaks() {
    final AutoWrappingLabel label = new AutoWrappingLabel(
        "Sehr langer text,\nder einen Zeilenumbruch beinhaltet. Wo und wann wird er umgebrochen? Sehen wir uns doch mal dieses Beispiel\nan."); //$NON-NLS-1$
    show(label.getContent());
  }

  public void demoAutoWrappingLabelCenteredWithLineBreaks() {
    final AutoWrappingLabel label = new AutoWrappingLabel(
        "Sehr langer text,\nder einen Zeilenumbruch beinhaltet. Wo und wann wird er umgebrochen? Sehen wir uns doch mal dieses Beispiel\nan."); //$NON-NLS-1$
    label.setTextAlignment(TextAlignment.CENTER);
    show(label.getContent());
  }

  public void demoAutoWrappingLabelWithTabsAndWhitespace() {
    final AutoWrappingLabel label = new AutoWrappingLabel(
        "Sehr langer text,        der einen Tab beinhaltet.\tWo und wann wird er umgebrochen? Sehen wir uns doch mal dieses Beispiel\nan."); //$NON-NLS-1$
    show(label.getContent());
  }

  public void demoAutoWrappingLabelWithWhiteBackground() {
    final AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);
    label.setBackground(Color.WHITE);
    show(label.getContent());
  }

  public void demoAutoWrappingLabelInLayout() {
    final AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);

    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(label.getContent(), BorderLayout.NORTH);
    panel.add(new JLabel("..."), BorderLayout.CENTER); //$NON-NLS-1$

    show(panel);
  }
}