// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets.demo;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.widgets.AutoWrappingLabel;

import de.jdemo.extensions.SwingDemoCase;

public class AutoWrappingLabelDemo extends SwingDemoCase {
  private static final String LONG_TEXT = "Sehr langer text, der keine Zeilenumbr�che beinhaltet. Wo und wann wird er umgebrochen? Sehen wir uns doch mal dieses Beispiel an."; //$NON-NLS-1$

  public void demoAutoWrappingLabel() {
    AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);
    show(label.getContent());
  }
  
  public void demoAutoWrappingLabelWithWhiteBackground() {
    AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);
    label.setBackground(Color.WHITE);
    show(label.getContent());
  }

  public void demoAutoWrappingLabelInLayout() {
    AutoWrappingLabel label = new AutoWrappingLabel(LONG_TEXT);

    JPanel panel = new JPanel(new BorderLayout());
    panel.add(label.getContent(), BorderLayout.NORTH);
    panel.add(new JLabel("..."), BorderLayout.CENTER); //$NON-NLS-1$

    show(panel);
  }
}
