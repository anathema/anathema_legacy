// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.SystemColor;

import javax.swing.JComponent;

/**
 * A horizontal line that can be used for visual structuring of gui layouts.
 */
public class HorizontalLine extends JComponent {

  public Dimension getMinimumSize() {
    Dimension size = super.getMinimumSize();
    size.height = 2;
    return size;
  }

  public Dimension getMaximumSize() {
    Dimension size = super.getMaximumSize();
    size.height = 2;
    return size;
  }

  public Dimension getPreferredSize() {
    Dimension size = super.getPreferredSize();
    size.height = 2;
    return size;
  }

  protected void paintComponent(Graphics g) {
    g.setColor(SystemColor.controlShadow);
    g.drawLine(0, 0, getSize().width, 0);
    g.setColor(SystemColor.controlLtHighlight);
    g.drawLine(0, 1, getSize().width, 1);
  }
}