// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;

import javax.swing.JComponent;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.SwingColors;

/**
 * A horizontal line that can be used for visual structuring of gui layouts.
 */
public class HorizontalLine extends JComponent {

  private Insets margin = new Insets(0, 0, 0, 0);

  public HorizontalLine() {
    this(100);
  }

  public HorizontalLine(int preferredWidth) {
    setPreferredSize(new Dimension(preferredWidth, 2));
  }

  public Dimension getPreferredSize() {
    final Dimension dimension = super.getPreferredSize();
    return new Dimension(dimension.width + margin.left + margin.right, dimension.height
        + margin.top
        + margin.bottom);
  }

  protected void paintComponent(Graphics g) {
    int y = margin.top + (getSize().height - 2 - margin.top - margin.bottom) / 2;
    g.setColor(SwingColors.getControlShadowColor());
    g.drawLine(margin.left, y, getSize().width - margin.right, y);
    g.setColor(SwingColors.getControlLtHighlightColor());
    g.drawLine(margin.left, y + 1, getSize().width - margin.right, y + 1);
  }

  public void setMargin(Insets margin) {
    Ensure.ensureArgumentNotNull(margin);
    this.margin = margin;
  }
}