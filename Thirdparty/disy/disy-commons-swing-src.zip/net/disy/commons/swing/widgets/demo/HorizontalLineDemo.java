// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.widgets.demo;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.widgets.HorizontalLine;

import de.jdemo.extensions.SwingDemoCase;
 
public class HorizontalLineDemo extends SwingDemoCase {

  public void demoHorizontalLine() {
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(new HorizontalLine(), BorderLayout.NORTH);
    panel.add(new JLabel("Foo, bar..."), BorderLayout.CENTER); //$NON-NLS-1$
    panel.add(new HorizontalLine(), BorderLayout.SOUTH);
    
    JPanel outerPanel = new JPanel(new BorderLayout());
    outerPanel.add(new JLabel("North"), BorderLayout.NORTH); //$NON-NLS-1$
    outerPanel.add(panel, BorderLayout.CENTER);
    outerPanel.add(new JLabel("South"), BorderLayout.SOUTH); //$NON-NLS-1$
    show(outerPanel);
  }

}
