/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.widgets.internal.demo;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.MessageFormat;

import net.disy.commons.swing.widgets.internal.AutoWrappingTextComponent;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class AutoWrappingTextComponentDemo extends SwingDemoCase {

  @Demo
  public void demo() throws MalformedURLException {
    final URL url = new URL("http://www.disy.net");
    final String text = MessageFormat
        .format(
            "Es ist ein lokales Repository mit der URL\n"
                + "{0}\n"
                + "in einer veralteten Version vorhanden.\n"
                + "Das Repository kann von dieser Cadenza-Version nicht gelesen werden.\n\n"
                + "Um Cadenza zu starten, müssen Sie das lokale Repository löschen lassen. Dabei gehen alle lokal gespeicherten Informationssichten und Weiterverarbeitungen verloren.\n\n"
                + "Alternativ können Sie Cadenza beenden.",
            url.toExternalForm());
    final AutoWrappingTextComponent textComponent = new AutoWrappingTextComponent(text, 50);
    show(textComponent);
  }

  @Demo
  public void demoWithSpace() {

    String text = "abc ";
    final AutoWrappingTextComponent textComponent = new AutoWrappingTextComponent(text, 50);
    show(textComponent);
  }

  @Demo
  public void demoWithTwoSpace() {

    String text = "abcsassdfasd abcd asdfss dfsd ";
    final AutoWrappingTextComponent textComponent = new AutoWrappingTextComponent(text, 30);
    show(textComponent);
  }

  @Demo
  public void demoWithoutSpace() {

    String text = "abc";
    final AutoWrappingTextComponent textComponent = new AutoWrappingTextComponent(text, 50);
    show(textComponent);
  }
}