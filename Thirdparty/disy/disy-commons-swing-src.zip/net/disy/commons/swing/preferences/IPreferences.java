// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.preferences;

import java.awt.Color;
import java.io.File;

import net.disy.commons.core.text.font.FontDescription;

// NOT_PUBLISHED
public interface IPreferences {

  public void putString(String key, String value, String defaultValue);

  public void putInt(String key, int value, int defaultValue);

  public void putBoolean(String key, boolean value, boolean defaultValue);

  public int getInt(String key, int defaultValue);

  public boolean getBoolean(String key, boolean defaultValue);

  public IPreferences node(String key);

  public void flush();

  public void remove(String key);

  public void putFontDescription(
      String key,
      FontDescription fontDescription,
      FontDescription defaultFontDescription);

  public void putColor(String key, Color color, Color defaultColor);

  public Color getColor(String key, Color defaultColor);

  public FontDescription getFontDescription(String key, FontDescription defaultFont);

  public String getString(String key);

  public String getString(String key, String defaultValue);

  public String[] getStringArray(String keyPrefix);

  public void putStringArray(String keyPrefix, String[] values);

  public boolean exists(String count_key);

  public void removeNode();

  public void putFile(String key, File selectedFile);

  public File getFile(String preferences_key_default_template);

  public boolean nodeExists(final String key);
}