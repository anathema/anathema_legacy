//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.font.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.swing.font.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(FontFactoryTest.class);
    //$JUnit-END$
    return suite;
  }
}
