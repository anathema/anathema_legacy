//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.font.test;

import java.awt.Font;

import junit.framework.TestCase;

import net.disy.commons.core.graphics.font.FontStyle;
import net.disy.commons.swing.font.FontFactory;

// NOT_PUBLISHED
public class FontFactoryTest extends TestCase {

  public void testGetStyleFromAwt() throws Exception {
    assertEquals(FontStyle.PLAIN, FontFactory.getStyleFromAwt(Font.PLAIN));
    assertEquals(FontStyle.BOLD, FontFactory.getStyleFromAwt(Font.BOLD));
    assertEquals(FontStyle.ITALIC, FontFactory.getStyleFromAwt(Font.ITALIC));
    assertEquals(FontStyle.BOLD_ITALIC, FontFactory.getStyleFromAwt(Font.BOLD | Font.ITALIC));
  }
  
  public void testGetAwtStyle() throws Exception {
    assertEquals(Font.PLAIN, FontFactory.getAwtStyle(FontStyle.PLAIN));
    assertEquals(Font.BOLD, FontFactory.getAwtStyle(FontStyle.BOLD));
    assertEquals(Font.ITALIC, FontFactory.getAwtStyle(FontStyle.ITALIC));
    assertEquals(Font.BOLD | Font.ITALIC, FontFactory.getAwtStyle(FontStyle.BOLD_ITALIC));
  }
}