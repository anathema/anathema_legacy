/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.font;

import java.awt.Font;

import net.disy.commons.core.text.font.FontDescription;
import net.disy.commons.core.text.font.FontStyle;
import net.disy.commons.core.text.font.FontStyleProperty;

public class FontFactory {

  private static final FontStyle[] FONT_STYLE_MAPPING = new FontStyle[]{
      FontStyle.PLAIN,
      FontStyle.BOLD,
      FontStyle.ITALIC,
      FontStyle.BOLD_ITALIC };

  public static FontStyle getStyleFromAwt(final int awtStyle) {
    return FONT_STYLE_MAPPING[awtStyle];
  }

  public static FontStyle getStyle(final Font font) {
    return getStyleFromAwt(font.getStyle());
  }

  public static int getAwtStyle(final FontStyle fontStyle) {
    for (int awtStyle = 0; awtStyle < FONT_STYLE_MAPPING.length; awtStyle++) {
      if (FONT_STYLE_MAPPING[awtStyle].equals(fontStyle)) {
        return awtStyle;
      }
    }
    throw new IllegalArgumentException("Unknown fontstyle " + fontStyle); //$NON-NLS-1$
  }

  public static Font createFont(final String fontFamilyName, final FontStyle style, final int size) {
    return new Font(fontFamilyName, getAwtStyle(style), size);
  }

  public static FontDescription createFontDescription(final Font font) {
    return new FontDescription(font.getFamily(), getStyle(font), font.getSize());
  }

  public static Font createFont(final FontDescription font) {
    return createFont(font.getFontFamilyName(), font.getFontStyle(), font.getFontSize());
  }

  public static int getAwtStyle(final FontStyleProperty fontStyle) {
    return getAwtStyle(FontStyle.PLAIN.derive(fontStyle, true));
  }

}