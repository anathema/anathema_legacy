/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.awt.event.ActionEvent;
import java.lang.reflect.InvocationTargetException;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JTable;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.util.EventDispatchThreadUtilities;

public class SwingTestUtilities {

  public static void waitForEventDispatchThread()
      throws InterruptedException,
      InvocationTargetException {
    SwingUtilities.invokeAndWait(new Runnable() {
      @Override
      public void run() {
        // nothing to do
      }
    });
  }

  public static void executeWhileEdtIsBlocked(final int joinTimeoutInMillis, final Runnable runnable)
      throws InvocationTargetException {
    final JFrame frame = new JFrame();
    final JButton button = new JButton(new AbstractAction() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        final Thread thread = new Thread(runnable);
        thread.start();
        try {
          thread.join(joinTimeoutInMillis);
        }
        catch (final InterruptedException exception) {
          throw new RuntimeException(exception);
        }
        if (thread.isAlive()) {
          stopThread(thread);
        }
      }

      @SuppressWarnings("deprecation")
      private void stopThread(final Thread thread) {
        thread.stop();
      }
    });
    frame.add(button);
    EventDispatchThreadUtilities.invokeAndWait(new Runnable() {
      @Override
      public void run() {
        frame.setVisible(true);
        try {
          button.doClick();
        }
        finally {
          frame.dispose();
        }
      }
    });
  }

  public static String getRenderedText(JComboBox box, Object object) {
    ListCellRenderer renderer = box.getRenderer();
    JList list = new JList();
    JLabel label = (JLabel) renderer.getListCellRendererComponent(list, object, 0, false, false);
    return label.getText();
  }

  public static String getRenderedText(Object object, TableCellRenderer renderer) {
    JLabel rendererComponent = (JLabel) renderer.getTableCellRendererComponent(
        new JTable(),
        object,
        false,
        false,
        0,
        0);
    return rendererComponent.getText();
  }
}