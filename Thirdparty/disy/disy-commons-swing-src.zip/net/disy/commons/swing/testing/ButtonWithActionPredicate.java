package net.disy.commons.swing.testing;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.JButton;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.action.IActionProxy;

public final class ButtonWithActionPredicate implements IPredicate<Component> {
  private final Class<? extends Action> actionClass;

  public ButtonWithActionPredicate(Class<? extends Action> actionClass) {
    this.actionClass = actionClass;
  }

  @Override
  public boolean evaluate(Component value) {
    if (!(value instanceof JButton)) {
      return false;
    }
    JButton button = (JButton) value;
    Action action = button.getAction();
    while (action instanceof IActionProxy && !isSearchedInstance(action)) {
      action = ((IActionProxy) action).getOriginalAction();
    }
    return isSearchedInstance(action);
  }

  private boolean isSearchedInstance(Action action) {
    return actionClass.isInstance(action);
  }
}