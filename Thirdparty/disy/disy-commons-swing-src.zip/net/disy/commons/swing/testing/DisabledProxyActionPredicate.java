/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import javax.swing.Action;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.action.DisableableProxyAction;

public final class DisabledProxyActionPredicate implements IPredicate<Action> {
  private final Action constructedAction;
  private final boolean enabled;

  public DisabledProxyActionPredicate(final Action constructedAction) {
    this(constructedAction, true);
  }

  public DisabledProxyActionPredicate(final Action constructedAction, final boolean enabled) {
    this.constructedAction = constructedAction;
    this.enabled = enabled;
  }

  @Override
  public boolean evaluate(final Action action) {
    final DisableableProxyAction targetProxyAction = new DisableableProxyAction(constructedAction);
    targetProxyAction.setEnabled(enabled);
    return targetProxyAction.equals(action);
  }
}