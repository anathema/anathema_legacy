/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.awt.Component;

import javax.swing.JCheckBox;

import net.disy.commons.core.predicate.AcceptAllPredicate;
import net.disy.commons.core.predicate.IPredicate;

public class IsJCheckBox {

  public static IPredicate<Component> ForText(final String text) {
    return ForPredicate(new HasText<JCheckBox>(text));
  }

  public static IPredicate<Component> ForPredicate(IPredicate<JCheckBox> predicate) {
    return new IsComponentInstanceWith<JCheckBox>(predicate, JCheckBox.class);
  }

  public static IPredicate<Component> Any() {
    return new IsComponentInstanceWith<JCheckBox>(
        new AcceptAllPredicate<JCheckBox>(),
        JCheckBox.class);
  }
}