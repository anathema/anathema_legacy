/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.awt.Component;

import javax.swing.AbstractButton;
import javax.swing.Icon;

import net.disy.commons.core.predicate.IPredicate;

public final class IsButtonWithIcon implements IPredicate<Component> {

  private final Icon expectedIcon;

  public IsButtonWithIcon(final Icon expectedIcon) {
    this.expectedIcon = expectedIcon;
  }

  @Override
  public boolean evaluate(final Component value) {
    if (!(value instanceof AbstractButton)) {
      return false;
    }
    final AbstractButton button = (AbstractButton) value;
    return button.getIcon() == expectedIcon;
  }
}