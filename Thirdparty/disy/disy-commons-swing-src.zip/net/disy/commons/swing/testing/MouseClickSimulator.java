/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.Modifier;

public class MouseClickSimulator {

  public static void clickComponent(final Component textField) {
    final MouseListener[] mouseListeners = textField.getMouseListeners();
    for (int index = 0; index < mouseListeners.length; index++) {
      textField.getMouseListeners()[index].mousePressed(new MouseEvent(
          textField,
          MouseEvent.MOUSE_PRESSED,
          System.currentTimeMillis(),
          Modifier.PUBLIC,
          textField.getLocation().x,
          textField.getLocation().y,
          1,
          false));
    }
  }

}
