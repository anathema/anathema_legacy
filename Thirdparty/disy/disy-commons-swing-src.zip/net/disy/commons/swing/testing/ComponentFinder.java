/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.awt.Component;
import java.awt.Container;

import javax.swing.AbstractButton;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.core.predicate.IPredicate;

public class ComponentFinder {

  public static AbstractButton findButton(
      final Component component,
      final IPredicate<Action> predicate) {
    return (AbstractButton) find(component, new IPredicate<Component>() {
      @Override
      public boolean evaluate(Component value) {
        return value instanceof AbstractButton
            && predicate.evaluate(((AbstractButton) value).getAction());
      }
    });
  }

  @SuppressWarnings("unchecked")
  public static <T extends Component> T find(Component component, IPredicate<Component> predicate) {
    if (predicate.evaluate(component)) {
      return (T) component;
    }
    if (component instanceof Container) {
      Container container = (Container) component;
      for (Component childComponent : container.getComponents()) {
        Component foundChild = find(childComponent, predicate);
        if (foundChild != null) {
          return (T) foundChild;
        }
      }
    }
    return null;
  }

  public static JButton findButtonWithAction(JComponent content, Class<? extends Action> clazz) {
    return (JButton) find(content, new ButtonWithActionPredicate(clazz));
  }
}