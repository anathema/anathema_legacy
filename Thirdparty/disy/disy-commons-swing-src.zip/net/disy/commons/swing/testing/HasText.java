/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.testing;

import java.lang.reflect.Method;

import net.disy.commons.core.predicate.IPredicate;

public final class HasText<T> implements IPredicate<T> {
  private final String text;

  public HasText(String text) {
    this.text = text;
  }

  @SuppressWarnings("nls")
  @Override
  public boolean evaluate(T value) {
    try {
      Method method = value.getClass().getMethod("getText");
      Object name = method.invoke(value);
      return text.equals(name);
    }
    catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}