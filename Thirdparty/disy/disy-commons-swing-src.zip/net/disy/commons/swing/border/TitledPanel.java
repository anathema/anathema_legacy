//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.border;

import java.awt.GridLayout;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.util.GuiUtilities;

// NOT_PUBLISHED
public class TitledPanel extends JPanel {

  public TitledPanel(String title, final JComponent content) {
    this(title, content, new GridDialogLayoutData());
  }

  public TitledPanel(String title, final JComponent content, IGridDialogLayoutData layoutData) {
    super(new GridLayout(1, 0));
    Ensure.ensureArgumentNotNull(title);
    Ensure.ensureArgumentNotNull(content);
    BorderUtilities.attachDisableableTitledBorder(this, new TitledBorder(title));

    setBorder(new CompoundBorder(getBorder(), new EmptyBorder(
        LayoutUtilities.getDpiAdjusted(2),
        LayoutUtilities.getDpiAdjusted(4),
        LayoutUtilities.getDpiAdjusted(4),
        LayoutUtilities.getDpiAdjusted(4))));
    add(content, layoutData);

    content.addPropertyChangeListener(
        GuiUtilities.ENABLED_PROPERTY_NAME,
        new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            setEnabled(content.isEnabled());
          }
        });
    setEnabled(content.isEnabled());
  }
}