/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.border.demo;

import javax.swing.JLabel;

import org.junit.runner.RunWith;

import net.disy.commons.swing.border.TitledPanel;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class TitledPanelDemo extends SwingDemoCase {

  public void demo() {
    show(new TitledPanel("Title", new JLabel("Content"))); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void demoDisabledContent() {
    final JLabel label = new JLabel("Disabled content"); //$NON-NLS-1$
    label.setEnabled(false);
    final TitledPanel titledPanel = new TitledPanel("Title", label); //$NON-NLS-1$
    titledPanel.setTitle("New Border Title"); //$NON-NLS-1$
    show(titledPanel);
  }
}