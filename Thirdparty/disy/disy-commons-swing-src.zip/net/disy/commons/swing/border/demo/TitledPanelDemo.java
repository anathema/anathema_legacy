//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.border.demo;

import javax.swing.JLabel;

import net.disy.commons.swing.border.TitledPanel;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class TitledPanelDemo extends SwingDemoCase {

  public void demo() {
    show(new TitledPanel("Title", new JLabel("Content"))); //$NON-NLS-1$ //$NON-NLS-2$
  }
  
  public void demoDisabledContent() {
    JLabel label = new JLabel("Disabled content"); //$NON-NLS-1$
    label.setEnabled(false);
    show(new TitledPanel("Title", label)); //$NON-NLS-1$ //$NON-NLS-2$
  }
}