/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.model;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.text.TextAlignment;

public class TextAlignmentModel extends AbstractChangeableModel {

  private TextAlignment alignment;

  public TextAlignmentModel(final TextAlignment alignment) {
    this.alignment = alignment;
  }

  public TextAlignment getTextAlignment() {
    return alignment;
  }

  public void setTextAlignment(final TextAlignment alignment) {
    if (this.alignment == alignment) {
      return;
    }
    this.alignment = alignment;
    fireChangeEvent();
  }
}