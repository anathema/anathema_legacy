package net.disy.commons.swing.tree;

import java.awt.Component;

import javax.swing.tree.TreeNode;

/**
 * @author Markus Gebhard
 */
public interface ITreeNodeActionListener {

  public void nodeActionPerformed(Component parentComponent, TreeNode node);

}
