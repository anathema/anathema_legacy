/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.ActionGroupId;
import net.disy.commons.swing.action.GroupedMenuItem;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class SmartTreeDeleteAddition<T> implements ISmartTreeAddition<T> {
  private final IActionConfiguration actionConfiguration;
  private final ISmartTreeDeleteStrategy<T> deleteStrategy;

  public SmartTreeDeleteAddition(final ISmartTreeDeleteStrategy<T> deleteStrategy) {
    this(deleteStrategy, new ActionConfiguration(DisyCommonsSwingMessages
        .getString("SmartTreeRenameAddition.Delete.label"))); //$NON-NLS-1$
  }

  public SmartTreeDeleteAddition(
      final ISmartTreeDeleteStrategy<T> deleteStrategy,
      final IActionConfiguration actionConfiguration) {
    this.deleteStrategy = deleteStrategy;
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public void applyTo(final SmartTreeComponent<T> smartTreeComponent, final EnhancedJTree<T> tree) {
    smartTreeComponent.addActionFactory(new AbstractSmartTreeActionFactory<T>() {

      @Override
      public GroupedMenuItem createMenuItem(final T[] path) {
        final SmartAction action = new SmartAction(actionConfiguration) {
          @Override
          protected void execute(final Component parentComponent) {
            deleteNode(smartTreeComponent, tree, path);
          }

        };
        action.setEnabled(isDeletable(smartTreeComponent.getSmartTree(), path[path.length - 1]));
        return new GroupedMenuItem(action, ActionGroupId.EDIT);
      }
    });

    tree.addKeyListener(new KeyListener() {
      @Override
      public void keyTyped(final KeyEvent e) {
        // nothing to do
      }

      @Override
      public void keyReleased(final KeyEvent e) {
        if (smartTreeComponent.getSelectionModel().isSelectionEmpty()) {
          return;
        }

        if (e.getKeyCode() != KeyEvent.VK_DELETE) {
          return;
        }

        if (!isDeletable(smartTreeComponent.getSmartTree(), smartTreeComponent
            .getSelectionModel()
            .getSelectedNode())) {
          return;
        }

        deleteNode(smartTreeComponent, tree, smartTreeComponent
            .getSelectionModel()
            .getSelectionPath());
      }

      @Override
      public void keyPressed(final KeyEvent e) {
        // nothing to do
      }
    });
  }

  private boolean isDeletable(final ISmartTree<T> smartTree, final T node) {
    return !node.equals(smartTree.getRoot()) && deleteStrategy.isDeletable(node);
  }

  private void deleteNode(
      final SmartTreeComponent<T> smartTreeComponent,
      final EnhancedJTree<T> tree,
      final T[] path) {
    final T parent = path.length > 1 ? path[path.length - 2] : null;
    final T node = path[path.length - 1];
    final SmartTreeModel<T> smartTreeModel = tree.getSmartTreeModel();
    final SmartTreeModelNode<T>[] modelPath = smartTreeModel.getPathInModel(path);
    final int index = smartTreeComponent.getSmartTree().getIndexOfChild(parent, node);
    final SmartTreeModelNode<T> modelParent = modelPath[modelPath.length - 2];
    final SmartTreeModelNode<T> modelNode = modelPath[modelPath.length - 1];
    if (deleteStrategy.deleteNode(tree, parent, index, node)) {
      smartTreeModel.nodeWasRemoved(modelParent, index, modelNode);
    }
  }

}
