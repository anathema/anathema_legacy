/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import javax.swing.tree.TreeNode;

public class TreeNodeSmartTree implements ISmartTree<TreeNode> {

  private final TreeNode root;

  public TreeNodeSmartTree(final TreeNode root) {
    this.root = root;
  }

  @Override
  public TreeNode getChild(final TreeNode parent, final int index) {
    return parent.getChildAt(index);
  }

  @Override
  public int getChildCount(final TreeNode parent) {
    return parent.getChildCount();
  }

  @Override
  public int getIndexOfChild(final TreeNode parent, final TreeNode child) {
    return parent.getIndex(child);
  }

  @Override
  public TreeNode getRoot() {
    return root;
  }

  @Override
  public boolean isLeaf(final TreeNode node) {
    return !node.getAllowsChildren();
  }

  @Override
  public Class<TreeNode> getNodeClass() {
    return TreeNode.class;
  }
}
