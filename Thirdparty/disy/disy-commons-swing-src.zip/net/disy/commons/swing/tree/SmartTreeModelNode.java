/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import net.disy.commons.core.util.Ensure;

public class SmartTreeModelNode<T> {

  private final SmartTreeModelNode<T> parent;
  private final T nodeInSmartTree;

  public SmartTreeModelNode(final SmartTreeModelNode<T> parent, final T node) {
    Ensure.ensureArgumentNotNull(node);
    this.parent = parent;
    this.nodeInSmartTree = node;
  }

  public SmartTreeModelNode<T> getParent() {
    return parent;
  }

  public T getNodeInSmartTree() {
    return nodeInSmartTree;
  }

  @Override
  public boolean equals(final Object object) {
    if (!(object instanceof SmartTreeModelNode)) {
      return false;
    }
    final SmartTreeModelNode other = (SmartTreeModelNode) object;
    return nodeInSmartTree.equals(other.nodeInSmartTree);
  }

  @Override
  public int hashCode() {
    return nodeInSmartTree.hashCode();
  }
}
