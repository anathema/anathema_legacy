/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class SmartTreeRenameAddition<T> implements ISmartTreeAddition<T> {
  private final IActionConfiguration actionConfiguration;
  private final ISmartTreeRenameStrategy<T> renameStrategy;

  public SmartTreeRenameAddition(final ISmartTreeRenameStrategy<T> renameStrategy) {
    this(renameStrategy, new ActionConfiguration(DisyCommonsSwingMessages
        .getString("SmartTreeRenameAddition.Rename.label"))); //$NON-NLS-1$
  }

  public SmartTreeRenameAddition(
      final ISmartTreeRenameStrategy<T> renameStrategy,
      final IActionConfiguration actionConfiguration) {
    this.renameStrategy = renameStrategy;
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public void applyTo(final SmartTreeComponent<T> smartTree, final EnhancedJTree<T> tree) {
    tree.setEditable(true);
    SmartTreeRenameCellEditor.attachTo(tree, renameStrategy);
    tree.getSmartTreeModel().setValueEditor(new ISmartTreeValueEditor<T>() {
      @Override
      public void changeValue(final T smartNode, final Object newValue) {
        renameStrategy.renameTo(smartNode, (String) newValue);
      }
    });
    smartTree
        .addActionFactory(new RenameSmartTreeActionFactory<T>(smartTree, renameStrategy, actionConfiguration));
  }
}
