/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.ArrayUtilities;

public class SmartTreeSelectionModel<T> extends AbstractChangeableModel {

  private final TreeSelectionModel selectionModel;
  private final SmartTreeModel<T> treeModel;

  public SmartTreeSelectionModel(
      final TreeSelectionModel selectionModel,
      final SmartTreeModel<T> treeModel) {
    this.selectionModel = selectionModel;
    this.treeModel = treeModel;
    selectionModel.addTreeSelectionListener(new TreeSelectionListener() {
      @Override
      public void valueChanged(final TreeSelectionEvent e) {
        fireChangeEvent();
      }
    });
  }

  public void setSelectionPath(final T[] path) {
    selectionModel.setSelectionPath(new TreePath(treeModel.getPathInModel(path)));
  }

  @SuppressWarnings("unchecked")
  public T[] getSelectionPath() {
    final TreePath selectionPath = selectionModel.getSelectionPath();
    if (selectionPath == null) {
      return null;
    }
    return treeModel.getPathInSmartTree(ArrayUtilities.transform(
        selectionPath.getPath(),
        SmartTreeModelNode.class));
  }

  public T getSelectedNode() {
    final T[] selectionPath = getSelectionPath();
    return selectionPath == null ? null : selectionPath[selectionPath.length - 1];
  }

  public boolean isSelectionEmpty() {
    return selectionModel.isSelectionEmpty();
  }

}
