/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DragGestureEvent;
import java.awt.dnd.DragGestureListener;
import java.awt.dnd.DragSource;
import java.awt.dnd.DragSourceDragEvent;
import java.awt.dnd.DragSourceDropEvent;
import java.awt.dnd.DragSourceEvent;
import java.awt.dnd.DragSourceListener;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.dnd.DropTargetListener;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JTree;
import javax.swing.tree.TreePath;

import net.disy.commons.swing.color.ColorUtilities;
import net.disy.commons.swing.color.SwingColors;

public class SmartTreeMoveAddition<T> implements ISmartTreeAddition<T> {
  private DragSource dragSource;
  private int currentDropLineIndex = -1;

  private SmartTreeModelNode<T> draggingTreeNode;

  private Timer nodeToggleTimer;
  private SmartTreeModelNode<T> togglingNode;
  private final ISmartTreeMoveStrategy<T> moveStrategy;
  private final DataFlavor defaultDataFlavor;

  public SmartTreeMoveAddition(
      final ISmartTreeMoveStrategy<T> moveStrategy,
      final DataFlavor defaultDataFlavor) {
    this.moveStrategy = moveStrategy;
    this.defaultDataFlavor = defaultDataFlavor;
  }

  @Override
  public void applyTo(final SmartTreeComponent<T> smartTreeComponent, final EnhancedJTree<T> tree) {
    final ISmartTree<T> smartTree = smartTreeComponent.getSmartTree();
    dragSource = DragSource.getDefaultDragSource();
    dragSource.createDefaultDragGestureRecognizer(
        tree,
        DnDConstants.ACTION_MOVE,
        new DragGestureListener() {
          @Override
          public void dragGestureRecognized(final DragGestureEvent dragGestureEvent) {
            SmartTreeMoveAddition.this.dragGestureRecognized(dragGestureEvent, tree);
          }
        });
    final DropTarget dropTarget = new DropTarget(tree, new DropTargetListener() {
      @Override
      public void dragEnter(DropTargetDragEvent evt) {
        //nothing to do
      }

      @Override
      public void dragOver(DropTargetDragEvent evt) {
        Point location = evt.getLocation();
        setCurrentDropLineIndex(tree, tree.getClosestRowForLocation(location.x, location.y));

        TreePath draggedTreePath = tree.getClosestPathForLocation(location.x, location.y);
        SmartTreeModelNode<T> node = (SmartTreeModelNode<T>) draggedTreePath.getLastPathComponent();
        if (smartTree.getChildCount(node.getNodeInSmartTree()) > 0) {
          startNodeToggleTimer(tree, node);
        }
        else {
          cancelNodeToggleTimer();
        }
      }

      @Override
      public void dropActionChanged(DropTargetDragEvent evt) {
        cancelNodeToggleTimer();
      }

      @Override
      public void dragExit(DropTargetEvent evt) {
        cancelNodeToggleTimer();
        setCurrentDropLineIndex(tree, -1);
      }

      @Override
      public void drop(DropTargetDropEvent evt) {
        SmartTreeMoveAddition.this.drop(tree, smartTree);
      }
    });
    dropTarget.setDefaultActions(DnDConstants.ACTION_COPY_OR_MOVE);

    tree.addAdditionalPainter(new IPainter() {
      @Override
      public void paint(final Graphics g) {
        if (getCurrentDropLineIndex() != -1) {
          paintDrag(tree, smartTree, g);
        }
      }
    });
  }

  protected void drop(final EnhancedJTree<T> tree, final ISmartTree<T> smartTree) {
    cancelNodeToggleTimer();
    final int dropLineIndex = getCurrentDropLineIndex();
    setCurrentDropLineIndex(tree, -1);

    final SmartTreeModel<T> model = tree.getSmartTreeModel();
    final SmartTreeModelNode<T> oldParent = draggingTreeNode.getParent();
    final int oldIndex = smartTree.getIndexOfChild(oldParent.getNodeInSmartTree(), draggingTreeNode
        .getNodeInSmartTree());
    final TreePath dropLinePath = tree.getPathForRow(dropLineIndex);
    if (dropLinePath == null) {
      return;
    }
    final SmartTreeModelNode<T> dropLineTreeNode = (SmartTreeModelNode<T>) dropLinePath
        .getLastPathComponent();
    SmartTreeModelNode<T> newParentTreeNode;
    int newIndex;
    if (model.isLeaf(dropLineTreeNode)) {
      newParentTreeNode = (SmartTreeModelNode<T>) dropLinePath
          .getParentPath()
          .getLastPathComponent();
      newIndex = model.getIndexOfChild(newParentTreeNode, dropLineTreeNode) + 1;
    }
    else {
      newParentTreeNode = dropLineTreeNode;
      if (tree.isExpanded(dropLineIndex)) {
        newIndex = 0;
      }
      else {
        newIndex = smartTree.getChildCount(dropLineTreeNode.getNodeInSmartTree());
      }
    }
    if (oldParent == newParentTreeNode && oldIndex < newIndex) {
      newIndex--;
    }
    if (tree.getSmartTreeModel().isAncestorOrSame(draggingTreeNode, newParentTreeNode)) {
      return;
    }
    moveStrategy.handleNodeMoved(draggingTreeNode.getNodeInSmartTree(), oldParent
        .getNodeInSmartTree(), newParentTreeNode.getNodeInSmartTree(), newIndex);
    model.nodeWasRemoved(oldParent, oldIndex, draggingTreeNode);
    model.nodeWasInserted(newParentTreeNode, newIndex);
  }

  public void dragGestureRecognized(final DragGestureEvent dragGestureEvent, final JTree tree) {
    if (tree.getSelectionCount() != 1) {
      return;
    }

    final TreePath path = tree.getSelectionPath();
    if (tree.isEditing() || path == null) {
      return;
    }
    draggingTreeNode = (SmartTreeModelNode<T>) path.getLastPathComponent();
    if (draggingTreeNode == tree.getModel().getRoot()
        || !moveStrategy.isMovableTreeNode(draggingTreeNode.getNodeInSmartTree())) {
      draggingTreeNode = null;
      return;
    }

    final TreeNodeTransferableAdapter<T> node = new TreeNodeTransferableAdapter<T>(draggingTreeNode
        .getNodeInSmartTree(), defaultDataFlavor);

    final DragSourceListener dragSourceListener = new DragSourceListener() {
      @Override
      public void dragDropEnd(DragSourceDropEvent evt) {
        //nothing to do
      }

      @Override
      public void dragEnter(DragSourceDragEvent evt) {
        //nothing to do
      }

      @Override
      public void dragExit(DragSourceEvent evt) {
        //nothing to do
      }

      @Override
      public void dragOver(DragSourceDragEvent evt) {
        //nothing to do
      }

      @Override
      public void dropActionChanged(DragSourceDragEvent evt) {
        //nothing to do
      }
    };
    dragSource.startDrag(dragGestureEvent, DragSource.DefaultMoveDrop, node, dragSourceListener);
  }

  private void setCurrentDropLineIndex(final EnhancedJTree tree, final int currentDragLineIndex) {
    if (this.currentDropLineIndex == currentDragLineIndex) {
      return;
    }

    this.currentDropLineIndex = currentDragLineIndex;
    tree.repaint();
  }

  private synchronized void startNodeToggleTimer(
      final EnhancedJTree<T> tree,
      final SmartTreeModelNode<T> node) {
    if (node == togglingNode) {
      return;
    }
    cancelNodeToggleTimer();
    this.togglingNode = node;

    final TreePath tp = new TreePath(tree.getSmartTreeModel().getPathToRoot(togglingNode));
    int delay = 0;
    if (tree.isExpanded(tp)) {
      delay = 2000;
    }
    else {
      delay = 1000;
    }

    nodeToggleTimer = new Timer();
    nodeToggleTimer.schedule(new TimerTask() {
      @Override
      public void run() {
        final TreePath treePath = new TreePath(tree.getSmartTreeModel().getPathToRoot(togglingNode));
        toggleExpanded(tree, treePath);
        togglingNode = null;
        tree.repaint();
      }
    },
        delay);
  }

  private synchronized void cancelNodeToggleTimer() {
    if (nodeToggleTimer != null) {
      nodeToggleTimer.cancel();
      nodeToggleTimer = null;
      togglingNode = null;
    }
  }

  public final void toggleExpanded(final EnhancedJTree<T> tree, final TreePath path) {
    if (tree.isExpanded(path)) {
      tree.collapsePath(path);
    }
    else {
      tree.expandPath(path);
    }
  }

  private int getCurrentDropLineIndex() {
    return currentDropLineIndex;
  }

  private Color getDropTargetLineColor(final EnhancedJTree<T> tree) {
    Color lineColor = SwingColors.getTreeLineColor();
    if (lineColor == null) {
      lineColor = Color.BLACK;
    }
    final Color backgroundColor = tree.getBackground();
    return ColorUtilities.createIntermediateColor(lineColor, backgroundColor);
  }

  private void paintDrag(
      final EnhancedJTree<T> tree,
      final ISmartTree<T> smartTree,
      final Graphics g) {
    final TreePath draggedTreePath = tree.getPathForRow(getCurrentDropLineIndex());
    final Rectangle r = tree.getUI().getPathBounds(tree, draggedTreePath);
    g.setColor(getDropTargetLineColor(tree));
    final SmartTreeModelNode<T> node = (SmartTreeModelNode<T>) draggedTreePath
        .getLastPathComponent();
    if (!smartTree.isLeaf(node.getNodeInSmartTree())) {
      //Folder
      final int y = r.y + r.height;
      final int x0 = r.x + 9;
      final int x1 = x0 + Math.max(40, r.width);
      g.drawLine(x0, y - 2, x0, y - 1);
      g.drawLine(x0, y - 1, x0 + 2, y + 1);
      g.drawLine(x0 + 2, y + 1, x1, y + 1);
    }
    else {
      //No Folder
      final int levelWidth = 16;
      final int y = r.y + r.height;
      final int x0 = r.x - levelWidth + 3;
      final int x1 = x0 + Math.max(40, r.width) + levelWidth;
      g.drawLine(x0, y - 7, x0, y - 4);
      g.drawLine(x0, y - 4, x0 + 4, y);
      g.drawLine(x0 + 4, y, x1, y);
    }
  }

}
