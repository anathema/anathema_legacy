/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree.demo;

import java.awt.Component;
import java.awt.datatransfer.DataFlavor;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;

import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.tree.ISmartTreeDeleteStrategy;
import net.disy.commons.swing.tree.ISmartTreeMoveStrategy;
import net.disy.commons.swing.tree.ISmartTreeRenameStrategy;
import net.disy.commons.swing.tree.SmartTreeComponent;
import net.disy.commons.swing.tree.SmartTreeDeleteAddition;
import net.disy.commons.swing.tree.SmartTreeMoveAddition;
import net.disy.commons.swing.tree.SmartTreeRenameAddition;
import net.disy.commons.swing.tree.TreeNodeSmartTree;
import net.disy.commons.swing.tree.test.TestDemoTreeFactory;
import net.disy.commons.swing.ui.DefaultObjectUi;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class SmartTreeComponentDemo extends SwingDemoCase {
  private SmartTreeComponent<TreeNode> tree;
  private SmartTreeRenameAddition<TreeNode> renameSmartTreeAddition;
  private SmartTreeMoveAddition<TreeNode> moveSmartTreeAddition;
  private SmartTreeDeleteAddition<TreeNode> deleteSmartTreeAddition;

  @Override
  protected void setUp() throws Exception {
    super.setUp();

    final TreeNodeSmartTree smartTree = TestDemoTreeFactory.createTree();

    final ISmartTreeRenameStrategy<TreeNode> renameStrategy = new ISmartTreeRenameStrategy<TreeNode>() {
      @Override
      public boolean isRenameable(final TreeNode node) {
        return node != smartTree.getRoot();
      }

      @Override
      public String getOriginalName(final TreeNode node) {
        return String.valueOf(((DefaultMutableTreeNode) node).getUserObject());
      }

      @Override
      public boolean isValidNewName(final TreeNode node, final String newName) {
        return !StringUtilities.isNullOrEmpty(newName);
      }

      @Override
      public void renameTo(final TreeNode node, final String newName) {
        ((DefaultMutableTreeNode) node).setUserObject(newName);
      }
    };

    renameSmartTreeAddition = new SmartTreeRenameAddition<TreeNode>(renameStrategy);

    final ISmartTreeMoveStrategy<TreeNode> dragAndDropStrategy = new ISmartTreeMoveStrategy<TreeNode>() {
      @Override
      public boolean isMovableTreeNode(final TreeNode node) {
        return true;
      }

      @Override
      public void handleNodeMoved(
          final TreeNode node,
          final TreeNode oldParent,
          final TreeNode newParent,
          final int newIndexInParent) {
        final DefaultMutableTreeNode mutableNode = (DefaultMutableTreeNode) node;
        final DefaultMutableTreeNode mutableParent = (DefaultMutableTreeNode) newParent;
        mutableNode.removeFromParent();
        mutableParent.insert(mutableNode, newIndexInParent);
      }
    };

    final DataFlavor dataFlavor = new DataFlavor(TreeNode.class, "Tree Node"); //$NON-NLS-1$

    tree = new SmartTreeComponent<TreeNode>(smartTree, new DefaultObjectUi<TreeNode>());

    moveSmartTreeAddition = new SmartTreeMoveAddition<TreeNode>(dragAndDropStrategy, dataFlavor);

    final ISmartTreeDeleteStrategy<TreeNode> deleteStrategy = new ISmartTreeDeleteStrategy<TreeNode>() {
      @Override
      public boolean isDeletable(final TreeNode node) {
        return true;
      }

      @Override
      public boolean deleteNode(
          final Component parentComponent,
          final TreeNode parentNode,
          final int index,
          final TreeNode node) {
        final DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node;
        treeNode.removeFromParent();
        return true;
      }
    };

    deleteSmartTreeAddition = new SmartTreeDeleteAddition<TreeNode>(deleteStrategy);
  }

  public void demoSimple() {
    show(tree.getContent());
  }

  public void demoRename() {
    tree.applyAddition(renameSmartTreeAddition);
    show(tree.getContent());
  }

  public void demoMove() {
    tree.applyAddition(moveSmartTreeAddition);
    show(tree.getContent());
  }

  public void demoDelete() {
    tree.applyAddition(deleteSmartTreeAddition);
    show(tree.getContent());
  }

  public void demoAll() {
    tree.applyAddition(renameSmartTreeAddition);
    tree.applyAddition(moveSmartTreeAddition);
    tree.applyAddition(deleteSmartTreeAddition);
    show(tree.getContent());
  }
}