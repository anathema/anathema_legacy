/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.util.LinkedList;

import javax.swing.event.TreeModelEvent;
import javax.swing.event.TreeModelListener;
import javax.swing.tree.TreeModel;
import javax.swing.tree.TreePath;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;
import net.disy.commons.core.util.ITransformer;

public class SmartTreeModel<T> implements TreeModel {
  private final transient ListenerList<TreeModelListener> listeners = new ListenerList<TreeModelListener>();

  private final ISmartTree<T> smartTree;

  private ISmartTreeValueEditor<T> valueEditor;

  public SmartTreeModel(final ISmartTree<T> smartTree) {
    Ensure.ensureArgumentNotNull(smartTree);
    this.smartTree = smartTree;
  }

  @Override
  public SmartTreeModelNode<T> getRoot() {
    return new SmartTreeModelNode<T>(null, smartTree.getRoot());
  }

  @Override
  public SmartTreeModelNode<T> getChild(final Object parent, final int index) {
    final SmartTreeModelNode<T> smartParent = (SmartTreeModelNode<T>) parent;
    return new SmartTreeModelNode<T>(smartParent, smartTree.getChild(smartParent
        .getNodeInSmartTree(), index));
  }

  @Override
  public int getChildCount(final Object parent) {
    return smartTree.getChildCount(getNodeInSmartTree(parent));
  }

  private T getNodeInSmartTree(final Object node) {
    final SmartTreeModelNode<T> smartNode = (SmartTreeModelNode<T>) node;
    return smartNode.getNodeInSmartTree();
  }

  public T[] getPathInSmartTree(final SmartTreeModelNode<T>[] pathInModel) {
    return ArrayUtilities.transform(
        pathInModel,
        smartTree.getNodeClass(),
        new ITransformer<SmartTreeModelNode<T>, T>() {
          @Override
          public T transform(final SmartTreeModelNode<T> input) {
            return input.getNodeInSmartTree();
          }
        });
  }

  @Override
  public int getIndexOfChild(final Object parent, final Object child) {
    return smartTree.getIndexOfChild(getNodeInSmartTree(parent), getNodeInSmartTree(child));
  }

  @Override
  public boolean isLeaf(final Object node) {
    return smartTree.isLeaf(getNodeInSmartTree(node));
  }

  public void setValueEditor(final ISmartTreeValueEditor<T> valueEditor) {
    this.valueEditor = valueEditor;
  }

  @Override
  public void valueForPathChanged(final TreePath path, final Object newValue) {
    final Object node = path.getLastPathComponent();
    final T smartNode = getNodeInSmartTree(node);
    if (valueEditor != null) {
      valueEditor.changeValue(smartNode, newValue);
    }
    nodeChanged((SmartTreeModelNode<T>) node);
  }

  @Override
  public void addTreeModelListener(final TreeModelListener listener) {
    listeners.add(listener);
  }

  @Override
  public void removeTreeModelListener(final TreeModelListener listener) {
    listeners.remove(listener);
  }

  private void nodeChanged(final SmartTreeModelNode<T> node) {
    final SmartTreeModelNode<T> parent = node.getParent();
    if (parent != null) {
      fireTreeNodesChanged(getPathToRoot(parent), new int[]{ smartTree.getIndexOfChild(parent
          .getNodeInSmartTree(), node.getNodeInSmartTree()) }, new SmartTreeModelNode[]{ node });
    }
    else {
      fireTreeNodesChanged(getPathToRoot(node), null, null);
    }
  }

  public void nodeWasRemoved(
      final SmartTreeModelNode<T> parent,
      final int index,
      final SmartTreeModelNode<T> child) {
    fireTreeNodesRemoved(
        getPathToRoot(parent),
        new int[]{ index },
        new SmartTreeModelNode[]{ child });
  }

  public void nodeWasInserted(final SmartTreeModelNode<T> parent, final int index) {
    fireTreeNodesInserted(
        getPathToRoot(parent),
        new int[]{ index },
        new SmartTreeModelNode[]{ getChild(parent, index) });
  }

  public SmartTreeModelNode<T>[] getPathToRoot(SmartTreeModelNode<T> node) {
    final LinkedList<SmartTreeModelNode<T>> path = new LinkedList<SmartTreeModelNode<T>>();
    while (node != null) {
      path.addFirst(node);
      node = node.getParent();
    }

    return path.toArray(new SmartTreeModelNode[path.size()]);
  }

  public boolean isAncestorOrSame(
      final SmartTreeModelNode<T> possibleAncestor,
      final SmartTreeModelNode<T> possibleDescendant) {
    for (SmartTreeModelNode<T> actualNode = possibleDescendant; actualNode != null; actualNode = actualNode
        .getParent()) {
      if (actualNode == possibleAncestor) {
        return true;
      }
    }
    return false;
  }

  public SmartTreeModelNode<T>[] getPathInModel(final T[] path) {
    final SmartTreeModelNode<T>[] modelPath = new SmartTreeModelNode[path.length];
    SmartTreeModelNode<T> parent = null;
    for (int i = 0; i < path.length; i++) {
      parent = new SmartTreeModelNode<T>(parent, path[i]);
      modelPath[i] = parent;
    }

    return modelPath;
  }

  private void fireTreeNodesChanged(
      final SmartTreeModelNode<T>[] path,
      final int[] childIndices,
      final SmartTreeModelNode<T>[] children) {
    listeners.forAllDo(new IClosure<TreeModelListener>() {
      @Override
      public void execute(final TreeModelListener listener) {
        listener.treeNodesChanged(new TreeModelEvent(this, path, childIndices, children));
      }
    });
  }

  private void fireTreeNodesRemoved(
      final SmartTreeModelNode<T>[] path,
      final int[] childIndices,
      final SmartTreeModelNode<T>[] children) {
    listeners.forAllDo(new IClosure<TreeModelListener>() {
      @Override
      public void execute(final TreeModelListener listener) {
        listener.treeNodesRemoved(new TreeModelEvent(this, path, childIndices, children));
      }
    });
  }

  private void fireTreeNodesInserted(
      final SmartTreeModelNode<T>[] path,
      final int[] childIndices,
      final SmartTreeModelNode<T>[] children) {
    listeners.forAllDo(new IClosure<TreeModelListener>() {
      @Override
      public void execute(final TreeModelListener listener) {
        listener.treeNodesInserted(new TreeModelEvent(this, path, childIndices, children));
      }
    });
  }
}