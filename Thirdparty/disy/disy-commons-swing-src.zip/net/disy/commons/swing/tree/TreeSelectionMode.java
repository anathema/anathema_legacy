/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import javax.swing.tree.TreeSelectionModel;

public class TreeSelectionMode {

  private final int treeSelectionMode;

  private TreeSelectionMode(final int treeSelectionMode) {
    this.treeSelectionMode = treeSelectionMode;
  }

  public int getTreeSelectionMode() {
    return treeSelectionMode;
  }

  public final static TreeSelectionMode SINGLE_TREE_SELECTION = new TreeSelectionMode(
      TreeSelectionModel.SINGLE_TREE_SELECTION);

  public final static TreeSelectionMode DISCONTIGUOUS_TREE_SELECTION = new TreeSelectionMode(
      TreeSelectionModel.DISCONTIGUOUS_TREE_SELECTION);

  public final static TreeSelectionMode CONTIGUOUS_TREE_SELECTION = new TreeSelectionMode(
      TreeSelectionModel.CONTIGUOUS_TREE_SELECTION);

}