/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree.test;

import javax.swing.tree.DefaultMutableTreeNode;

import net.disy.commons.swing.tree.TreeNodeSmartTree;

public class TestDemoTreeFactory {

  public static TreeNodeSmartTree createTree() {
    final DefaultMutableTreeNode root = new DefaultMutableTreeNode("JTree"); //$NON-NLS-1$
    final DefaultMutableTreeNode parent1 = new DefaultMutableTreeNode("colors", true); //$NON-NLS-1$
    root.add(parent1);
    parent1.add(new DefaultMutableTreeNode("blue", false)); //$NON-NLS-1$
    parent1.add(new DefaultMutableTreeNode("violet", false)); //$NON-NLS-1$
    parent1.add(new DefaultMutableTreeNode("red", false)); //$NON-NLS-1$
    parent1.add(new DefaultMutableTreeNode("yellow", false)); //$NON-NLS-1$

    final DefaultMutableTreeNode parent2 = new DefaultMutableTreeNode("sports", true); //$NON-NLS-1$
    root.add(parent2);
    parent2.add(new DefaultMutableTreeNode("basketball", false)); //$NON-NLS-1$
    parent2.add(new DefaultMutableTreeNode("soccer", false)); //$NON-NLS-1$
    parent2.add(new DefaultMutableTreeNode("football", false)); //$NON-NLS-1$
    parent2.add(new DefaultMutableTreeNode("hockey", false)); //$NON-NLS-1$

    final DefaultMutableTreeNode parent3 = new DefaultMutableTreeNode("food", true); //$NON-NLS-1$
    root.add(parent3);
    parent3.add(new DefaultMutableTreeNode("hot dogs", false)); //$NON-NLS-1$
    parent3.add(new DefaultMutableTreeNode("pizza", false)); //$NON-NLS-1$
    parent3.add(new DefaultMutableTreeNode("ravioli", false)); //$NON-NLS-1$
    parent3.add(new DefaultMutableTreeNode("bananas", false)); //$NON-NLS-1$

    final DefaultMutableTreeNode parent4 = new DefaultMutableTreeNode("empty", true); //$NON-NLS-1$
    root.add(parent4);
    return new TreeNodeSmartTree(root);
  }
}