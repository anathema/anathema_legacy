/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.Component;

import net.disy.commons.swing.action.ActionGroupId;
import net.disy.commons.swing.action.GroupedMenuItem;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;

public class RenameSmartTreeActionFactory<T> extends AbstractSmartTreeActionFactory<T> {
  private final SmartTreeComponent<T> smartTree;
  private final IActionConfiguration actionConfiguration;
  private final ISmartTreeRenameStrategy<T> renameStrategy;

  public RenameSmartTreeActionFactory(
      SmartTreeComponent<T> smartTree,
      ISmartTreeRenameStrategy<T> renameStrategy,
      IActionConfiguration actionConfiguration) {
    this.smartTree = smartTree;
    this.renameStrategy = renameStrategy;
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public GroupedMenuItem createMenuItem(final T[] path) {
    final SmartAction action = new SmartAction(actionConfiguration) {
      @Override
      protected void execute(Component parentComponent) {
        smartTree.startEditing(path);
      }
    };
    action.setEnabled(renameStrategy.isRenameable(path[path.length - 1]));
    return new GroupedMenuItem(action, ActionGroupId.EDIT);
  }
}