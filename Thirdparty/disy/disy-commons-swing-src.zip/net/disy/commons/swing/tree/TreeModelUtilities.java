/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.util.LinkedList;

import javax.swing.tree.TreeModel;
import javax.swing.tree.TreeNode;

public class TreeModelUtilities {
  public static TreeNode[] getPathToRoot(final TreeModel treeModel, TreeNode node) {
    final LinkedList<TreeNode> path = new LinkedList<TreeNode>();
    while (node != treeModel.getRoot()) {
      if (node == null) {
        return null;
      }
      path.addFirst(node);
      node = node.getParent();
    }

    path.addFirst(node);
    return path.toArray(new TreeNode[path.size()]);
  }

  public static boolean isAncestorOrSame(
      final TreeNode possibleAncestor,
      final TreeNode possibleDescendant) {
    for (TreeNode actualNode = possibleDescendant; actualNode != null; actualNode = actualNode
        .getParent()) {
      if (actualNode == possibleAncestor) {
        return true;
      }
    }
    return false;
  }
}