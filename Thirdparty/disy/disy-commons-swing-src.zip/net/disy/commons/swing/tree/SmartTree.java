package net.disy.commons.swing.tree;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTree;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.ListenerList;

/**
 * @author Markus Gebhard
 */
public class SmartTree extends JTree {

  private final ListenerList/*<ITreeNodeActionListener>*/nodeActionListeners = new ListenerList();

  private int lastRowClickIndex = -1;

  public SmartTree(TreeNode rootNode) {
    super(rootNode);

    addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() == 1) {
          lastRowClickIndex = getRowForLocation(e.getX(), e.getY());
        }
        if (e.getClickCount() != 2 || e.isMetaDown()) {
          return;
        }
        int rowIndex = getRowForLocation(e.getX(), e.getY());
        if (rowIndex == -1 || lastRowClickIndex != rowIndex) {
          lastRowClickIndex = -1;
          return;
        }
        lastRowClickIndex = -1;
        TreePath path = getPathForRow(rowIndex);
        fireNodeActionPerformed((TreeNode) path.getLastPathComponent());
      }
    });
  }

  public void addNodeActionListener(ITreeNodeActionListener listener) {
    nodeActionListeners.add(listener);
  }

  public void removeNodeActionListener(ITreeNodeActionListener listener) {
    nodeActionListeners.add(listener);
  }

  public void fireNodeActionPerformed(final TreeNode node) {
    nodeActionListeners.forAllDo(new IListenerClosure() {
      public void execute(Object input) {
        ((ITreeNodeActionListener) input).nodeActionPerformed(SmartTree.this, node);
      }
    });
  }
}