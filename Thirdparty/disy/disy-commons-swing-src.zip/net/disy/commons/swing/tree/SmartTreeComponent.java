/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.tree.TreePath;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionGroupMenuBuilder;
import net.disy.commons.swing.action.GroupedMenuItem;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.ui.IObjectUi;

public class SmartTreeComponent<T> implements IComponentContainer {

  private final ListenerList<ITreeNodeActionListener<T>> nodeActionListeners = new ListenerList<ITreeNodeActionListener<T>>();
  private final JComponent content;
  private final EnhancedJTree<T> tree;
  private final SmartTreeSelectionModel<T> selectionModel;
  private final List<ISmartTreeActionFactory<T>> actionFactories = new ArrayList<ISmartTreeActionFactory<T>>();
  private ISmartTree<T> smartTree;

  public SmartTreeComponent(final ISmartTree<T> smartTree, final IObjectUi<T> objectUi) {
    this.smartTree = smartTree;
    Ensure.ensureArgumentNotNull(smartTree);
    Ensure.ensureArgumentNotNull(objectUi);
    tree = new EnhancedJTree<T>(smartTree, objectUi);
    tree.addMouseListener(new TreeDoubleClickMouseActionListener<T>(nodeActionListeners));
    this.content = new JScrollPane(tree);
    selectionModel = new SmartTreeSelectionModel<T>(tree.getSelectionModel(), tree
        .getSmartTreeModel());

    tree.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseReleased(final MouseEvent event) {
        if (event.isMetaDown()) {
          showContextMenu(event);
        }
      }
    });
  }

  private void showContextMenu(MouseEvent event) {
    T[] selectionPath = getSelectionModel().getSelectionPath();
    ActionGroupMenuBuilder menuBuilder = new ActionGroupMenuBuilder();
    for (ISmartTreeActionFactory<T> actionFactory : actionFactories) {
      if (!actionFactory.supportsPath(selectionPath)) {
        continue;
      }
      GroupedMenuItem menuItem = actionFactory.createMenuItem(selectionPath);
      if (menuItem != GroupedMenuItem.NO_ITEM) {
        menuBuilder.add(menuItem);
      }
    }
    if (menuBuilder.isEmpty()) {
      return;
    }
    JPopupMenu contextMenu = menuBuilder.createPopupMenu();
    tree.add(contextMenu);
    contextMenu.show(tree, event.getX(), event.getY());
  }

  public ISmartTree<T> getSmartTree() {
    return smartTree;
  }

  @Override
  public JComponent getContent() {
    return content;
  }

  public final void addNodeActionListener(final ITreeNodeActionListener<T> listener) {
    nodeActionListeners.add(listener);
  }

  public final void removeNodeActionListener(final ITreeNodeActionListener<T> listener) {
    nodeActionListeners.add(listener);
  }

  public void setRootVisible(final boolean rootVisible) {
    tree.setRootVisible(rootVisible);
    tree.setShowsRootHandles(!rootVisible);
  }

  public void setSmartTree(final ISmartTree<T> smartTree) {
    this.smartTree = smartTree;
    tree.setModel(new SmartTreeModel<T>(smartTree));
  }

  public SmartTreeSelectionModel<T> getSelectionModel() {
    return selectionModel;
  }

  public void expandPath(final T[] path) {
    tree.expandPath(new TreePath(tree.getSmartTreeModel().getPathInModel(path)));
  }

  public void addActionFactory(final ISmartTreeActionFactory<T> actionFactory) {
    actionFactories.add(actionFactory);
  }

  public void applyAddition(final ISmartTreeAddition<T> addition) {
    addition.applyTo(this, tree);
  }

  public void setSelectionMode(final TreeSelectionMode selectionMode) {
    tree.getSelectionModel().setSelectionMode(selectionMode.getTreeSelectionMode());
  }

  public void nodeInserted(final T[] nodePath) {
    final SmartTreeModel<T> smartTreeModel = tree.getSmartTreeModel();
    final SmartTreeModelNode<T>[] pathInModel = smartTreeModel.getPathInModel(nodePath);
    smartTreeModel.nodeWasInserted(pathInModel[pathInModel.length - 2], smartTree.getIndexOfChild(
        nodePath[nodePath.length - 2],
        nodePath[nodePath.length - 1]));
  }

  public void startEditing(final T[] path) {
    tree.startEditingAtPath(new TreePath(tree.getSmartTreeModel().getPathInModel(path)));
  }
}