/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTree;

public class RightMouseClickTreeSelectionMouseListener extends MouseAdapter {

  @Override
  public void mousePressed(final MouseEvent event) {
    if (!event.isMetaDown()) {
      return;
    }
    final JTree tree = (JTree) event.getComponent();
    final int selectedRow = tree.getRowForLocation(event.getX(), event.getY());
    if (selectedRow != -1 && !tree.isRowSelected(selectedRow)) {
      tree.setSelectionRow(selectedRow);
    }
  }
}