/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.AbstractCellEditor;
import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.tree.TreeCellEditor;
import javax.swing.tree.TreePath;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.icon.EmptyIcon;

/**
 * @author Markus Gebhard
 */
public class SmartTreeRenameCellEditor<T> extends AbstractCellEditor
    implements
    TreeCellEditor,
    FocusListener {

  private final JTree tree;
  private final ISmartTreeRenameStrategy<T> renameStrategy;
  private final JTextField textField;

  private SmartTreeModelNode<T> editingNode;
  private TreePath lastPath;

  private SmartTreeRenameCellEditor(
      final JTree tree,
      final ISmartTreeRenameStrategy<T> renameStrategy) {
    Ensure.ensureArgumentNotNull(tree);
    Ensure.ensureArgumentNotNull(renameStrategy);
    this.tree = tree;
    this.renameStrategy = renameStrategy;

    final Border aBorder = UIManager.getBorder("Tree.editorBorder"); //$NON-NLS-1$
    textField = new JTextField(12);
    textField.setBorder(aBorder);
    textField.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent arg0) {
        stopCellEditing();
      }
    });
    textField.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(final FocusEvent evt) {
        //nothing to do
      }

      @Override
      public void focusLost(final FocusEvent evt) {
        stopCellEditing();
      }
    });
  }

  public static <T> void attachTo(final JTree tree, final ISmartTreeRenameStrategy<T> renameStrategy) {
    final SmartTreeRenameCellEditor editor = new SmartTreeRenameCellEditor<T>(tree, renameStrategy);
    tree.setCellEditor(editor);
    tree.addFocusListener(editor);
  }

  @Override
  public Object getCellEditorValue() {
    return textField.getText();
  }

  @Override
  public Component getTreeCellEditorComponent(
      final JTree theTree,
      final Object selectedNode,
      final boolean isSelected,
      final boolean isExpanded,
      final boolean leaf,
      final int row) {

    final SmartTreeModelNode<T> treeNode = (SmartTreeModelNode<T>) selectedNode;
    editingNode = treeNode;

    final Component rendererComponent = tree.getCellRenderer().getTreeCellRendererComponent(
        tree,
        selectedNode,
        isSelected,
        isExpanded,
        leaf,
        row,
        true);

    final Icon icon;
    if (rendererComponent instanceof JLabel) {
      final JLabel label = (JLabel) rendererComponent;
      icon = label.getIcon();
    }
    else {
      icon = new EmptyIcon();
    }

    textField.setText(renameStrategy.getOriginalName(treeNode.getNodeInSmartTree()));
    textField.selectAll();
    final JPanel panel = new JPanel();
    panel.setLayout(new BorderLayout());
    panel.add(new JLabel(icon), BorderLayout.WEST);
    panel.add(textField, BorderLayout.CENTER);
    panel.setBackground(tree.getBackground());
    return panel;
  }

  @Override
  public boolean isCellEditable(final EventObject event) {
    if (event == null) {
      //Seems only to happen when
      // - editing is started programmatically e.g. when creating a new node
      // - F2 key is being pressed
      final TreePath selectionPath = tree.getSelectionPath();
      if (selectionPath == null) {
        return false;
      }
      final SmartTreeModelNode<T> node = (SmartTreeModelNode<T>) selectionPath
          .getLastPathComponent();
      return renameStrategy.isRenameable(node.getNodeInSmartTree());
    }

    if (!(event.getSource() instanceof JTree)) {
      return false;
    }
    if (!(event instanceof MouseEvent)) {
      return true;
    }
    final MouseEvent mouseEvent = (MouseEvent) event;
    if (mouseEvent.isMetaDown()) {
      lastPath = null;
      return false;
    }
    if (mouseEvent.getClickCount() == 2) {
      return false;
    }
    final TreePath path = tree.getPathForLocation(mouseEvent.getX(), mouseEvent.getY());
    if (path == null) {
      return false;
    }
    final Rectangle nodeBounds = tree.getUI().getPathBounds(tree, path);
    final SmartTreeModelNode<T> node = (SmartTreeModelNode<T>) path.getLastPathComponent();
    if (!renameStrategy.isRenameable(node.getNodeInSmartTree())) {
      return false;
    }
    final int iconWidth = 16;
    final Rectangle boundsWithoutIcon = new Rectangle(
        nodeBounds.x + iconWidth,
        nodeBounds.y,
        nodeBounds.width - iconWidth,
        nodeBounds.height);
    if (!boundsWithoutIcon.contains(mouseEvent.getPoint())) {
      return false;
    }
    if (lastPath != null && lastPath.equals(path)) {
      lastPath = null;
      return true;
    }
    lastPath = path;
    return false;
  }

  @Override
  public boolean shouldSelectCell(final EventObject anEvent) {
    return true;
  }

  @Override
  public boolean stopCellEditing() {
    final String newName = textField.getText();
    final boolean success = !StringUtilities.isNullOrEmpty(newName)
        && renameStrategy.isValidNewName(editingNode.getNodeInSmartTree(), newName);
    if (success) {
      fireEditingStopped();
    }
    else {
      Toolkit.getDefaultToolkit().beep();
    }
    return success;
  }

  @Override
  public void cancelCellEditing() {
    fireEditingCanceled();
  }

  @Override
  public void focusGained(final FocusEvent arg0) {
    //nothing to do
  }

  @Override
  public void focusLost(final FocusEvent arg0) {
    lastPath = null;
  }
}