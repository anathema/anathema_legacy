/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree.test;

import static org.junit.Assert.assertEquals;

import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;

import javax.swing.tree.TreeNode;

import net.disy.commons.swing.tree.EnhancedJTree;
import net.disy.commons.swing.tree.TreeNodeSmartTree;
import net.disy.commons.swing.ui.DefaultObjectUi;

import org.junit.Test;

public class EnhancedJTreeTest {

  @Test
  public void testNoEmptyTooltipForRegionOutSideNodes_disyTIPI415() {
    final TreeNodeSmartTree smartTree = TestDemoTreeFactory.createTree();
    final EnhancedJTree<TreeNode> tree = new EnhancedJTree<TreeNode>(
        smartTree,
        new DefaultObjectUi<TreeNode>());
    final Dimension treeComponentSize = new Dimension(200, 300);
    tree.setSize(treeComponentSize);
    tree.setLocation(0, 0);
    final MouseEvent event = createMouseEventInsideTreeComponentButBelowLastNode(
        tree,
        treeComponentSize);
    assertEquals(null, tree.getToolTipText(event));
  }

  @Test
  public void testTooltipShownForRootNode() {
    final TreeNodeSmartTree smartTree = TestDemoTreeFactory.createTree();
    final DefaultObjectUi<TreeNode> objectUi = new DefaultObjectUi<TreeNode>();
    final EnhancedJTree<TreeNode> tree = new EnhancedJTree<TreeNode>(smartTree, objectUi);
    final Dimension treeComponentSize = new Dimension(200, 300);
    tree.setSize(treeComponentSize);
    tree.setLocation(0, 0);
    final MouseEvent event = createMouseEventForToolTipOnRootNode(tree);
    assertEquals(objectUi.getToolTipText(smartTree.getRoot()), tree.getToolTipText(event));
  }

  private MouseEvent createMouseEventForToolTipOnRootNode(final EnhancedJTree<TreeNode> tree) {
    final Rectangle rootNodeRowBounds = tree.getRowBounds(0);
    final int x = 5;
    final int y = rootNodeRowBounds.y + rootNodeRowBounds.height / 2;
    return new MouseEvent(tree, 0, 0, 0, x, y, 0, 0, 0, true, 0);
  }

  private MouseEvent createMouseEventInsideTreeComponentButBelowLastNode(
      final EnhancedJTree<TreeNode> tree,
      final Dimension treeComponentSize) {
    final int y = treeComponentSize.height - 5;
    final int x = treeComponentSize.width / 2;
    return new MouseEvent(tree, 0, 0, 0, x, y, 0, 0, 0, true, 0);
  }
}