/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JTree;
import javax.swing.tree.TreePath;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;

public final class TreeDoubleClickMouseActionListener<T> extends MouseAdapter {

  private final ListenerList<ITreeNodeActionListener<T>> nodeActionListeners;
  private int lastRowClickIndex = -1;

  public TreeDoubleClickMouseActionListener(
      final ListenerList<ITreeNodeActionListener<T>> nodeActionListeners) {
    Ensure.ensureArgumentNotNull(nodeActionListeners);
    this.nodeActionListeners = nodeActionListeners;
  }

  @Override
  public void mouseClicked(final MouseEvent e) {
    final JTree tree = (JTree) e.getSource();
    if (e.getClickCount() == 1) {
      lastRowClickIndex = tree.getRowForLocation(e.getX(), e.getY());
    }
    if (e.getClickCount() != 2 || e.isMetaDown()) {
      return;
    }
    final int rowIndex = tree.getRowForLocation(e.getX(), e.getY());
    if (rowIndex == -1 || lastRowClickIndex != rowIndex) {
      lastRowClickIndex = -1;
      return;
    }
    lastRowClickIndex = -1;
    final TreePath path = tree.getPathForRow(rowIndex);
    fireNodeActionPerformed(tree, (SmartTreeModelNode<T>) path.getLastPathComponent());
  }

  private final void fireNodeActionPerformed(final JTree tree, final SmartTreeModelNode<T> node) {
    nodeActionListeners.forAllDo(new IClosure<ITreeNodeActionListener<T>>() {
      @Override
      public void execute(final ITreeNodeActionListener<T> listener) {
        listener.nodeActionPerformed(tree, node.getNodeInSmartTree());
      }
    });
  }
}