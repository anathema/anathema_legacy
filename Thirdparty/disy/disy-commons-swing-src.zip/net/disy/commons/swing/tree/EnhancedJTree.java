/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.tree;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.dnd.Autoscroll;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.ToolTipManager;

import net.disy.commons.swing.ui.DelegatingObjectUi;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiTreeCellRenderer;

public class EnhancedJTree<T> extends JTree implements Autoscroll {

  private final static Insets AUTOSCROLL_INSETS = new Insets(5, 5, 5, 5);

  private final List<IPainter> additinalPainters = new ArrayList<IPainter>();

  public EnhancedJTree(final ISmartTree<T> smartTree, final IObjectUi<T> objectUi) {
    super(new SmartTreeModel<T>(smartTree));
    activateToolTips();
    setCellRenderer(new ObjectUiTreeCellRenderer(new DelegatingObjectUi<SmartTreeModelNode<T>, T>(
        objectUi) {
      @Override
      protected T getDelegatingValue(final SmartTreeModelNode<T> value) {
        return value.getNodeInSmartTree();
      }
    }));
    addMouseListener(new RightMouseClickTreeSelectionMouseListener());
  }

  private void activateToolTips() {
    final ToolTipManager toolTipManager = ToolTipManager.sharedInstance();
    toolTipManager.registerComponent(this);
  }

  public void addAdditionalPainter(final IPainter painter) {
    additinalPainters.add(painter);
  }

  @Override
  public Insets getAutoscrollInsets() {
    final Rectangle r = getVisibleRect();
    final Dimension size = getSize();
    final Insets i = new Insets(
        r.y + AUTOSCROLL_INSETS.top,
        r.x + AUTOSCROLL_INSETS.left,
        size.height - r.y - r.height + AUTOSCROLL_INSETS.bottom,
        size.width - r.x - r.width + AUTOSCROLL_INSETS.right);
    return i;
  }

  @Override
  public void autoscroll(final Point location) {
    final JScrollPane scroller = (JScrollPane) SwingUtilities.getAncestorOfClass(
        JScrollPane.class,
        this);
    if (scroller != null) {
      final JScrollBar hBar = scroller.getHorizontalScrollBar();
      final JScrollBar vBar = scroller.getVerticalScrollBar();
      final Rectangle r = getVisibleRect();
      if (location.x <= r.x + AUTOSCROLL_INSETS.left) {
        // Need to scroll left
        hBar.setValue(hBar.getValue() - hBar.getUnitIncrement(-1));
      }
      if (location.y <= r.y + AUTOSCROLL_INSETS.top) {
        // Need to scroll up
        vBar.setValue(vBar.getValue() - vBar.getUnitIncrement(-1));
      }
      if (location.x >= r.x + r.width - AUTOSCROLL_INSETS.right) {
        // Need to scroll right
        hBar.setValue(hBar.getValue() + hBar.getUnitIncrement(1));
      }
      if (location.y >= r.y + r.height - AUTOSCROLL_INSETS.bottom) {
        // Need to scroll down
        vBar.setValue(vBar.getValue() + vBar.getUnitIncrement(1));
      }
    }
  }

  @Override
  protected void paintComponent(final Graphics g) {
    super.paintComponent(g);

    for (final IPainter painter : additinalPainters) {
      painter.paint(g);
    }
  }

  public SmartTreeModel<T> getSmartTreeModel() {
    return (SmartTreeModel<T>) getModel();
  }
}