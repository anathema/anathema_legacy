/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.geometry.test;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.geometry.SmartRectangle;

public class SmartRectangleTest extends CoreTestCase {

  public void testTranslated() throws Exception {
    final SmartRectangle rectangle = new SmartRectangle(2, 3, 12, 13);
    final SmartRectangle translated = rectangle.createTranslated(2, 4);
    assertNotSame(rectangle, translated);
    assertEquals("X Coordinate", 4, translated.x); //$NON-NLS-1$
    assertEquals("Y Coordinate", 7, translated.y); //$NON-NLS-1$
    assertEquals("Width", 12, translated.width); //$NON-NLS-1$
    assertEquals("Height", 13, translated.height); //$NON-NLS-1$
  }

  public void testEnlarged() throws Exception {
    final SmartRectangle rectangle = new SmartRectangle(2, 3, 12, 13);
    final SmartRectangle enlarged = rectangle.createEnlarged(3);
    assertNotSame(rectangle, enlarged);
    assertEquals("X Coordinate", -1, enlarged.x); //$NON-NLS-1$
    assertEquals("Y Coordinate", 0, enlarged.y); //$NON-NLS-1$
    assertEquals("Width", 18, enlarged.width); //$NON-NLS-1$
    assertEquals("Height", 19, enlarged.height); //$NON-NLS-1$
  }
}