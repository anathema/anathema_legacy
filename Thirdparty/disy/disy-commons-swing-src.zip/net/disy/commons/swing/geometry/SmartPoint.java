/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.geometry;

import java.awt.Point;
import java.awt.Rectangle;

public class SmartPoint extends Point {

  public SmartPoint(final int x, final int y) {
    super(x, y);
  }

  public SmartPoint(final Point point) {
    super(point);
  }

  public Point getVectorTo(final Point point) {
    return new Point(point.x - x, point.y - y);
  }

  public void limitTo(final Rectangle limits) {
    x = Math.min(Math.max(x, limits.x), limits.x + limits.width);
    y = Math.min(Math.max(y, limits.y), limits.y + limits.height);
  }

  public void subtract(final Point subtrahend) {
    x -= subtrahend.x;
    y -= subtrahend.y;
  }
}