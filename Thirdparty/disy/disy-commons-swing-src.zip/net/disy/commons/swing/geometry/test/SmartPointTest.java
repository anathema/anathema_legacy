/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.geometry.test;

import java.awt.Point;
import java.awt.Rectangle;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.geometry.SmartPoint;

public class SmartPointTest extends CoreTestCase {

  public void testSubtract() throws Exception {
    final Point subtrahend = new Point(3, 5);
    final SmartPoint smartPoint = new SmartPoint(4, 7);
    smartPoint.subtract(subtrahend);
    assertEquals(1.0, smartPoint.getX(), 0.0);
    assertEquals(2.0, smartPoint.getY(), 0.0);
  }

  public void testGetVectorTo() throws Exception {
    final SmartPoint smartPoint = new SmartPoint(1, 2);
    final Point samePoint = new Point(1, 2);
    assertEquals(new Point(0, 0), smartPoint.getVectorTo(samePoint));
    assertEquals(new Point(3, 4), smartPoint.getVectorTo(new Point(4, 6)));
    assertEquals(new Point(2, -2), smartPoint.getVectorTo(new Point(3, 0)));
    assertEquals(new Point(-1, -3), smartPoint.getVectorTo(new Point(0, -1)));
    assertEquals(new Point(-2, 3), smartPoint.getVectorTo(new Point(-1, 5)));
  }

  public void testLimitTo_pointsOnEdgeOrInsideRectangle() throws Exception {
    final Rectangle rectangle = new Rectangle(1, 2, 3, 4);
    assertNotChangedByLimit(1, 3, rectangle);
    assertNotChangedByLimit(4, 3, rectangle);
    assertNotChangedByLimit(3, 2, rectangle);
    assertNotChangedByLimit(3, 6, rectangle);
    assertNotChangedByLimit(3, 3, rectangle);
  }

  public void testLimitTo_pointsOutsideRectangle() throws Exception {
    final Rectangle rectangle = new Rectangle(1, 2, 3, 4);
    assertChangedProperlyByLimit(0, 3, rectangle, 1, 3);
    assertChangedProperlyByLimit(5, 3, rectangle, 4, 3);
    assertChangedProperlyByLimit(3, 1, rectangle, 3, 2);
    assertChangedProperlyByLimit(3, 7, rectangle, 3, 6);
  }

  private void assertNotChangedByLimit(final int x, final int y, final Rectangle rectangle) {
    final SmartPoint smartPoint = new SmartPoint(x, y);
    smartPoint.limitTo(rectangle);
    assertEquals(new SmartPoint(x, y), smartPoint);
  }

  private void assertChangedProperlyByLimit(
      final int x,
      final int y,
      final Rectangle rectangle,
      final int newX,
      final int newY) {
    final SmartPoint smartPoint = new SmartPoint(x, y);
    smartPoint.limitTo(rectangle);
    assertEquals(new SmartPoint(newX, newY), smartPoint);
  }
}
