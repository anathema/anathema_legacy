// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 07.07.2004
package net.disy.commons.swing.util;

import java.awt.Component;

import javax.swing.JOptionPane;

// NOT_PUBLISHED
public class JOptionPaneUtilities {
  
  private JOptionPaneUtilities() {
    // nothing to do
  }

  public static boolean confirmUserOperation(Component parent, String message, String title) {
    parent = net.disy.commons.swing.util.GuiUtilities.getWindowForComponent(parent);
    int optionType = JOptionPane.YES_NO_OPTION;
    int messageType = JOptionPane.QUESTION_MESSAGE;
    int confirmOption = JOptionPane.showConfirmDialog(
        parent,
        message,
        title,
        optionType,
        messageType);
    return confirmOption == JOptionPane.OK_OPTION;
  }

}