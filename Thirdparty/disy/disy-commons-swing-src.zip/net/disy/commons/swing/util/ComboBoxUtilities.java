/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util;

import java.util.Collection;

import javax.swing.DefaultComboBoxModel;

public class ComboBoxUtilities {

  private ComboBoxUtilities() {
    // nothing to do
  }

  public static void setComboBoxItems(
      final DefaultComboBoxModel comboBoxModel,
      final Collection<?> allItems) {
    comboBoxModel.removeAllElements();
    for (final Object bearbeiter : allItems) {
      comboBoxModel.addElement(bearbeiter);
    }
  }
}