/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.test;

import static junit.framework.Assert.assertEquals;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.image.BufferedImage;

import javax.swing.JFrame;

import net.disy.commons.swing.util.GuiUtilities;

import org.junit.Test;

import sun.awt.HeadlessToolkit;
import sun.awt.image.BufferedImageGraphicsConfig;

public class GuiUtilitiesTest {
  @Test
  public void testCalculateScreenBounds_noInsets() throws Exception {
    final Rectangle expected = new Rectangle(10, 20, 30, 40);
    final Toolkit toolkit = new HeadlessToolkit(null) {
      @Override
      public Insets getScreenInsets(final GraphicsConfiguration arg0) {
        return new Insets(0, 0, 0, 0);
      }
    };
    final Rectangle actual = GuiUtilities.calculateScreenBounds(
        createGraphicsConfigurationWithScreenBounds(expected),
        toolkit);
    assertEquals(expected, actual);
  }

  @Test
  public void testCalculateScreenBounds_differentInsets() throws Exception {
    final Rectangle screenBounds = new Rectangle(0, 0, 40, 30);
    final Toolkit toolkit = new HeadlessToolkit(null) {
      @Override
      public Insets getScreenInsets(final GraphicsConfiguration arg0) {
        return new Insets(1, 2, 3, 4);
      }
    };
    final Rectangle actual = GuiUtilities.calculateScreenBounds(
        createGraphicsConfigurationWithScreenBounds(screenBounds),
        toolkit);
    assertEquals(new Rectangle(2, 1, 34, 26), actual);
  }

  @Test
  public void testAssureIsOnScreen_WindowAlreadyOnScreen() throws Exception {
    final Dimension size = new Dimension(10, 20);
    final Point location = new Point(5, 5);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 30);
    GuiUtilities.assureIsOnScreen(window, screenBounds);
    assertEquals(size, window.getSize());
    assertEquals(location, window.getLocation());
  }

  @Test
  public void testAssureIsOnScreen_WindowTooWide() throws Exception {
    final Dimension size = new Dimension(20, 10);
    final Point location = new Point(0, 5);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 15, 20);
    GuiUtilities.assureIsOnScreen(window, screenBounds);
    assertEquals(new Dimension(15, 10), window.getSize());
    assertEquals(location, window.getLocation());
  }

  @Test
  public void testAssureIsOnScreen_WindowTooLong() throws Exception {
    final Dimension size = new Dimension(10, 20);
    final Point location = new Point(5, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 10);
    GuiUtilities.assureIsOnScreen(window, screenBounds);
    assertEquals(new Dimension(10, 10), window.getSize());
    assertEquals(location, window.getLocation());
  }

  @Test
  public void testAssureIsOnScreen_WindowPartiallyOutsideScreen() throws Exception {
    final Dimension size = new Dimension(10, 20);
    final Point location = new Point(5, 5);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 10, 20);
    GuiUtilities.assureIsOnScreen(window, screenBounds);
    assertEquals(size, window.getSize());
    assertEquals(new Point(0, 0), window.getLocation());
  }

  @Test
  public void testAssureIsOnScreen_WindowPartiallyOutsideScreenAndTooHighAndTooWide()
      throws Exception {
    final Dimension size = new Dimension(15, 25);
    final Point location = new Point(5, 5);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 10, 20);
    GuiUtilities.assureIsOnScreen(window, screenBounds);
    assertEquals(new Dimension(10, 20), window.getSize());
    assertEquals(new Point(0, 0), window.getLocation());
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarLeft() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(-5, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(0, 0), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarRight() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(30, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(10, 0), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarAbove() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(0, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 10, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(0, 10), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarBelow() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(0, 30);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(0, 10), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarRightAndTooFarAbove() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(30, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 10, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(10, 10), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarLeftAndTooFarAbove() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(0, 0);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(10, 10, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(10, 10), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarRightAndTooFarBelow() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(30, 30);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(0, 0, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(10, 10), newLocation);
  }

  @Test
  public void testCalculateScreenFittingLocation_WindowTooFarLeftAndTooFarBelowe() throws Exception {
    final Dimension size = new Dimension(10, 10);
    final Point location = new Point(0, 30);
    final Window window = createWindow(size, location);
    final Rectangle screenBounds = new Rectangle(10, 0, 20, 20);
    final Point newLocation = GuiUtilities.calculateScreenFittingLocation(screenBounds, window
        .getBounds());
    assertEquals(size, window.getSize());
    assertEquals(new Point(10, 10), newLocation);
  }

  private Window createWindow(final Dimension size, final Point location) {
    final Window window = new Window(new Frame());
    window.setSize(size);
    window.setLocation(location);
    return window;
  }

  private GraphicsConfiguration createGraphicsConfigurationWithScreenBounds(final Rectangle bounds) {
    return new BufferedImageGraphicsConfig(new BufferedImage(1, 1, 1), null) {
      @Override
      public Rectangle getBounds() {
        return bounds;
      }
    };
  }

  @Test
  public void testAssureIsOnScreenDoesNotChangeMaximizedStateOfFrame() {
    final JFrame frame = new JFrame();
    if (!frame.getToolkit().isFrameStateSupported(Frame.MAXIMIZED_BOTH)) {
      return; //on build system with virtual framebuffer this frame state might not be supported
    }
    frame.setVisible(true);
    frame.setExtendedState(Frame.MAXIMIZED_BOTH);
    //On linux systems state is being set asynchronously! So: Wait until being set.
    while (frame.getExtendedState() != Frame.MAXIMIZED_BOTH) {
      Thread.yield();
    }
    GuiUtilities.assureIsOnScreen(frame);
    assertEquals(Frame.MAXIMIZED_BOTH, frame.getExtendedState());
    frame.dispose();
  }
}