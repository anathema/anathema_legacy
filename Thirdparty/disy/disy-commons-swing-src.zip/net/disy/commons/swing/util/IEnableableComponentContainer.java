//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.util;

import net.disy.commons.swing.component.IComponentContainer;

// NOT_PUBLISHED
public interface IEnableableComponentContainer extends IComponentContainer {

  public void setEnabled(boolean enabled);

  public boolean isEnabled();

}