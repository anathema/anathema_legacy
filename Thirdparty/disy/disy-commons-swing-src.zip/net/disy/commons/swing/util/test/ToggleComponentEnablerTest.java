/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.test;

import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import junit.framework.TestCase;

import net.disy.commons.swing.util.ToggleComponentEnabler;

public class ToggleComponentEnablerTest extends TestCase {

  private class DummyComponent extends JComponent {
    public void doClick() {
      processMouseEvent(new MouseEvent(this, MouseEvent.MOUSE_PRESSED, 0, 0, 0, 0, 1, false));
    }
  }

  private JRadioButton button2;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    final JRadioButton button1 = new JRadioButton();
    button2 = new JRadioButton();
    final ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    button1.doClick();
  }

  public void testClickDecoration() throws Exception {
    final DummyComponent decoration = new DummyComponent();
    ToggleComponentEnabler.connectWithDecoration(button2, new JComponent[0], decoration);
    decoration.doClick();
    assertTrue(button2.isSelected());
  }

  public void testDisableButton() throws Exception {
    final JComponent component = new JTextField();
    final JLabel label = new JLabel();
    button2.doClick();
    ToggleComponentEnabler.connectWithDecoration(button2, component, label);
    button2.setEnabled(false);
    assertFalse(label.isEnabled());
    assertFalse(component.isEnabled());
  }

  public void testDisabledButtonClickComponent() throws Exception {
    final DummyComponent component = new DummyComponent();
    ToggleComponentEnabler.connect(button2, component);
    button2.setEnabled(false);
    component.doClick();
    assertFalse(button2.isSelected());
  }

  public void testDisableButtonWithTwoDecorations() throws Exception {
    final JLabel label = new JLabel();
    final JLabel label2 = new JLabel();
    ToggleComponentEnabler.connectWithDecorations(button2, new JComponent[0], new JComponent[]{
        label,
        label2 });
    button2.setEnabled(false);
    assertFalse(label.isEnabled());
    assertFalse(label2.isEnabled());
  }

}
