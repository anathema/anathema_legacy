//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.util.test;

import java.awt.Component;
import java.awt.event.MouseEvent;

import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import junit.framework.TestCase;

import net.disy.commons.swing.util.ToggleComponentEnabler;

public class ToggleComponentEnablerTest extends TestCase {

  private class DummyComponent extends Component {
    public void doClick() {
      processMouseEvent(new MouseEvent(this, MouseEvent.MOUSE_PRESSED, 0, 0, 0, 0, 1, false));
    }
  }

  private JRadioButton button2;

  protected void setUp() throws Exception {
    super.setUp();
    JRadioButton button1 = new JRadioButton();
    button2 = new JRadioButton();
    ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    button1.doClick();
  }

  public void testClickDecoration() throws Exception {
    DummyComponent decoration = new DummyComponent();
    ToggleComponentEnabler.connect(button2, new Component[0], decoration);
    decoration.doClick();
    assertTrue(button2.isSelected());
  }

  public void testDisableButton() throws Exception {
    Component component = new JTextField();
    JLabel label = new JLabel();
    button2.doClick();
    ToggleComponentEnabler.connect(button2, component, label);
    button2.setEnabled(false);
    assertFalse(label.isEnabled());
    assertFalse(component.isEnabled());
  }

  public void testDisabledButtonClickComponent() throws Exception {
    DummyComponent component = new DummyComponent();
    ToggleComponentEnabler.connect(button2, component);
    button2.setEnabled(false);
    component.doClick();
    assertFalse(button2.isSelected());
  }

  public void testDisableButtonWithTwoDecorations() throws Exception {
    JLabel label = new JLabel();
    JLabel label2 = new JLabel();
    ToggleComponentEnabler.connect(button2, new Component[0], new Component[] { label, label2 });
    button2.setEnabled(false);
    assertFalse(label.isEnabled());
    assertFalse(label2.isEnabled());
  }

}
