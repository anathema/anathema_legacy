/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.test;

import static org.junit.Assert.*;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.Modifier;

import javax.swing.AbstractAction;
import javax.swing.JPanel;

import net.disy.commons.swing.util.GuiUtilities;

import org.junit.Test;

public class GuiUtilities_AddActionToComponent_Test {

  @Test
  public void mouseClickPerformsAction() throws Exception {
    final Component component = new JPanel();
    final MockAction action = new MockAction(true);
    GuiUtilities.addClickActionTo(component, action);
    clickComponent(component);
    action.verify();
  }

  @Test
  public void mouseClickOnDisabledComponentDoesNotPerformAction() {
    final Component component = new JPanel();
    component.setEnabled(false);
    final MockAction action = new MockAction(false);
    GuiUtilities.addClickActionTo(component, action);
    clickComponent(component);
    action.verify();
  }

  @Test
  public void mouseClickDoesNotPerformDisabledAction() {
    final Component component = new JPanel();
    final MockAction action = new MockAction(false);
    action.setEnabled(false);
    GuiUtilities.addClickActionTo(component, action);
    clickComponent(component);
    action.verify();
  }

  private void clickComponent(final Component component) {
    final MouseListener[] mouseListeners = component.getMouseListeners();
    for (int index = 0; index < mouseListeners.length; index++) {
      component.getMouseListeners()[index].mousePressed(new MouseEvent(
          component,
          MouseEvent.MOUSE_PRESSED,
          System.currentTimeMillis(),
          Modifier.PUBLIC,
          component.getLocation().x,
          component.getLocation().y,
          1,
          false));
    }
  }

  private class MockAction extends AbstractAction {
    private boolean executed = false;
    private final boolean expected;

    public MockAction(final boolean expected) {
      this.expected = expected;
    }

    @Override
    public void actionPerformed(final ActionEvent e) {
      this.executed = true;
    }

    public void verify() {
      assertEquals(
          expected
              ? "Expected execution of action did not occur." : "Unexpected execution of action.", expected, executed); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }
}
