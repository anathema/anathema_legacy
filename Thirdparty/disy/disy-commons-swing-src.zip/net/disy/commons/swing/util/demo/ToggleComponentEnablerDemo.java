// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.util.demo;

import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import net.disy.commons.swing.util.ToggleComponentEnabler;

import de.jdemo.extensions.SwingDemoCase;

public class ToggleComponentEnablerDemo extends SwingDemoCase {
  public void demoToggleComponentEnabler() {
    JRadioButton button1 = new JRadioButton("button 1:", true); //$NON-NLS-1$
    JTextField textfield1 = new JTextField("textfield1"); //$NON-NLS-1$
    JRadioButton button2 = new JRadioButton("button 2:", false); //$NON-NLS-1$
    JTextField textfield2 = new JTextField("textfield2"); //$NON-NLS-1$
    JLabel label2 = new JLabel("label"); //$NON-NLS-1$

    JRadioButton button3 = new JRadioButton("button 3:", false); //$NON-NLS-1$
    JComboBox combo3 = new JComboBox(new String[]{ "item1", "item2" }); //$NON-NLS-1$ //$NON-NLS-2$

    ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    group.add(button3);

    ToggleComponentEnabler.connect(button1, textfield1);
    ToggleComponentEnabler.connect(button2, new Component[]{ label2, textfield2 });
    ToggleComponentEnabler.connect(button3, combo3);

    JPanel panel = new JPanel(new GridLayout(0, 3, 2, 2));
    panel.add(button1);
    panel.add(textfield1);
    panel.add(Box.createGlue());
    panel.add(button2);
    panel.add(label2);
    panel.add(textfield2);
    panel.add(button3);
    panel.add(combo3);
    show(panel);
  }

  public void demoDecorations() {
    JRadioButton button1 = new JRadioButton("button 1:", true); //$NON-NLS-1$
    JTextField textfield1 = new JTextField("textfield1"); //$NON-NLS-1$
    final JRadioButton button2 = new JRadioButton("button 2:", false); //$NON-NLS-1$
    JTextField textfield2 = new JTextField("textfield2"); //$NON-NLS-1$
    JLabel label2 = new JLabel("decoration"); //$NON-NLS-1$

    JRadioButton button3 = new JRadioButton("button 3:", false); //$NON-NLS-1$
    JComboBox combo3 = new JComboBox(new String[]{ "item1", "item2" }); //$NON-NLS-1$//$NON-NLS-2$

    ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    group.add(button3);

    ToggleComponentEnabler.connect(button1, textfield1);
    ToggleComponentEnabler.connect(button2, textfield2, label2);
    ToggleComponentEnabler.connect(button3, combo3);

    JPanel panel = new JPanel(new GridLayout(0, 4, 2, 2));
    panel.add(Box.createGlue());
    panel.add(button1);
    panel.add(textfield1);
    panel.add(Box.createGlue());
    final JCheckBox checkbox = new JCheckBox("disabled"); //$NON-NLS-1$
    checkbox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        button2.setEnabled(!checkbox.isSelected());
      }
    });
    panel.add(checkbox);
    panel.add(button2);
    panel.add(label2);
    panel.add(textfield2);
    panel.add(Box.createGlue());
    panel.add(button3);
    panel.add(combo3);
    show(panel);
  }
}