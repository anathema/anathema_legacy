/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.demo;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import org.junit.runner.RunWith;

import net.disy.commons.swing.util.ToggleComponentEnabler;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class ToggleComponentEnablerDemo extends SwingDemoCase {
  public void demoToggleComponentEnabler() {
    final JRadioButton button1 = new JRadioButton("button 1:", true); //$NON-NLS-1$
    final JTextField textfield1 = new JTextField("textfield1"); //$NON-NLS-1$
    final JRadioButton button2 = new JRadioButton("button 2:", false); //$NON-NLS-1$
    final JTextField textfield2 = new JTextField("textfield2"); //$NON-NLS-1$
    final JLabel label2 = new JLabel("label"); //$NON-NLS-1$

    final JRadioButton button3 = new JRadioButton("button 3:", false); //$NON-NLS-1$
    final JComboBox combo3 = new JComboBox(new String[]{ "item1", "item2" }); //$NON-NLS-1$ //$NON-NLS-2$

    final ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    group.add(button3);

    ToggleComponentEnabler.connect(button1, textfield1);
    ToggleComponentEnabler.connect(button2, new JComponent[]{ label2, textfield2 });
    ToggleComponentEnabler.connect(button3, combo3);

    final JPanel panel = new JPanel(new GridLayout(0, 3, 2, 2));
    panel.add(button1);
    panel.add(textfield1);
    panel.add(Box.createGlue());
    panel.add(button2);
    panel.add(label2);
    panel.add(textfield2);
    panel.add(button3);
    panel.add(combo3);
    show(panel);
  }

  public void demoDecorations() {
    final JRadioButton button1 = new JRadioButton("button 1:", true); //$NON-NLS-1$
    final JTextField textfield1 = new JTextField("textfield1"); //$NON-NLS-1$
    final JRadioButton button2 = new JRadioButton("button 2:", false); //$NON-NLS-1$
    final JTextField textfield2 = new JTextField("textfield2"); //$NON-NLS-1$
    final JLabel label2 = new JLabel("decoration"); //$NON-NLS-1$

    final JRadioButton button3 = new JRadioButton("button 3:", false); //$NON-NLS-1$
    final JComboBox combo3 = new JComboBox(new String[]{ "item1", "item2" }); //$NON-NLS-1$//$NON-NLS-2$

    final ButtonGroup group = new ButtonGroup();
    group.add(button1);
    group.add(button2);
    group.add(button3);

    ToggleComponentEnabler.connect(button1, textfield1);
    ToggleComponentEnabler.connectWithDecoration(button2, textfield2, label2);
    ToggleComponentEnabler.connect(button3, combo3);

    final JPanel panel = new JPanel(new GridLayout(0, 4, 2, 2));
    panel.add(Box.createGlue());
    panel.add(button1);
    panel.add(textfield1);
    panel.add(Box.createGlue());
    final JCheckBox checkbox = new JCheckBox("disabled"); //$NON-NLS-1$
    checkbox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        button2.setEnabled(!checkbox.isSelected());
      }
    });
    panel.add(checkbox);
    panel.add(button2);
    panel.add(label2);
    panel.add(textfield2);
    panel.add(Box.createGlue());
    panel.add(button3);
    panel.add(combo3);
    show(panel);
  }
}