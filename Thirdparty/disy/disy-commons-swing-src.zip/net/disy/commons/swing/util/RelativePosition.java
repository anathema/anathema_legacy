//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.util;

import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Window;

// NOT_PUBLISHED
public abstract class RelativePosition {

  public static final RelativePosition TOP_LEFT = new RelativePosition() {
    protected Point createLocation(Rectangle windowBounds, Rectangle ownerBounds) {
      return new Point(ownerBounds.x - windowBounds.width, ownerBounds.y);
    }
  };

  public static final RelativePosition RIGHT = new RelativePosition() {
    protected Point createLocation(Rectangle windowBounds, Rectangle ownerBounds) {
      return new Point(
          (int) ownerBounds.getMaxX(),
          (int) (ownerBounds.getCenterY() - windowBounds.height / 2));
    }
  };

  public static final RelativePosition CENTER = new RelativePosition() {
    protected Point createLocation(Rectangle windowBounds, Rectangle ownerBounds) {
      return new Point(
          (int) (ownerBounds.getCenterX() - windowBounds.width / 2),
          (int) (ownerBounds.getCenterY() - windowBounds.height / 2));
    }
  };

  private RelativePosition() {
    //nothing to do
  }

  public void place(Window window) {
    Window owner = window.getOwner();
    if (owner != null && owner.isVisible()) {
      window.setLocation(createLocation(window.getBounds(), window.getOwner().getBounds()));
    }
    else {
      GuiUtilities.centerOnScreen(window);
    }
  }

  protected abstract Point createLocation(Rectangle windowBounds, Rectangle ownerBounds);

}