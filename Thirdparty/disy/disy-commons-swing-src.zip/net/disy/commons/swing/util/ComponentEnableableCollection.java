/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util;

import java.awt.Component;
import java.awt.Container;
import java.util.ArrayList;
import java.util.List;

public class ComponentEnableableCollection implements IEnableable {

  private final List<IEnableable> allEnableables = new ArrayList<IEnableable>();

  public void addComponent(final Component component) {
    allEnableables.add(new ComponentEnableableAdapter(component));
  }

  public void addContainer(final Container container) {
    allEnableables.add(new ContainerEnableableAdapter(container));
  }

  @Override
  public void setEnabled(final boolean enabled) {
    for (final IEnableable enableable : allEnableables) {
      enableable.setEnabled(enabled);
    }
  }
}