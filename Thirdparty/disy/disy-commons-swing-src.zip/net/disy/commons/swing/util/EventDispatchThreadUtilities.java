/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util;

import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import net.disy.commons.core.util.ContractFailedException;

public class EventDispatchThreadUtilities {

  private EventDispatchThreadUtilities() {
    //prevent public construction
  }

  public static void ensureIsEventDispatchThread() {
    if (!SwingUtilities.isEventDispatchThread()) {
      throw new ContractFailedException(
          "Expected to be executed on the event dispatch thread, but was '" + Thread.currentThread().getName() + "'"); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }

  public static void invokeAndWait(final Runnable runnable) throws InvocationTargetException {
    if (!SwingUtilities.isEventDispatchThread()) {
      try {
        SwingUtilities.invokeAndWait(runnable);
      }
      catch (final InterruptedException e) {
        throw new RuntimeException(e);
      }
    }
    else {
      runnable.run();
    }
  }
}