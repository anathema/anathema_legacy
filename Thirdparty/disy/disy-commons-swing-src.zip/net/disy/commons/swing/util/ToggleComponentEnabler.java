// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.util;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.JToggleButton;

import net.disy.commons.core.util.Ensure;

/**
 * A ToggleComponentEnabler manages a JToggleButton and one or more components so that when the
 * toggle button is selected, the components are enabled and vice versa. Furthermore pressing the
 * mouse on a disabled component will select the toggle button.
 * 
 * Note that JComboBox components will not work properly for receiving mouse click events
 * (http://developer.java.sun.com/developer/bugParade/bugs/4144505.html), so selecting a
 * ToggleButton by klicking the mouse on a disabled combobox will not work.
 * 
 * @author gebhard
 */
public class ToggleComponentEnabler {

  public static void connect(JToggleButton button, IEnableableComponentContainer component) {
    connect(button, new IEnableableComponentContainer[]{ component }, new JComponent[0]);
  }

  public static void connect(JToggleButton button, IEnableableComponentContainer[] components) {
    connect(button, components, new JComponent[0]);
  }

  public static void connect(
      JToggleButton button,
      IEnableableComponentContainer component,
      JComponent decoration) {
    connect(
        button,
        new IEnableableComponentContainer[]{ component },
        new JComponent[]{ decoration });
  }

  private static void connect(
      JToggleButton button,
      IEnableableComponentContainer[] components,
      JComponent[] decorations) {
    new ToggleComponentEnabler(button, components, decorations);
  }

  public static void connect(JToggleButton button, JComponent component) {
    connect(button, createEnableableComponentContainer(component));
  }

  public static void connect(JToggleButton button, JComponent component, JComponent decoration) {
    connect(button, createEnableableComponentContainer(component), decoration);
  }

  public static void connect(JToggleButton button, JComponent[] components) {
    connect(button, createEnableableComponentContainers(components));
  }

  public static void connect(JToggleButton button, JComponent[] components, JComponent decoration) {
    connect(button, createEnableableComponentContainers(components), new JComponent[]{ decoration });
  }

  public static void connect(JToggleButton button, JComponent[] components, JComponent[] decorations) {
    connect(button, createEnableableComponentContainers(components), decorations);
  }

  private static IEnableableComponentContainer[] createEnableableComponentContainers(
      JComponent[] components) {
    Ensure.ensureArgumentNotNull(components);
    Ensure.ensureArgumentArrayContentsNotNull(components);
    IEnableableComponentContainer[] containers = new IEnableableComponentContainer[components.length];
    for (int i = 0; i < containers.length; ++i) {
      containers[i] = createEnableableComponentContainer(components[i]);
    }
    return containers;
  }

  private static IEnableableComponentContainer createEnableableComponentContainer(
      final JComponent component) {
    Ensure.ensureArgumentNotNull(component);
    return new IEnableableComponentContainer() {
      public JComponent getContent() {
        return component;
      }

      public boolean isEnabled() {
        return component.isEnabled();
      }

      public void setEnabled(boolean enabled) {
        setComponentsEnabled(new Component[]{ component }, enabled);
      }

      private void setComponentsEnabled(Component[] components, boolean enabled) {
        for (int i = 0; i < components.length; ++i) {
          Component component = components[i];
          component.setEnabled(enabled);
          if (component instanceof Container) {
            setComponentsEnabled(((Container) component).getComponents(), enabled);
          }
        }
      }
    };
  }

  private final JToggleButton button;
  private final IEnableableComponentContainer[] components;

  private ToggleComponentEnabler(
      final JToggleButton button,
      IEnableableComponentContainer[] components,
      JComponent[] decorations) {
    Ensure.ensureNotNull(button);
    Ensure.ensureNotNull(components);
    Ensure.ensureArgumentArrayContentsNotNull(components);
    this.button = button;
    this.components = components;
    setButtonListeners();
    listenToComponentClicks(components);
    updateComponentsEnabled();
    addDecorationListeners(decorations);
  }

  private void addDecorationListeners(Component[] decorations) {
    for (int i = 0; i < decorations.length; i++) {
      final Component currentDecoration = decorations[i];
      currentDecoration.addMouseListener(new MouseAdapter() {
        @Override
        public void mousePressed(MouseEvent e) {
          button.doClick();
        }
      });
      addEnabledListener(currentDecoration);
    }
  }

  private void addEnabledListener(final Component component) {
    button.addPropertyChangeListener(
        GuiUtilities.ENABLED_PROPERTY_NAME,
        new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            component.setEnabled(button.isEnabled());
          }
        });
    component.setEnabled(button.isEnabled());
  }

  private void listenToComponentClicks(IEnableableComponentContainer[] componentsToListenTo) {
    for (int i = 0; i < componentsToListenTo.length; ++i) {
      listenToComponentClicks(new Component[]{ componentsToListenTo[i].getContent() });
    }
  }

  private void listenToComponentClicks(Component[] componentsToListenTo) {
    for (int i = 0; i < componentsToListenTo.length; ++i) {
      Component component = componentsToListenTo[i];
      component.addMouseListener(new MouseAdapter() {
        @Override
        public void mousePressed(MouseEvent e) {
          if (button.isEnabled() && !button.isSelected()) {
            button.doClick();
            if (e.getSource() instanceof Component) {
              ((Component) e.getSource()).requestFocus();
            }
          }
        }
      });
      if (component instanceof Container) {
        listenToComponentClicks(((Container) component).getComponents());
      }
    }
  }

  private void setButtonListeners() {
    button.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        updateComponentsEnabled();
      }
    });
    button.addPropertyChangeListener(
        GuiUtilities.ENABLED_PROPERTY_NAME,
        new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            updateComponentsEnabled();
          }
        });
  }

  private void setComponentsEnabled(boolean enabled) {
    for (int i = 0; i < components.length; ++i) {
      components[i].setEnabled(enabled);
    }
  }

  private void updateComponentsEnabled() {
    setComponentsEnabled(button.isSelected() && button.isEnabled());
  }
}