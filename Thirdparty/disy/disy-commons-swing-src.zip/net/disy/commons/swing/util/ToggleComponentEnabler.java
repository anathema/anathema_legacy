// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.util;

import java.awt.Component;
import java.awt.Container;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JToggleButton;

import net.disy.commons.core.util.Ensure;

/**
 * A ToggleComponentEnabler manages a JToggleButton and one or more components so that when the
 * toggle button is selected, the components are enabled and vice versa. Furthermore pressing the
 * mouse on a disabled component will select the toggle button.
 * 
 * Note that JComboBox components will not work properly for receiving mouse click events
 * (http://developer.java.sun.com/developer/bugParade/bugs/4648623.html), so selecting a
 * ToggleButton by klicking the mouse on a disabled combobox will not work.
 * 
 * @author gebhard
 */
public class ToggleComponentEnabler {

  public static void connect(JToggleButton button, Component component) {
    connect(button, new Component[]{ component });
  }

  public static void connect(JToggleButton button, Component component, Component decoration) {
    connect(button, new Component[]{ component }, decoration);
  }

  public static void connect(JToggleButton button, Component[] components) {
    connect(button, components, new Component[0]);
  }

  public static void connect(JToggleButton button, Component[] components, Component decoration) {
    connect(button, components, new Component[]{ decoration });
  }

  public static void connect(JToggleButton button, Component[] components, Component[] decorations) {
    new ToggleComponentEnabler(button, components, decorations);
  }

  private JToggleButton button;
  private Component[] components;

  private ToggleComponentEnabler(
      final JToggleButton button,
      Component[] components,
      Component[] decorations) {
    Ensure.ensureNotNull(button);
    Ensure.ensureNotNull(components);
    this.button = button;
    this.components = components;
    setButtonListeners();
    listenToComponentClicks(components);
    updateComponentsEnabled();
    addDecorationListeners(decorations);
  }

  private void addDecorationListeners(Component[] decorations) {
    for (int i = 0; i < decorations.length; i++) {
      final Component currentDecoration = decorations[i];
      currentDecoration.addMouseListener(new MouseAdapter() {
        public void mousePressed(MouseEvent e) {
          button.doClick();
        }
      });
      addEnabledListener(currentDecoration);
    }
  }

  private void addEnabledListener(final Component component) {
    button.addPropertyChangeListener(
        GuiUtilities.ENABLED_PROPERTY_NAME,
        new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            component.setEnabled(button.isEnabled());
          }
        });
    component.setEnabled(button.isEnabled());
  }

  private void listenToComponentClicks(Component[] componentsToListenTo) {
    for (int i = 0; i < componentsToListenTo.length; ++i) {
      Component component = componentsToListenTo[i];
      component.addMouseListener(new MouseAdapter() {
        public void mousePressed(MouseEvent e) {
          if (button.isEnabled() && !button.isSelected()) {
            button.doClick();
            if (e.getSource() instanceof Component) {
              ((Component) e.getSource()).requestFocus();
            }
          }
        }
      });
      if (component instanceof Container) {
        listenToComponentClicks(((Container) component).getComponents());
      }
    }
  }

  private void setButtonListeners() {
    button.addItemListener(new ItemListener() {
      public void itemStateChanged(ItemEvent e) {
        updateComponentsEnabled();
      }
    });
    button.addPropertyChangeListener(
        GuiUtilities.ENABLED_PROPERTY_NAME,
        new PropertyChangeListener() {
          public void propertyChange(PropertyChangeEvent evt) {
            updateComponentsEnabled();
          }
        });
  }

  private void setComponentsEnabled(boolean enabled) {
    setComponentsEnabled(components, enabled);
  }

  private void setComponentsEnabled(Component[] components, boolean enabled) {
    for (int i = 0; i < components.length; ++i) {
      Component component = components[i];
      component.setEnabled(enabled);
      if (component instanceof Container) {
        setComponentsEnabled(((Container) component).getComponents(), enabled);
      }
    }
  }

  private void updateComponentsEnabled() {
    setComponentsEnabled(button.isSelected() && button.isEnabled());
  }
}