/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.lang.reflect.InvocationTargetException;
import java.util.EventObject;
import java.util.HashSet;
import java.util.Set;

import javax.swing.AbstractSpinnerModel;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.TableCellEditor;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.IBooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.geometry.SmartRectangle;
import net.disy.commons.swing.layout.util.LayoutUtilities;

public class GuiUtilities {

  public static final String ENABLED_PROPERTY_NAME = "enabled"; //$NON-NLS-1$
  public static final String ELLIPSIS = "..."; //$NON-NLS-1$

  protected GuiUtilities() {
    throw new UnreachableCodeReachedException();
  }

  /** @deprecated As of 28.11.2009 (gebhard), replaced by {@link #getWindowFor(EventObject)}*/
  @Deprecated
  public static final Window getWindowForComponent(final EventObject event) {
    return getWindowFor(event);
  }

  public static final Window getWindowFor(final EventObject event) {
    if (event == null) {
      return JOptionPane.getRootFrame();
    }
    final Object object = event.getSource();
    if (object instanceof Component) {
      return getWindowFor((Component) object);
    }
    return JOptionPane.getRootFrame();
  }

  /** @deprecated As of 28.11.2009 (gebhard), replaced by {@link #getWindowFor(Component)}*/
  @Deprecated
  public final static Window getWindowForComponent(final Component component) {
    return getWindowFor(component);
  }

  public final static Window getWindowFor(final Component component) {
    if (component == null) {
      return JOptionPane.getRootFrame();
    }
    if (component instanceof JPopupMenu) {
      return getWindowFor(((JPopupMenu) component).getInvoker());
    }
    if (component instanceof Window) {
      return (Window) component;
    }
    return getWindowFor(component.getParent());
  }

  /**
   * Sets the location of the given window relative to another component. If the other component is
   * not currently showing, the window is centered on the screen.
   */
  public static final void centerToComponent(final Window window, final Component component) {
    final Window parentWindow = getWindowFor(component);
    if (parentWindow == null || !parentWindow.isVisible()) {
      centerOnScreen(window);
    }
    else {
      final SmartRectangle parentBounds = getSizeOnScreen(parentWindow);
      centerToPoint(window, parentBounds.getCenter());
    }
  }

  private static SmartRectangle getSizeOnScreen(final Component component) {
    return new SmartRectangle(component.getLocationOnScreen(), component.getSize());
  }

  public static void placeRelativeToOwner(final Window window, final RelativePosition position) {
    position.place(window);
    assureIsOnScreen(window);
  }

  public static final void centerOnScreen(final Window window) {
    final Point screenCenter = new SmartRectangle(getScreenBounds(window)).getCenter();
    centerToPoint(window, screenCenter);
  }

  /**
   * Centers the given window to its parent and show it on the screen.
   * 
   * @see #centerToParent(Window)
   */
  public static final void show(final Window window) {
    centerToParent(window);
    window.setVisible(true);
  }

  public static final Dimension getScreenSize(final Window window) {
    return getScreenBounds(window).getSize();
  }

  public static Rectangle getScreenBounds(final Component component) {
    return component.getGraphicsConfiguration().getBounds();
  }

  public static final void centerToPoint(final Window window, final Point center) {
    final Dimension size = window.getSize();
    int x = center.x - size.width / 2;
    int y = center.y - size.height / 2;
    x = x < 0 ? 0 : x;
    y = y < 0 ? 0 : y;
    window.setLocation(x, y);
  }

  /**
   * Sets the location of the given window relative to its parent. If the parent is not currently
   * showing the window is centered on the screen.
   * 
   * @see #show(Window)
   */
  public static final void centerToParent(final Window window) {
    centerToComponent(window, window.getParent());
  }

  public static final JDialog createDialog(final Component parentComponent, final String title) {
    final JDialog dialog = createRawDialogForParentComponent(parentComponent);
    dialog.setTitle(title);
    accountForScreenSize(dialog);
    return dialog;
  }

  private static JDialog createRawDialogForParentComponent(final Component parentComponent) {
    final Window window = getWindowFor(parentComponent);
    if (window instanceof Frame) {
      return new JDialog((Frame) window);
    }
    if (window instanceof Dialog) {
      return new JDialog((Dialog) window);
    }
    return new JDialog();
  }

  public static final void accountForScreenSize(final Window window) {
    window.addComponentListener(new ComponentAdapter() {
      @Override
      public void componentResized(final ComponentEvent e) {
        assureIsOnScreen((Window) e.getSource());
      }
    });
  }

  public static final void assureIsOnScreen(final Window window) {
    assureIsOnScreen(window, calculateScreenBounds(window));
  }

  public static final void assureIsOnScreen(final Window window, final Rectangle screenBounds) {
    if (window instanceof Frame && ((Frame) window).getExtendedState() == Frame.MAXIMIZED_BOTH) {
      return; //setting bounds would cause the extended state to be set from maximized back to normal!
      //Also in maximized mode the system will take care of the frame being on the screen   
    }
    window.setBounds(calculateOnScreenBounds(window.getBounds(), screenBounds));
    window.validate(); // ohne das war bei niedrigen Auflösungen die Toolbar in GISterm initial nicht sichtbar (ip)
  }

  public static final Rectangle calculateOnScreenBounds(
      final Rectangle componentBounds,
      final Rectangle screenBounds) {
    final Rectangle onScreenBounds = new Rectangle(componentBounds);
    if (onScreenBounds.height > screenBounds.height) {
      onScreenBounds.height = screenBounds.height;
    }
    if (onScreenBounds.width > screenBounds.width) {
      onScreenBounds.width = screenBounds.width;
    }
    onScreenBounds.setLocation(calculateScreenFittingLocation(screenBounds, onScreenBounds));
    return onScreenBounds;
  }

  public static void autoScrollOnMouseDrag(final JComponent component) {
    component.addMouseMotionListener(new MouseMotionAdapter() {
      @Override
      public void mouseDragged(final MouseEvent evt) {
        component.scrollRectToVisible(new Rectangle(evt.getX(), evt.getY(), 1, 1));
      }
    });
  }

  public static void autoScrollHeaderOnMouseDrag(final JTable table) {
    table.getTableHeader().addMouseMotionListener(new MouseMotionAdapter() {
      @Override
      public void mouseDragged(final MouseEvent evt) {
        table.scrollRectToVisible(new Rectangle(
            evt.getX(),
            (int) table.getVisibleRect().getY(),
            1,
            1));
      }
    });
  }

  public static void stopCellEditing(final JTable table) {
    final TableCellEditor cellEditor = table.getCellEditor();
    if (cellEditor != null) {
      cellEditor.stopCellEditing();
    }
  }

  public static void showFitToScreen(
      final JPopupMenu popup,
      final JComponent invoker,
      final int x,
      final int y) {
    popup.show(invoker, x, y);
    // determine boundaries
    final Point point = popup.getLocationOnScreen();
    final Dimension size = popup.getSize();
    final Rectangle oldRect = new Rectangle(point, size);
    final Point newLocation = calculateScreenFittingLocation(invoker, oldRect);

    // rects differ, need moving
    if (!point.equals(newLocation)) {
      final Window window = SwingUtilities.getWindowAncestor(popup);
      if (window != null) {
        window.setLocation(newLocation.x, newLocation.y);
      }
    }
  }

  public static Point calculateScreenFittingLocation(
      final Component screenComponent,
      final Rectangle rectangle) {
    final Rectangle screenBounds = calculateScreenBounds(screenComponent);
    return calculateScreenFittingLocation(screenBounds, rectangle);
  }

  public static Point calculateScreenFittingLocation(
      final Rectangle screenBounds,
      final Rectangle rectangle) {
    final int x = (int) Math.max(
        screenBounds.x,
        Math.min(screenBounds.getMaxX() - rectangle.width, rectangle.x));
    final int y = (int) Math.max(
        screenBounds.y,
        Math.min(screenBounds.getMaxY() - rectangle.height, rectangle.y));
    return new Point(x, y);
  }

  /** @deprecated As of 19.02.2010 (gebhard), replaced by {@link #calculateScreenBounds(GraphicsConfiguration, Toolkit)} */
  @Deprecated
  public static Rectangle calculateScreenBounds(
      final Component screenComponent,
      final Toolkit toolkit) {
    return calculateScreenBounds(screenComponent.getGraphicsConfiguration(), toolkit);
  }

  public static Rectangle calculateScreenBounds(final Component anyComponentOnScreen) {
    return calculateScreenBounds(
        anyComponentOnScreen.getGraphicsConfiguration(),
        anyComponentOnScreen.getToolkit());
  }

  public static Rectangle calculateScreenBounds(
      final GraphicsConfiguration graphicsConfiguration,
      final Toolkit toolkit) {
    final Rectangle overallScreenBounds = graphicsConfiguration.getBounds();
    final Insets screenInsets = toolkit.getScreenInsets(graphicsConfiguration);
    final Rectangle screenBounds = new Rectangle(
        overallScreenBounds.x + screenInsets.left,
        overallScreenBounds.y + screenInsets.top,
        overallScreenBounds.width - screenInsets.left - screenInsets.right,
        overallScreenBounds.height - screenInsets.top - screenInsets.bottom);
    return screenBounds;
  }

  public static void invokeLaterIfNecessary(final Runnable runnable) {
    if (SwingUtilities.isEventDispatchThread()) {
      runnable.run();
    }
    else {
      SwingUtilities.invokeLater(runnable);
    }
  }

  public static void invokeOnEventDispatchThread(final Runnable runnable) {
    if (SwingUtilities.isEventDispatchThread()) {
      runnable.run();
    }
    else {
      try {
        SwingUtilities.invokeAndWait(runnable);
      }
      catch (final InterruptedException e) {
        throw new RuntimeException(e);
      }
      catch (final InvocationTargetException e) {
        throw new RuntimeException(e);
      }
    }
  }

  public static void clearChangeListeners(final AbstractSpinnerModel model) {
    final javax.swing.event.ChangeListener[] changeListeners = model.getChangeListeners();
    for (int index = 0; index < changeListeners.length; index++) {
      model.removeChangeListener(changeListeners[index]);
    }
  }

  public static void obeyEnabledModel(final Component component, final IBooleanModel enabledModel) {
    obeyEnabledModel(new ComponentEnableableAdapter(component), enabledModel);
  }

  public static void obeyEnabledModel(final IEnableable enableable, final IBooleanModel enabledModel) {
    enabledModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        enableable.setEnabled(enabledModel.getValue());
      }
    });
    enableable.setEnabled(enabledModel.getValue());
  }

  public static Set<Container> setContainerEnabled(final Container control, final boolean enabled) {
    return setContainerEnabled(control, enabled, new HashSet<Container>());
  }

  /**
   * Enabled / Disabled einen Container mit allen Unterkomponenten
   * 
   * @param c der Container
   * @param enable true, wenn der Container enabled werden soll
   * @param components die Komponenten, die nicht enabled / disabled werden sollen
   * @return die Komponenten, die vorher schon enabled / disabled waren
   */
  public static Set<Container> setContainerEnabled(
      final Container c,
      final boolean enable,
      final Set<Container> components) {
    final HashSet<Container> enabledComps = new HashSet<Container>();

    if (!components.contains(c)) {
      if (c.isEnabled() == enable) {
        enabledComps.add(c);
      }
      else {
        c.setEnabled(enable);
      }
    }
    return setSubComponentsEnabled(c, enable, components, enabledComps);
  }

  private static Set<Container> setSubComponentsEnabled(
      final Container c,
      final boolean enable,
      final Set<Container> components,
      final Set<Container> enabledComps) {
    final Component[] comps = c.getComponents();
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] instanceof Container) {
        final Set<Container> enabledContainers = setContainerEnabled(
            (Container) comps[i],
            enable,
            components);
        enabledComps.addAll(enabledContainers);
      }
      else {
        if (!components.contains(comps[i])) {
          if (comps[i].isEnabled() == enable) {
            enabledComps.add(c);
          }
          else {
            comps[i].setEnabled(enable);
          }
        }
      }
    }
    return enabledComps;
  }

  public static void repack(final Window window) {
    if (!window.isVisible()) {
      window.pack();
      return;
    }
    final Rectangle oldBounds = window.getBounds();
    final Dimension newSize = window.getPreferredSize();
    final Point newLocation = new Point(
        oldBounds.x + (oldBounds.width - newSize.width) / 2,
        oldBounds.y + (oldBounds.height - newSize.height) / 2);
    Rectangle newBounds = new Rectangle(newLocation, newSize);
    newBounds = calculateOnScreenBounds(newBounds, calculateScreenBounds(window));
    window.setBounds(newBounds);
    window.validate();
  }

  public static void stopCellEditing(final Container container) {
    if (container instanceof JTable) {
      stopCellEditing((JTable) container);
    }
    else {
      for (final Component component : container.getComponents()) {
        if (component instanceof Container) {
          stopCellEditing((Container) component);
        }
      }
    }
  }

  public static JComponent addEmptyBorder(final JComponent content) {
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(content, BorderLayout.CENTER);
    panel.setBorder(LayoutUtilities.getDefaultEmptyBorder());
    return panel;
  }

  public static void addClickActionTo(final Component component, final Action action) {
    component.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        if (component.isEnabled() && action.isEnabled()) {
          action.actionPerformed(new ActionEvent(e, e.getID(), null));
        }
      }
    });
  }

  /**
   * @deprecated As of 29.03.2009 (Markus Gebhard), replaced by
   *             {@link EventDispatchThreadUtilities#ensureIsEventDispatchThread()}
   */
  @Deprecated
  public static void ensureEventDispatchThread() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
  }

  public static boolean isContainedInActiveWindow(final Component component) {
    final Window window = getWindowFor(component);
    if (window == null) {
      return true;
    }
    return window.isActive();
  }

  public static boolean containsFocusOwner(final Component component) {
    if (component.isFocusOwner()) {
      return true;
    }
    if (!(component instanceof Container)) {
      return false;
    }
    final Container container = (Container) component;
    for (int i = 0; i < container.getComponentCount(); ++i) {
      final Component child = container.getComponent(i);
      if (containsFocusOwner(child)) {
        return true;
      }
    }
    return false;
  }
}