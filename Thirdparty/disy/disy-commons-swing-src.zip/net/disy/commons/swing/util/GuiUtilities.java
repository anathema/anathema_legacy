//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.util;

import java.awt.Component;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.EventObject;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.TableCellEditor;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.geometry.SmartRectangle;

// NOT_PUBLISHED
public class GuiUtilities {

  public static final String ENABLED_PROPERTY_NAME = "enabled"; //$NON-NLS-1$

  protected GuiUtilities() {
    throw new UnreachableCodeReachedException();
  }

  public static final Window getWindowForComponent(EventObject event) {
    if (event == null) {
      return JOptionPane.getRootFrame();
    }
    Object object = event.getSource();
    if (object instanceof Component) {
      return getWindowForComponent((Component) object);
    }
    return JOptionPane.getRootFrame();
  }

  public final static Window getWindowForComponent(Component component) {
    if (component == null) {
      return JOptionPane.getRootFrame();
    }
    if (component instanceof JPopupMenu) {
      return getWindowForComponent(((JPopupMenu) component).getInvoker());
    }
    if (component instanceof Window) {
      return (Window) component;
    }
    return getWindowForComponent(component.getParent());
  }

  /**
   * Sets the location of the given window relative to another component. If the other component is
   * not currently showing, the window is centered on the screen.
   */
  public static final void centerToComponent(Window window, Component component) {
    Window parentWindow = getWindowForComponent(component);
    if (parentWindow == null || !parentWindow.isVisible()) {
      GuiUtilities.centerOnScreen(window);
    }
    else {
      SmartRectangle parentBounds = getSizeOnScreen(parentWindow);
      GuiUtilities.centerToPoint(window, parentBounds.getCenter());
    }
  }

  private static SmartRectangle getSizeOnScreen(Component component) {
    return new SmartRectangle(component.getLocationOnScreen(), component.getSize());
  }

  public static void placeRelativeToOwner(Window window, RelativePosition position) {
    position.place(window);
    assureIsOnScreen(window);
  }

  public static final void centerOnScreen(Window window) {
    Point screenCenter = new SmartRectangle(getScreenBounds(window)).getCenter();
    GuiUtilities.centerToPoint(window, screenCenter);
  }

  /**
   * Centers the given window to its parent and show it on the screen.
   * 
   * @see GuiUtilities#centerToParent(Window)
   */
  public static final void show(Window window) {
    GuiUtilities.centerToParent(window);
    window.setVisible(true);
  }

  public static final Dimension getScreenSize(Window window) {
    return getScreenBounds(window).getSize();
  }

  public static Rectangle getScreenBounds(Component component) {
    return component.getGraphicsConfiguration().getBounds();
  }

  public static final void centerToPoint(Window window, Point center) {
    Dimension size = window.getSize();
    int x = center.x - size.width / 2;
    int y = center.y - size.height / 2;
    x = x < 0 ? 0 : x;
    y = y < 0 ? 0 : y;
    window.setLocation(x, y);
  }

  /**
   * Sets the location of the given window relative to its parent. If the parent is not currently
   * showing the window is centered on the screen.
   * 
   * @see GuiUtilities#show(Window)
   */
  public static final void centerToParent(Window window) {
    centerToComponent(window, window.getParent());
  }

  public static final JDialog createDialog(Component parentComponent, String title) {
    final JDialog dialog;

    Window window = getWindowForComponent(parentComponent);
    if (window instanceof Frame) {
      dialog = new JDialog((Frame) window);
    }
    else if (window instanceof Dialog) {
      dialog = new JDialog((Dialog) window);
    }
    else {
      dialog = new JDialog();
    }
    dialog.setTitle(title);
    GuiUtilities.accountForScreenSize(dialog);
    return dialog;
  }

  public static final void accountForScreenSize(final Window window) {
    window.addComponentListener(new ComponentAdapter() {
      public void componentResized(ComponentEvent e) {
        assureIsOnScreen((Window) e.getSource());
      }
    });
  }

  public static final void assureIsOnScreen(Window window) {
    Point newLocation = calculateScreenFittingLocation(window, new SmartRectangle(window
        .getBounds()));
    if (!window.getLocation().equals(newLocation)) {
      window.setLocation(newLocation);
    }
  }

  public static void autoScrollOnMouseDrag(final JComponent component) {
    component.addMouseMotionListener(new MouseMotionAdapter() {
      public void mouseDragged(MouseEvent evt) {
        component.scrollRectToVisible(new Rectangle(evt.getX(), evt.getY(), 1, 1));
      }
    });
  }

  public static void autoScrollHeaderOnMouseDrag(final JTable table) {
    table.getTableHeader().addMouseMotionListener(new MouseMotionAdapter() {
      public void mouseDragged(MouseEvent evt) {
        table.scrollRectToVisible(new Rectangle(
            evt.getX(),
            (int) table.getVisibleRect().getY(),
            1,
            1));
      }
    });
  }

  public static void stopCellEditing(JTable table) {
    TableCellEditor cellEditor = table.getCellEditor();
    if (cellEditor != null) {
      cellEditor.stopCellEditing();
    }
  }

  public static void showFitToScreen(JPopupMenu popup, JComponent invoker, int x, int y) {
    popup.show(invoker, x, y);
    // determine boundaries
    Point point = popup.getLocationOnScreen();
    Dimension size = popup.getSize();
    Rectangle oldRect = new Rectangle(point, size);
    Point newLocation = calculateScreenFittingLocation(invoker, oldRect);

    // rects differ, need moving
    if (!point.equals(newLocation)) {
      Window window = SwingUtilities.getWindowAncestor(popup);
      if (window != null) {
        window.setLocation(newLocation.x, newLocation.y);
      }
    }
  }

  public static Point calculateScreenFittingLocation(Component screenComponent, Rectangle rectangle) {
    GraphicsConfiguration graphicsConfiguration = screenComponent.getGraphicsConfiguration();
    Rectangle overallScreenBounds = graphicsConfiguration.getBounds();
    Insets screenInsets = Toolkit.getDefaultToolkit().getScreenInsets(graphicsConfiguration);
    Rectangle screenBounds = new Rectangle(
        overallScreenBounds.x + screenInsets.left,
        overallScreenBounds.y + screenInsets.top,
        overallScreenBounds.width - screenInsets.left - screenInsets.right,
        overallScreenBounds.height - screenInsets.top - screenInsets.bottom);
    int x = (int) Math.max(screenBounds.x, Math.min(
        screenBounds.getMaxX() - rectangle.width,
        rectangle.x));
    int y = (int) Math.max(screenBounds.y, Math.min(
        screenBounds.getMaxY() - rectangle.height,
        rectangle.y));
    return new Point(x, y);
  }
}