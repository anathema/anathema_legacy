/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.test;

import static junit.framework.Assert.*;

import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import net.disy.commons.core.util.ContractFailedException;
import net.disy.commons.swing.util.EventDispatchThreadUtilities;

import org.junit.Assert;
import org.junit.Test;

public class EventDispatchThreadUtilitiesTest {

  @Test
  public void ensureIsEventDispatchThreadOnEventDispatchThread() throws Exception {
    SwingUtilities.invokeAndWait(new Runnable() {
      @Override
      public void run() {
        EventDispatchThreadUtilities.ensureIsEventDispatchThread();
      }
    });
  }

  @Test
  public void ensureIsEventDispatchThreadNotOnEventDispatchThread() throws Exception {
    class TestRunnable implements Runnable {
      private Throwable caughtThrowable;

      @Override
      public void run() {
        try {
          EventDispatchThreadUtilities.ensureIsEventDispatchThread();
          fail();
        }
        catch (final ContractFailedException e) {
          // nothing to do
        }
        catch (final Throwable e) {
          caughtThrowable = e;
        }
      }

      public void finish() {
        if (caughtThrowable != null) {
          fail("Expected ContractFailedException, but was " + caughtThrowable); //$NON-NLS-1$
        }
      }
    }
    final TestRunnable runnable = new TestRunnable();
    final Thread thread = new Thread(runnable);
    thread.start();
    thread.join();
    runnable.finish();
  }

  @Test
  public void invokeAndWaitRunsOnEdtWhenCalledFromOutsideEventDispatchThread()
      throws InvocationTargetException {
    EventDispatchThreadUtilities.invokeAndWait(new Runnable() {
      @Override
      public void run() {
        Assert.assertTrue(SwingUtilities.isEventDispatchThread());
      }
    });
  }
}