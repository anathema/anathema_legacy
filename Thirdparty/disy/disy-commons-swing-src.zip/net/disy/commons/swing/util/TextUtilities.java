/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util;

import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.font.FontRenderContext;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;

public class TextUtilities {

  public static double getValueWidth(final Component component, final String value) {
    Ensure.ensureArgumentNotNull(component);
    if (StringUtilities.isNullOrEmpty(value)) {
      return 0;
    }
    final Font font = component.getFont();
    final FontRenderContext fontRenderContext = component
        .getFontMetrics(font)
        .getFontRenderContext();
    return font.getStringBounds(value, fontRenderContext).getWidth();
  }

  public static double getValueWidth(final Graphics graphics, final String value) {
    Ensure.ensureArgumentNotNull(graphics);
    if (StringUtilities.isNullOrEmpty(value)) {
      return 0;
    }
    final Font font = graphics.getFont();
    final FontRenderContext fontRenderContext = graphics
        .getFontMetrics(font)
        .getFontRenderContext();
    return font.getStringBounds(value, fontRenderContext).getWidth();
  }

}
