/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.util.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.WindowConstants;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import org.junit.runner.RunWith;

import net.disy.commons.swing.util.GuiUtilities;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class GuiUtilitiesDemo extends SwingDemoCase {

  public void demoAutoScrollOnMouseDragTree() throws Exception {
    final JTree tree = new JTree();
    GuiUtilities.autoScrollOnMouseDrag(tree);
    show(new JScrollPane(tree));
  }

  public void demoAutoScrollOnMouseDragTableHeader() throws Exception {
    final TableModel tableModel = new AbstractTableModel() {
      @Override
      public int getColumnCount() {
        return 26;
      }

      @Override
      public int getRowCount() {
        return 1000;
      }

      @Override
      public Object getValueAt(int rowIndex, int columnIndex) {
        return String.valueOf(Character.forDigit(columnIndex + 10, 36)) + rowIndex;
      }
    };
    final JTable table = new JTable(tableModel);
    for (int columnIndex = 0; columnIndex < table.getColumnCount(); columnIndex++) {
      table.getColumnModel().getColumn(columnIndex).setMinWidth(50);
    }
    table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    GuiUtilities.autoScrollHeaderOnMouseDrag(table);
    show(new JScrollPane(table));
  }

  public void demoCreateDialogWithFrameAsParent() {
    final JButton button = new JButton("Show Dialog"); //$NON-NLS-1$
    show(button);

    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        final JDialog dialog = GuiUtilities.createDialog(button, "title"); //$NON-NLS-1$
        dialog.getContentPane().setLayout(new BorderLayout());
        dialog.getContentPane().add(new JLabel("frame as parent"), BorderLayout.CENTER); //$NON-NLS-1$
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.pack();
        GuiUtilities.show(dialog);
      }
    });
  }

  public void demoCreateDialogWithNoParent() {
    final JButton button = new JButton("Show Dialog"); //$NON-NLS-1$
    show(button);

    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        final JDialog dialog = GuiUtilities.createDialog(null, "title"); //$NON-NLS-1$
        dialog.getContentPane().setLayout(new BorderLayout());
        dialog.getContentPane().add(new JLabel("no parent"), BorderLayout.CENTER); //$NON-NLS-1$
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.pack();
        GuiUtilities.show(dialog);
      }
    });
  }

}