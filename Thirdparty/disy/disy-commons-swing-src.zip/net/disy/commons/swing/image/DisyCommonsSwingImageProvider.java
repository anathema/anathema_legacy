//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.image;

// NOT_PUBLISHED
public class DisyCommonsSwingImageProvider extends ImageProvider {

  private final static DisyCommonsSwingImageProvider instance = new DisyCommonsSwingImageProvider();

  public static DisyCommonsSwingImageProvider getInstance() {
    return instance;
  }

  private DisyCommonsSwingImageProvider() {
    super("net/disy/commons/swing/icons"); //$NON-NLS-1$
  }

}