// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 12.01.2005
package net.disy.commons.swing.image;

// NOT_PUBLISHED
public class ImageLoadingException extends RuntimeException {

  public ImageLoadingException(String message) {
    super(message);
  }
}