//Copyright (c) 2003 by disy Informationssysteme GmbH

package net.disy.commons.swing.image;

import java.awt.Image;

import javax.swing.Icon;

public interface IImageProvider {

  public Image getImage(String relativePath);

  public Image getAnimatedImage(String relativePath);

  public Icon getImageIcon(String relativePath);

  public Icon getAnimatedImageIcon(String relativePath);

}