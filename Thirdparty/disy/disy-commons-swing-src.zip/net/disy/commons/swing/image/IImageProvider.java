//Copyright (c) 2003 by disy Informationssysteme GmbH

package net.disy.commons.swing.image;

import java.awt.Image;

import javax.swing.Icon;

public interface IImageProvider {

  /** @deprecated As of 19.01.2006 (gebhard), Only use it if you really need it.
   * If you need an Icon, use {@link #getImageIcon(String)} instead.*/
  @Deprecated
  public Image getImage(String relativePath);

  /** @deprecated As of 19.01.2006 (gebhard), Only use it if you really need it.
   * If you need an Icon, use {@link #getAnimatedImageIcon(String)} instead.*/
  @Deprecated
  public Image getAnimatedImage(String relativePath);

  public Icon getImageIcon(String relativePath);

  public Icon getAnimatedImageIcon(String relativePath);

}