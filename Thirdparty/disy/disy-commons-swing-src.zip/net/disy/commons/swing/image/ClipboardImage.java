/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.image;

import java.awt.Image;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.ClipboardOwner;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;

import net.disy.commons.core.util.Ensure;

public class ClipboardImage implements Transferable, ClipboardOwner {

  private final Image image;

  public ClipboardImage(final Image image) {
    Ensure.ensureArgumentNotNull(image);
    this.image = image;
  }

  @Override
  public DataFlavor[] getTransferDataFlavors() {
    return (new DataFlavor[]{ DataFlavor.imageFlavor });
  }

  @Override
  public boolean isDataFlavorSupported(final DataFlavor flavor) {
    return DataFlavor.imageFlavor.equals(flavor);
  }

  @Override
  public Object getTransferData(final DataFlavor flavor) throws UnsupportedFlavorException {
    if (!isDataFlavorSupported(flavor)) {
      throw new UnsupportedFlavorException(flavor);
    }
    return image;
  }

  @Override
  public void lostOwnership(final Clipboard clipboard, final Transferable contents) {
    //nothing to do
  }
}