//Copyright (c) 2003-2005 by disy Informationssysteme GmbH

package net.disy.commons.swing.image;

import java.awt.Image;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.Icon;
import javax.swing.ImageIcon;

import net.disy.commons.core.util.Ensure;

public class ImageProvider implements IImageProvider {

  private final String rootPath;

  /**
   * class for loading images out of a central path
   * @param rootPath central path where all images are located
   */
  public ImageProvider(String rootPath) {
    Ensure.ensureNotNull("RootPath is null.", rootPath); //$NON-NLS-1$
    this.rootPath = rootPath;
  }

  /**
   * gets an image relative to root path
   * @param relativePath
   * @return Image or null, if image cannot be loaded and hasDummyImage is false
   */
  public Image getImage(String relativePath) {
    return getImage(relativePath, false);
  }

  /**
   * gets an animated image relative to root path
   * @param relativePath
   * @return Image or null, if image cannot be loaded and hasDummyImage is false
   */
  public Image getAnimatedImage(String relativePath) {
    return getImage(relativePath, true);
  }

  /**
   * @param relativePath
   * @param isAnimated
   * @return Image or null, if image cannot be loaded and hasDummyImage is false
   */
  private Image getImage(String relativePath, boolean isAnimated) {
    InputStream inputStream = getInputStream(relativePath);
    return loadImage(isAnimated, inputStream);
  }

  private Image loadImage(boolean isAnimated, InputStream inputStream) {
    if (inputStream == null) {
      return null;
    }
    try {
      if (isAnimated) {
        return ImageLoader.getImageWithoutCaching(inputStream);
      }
      return ImageLoader.getMemoryImageWithoutCaching(inputStream);
    }
    catch (IOException e) {
      throw new ImageLoadingException("Cannot open image: " + e.getMessage()); //$NON-NLS-1$
    }
  }

  private InputStream getInputStream(String relativePath) {
    Ensure.ensureNotNull("RelativePath to image is null.", relativePath); //$NON-NLS-1$
    String resourceName = rootPath + "/" + relativePath; //$NON-NLS-1$
    InputStream inputStream = getClass().getClassLoader().getResourceAsStream(resourceName);
    if (inputStream == null) {
      throw new ImageLoadingException("Cannot find image resource: " + resourceName); //$NON-NLS-1$
    }
    return inputStream;
  }

  public Icon getImageIcon(String relativePath) {
    Image image = getImage(relativePath);
    return new ImageIcon(image);
  }

  public Icon getAnimatedImageIcon(String relativePath) {
    Image image = getAnimatedImage(relativePath);
    return new ImageIcon(image);
  }
}