/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list.test;

import java.util.List;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.model.test.AbstractChangeableModelTestCase;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.list.AsynchronousFilteredListModel;

import org.easymock.EasyMock;

public class AsynchronousFilteredListModelTest extends AbstractChangeableModelTestCase {

  private DummyListModel originalModel;
  private AsynchronousFilteredListModel<String> model;
  private IChangeListener listener;

  private class DummyListModel extends AbstractChangeableModel implements IListModel<String> {
    @Override
    public int getItemCount() {
      return 2;
    }

    @Override
    public String getItem(final int index) {
      return index == 0 ? "first" : "second"; //$NON-NLS-1$ //$NON-NLS-2$
    }

    public void fireEvent() {
      fireChangeEvent();
    }

    @Override
    public List<String> getItemList() {
      throw new UnsupportedOperationException();
    }

    @Override
    public int indexOf(Object selectedValue) {
      throw new UnsupportedOperationException();
    }
  }

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    originalModel = new DummyListModel();
    model = new AsynchronousFilteredListModel<String>(originalModel);
    listener = EasyMock.createMock(IChangeListener.class);
    listener.stateChanged();
    model.addChangeListener(listener);
    EasyMock.replay(listener);
  }

  public void testCreate() {
    assertEquals(originalModel.getItemCount(), model.getItemCount());
    assertEquals(originalModel.getItem(0), model.getItem(0));
    assertEquals(originalModel.getItem(1), model.getItem(1));
  }

  public void testChangesOnOriginalListModelChange() {
    originalModel.fireEvent();
    waitForAsynchronousExecutionToBeFinished();
    EasyMock.verify(listener);
  }

  public void testFiltersOnSetFilter() {
    final IPredicate<String> filter = createAndSetFilter();
    waitForAsynchronousExecutionToBeFinished();
    assertEquals(1, model.getItemCount());
    assertEquals("second", model.getItem(0)); //$NON-NLS-1$
    EasyMock.verify(listener, filter);
  }

  private void waitForAsynchronousExecutionToBeFinished() {
    while (!model.hasFinishedFiltering()) {
      // wait
    }
  }

  @SuppressWarnings("unchecked")
  private IPredicate<String> createAndSetFilter() {
    final IPredicate<String> filter = EasyMock.createMock(IPredicate.class);
    EasyMock.expect(filter.evaluate("first")).andReturn(false).anyTimes(); //$NON-NLS-1$
    EasyMock.expect(filter.evaluate("second")).andReturn(true).anyTimes(); //$NON-NLS-1$
    EasyMock.replay(filter);
    model.setFilter(filter);
    return filter;
  }
}