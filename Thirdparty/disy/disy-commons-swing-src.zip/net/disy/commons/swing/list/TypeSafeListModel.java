/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractListModel;

public class TypeSafeListModel<T> extends AbstractListModel {
  private final List<T> elements;

  public TypeSafeListModel() {
    this(new ArrayList<T>());
  }

  public TypeSafeListModel(final List<T> elements) {
    this.elements = elements;
  }

  @Override
  public int getSize() {
    return elements.size();
  }

  @Override
  public T getElementAt(final int index) {
    return elements.get(index);
  }

  public void addElement(final T element) {
    elements.add(element);
    fireIntervalAdded(this, elements.size() - 1, elements.size() - 1);
  }
}