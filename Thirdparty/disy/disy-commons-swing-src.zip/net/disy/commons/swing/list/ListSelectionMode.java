/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import javax.swing.ListSelectionModel;

public class ListSelectionMode {

  private final int listSelectionMode;

  private ListSelectionMode(final int listSelectionMode) {
    this.listSelectionMode = listSelectionMode;
  }

  public int getListSelectionMode() {
    return listSelectionMode;
  }

  public final static ListSelectionMode SINGLE_SELECTION = new ListSelectionMode(
      ListSelectionModel.SINGLE_SELECTION);

  public final static ListSelectionMode MULTIPLE_INTERVAL_SELECTION = new ListSelectionMode(
      ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);

  public final static ListSelectionMode SINGLE_INTERVAL_SELECTION = new ListSelectionMode(
      ListSelectionModel.SINGLE_INTERVAL_SELECTION);

}