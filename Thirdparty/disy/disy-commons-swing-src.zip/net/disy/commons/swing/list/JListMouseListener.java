/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;

public class JListMouseListener {

  private final MouseAdapter mouseListener;
  private final JList list;

  private JListMouseListener(final JList list, final IListMouseHandler handler) {
    this.list = list;
    mouseListener = new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent event) {
        if (!event.isMetaDown() || !isClickOnListItem(list, event)) {
          return;
        }
        final int index = list.locationToIndex(event.getPoint());
        if (!list.isSelectedIndex(index)) {
          list.setSelectedIndex(index);
        }
        handler.handleContextMenuClick(list.getSelectedValues());
      }

      @Override
      public void mouseClicked(final MouseEvent event) {
        if (!isClickOnListItem(list, event)) {
          return;
        }
        if (event.getClickCount() == 2) {
          handler.handleDoubleClick(list.getSelectedValues());
          return;
        }
      }

      @Override
      public void mouseReleased(final MouseEvent event) {
        if (!isClickOnListItem(list, event)) {
          return;
        }
        if (event.getClickCount() == 1) {
          handler.handleClick(list.getSelectedValues());
          return;
        }
      }

      private boolean isClickOnListItem(final JList jList, final MouseEvent event) {
        boolean state = true;
        final int index = jList.locationToIndex(event.getPoint());
        if (index == -1) {
          state = false;
        }
        if (!jList.getCellBounds(index, index).contains(event.getPoint())) {
          state = false;
        }
        return state;
      }
    };
    list.addMouseListener(mouseListener);
  }

  public void dispose() {
    list.removeMouseListener(mouseListener);
  }

  public static JListMouseListener attachTo(final JList list, final IListMouseHandler handler) {
    return new JListMouseListener(list, handler);
  }
}