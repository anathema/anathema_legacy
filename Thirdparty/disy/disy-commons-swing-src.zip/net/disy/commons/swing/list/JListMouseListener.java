//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.list;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JList;

// NOT_PUBLISHED
public class JListMouseListener {

  private final MouseAdapter mouseListener;
  private final JList list;

  private JListMouseListener(final JList list, final IListMouseHandler handler) {
    this.list = list;
    mouseListener = new MouseAdapter() {
      @Override
      public void mousePressed(MouseEvent event) {
        if (!event.isMetaDown() || !isClickOnListItem(list, event)) {
          return;
        }
        int index = list.locationToIndex(event.getPoint());
        if (!list.isSelectedIndex(index)) {
          list.setSelectedIndex(index);
        }
        handler.handleContextMenuClick(list.getSelectedValues());
      }

      @Override
      public void mouseClicked(MouseEvent event) {
        if (event.getClickCount() != 2 || !isClickOnListItem(list, event)) {
          return;
        }
        handler.handleDoubleClick(list.getSelectedValues());
      }

      private boolean isClickOnListItem(final JList list, MouseEvent event) {
        boolean state = true;
        int index = list.locationToIndex(event.getPoint());
        if (index == -1) {
          state = false;
        }
        if (!list.getCellBounds(index, index).contains(event.getPoint())) {
          state = false;
        }
        return state;
      }
    };
    list.addMouseListener(mouseListener);
  }

  public void dispose() {
    list.removeMouseListener(mouseListener);
  }

  public static JListMouseListener attachTo(JList list, IListMouseHandler handler) {
    return new JListMouseListener(list, handler);
  }
}