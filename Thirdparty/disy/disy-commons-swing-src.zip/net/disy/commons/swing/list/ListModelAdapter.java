/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import javax.swing.AbstractListModel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.listener.IChangeListener;

public class ListModelAdapter<T> extends AbstractListModel {

  private final IListModel<T> listModel;

  public ListModelAdapter(final IListModel<T> listModel) {
    this.listModel = listModel;
    listModel.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        fireContentsChanged(listModel, 0, getSize());
      }
    });
  }

  @Override
  public T getElementAt(final int index) {
    return listModel.getItem(index);
  }

  @Override
  public int getSize() {
    return listModel.getItemCount();
  }
}