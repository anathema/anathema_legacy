/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import java.util.Collection;

import net.disy.commons.core.list.IMutableListModel;

public class AsynchronousMutableFilteredListModel<T> extends AsynchronousFilteredListModel<T>
    implements
    IMutableListModel<T> {

  public AsynchronousMutableFilteredListModel(final IMutableListModel<T> listModel) {
    super(listModel);
  }

  protected IMutableListModel<T> getMutableListModel() {
    return (IMutableListModel<T>) listModel;
  }

  @Override
  public void clear() {
    synchronized (getMutex()) {
      getMutableListModel().clear();
      getMutex().notifyAll();
    }
  }

  @Override
  public void add(T item) {
    synchronized (getMutex()) {
      getMutableListModel().add(item);
      startFiltering();
    }
  }

  @Override
  public void add(T item, int index) {
    throw new UnsupportedOperationException("add with index is not supported for filtered models"); //$NON-NLS-1$
  }

  @Override
  public void add(T[] items) {
    synchronized (getMutex()) {
      getMutableListModel().add(items);
      startFiltering();
    }
  }

  @Override
  public void add(Collection<T> items) {
    synchronized (getMutex()) {
      getMutableListModel().add(items);
      startFiltering();
    }
  }

  @Override
  public void remove(T item) {
    synchronized (getMutex()) {
      getMutableListModel().remove(item);
      startFiltering();
    }
  }

  @Override
  public void remove(Collection<T> items) {
    synchronized (getMutex()) {
      getMutableListModel().remove(items);
      startFiltering();
    }
  }

  @Override
  public void removeItemAt(int index) {
    synchronized (getMutex()) {
      int originalIndex = getOriginalIndex(index);
      getMutableListModel().removeItemAt(originalIndex);
      startFiltering();
    }
  }

  @Override
  public void replace(T oldItem, T newItem) {
    synchronized (getMutex()) {
      getMutableListModel().replace(oldItem, newItem);
      startFiltering();
    }
  }

  @Override
  public void setItem(T value, int index) {
    synchronized (getMutex()) {
      int originalIndex = getOriginalIndex(index);
      getMutableListModel().setItem(value, originalIndex);
      // gn 23.11.2011:  Filtering is not initiated when a row is edited
      // It is not theoretically not a good solution because by changing a row it may not fit to the filter
      // criteria any more. However, it would be surprising for the user it the row disappears after editing
      // startFiltering();
    }
  }

  @Override
  public void moveValueUp(int rowIndex) {
    throw new UnsupportedOperationException("not yet supported for filtered models"); //$NON-NLS-1$
  }

  @Override
  public void moveValueDown(int rowIndex) {
    throw new UnsupportedOperationException("not yet supported for filtered models"); //$NON-NLS-1$
  }
}