//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.list;

// NOT_PUBLISHED
public interface IListMouseHandler {

  public void handleContextMenuClick(Object[] selectedValues);

  public void handleDoubleClick(Object[] selectedValues);

}
