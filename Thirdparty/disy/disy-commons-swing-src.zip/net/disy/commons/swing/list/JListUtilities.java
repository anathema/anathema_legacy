/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JList;

import net.disy.commons.core.util.CollectionUtilities;

/**
 * @author gebhard
 */
public class JListUtilities {
  private JListUtilities() {
    //nothing to do
  }

  public static void setListItems(final JList list, final Object[] items) {
    list.setModel(createListModel(items));
  }

  public static void setComboItems(final JComboBox comboBox, final Object[] items) {
    comboBox.setModel(createListModel(items));
  }

  public static DefaultComboBoxModel createListModel(final Object[] items) {
    final DefaultComboBoxModel model = new DefaultComboBoxModel();
    for (int i = 0; i < items.length; ++i) {
      model.addElement(items[i]);
    }
    return model;
  }

  public static <T> TypeSafeListModel<T> createTypeSafeListModel(final T[] items) {
    final TypeSafeListModel<T> model = new TypeSafeListModel<T>();
    //it can't be re-factored because TypeSafeListModel should not implement MutableComboBoxModel
    //and there is no common superclass for TypeSafeListModel and DefaultComboBoxModel
    for (int i = 0; i < items.length; ++i) {
      model.addElement(items[i]);
    }
    return model;
  }

  @SuppressWarnings("unchecked")
  public static <T> T[] getSelectedValues(final JList list, final Class<T> clazz) {
    Object[] draftSelectedValues = list.getSelectedValues();
    List<T> selectedValues = new ArrayList<T>(draftSelectedValues.length);
    for (Object selectedValue : draftSelectedValues) {
      selectedValues.add((T) selectedValue);
    }
    return CollectionUtilities.toArray(selectedValues, clazz);
  }
}