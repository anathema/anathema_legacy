// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.list;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JList;
 
/**
 * @author gebhard
 */
public class JListUtilities {
  private JListUtilities(){
    //nothing to do
  }

  public static void setListItems(JList list, final Object[] items) {
    list.setModel(createListModel(items));
  }

  public static void setComboItems(JComboBox comboBox, final Object[] items) {
    comboBox.setModel(createListModel(items));
  }

  public static DefaultComboBoxModel createListModel(final Object[] items) {
    DefaultComboBoxModel model = new DefaultComboBoxModel();
    for (int i=0;i<items.length;++i){
      model.addElement(items[i]);
    }
    return model;
  }
}