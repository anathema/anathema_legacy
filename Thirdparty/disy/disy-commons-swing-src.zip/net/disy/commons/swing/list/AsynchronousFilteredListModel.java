/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.list;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.RowSorter;

import net.disy.commons.core.asynchronous.AsynchronousDroppingJobProcessor;
import net.disy.commons.core.asynchronous.IJobProcessor;
import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.predicate.AcceptAllPredicate;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;

public class AsynchronousFilteredListModel<T> extends AbstractChangeableModel
    implements
    IListModel<T> {

  protected final IListModel<T> listModel;
  private IPredicate<T> filter = new AcceptAllPredicate<T>();
  private T[] filteredObjects = (T[]) new Object[0];
  private int[] originalIndices = new int[0];
  private boolean filteringFinished = false;

  private final AsynchronousDroppingJobProcessor<IPredicate<T>> jobProcessor = new AsynchronousDroppingJobProcessor<IPredicate<T>>(
      new IJobProcessor<IPredicate<T>>() {
        @Override
        public void process(ICancelable cancelable, IPredicate<T> processingFilter)
            throws InterruptedException {
          final List<T> filteredValues = new ArrayList<T>();
          final List<Integer> originalIndicesList = new ArrayList<Integer>();
          for (int i = 0; i < listModel.getItemCount(); i++) {
            ProgressUtilities.checkInterrupted(cancelable);
            T value = listModel.getItem(i);
            if (processingFilter.evaluate(value)) {
              filteredValues.add(value);
              originalIndicesList.add(i);
            }
          }
          synchronized (getMutex()) {
            AsynchronousFilteredListModel.this.filter = processingFilter;
            AsynchronousFilteredListModel.this.filteredObjects = (T[]) filteredValues.toArray();
            AsynchronousFilteredListModel.this.originalIndices = ArrayUtilities.toPrimitive(originalIndicesList
                .toArray(new Integer[]{}));
            AsynchronousFilteredListModel.this.fireChangeEvent();
            AsynchronousFilteredListModel.this.filteringFinished = true;

            getMutex().notifyAll();
          }

        }
      },
      new IExceptionHandler() {
        @Override
        public void handle(Throwable exception) {
          throw new RuntimeException(exception);
        }
      });
  private RowSorter<?> rowSorter;

  public void setRowSorter(final RowSorter<?> rowSorter) {
    this.rowSorter = rowSorter;
  }

  public AsynchronousFilteredListModel(final IListModel<T> listModel) {
    Ensure.ensureArgumentNotNull(listModel);
    this.listModel = listModel;
    final IChangeListener changeListener = new IChangeListener() {
      @Override
      public void stateChanged() {
        startFiltering();
      }
    };
    listModel.addChangeListener(changeListener);
    startFiltering();
    waitForFilteringFinished();
  }

  public void waitForFilteringFinished() {
    synchronized (getMutex()) {
      while (!hasFinishedFiltering()) {
        try {
          getMutex().wait();
        }
        catch (final InterruptedException e) {
          // nothing to do
        }
      }
    }
  }

  @Override
  public int getItemCount() {
    synchronized (getMutex()) {
      return filteredObjects.length;
    }
  }

  @Override
  @SuppressWarnings("unchecked")
  public T getItem(final int index) {
    synchronized (getMutex()) {
      return filteredObjects[index];
    }
  }

  @Override
  public List<T> getItemList() {
    synchronized (getMutex()) {
      return Arrays.asList(filteredObjects);
    }
  }

  public void setFilter(final IPredicate<T> filter) {
    synchronized (getMutex()) {
      this.filter = filter;
      startFiltering();
    }
  }

  protected void startFiltering() {
    synchronized (getMutex()) {
      filteringFinished = false;
      jobProcessor.startJob(filter);
    }
  }

  public boolean hasFinishedFiltering() {
    synchronized (getMutex()) {
      return filteringFinished;
    }
  }

  public BooleanModel getBusyModel() {
    return jobProcessor.getBusyModel();
  }

  public int getOriginalIndex(int index) {
    return originalIndices[index];
  }

  @Override
  public int indexOf(final Object value) {
    synchronized (getMutex()) {
      return ArrayUtilities.indexOf(filteredObjects, new IPredicate<Object>() {
        @Override
        public boolean evaluate(final Object object) {
          return ObjectUtilities.equals(object, value);
        }
      });
    }
  }
}