/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.laf;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import net.disy.commons.swing.color.SwingColors;

public class LookAndFeelUtilities {

  public static final String COMPONENT_TYPE_LABEL = "Label"; //$NON-NLS-1$

  public static void installColorsAndFont(final JComponent component, final String type) {
    LookAndFeel.installColorsAndFont(component, type + ".background", type + ".foreground", type //$NON-NLS-1$ //$NON-NLS-2$
        + ".font"); //$NON-NLS-1$
  }

  public static void adjustCell(
      final JComponent renderer,
      final JTable table,
      final boolean isSelected,
      final boolean hasFocus,
      final boolean cellEditable) {
    if (isSelected) {
      renderer.setForeground(table.getSelectionForeground());
      renderer.setBackground(table.getSelectionBackground());
    }
    else {
      renderer.setForeground(table.getForeground());
      renderer.setBackground(table.getBackground());
    }
    if (hasFocus) {
      renderer.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder")); //$NON-NLS-1$
      if (cellEditable) {
        renderer.setForeground(SwingColors.getTableFocusCellForegroundColor());
        renderer.setBackground(SwingColors.getTableFocusCellBackgroundColor());
      }
    }
    else {
      renderer.setBorder(new EmptyBorder(1, 1, 1, 1));
    }
  }

  public static void setSystemLookAndFeel() {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch (final Exception e) {
      //nothing to do
    }
  }
}