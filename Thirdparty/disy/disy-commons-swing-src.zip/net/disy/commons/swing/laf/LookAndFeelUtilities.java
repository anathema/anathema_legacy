//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.laf;

import java.awt.Color;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.LookAndFeel;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import net.disy.commons.swing.color.SwingColors;

// NOT_PUBLISHED
public class LookAndFeelUtilities {

  public static final String COMPONENT_TYPE_LABEL = "Label"; //$NON-NLS-1$

  public static void installColorsAndFont(JComponent component, String type) {
    LookAndFeel.installColorsAndFont(component, type + ".background", type + ".foreground", type //$NON-NLS-1$ //$NON-NLS-2$
        + ".font"); //$NON-NLS-1$
  }

  /** @deprecated As of 29.09.2005 (gebhard), replaced by {@link SwingColors#getControlColor()} */
  @Deprecated
  public static Color getControlColor() {
    return SwingColors.getControlColor();
  }

  public static void adjustCell(
      JComponent renderer,
      JTable table,
      boolean isSelected,
      boolean hasFocus,
      boolean cellEditable) {
    if (isSelected) {
      renderer.setForeground(table.getSelectionForeground());
      renderer.setBackground(table.getSelectionBackground());
    }
    else {
      renderer.setForeground(table.getForeground());
      renderer.setBackground(table.getBackground());
    }
    if (hasFocus) {
      renderer.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder")); //$NON-NLS-1$
      if (cellEditable) {
        renderer.setForeground(SwingColors.getTabelFocusCellForegroundColor());
        renderer.setBackground(SwingColors.getTabelFocusCellBackgroundColor());
      }
    }
    else {
      renderer.setBorder(new EmptyBorder(1, 1, 1, 1));
    }
  }

}
