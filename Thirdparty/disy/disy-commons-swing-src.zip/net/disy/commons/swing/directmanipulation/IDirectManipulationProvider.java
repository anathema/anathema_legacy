package net.disy.commons.swing.directmanipulation;

import java.awt.Point;

import javax.swing.JComponent;

/**
 * @author Markus Gebhard
 */
public interface IDirectManipulationProvider {

  public DirectManipulationObject getDirectManipulationObject(Point point);

  public void handleContextMenuInvoked(
      JComponent component,
      Point point,
      DirectManipulationObject directManipulationObject);

  public void handleDoubleClick(JComponent content, Point point, DirectManipulationObject directManipulationObject);

}