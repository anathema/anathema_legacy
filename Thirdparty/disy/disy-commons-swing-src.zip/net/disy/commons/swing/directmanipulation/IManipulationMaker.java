package net.disy.commons.swing.directmanipulation;

import java.awt.Point;

/**
 * @author Markus Gebhard
 */
public interface IManipulationMaker {
  public Point getPoint();
}
