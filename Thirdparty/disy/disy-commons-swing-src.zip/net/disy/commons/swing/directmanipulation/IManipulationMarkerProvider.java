package net.disy.commons.swing.directmanipulation;

/**
 * @author Markus Gebhard
 */
public interface IManipulationMarkerProvider {
  public IManipulationMaker[] getMarkers();
}
