package net.disy.commons.swing.directmanipulation;

import java.awt.Point;

import net.disy.commons.core.util.Ensure;


/**
 * @author Markus Gebhard
 */
public class ManipulationMarker implements IManipulationMaker {

  private final Point point;

  public ManipulationMarker(Point point) {
    Ensure.ensureArgumentNotNull(point);
    this.point = point;
  }

  public Point getPoint() {
    return point;
  }

}