/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.directmanipulation;

import java.awt.Point;
import java.awt.Rectangle;

import net.disy.commons.core.util.Ensure;

/**
 * @author Markus Gebhard
 * @deprecated As of 20.02.2009 (gebhard), this feature has never finished and AFAIK never been used
 */
@Deprecated
public class RectangleMarkerProvider implements IManipulationMarkerProvider {

  private final Rectangle rectangle;

  public RectangleMarkerProvider(final Rectangle rectangle) {
    Ensure.ensureArgumentNotNull(rectangle);
    this.rectangle = rectangle;
  }

  @Override
  public IManipulationMaker[] getMarkers() {
    final Point[] points = new Point[]{
        new Point(rectangle.x, rectangle.y),
        new Point(rectangle.x + rectangle.width / 2, rectangle.y),
        new Point(rectangle.x, rectangle.y + rectangle.height / 2),
        new Point(rectangle.x, rectangle.y + rectangle.height),
        new Point(rectangle.x + rectangle.width, rectangle.y),
        new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height / 2),
        new Point(rectangle.x + rectangle.width / 2, rectangle.y + rectangle.height),
        new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height), };

    final IManipulationMaker[] markers = new IManipulationMaker[points.length];
    for (int i = 0; i < points.length; i++) {
      markers[i] = new ManipulationMarker(points[i]);
    }
    return markers;
  }
}