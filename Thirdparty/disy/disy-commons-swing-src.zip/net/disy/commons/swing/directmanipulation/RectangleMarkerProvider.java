package net.disy.commons.swing.directmanipulation;

import java.awt.Point;
import java.awt.Rectangle;

import net.disy.commons.core.util.Ensure;

/**
 * @author Markus Gebhard
 */
public class RectangleMarkerProvider implements IManipulationMarkerProvider {

  private final Rectangle rectangle;

  public RectangleMarkerProvider(Rectangle rectangle) {
    Ensure.ensureArgumentNotNull(rectangle);
    this.rectangle = rectangle;
  }

  public IManipulationMaker[] getMarkers() {
    Point[] points = new Point[]{
        new Point(rectangle.x, rectangle.y),
        new Point(rectangle.x + rectangle.width / 2, rectangle.y),
        new Point(rectangle.x, rectangle.y + rectangle.height / 2),
        new Point(rectangle.x, rectangle.y + rectangle.height),
        new Point(rectangle.x + rectangle.width, rectangle.y),
        new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height / 2),
        new Point(rectangle.x + rectangle.width / 2, rectangle.y + rectangle.height),
        new Point(rectangle.x + rectangle.width, rectangle.y + rectangle.height), };

    IManipulationMaker[] markers = new IManipulationMaker[points.length];
    for (int i = 0; i < points.length; i++) {
      markers[i] = new ManipulationMarker(points[i]);
    }
    return markers;
  }
}