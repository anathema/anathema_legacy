/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.directmanipulation;

import net.disy.commons.core.util.Ensure;

/**
 * @author Markus Gebhard
 * @deprecated As of 20.02.2009 (gebhard), this feature has never finished and AFAIK never been used
 */
@Deprecated
public class DirectManipulationObject {

  private final IManipulationMarkerProvider markerProvider;

  public DirectManipulationObject(final IManipulationMarkerProvider markerProvider) {
    Ensure.ensureArgumentNotNull(markerProvider);
    this.markerProvider = markerProvider;
  }

  public IManipulationMarkerProvider getMarkerProvider() {
    return markerProvider;
  }
}