/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.directmanipulation;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.ObjectUtilities;

/**
 * @author Markus Gebhard
 * @deprecated As of 20.02.2009 (gebhard), this feature has never finished and AFAIK never been used
 */
@Deprecated
public class DirectManipulationObjectModel extends AbstractChangeableModel {

  private DirectManipulationObject directManipulationObject;

  public void setDirectManipulationObject(final DirectManipulationObject directManipulationObject) {
    if (ObjectUtilities.equals(this.directManipulationObject, directManipulationObject)) {
      return;
    }
    this.directManipulationObject = directManipulationObject;
    fireChangeEvent();
  }

  public DirectManipulationObject getDirectManipulationObject() {
    return directManipulationObject;
  }
}