package net.disy.commons.swing.directmanipulation;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.ObjectUtilities;

/**
 * @author Markus Gebhard
 */
public class DirectManipulationObjectModel {
  //TODO Nov 28, 2004 (Markus Gebhard):  Von AbstractChangeableModel ableiten
  private final Collection/*<ChangeListener>*/changeListeners = new ArrayList();

  public synchronized void addChangeListener(ChangeListener listener) {
    changeListeners.add(listener);
  }

  public synchronized void removeChangeListener(ChangeListener listener) {
    changeListeners.remove(listener);
  }

  protected void fireChangeEvent() {
    Collection clone;
    synchronized (changeListeners) {
      clone = new ArrayList(changeListeners);

    }
    ChangeEvent event = new ChangeEvent(this);
    for (Iterator iter = clone.iterator(); iter.hasNext();) {
      ChangeListener listener = (ChangeListener) iter.next();
      listener.stateChanged(event);
    }
  }

  private DirectManipulationObject directManipulationObject;

  public void setDirectManipulationObject(DirectManipulationObject directManipulationObject) {
    if (ObjectUtilities.equals(this.directManipulationObject, directManipulationObject)) {
      return;
    }
    this.directManipulationObject = directManipulationObject;
    fireChangeEvent();
  }

  public DirectManipulationObject getDirectManipulationObject() {
    return directManipulationObject;
  }
}