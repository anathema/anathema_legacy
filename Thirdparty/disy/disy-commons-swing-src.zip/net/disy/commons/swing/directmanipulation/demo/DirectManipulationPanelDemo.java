/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.directmanipulation.demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Point;

import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.WindowConstants;

import net.disy.commons.swing.directmanipulation.DirectManipulationObject;
import net.disy.commons.swing.directmanipulation.DirectManipulationPanel;
import net.disy.commons.swing.directmanipulation.IDirectManipulationProvider;
import net.disy.commons.swing.directmanipulation.RectangleMarkerProvider;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;
import de.jdemo.util.GuiUtilities;

import org.junit.runner.RunWith;

/**
* @deprecated As of 20.02.2009 (gebhard), this feature has never finished and AFAIK never been used
*/
@Deprecated
@RunWith(DemoAsTestRunner.class)
public class DirectManipulationPanelDemo extends SwingDemoCase {
  public void demo() {
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(new JLabel("Top", SwingConstants.CENTER), BorderLayout.NORTH); //$NON-NLS-1$
    final JTextArea textArea = new JTextArea(4, 40);
    textArea.setEditable(false);
    panel.add(new JScrollPane(textArea), BorderLayout.CENTER);
    panel.add(new JLabel("Bottom", SwingConstants.CENTER), BorderLayout.SOUTH); //$NON-NLS-1$
    final JLabel westLabel = new JLabel("West"); //$NON-NLS-1$
    panel.add(westLabel, BorderLayout.WEST);
    panel.add(new JLabel("East"), BorderLayout.EAST); //$NON-NLS-1$

    final IDirectManipulationProvider provider = new IDirectManipulationProvider() {
      @Override
      public DirectManipulationObject getDirectManipulationObject(final Point point) {
        final Component component = panel.getComponentAt(point);
        if (component == null) {
          return null;
        }
        if (component == westLabel) {
          return null;
        }
        return new DirectManipulationObject(new RectangleMarkerProvider(component.getBounds()));
      }

      @Override
      public void handleContextMenuInvoked(
          final JComponent component,
          final Point point,
          final DirectManipulationObject directManipulationObject) {
        final JPopupMenu popupMenu = new JPopupMenu();
        popupMenu.add(new JMenuItem("Context menu for: " + directManipulationObject)); //$NON-NLS-1$
        popupMenu.show(component, point.x, point.y);
      }

      @Override
      public void handleDoubleClick(
          final JComponent content,
          final Point point,
          final DirectManipulationObject directManipulationObject) {
        final JDialog dialog = GuiUtilities.createDialog(content);
        dialog.getContentPane().add(new JLabel("Dialog for: " + directManipulationObject)); //$NON-NLS-1$
        dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        dialog.pack();
        GuiUtilities.centerOnScreen(dialog);
        dialog.setVisible(true);
      }
    };
    show(new DirectManipulationPanel(panel, provider).getContent());
  }
}