/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.directmanipulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;

/**
 * @author Markus Gebhard
 * @deprecated As of 20.02.2009 (gebhard), this feature has never finished and AFAIK never been used
 */
@Deprecated
public class DirectManipulationPanel {

  private final JComponent content;

  private final DirectManipulationObjectModel model = new DirectManipulationObjectModel();

  public DirectManipulationPanel(
      final JComponent content,
      final IDirectManipulationProvider directManipulationProvider) {
    final JPanel panel = new OverallMouseListeningPanel(content) {
      @Override
      protected void paintChildren(final Graphics g) {
        super.paintChildren(g);
        final DirectManipulationObject directManipulationObject = model
            .getDirectManipulationObject();
        if (directManipulationObject != null) {
          final IManipulationMaker[] markers = directManipulationObject
              .getMarkerProvider()
              .getMarkers();
          g.setColor(Color.black);
          g.setXORMode(Color.white);
          for (int i = 0; i < markers.length; i++) {
            paintMarker(g, markers[i].getPoint());
          }
          g.setPaintMode();
        }
      }

      private void paintMarker(final Graphics g, final Point point) {
        g.fillRect(point.x - 2, point.y - 2, 5, 5);
      }
    };
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        panel.repaint();
      }
    });
    panel.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        adjustDirectManipulationObject(e);
      }

      private void adjustDirectManipulationObject(final MouseEvent e) {
        final DirectManipulationObject directManipulationObject = directManipulationProvider
            .getDirectManipulationObject(e.getPoint());
        model.setDirectManipulationObject(directManipulationObject);
      }

      @Override
      public void mouseReleased(final MouseEvent e) {
        adjustDirectManipulationObject(e);
        if (model.getDirectManipulationObject() == null) {
          return;
        }
        if (e.isMetaDown()) {
          directManipulationProvider.handleContextMenuInvoked(getContent(), e.getPoint(), model
              .getDirectManipulationObject());
        }
        else if (e.getClickCount() == 2) {
          directManipulationProvider.handleDoubleClick(getContent(), e.getPoint(), model
              .getDirectManipulationObject());
        }
      }
    });
    this.content = panel;
  }

  public JComponent getContent() {
    return content;
  }
}