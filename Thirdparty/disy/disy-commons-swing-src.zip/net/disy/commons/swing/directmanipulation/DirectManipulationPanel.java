package net.disy.commons.swing.directmanipulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;

/**
 * @author Markus Gebhard
 */
public class DirectManipulationPanel {

  private final JComponent content;

  private final DirectManipulationObjectModel model = new DirectManipulationObjectModel();

  public DirectManipulationPanel(
      JComponent content,
      final IDirectManipulationProvider directManipulationProvider) {
    final JPanel panel = new OverallMouseListeningPanel(content) {
      protected void paintChildren(Graphics g) {
        super.paintChildren(g);
        DirectManipulationObject directManipulationObject = model.getDirectManipulationObject();
        if (directManipulationObject != null) {
          IManipulationMaker[] markers = directManipulationObject.getMarkerProvider().getMarkers();
          g.setColor(Color.black);
          g.setXORMode(Color.white);
          for (int i = 0; i < markers.length; i++) {
            paintMarker(g, markers[i].getPoint());
          }
          g.setPaintMode();
        }
      }

      private void paintMarker(Graphics g, Point point) {
        g.fillRect(point.x - 2, point.y - 2, 5, 5);
      }
    };
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        panel.repaint();
      }
    });
    panel.addMouseListener(new MouseAdapter() {
      public void mousePressed(MouseEvent e) {
        adjustDirectManipulationObject(e);
      }

      private void adjustDirectManipulationObject(MouseEvent e) {
        DirectManipulationObject directManipulationObject = directManipulationProvider
            .getDirectManipulationObject(e.getPoint());
        model.setDirectManipulationObject(directManipulationObject);
      }

      public void mouseReleased(MouseEvent e) {
        adjustDirectManipulationObject(e);
        if (model.getDirectManipulationObject() == null) {
          return;
        }
        if (e.isMetaDown()) {
          directManipulationProvider.handleContextMenuInvoked(getContent(), e.getPoint(), model
              .getDirectManipulationObject());
        }
        else if (e.getClickCount() == 2) {
          directManipulationProvider.handleDoubleClick(getContent(), e.getPoint(), model
              .getDirectManipulationObject());
        }
      }
    });
    this.content = panel;
  }

  public JComponent getContent() {
    return content;
  }
}