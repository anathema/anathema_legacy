//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.suite;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDisyCommonsSwingDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.suite"); //$NON-NLS-1$
    suite.addDemo(net.disy.commons.swing.button.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.cardlayout.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.action.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.events.mouse.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.directmanipulation.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.util.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.color.widgets.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.border.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.icon.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.color.demo.AllDemos.suite());
    //$JDemo-BEGIN$

    //$JDemo-END$
    return suite;
  }
}
