//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.suite;

import junit.framework.Test;
import junit.framework.TestSuite;

import de.jdemo.junit.Demo2TestConverter;

// NOT_PUBLISHED
public class AllDisyCommonsSwingTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.swing.suite"); //$NON-NLS-1$
    suite.addTest(Demo2TestConverter.createTest(AllDisyCommonsSwingDemos.suite()));
    suite.addTest(net.disy.commons.swing.cardlayout.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.action.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.font.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.events.mouse.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.message.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.menu.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.util.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.widgets.test.AllTests.suite());
    //$JUnit-BEGIN$

    //$JUnit-END$
    return suite;
  }
}
