/*
 * (c) disy Informationssysteme GmbH
 * 
 * Created on 18.04.2004
 *
 */
package net.disy.commons.swing.button;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Action;
import javax.swing.JToggleButton;

import net.disy.commons.swing.action.IToggleAction;
import net.disy.commons.swing.action.SmartToggleAction;

/**
 * @author behrens
 * @deprecated As of 28.06.2005 (gebhard), replaced by {@link net.disy.commons.swing.action.ActionWidgetFactory#createToggleButton(SmartToggleAction)}
 */
public class ToggleActionButton extends JToggleButton {

  private final class SelectionStateHandler implements PropertyChangeListener {
    public void propertyChange(PropertyChangeEvent evt) {
      if(IToggleAction.PROPERTY_NAME_SELECT.equals(evt.getPropertyName())) {
        boolean selected = ((Boolean)evt.getNewValue()).booleanValue();
        setSelected(selected);
      }
    }
  }

  private SelectionStateHandler selectionStateHandler = new SelectionStateHandler();
  
  public void setAction(Action action) {
    Action oldAction = getAction();
    if(oldAction != null) {
      oldAction.removePropertyChangeListener(selectionStateHandler);
    }
    
    super.setAction(action);
    
    if(action != null && action instanceof IToggleAction) {
      IToggleAction toggleAction = (IToggleAction) action;
      setSelected(toggleAction.isSelected());
      action.addPropertyChangeListener(new SelectionStateHandler());
    }
  }
}
