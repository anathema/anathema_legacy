//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.button.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.button.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(DropDownButtonDemo.class));
    //$JDemo-END$
    return suite;
  }
}