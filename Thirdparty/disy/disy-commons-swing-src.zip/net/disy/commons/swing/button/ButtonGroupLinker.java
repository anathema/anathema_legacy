/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.button;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;

import net.disy.commons.core.model.IObjectModel;

public class ButtonGroupLinker<T> {

  private final IObjectModel<T> model;
  private final ButtonGroup buttonGroup = new ButtonGroup();
  private final Map<ButtonModel, T> valueByButtonModel = new HashMap<ButtonModel, T>();
  private final ActionListener listener = new ActionListener() {
    @Override
    public void actionPerformed(final ActionEvent e) {
      model.setValue(valueByButtonModel.get(buttonGroup.getSelection()));
    }
  };

  public ButtonGroupLinker(final IObjectModel<T> model) {
    this.model = model;
  }

  public AbstractButton addButton(final AbstractButton button, final T value) {
    if (valueByButtonModel.containsKey(button.getModel())) {
      throw new IllegalArgumentException(
          "A button with equal model has already been linked. Tryed to link '" //$NON-NLS-1$
              + value
              + "' to " + button); //$NON-NLS-1$
    }
    buttonGroup.add(button);
    valueByButtonModel.put(button.getModel(), value);
    button.addActionListener(listener);
    button.setSelected(value.equals(model.getValue()));
    return button;
  }
}