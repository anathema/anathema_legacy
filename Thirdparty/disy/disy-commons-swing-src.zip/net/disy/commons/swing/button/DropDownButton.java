package net.disy.commons.swing.button;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.AbstractButton;
import javax.swing.ButtonModel;
import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;

/**
 * @author Markus Gebhard
 */
public class DropDownButton {
  private final static Icon ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "button/drop_down.gif"); //$NON-NLS-1$
  private final static Icon DISABLED_ICON = DisyCommonsSwingImageProvider
      .getInstance()
      .getImageIcon("button/drop_down_disabled.gif"); //$NON-NLS-1$

  private JPopupMenu menu;

  private final JButton button;
  private final JComponent content;
  private final AbstractButton parentButton;

  public DropDownButton() {
    this(null);
  }

  public DropDownButton(final AbstractButton parentButton) {
    this.parentButton = parentButton;
    button = new JButton();
    button.setIcon(ICON);
    button.setDisabledIcon(DISABLED_ICON);
    setPreferredDropDownButtonHeight(22);
    button.setMargin(new Insets(0, 0, 0, 0));
    button.setFocusPainted(false);
    button.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(MouseEvent e) {
        if (button.isEnabled()) {
          int menuWidth = menu.getPreferredSize().width;
          int x;
          if (parentButton != null) {
            x = -parentButton.getWidth();
          }
          else {
            x = button.getWidth() - menuWidth;
          }
          menu.show(button, x, button.getHeight());
        }
      }
    });

    if (parentButton != null) {
      connectButtonModelsForRollover(parentButton.getModel(), button.getModel());
      //Propagate isEnabled
      parentButton.getModel().addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          updateEnabled();
        }
      });
      parentButton.addPropertyChangeListener(
          JComponent.TOOL_TIP_TEXT_KEY,
          new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent evt) {
              adaptToolTipText();
            }
          });
      adaptToolTipText();
      JPanel panel = new JPanel(new BorderLayout());
      panel.add(parentButton, BorderLayout.CENTER);
      panel.add(button, BorderLayout.EAST);
      this.content = panel;
    }
    else {
      this.content = button;
    }
    updateEnabled();
  }

  private void adaptToolTipText() {
    button.setToolTipText(parentButton.getToolTipText());
  }

  public void setPreferredDropDownButtonHeight(int height) {
    button.setPreferredSize(new Dimension(13, height));
  }

  private static void connectButtonModelsForRollover(
      final ButtonModel model1,
      final ButtonModel model2) {
    model1.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        model2.setRollover(model1.isRollover());
      }
    });
    model2.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        model1.setRollover(model2.isRollover());
      }
    });
  }

  private void updateEnabled() {
    button.setEnabled(menu != null && (parentButton == null || parentButton.isEnabled()));
  }

  public void setMenu(JPopupMenu menu) {
    this.menu = menu;
    updateEnabled();
  }

  public JComponent getComponent() {
    return content;
  }

  public JComponent[] getSeparateComponents() {
    if (parentButton == null) {
      return new JComponent[]{ button };
    }
    return new JComponent[]{ parentButton, button };
  }

  public void setToolTipText(String text) {
    button.setToolTipText(text);
  }
}