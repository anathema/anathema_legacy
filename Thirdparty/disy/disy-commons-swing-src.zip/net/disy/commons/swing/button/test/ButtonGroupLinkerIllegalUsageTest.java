/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.button.test;

import javax.swing.JToggleButton;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.button.ButtonGroupLinker;

import org.junit.Test;

public class ButtonGroupLinkerIllegalUsageTest {

  @Test(expected = IllegalArgumentException.class)
  public void sameButtonIsAddedTwice() throws Exception {
    final JToggleButton button = new JToggleButton();
    final ButtonGroupLinker<String> linker = new ButtonGroupLinker<String>(
        new ObjectModel<String>());
    linker.addButton(button, "a"); //$NON-NLS-1$
    linker.addButton(button, "b"); //$NON-NLS-1$
  }
}