/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.button.test;

import static org.junit.Assert.*;

import javax.swing.JToggleButton;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.button.ButtonGroupLinker;

import org.junit.Before;
import org.junit.Test;

public class ButtonGroupLinkerInitialSelectionTest {

  private static final String EXPECTED = "Expected"; //$NON-NLS-1$
  private ButtonGroupLinker<String> buttonGroupLinker;
  private ObjectModel<String> objectModel;

  @Before
  public void createLinker() {
    objectModel = new ObjectModel<String>(EXPECTED);
    buttonGroupLinker = new ButtonGroupLinker<String>(objectModel);
  }

  @Test
  public void expectedButtonIsSelected() throws Exception {
    JToggleButton button = new JToggleButton();
    buttonGroupLinker.addButton(button, EXPECTED);
    assertTrue(button.isSelected());
  }

  @Test
  public void anotherExpectedButtonIsSelectedAsWell() throws Exception {
    String anotherValue = "EvenMoreExpected"; //$NON-NLS-1$
    objectModel.setValue(anotherValue);
    JToggleButton button = new JToggleButton();
    buttonGroupLinker.addButton(button, anotherValue);
    assertTrue(button.isSelected());
  }

  @Test
  public void unexpectedButtonIsNotSelected() throws Exception {
    JToggleButton button = new JToggleButton();
    buttonGroupLinker.addButton(button, "unexpected"); //$NON-NLS-1$
    assertFalse(button.isSelected());
  }
}