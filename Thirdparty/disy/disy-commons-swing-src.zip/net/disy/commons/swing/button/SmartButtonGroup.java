

//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.button;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;

// NOT_PUBLISHED
public class SmartButtonGroup extends ButtonGroup {

  public void clear() {
    while (getButtonCount() > 0) {
      remove(getElements().nextElement());
    }
  }

  public int getSelectedIndex() {
    for (int i = 0; i < buttons.size(); ++i) {
      if (getButton(i).isSelected()) {
        return i;
      }
    }
    return -1;
  }

  public void setSelectedIndex(int index) {
    AbstractButton button = getButton(index);
    button.setSelected(true);
  }

  public AbstractButton getButton(int index) {
    return buttons.get(index);
  }
}