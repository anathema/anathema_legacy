/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.button;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;

/** @deprecated As of 01.05.2009 (Markus Gebhard), replaced by {@link ButtonGroupLinker}*/
@Deprecated
public class SmartButtonGroup extends ButtonGroup {

  public void clear() {
    while (getButtonCount() > 0) {
      remove(getElements().nextElement());
    }
  }

  public int getSelectedIndex() {
    for (int i = 0; i < buttons.size(); ++i) {
      if (getButton(i).isSelected()) {
        return i;
      }
    }
    return -1;
  }

  public void setSelectedIndex(final int index) {
    final AbstractButton button = getButton(index);
    button.setSelected(true);
  }

  public AbstractButton getButton(final int index) {
    return buttons.get(index);
  }
}