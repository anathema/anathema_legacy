//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.button;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;

// NOT_PUBLISHED
public class SmartButtonGroup extends ButtonGroup {

  public void clear() {
    while (getButtonCount() > 0) {
      remove((AbstractButton) getElements().nextElement());
    }
  }

}