package net.disy.commons.swing.button.demo;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JToggleButton;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.button.DropDownButton;
import net.disy.commons.swing.message.gui.MessageTypeUi;

import de.jdemo.extensions.SwingDemoCase;

public class DropDownButtonDemo extends SwingDemoCase {

  public void demo() {
    DropDownButton dropDownButton = new DropDownButton();
    JPopupMenu popupMenu = createPopupMenu();
    dropDownButton.setMenu(popupMenu);
    show(dropDownButton.getComponent());
  }

  private JPopupMenu createPopupMenu() {
    JRadioButtonMenuItem rbUniversal = new JRadioButtonMenuItem("Universal smushing"); //$NON-NLS-1$
    JRadioButtonMenuItem rbSpecific = new JRadioButtonMenuItem("Smushing rules:"); //$NON-NLS-1$
    ButtonGroup group = new ButtonGroup();
    group.add(rbUniversal);
    group.add(rbSpecific);
    JCheckBoxMenuItem cbEqualCharacter = new JCheckBoxMenuItem("Equal character smushing"); //$NON-NLS-1$
    JCheckBoxMenuItem cbUnderscore = new JCheckBoxMenuItem("Underscore smushing"); //$NON-NLS-1$
    JCheckBoxMenuItem cbHierarchy = new JCheckBoxMenuItem("Hierarchy smushing"); //$NON-NLS-1$
    JPopupMenu menu = new JPopupMenu();
    menu.add(rbUniversal);
    menu.add(rbSpecific);
    menu.addSeparator();
    menu.add(cbEqualCharacter);
    menu.add(cbUnderscore);
    menu.add(cbHierarchy);
    return menu;
  }

  public void demoWithToggleButtons() {
    final JButton parentButton = new JButton(MessageTypeUi.infoIcon); //$NON-NLS-1$
    parentButton.setPreferredSize(new Dimension(22, 21));

    DropDownButton dropDownButton = new DropDownButton(parentButton);

    ButtonGroup toggleButtonGroup = new ButtonGroup();
    JToggleButton toggleButton1 = createToggleButton(toggleButtonGroup, new SmartAction(
        MessageTypeUi.errorIcon) {
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    });
    toggleButton1.setSelected(true);
    JToggleButton toggleButton2 = createToggleButton(toggleButtonGroup, new SmartAction(
        MessageTypeUi.warningIcon) {
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    });
    JToggleButton toggleButton3 = createToggleButton(toggleButtonGroup, new SmartAction(
        MessageTypeUi.infoIcon) {
      protected void execute(Component parentComponent) {
        //nothing to do
      }
    });

    final JPopupMenu menu = new JPopupMenu();
    menu.add(toggleButton1);
    menu.add(toggleButton2);
    menu.add(toggleButton3);

    toggleButton1.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        menu.setVisible(false);
      }
    });
    toggleButton2.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        menu.setVisible(false);
      }
    });
    toggleButton3.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        menu.setVisible(false);
      }
    });
    dropDownButton.setMenu(menu);

    final JCheckBox checkBox = new JCheckBox();
    SmartAction action = new SmartAction("enabled") { //$NON-NLS-1$
      protected void execute(Component parentComponent) {
        parentButton.setEnabled(checkBox.isSelected());
      }
    };

    checkBox.setSelected(true);

    checkBox.setAction(action);

    JPanel panel = new JPanel();
    panel.add(checkBox);
    panel.add(dropDownButton.getComponent());
    show(panel);
  }

  private JToggleButton createToggleButton(ButtonGroup toggleButtonGroup, Action action) {
    JToggleButton toggleButton = new JToggleButton(action);
    toggleButton.setPreferredSize(new Dimension(22, 21));
    toggleButton.setFocusPainted(false);
    toggleButtonGroup.add(toggleButton);
    return toggleButton;
  }
}