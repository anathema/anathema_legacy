/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.navigate;

import net.disy.commons.core.asynchronous.AsynchronousDroppingJobProcessor;
import net.disy.commons.core.asynchronous.IJobProcessor;
import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;

public class DelayedObjectModelFactory {

  public static <T> ObjectModel<T> createDelayedModel(
      final ObjectModel<T> model,
      final long delayMillis) {
    final ObjectModel<T> delayedModel = new ObjectModel<T>();
    delayedModel.setValue(model.getValue());
    final AsynchronousDroppingJobProcessor<T> processor = new AsynchronousDroppingJobProcessor<T>(
        new IJobProcessor<T>() {
          @Override
          public void process(final ICancelable cancelable, final T job)
              throws InterruptedException {
            ProgressUtilities.checkInterrupted(cancelable);
            Thread.sleep(delayMillis);
            ProgressUtilities.checkInterrupted(cancelable);
            delayedModel.setValue(job);
          }
        },
        new IExceptionHandler() {
          @Override
          public void handle(final Throwable exception) {
            if (exception instanceof Error) {
              throw (Error) exception;
            }
            throw new RuntimeException(exception);

          }
        });
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        processor.startJob(model.getValue());
      }
    });
    return delayedModel;
  }
}