/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.navigate;

import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.SwingUtilities;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;

public abstract class AbstractBorderNavigationComponent extends JComponent {

  private final NavigationMouseLocationModel mouseLocationModel = new NavigationMouseLocationModel();

  public AbstractBorderNavigationComponent() {
    this(true);
  }

  public AbstractBorderNavigationComponent(final boolean navigationEnabled) {
    if (!navigationEnabled) {
      return;
    }
    final MouseAdapter mouseListener = new MouseAdapter() {
      @Override
      public void mouseMoved(final MouseEvent e) {
        final NavigationDirection direction = getNavigationDirection(e);
        mouseLocationModel.setValue(direction);
      }

      @Override
      public void mouseExited(final MouseEvent e) {
        mouseLocationModel.setValue(null);
      }
    };
    addMouseMotionListener(mouseListener);
    addMouseListener(mouseListener);

    final ObjectModel<NavigationDirection> delayedModel = DelayedObjectModelFactory
        .createDelayedModel(mouseLocationModel, IBorderNavigationConstants.POPUP_DELAY);
    delayedModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        final NavigationDirection newNavigationDirection = mouseLocationModel.getValue();
        if (newNavigationDirection == null) {
          return;
        }
        final INavigationHandler handler = new INavigationHandler() {
          @Override
          public void navigateTo(final NavigationDirection navigationDirection) {
            AbstractBorderNavigationComponent.this.navigateTo(navigationDirection);
          }
        };
        SwingUtilities.invokeLater(new Runnable() {
          @Override
          public void run() {
            BorderNavigationGlassPaneAttacher.attachNavigationGlassPane(
                AbstractBorderNavigationComponent.this,
                IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
                IBorderNavigationConstants.DIAGONAL_BORDER_RATIO,
                newNavigationDirection,
                handler);
          }
        });
      }
    });
  }

  private NavigationDirection getNavigationDirection(final MouseEvent event) {
    for (final NavigationDirection direction : NavigationDirection.values()) {
      final Shape shape = BorderNavigationGlassPaneAttacher.createNavigationArea(
          this,
          IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
          IBorderNavigationConstants.DIAGONAL_BORDER_RATIO,
          direction);
      if (shape.contains(event.getPoint())) {
        return direction;
      }
    }
    return null;
  }

  protected abstract void navigateTo(NavigationDirection direction);
}