/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.navigate;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.Window;

import javax.swing.JComponent;
import javax.swing.RootPaneContainer;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.GuiUtilities;

public class BorderNavigationGlassPaneAttacher {

  public static void attachNavigationGlassPane(
      final JComponent component,
      final int navigationBorderWidth,
      final int diagonalBorderRatio,
      final NavigationDirection direction,
      final INavigationHandler handler) {
    Ensure.ensureArgumentNotNull(direction);
    Ensure.ensureArgumentNotNull(handler);
    final Window frame = GuiUtilities.getWindowFor(component);
    if (!(frame instanceof RootPaneContainer)) {
      return;
    }
    final RootPaneContainer parentFrame = (RootPaneContainer) frame;
    final Point parentLocation = parentFrame.getLayeredPane().getLocationOnScreen();
    final Point componentLocation = component.getLocationOnScreen();

    final int dx = componentLocation.x - parentLocation.x;
    final int dy = componentLocation.y - parentLocation.y;
    final Shape area = getNavigationArea(
        component,
        navigationBorderWidth,
        diagonalBorderRatio,
        direction,
        dx,
        dy);
    final BorderNavigationGlassPane glassPane = new BorderNavigationGlassPane(
        area,
        direction,
        handler);
    parentFrame.setGlassPane(glassPane);
    glassPane.setVisible(true);
  }

  public static Shape createNavigationArea(
      final JComponent component,
      final int navigationBorderWidth,
      final int diagonalBorderRatio,
      final NavigationDirection direction) {
    return getNavigationArea(component, navigationBorderWidth, diagonalBorderRatio, direction, 0, 0);
  }

  private static Shape getNavigationArea(
      final JComponent component,
      final int navigationBorderWidth,
      final int diagonalBorderRatio,
      final NavigationDirection direction,
      final int dx,
      final int dy) {
    final Dimension componentSize = component.getSize();
    final int diagonalLength = Math.min(componentSize.width, componentSize.height)
        / diagonalBorderRatio;
    switch (direction) {
      case EAST:
        return new Rectangle(
            dx + componentSize.width - navigationBorderWidth,
            dy + diagonalLength,
            navigationBorderWidth,
            componentSize.height - 2 * diagonalLength);
      case NORTH:
        return new Rectangle(
            dx + diagonalLength,
            dy,
            componentSize.width - 2 * diagonalLength,
            navigationBorderWidth);
      case SOUTH:
        return new Rectangle(
            dx + diagonalLength,
            dy + componentSize.height - navigationBorderWidth,
            componentSize.width - 2 * diagonalLength,
            navigationBorderWidth);
      case WEST:
        return new Rectangle(dx, dy + diagonalLength, navigationBorderWidth, componentSize.height
            - 2
            * diagonalLength);
      case NORTH_EAST:
        return new Polygon(new int[]{
            dx + componentSize.width,
            dx + componentSize.width - diagonalLength,
            dx + componentSize.width - diagonalLength,
            dx + componentSize.width - navigationBorderWidth,
            dx + componentSize.width - navigationBorderWidth,
            dx + componentSize.width,
            dx + componentSize.width }, new int[]{
            dy,
            dy,
            dy + navigationBorderWidth,
            dy + navigationBorderWidth,
            dy + diagonalLength,
            dy + diagonalLength,
            dy }, 7);
      case NORTH_WEST:
        return new Polygon(new int[]{
            dx,
            dx + diagonalLength,
            dx + diagonalLength,
            dx + navigationBorderWidth,
            dx + navigationBorderWidth,
            dx,
            dx }, new int[]{
            dy,
            dy,
            dy + navigationBorderWidth,
            dy + navigationBorderWidth,
            dy + diagonalLength,
            dy + diagonalLength,
            dy }, 7);
      case SOUTH_EAST:
        return new Polygon(new int[]{
            dx + componentSize.width,
            dx + componentSize.width - diagonalLength,
            dx + componentSize.width - diagonalLength,
            dx + componentSize.width - navigationBorderWidth,
            dx + componentSize.width - navigationBorderWidth,
            dx + componentSize.width,
            dx + componentSize.width }, new int[]{
            dy + componentSize.height,
            dy + componentSize.height,
            dy + componentSize.height - navigationBorderWidth,
            dy + componentSize.height - navigationBorderWidth,
            dy + componentSize.height - diagonalLength,
            dy + componentSize.height - diagonalLength,
            dy + componentSize.height }, 7);
      case SOUTH_WEST:
        return new Polygon(new int[]{
            dx,
            dx + diagonalLength,
            dx + diagonalLength,
            dx + navigationBorderWidth,
            dx + navigationBorderWidth,
            dx,
            dx }, new int[]{
            dy + componentSize.height,
            dy + componentSize.height,
            dy + componentSize.height - navigationBorderWidth,
            dy + componentSize.height - navigationBorderWidth,
            dy + componentSize.height - diagonalLength,
            dy + componentSize.height - diagonalLength,
            dy + componentSize.height }, 7);
    }
    throw new UnreachableCodeReachedException();
  }
}