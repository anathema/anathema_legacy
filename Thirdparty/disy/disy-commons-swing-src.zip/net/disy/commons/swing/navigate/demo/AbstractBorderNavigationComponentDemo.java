/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.navigate.demo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseEvent;

import javax.swing.ToolTipManager;

import net.disy.commons.swing.navigate.AbstractBorderNavigationComponent;
import net.disy.commons.swing.navigate.NavigationDirection;

import de.jdemo.extensions.SwingDemoCase;

public class AbstractBorderNavigationComponentDemo extends SwingDemoCase {

  public void demo() {
    show(new DemoBorderNavigationComponent());
  }

  public static final class DemoBorderNavigationComponent extends AbstractBorderNavigationComponent {
    private static final int NAVIGATION_STEP = 10;
    private static final int RECTANGLE_SIZE = 20;

    private int x = 0;
    private int y = 0;

    public DemoBorderNavigationComponent() {
      ToolTipManager.sharedInstance().registerComponent(this);
    }

    @Override
    public String getToolTipText(final MouseEvent event) {
      return event.getX() + " " + event.getY(); //$NON-NLS-1$
    }

    @Override
    protected void navigateTo(final NavigationDirection direction) {
      switch (direction) {
        case EAST:
          x -= NAVIGATION_STEP;
          break;
        case WEST:
          x += NAVIGATION_STEP;
          break;
        case NORTH:
          y += NAVIGATION_STEP;
          break;
        case SOUTH:
          y -= NAVIGATION_STEP;
          break;
        case NORTH_EAST:
          x -= NAVIGATION_STEP;
          y += NAVIGATION_STEP;
          break;
        case NORTH_WEST:
          x += NAVIGATION_STEP;
          y += NAVIGATION_STEP;
          break;
        case SOUTH_EAST:
          x -= NAVIGATION_STEP;
          y -= NAVIGATION_STEP;
          break;
        case SOUTH_WEST:
          x += NAVIGATION_STEP;
          y -= NAVIGATION_STEP;
          break;
      }
      repaint();
    }

    @Override
    public Dimension getPreferredSize() {
      return new Dimension(450, 400);
    }

    @Override
    protected void paintComponent(final Graphics g) {
      super.paintComponent(g);
      final Dimension size = getSize();
      g.setColor(Color.WHITE);
      g.fillRect(0, 0, size.width, size.height);
      g.setColor(getForeground());
      g
          .drawString(
              "Place the mouse near the border of this component in order to navigate.", 10 + x, 100 + y); //$NON-NLS-1$
      g.drawRect(
          size.width / 2 - RECTANGLE_SIZE / 2 + x,
          size.height / 2 - RECTANGLE_SIZE / 2 + y,
          RECTANGLE_SIZE,
          RECTANGLE_SIZE);
    }
  }
}