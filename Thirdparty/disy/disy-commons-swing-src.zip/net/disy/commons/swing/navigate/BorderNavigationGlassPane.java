/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.navigate;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;

import javax.swing.JComponent;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.ColorUtilities;
import net.disy.commons.swing.color.SwingColors;

public class BorderNavigationGlassPane extends JComponent {

  private final Shape navigationShape;
  private final NavigationDirection direction;

  public BorderNavigationGlassPane(
      final Shape navigationShape,
      final NavigationDirection direction,
      final INavigationHandler handler) {
    Ensure.ensureArgumentNotNull(navigationShape);
    Ensure.ensureArgumentNotNull(direction);
    Ensure.ensureArgumentNotNull(handler);
    this.navigationShape = navigationShape;
    this.direction = direction;
    addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        handler.navigateTo(direction);
      }

      @Override
      public void mouseExited(final MouseEvent e) {
        dispose();
      }
    });
    addMouseMotionListener(new MouseMotionListener() {
      @Override
      public void mouseMoved(final MouseEvent e) {
        if (!navigationShape.contains(e.getPoint())) {
          dispose();
        }
      }

      @Override
      public void mouseDragged(final MouseEvent e) {
        if (!navigationShape.contains(e.getPoint())) {
          dispose();
        }
      }
    });
  }

  private void dispose() {
    setVisible(false);
  }

  @Override
  protected void paintComponent(final Graphics g) {
    final Graphics2D graphics = (Graphics2D) g;
    graphics.setColor(getNavigationButtonAreaColor());
    graphics.fill(navigationShape);
    final Rectangle bounds = navigationShape.getBounds();
    switch (direction) {
      case EAST:
      case WEST:
        renderVerticalErrorBar(graphics, navigationShape.getBounds());
        break;
      case NORTH:
      case SOUTH:
        renderHorizontalArrowBar(graphics, navigationShape.getBounds());
        break;
      case NORTH_EAST:
        renderHorizontalArrowBar(graphics, new Rectangle(
            bounds.x,
            bounds.y,
            bounds.width,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH));
        renderVerticalErrorBar(graphics, new Rectangle(
            bounds.x + bounds.width - IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.y,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.height));
        break;
      case NORTH_WEST:
        renderHorizontalArrowBar(graphics, new Rectangle(
            bounds.x,
            bounds.y,
            bounds.width,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH));
        renderVerticalErrorBar(graphics, new Rectangle(
            bounds.x,
            bounds.y,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.height));
        break;
      case SOUTH_EAST:
        renderHorizontalArrowBar(graphics, new Rectangle(
            bounds.x,
            bounds.y + bounds.height - IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.width,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH));
        renderVerticalErrorBar(graphics, new Rectangle(
            bounds.x + bounds.width - IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.y,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.height));
        break;
      case SOUTH_WEST:
        renderHorizontalArrowBar(graphics, new Rectangle(
            bounds.x,
            bounds.y + bounds.height - IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.width,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH));
        renderVerticalErrorBar(graphics, new Rectangle(
            bounds.x,
            bounds.y,
            IBorderNavigationConstants.NAVIGATION_BORDER_WIDTH,
            bounds.height));
        break;
    }
  }

  private void renderHorizontalArrowBar(final Graphics2D graphics, final Rectangle rectangle) {
    renderArrowBar(graphics, rectangle, rectangle.width, 1, 0);
  }

  private void renderVerticalErrorBar(final Graphics2D graphics, final Rectangle rectangle) {
    renderArrowBar(graphics, rectangle, rectangle.height, 0, 1);
  }

  private void renderArrowBar(
      final Graphics2D graphics,
      final Rectangle rectangle,
      final int length,
      final int dx,
      final int dy) {
    final int arrowCount = getAppropriateArrowCount(length);
    final int centerY = (int) rectangle.getCenterY();
    final int centerX = (int) rectangle.getCenterX();
    renderArrow(graphics, centerX, centerY, direction);
    final int spacing = length / (arrowCount + 1);
    for (int i = 1; i <= arrowCount / 2; ++i) {
      renderArrow(graphics, centerX + (spacing * i) * dx, centerY + (spacing * i) * dy, direction);
      renderArrow(graphics, centerX - (spacing * i) * dx, centerY - (spacing * i) * dy, direction);
    }
  }

  private static int getAppropriateArrowCount(final int length) {
    return length / 75;
  }

  private Color getNavigationButtonAreaColor() {
    final Color controlColor = SwingColors.getControlColor();
    return ColorUtilities.getTransparentColor(controlColor, 128);
  }

  private static void renderArrow(
      final Graphics g,
      final int x,
      final int y,
      final NavigationDirection direction) {
    g.setColor(SwingColors.getPanelForegroundColor());
    switch (direction) {
      case WEST:
        g.fillPolygon(new int[]{ x - 3, x + 2, x + 2, x - 3 }, new int[]{ y, y - 5, y + 5, y }, 4);
        return;
      case EAST:
        g.fillPolygon(new int[]{ x + 2, x - 3, x - 3, x + 2 }, new int[]{ y, y - 5, y + 5, y }, 4);
        return;
      case NORTH:
        g.fillPolygon(new int[]{ x, x - 5, x + 5, x }, new int[]{ y - 2, y + 3, y + 3, y - 2 }, 4);
        return;
      case SOUTH:
        g.fillPolygon(new int[]{ x, x - 5, x + 5, x }, new int[]{ y + 2, y - 3, y - 3, y + 2 }, 4);
        return;
      case NORTH_EAST:
        g.fillPolygon(new int[]{ x + 2, x - 5, x + 2, x + 2 }, new int[]{
            y - 2,
            y - 2,
            y + 5,
            y - 2 }, 4);
        return;
      case NORTH_WEST:
        g.fillPolygon(new int[]{ x - 2, x - 2, x + 5, x - 2 }, new int[]{
            y - 2,
            y + 5,
            y - 2,
            y - 2 }, 4);
        return;
      case SOUTH_EAST:
        g.fillPolygon(new int[]{ x + 2, x - 5, x + 2, x + 2 }, new int[]{
            y + 2,
            y + 2,
            y - 5,
            y + 2 }, 4);
        return;
      case SOUTH_WEST:
        g.fillPolygon(new int[]{ x - 2, x - 2, x + 5, x - 2 }, new int[]{
            y + 2,
            y - 5,
            y + 2,
            y + 2 }, 4);
        return;
    }
    throw new UnreachableCodeReachedException();
  }
}