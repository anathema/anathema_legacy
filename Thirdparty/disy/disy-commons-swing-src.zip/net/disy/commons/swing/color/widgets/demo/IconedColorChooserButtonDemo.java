//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets.demo;

import java.awt.Color;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.color.widgets.IconedColorChooserButton;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class IconedColorChooserButtonDemo extends SwingDemoCase {

  public void demoTextColorChooserButton() {
    show(IconedColorChooserButton.createTextColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }

  public void demoTextColorChooserDropDownButton() {
    show(IconedColorChooserButton.createTextColorChooserButton(
        new ColorModel(Color.RED),
        new IconedColorChooserButton.DropDownStrategy(false)).getContent());
  }

  public void demoMarkerColorChooserButton() {
    show(IconedColorChooserButton.createMarkerColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }

  public void demoBackgroundColorChooserButton() {
    show(IconedColorChooserButton.createBackgroundColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }
}