// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutDirection;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.util.GuiUtilities;

/**
 * adds to standard swing colorChooser a possibility to enter transparency
 */
public class ColorChooserDialog {

  /** @deprecated As of 17.03.2005 (gebhard), replaced by {@link #showDialog(Component, IColorChooserConfiguration, Color)} */
  public static Color showDialog(
      Component parent,
      String title,
      Color color,
      boolean hasTransparencyChangePanel) {
    return showDialog(parent, new DefaultColorChooserConfiguration(
        title,
        hasTransparencyChangePanel), color);
  }

  public static Color showDialog(
      Component parent,
      IColorChooserConfiguration configuration,
      Color color) {
    //TODO 15.12.2004 (gebhard): Auf neue UserDialoge umstellen
    final ColorModel colorModel = new ColorModel(color);
    final ColorChooserPanel colorChooserPanel = new ColorChooserPanel(colorModel, configuration
        .isTransparencyEnabled());
    final JDialog dialog = GuiUtilities.createDialog(parent, configuration
        .getColorChooserDialogTitle());
    dialog.setModal(true);

    final boolean[] canceled = new boolean[]{ false };

    Action okAction = new SmartAction(DisyCommonsSwingMessages.getString("ColorChooserDialog.Ok")) { //$NON-NLS-1$
      protected void execute(Component parentComponent) {
        dialog.dispose();
        canceled[0] = false;
      }
    };
    Action cancelAction = new SmartAction(DisyCommonsSwingMessages
        .getString("ColorChooserDialog.Cancel")) { //$NON-NLS-1$
      protected void execute(Component parentComponent) {
        dialog.dispose();
        canceled[0] = true;
      }
    };

    Action resetAction = new SmartAction(DisyCommonsSwingMessages
        .getString("ColorChooserDialog.Reset")) { //$NON-NLS-1$
      protected void execute(Component parentComponent) {
        colorChooserPanel.resetColor();
      }
    };

    JButton okButton = new JButton(okAction);
    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.HORIZONTAL);
    builder.add(okButton);
    builder.add(cancelAction);
    builder.add(resetAction);
    JPanel buttonPanel = builder.createPanel();

    dialog.getContentPane().setLayout(
        new BorderLayout(LayoutUtilities.getComponentGroupsSpacing(), LayoutUtilities
            .getComponentGroupsSpacing()));
    dialog.getContentPane().add(colorChooserPanel.getContent(), BorderLayout.CENTER);
    dialog.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

    dialog.getRootPane().setDefaultButton(okButton);
    dialog.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
    dialog.pack();
    try {
      net.disy.commons.swing.util.GuiUtilities.show(dialog);
    }
    catch (ArrayIndexOutOfBoundsException e) {
      // workaround: swing bug JDK1.4 - kann ignoriert werden, da kein Effekt
    }
    if (canceled[0]) {
      return color;
    }
    return colorModel.getColor();
  }
}