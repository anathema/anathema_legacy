//Copyright (c) 2001 by disy Informationssysteme GmbH

package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public abstract class AbstractColorChooseButton extends AbstractColorChoosingComponent {

  private static final Insets INSETS = new Insets(5, 5, 5, 5);

  public AbstractColorChooseButton() {
    this(new ColorModel());
  }

  /** @deprecated As of 01.10.2004 (gebhard), replaced by {@link #AbstractColorChooseButton(ColorModel)}*/
  public AbstractColorChooseButton(Color color) {
    this(new ColorModel(color));
  }

  public AbstractColorChooseButton(ColorModel model) {
    super(model);
  }

  /** @deprecated As of 01.10.2004 (gebhard), replaced by {@link #AbstractColorChooseButton(ColorModel, String)}*/
  public AbstractColorChooseButton(Color color, final String title) {
    this(new ColorModel(color), title);
  }

  public AbstractColorChooseButton(ColorModel model, String title) {
    super(model, title);
  }

  protected final JComponent createContent() {
    JButton button = createButton();
    button.setOpaque(false);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        performColorChooseDialog();
      }
    });
    button.setToolTipText(getTooltipText());
    return button;
  }

  protected String getTooltipText() {
    return DisyCommonsSwingMessages.getString("ColorChooseButton.ToolTip"); //$NON-NLS-1$
  }

  protected abstract JButton createButton();

  protected final Insets getColorRectangleInsets() {
    return INSETS;
  }
}