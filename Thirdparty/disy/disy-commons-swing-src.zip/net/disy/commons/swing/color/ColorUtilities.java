/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color;

import java.awt.Color;

public class ColorUtilities {

  protected ColorUtilities() {
    throw new UnsupportedOperationException();
  }

  public static String convertToRGBHex(final Color color, boolean withHash) {
    String hexString = "";
    if (withHash) {
      hexString += "#";
    }
    hexString += addLeadingZeros(Integer.toHexString(color.getRed()), 2);
    hexString += addLeadingZeros(Integer.toHexString(color.getGreen()), 2);
    hexString += addLeadingZeros(Integer.toHexString(color.getBlue()), 2);
    return hexString.toUpperCase();
  }

  public static Color convertFromRGBHex(String hexString, final boolean withHash) {
    Color color;
    if (withHash) {
      hexString = hexString.substring(1);
    }
    color = new Color(Integer.parseInt(hexString.substring(0, 2), 16), Integer.parseInt(
        hexString.substring(2, 4),
        16), Integer.parseInt(hexString.substring(4, 6), 16));
    return color;
  }

  private static String addLeadingZeros(String number, int numberOfDigits) {
    String result = number;
    while (result.length() < numberOfDigits) {
      result = "0" + result;
    }
    return result;
  }

  public static Color createIntermediateColor(final Color color1, final Color color2) {
    final int blue = (color1.getBlue() + color2.getBlue()) / 2;
    final int red = ((color1.getRed() + color2.getRed())) / 2;
    final int green = ((color1.getGreen() + color2.getGreen())) / 2;
    return new Color(red, green, blue);
  }

  public static float getHue(final Color color) {
    final float[] hsb = Color.RGBtoHSB(
        color.getRed(),
        color.getGreen(),
        color.getBlue(),
        new float[3]);
    return hsb[0];
  }

  public static float getSaturation(final Color color) {
    final float[] hsb = Color.RGBtoHSB(
        color.getRed(),
        color.getGreen(),
        color.getBlue(),
        new float[3]);
    return hsb[1];
  }

  public static float getBrightness(final Color color) {
    final float[] hsb = Color.RGBtoHSB(
        color.getRed(),
        color.getGreen(),
        color.getBlue(),
        new float[3]);
    return hsb[2];
  }

  public static Color getTransparentColor(final Color color, final int alpha) {
    return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
  }
}