//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ColorModel extends AbstractChangeableModel {

  private Color color;
  private final boolean supressEventsOnEquality;

  public ColorModel() {
    this(Color.BLACK);
  }

  public ColorModel(Color color) {
    this(color, true);
  }

  public ColorModel(Color color, boolean supressEventsOnEquality) {
    this.supressEventsOnEquality = supressEventsOnEquality;
    setColor(color);
  }

  public Color getColor() {
    return color;
  }

  public void setColor(Color color) {
    Ensure.ensureArgumentNotNull(color);
    if (supressEventsOnEquality && color.equals(this.color)) {
      return;
    }
    this.color = color;
    fireChangeEvent();
  }
}