//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ColorModel extends AbstractChangeableModel {

  private Color color = Color.BLACK;

  public ColorModel() {
    //nothing to do
  }
  
  public ColorModel(Color color) {
    this();
    setColor(color);
  }

  public Color getColor() {
    return color;
  }

  public void setColor(Color color) {
    Ensure.ensureArgumentNotNull(color);
    if (color.equals(this.color)) {
      return;
    }
    this.color = color;
    fireChangeEvent();
  }
}