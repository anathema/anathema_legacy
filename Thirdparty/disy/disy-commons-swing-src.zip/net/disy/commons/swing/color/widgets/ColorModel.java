/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.Ensure;

public class ColorModel extends AbstractChangeableModel {

  private Color color;
  private final boolean supressEventsOnEquality;

  public ColorModel() {
    this(Color.BLACK);
  }

  public ColorModel(final Color color) {
    this(color, true);
  }

  public ColorModel(final Color color, final boolean supressEventsOnEquality) {
    this.supressEventsOnEquality = supressEventsOnEquality;
    setColor(color);
  }

  public Color getColor() {
    return color;
  }

  public void setColor(final Color color) {
    Ensure.ensureArgumentNotNull(color);
    if (supressEventsOnEquality && color.equals(this.color)) {
      return;
    }
    this.color = color;
    fireChangeEvent();
  }
}