//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

// NOT_PUBLISHED
public interface IColorChooserConfiguration {

  public boolean isTransparencyEnabled();

  public String getColorChooserDialogTitle();

}
