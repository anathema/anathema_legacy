package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;
import javax.swing.plaf.MenuItemUI;
import javax.swing.plaf.basic.BasicMenuItemUI;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.layout.grid.EndOfLineMarkerComponent;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;

public abstract class ColorPopupMenu extends JPopupMenu {

  private static final int COLUMN_COUNT = 6;

  private final static Color[] DEFAULT_COLORS = new Color[]{
  //grey scales  
      Color.WHITE,
      Color.LIGHT_GRAY,
      Color.GRAY,
      Color.DARK_GRAY,
      Color.BLACK,
      Color.PINK,//added this one to fill up the columns...

      //primary colors
      Color.RED,
      Color.YELLOW,
      Color.GREEN,
      Color.CYAN,
      Color.BLUE,
      Color.MAGENTA,

      //dark primary colors
      new Color(128, 0, 0), //dark red
      new Color(128, 128, 0), //dark yellow
      new Color(0, 128, 0),//dark green
      new Color(0, 128, 128),//dark cyan
      new Color(0, 0, 128),//dark blue
      new Color(128, 0, 128),//dark magenta

      //others
      Color.ORANGE, };

  public ColorPopupMenu(boolean transparencyEnabled) {
    setLayout(new GridDialogLayout(COLUMN_COUNT, true, LayoutUtilities.getDpiAdjusted(2), LayoutUtilities
        .getDpiAdjusted(2)));
    GridDialogLayoutData data = new GridDialogLayoutData();
    data.setHorizontalSpan(COLUMN_COUNT);

    if (transparencyEnabled) {
      add(new JMenuItem(new SmartAction("Transparent") {
        @Override
        protected void execute(Component parentComponent) {
          setColor(new Color(0, 0, 0, 0));
        }
      }), data);
      add(new JPopupMenu.Separator(), data);
    }
    for (int i = 0; i < DEFAULT_COLORS.length; ++i) {
      addColorItem(DEFAULT_COLORS[i]);
    }
    add(new EndOfLineMarkerComponent());

    add(new JPopupMenu.Separator(), data);
    add(new JMenuItem(new SmartAction("Weitere Farben...") {
      @Override
      protected void execute(Component parentComponent) {
        performColorChooserDialog(parentComponent);
      }
    }), data);
  }

  protected abstract void performColorChooserDialog(Component parentComponent);

  protected abstract void setColor(Color color);

  private void addColorItem(final Color color) {
    Icon icon = new Icon() {
      public int getIconHeight() {
        return 16;
      }

      public int getIconWidth() {
        return 16;
      }

      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillRect(x, y, getIconWidth(), getIconHeight());
        g.setColor(SwingColors.getControlDkShadowColor());
        g.drawLine(x, y, getIconWidth(), y);
        g.drawLine(x, y, x, y + getIconHeight() - 1);
        g.setColor(SwingColors.getControlLtHighlightColor());
        g.drawLine(x, y + getIconHeight() - 1, getIconWidth(), y + getIconHeight() - 1);
        g.drawLine(x + getIconWidth() - 1, y, x + getIconWidth() - 1, y + getIconHeight() - 1);
      }
    };
    final JMenuItem menuItem = new JMenuItem(new SmartAction(icon) {
      @Override
      protected void execute(Component parentComponent) {
        setColor(color);
      }
    }) {
      @Override
      public void setUI(MenuItemUI ui) {
        //Don't allow the UI to be modified!
        super.setUI(new BasicMenuItemUI() {
          @Override
          public Dimension getPreferredSize(JComponent component) {
            JMenuItem menuItem = (JMenuItem) component;
            return new Dimension(menuItem.getIcon().getIconWidth() + 4, menuItem.getIcon().getIconHeight() + 2);
          }

          @Override
          protected void paintMenuItem(
              Graphics g,
              JComponent component,
              Icon checkIcon,
              Icon arrowIcon,
              Color background,
              Color foreground,
              int defaultTextIconGap) {
            JMenuItem menuItem = (JMenuItem) component;
            paintBackground(g, menuItem, background);
            if (menuItem.getIcon() != null) {
              Icon paintIcon;
              if (!model.isEnabled()) {
                paintIcon = menuItem.getDisabledIcon();
              }
              else if (model.isPressed() && model.isArmed()) {
                paintIcon = menuItem.getPressedIcon();
                if (paintIcon == null) {
                  // Use default icon
                  paintIcon = menuItem.getIcon();
                }
              }
              else {
                paintIcon = menuItem.getIcon();
              }
              if (paintIcon != null) {
                paintIcon.paintIcon(component, g, 2, 1);
              }
            }
          }
        });
      }
    };
    add(menuItem);
  }
}