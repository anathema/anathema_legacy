// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

/**
 * Kurze Beschreibung der Verantwortlichkeit von TransparencyBarPanel
 */
public class TransparencyBarPanel implements IDialogComponent {

  private final JSlider alphaSlider;
  private final SpinnerNumberModel spinnerModel;
  private final boolean showLabel;

  public TransparencyBarPanel(final ColorModel colorModel) {
    this(colorModel, true);
  }

  public TransparencyBarPanel(final ColorModel colorModel, boolean showLabel) {
    this.showLabel = showLabel;
    alphaSlider = new JSlider();
    alphaSlider.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        int percentage = alphaSlider.getValue();
        updateModel(colorModel, percentage);
      }
    });

    spinnerModel = new SpinnerNumberModel(0, 0, 100, 1);
    spinnerModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateModel(colorModel, spinnerModel.getNumber().intValue());
      }
    });

    colorModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateView(colorModel);
      }
    });
    updateView(colorModel);
  }

  private void updateModel(ColorModel colorModel, int percentage) {
    int alpha = 255 - (int) (percentage * 2.55);
    Color color = colorModel.getColor();
    Color alphaColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    colorModel.setColor(alphaColor);
  }

  private void updateView(final ColorModel colorModel) {
    int alpha = colorModel.getColor().getAlpha();
    int percentage = 100 - (int) Math.round(alpha / 2.55);
    alphaSlider.setValue(percentage);
    spinnerModel.setValue(new Integer(percentage));
  }

  public int getColumnCount() {
    return showLabel ? 4 : 3;
  }

  public void fillInto(JPanel panel, int columnCount) {
    if (showLabel) {
      panel.add(new JLabel(DisyCommonsSwingMessages.getString("TransparencyBarPanel.Transparency")), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    }
    panel.add(alphaSlider, GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(new JSpinner(spinnerModel));
    panel.add(new JLabel("%")); //$NON-NLS-1$
  }
}