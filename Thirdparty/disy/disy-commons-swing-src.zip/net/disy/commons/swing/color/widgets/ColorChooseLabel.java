//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;


// NOT_PUBLISHED
public class ColorChooseLabel extends AbstractColorChoosingComponent {

  private static final Insets INSETS = new Insets(0, 0, 0, 0);

  public ColorChooseLabel(ColorModel model) {
    super(model);
  }

  protected JComponent createContent() {
    JComponent label = new JComponent() { //$NON-NLS-1$
      public Dimension getPreferredSize() {
        return new Dimension(50, 20);
      }

      public void paint(Graphics g) {
        paintColorRectangle(g, getSize(), isEnabled());
        super.paint(g);
      }
    };
    label.setOpaque(false);
    label.addMouseListener(new MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        if (e.getClickCount() == 2 && !e.isMetaDown()) {
          performColorChooseDialog();
        }
      }
    });
    label.addKeyListener(new KeyAdapter() {
      public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_F2) {
          performColorChooseDialog();
        }
      }
    });
    return label;
  }

  protected Insets getColorRectangleInsets() {
    return INSETS;
  }
}