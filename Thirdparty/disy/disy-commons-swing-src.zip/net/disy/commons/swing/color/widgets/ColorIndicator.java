// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

public class ColorIndicator extends ColorChooserLabel {

  public ColorIndicator(Color color) {
    this(new ColorModel(color));
  }

  public ColorIndicator(ColorModel colorModel) {
    super(colorModel, new DefaultColorChooserConfiguration(true));
    setEditable(false);
  }

}