//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

// NOT_PUBLISHED
public class DefaultColorChooserConfiguration implements IColorChooserConfiguration {

  private String colorChooserDialogTitle;
  private boolean transparencyEnabled;

  public DefaultColorChooserConfiguration() {
    this(DisyCommonsSwingMessages.getString("ColorChooserButton.DefaultTitle"), false); //$NON-NLS-1$
  }

  public DefaultColorChooserConfiguration(boolean transparencyEnabled) {
    this(DisyCommonsSwingMessages.getString("ColorChooserButton.DefaultTitle"), transparencyEnabled); //$NON-NLS-1$
  }

  public DefaultColorChooserConfiguration(
      String colorChooserDialogTitle,
      boolean transparencyEnabled) {
    Ensure.ensureArgumentNotNull(colorChooserDialogTitle);
    this.colorChooserDialogTitle = colorChooserDialogTitle;
    this.transparencyEnabled = transparencyEnabled;
  }

  public boolean isTransparencyEnabled() {
    return transparencyEnabled;
  }

  public String getColorChooserDialogTitle() {
    return colorChooserDialogTitle;
  }

  public void setColorChooserDialogTitle(String colorChooserDialogTitle) {
    Ensure.ensureArgumentNotNull(colorChooserDialogTitle);
    this.colorChooserDialogTitle = colorChooserDialogTitle;
  }

  public void setTransparencyEnabled(boolean transparencyEnabled) {
    this.transparencyEnabled = transparencyEnabled;
  }
}