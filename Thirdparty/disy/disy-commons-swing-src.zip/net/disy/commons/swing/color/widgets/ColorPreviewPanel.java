// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.EndOfLineMarkerComponent;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

/**
 * Kurze Beschreibung der Verantwortlichkeit von ColorPreviewPanel
 */
public class ColorPreviewPanel implements IDialogComponent {

  private ColorIndicator oldColorIndicator;
  private ColorIndicator currentColorIndicator;

  public ColorPreviewPanel(ColorModel colorModel) {
    oldColorIndicator = new ColorIndicator(new ColorModel(colorModel.getColor()));
    currentColorIndicator = new ColorIndicator(colorModel);
  }

  public int getColumnCount() {
    return 2;
  }

  public void fillInto(JPanel panel, int columnCount) {
    JLabel oldColorLabel = new JLabel(DisyCommonsSwingMessages
        .getString("ColorPreviewPanel.OriginalColor")); //$NON-NLS-1$
    JLabel currentColorLabel = new JLabel(DisyCommonsSwingMessages
        .getString("ColorPreviewPanel.SelectedColor")); //$NON-NLS-1$

    panel.add(oldColorLabel, GridDialogLayoutData.RIGHT);
    panel.add(oldColorIndicator.getContent());
    panel.add(new EndOfLineMarkerComponent());

    panel.add(currentColorLabel, GridDialogLayoutData.RIGHT);
    panel.add(currentColorIndicator.getContent());
    panel.add(new EndOfLineMarkerComponent());
  }
}