//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets.demo;

import java.awt.Color;

import net.disy.commons.swing.color.widgets.ColorChooserPanel;
import net.disy.commons.swing.color.widgets.ColorModel;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class ColorChooserPanelDemo extends SwingDemoCase {
  public void demo() {
    show(new ColorChooserPanel(new ColorModel(Color.MAGENTA), true).getContent());
  }
}