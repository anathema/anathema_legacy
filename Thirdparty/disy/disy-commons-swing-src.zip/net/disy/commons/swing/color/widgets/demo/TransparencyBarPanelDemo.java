//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets.demo;


import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.color.widgets.TransparencyBarPanel;
import net.disy.commons.swing.layout.grid.GridDialogPanel;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class TransparencyBarPanelDemo extends SwingDemoCase {

  public void demo() {
    GridDialogPanel panel = new GridDialogPanel();
    panel.add(new TransparencyBarPanel(new ColorModel()));
    show(panel.getContent());
  }
  
}