package net.disy.commons.swing.color.widgets.demo;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JComponent;

import net.disy.commons.swing.color.widgets.ColorChooserButton;
import net.disy.commons.swing.color.widgets.ColorChooserLabel;
import net.disy.commons.swing.color.widgets.ColorIndicator;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.color.widgets.DefaultColorChooserConfiguration;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author gebhard
 */
public class ColorChooserButtonDemo extends SwingDemoCase {

  public void demoShowColorChooseButton() {
    ColorChooserButton button1 = new ColorChooserButton();
    button1.setEnabled(false);
    ColorChooserButton button2 = new ColorChooserButton(
        new ColorModel(new Color(255, 255, 0, 128)),
        new DefaultColorChooserConfiguration(true));

    show(new JComponent[]{
        new ColorChooserButton(new ColorModel(Color.red)).getContent(),
        button1.getContent(),
        button2.getContent() }, new FlowLayout());
  }

  public void demoColorIndicator() {
    show(new ColorIndicator(new ColorModel(Color.red)).getContent());
  }

  public void demoColorChooseLabel() {
    ColorChooserLabel colorLabel = new ColorChooserLabel(new ColorModel(Color.red));
    show(colorLabel.getContent());
  }

  public void demoColorChooseLabelWithTransparency() {
    ColorChooserLabel colorLabel = new ColorChooserLabel(
        new ColorModel(Color.red),
        new DefaultColorChooserConfiguration(true));
    show(colorLabel.getContent());
  }
}