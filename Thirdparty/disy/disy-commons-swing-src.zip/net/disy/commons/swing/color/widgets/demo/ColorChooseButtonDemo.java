package net.disy.commons.swing.color.widgets.demo;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JComponent;

import net.disy.commons.swing.color.widgets.ColorChooseButton;
import net.disy.commons.swing.color.widgets.ColorChooseLabel;
import net.disy.commons.swing.color.widgets.ColorIndicator;
import net.disy.commons.swing.color.widgets.ColorModel;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author gebhard
 */
public class ColorChooseButtonDemo extends SwingDemoCase {

  public void demoShowColorChooseButton() {
    ColorChooseButton button1 = new ColorChooseButton();
    button1.setEnabled(false);
    ColorChooseButton button2 = new ColorChooseButton(new ColorModel(new Color(255, 255, 0, 128)));
    button2.setTransparencyEnabled(true);

    show(new JComponent[]{
        new ColorChooseButton(new ColorModel(Color.red)).getContent(),
        button1.getContent(),
        button2.getContent() }, new FlowLayout());
  }

  public void demoColorIndicator() {
    show(new ColorIndicator(new ColorModel(Color.red)).getContent());
  }

  public void demoColorChooseLabel() {
    ColorChooseLabel colorLabel = new ColorChooseLabel(new ColorModel(Color.red));
    show(colorLabel.getContent());
  }

  public void demoColorChooseLabelWithTransparency() {
    ColorChooseLabel colorLabel = new ColorChooseLabel(new ColorModel(Color.red));
    colorLabel.setTransparencyEnabled(true);
    show(colorLabel.getContent());
  }
}