package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractColorDemoCase extends SwingDemoCase {

  protected static String getSimpleClassName(Class class1) {
    String className = class1.getName();
    int index = className.lastIndexOf('.');
    return className.substring(index + 1);
  }

  public static JLabel createColorLabel(String name, Color color) {
    return new JLabel(name, createColorIcon(color), SwingConstants.LEFT);
  }

  public static Icon createColorIcon(final Color color) {
    return new Icon() {
      public int getIconHeight() {
        return 16;
      }

      public int getIconWidth() {
        return 24;
      }

      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillRect(x, y, getIconWidth(), getIconHeight());
      }
    };
  }
}