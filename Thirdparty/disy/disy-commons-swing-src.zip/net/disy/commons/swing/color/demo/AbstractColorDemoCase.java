/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractColorDemoCase extends SwingDemoCase {

  protected static String getSimpleClassName(final Class<?> class1) {
    final String className = class1.getName();
    final int index = className.lastIndexOf('.');
    return className.substring(index + 1);
  }

  public static JLabel createColorLabel(final String name, final Color color) {
    return new JLabel(name, createColorIcon(color), SwingConstants.LEFT);
  }

  public static Icon createColorIcon(final Color color) {
    return new Icon() {
      @Override
      public int getIconHeight() {
        return 16;
      }

      @Override
      public int getIconWidth() {
        return 24;
      }

      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        g.setColor(color);
        g.fillRect(x, y, getIconWidth(), getIconHeight());
      }
    };
  }
}