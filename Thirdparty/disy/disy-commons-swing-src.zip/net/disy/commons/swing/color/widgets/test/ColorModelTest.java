/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.widgets.test;

import java.awt.Color;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.color.widgets.ColorModel;

import org.easymock.EasyMock;

public class ColorModelTest extends CoreTestCase {

  private ColorModel model;
  private IChangeListener mockListener;

  private void assertEventSuppressedOnNonChange() {
    model.addChangeListener(mockListener);
    EasyMock.replay(mockListener);
    model.setColor(model.getColor());
    EasyMock.verify(mockListener);
  }

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    mockListener = EasyMock.createMock(IChangeListener.class);
  }

  public void testEventOnChange() throws Exception {
    model = new ColorModel(Color.BLACK);
    model.addChangeListener(mockListener);
    mockListener.stateChanged();
    EasyMock.replay(mockListener);
    model.setColor(Color.WHITE);
    EasyMock.verify(mockListener);
  }

  public void testEventSupressedOnNonChange() throws Exception {
    model = new ColorModel(Color.BLACK);
    assertEventSuppressedOnNonChange();
  }

  public void testEventSuppressedOnNonChangeWithNoArgConstructor() throws Exception {
    model = new ColorModel();
    assertEventSuppressedOnNonChange();
  }

  public void testEventNotSupressedOnNonChange() throws Exception {
    model = new ColorModel(Color.BLACK, false);
    model.addChangeListener(mockListener);
    mockListener.stateChanged();
    EasyMock.replay(mockListener);
    model.setColor(Color.BLACK);
    EasyMock.verify(mockListener);
  }
}