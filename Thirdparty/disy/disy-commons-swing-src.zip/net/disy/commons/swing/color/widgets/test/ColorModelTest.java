//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets.test;

import java.awt.Color;

import javax.swing.event.ChangeListener;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.color.widgets.ColorModel;

import org.easymock.MockControl;
import org.easymock.internal.AlwaysMatcher;

// NOT_PUBLISHED
public class ColorModelTest extends CoreTestCase {

  private ColorModel model;
  private MockControl control;
  private ChangeListener listener;

  private void assertEventSuppressedOnNonChange() {
    model.addChangeListener(listener);
    control.replay();
    model.setColor(model.getColor());
    control.verify();
  }

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    control = MockControl.createControl(ChangeListener.class);
    control.setDefaultMatcher(new AlwaysMatcher());
    listener = (ChangeListener) control.getMock();
  }

  public void testEventOnChange() throws Exception {
    model = new ColorModel(Color.BLACK);
    model.addChangeListener(listener);
    listener.stateChanged(null);
    control.replay();
    model.setColor(Color.WHITE);
    control.verify();
  }

  public void testEventSupressedOnNonChange() throws Exception {
    model = new ColorModel(Color.BLACK);
    assertEventSuppressedOnNonChange();
  }

  public void testEventSuppressedOnNonChangeWithNoArgConstructor() throws Exception {
    model = new ColorModel();
    assertEventSuppressedOnNonChange();
  }

  public void testEventNotSupressedOnNonChange() throws Exception {
    model = new ColorModel(Color.BLACK, false);
    model.addChangeListener(listener);
    listener.stateChanged(null);
    control.replay();
    model.setColor(Color.BLACK);
    control.verify();
  }
}