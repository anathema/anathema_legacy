//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

// NOT_PUBLISHED
public class ColorChooserLabel extends AbstractColorChoosingComponent {

  public ColorChooserLabel(ColorModel model) {
    this(model, new DefaultColorChooserConfiguration());
  }

  public ColorChooserLabel(ColorModel model, IColorChooserConfiguration configuration) {
    super(model, configuration);
  }

  @Override
  protected JComponent createContent() {
    JComponent label = new JComponent() {
      @Override
      public Dimension getPreferredSize() {
        return new Dimension(50, 20);
      }

      @Override
      public void paint(Graphics g) {
        paintColorRectangle(g, 0, 0, getSize(), isEnabled());
        super.paint(g);
      }
    };
    label.setOpaque(false);
    label.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseReleased(MouseEvent e) {
        if (e.getClickCount() == 2 && !e.isMetaDown()) {
          performColorChooseDialog();
        }
      }
    });
    label.addKeyListener(new KeyAdapter() {
      @Override
      public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_F2) {
          performColorChooseDialog();
        }
      }
    });
    return label;
  }
}