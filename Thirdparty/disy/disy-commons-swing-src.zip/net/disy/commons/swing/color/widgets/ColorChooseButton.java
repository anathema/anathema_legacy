// Copyright (c) 2001 by disy Informationssysteme GmbH

package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JButton;

public class ColorChooseButton extends AbstractColorChooseButton {

  public ColorChooseButton() {
    this(new ColorModel());
  }

  /** @deprecated As of 01.10.2004 (gebhard), replaced by {@link #ColorChooseButton(ColorModel)}*/
  public ColorChooseButton(Color color) {
    this(new ColorModel(color));
  }

  public ColorChooseButton(ColorModel model) {
    super(model);
  }

  /** @deprecated As of 01.10.2004 (gebhard), replaced by {@link #ColorChooseButton(ColorModel, String)}*/
  public ColorChooseButton(Color color, final String title) {
    this(new ColorModel(color), title);
  }

  public ColorChooseButton(ColorModel model, String title) {
    super(model, title);
  }

  protected JButton createButton() {
    return new JButton("        ") { //$NON-NLS-1$
      public void paint(Graphics g) {
        paintColorRectangle(g, getSize(), isEnabled());
        super.paint(g);
      }
    };
  }
}