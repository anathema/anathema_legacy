//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;

/** @deprecated As of 05.12.2005 (gebhard), replaced by {@link ColorChooserButton} */
@Deprecated
public class ColorChooseButton extends ColorChooserButton {

  public ColorChooseButton(Color color) {
    super(new ColorModel(color));
  }

}