//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color;

import java.awt.Color;

import javax.swing.UIManager;

// NOT_PUBLISHED
public class SwingColors {

  public static Color getControlColor() {
    return UIManager.getColor("control"); //$NON-NLS-1$
  }

  public static Color getControlDkShadowColor() {
    return UIManager.getColor("controlDkShadow"); //$NON-NLS-1$
  }

  public static Color getControlHighlightColor() {
    return UIManager.getColor("controlHighlight"); //$NON-NLS-1$
  }

  public static Color getControlLtHighlightColor() {
    return UIManager.getColor("controlLtHighlight"); //$NON-NLS-1$
  }

  public static Color getControlShadowColor() {
    return UIManager.getColor("controlShadow"); //$NON-NLS-1$
  }

  public static Color getPanelBackgroundColor() {
    return UIManager.getColor("Panel.background"); //$NON-NLS-1$
  }

  public static Color getPanelForegroundColor() {
    return UIManager.getColor("Panel.foreground"); //$NON-NLS-1$
  }

  public static Color getTabelFocusCellBackgroundColor() {
    return UIManager.getColor("Table.focusCellBackground"); //$NON-NLS-1$
  }

  public static Color getTabelFocusCellForegroundColor() {
    return UIManager.getColor("Table.focusCellForeground"); //$NON-NLS-1$
  }

  public static Color getTableHeaderBackgroundColor() {
    return UIManager.getColor("TableHeader.background"); //$NON-NLS-1$
  }

  public static Color getTableHeaderForegroundColor() {
    return UIManager.getColor("TableHeader.foreground"); //$NON-NLS-1$
  }

  public static Color getTableSelectionBackgroundColor() {
    return UIManager.getColor("Table.selectionBackground"); //$NON-NLS-1$
  }

  public static Color getTableSelectionForegroundColor() {
    return UIManager.getColor("Table.selectionForeground"); //$NON-NLS-1$
  }

  public static Color getTreeSelectionBackgroundColor() {
    return UIManager.getColor("Tree.selectionBackground"); //$NON-NLS-1$
  }

  public static Color getTreeSelectionBorderColor() {
    return UIManager.getColor("Tree.selectionBorderColor"); //$NON-NLS-1$
  }

  public static Color getTreeSelectionForegroundColor() {
    return UIManager.getColor("Tree.selectionForeground"); //$NON-NLS-1$
  }

  public static Color getTreeTextBackgroundColor() {
    return UIManager.getColor("Tree.textBackground"); //$NON-NLS-1$
  }

  public static Color getTreeTextForegroundColor() {
    return UIManager.getColor("Tree.textForeground"); //$NON-NLS-1$
  }

  public static Color getTextAreaForegroundColor() {
    return UIManager.getColor("TextArea.foreground"); //$NON-NLS-1$
  }

  public static Color getTextAreaBackgroundColor() {
    return UIManager.getColor("TextArea.background"); //$NON-NLS-1$
  }

  public static Color getTextAreaCaretForegroundColor() {
    return UIManager.getColor("TextArea.caretForeground"); //$NON-NLS-1$
  }

  public static Color getTextAreaSelectionBackgroundColor() {
    return UIManager.getColor("TextArea.selectionBackground"); //$NON-NLS-1$
  }

  public static Color getTextAreaSelectionForegroungColor() {
    return UIManager.getColor("TextArea.selectionForeground"); //$NON-NLS-1$
  }

  public static Color getTextAreaInactiveForegroundColor() {
    return UIManager.getColor("TextArea.inactiveForeground"); //$NON-NLS-1$
  }
}