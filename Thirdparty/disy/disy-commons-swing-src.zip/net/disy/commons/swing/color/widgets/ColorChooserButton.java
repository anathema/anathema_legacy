// Copyright (c) 2001 by disy Informationssysteme GmbH

package net.disy.commons.swing.color.widgets;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class ColorChooserButton extends AbstractColorChoosingComponent {

  public ColorChooserButton() {
    this(new ColorModel());
  }

  public ColorChooserButton(ColorModel model) {
    super(model);
  }

  public ColorChooserButton(ColorModel model, IColorChooserConfiguration configuration) {
    super(model, configuration);
  }

  @Override
  protected final JComponent createContent() {
    JButton button = createButton();
    button.setOpaque(false);
    button.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        performColorChooseDialog();
      }
    });
    button.setToolTipText(getTooltipText());
    return button;
  }

  private String getTooltipText() {
    return DisyCommonsSwingMessages.getString("ColorChooseButton.ToolTip"); //$NON-NLS-1$
  }

  private JButton createButton() {
    JButton button = new JButton();
    /* 02.11.2005 (gebhard): Color rectangle must be painted as Icon: Overriding paint...() will
     * not work, since some look and feels will add decorations. 
     */
    Icon icon = createIcon(button);
    button.setIcon(icon);
    final int twoPixels = LayoutUtilities.getDpiAdjusted(2);
    button.setMargin(new Insets(twoPixels, twoPixels, twoPixels, twoPixels));
    return button;
  }

  private Icon createIcon(final JButton button) {
    return new Icon() {
      public int getIconHeight() {
        return 13;
      }

      public int getIconWidth() {
        return 49;
      }

      public void paintIcon(Component c, Graphics g, int x, int y) {
        paintColorRectangle(g, x, y, new Dimension(getIconWidth(), getIconHeight()), button
            .isEnabled());
      }
    };
  }
}