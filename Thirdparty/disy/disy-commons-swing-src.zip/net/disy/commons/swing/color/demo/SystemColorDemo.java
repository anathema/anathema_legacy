/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.awt.SystemColor;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.junit.runner.RunWith;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class SystemColorDemo extends AbstractColorDemoCase {

  public void demo() throws IllegalArgumentException, IllegalAccessException {
    final Field[] fields = SystemColor.class.getFields();
    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < fields.length; ++i) {
      final Field field = fields[i];
      if (isColorConstant(field)) {
        final Color color = (Color) field.get(null);
        panel.add(createColorLabel(
            getSimpleClassName(SystemColor.class) + '.' + field.getName(),
            color));
      }
    }
    show(new JScrollPane(panel));
  }

  private boolean isColorConstant(final Field field) {
    if (!Modifier.isStatic(field.getModifiers())) {
      return false;
    }
    final String name = field.getName();
    if (isOnlyUpperCaseCharactersOrUnderScore(name)) {
      return false;
    }
    return (Color.class.isAssignableFrom(field.getType()));
  }

  private boolean isOnlyUpperCaseCharactersOrUnderScore(final String name) {
    for (int i = 0; i < name.length(); ++i) {
      final char character = name.charAt(i);
      if (character != '_' && !Character.isUpperCase(character)) {
        return false;
      }
    }
    return true;
  }
}