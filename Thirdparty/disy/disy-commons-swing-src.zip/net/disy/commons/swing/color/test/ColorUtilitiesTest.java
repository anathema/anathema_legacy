/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.test;

import static org.junit.Assert.*;

import java.awt.Color;

import net.disy.commons.swing.color.ColorUtilities;

import org.junit.Test;

public class ColorUtilitiesTest {

  @Test
  public void getTransparentColor() {
    assertEquals(
        new Color(1, 2, 3, 6),
        ColorUtilities.getTransparentColor(new Color(1, 2, 3, 4), 6));
  }

  @Test
  public void convertColorToHex() {
    assertEquals("0000FF", ColorUtilities.convertToRGBHex(Color.blue, false));
    assertEquals("#00FF00", ColorUtilities.convertToRGBHex(Color.green, true));
    assertEquals("FF0000", ColorUtilities.convertToRGBHex(Color.red, false));
  }

  @Test
  public void convertFromRGBHex() {
    assertEquals(new Color(0, 0, 255), ColorUtilities.convertFromRGBHex("0000FF", false));
    assertEquals(new Color(0, 255, 0), ColorUtilities.convertFromRGBHex("#00FF00", true));
    assertEquals(new Color(0, 255, 0), ColorUtilities.convertFromRGBHex("00FF00", false));
    assertEquals(new Color(255, 0, 0), ColorUtilities.convertFromRGBHex("FF0000", false));
  }

}