//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.layout.grid.GridDialogLayout;

// NOT_PUBLISHED
public class SwingColorsDemo extends AbstractColorDemoCase {

  public void demo() throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
    Method[] methods = SwingColors.class.getMethods();
    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < methods.length; ++i) {
      final Method method = methods[i];
      if (isStaticColorGetter(method)) {
        Color color = (Color) method.invoke(null, null);
        panel.add(createColorLabel(getSimpleClassName(SwingColors.class) + '.' + method.getName() + "()", color)); //$NON-NLS-1$
      }
    }
    show(new JScrollPane(panel));
  }

  private boolean isStaticColorGetter(final Method method) {
    if (!Modifier.isStatic(method.getModifiers())) {
      return false;
    }
    return (Color.class.isAssignableFrom(method.getReturnType()));
  }
}