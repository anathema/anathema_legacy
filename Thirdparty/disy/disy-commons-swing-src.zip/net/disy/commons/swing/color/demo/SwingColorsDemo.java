//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.swing.color.SwingColors;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SwingColorsDemo extends SwingDemoCase {

  public void demoControlColor() {
    show(SwingColors.getControlColor());
  }

  public void demoControlDkShadowColo() {
    show(SwingColors.getControlDkShadowColor());
  }

  public void demoControlHighlightColor() {
    show(SwingColors.getControlHighlightColor());
  }

  public void demoControlLtHighlightColor() {
    show(SwingColors.getControlLtHighlightColor());
  }

  public void demoControlShadowColor() {
    show(SwingColors.getControlShadowColor());
  }

  public void demoPanelBackgroundColo() {
    show(SwingColors.getPanelBackgroundColor());
  }

  public void demoPanelForegroundColor() {
    show(SwingColors.getPanelForegroundColor());
  }

  public void demoTabelFocusCellBackgroundColor() {
    show(SwingColors.getTabelFocusCellBackgroundColor());
  }

  public void demoTabelFocusCellForegroundColor() {
    show(SwingColors.getTabelFocusCellForegroundColor());
  }

  public void demoTableHeaderBackgroundColor() {
    show(SwingColors.getTableHeaderBackgroundColor());
  }

  public void demoTableHeaderForegroundColor() {
    show(SwingColors.getTableHeaderForegroundColor());
  }

  public void demoTableSelectionBackgroundColor() {
    show(SwingColors.getTableSelectionBackgroundColor());
  }

  public void demoTableSelectionForegroundColor() {
    show(SwingColors.getTableSelectionForegroundColor());
  }

  public void demoTreeSelectionBackgroundColor() {
    show(SwingColors.getTreeSelectionBackgroundColor());
  }

  public void demoTreeSelectionBorderColor() {
    show(SwingColors.getTreeSelectionBorderColor());
  }

  public void demoTreeSelectionForegroundColor() {
    show(SwingColors.getTreeSelectionForegroundColor());
  }

  public void demoTreeTextBackgroundColor() {
    show(SwingColors.getTreeTextBackgroundColor());
  }

  public void demoTreeTextForegroundColor() {
    show(SwingColors.getTreeTextForegroundColor());
  }

  private void show(final Color color) {
    show(new Icon() {
      public int getIconHeight() {
        return 16;
      }

      public int getIconWidth() {
        return 24;
      }

      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillRect(x, y, getIconWidth(), getIconHeight());
      }
    });
  }
}