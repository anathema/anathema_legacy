/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.color.demo;

import java.awt.Color;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import javax.swing.JPanel;
import javax.swing.JScrollPane;

import org.junit.runner.RunWith;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class SwingColorsDemo extends AbstractColorDemoCase {

  public void demo()
      throws IllegalArgumentException,
      IllegalAccessException,
      InvocationTargetException {
    final Method[] methods = SwingColors.class.getMethods();
    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < methods.length; ++i) {
      final Method method = methods[i];
      if (isStaticColorGetter(method)) {
        final Color color = (Color) method.invoke((Object) null, (Object[]) null);
        panel.add(createColorLabel(getSimpleClassName(SwingColors.class)
            + '.'
            + method.getName()
            + "()", color)); //$NON-NLS-1$
      }
    }
    show(new JScrollPane(panel));
  }

  private boolean isStaticColorGetter(final Method method) {
    if (!Modifier.isStatic(method.getModifiers())) {
      return false;
    }
    return (Color.class.isAssignableFrom(method.getReturnType()));
  }
}