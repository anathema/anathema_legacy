//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.icon.AggregatedIcon;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.layout.util.LayoutUtilities;

// NOT_PUBLISHED
public class IconedColorChooserButton extends AbstractActionComponent {

  private static final Icon TEXT_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/text_color.gif"); //$NON-NLS-1$
  private static final Icon BACKGROUND_ICON = DisyCommonsSwingImageProvider
      .getInstance()
      .getImageIcon("color/background_color.gif"); //$NON-NLS-1$

  public final static IconedColorChooserButton createTextColorChooserButton(ColorModel colorModel) {
    return new IconedColorChooserButton(
        TEXT_ICON,
        colorModel,
        new DefaultColorChooserConfiguration(),
        "Textfarbe...");
  }

  public final static IconedColorChooserButton createBackgroundColorChooserButton(
      ColorModel colorModel) {
    return new IconedColorChooserButton(
        BACKGROUND_ICON,
        colorModel,
        new DefaultColorChooserConfiguration(),
        "Hintergrundfarbe...");
  }

  private final JComponent content;
  private final ColorModel model;
  private final IColorChooserConfiguration configuration;

  public IconedColorChooserButton(
      Icon baseIcon,
      final ColorModel model,
      IColorChooserConfiguration configuration,
      String name) {
    Ensure.ensureArgumentNotNull(baseIcon);
    Ensure.ensureArgumentNotNull(configuration);
    Ensure.ensureArgumentNotNull(model);
    this.configuration = configuration;
    this.model = model;
    SmartAction action = new SmartAction(name, createColorIcon(baseIcon)) {
      protected void execute(Component parentComponent) {
        performColorChooserDialog(parentComponent);
      }
    };
    final JButton button = new JButton(action);
    button.setPreferredSize(LayoutUtilities.TOOLBAR_BUTTON_SIZE);
    button.setFocusPainted(false);
    this.content = button;
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        button.repaint();
      }
    });
  }

  private Icon createColorIcon(Icon baseIcon) {
    AggregatedIcon icon = new AggregatedIcon(new Icon() {
      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(model.getColor());
        g.fillRect(x + 0, y + 16 - 4, 16, 4);
      }

      public int getIconWidth() {
        return 16;
      }

      public int getIconHeight() {
        return 16;
      }
    });
    icon.addDecorationIcon(baseIcon);
    return icon;
  }

  protected void performColorChooserDialog(Component parentComponent) {
    Color newColor = ColorChooserDialog
        .showDialog(parentComponent, configuration, model.getColor());
    if (newColor != null) {
      model.setColor(newColor);
    }
    fireActionEvent();
  }

  public JComponent getContent() {
    return content;
  }

}