//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.button.DropDownButton;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.icon.AggregatedIcon;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.toolbar.ToolBarBuilder;

// NOT_PUBLISHED
public class IconedColorChooserButton extends AbstractActionComponent {

  public static interface IChooseStrategy {
    JComponent[] createContent(JButton button, IconedColorChooserButton chooserButton, ColorModel colorModel);

    ColorModel createColorModel(ColorModel model);

    void execute(Component parentComponent, ColorModel model, IconedColorChooserButton button);

    String amendName(String name);
  }

  public static class DropDownStrategy implements IChooseStrategy {
    private final boolean showTransparent;

    public DropDownStrategy(boolean showTransparent) {
      this.showTransparent = showTransparent;
    }

    public ColorModel createColorModel(ColorModel model) {
      return new ColorModel(model.getColor());
    }

    public JComponent[] createContent(
        JButton button,
        final IconedColorChooserButton chooserButton,
        final ColorModel colorModel) {
      DropDownButton dropDownButton = new DropDownButton(button);
      JPopupMenu popupMenu = new ColorPopupMenu(showTransparent) {
        @Override
        protected void performColorChooserDialog(Component parentComponent) {
          chooserButton.performColorChooserDialog(parentComponent);
          applyColor(chooserButton, colorModel);
        }

        @Override
        protected void setColor(Color color) {
          chooserButton.buttonModel.setColor(color);
          applyColor(chooserButton, colorModel);
        }
      };
      dropDownButton.setMenu(popupMenu);
      return dropDownButton.getSeparateComponents();
    }

    public void execute(Component parentComponent, ColorModel model, IconedColorChooserButton button) {
      applyColor(button, model);
    }

    private void applyColor(IconedColorChooserButton button, ColorModel model) {
      model.setColor(button.buttonModel.getColor());
    }

    public String amendName(String name) {
      return name;
    }
  }

  public static final IChooseStrategy DIRECT = new IChooseStrategy() {
    public ColorModel createColorModel(ColorModel model) {
      return model;
    }

    public JComponent[] createContent(
        JButton button,
        IconedColorChooserButton chooserButton,
        ColorModel colorModel) {
      return new JComponent[]{ button };
    }

    public void execute(Component parentComponent, ColorModel model, IconedColorChooserButton button) {
      button.performColorChooserDialog(parentComponent);
    }

    public String amendName(String name) {
      return name + "..."; //$NON-NLS-1$
    }
  };

  private static final Icon TEXT_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/text_color.gif"); //$NON-NLS-1$
  private static final Icon MARKER_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/marked_background_color.gif"); //$NON-NLS-1$
  private static final Icon BACKGROUND_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/background_color.gif"); //$NON-NLS-1$

  public final static IconedColorChooserButton createTextColorChooserButton(
      ColorModel colorModel,
      IChooseStrategy strategy) {
    return new IconedColorChooserButton(TEXT_ICON, colorModel, "Schriftfarbe", strategy);
  }

  public final static IconedColorChooserButton createMarkerColorChooserButton(
      ColorModel colorModel,
      IChooseStrategy strategy) {
    return new IconedColorChooserButton(MARKER_ICON, colorModel, "Hervorhebungsfarbe", strategy);
  }

  public final static IconedColorChooserButton createBackgroundColorChooserButton(
      ColorModel colorModel,
      IChooseStrategy strategy) {
    return new IconedColorChooserButton(BACKGROUND_ICON, colorModel, "Hintergrundfarbe", strategy);
  }

  private final JComponent content;
  private final JComponent[] components;
  private final ColorModel buttonModel;

  private final DefaultColorChooserConfiguration colorChooserConfiguration;

  public IconedColorChooserButton(
      Icon baseIcon,
      final ColorModel model,
      String name,
      final IChooseStrategy strategy) {
    Ensure.ensureArgumentNotNull(baseIcon);
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(strategy);
    this.buttonModel = strategy.createColorModel(model);
    SmartAction action = new SmartAction(strategy.amendName(name), createColorIcon(baseIcon)) {
      @Override
      protected void execute(Component parentComponent) {
        strategy.execute(parentComponent, model, IconedColorChooserButton.this);
      }
    };
    final JButton button = new JButton(action);
    button.setPreferredSize(LayoutUtilities.TOOLBAR_BUTTON_SIZE);
    button.setFocusPainted(false);
    this.components = strategy.createContent(button, this, model);
    ToolBarBuilder builder = new ToolBarBuilder();
    builder.add(components);
    this.content = builder.getToolBar();
    this.buttonModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        button.repaint();
      }
    });
    colorChooserConfiguration = new DefaultColorChooserConfiguration(name + " ausw�hlen", false);
  }

  private Icon createColorIcon(Icon baseIcon) {
    AggregatedIcon icon = new AggregatedIcon(new Icon() {
      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(buttonModel.getColor());
        g.fillRect(x + 0, y + 16 - 4, 16, 4);
      }

      public int getIconWidth() {
        return 16;
      }

      public int getIconHeight() {
        return 16;
      }
    });
    icon.addDecorationIcon(baseIcon);
    return icon;
  }

  private void performColorChooserDialog(Component parentComponent) {
    Color color = buttonModel.getColor();
    if (color.getAlpha() == 0) {
      color = Color.WHITE;
    }
    Color newColor = ColorChooserDialog.showDialog(parentComponent, colorChooserConfiguration, color);
    if (newColor != null) {
      buttonModel.setColor(newColor);
    }
    fireActionEvent();
  }

  public JComponent getContent() {
    return content;
  }

}