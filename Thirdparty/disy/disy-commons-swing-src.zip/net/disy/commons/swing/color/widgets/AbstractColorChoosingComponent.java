//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.SystemColor;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

// NOT_PUBLISHED
public abstract class AbstractColorChoosingComponent extends AbstractActionComponent {

  private final static Font FONT = new Font("Dialog", Font.PLAIN, 10); //$NON-NLS-1$
  private boolean isTransparencyEnabled = false;
  private final String title;
  private final ColorModel model;
  private JComponent content;
  private boolean editable = true;

  public AbstractColorChoosingComponent(ColorModel model, String title) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(title);
    this.title = title;
    this.model = model;

    //TODO 01.10.2004 (gebhard): Listener wird nie mehr entfernt. An setVisible() koppeln?
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateView();
      }
    });

    content = createContent();
    updateView();
  }

  protected abstract JComponent createContent();

  public AbstractColorChoosingComponent(ColorModel model) {
    this(model, DisyCommonsSwingMessages.getString("ColorChooserButton.DefaultTitle")); //$NON-NLS-1$
  }

  public void setEditable(boolean editable) {
    this.editable = editable;
  }

  protected final void performColorChooseDialog() {
    if (!editable) {
      return;
    }
    Color newColor = ColorChooserDialog.showDialog(
        getContent(),
        title,
        model.getColor(),
        isTransparencyEnabled);
    if (newColor != null) {
      model.setColor(newColor);
    }
    fireActionEvent();
  }

  public void setTransparencyEnabled(boolean isTransparencyEnabled) {
    this.isTransparencyEnabled = isTransparencyEnabled;
  }

  public ColorModel getModel() {
    return model;
  }

  protected final void paintColorRectangle(Graphics g, Dimension size, boolean enabled) {
    paintColorRectangle(model.getColor(), g, size, enabled);
  }

  protected final void paintColorRectangle(
      Color rectColor,
      Graphics g,
      Dimension size,
      boolean enabled) {
    Insets insets = getColorRectangleInsets();
    int h = size.height;
    int w = size.width;
    Color oldColor = g.getColor();
    g.setFont(FONT);
    g.setColor(Color.white);
    g.fillRect(insets.left + 1, insets.top + 1, w - insets.left - insets.right - 2, h
        - insets.top
        - insets.bottom
        - 2);
    if (isTransparencyEnabled) {
      g.setColor(SystemColor.textText);
      int alphaPercentage = (100 - (int) Math.round(getModel().getColor().getAlpha() / 2.55));
      g.drawString(alphaPercentage + " %", w / 2 - 10, h / 2 + 4); //$NON-NLS-1$
    }
    if (enabled) {
      g.setColor(rectColor);
    }
    else {
      g.setColor(SystemColor.control);
    }
    g.fillRect(insets.left + 1, insets.top + 1, w - insets.left - insets.right - 2, h
        - insets.top
        - insets.bottom
        - 2);
    if (enabled) {
      g.setColor(Color.black);
    }
    else {
      g.setColor(SystemColor.controlShadow);
    }
    g.drawRect(insets.left, insets.top, w - insets.left - insets.right - 1, h
        - insets.top
        - insets.bottom
        - 1);
    g.setColor(oldColor);
  }

  protected abstract Insets getColorRectangleInsets();

  protected void updateView() {
    content.repaint();
  }

  public JComponent getContent() {
    return content;
  }

  public final void setEnabled(boolean enabled) {
    content.setEnabled(enabled);
  }
}