//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.color.widgets;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.component.AbstractActionComponent;

// NOT_PUBLISHED
public abstract class AbstractColorChoosingComponent extends AbstractActionComponent {

  private final static Font FONT = new Font("Dialog", Font.PLAIN, 10); //$NON-NLS-1$

  private final ColorModel model;
  private final IColorChooserConfiguration configuration;
  private JComponent content;
  private boolean editable = true;

  public AbstractColorChoosingComponent(ColorModel model, IColorChooserConfiguration configuration) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(configuration);
    this.model = model;
    this.configuration = configuration;

    //TODO 01.10.2004 (gebhard): Listener wird nie mehr entfernt. An setVisible() koppeln?
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateView();
      }
    });

    content = createContent();
    updateView();
  }

  protected abstract JComponent createContent();

  public AbstractColorChoosingComponent(ColorModel model) {
    this(model, new DefaultColorChooserConfiguration());
  }

  public void setEditable(boolean editable) {
    this.editable = editable;
  }

  protected final void performColorChooseDialog() {
    if (!editable) {
      return;
    }
    Color newColor = ColorChooserDialog.showDialog(getContent(), configuration, model.getColor());
    if (newColor != null) {
      model.setColor(newColor);
    }
    fireActionEvent();
  }

  public ColorModel getModel() {
    return model;
  }

  protected final void paintColorRectangle(Graphics g, int x, int y, Dimension size, boolean enabled) {
    paintColorRectangle(model.getColor(), g, x, y, size, enabled);
  }

  private final void paintColorRectangle(
      Color rectColor,
      Graphics g,
      int x,
      int y,
      Dimension size,
      boolean enabled) {
    int h = size.height;
    int w = size.width;
    Color oldColor = g.getColor();
    g.setFont(FONT);
    g.setColor(Color.white);
    g.fillRect(x + 1, y + 1, w - 2, h - 2);
    if (configuration.isTransparencyEnabled()) {
      g.setColor(SwingColors.getTextAreaForegroundColor());      
      int alphaPercentage = (100 - (int) Math.round(getModel().getColor().getAlpha() / 2.55));
      g.drawString(alphaPercentage + " %", x + w / 2 - 10, y + h / 2 + 4); //$NON-NLS-1$
    }
    if (enabled) {
      g.setColor(rectColor);
    }
    else {
      g.setColor(SwingColors.getControlColor());      
    }
    g.fillRect(x + 1, y + 1, w - 2, h - 2);
    if (enabled) {
      g.setColor(Color.black);
    }
    else {
      g.setColor(SwingColors.getControlShadowColor());      
    }
    g.drawRect(x, y, w - 1, h - 1);
    g.setColor(oldColor);
  }

  protected void updateView() {
    content.repaint();
  }

  public JComponent getContent() {
    return content;
  }

  public final void setEnabled(boolean enabled) {
    content.setEnabled(enabled);
  }
}