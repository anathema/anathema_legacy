/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.resources;

import javax.swing.Icon;

import net.disy.commons.swing.image.ImageProvider;

public class DisyCommonsSwingIconResources implements IIconResources {
  public static final Icon UNDO = getImageIcon("undo.gif"); //$NON-NLS-1$
  public static final Icon REDO = getImageIcon("redo.gif"); //$NON-NLS-1$
  public static final Icon UNDO_MODERN = getImageIcon("undo_modern.gif"); //$NON-NLS-1$
  public static final Icon REDO_MODERN = getImageIcon("redo_modern.gif"); //$NON-NLS-1$

  public static final Icon COPY = getImageIcon("copy.gif"); //$NON-NLS-1$
  public static final Icon CUT = getImageIcon("cut.gif"); //$NON-NLS-1$
  public static final Icon PASTE = getImageIcon("paste.gif"); //$NON-NLS-1$

  public static final Icon ELLIPSIS = getImageIcon("ellipsis.gif"); //$NON-NLS-1$

  private static Icon getImageIcon(final String relativePath) {
    return new ImageProvider("net/disy/commons/swing/icons").getImageIcon(relativePath); //$NON-NLS-1$
  }
}