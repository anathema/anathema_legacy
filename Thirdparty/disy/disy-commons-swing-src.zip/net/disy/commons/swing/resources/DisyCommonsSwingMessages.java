//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.resources;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

// NOT_PUBLISHED
public class DisyCommonsSwingMessages {
  private static final String BUNDLE_NAME = "net.disy.commons.swing.resources.messages";//$NON-NLS-1$

  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(BUNDLE_NAME);

  private DisyCommonsSwingMessages() {
    //no instance available
  }

  public static String getString(String key) {
    try {
      return RESOURCE_BUNDLE.getString(key);
    }
    catch (MissingResourceException e) {
      return '!' + key + '!';
    }
  }
}