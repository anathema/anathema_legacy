/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events;

import java.awt.datatransfer.FlavorEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.beans.PropertyChangeEvent;

import javax.swing.event.ChangeEvent;
import javax.swing.event.DocumentEvent;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TreeSelectionEvent;

public class NullCheckInputValidListener implements ICheckInputValidListener {

  @Override
  public void actionPerformed(ActionEvent e) {
    //nothing to do

  }

  @Override
  public void itemStateChanged(ItemEvent e) {
    //nothing to do

  }

  @Override
  public void valueChanged(ListSelectionEvent e) {
    //nothing to do

  }

  @Override
  public void insertUpdate(DocumentEvent e) {
    //nothing to do

  }

  @Override
  public void removeUpdate(DocumentEvent e) {
    //nothing to do

  }

  @Override
  public void changedUpdate(DocumentEvent e) {
    //nothing to do

  }

  @Override
  public void stateChanged() {
    //nothing to do

  }

  @Override
  public void stateChanged(ChangeEvent e) {
    //nothing to do

  }

  @Override
  public void tableChanged(TableModelEvent e) {
    //nothing to do

  }

  @Override
  public void valueChanged(TreeSelectionEvent e) {
    //nothing to do

  }

  @Override
  public void propertyChange(PropertyChangeEvent evt) {
    //nothing to do

  }

  @Override
  public void flavorsChanged(FlavorEvent e) {
    //nothing to do

  }

  @Override
  public void intervalAdded(ListDataEvent e) {
    //nothing to do

  }

  @Override
  public void intervalRemoved(ListDataEvent e) {
    //nothing to do

  }

  @Override
  public void contentsChanged(ListDataEvent e) {
    //nothing to do

  }

  @Override
  public void checkInputValid() {
    //nothing to do

  }

}
