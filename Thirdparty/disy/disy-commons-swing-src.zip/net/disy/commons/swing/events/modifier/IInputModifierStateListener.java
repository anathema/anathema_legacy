//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.modifier;

// NOT_PUBLISHED
public interface IInputModifierStateListener {

  public void inputModifierStateChanged(InputModifierStateChangeEvent event);

}
