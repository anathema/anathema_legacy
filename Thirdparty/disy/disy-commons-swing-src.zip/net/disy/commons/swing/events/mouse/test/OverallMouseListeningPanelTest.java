//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.mouse.test;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;

// NOT_PUBLISHED
public class OverallMouseListeningPanelTest extends TestCase {

  private JFrame frame;

  protected void setUp() throws Exception {
    super.setUp();
    frame = new JFrame();
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    frame.dispose();
    frame = null;
  }

  public void testAddingComponentsThrowsException() {
    try {
      OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel());
      fail();
    }
    catch (UnsupportedOperationException expected) {
      //expected
    }
    try {
      OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), 0);
      fail();
    }
    catch (UnsupportedOperationException expected) {
      //expected
    }
    try {
      OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), new Object());
      fail();
    }
    catch (UnsupportedOperationException expected) {
      //expected
    }
    try {
      OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), new Object(), 0);
      fail();
    }
    catch (UnsupportedOperationException expected) {
      //expected
    }
  }

  public void testReceivesMouseEventsFromWrappedComponent() {
    MouseClickComponent component = new MouseClickComponent();
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(component);
    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromWrappedComponent() {
    MouseMoveComponent component = new MouseMoveComponent();
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(component);
    MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  private OverallMouseListeningPanel createManagedOverallMouseListenerPanel(JComponent component) {
    OverallMouseListeningPanel panel = new OverallMouseListeningPanel(component);
    frame.getContentPane().add(panel);
    frame.pack();
    frame.show();
    return panel;
  }

  public void testReceivesMouseEventsFromSubcomponent() {
    MouseClickComponent component = new MouseClickComponent();
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromSubcomponent() {
    MouseMoveComponent component = new MouseMoveComponent();
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testReceivesMouseClickEventsFromSubcomponentHavingOwnListener() {
    MouseClickComponent component = new MouseClickComponent();
    component.addMouseListener(new MouseAdapter() {
      //nothing to do
      });
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromSubcomponentHavingOwnListener() {
    MouseMoveComponent component = new MouseMoveComponent();
    component.addMouseMotionListener(new MouseMotionAdapter() {
      //nothing to do
      });
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testNotReceivesMouseEventsFromRemovedSubcomponent() {
    MouseClickComponent component = new MouseClickComponent();
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    p.remove(component);
    MockMouseClickedListener listener = new MockMouseClickedListener(0);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testNotReceivesMouseMotionEventsFromRemovedSubcomponent() {
    MouseMoveComponent component = new MouseMoveComponent();
    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    p.remove(component);
    MockMouseMovedListener listener = new MockMouseMovedListener(0);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testReceivesMouseEventsFromSubcomponentAddedLater() {
    MouseClickComponent component = new MouseClickComponent();
    JPanel p = new JPanel();
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    p.add(component);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseEventsFromMultipleSubcomponentsAddedLater() {
    MouseClickComponent component = new MouseClickComponent();
    JPanel p = new JPanel();
    frame.getContentPane().add(p);
    frame.pack();
    frame.show();
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    p.add(new JLabel());
    p.add(component);
    p.revalidate();
    waitUntilValid(p);
    component.performMouseClicked();
    listener.verify();
    frame.dispose();
  }

  private void waitUntilValid(Component component) {
    long time0 = System.currentTimeMillis();
    while (!component.isValid() && System.currentTimeMillis() - time0 < 30000) {
      Thread.yield();
    }
    if (!component.isValid()) {
      throw new RuntimeException("Timeout"); //$NON-NLS-1$
    }
  }

  public void testReceivesMouseMotionEventsFromSubcomponentAddedLater() {
    MouseMoveComponent component = new MouseMoveComponent();
    JPanel p = new JPanel();
    OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    p.add(component);
    component.performMouseMoved();
    listener.verify();
  }

  private final static class MockMouseClickedListener extends MouseAdapter {
    private final int expectedClickCount;
    private int actualClickCount = 0;

    public MockMouseClickedListener(int expectedClickCount) {
      this.expectedClickCount = expectedClickCount;
    }

    public void mouseClicked(MouseEvent e) {
      ++actualClickCount;
    }

    public void verify() {
      if (expectedClickCount != actualClickCount) {
        throw new AssertionFailedError("Expected " //$NON-NLS-1$
            + expectedClickCount + " clicks, but was " //$NON-NLS-1$
            + actualClickCount);
      }
    }
  }

  private final static class MockMouseMovedListener extends MouseMotionAdapter {
    private final int expectedMoveCount;
    private int actualMoveCount = 0;

    public MockMouseMovedListener(int expectedMoveCount) {
      this.expectedMoveCount = expectedMoveCount;
    }

    public void mouseMoved(MouseEvent e) {
      ++actualMoveCount;
    }

    public void verify() {
      if (expectedMoveCount != actualMoveCount) {
        throw new AssertionFailedError("Expected " //$NON-NLS-1$
            + expectedMoveCount + " moves, but was " //$NON-NLS-1$
            + actualMoveCount);
      }
    }
  }

  public void testReceivesOnlyOneMouseEventFromOverallListeningPanelInsideOverallListeningPanel() {
    MouseClickComponent component = new MouseClickComponent();

    JPanel p = new JPanel();
    p.add(component);
    OverallMouseListeningPanel innerPanel = createManagedOverallMouseListenerPanel(p);
    OverallMouseListeningPanel outerPanel = createManagedOverallMouseListenerPanel(innerPanel);

    MockMouseClickedListener listener = new MockMouseClickedListener(1);
    outerPanel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }
}