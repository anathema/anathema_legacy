/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.mouse.test;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import junit.framework.AssertionFailedError;
import junit.framework.TestCase;

import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;

public class OverallMouseListeningPanelTest extends TestCase {

  private JFrame frame;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    frame = new JFrame();
  }

  @Override
  protected void tearDown() throws Exception {
    super.tearDown();
    frame.dispose();
    frame = null;
  }

  public void testAddingComponentsThrowsException() {
    try {
      final OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel());
      fail();
    }
    catch (final UnsupportedOperationException expected) {
      //expected
    }
    try {
      final OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), 0);
      fail();
    }
    catch (final UnsupportedOperationException expected) {
      //expected
    }
    try {
      final OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), new Object());
      fail();
    }
    catch (final UnsupportedOperationException expected) {
      //expected
    }
    try {
      final OverallMouseListeningPanel panel = new OverallMouseListeningPanel(new JLabel());
      panel.add(new JLabel(), new Object(), 0);
      fail();
    }
    catch (final UnsupportedOperationException expected) {
      //expected
    }
  }

  public void testReceivesMouseEventsFromWrappedComponent() {
    final MouseClickComponent component = new MouseClickComponent();
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(component);
    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromWrappedComponent() {
    final MouseMoveComponent component = new MouseMoveComponent();
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(component);
    final MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  private OverallMouseListeningPanel createManagedOverallMouseListenerPanel(
      final JComponent component) {
    final OverallMouseListeningPanel panel = new OverallMouseListeningPanel(component);
    frame.getContentPane().add(panel);
    frame.pack();
    frame.setVisible(true);
    return panel;
  }

  public void testReceivesMouseEventsFromSubcomponent() {
    final MouseClickComponent component = new MouseClickComponent();
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromSubcomponent() {
    final MouseMoveComponent component = new MouseMoveComponent();
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testReceivesMouseClickEventsFromSubcomponentHavingOwnListener() {
    final MouseClickComponent component = new MouseClickComponent();
    component.addMouseListener(new MouseAdapter() {
      //nothing to do
    });
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseMotionEventsFromSubcomponentHavingOwnListener() {
    final MouseMoveComponent component = new MouseMoveComponent();
    component.addMouseMotionListener(new MouseMotionAdapter() {
      //nothing to do
    });
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testNotReceivesMouseEventsFromRemovedSubcomponent() {
    final MouseClickComponent component = new MouseClickComponent();
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    p.remove(component);
    final MockMouseClickedListener listener = new MockMouseClickedListener(0);
    panel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }

  public void testNotReceivesMouseMotionEventsFromRemovedSubcomponent() {
    final MouseMoveComponent component = new MouseMoveComponent();
    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    p.remove(component);
    final MockMouseMovedListener listener = new MockMouseMovedListener(0);
    panel.addMouseMotionListener(listener);
    component.performMouseMoved();
    listener.verify();
  }

  public void testReceivesMouseEventsFromSubcomponentAddedLater() {
    final MouseClickComponent component = new MouseClickComponent();
    final JPanel p = new JPanel();
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    p.add(component);
    component.performMouseClicked();
    listener.verify();
  }

  public void testReceivesMouseEventsFromMultipleSubcomponentsAddedLater() {
    final MouseClickComponent component = new MouseClickComponent();
    final JPanel p = new JPanel();
    frame.getContentPane().add(p);
    frame.pack();
    frame.setVisible(true);
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    panel.addMouseListener(listener);
    p.add(new JLabel());
    p.add(component);
    p.revalidate();
    waitUntilValid(p);
    component.performMouseClicked();
    listener.verify();
    frame.dispose();
  }

  private void waitUntilValid(final Component component) {
    final long time0 = System.currentTimeMillis();
    while (!component.isValid() && System.currentTimeMillis() - time0 < 30000) {
      Thread.yield();
    }
    if (!component.isValid()) {
      throw new RuntimeException("Timeout"); //$NON-NLS-1$
    }
  }

  public void testReceivesMouseMotionEventsFromSubcomponentAddedLater() {
    final MouseMoveComponent component = new MouseMoveComponent();
    final JPanel p = new JPanel();
    final OverallMouseListeningPanel panel = createManagedOverallMouseListenerPanel(p);
    final MockMouseMovedListener listener = new MockMouseMovedListener(1);
    panel.addMouseMotionListener(listener);
    p.add(component);
    component.performMouseMoved();
    listener.verify();
  }

  private final static class MockMouseClickedListener extends MouseAdapter {
    private final int expectedClickCount;
    private int actualClickCount = 0;

    public MockMouseClickedListener(final int expectedClickCount) {
      this.expectedClickCount = expectedClickCount;
    }

    @Override
    public void mouseClicked(final MouseEvent e) {
      ++actualClickCount;
    }

    public void verify() {
      if (expectedClickCount != actualClickCount) {
        throw new AssertionFailedError("Expected " //$NON-NLS-1$
            + expectedClickCount
            + " clicks, but was " //$NON-NLS-1$
            + actualClickCount);
      }
    }
  }

  private final static class MockMouseMovedListener extends MouseMotionAdapter {
    private final int expectedMoveCount;
    private int actualMoveCount = 0;

    public MockMouseMovedListener(final int expectedMoveCount) {
      this.expectedMoveCount = expectedMoveCount;
    }

    @Override
    public void mouseMoved(final MouseEvent e) {
      ++actualMoveCount;
    }

    public void verify() {
      if (expectedMoveCount != actualMoveCount) {
        throw new AssertionFailedError("Expected " //$NON-NLS-1$
            + expectedMoveCount
            + " moves, but was " //$NON-NLS-1$
            + actualMoveCount);
      }
    }
  }

  public void testReceivesOnlyOneMouseEventFromOverallListeningPanelInsideOverallListeningPanel() {
    final MouseClickComponent component = new MouseClickComponent();

    final JPanel p = new JPanel();
    p.add(component);
    final OverallMouseListeningPanel innerPanel = createManagedOverallMouseListenerPanel(p);
    final OverallMouseListeningPanel outerPanel = createManagedOverallMouseListenerPanel(innerPanel);

    final MockMouseClickedListener listener = new MockMouseClickedListener(1);
    outerPanel.addMouseListener(listener);
    component.performMouseClicked();
    listener.verify();
  }
}