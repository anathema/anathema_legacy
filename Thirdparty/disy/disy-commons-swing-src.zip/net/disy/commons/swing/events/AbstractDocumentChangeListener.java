package net.disy.commons.swing.events;

import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public abstract class AbstractDocumentChangeListener implements DocumentListener {

  public void insertUpdate(DocumentEvent e) {
    documentChanged();
  }

  public void removeUpdate(DocumentEvent e) {
    documentChanged();
  }

  public void changedUpdate(DocumentEvent e) {
    documentChanged();
  }

  protected abstract void documentChanged();
}