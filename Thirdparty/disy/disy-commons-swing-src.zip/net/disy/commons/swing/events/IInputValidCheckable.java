package net.disy.commons.swing.events;

/**
 * @author gebhard
 */
public interface IInputValidCheckable {
  public void checkInputValid();
}
