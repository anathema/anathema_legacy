/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.mouse.demo;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import org.junit.runner.RunWith;

import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class OverallMouseListeningPanelDemo extends SwingDemoCase {
  public void demo() {
    final JLabel label1 = new JLabel("Label with a MouseListener of its own"); //$NON-NLS-1$
    label1.setBorder(new EtchedBorder());
    label1.addMouseListener(new MouseAdapter() {
      //nothing to do
    });
    final JLabel label2 = new JLabel("Label without a MouseListener"); //$NON-NLS-1$
    label2.setBorder(new EtchedBorder());

    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(label1, BorderLayout.NORTH);
    panel.add(label2, BorderLayout.SOUTH);

    final OverallMouseListeningPanel listeningPanel = new OverallMouseListeningPanel(panel);
    listeningPanel.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseReleased(final MouseEvent e) {
        System.err.println(e);
      }
    });

    show(listeningPanel);
  }
}