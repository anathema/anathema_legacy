//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.mouse.demo;

import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EtchedBorder;

import net.disy.commons.swing.events.mouse.OverallMouseListeningPanel;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class OverallMouseListeningPanelDemo extends SwingDemoCase {
  public void demo() {
    JLabel label1 = new JLabel("Label with a MouseListener of its own"); //$NON-NLS-1$
    label1.setBorder(new EtchedBorder());
    label1.addMouseListener(new MouseAdapter() {
      //nothing to do
      });
    JLabel label2 = new JLabel("Label without a MouseListener"); //$NON-NLS-1$
    label2.setBorder(new EtchedBorder());
    
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(label1, BorderLayout.NORTH);
    panel.add(label2, BorderLayout.SOUTH);

    OverallMouseListeningPanel listeningPanel = new OverallMouseListeningPanel(panel);
    listeningPanel.addMouseListener(new MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        System.err.println(e);
      }
    });
    
    show(listeningPanel);
  }
}