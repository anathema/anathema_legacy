/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.modifier;

import java.awt.event.InputEvent;

import net.disy.commons.core.util.Ensure;

public class InputModifierState {
  private static final String EMPTY = ""; //$NON-NLS-1$

  private final int modifiers;

  public InputModifierState() {
    this.modifiers = 0;
  }

  public InputModifierState(final InputEvent event) {
    Ensure.ensureArgumentNotNull(event);
    this.modifiers = event.getModifiers();
  }

  public boolean isShiftDown() {
    return (modifiers & InputEvent.SHIFT_MASK) != 0;
  }

  public boolean isControlDown() {
    return (modifiers & InputEvent.CTRL_MASK) != 0;
  }

  public boolean isMetaDown() {
    return (modifiers & InputEvent.META_MASK) != 0;
  }

  public boolean isAltDown() {
    return (modifiers & InputEvent.ALT_MASK) != 0;
  }

  @Override
  public String toString() {
    return "InputModifierState{" //$NON-NLS-1$
        + (isShiftDown() ? "S" : EMPTY) //$NON-NLS-1$
        + (isAltDown() ? "A" : EMPTY) //$NON-NLS-1$
        + (isControlDown() ? "C" : EMPTY) //$NON-NLS-1$
        + (isMetaDown() ? "M" : EMPTY) //$NON-NLS-1$
        + "}"; //$NON-NLS-1$
  }

  public boolean isEqualState(final InputEvent e) {
    return e.getModifiers() == modifiers;
  }
}