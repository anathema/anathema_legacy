// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.modifier;

import java.awt.event.InputEvent;

import net.disy.commons.core.util.Ensure;

public class InputModifierState {
  private static final String EMPTY = ""; //$NON-NLS-1$

  private final int modifiers;

  public InputModifierState() {
    this.modifiers = 0;
  }

  public InputModifierState(InputEvent event) {
    Ensure.ensureArgumentNotNull(event);
    this.modifiers = event.getModifiers();
  }

  public boolean isShiftDown() {
    return (modifiers & InputEvent.SHIFT_MASK) != 0;
  }

  public boolean isControlDown() {
    return (modifiers & InputEvent.CTRL_MASK) != 0;
  }

  public boolean isMetaDown() {
    return (modifiers & InputEvent.META_MASK) != 0;
  }

  public boolean isAltDown() {
    return (modifiers & InputEvent.ALT_MASK) != 0;
  }

  @Override
  public String toString() {
    return "InputModifierState{" //$NON-NLS-1$
        + (isShiftDown() ? "S" : EMPTY) //$NON-NLS-1$
        + (isAltDown() ? "A" : EMPTY) //$NON-NLS-1$
        + (isControlDown() ? "C" : EMPTY) //$NON-NLS-1$
        + (isMetaDown() ? "M" : EMPTY) //$NON-NLS-1$
        + "}"; //$NON-NLS-1$
  }

  public boolean isEqualState(InputEvent e) {
    return e.getModifiers() == modifiers;
  }
}