//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.mouse;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;

/** A panels that can be used to receive mouse events from all contained components.
 * With Swing/AWT you cannot add a MouseListener to a Container and guarantee that it 
 * receives all the events even from the subcomponents. This class tries to keep all
 * registered MouseListeners attached to all the subcomponents - even if the component
 * hierarchy changes. 
 * It does this by using the assumtion that adding/removing subcomponents will cause
 * the topmost panel (when visible on screen) to be invalidated.
 */
public class OverallMouseListeningPanel extends JPanel {

  private final List/*<Component>*/managedComponents = new ArrayList();
  private final List/*<MouseListener>*/mouseListeners = new ArrayList();
  private final List/*<MouseListener>*/mouseMotionListeners = new ArrayList();

  public OverallMouseListeningPanel(JComponent content) {
    super(new GridLayout(1, 0));
    super.add(content);
    updateManagedComponentsList();
  }

  //@Overrides
  public synchronized void invalidate() {
    updateManagedComponentsAndListeners();
    super.invalidate();
  }

  private void updateManagedComponentsAndListeners() {
    removeMouseListenersFromManagedComponents();
    removeMouseMotionListenersFromManagedComponents();
    updateManagedComponentsList();
    addMouseListenersToManagedComponents();
    addMouseMotionListenersToManagedComponents();
  }

  public void validate() {
    updateManagedComponentsAndListeners();
    super.validate();
  }

  protected void validateTree() {
    updateManagedComponentsAndListeners();
    super.validateTree();
  }

  //@Overrides
  public synchronized void addMouseListener(MouseListener listener) {
    mouseListeners.add(listener);
    addMouseListenerToManagedComponents(listener);
  }

  //@Overrides
  public synchronized void removeMouseListener(MouseListener listener) {
    mouseListeners.remove(listener);
    removeMouseListenerFromManagedComponents(listener);
  }

  //@Overrides
  public synchronized void addMouseMotionListener(MouseMotionListener listener) {
    mouseMotionListeners.add(listener);
    addMouseMotionListenerToManagedComponents(listener);
  }

  //@Overrides
  public synchronized void removeMouseMotionListener(MouseMotionListener listener) {
    mouseMotionListeners.remove(listener);
    removeMouseMotionListenerFromManagedComponents(listener);
  }

  private void addMouseListenerToManagedComponents(MouseListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      Component component = (Component) managedComponents.get(i);
      component.addMouseListener(listener);
    }
  }

  private void removeMouseListenerFromManagedComponents(MouseListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      Component component = (Component) managedComponents.get(i);
      component.removeMouseListener(listener);
    }
  }

  private void addMouseMotionListenerToManagedComponents(MouseMotionListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      Component component = (Component) managedComponents.get(i);
      component.addMouseMotionListener(listener);
    }
  }

  private void removeMouseMotionListenerFromManagedComponents(MouseMotionListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      Component component = (Component) managedComponents.get(i);
      component.removeMouseMotionListener(listener);
    }
  }

  private void addMouseListenersToManagedComponents() {
    for (int i = 0; i < mouseListeners.size(); i++) {
      MouseListener listener = (MouseListener) mouseListeners.get(i);
      addMouseListenerToManagedComponents(listener);
    }
  }

  private void removeMouseListenersFromManagedComponents() {
    for (int i = 0; i < mouseListeners.size(); i++) {
      MouseListener listener = (MouseListener) mouseListeners.get(i);
      removeMouseListenerFromManagedComponents(listener);
    }
  }

  private void addMouseMotionListenersToManagedComponents() {
    for (int i = 0; i < mouseMotionListeners.size(); i++) {
      MouseMotionListener listener = (MouseMotionListener) mouseMotionListeners.get(i);
      addMouseMotionListenerToManagedComponents(listener);
    }
  }

  private void removeMouseMotionListenersFromManagedComponents() {
    for (int i = 0; i < mouseMotionListeners.size(); i++) {
      MouseMotionListener listener = (MouseMotionListener) mouseMotionListeners.get(i);
      removeMouseMotionListenerFromManagedComponents(listener);
    }
  }

  private void updateManagedComponentsList() {
    managedComponents.clear();
    collectComponents(getComponent(0));
  }

  private void collectComponents(Component component) {
    managedComponents.add(component);
    if (component instanceof Container && !(component instanceof OverallMouseListeningPanel)) {
      Container container = (Container) component;
      Component[] components = container.getComponents();
      for (int i = 0; i < components.length; i++) {
        collectComponents(components[i]);
      }
    }
  }

  //@Overrides  
  public final Component add(Component comp) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  //@Overrides  
  public final void add(Component comp, Object constraints) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  //  @Overrides  
  public Component add(Component comp, int index) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  //@Overrides  
  public void add(Component comp, Object constraints, int index) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }
}