/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.mouse;

import java.awt.Component;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;

/**
 * A panels that can be used to receive mouse events from all contained components. With Swing/AWT
 * you cannot add a MouseListener to a Container and guarantee that it receives all the events even
 * from the subcomponents. This class tries to keep all registered MouseListeners attached to all
 * the subcomponents - even if the component hierarchy changes. It does this by using the assumtion
 * that adding/removing subcomponents will cause the topmost panel (when visible on screen) to be
 * invalidated.
 */
public class OverallMouseListeningPanel extends JPanel {

  private final List<Component> managedComponents = new ArrayList<Component>();
  private final List<MouseListener> mouseListeners = new ArrayList<MouseListener>();
  private final List<MouseMotionListener> mouseMotionListeners = new ArrayList<MouseMotionListener>();

  public OverallMouseListeningPanel(final JComponent content) {
    super(new GridLayout(1, 0));
    super.add(content);
    updateManagedComponentsList();
  }

  @Override
  public synchronized void invalidate() {
    updateManagedComponentsAndListeners();
    super.invalidate();
  }

  private void updateManagedComponentsAndListeners() {
    removeMouseListenersFromManagedComponents();
    removeMouseMotionListenersFromManagedComponents();
    updateManagedComponentsList();
    addMouseListenersToManagedComponents();
    addMouseMotionListenersToManagedComponents();
  }

  @Override
  public void validate() {
    updateManagedComponentsAndListeners();
    super.validate();
  }

  @Override
  protected void validateTree() {
    updateManagedComponentsAndListeners();
    super.validateTree();
  }

  @Override
  public synchronized void addMouseListener(final MouseListener listener) {
    mouseListeners.add(listener);
    addMouseListenerToManagedComponents(listener);
  }

  @Override
  public synchronized void removeMouseListener(final MouseListener listener) {
    mouseListeners.remove(listener);
    removeMouseListenerFromManagedComponents(listener);
  }

  @Override
  public synchronized void addMouseMotionListener(final MouseMotionListener listener) {
    mouseMotionListeners.add(listener);
    addMouseMotionListenerToManagedComponents(listener);
  }

  @Override
  public synchronized void removeMouseMotionListener(final MouseMotionListener listener) {
    mouseMotionListeners.remove(listener);
    removeMouseMotionListenerFromManagedComponents(listener);
  }

  private void addMouseListenerToManagedComponents(final MouseListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      final Component component = managedComponents.get(i);
      component.addMouseListener(listener);
    }
  }

  private void removeMouseListenerFromManagedComponents(final MouseListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      final Component component = managedComponents.get(i);
      component.removeMouseListener(listener);
    }
  }

  private void addMouseMotionListenerToManagedComponents(final MouseMotionListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      final Component component = managedComponents.get(i);
      component.addMouseMotionListener(listener);
    }
  }

  private void removeMouseMotionListenerFromManagedComponents(final MouseMotionListener listener) {
    for (int i = 0; i < managedComponents.size(); i++) {
      final Component component = managedComponents.get(i);
      component.removeMouseMotionListener(listener);
    }
  }

  private void addMouseListenersToManagedComponents() {
    for (int i = 0; i < mouseListeners.size(); i++) {
      final MouseListener listener = mouseListeners.get(i);
      addMouseListenerToManagedComponents(listener);
    }
  }

  private void removeMouseListenersFromManagedComponents() {
    for (int i = 0; i < mouseListeners.size(); i++) {
      final MouseListener listener = mouseListeners.get(i);
      removeMouseListenerFromManagedComponents(listener);
    }
  }

  private void addMouseMotionListenersToManagedComponents() {
    for (int i = 0; i < mouseMotionListeners.size(); i++) {
      final MouseMotionListener listener = mouseMotionListeners.get(i);
      addMouseMotionListenerToManagedComponents(listener);
    }
  }

  private void removeMouseMotionListenersFromManagedComponents() {
    for (int i = 0; i < mouseMotionListeners.size(); i++) {
      final MouseMotionListener listener = mouseMotionListeners.get(i);
      removeMouseMotionListenerFromManagedComponents(listener);
    }
  }

  private void updateManagedComponentsList() {
    managedComponents.clear();
    collectComponents(getComponent(0));
  }

  private void collectComponents(final Component component) {
    managedComponents.add(component);
    if (component instanceof Container && !(component instanceof OverallMouseListeningPanel)) {
      final Container container = (Container) component;
      final Component[] components = container.getComponents();
      for (Component component2 : components) {
        collectComponents(component2);
      }
    }
  }

  @Override
  public final Component add(final Component comp) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  @Override
  public final void add(final Component comp, final Object constraints) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  @Override
  public Component add(final Component comp, final int index) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }

  @Override
  public void add(final Component comp, final Object constraints, final int index) {
    throw new UnsupportedOperationException(
        "Adding components to an OverallMouseListeningPanel not allowed."); //$NON-NLS-1$
  }
}