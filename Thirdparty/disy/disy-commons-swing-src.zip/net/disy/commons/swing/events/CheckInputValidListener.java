package net.disy.commons.swing.events;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;

public class CheckInputValidListener
    implements
    ActionListener,
    ItemListener,
    ListSelectionListener,
    DocumentListener,
    ChangeListener,
    TableModelListener,
    TreeSelectionListener,
    PropertyChangeListener {

  private IInputValidCheckable checkable;

  public CheckInputValidListener(IInputValidCheckable checkable) {
    this.checkable = checkable;
  }

  public void checkInputValid() {
    checkable.checkInputValid();
  }

  public void itemStateChanged(ItemEvent e) {
    checkInputValid();
  }

  public void valueChanged(ListSelectionEvent e) {
    checkInputValid();
  }

  public void insertUpdate(DocumentEvent e) {
    checkInputValid();
  }

  public void removeUpdate(DocumentEvent e) {
    checkInputValid();
  }

  public void changedUpdate(DocumentEvent e) {
    checkInputValid();
  }

  public void stateChanged(ChangeEvent e) {
    checkInputValid();
  }

  public void tableChanged(TableModelEvent e) {
    checkInputValid();
  }

  public void propertyChange(PropertyChangeEvent evt) {
    checkInputValid();
  }

  public void valueChanged(TreeSelectionEvent e) {
    checkInputValid();
  }

  public void actionPerformed(ActionEvent e) {
    checkInputValid();
  }
}