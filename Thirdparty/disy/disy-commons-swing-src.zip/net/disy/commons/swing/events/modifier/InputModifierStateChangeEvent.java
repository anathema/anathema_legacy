/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.modifier;

import java.util.EventObject;

import net.disy.commons.core.util.Ensure;

/**
 * Event describing a change in an {@link net.disy.commons.swing.events.modifier.InputModifierState} object.
 */
public class InputModifierStateChangeEvent extends EventObject {

  private final InputModifierState state;

  public InputModifierStateChangeEvent(final InputModifierState state) {
    super(state);
    Ensure.ensureArgumentNotNull(state);
    this.state = state;
  }

  public InputModifierState getState() {
    return state;
  }
}