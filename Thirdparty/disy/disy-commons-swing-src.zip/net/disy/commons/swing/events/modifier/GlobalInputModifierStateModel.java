//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.modifier;

import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;

import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.WeakListenerList;

// NOT_PUBLISHED
public class GlobalInputModifierStateModel {

  private final static GlobalInputModifierStateModel instance = new GlobalInputModifierStateModel();

  public static GlobalInputModifierStateModel getInstance() {
    return instance;
  }

  private final WeakListenerList/*<IInputModifierStateListener>*/listeners = new WeakListenerList();
  private InputModifierState inputModifierState = new InputModifierState();

  private GlobalInputModifierStateModel() {
    KeyboardFocusManager kfm = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    kfm.addKeyEventDispatcher(new KeyEventDispatcher() {
      public boolean dispatchKeyEvent(KeyEvent e) {
        if (!inputModifierState.isEqualState(e)) {
          inputModifierState = new InputModifierState(e);
          fireInputModifierStateChangeEvent();
        }
        return false;
      }
    });
  }

  public void addWeakInputModifierStateListener(IInputModifierStateListener listener) {
    listeners.add(listener);
  }

  public void removeWeakInputModifierStateListener(IInputModifierStateListener listener) {
    listeners.remove(listener);
  }

  private void fire(final InputModifierStateChangeEvent event) {
    listeners.forAllDo(new IListenerClosure() {
      public void execute(Object input) {
        ((IInputModifierStateListener) input).inputModifierStateChanged(event);
      }
    });
  }

  private void fireInputModifierStateChangeEvent() {
    fire(new InputModifierStateChangeEvent(inputModifierState));
  }

  public InputModifierState getInputModifierState() {
    return inputModifierState;
  }
}