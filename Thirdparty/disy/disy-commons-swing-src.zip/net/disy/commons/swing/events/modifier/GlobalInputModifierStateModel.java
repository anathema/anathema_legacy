/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.modifier;

import java.awt.KeyEventDispatcher;
import java.awt.KeyboardFocusManager;
import java.awt.event.KeyEvent;

import net.disy.commons.core.model.listener.WeakListenerList;
import net.disy.commons.core.util.IClosure;

public class GlobalInputModifierStateModel {

  private final static GlobalInputModifierStateModel instance = new GlobalInputModifierStateModel();

  public static GlobalInputModifierStateModel getInstance() {
    return instance;
  }

  private final WeakListenerList<IInputModifierStateListener> listeners = new WeakListenerList<IInputModifierStateListener>();
  private InputModifierState inputModifierState = new InputModifierState();

  private GlobalInputModifierStateModel() {
    final KeyboardFocusManager kfm = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    kfm.addKeyEventDispatcher(new KeyEventDispatcher() {
      @Override
      public boolean dispatchKeyEvent(final KeyEvent e) {
        if (!inputModifierState.isEqualState(e)) {
          inputModifierState = new InputModifierState(e);
          fireInputModifierStateChangeEvent();
        }
        return false;
      }
    });
  }

  public void addWeakInputModifierStateListener(final IInputModifierStateListener listener) {
    listeners.add(listener);
  }

  public void removeWeakInputModifierStateListener(final IInputModifierStateListener listener) {
    listeners.remove(listener);
  }

  private void fire(final InputModifierStateChangeEvent event) {
    listeners.forAllDo(new IClosure<IInputModifierStateListener>() {
      @Override
      public void execute(final IInputModifierStateListener input) {
        input.inputModifierStateChanged(event);
      }
    });
  }

  private void fireInputModifierStateChangeEvent() {
    fire(new InputModifierStateChangeEvent(inputModifierState));
  }

  public InputModifierState getInputModifierState() {
    return inputModifierState;
  }
}