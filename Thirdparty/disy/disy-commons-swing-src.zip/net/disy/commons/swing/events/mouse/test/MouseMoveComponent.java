//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.events.mouse.test;

import java.awt.event.MouseEvent;

import javax.swing.JComponent;

// NOT_PUBLISHED
public class MouseMoveComponent extends JComponent {
  
  public void performMouseMoved() {
    processEvent(new MouseEvent(
        this,
        MouseEvent.MOUSE_MOVED,
        System.currentTimeMillis(),
        0,
        0,
        0,
        1,
        false,
        MouseEvent.BUTTON1));
  }

}