/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.events.mouse.test;

import java.awt.event.MouseEvent;

import javax.swing.JComponent;

public class MouseMoveComponent extends JComponent {

  public void performMouseMoved() {
    processEvent(new MouseEvent(
        this,
        MouseEvent.MOUSE_MOVED,
        System.currentTimeMillis(),
        0,
        0,
        0,
        1,
        false,
        MouseEvent.BUTTON1));
  }

}