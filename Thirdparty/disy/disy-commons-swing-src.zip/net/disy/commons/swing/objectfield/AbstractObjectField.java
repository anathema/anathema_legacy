/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.ToolTipManager;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AbstractDocument;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.IBooleanModel;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.string.IStringConverter;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.TextUtilities;

public abstract class AbstractObjectField<T> implements IObjectField<T> {

  public static final class TextField extends JTextField {

    private final IStringConverter toolTipConverter;

    public TextField(final int columns, final IStringConverter toolTipConverter) {
      super(columns);
      this.toolTipConverter = toolTipConverter;
      if (this.toolTipConverter != null) {
        final ToolTipManager manager = ToolTipManager.sharedInstance();
        manager.registerComponent(this);
      }
    }

    @Override
    public void setToolTipText(final String text) {
      super.setToolTipText(text);
      if (text == null && this.toolTipConverter != null) {
        final ToolTipManager manager = ToolTipManager.sharedInstance();
        manager.registerComponent(this);
      }
    }

    @Override
    public String getToolTipText() {
      if (this.toolTipConverter == null) {
        return super.getToolTipText();
      }
      final int columnWidth = getWidth();
      final double valueWidth = TextUtilities.getValueWidth(this, getText());
      if (valueWidth > columnWidth - 2) {
        return this.toolTipConverter.convert(getText());
      }
      return this.toolTipConverter.convert(null);
    }
  }

  private final ObjectModel<T> model;
  private final BooleanModel validStateModel = new BooleanModel(true);
  private final JTextField textField;
  boolean isDocumentListenerEnabled = true;
  private final IObjectFormater<T> formater;

  public AbstractObjectField(final IObjectFieldConfiguration<T> configuration) {
    Ensure.ensureNotNull(configuration);
    this.model = configuration.getModelFactory().createInstance();
    this.formater = configuration.getObjectFormater(model);
    final IStringConverter toolTipConverter = configuration.getToolTipConverter();
    this.textField = new TextField(configuration.getColumns(), toolTipConverter);
    this.textField.setEditable(configuration.isEditable());
    this.textField.setHorizontalAlignment(configuration.getHorizontalAlignment());
    this.textField.addActionListener(null);
    final Document document = this.textField.getDocument();
    if (configuration.isEditable()) {
      document.addDocumentListener(new DocumentListener() {

        @Override
        public void removeUpdate(final DocumentEvent e) {
          if (AbstractObjectField.this.isDocumentListenerEnabled) {
            updateModel(document);
          }
        }

        @Override
        public void insertUpdate(final DocumentEvent e) {
          if (AbstractObjectField.this.isDocumentListenerEnabled) {
            updateModel(document);
          }
        }

        @Override
        public void changedUpdate(final DocumentEvent e) {
          if (AbstractObjectField.this.isDocumentListenerEnabled) {
            updateModel(document);
          }
        }
      });
    }
    this.model.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        updateFieldText(document);
      }

    });
    this.textField.addKeyListener(new KeyListener() {

      @Override
      public void keyTyped(final KeyEvent event) {
        if (event.getKeyChar() == 0x1b) {
          updateFieldText(document);
        }
      }

      @Override
      public void keyReleased(final KeyEvent event) {
        //nothing to do
      }

      @Override
      public void keyPressed(final KeyEvent event) {
        //nothing to do
      }
    });
    updateFieldText(document);
  }

  protected IObjectFormater<T> getObjectFormater() {
    return formater;
  }

  @Override
  public IObjectModel<T> getModel() {
    return this.model;
  }

  public void setHorizontalAlignment(final int alignment) {
    this.textField.setHorizontalAlignment(alignment);
  }

  @Override
  public JComponent getContent() {
    return this.textField;
  }

  private String getText(final Document document) {
    try {
      return document.getText(0, document.getLength());
    }
    catch (final BadLocationException exception) {
      return ""; //$NON-NLS-1$
    }
  }

  @Override
  public IBooleanModel getValidStateModel() {
    return this.validStateModel;
  }

  synchronized void updateModel(final Document document) {
    final String text = getText(document);
    final IObjectFormater<T> objectFormater = getObjectFormater();
    if (objectFormater.isValid(text)) {
      this.model.setValue(objectFormater.parse(text));
      this.validStateModel.setValue(true);
      return;
    }
    this.validStateModel.setValue(false);
  }

  protected synchronized void updateFieldText(final Document document) {
    final String text = getText(document);
    final T value = this.model.getValue();
    if (value == null && (text == null || text.length() == 0)) {
      return;
    }
    final IObjectFormater<T> objectFormater = getObjectFormater();
    if (text != null
        && text.length() != 0
        && objectFormater.isValid(text)
        && objectFormater.parse(text).equals(value)) {
      this.validStateModel.setValue(true);
      return;
    }
    final String textValue = objectFormater.format(value);
    try {
      if (document instanceof AbstractDocument) {
        ((AbstractDocument) document).replace(0, document.getLength(), textValue, null);
      }
      else {
        this.isDocumentListenerEnabled = false;
        document.remove(0, document.getLength());
        this.isDocumentListenerEnabled = true;
        document.insertString(0, textValue, null);
      }
      this.validStateModel.setValue(objectFormater.isValid(textValue));
    }
    catch (final BadLocationException exception) {
      throw new UnreachableCodeReachedException(exception);
    }
  }

  public void requestFocus() {
    textField.requestFocus();
  }

  public synchronized void addActionListener(final ActionListener listener) {
    this.textField.addActionListener(listener);
  }

  public synchronized void removeActionListener(final ActionListener listener) {
    this.textField.removeActionListener(listener);
  }
}