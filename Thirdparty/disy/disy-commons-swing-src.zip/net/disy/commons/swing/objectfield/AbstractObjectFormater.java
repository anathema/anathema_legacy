/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

public abstract class AbstractObjectFormater<T> implements IObjectFormater<T> {

  private final IObjectValidator<String> validator;

  public AbstractObjectFormater(final IObjectValidator<String> validator) {
    this.validator = validator;
  }

  @Override
  public boolean isValid(final String text) {
    return validator.isValid(text);
  }

}
