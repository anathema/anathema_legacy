/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

import javax.swing.SwingConstants;

import net.disy.commons.core.creation.IFactory;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.provider.IObjectProvider;
import net.disy.commons.core.string.IStringConverter;

public final class StringFieldConfiguration implements IObjectFieldConfiguration<String> {
  private final int horizontalAlignment;
  private final IObjectFormater<String> formater;
  private final int columns;
  private final boolean editable;
  private final IStringConverter toolTipConverter;

  public StringFieldConfiguration(final int columns, final IObjectFormater<String> formater) {
    this(columns, formater, null, true, SwingConstants.LEFT);
  }

  public StringFieldConfiguration(
      final int columns,
      final IObjectFormater<String> formater,
      final IStringConverter toolTipConverter,
      boolean editable,
      int horizontalAlignment) {
    this.horizontalAlignment = horizontalAlignment;
    this.columns = columns;
    this.formater = formater;
    this.toolTipConverter = toolTipConverter;
    this.editable = editable;
  }

  @Override
  public IObjectFormater<String> getObjectFormater(IObjectProvider<String> provider) {
    return this.formater;
  }

  @Override
  public int getColumns() {
    return columns;
  }

  @Override
  public int getHorizontalAlignment() {
    return horizontalAlignment;
  }

  @Override
  public boolean isEditable() {
    return editable;
  }

  @Override
  public IFactory<ObjectModel<String>, RuntimeException> getModelFactory() {
    return new IFactory<ObjectModel<String>, RuntimeException>() {

      @Override
      public ObjectModel<String> createInstance() throws RuntimeException {
        return new ObjectModel<String>();
      }
    };
  }

  @Override
  public IStringConverter getToolTipConverter() {
    return toolTipConverter;
  }
}