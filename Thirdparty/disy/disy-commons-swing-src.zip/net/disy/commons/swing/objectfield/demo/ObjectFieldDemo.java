/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield.demo;

import javax.swing.JTextField;

import net.disy.commons.core.creation.IFactory;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.provider.IObjectProvider;
import net.disy.commons.core.string.IStringConverter;
import net.disy.commons.swing.objectfield.AbstractObjectField;
import net.disy.commons.swing.objectfield.AbstractObjectFormater;
import net.disy.commons.swing.objectfield.IObjectField;
import net.disy.commons.swing.objectfield.IObjectFieldConfiguration;
import net.disy.commons.swing.objectfield.IObjectFormater;
import net.disy.commons.swing.objectfield.IObjectValidator;
import net.disy.commons.swing.objectfield.StringField;
import net.disy.commons.swing.objectfield.StringFieldConfiguration;
import net.disy.commons.swing.objectfield.StringFormater;
import net.disy.commons.swing.objectfield.StringValidator;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class ObjectFieldDemo extends AbstractObjectFieldDemo {

  @Demo
  public void DoubleField() {
    final IObjectValidator<String> validator = new IObjectValidator<String>() {

      @Override
      public boolean isValid(final String text) {
        if (text == null || text.trim().length() == 0) {
          return true;
        }
        try {
          Double.valueOf(text);
        }
        catch (final Exception e) {
          return false;
        }
        return true;
      }
    };
    final IObjectFormater<Double> formater = new AbstractObjectFormater<Double>(validator) {

      @Override
      public Double parse(final String text) {
        if (text == null || text.trim().length() == 0) {
          return null;
        }
        return Double.valueOf(text);
      }

      @Override
      public String format(final Double object) {
        if (object == null) {
          return null;
        }
        return object.toString();
      }
    };
    final IObjectFieldConfiguration<Double> configuration = new IObjectFieldConfiguration<Double>() {

      @Override
      public IObjectFormater<Double> getObjectFormater(IObjectProvider<Double> provider) {
        return formater;
      }

      @Override
      public int getColumns() {
        return 10;
      }

      @Override
      public int getHorizontalAlignment() {
        return JTextField.RIGHT;
      }

      @Override
      public boolean isEditable() {
        return true;
      }

      @Override
      public IFactory<ObjectModel<Double>, RuntimeException> getModelFactory() {
        return new IFactory<ObjectModel<Double>, RuntimeException>() {

          @Override
          public ObjectModel<Double> createInstance() throws RuntimeException {
            return new ObjectModel<Double>();
          }
        };
      }

      @Override
      public IStringConverter getToolTipConverter() {
        return new IStringConverter() {

          @Override
          public String convert(String text) {
            if (text == null) {
              return "demo field"; //$NON-NLS-1$
            }
            return text;
          }
        };
      }
    };
    final IObjectField<Double> field = new AbstractObjectField<Double>(configuration) {
    };
    show(createPanel(field));
  }

  @Demo
  public void StringField() {
    final IObjectValidator<String> validator = new StringValidator();
    final IObjectFormater<String> formater = new StringFormater(validator);
    final IObjectFieldConfiguration<String> configuration = new StringFieldConfiguration(
        10,
        formater);
    final IObjectField<String> field = new StringField(configuration);
    show(createPanel(field));
  }
}
