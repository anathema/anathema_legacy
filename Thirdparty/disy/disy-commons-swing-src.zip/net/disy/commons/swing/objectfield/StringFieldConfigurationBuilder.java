/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

import javax.swing.SwingConstants;

import net.disy.commons.core.string.IStringConverter;

public class StringFieldConfigurationBuilder {

  private int horizontalAlignment = SwingConstants.LEFT;
  private int columns = 10;
  private IObjectFormater<String> formater = new StringFormater();
  private boolean editable = true;
  private IStringConverter toolTipConverter = null;

  public void setHorizontalAlignment(int horizontalAlignment) {
    this.horizontalAlignment = horizontalAlignment;
  }

  public void setToolTipConverter(IStringConverter converter) {
    this.toolTipConverter = converter;
  }

  public void setFormater(IObjectFormater<String> formater) {
    this.formater = formater;
  }

  public void setColumns(int columns) {
    this.columns = columns;
  }

  public void setEditable(boolean editable) {
    this.editable = editable;
  }

  public IObjectFieldConfiguration<String> build() {
    return new StringFieldConfiguration(
        columns,
        formater,
        toolTipConverter,
        editable,
        horizontalAlignment);
  }
}
