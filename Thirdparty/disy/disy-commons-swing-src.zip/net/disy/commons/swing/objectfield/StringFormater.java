/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

public final class StringFormater extends AbstractObjectFormater<String> {

  public StringFormater() {
    this(new StringValidator());
  }

  public StringFormater(final IObjectValidator<String> validator) {
    super(validator);
  }

  @Override
  public String parse(final String text) {
    if (text == null || text.trim().length() == 0) {
      return null;
    }
    return text;
  }

  @Override
  public String format(final String object) {
    return object;
  }
}