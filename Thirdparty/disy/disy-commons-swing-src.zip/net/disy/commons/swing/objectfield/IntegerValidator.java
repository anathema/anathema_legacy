/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

public class IntegerValidator implements IObjectValidator<String> {

  @Override
  public boolean isValid(String text) {
    if (text == null || text.trim().length() == 0) {
      return true;
    }
    try {
      Integer.valueOf(text);
      return true;
    }
    catch (NumberFormatException e) {
      return false;
    }

    //    String value = text.trim();
    //    boolean flag = false;
    //    for (int i = 0; i < value.length(); ++i) {
    //      switch (value.charAt(i)) {
    //        case '0':
    //        case '1':
    //        case '2':
    //        case '3':
    //        case '4':
    //        case '5':
    //        case '6':
    //        case '7':
    //        case '8':
    //        case '9':
    //          flag = true;
    //          break;
    //        case '+':
    //        case '-':
    //        case ' ':
    //        case '\t':
    //          if (flag) {
    //            return false;
    //          }
    //          break;
    //        default:
    //          return false;
    //      }
    //    }
    //    return true;
  }

}
