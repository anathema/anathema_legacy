/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield;

import javax.swing.SwingConstants;

import net.disy.commons.core.creation.IFactory;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.provider.IObjectProvider;
import net.disy.commons.core.string.IStringConverter;

public final class IntegerFieldConfiguration implements IObjectFieldConfiguration<Integer> {
  private final IObjectFormater<Integer> formater;
  private final int columns;
  private final IStringConverter toolTipConverter = new IStringConverter() {

    @Override
    public String convert(String text) {
      return text;
    }
  };

  public IntegerFieldConfiguration(final IObjectFormater<Integer> formater) {
    this(10, formater);
  }

  public IntegerFieldConfiguration(final int columns, final IObjectFormater<Integer> formater) {
    this.columns = columns;
    this.formater = formater;
  }

  @Override
  public IObjectFormater<Integer> getObjectFormater(IObjectProvider<Integer> provider) {
    return this.formater;
  }

  @Override
  public int getColumns() {
    return columns;
  }

  @Override
  public int getHorizontalAlignment() {
    return SwingConstants.RIGHT;
  }

  @Override
  public boolean isEditable() {
    return true;
  }

  @Override
  public IFactory<ObjectModel<Integer>, RuntimeException> getModelFactory() {
    return new IFactory<ObjectModel<Integer>, RuntimeException>() {

      @Override
      public ObjectModel<Integer> createInstance() throws RuntimeException {
        return new ObjectModel<Integer>();
      }
    };
  }

  @Override
  public IStringConverter getToolTipConverter() {
    return toolTipConverter;
  }
}