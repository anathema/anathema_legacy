/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.objectfield.demo;

import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.objectfield.IObjectField;
import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractObjectFieldDemo extends SwingDemoCase {

  protected void show(final IObjectField<?> field) {
    show(createPanel(field));
  }

  protected JPanel createPanel(final IObjectField<?> field) {
    final JTextField textField = new JTextField();
    textField.setEditable(false);
    final JTextField validField = new JTextField();
    validField.setEditable(false);
    field.getModel().addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        update(field, textField, validField);
      }

    });
    field.getValidStateModel().addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        update(field, textField, validField);
      }
    });
    final JPanel panel = new JPanel(new GridDialogLayout(1, true));
    panel.add(field.getContent(), GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(textField, GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(validField, GridDialogLayoutData.FILL_HORIZONTAL);
    update(field, textField, validField);
    return panel;
  }

  private void update(
      final IObjectField<?> field,
      final JTextField textField,
      final JTextField validField) {
    final Object value = field.getModel().getValue();
    textField.setText(value == null ? null : value.toString());
    final boolean state = field.getValidStateModel().getValue();
    validField.setText(state ? "valid" : "invalid"); //$NON-NLS-1$//$NON-NLS-2$
  }

}
