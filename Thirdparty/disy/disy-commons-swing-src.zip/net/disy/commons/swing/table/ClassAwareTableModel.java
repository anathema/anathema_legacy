/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import javax.swing.table.DefaultTableModel;

import net.disy.commons.core.util.Ensure;

public class ClassAwareTableModel extends DefaultTableModel {

  private final Class<?>[] columnClasses;

  public ClassAwareTableModel(int rowCount, int columnCount, Class<?>[] columnClasses) {
    super(rowCount, columnCount);
    this.columnClasses = columnClasses;
    Ensure.ensureTrue("The number of column classes should be the same as column count.", //$NON-NLS-1$
        columnCount == columnClasses.length);
  }

  @Override
  public Class<?> getColumnClass(int columnIndex) {
    return columnClasses[columnIndex];
  }

}
