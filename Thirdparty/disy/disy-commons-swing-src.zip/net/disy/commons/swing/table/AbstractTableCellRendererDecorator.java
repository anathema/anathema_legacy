/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public abstract class AbstractTableCellRendererDecorator implements TableCellRenderer {

  private TableCellRenderer renderer;

  protected TableCellRenderer getRenderer() {
    return renderer;
  }

  public void setDelegate(final TableCellRenderer renderer) {
    this.renderer = renderer;
  }

  protected JComponent getOriginalRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    return (JComponent) getRenderer().getTableCellRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
  }

}
