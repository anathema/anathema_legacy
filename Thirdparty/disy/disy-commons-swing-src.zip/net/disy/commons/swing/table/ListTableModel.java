/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import net.disy.commons.core.model.listener.IChangeListener;
import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.GuiUtilities;

public class ListTableModel<T> extends AbstractTableModel {

  private final IListModel<T> listModel;
  private final String[] columnNames;

  public ListTableModel(final IListModel<T> listModel, final String... columnNames) {
    Ensure.ensureArgumentNotNull(listModel);
    Ensure.ensureArgumentNotNull(columnNames);
    this.columnNames = columnNames;
    this.listModel = listModel;
    listModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        //Bugfix (gebhard) 13.04.2006: Deadlock in FilterableListTable by firing events outside EDT
        GuiUtilities.invokeLaterIfNecessary(new Runnable() {
          @Override
          public void run() {
            fireTableDataChanged();
          }
        });
      }
    });
  }

  @Override
  public int getColumnCount() {
    return columnNames.length;
  }

  @Override
  public String getColumnName(final int column) {
    return columnNames[column];
  }

  @Override
  public int getRowCount() {
    return listModel.getItemCount();
  }

  @Override
  public T getValueAt(final int rowIndex, final int columnIndex) {
    return listModel.getItem(rowIndex);
  }
}