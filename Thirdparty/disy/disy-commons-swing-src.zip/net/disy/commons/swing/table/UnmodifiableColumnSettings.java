/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import net.disy.commons.core.util.Ensure;

public class UnmodifiableColumnSettings<T> implements ITableModelColumnSettings<T> {

  private final T[] objects;
  private final Class<T> itemClass;
  private final String columnName;

  public UnmodifiableColumnSettings(
      final T[] objects,
      final String columnName,
      final Class<T> itemClass) {
    Ensure.ensureArgumentNotNull(objects);
    Ensure.ensureArgumentNotNull(columnName);
    Ensure.ensureArgumentNotNull(itemClass);
    this.objects = objects;
    this.columnName = columnName;
    this.itemClass = itemClass;
  }

  @Override
  public String getColumnName() {
    return columnName;
  }

  @Override
  public Class<T> getItemClass() {
    return itemClass;
  }

  @Override
  public T getValueAt(final int rowIndex) {
    return objects[rowIndex];
  }

  @Override
  public void setValueAt(final T value, final int rowIndex) {
    // nothing to do
  }

  @Override
  public boolean isCellEditable(final int rowIndex) {
    return false;
  }
}
