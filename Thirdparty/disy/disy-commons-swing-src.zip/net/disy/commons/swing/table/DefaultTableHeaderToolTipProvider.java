// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 29.04.2004
package net.disy.commons.swing.table;

// NOT_PUBLISHED
public class DefaultTableHeaderToolTipProvider implements ITableHeaderToolTipProvider {

  public String getToolTip(Object value, int columnIndex) {
    return value == null ? "" : value.toString(); //$NON-NLS-1$
  }

}
