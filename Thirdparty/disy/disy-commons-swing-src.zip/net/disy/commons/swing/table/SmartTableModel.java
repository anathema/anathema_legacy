/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.util.GuiUtilities;

public abstract class SmartTableModel extends AbstractTableModel {
  private final ITableModelColumnSettings[] settings;

  public SmartTableModel(
      final ITableModelColumnSettings[] settings,
      final IChangeableModel... models) {
    this(settings, true, models);
  }

  public SmartTableModel(
      final ITableModelColumnSettings[] settings,
      boolean registerChangeListeners,
      final IChangeableModel... models) {
    Ensure.ensureArgumentNotNull(settings);
    this.settings = settings;
    if (registerChangeListeners) {
      for (final IChangeableModel model : models) {
        model.addChangeListener(new IChangeListener() {
          @Override
          public void stateChanged() {
            GuiUtilities.invokeLaterIfNecessary(new Runnable() {
              @Override
              public void run() {
                fireTableDataChanged();
              }
            });
          }
        });
      }
    }
  }

  @Override
  public final int getColumnCount() {
    return settings.length;
  }

  @Override
  public final Object getValueAt(final int rowIndex, final int columnIndex) {
    return settings[columnIndex].getValueAt(rowIndex);
  }

  @Override
  public final String getColumnName(final int column) {
    return settings[column].getColumnName();
  }

  @Override
  public final void setValueAt(final Object aValue, final int rowIndex, final int columnIndex) {
    settings[columnIndex].setValueAt(aValue, rowIndex);
  }

  @Override
  public final Class<?> getColumnClass(final int columnIndex) {
    return settings[columnIndex].getItemClass();
  }

  @Override
  public final boolean isCellEditable(final int rowIndex, final int columnIndex) {
    return settings[columnIndex].isCellEditable(rowIndex);
  }
}
