/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JTable;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;

public class ToolTipCellRendererDecorator extends AbstractTableCellRendererDecorator {

  private final ITableHeaderToolTipProvider tooltipProvider;

  public ToolTipCellRendererDecorator(final ITableHeaderToolTipProvider tooltipProvider) {
    Ensure.ensureArgumentNotNull(tooltipProvider);
    this.tooltipProvider = tooltipProvider;
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    final JComponent component = getOriginalRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
    final String toolTipText = tooltipProvider.getToolTip(value, column);
    component.setToolTipText(StringUtilities.isNullOrEmpty(toolTipText) ? null : toolTipText);
    return component;
  }
}