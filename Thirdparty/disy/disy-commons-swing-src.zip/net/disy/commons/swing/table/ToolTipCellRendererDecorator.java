//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.table;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JTable;


// NOT_PUBLISHED
public class ToolTipCellRendererDecorator extends AbstractTableCellRendererDecorator {

  private final ITableHeaderToolTipProvider tooltipProvider;

  public ToolTipCellRendererDecorator(ITableHeaderToolTipProvider provider) {
    this.tooltipProvider = provider;
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    JComponent component = getOriginalRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
    component.setToolTipText(tooltipProvider.getToolTip(value, column));
    return component;
  }
}