/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.table;

import java.util.ArrayList;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.util.Ensure;

public class ObjectTableModel<T> extends AbstractTableModel {

  private final List<T> values = new ArrayList<T>();
  private final List<String> columnNames = new ArrayList<String>();
  private final IObjectValueExtractor<T> extractor;
  private final List<Class<?>> columnClasses;

  public ObjectTableModel(
      final List<String> columnNames,
      final List<Class<?>> columnClasses,
      final List<T> values,
      final IObjectValueExtractor<T> extractor) {
    Ensure.ensureArgumentNotNull(values);
    Ensure.ensureArgumentNotNull(columnNames);
    Ensure.ensureArgumentNotNull(columnClasses);
    Ensure.ensureArgumentNotNull(extractor);
    this.columnNames.addAll(columnNames);
    this.values.addAll(values);
    this.extractor = extractor;
    this.columnClasses = columnClasses;
  }

  @Override
  public int getColumnCount() {
    return columnNames.size();
  }

  @Override
  public Class<?> getColumnClass(int columnIndex) {
    if (columnIndex < 0 || columnIndex >= columnClasses.size()) {
      return Object.class;
    }
    return columnClasses.get(columnIndex);
  }

  @Override
  public String getColumnName(final int columnIndex) {
    if (columnIndex < 0 || columnIndex >= columnNames.size()) {
      return null;
    }
    return columnNames.get(columnIndex);
  }

  @Override
  public int getRowCount() {
    return values.size();
  }

  @Override
  public Object getValueAt(final int rowIndex, final int columnIndex) {
    if (rowIndex < 0 || rowIndex >= values.size()) {
      return null;
    }
    if (columnIndex < 0 || columnIndex >= columnNames.size()) {
      return null;
    }
    return extractor.extract(values.get(rowIndex), getColumnName(columnIndex));
  }
}