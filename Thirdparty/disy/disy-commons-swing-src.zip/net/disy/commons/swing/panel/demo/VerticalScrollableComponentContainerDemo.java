/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.panel.demo;

import javax.swing.JLabel;

import org.junit.runner.RunWith;

import net.disy.commons.swing.panel.VerticalScrollableComponentContainer;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class VerticalScrollableComponentContainerDemo extends SwingDemoCase {
  private VerticalScrollableComponentContainer verticalScrollableComponentContainer;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    verticalScrollableComponentContainer = new VerticalScrollableComponentContainer(200);
  }

  public void demoThreeItems() throws Exception {
    showVerticalComponentContainer(3);
  }

  public void demoLotOfItems() throws Exception {
    showVerticalComponentContainer(100);
  }

  public void demoDifferentHeightItems() throws Exception {
    for (int i = 0; i < 100; i++) {
      final JLabel label = new JLabel("Label " + (i + 1)); //$NON-NLS-1$
      label.setFont(label.getFont().deriveFont((float) (30 * Math.random() + 6)));
      verticalScrollableComponentContainer.addComponent(label);
    }
    showVerticalComponentContainer();
  }

  private void showVerticalComponentContainer(final int numComponents) {
    for (int i = 0; i < numComponents; i++) {
      verticalScrollableComponentContainer.addComponent(new JLabel("Label " + (i + 1))); //$NON-NLS-1$
    }
    showVerticalComponentContainer();
  }

  private void showVerticalComponentContainer() {
    show(verticalScrollableComponentContainer.getContent());
  }
}