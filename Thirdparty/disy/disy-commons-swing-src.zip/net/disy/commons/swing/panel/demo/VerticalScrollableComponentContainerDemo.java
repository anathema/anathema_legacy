// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.panel.demo;

import javax.swing.JLabel;

import net.disy.commons.swing.panel.VerticalScrollableComponentContainer;

import de.jdemo.extensions.SwingDemoCase;

//NOT_PUBLISHED
public class VerticalScrollableComponentContainerDemo extends SwingDemoCase {
  private VerticalScrollableComponentContainer verticalScrollableComponentContainer;

  @Override
  protected void setUp() throws Exception {
    super.setUp();
    verticalScrollableComponentContainer = new VerticalScrollableComponentContainer(200);
  }

  public void demoThreeItems() throws Exception {
    showVerticalComponentContainer(3);
  }

  public void demoLotOfItems() throws Exception {
    showVerticalComponentContainer(100);
  }

  public void demoDifferentHeightItems() throws Exception {
    for (int i = 0; i < 100; i++) {
      JLabel label = new JLabel("Label " + (i + 1)); //$NON-NLS-1$
      label.setFont(label.getFont().deriveFont((float) (30 * Math.random() + 6)));
      verticalScrollableComponentContainer.addComponent(label);
    }
    showVerticalComponentContainer();
  }

  private void showVerticalComponentContainer(int numComponents) {
    for (int i = 0; i < numComponents; i++) {
      verticalScrollableComponentContainer.addComponent(new JLabel("Label " + (i + 1))); //$NON-NLS-1$
    }
    showVerticalComponentContainer();
  }

  private void showVerticalComponentContainer() {
    show(verticalScrollableComponentContainer.getContent());
  }
}