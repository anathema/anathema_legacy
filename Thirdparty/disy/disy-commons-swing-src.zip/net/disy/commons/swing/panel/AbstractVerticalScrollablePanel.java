/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.panel;

import java.awt.Dimension;
import java.awt.LayoutManager;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;

public abstract class AbstractVerticalScrollablePanel extends JPanel implements Scrollable {
  private final int preferredViewPortHeight;

  public AbstractVerticalScrollablePanel(
      final LayoutManager layout,
      final int preferredViewPortHeight) {
    super(layout);
    this.preferredViewPortHeight = preferredViewPortHeight;
  }

  @Override
  public final boolean getScrollableTracksViewportHeight() {
    return false;
  }

  @Override
  public final boolean getScrollableTracksViewportWidth() {
    return true;
  }

  @Override
  public final Dimension getPreferredScrollableViewportSize() {
    return new Dimension(1, Math.min(preferredViewPortHeight, getPreferredSize().height));
  }

  @Override
  public final int getScrollableBlockIncrement(
      final Rectangle visibleRect,
      final int orientation,
      final int direction) {
    if (orientation == SwingConstants.HORIZONTAL) {
      return visibleRect.width;
    }

    return visibleRect.height;
  }

  @Override
  public final int getScrollableUnitIncrement(
      final Rectangle visibleRect,
      final int orientation,
      final int direction) {
    if (orientation == SwingConstants.HORIZONTAL) {
      return visibleRect.width;
    }

    return getVerticalScrollabelUnitIncrement(visibleRect, direction);
  }

  protected abstract int getVerticalScrollabelUnitIncrement(Rectangle visibleRect, int direction);
}
