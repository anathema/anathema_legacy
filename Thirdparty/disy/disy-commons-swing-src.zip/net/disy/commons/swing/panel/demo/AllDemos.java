// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.panel.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

//NOT_PUBLISHED
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.panel.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(VerticalScrollableComponentContainerDemo.class));
    //$JDemo-END$
    return suite;
  }

}
