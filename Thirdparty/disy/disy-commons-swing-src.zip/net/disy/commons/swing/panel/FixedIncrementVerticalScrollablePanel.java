/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.panel;

import java.awt.LayoutManager;
import java.awt.Rectangle;

import net.disy.commons.swing.layout.util.LayoutUtilities;

public class FixedIncrementVerticalScrollablePanel extends AbstractVerticalScrollablePanel {

  private final int unitIncrement;

  public FixedIncrementVerticalScrollablePanel(
      final LayoutManager layout,
      final int preferredViewPortHeight) {
    this(layout, preferredViewPortHeight, LayoutUtilities.getDpiAdjusted(20));
  }

  private FixedIncrementVerticalScrollablePanel(
      final LayoutManager layout,
      final int preferredViewPortHeight,
      final int unitIncrement) {
    super(layout, preferredViewPortHeight);
    this.unitIncrement = unitIncrement;
  }

  @Override
  protected int getVerticalScrollabelUnitIncrement(final Rectangle visibleRect, final int direction) {
    return unitIncrement;
  }
}