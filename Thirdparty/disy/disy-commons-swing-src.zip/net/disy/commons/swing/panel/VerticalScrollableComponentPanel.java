/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.panel;

import java.awt.Component;
import java.awt.Rectangle;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

public class VerticalScrollableComponentPanel extends AbstractVerticalScrollablePanel {
  public VerticalScrollableComponentPanel(final int preferredViewPortHeight) {
    super(new GridDialogLayout(1, false), preferredViewPortHeight);
  }

  @Override
  protected int getVerticalScrollabelUnitIncrement(final Rectangle visibleRect, final int direction) {
    if (direction > 0) {
      final Component component = getNextComponentToShow(visibleRect);
      return component.getY() + component.getHeight() - (visibleRect.y + visibleRect.height);
    }

    final Component component = getPreviousComponentToShow(visibleRect);
    return visibleRect.y - component.getY();
  }

  private Component getNextComponentToShow(final Rectangle visibleRect) {
    int componentIndex = 0;
    for (; componentIndex < getComponentCount(); componentIndex++) {
      final Component component = getComponent(componentIndex);
      if (component.getY() >= visibleRect.y) {
        break;
      }
    }

    for (; componentIndex < getComponentCount(); componentIndex++) {
      final Component component = getComponent(componentIndex);
      if (component.getY() + component.getHeight() > visibleRect.y + visibleRect.height) {
        break;
      }
    }

    if (componentIndex >= getComponentCount()) {
      componentIndex = getComponentCount() - 1;
    }

    return getComponent(componentIndex);
  }

  private Component getPreviousComponentToShow(final Rectangle visibleRect) {
    int componentIndex = getComponentCount() - 1;
    for (; componentIndex >= 0; componentIndex--) {
      final Component component = getComponent(componentIndex);
      if (component.getY() + component.getHeight() <= visibleRect.y + visibleRect.height) {
        break;
      }
    }

    for (; componentIndex >= 0; componentIndex--) {
      final Component component = getComponent(componentIndex);
      if (component.getY() < visibleRect.y) {
        break;
      }
    }

    if (componentIndex < 0) {
      componentIndex = 0;
    }

    return getComponent(componentIndex);
  }

}
