// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.panel;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JPanel;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

//NOT_PUBLISHED
public class VerticalScrollableComponentPanel extends JPanel implements Scrollable {
  private final int preferredViewPortHeight;

  public VerticalScrollableComponentPanel(int preferredViewPortHeight) {
    super(new GridDialogLayout(1, false));
    this.preferredViewPortHeight = preferredViewPortHeight;
  }

  public boolean getScrollableTracksViewportHeight() {
    return false;
  }

  public boolean getScrollableTracksViewportWidth() {
    return true;
  }

  public Dimension getPreferredScrollableViewportSize() {
    return new Dimension(1, Math.min(preferredViewPortHeight, getPreferredSize().height));
  }

  public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
    if (orientation == SwingConstants.HORIZONTAL) {
      return visibleRect.width;
    }

    return visibleRect.height;
  }

  public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
    if (orientation == SwingConstants.HORIZONTAL) {
      return visibleRect.width;
    }

    if (direction > 0) {
      Component component = getNextComponentToShow(visibleRect);
      return component.getY() + component.getHeight() - (visibleRect.y + visibleRect.height);
    }
    
    Component component = getPreviousComponentToShow(visibleRect);
    return visibleRect.y - component.getY();
  }

  private Component getNextComponentToShow(Rectangle visibleRect) {
    int componentIndex = 0;
    for (; componentIndex < getComponentCount(); componentIndex++) {
      Component component = getComponent(componentIndex);
      if (component.getY() >= visibleRect.y) {
        break;
      }
    }

    for (; componentIndex < getComponentCount(); componentIndex++) {
      Component component = getComponent(componentIndex);
      if (component.getY() + component.getHeight() > visibleRect.y + visibleRect.height) {
        break;
      }
    }

    if (componentIndex >= getComponentCount()) {
      componentIndex = getComponentCount() - 1;
    }
    
    return getComponent(componentIndex);
  }

  private Component getPreviousComponentToShow(Rectangle visibleRect) {
    int componentIndex = getComponentCount() - 1;
    for (; componentIndex >= 0; componentIndex--) {
      Component component = getComponent(componentIndex);
      if (component.getY() + component.getHeight() <= visibleRect.y + visibleRect.height) {
        break;
      }
    }

    for (; componentIndex >= 0; componentIndex--) {
      Component component = getComponent(componentIndex);
      if (component.getY() < visibleRect.y) {
        break;
      }
    }

    if (componentIndex < 0) {
      componentIndex = 0;
    }
    
    return getComponent(componentIndex);
  }

}
