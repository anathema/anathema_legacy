/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.panel;

import javax.swing.JComponent;
import javax.swing.JScrollPane;

import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public class VerticalScrollableComponentContainer {
  private final JComponent content;
  private final VerticalScrollableComponentPanel panel;

  public VerticalScrollableComponentContainer(final int preferredViewportHeight) {
    panel = new VerticalScrollableComponentPanel(preferredViewportHeight);
    content = new JScrollPane(panel);
  }

  public void addComponent(final JComponent component) {
    panel.add(component, GridDialogLayoutData.FILL_HORIZONTAL);
  }

  public JComponent getContent() {
    return content;
  }
}
