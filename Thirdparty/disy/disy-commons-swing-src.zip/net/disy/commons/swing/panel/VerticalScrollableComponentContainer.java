// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.panel;

import javax.swing.JComponent;
import javax.swing.JScrollPane;

import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

//NOT_PUBLISHED
public class VerticalScrollableComponentContainer {
  private final JComponent content;
  private final VerticalScrollableComponentPanel panel;
  
  public VerticalScrollableComponentContainer(int preferredViewportHeight) {
    panel = new VerticalScrollableComponentPanel(preferredViewportHeight);
    content = new JScrollPane(panel);
  }
  
  public void addComponent(JComponent component) {
    panel.add(component, GridDialogLayoutData.FILL_HORIZONTAL);
  }
  
  public JComponent getContent() {
    return content;
  }
}
