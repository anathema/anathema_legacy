//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.menu.test;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

import junit.framework.TestCase;

import net.disy.commons.swing.menu.HelpImplementedMenuBar;

// NOT_PUBLISHED
public class HelpImplementedMenuBarTest extends TestCase {
  private HelpImplementedMenuBar menuBar;
  private JMenu helpMenu;
  private JMenu menu2;
  private JMenu menu1;

  protected void setUp() throws Exception {
    menuBar = new HelpImplementedMenuBar();
    helpMenu = new JMenu();
    menu1 = new JMenu();
    menu2 = new JMenu();
  }

  public void testOwnImplementationStillNecessary() {
    try {
      new JMenuBar().setHelpMenu(new JMenu());
      fail();
    }
    catch (Error e) {
      //nothing to do
    }
  }

  public void testCreation() {
    assertNull(menuBar.getHelpMenu());
  }

  public void testSetGetHelpMenu() {
    menuBar.setHelpMenu(helpMenu);
    assertSame(helpMenu, menuBar.getHelpMenu());
  }

  public void testHelpMenuIsLast1() {
    menuBar.add(menu1);
    menuBar.add(menu2);
    menuBar.setHelpMenu(helpMenu);
    assertSame(menu1, menuBar.getComponent(0));
    assertSame(menu2, menuBar.getComponent(1));
    assertSame(helpMenu, menuBar.getComponent(2));
  }

  public void testHelpMenuIsLast2() {
    menuBar.add(menu1);
    menuBar.setHelpMenu(helpMenu);
    menuBar.add(menu2);
    assertSame(menu1, menuBar.getComponent(0));
    assertSame(menu2, menuBar.getComponent(1));
    assertSame(helpMenu, menuBar.getComponent(2));
  }

  public void testHelpMenuIsLast3() {
    menuBar.setHelpMenu(helpMenu);
    menuBar.add(menu1);
    menuBar.add(menu2);
    assertSame(menu1, menuBar.getComponent(0));
    assertSame(menu2, menuBar.getComponent(1));
    assertSame(helpMenu, menuBar.getComponent(2));
  }

  public void testSetHelpMenuTwice() {
    JMenu helpMenu2 = new JMenu();
    menuBar.setHelpMenu(helpMenu);
    menuBar.setHelpMenu(helpMenu2);
    assertSame(helpMenu2, menuBar.getHelpMenu());
    assertSame(helpMenu2, menuBar.getComponent(0));
    assertEquals(1, menuBar.getComponentCount());
  }

  public void testRemoveHelpMenu() {
    menuBar.setHelpMenu(helpMenu);
    menuBar.remove(helpMenu);
    assertNull(menuBar.getHelpMenu());
    assertEquals(0, menuBar.getComponentCount());
  }

  public void testRemoveAllMenus() {
    menuBar.setHelpMenu(helpMenu);
    menuBar.removeAll();
    assertNull(menuBar.getHelpMenu());
    assertEquals(0, menuBar.getComponentCount());
  }
}