/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.menu;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

public class HelpImplementedMenuBar extends JMenuBar {
  private JMenu helpMenu;

  @Override
  public void setHelpMenu(final JMenu menu) {
    if (helpMenu != null) {
      remove(helpMenu);
    }
    helpMenu = menu;
    super.add(helpMenu);
  }

  @Override
  public JMenu add(final JMenu menu) {
    if (helpMenu != null) {
      return (JMenu) add(menu, getComponentCount() - 1);
    }
    return super.add(menu);
  }

  @Override
  public JMenu getHelpMenu() {
    return helpMenu;
  }

  public void remove(final JMenu menu) {
    if (menu == helpMenu) {
      helpMenu = null;
    }
    super.remove(menu);
  }

  @Override
  public void removeAll() {
    super.removeAll();
    helpMenu = null;
  }
}