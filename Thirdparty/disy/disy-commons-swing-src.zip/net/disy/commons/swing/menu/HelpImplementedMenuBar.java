//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.menu;

import javax.swing.JMenu;
import javax.swing.JMenuBar;

// NOT_PUBLISHED
public class HelpImplementedMenuBar extends JMenuBar {
  private JMenu helpMenu;

  @Override
  public void setHelpMenu(JMenu menu) {
    if (helpMenu != null) {
      remove(helpMenu);
    }
    helpMenu = menu;
    super.add(helpMenu);
  }

  @Override
  public JMenu add(JMenu menu) {
    if (helpMenu != null) {
      return (JMenu) add(menu, getComponentCount() - 1);
    }
    return super.add(menu);
  }

  @Override
  public JMenu getHelpMenu() {
    return helpMenu;
  }

  public void remove(JMenu menu) {
    if (menu == helpMenu) {
      helpMenu = null;
    }
    super.remove(menu);
  }

  @Override
  public void removeAll() {
    super.removeAll();
    helpMenu = null;
  }
}