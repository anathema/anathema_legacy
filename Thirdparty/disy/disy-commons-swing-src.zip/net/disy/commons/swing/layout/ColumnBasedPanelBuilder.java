/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout;

import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;

public class ColumnBasedPanelBuilder implements IColumnContainer {

  private final List<JPanel> allPanels = new ArrayList<JPanel>();
  private JPanel currentPanel;

  public JComponent create() {
    final JPanel container = new JPanel(new GridDialogLayout(Math.max(1, allPanels.size()), true));
    container.setBorder(BorderFactory.createEmptyBorder());
    for (JPanel panel : allPanels) {
      container.add(panel, GridDialogLayoutData.FILL_BOTH);
    }
    return container;
  }

  @Override
  public void add(JComponent component, IGridDialogLayoutData layoutData) {
    if (currentPanel == null) {
      currentPanel = new JPanel(new GridDialogLayout(1, false));
      allPanels.add(currentPanel);
    }
    currentPanel.add(component, layoutData);
  }

  public void breakColumn() {
    currentPanel = null;
  }
}