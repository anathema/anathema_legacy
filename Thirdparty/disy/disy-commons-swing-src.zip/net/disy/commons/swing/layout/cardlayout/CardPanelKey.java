/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout;

import net.disy.commons.core.util.Ensure;

public class CardPanelKey {

  private static int idCounter = 0;

  private static String createNewId() {
    int id;
    synchronized (CardPanelKey.class) {
      id = idCounter++;
    }
    return String.valueOf(id);
  }

  private final String id;

  public CardPanelKey() {
    this(createNewId());
  }

  public CardPanelKey(final String id) {
    Ensure.ensureArgumentNotNull(id);
    this.id = id;
  }

  @Override
  public int hashCode() {
    return id.hashCode();
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof CardPanelKey)) {
      return false;
    }
    final CardPanelKey other = (CardPanelKey) obj;
    return other.id.equals(id);
  }

  public String getId() {
    return id;
  }

  @Override
  public String toString() {
    return "CardPanelKey{" + id + "}"; //$NON-NLS-1$ //$NON-NLS-2$
  }
}