// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 02.01.2006
package net.disy.commons.swing.layout;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;

// NOT_PUBLISHED
public class GridDialogLayoutDataUtilities {

  public static GridDialogLayoutData createHorizontalSpanData(int columnCount, IGridDialogLayoutData prototype) {
    GridDialogLayoutData layoutData = new GridDialogLayoutData(prototype);
    layoutData.setHorizontalSpan(columnCount);
    return layoutData;
  }

  public static GridDialogLayoutData createHorizontalSpanData(int columnCount) {
    return createHorizontalSpanData(columnCount, new GridDialogLayoutData());
  }
  
  public static GridDialogLayoutData createHorizontalFillNoGrab() {
    GridDialogLayoutData horizontalFillNoGrab = new GridDialogLayoutData();
    horizontalFillNoGrab.setHorizontalAlignment(GridAlignment.FILL);
    return horizontalFillNoGrab;
  }

  public static GridDialogLayoutData createFillNoGrab() {
    GridDialogLayoutData fillNoGrab = new GridDialogLayoutData();
    fillNoGrab.setHorizontalAlignment(GridAlignment.FILL);
    fillNoGrab.setVerticalAlignment(GridAlignment.FILL);
    return fillNoGrab;
  }

  public static GridDialogLayoutData createTopData() {
    GridDialogLayoutData topData = new GridDialogLayoutData();
    topData.setVerticalAlignment(GridAlignment.BEGINNING);
    return topData;
  }
}