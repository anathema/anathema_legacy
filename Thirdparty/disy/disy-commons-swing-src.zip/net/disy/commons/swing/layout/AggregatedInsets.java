// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 24.08.2005
package net.disy.commons.swing.layout;

import java.awt.Insets;

// NOT_PUBLISHED
public class AggregatedInsets extends  Insets {

  public AggregatedInsets(Insets first, Insets second) {
    super(first.top + second.top, first.left + second.left, first.bottom + second.bottom, first.right + second.right);
  }
}