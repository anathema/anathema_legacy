/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout;

import static java.text.MessageFormat.format;

import java.awt.CardLayout;
import java.awt.Component;
import java.util.HashSet;
import java.util.Set;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;

public class CardPanel {

  private final Set<CardPanelKey> knownKeys = new HashSet<CardPanelKey>();
  private final CardLayout cardLayout;
  private final JPanel panel;

  public CardPanel() {
    cardLayout = new CardLayout();
    panel = new JPanel(cardLayout);
  }

  public void add(final Component subPanel, final CardPanelKey key) {
    Ensure.ensureArgumentNotNull(subPanel);
    Ensure.ensureArgumentNotNull(key);
    if (knownKeys.contains(key)) {
      throw new IllegalArgumentException("Key '" + key + "' already exists in this card panel."); //$NON-NLS-1$ //$NON-NLS-2$
    }
    knownKeys.add(key);
    panel.add(subPanel, key.getId());
  }

  /**@deprecated (preuss, reupke, 28.05.2010) Use {@link #show(CardPanelKey)} instead.*/
  @Deprecated
  public void setSelectedSubPanel(final CardPanelKey key) {
    show(key);
  }

  public void show(CardPanelKey key) {
    if (!knownKeys.contains(key)) {
      throw new IllegalArgumentException(format("No sub panel registered for the key ''{0}''", key)); //$NON-NLS-1$
    }
    cardLayout.show(panel, key.getId());
  }

  public JComponent getContent() {
    return panel;
  }

  public void add(Component component, String key) {
    add(component, new CardPanelKey(key));
  }

  public void show(String key) {
    show(new CardPanelKey(key));
  }
}