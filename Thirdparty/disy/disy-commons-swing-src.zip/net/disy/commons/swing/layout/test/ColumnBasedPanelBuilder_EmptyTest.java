/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.ColumnBasedPanelBuilder;

import org.junit.Before;
import org.junit.Test;

public class ColumnBasedPanelBuilder_EmptyTest {

  private ColumnBasedPanelBuilder builder;
  private JComponent component;

  @Before
  public void createBuilder() throws Exception {
    this.builder = new ColumnBasedPanelBuilder();
    this.component = builder.create();
  }

  @Test
  public void createsPanel() throws Exception {
    assertThat(component, instanceOf(JPanel.class));
  }

  @Test
  public void createdComponentIsEmpty() throws Exception {
    assertThat(component.getComponentCount(), is(0));
  }
}