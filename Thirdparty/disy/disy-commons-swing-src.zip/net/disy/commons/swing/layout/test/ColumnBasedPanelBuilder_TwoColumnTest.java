/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.ColumnBasedPanelBuilder;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import org.junit.Before;
import org.junit.Test;

public class ColumnBasedPanelBuilder_TwoColumnTest {

  private JLabel firstColumnLabel;
  private JComponent content;
  private JLabel secondColumnLabel;

  @Before
  public void buildOneColumnContent() throws Exception {
    ColumnBasedPanelBuilder builder = new ColumnBasedPanelBuilder();
    firstColumnLabel = new JLabel("Hallo"); //$NON-NLS-1$
    secondColumnLabel = new JLabel("Du"); //$NON-NLS-1$
    builder.add(firstColumnLabel, GridDialogLayoutData.FILL_BOTH);
    builder.breakColumn();
    builder.add(secondColumnLabel, GridDialogLayoutData.FILL_BOTH);
    content = builder.create();
  }

  @Test
  public void contentHasTwoChild() throws Exception {
    assertThat(content.getComponentCount(), is(2));
  }

  @Test
  public void firstColumnLabelIsContainedInFirstPanelChild() throws Exception {
    JPanel column = (JPanel) content.getComponent(0);
    assertThat(column.getComponentCount(), is(1));
    assertThat(column.getComponent(0), sameInstance((Component) firstColumnLabel));
  }

  @Test
  public void secondColumnLabelIsContainedInSecondPanelChild() throws Exception {
    JPanel column = (JPanel) content.getComponent(1);
    assertThat(column.getComponentCount(), is(1));
    assertThat(column.getComponent(0), sameInstance((Component) secondColumnLabel));
  }
}