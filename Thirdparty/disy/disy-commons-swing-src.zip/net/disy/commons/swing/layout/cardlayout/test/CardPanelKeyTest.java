/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout.test;

import junit.framework.TestCase;

import net.disy.commons.swing.layout.cardlayout.CardPanelKey;

public class CardPanelKeyTest extends TestCase {

  public void testIllegalCreate() {
    try {
      new CardPanelKey(null);
      fail();
    }
    catch (final IllegalArgumentException expected) {
      //expected
    }
  }

  public void testCreateDefault() {
    final CardPanelKey key = new CardPanelKey();
    assertNotNull(key.getId());
  }

  public void testCreateByString() {
    assertEquals("id42", new CardPanelKey("id42").getId()); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public void testDefaultCreatedEquals() {
    final CardPanelKey key = new CardPanelKey();
    assertEquals(key, key);
    assertFalse(new CardPanelKey().equals(key));
  }

  public void testByIdCreatedEquals() {
    assertEquals(new CardPanelKey("id42"), new CardPanelKey("id42")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals(new CardPanelKey("1"), new CardPanelKey("1")); //$NON-NLS-1$ //$NON-NLS-2$
    assertFalse(new CardPanelKey("1").equals(new CardPanelKey("2"))); //$NON-NLS-1$ //$NON-NLS-2$
  }
}