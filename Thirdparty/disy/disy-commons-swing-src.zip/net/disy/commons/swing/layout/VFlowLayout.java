/*
 * @(#)VFlowLayout.java	1.27 98/07/01
 * (adapted from FlowLayout.java  1.39 00/02/02)
 *
 * Copyright 1995-2000 Sun Microsystems, Inc. All Rights Reserved.
 *
 * This software is the proprietary information of Sun Microsystems, Inc.
 * Use is subject to license terms.
 *
 */
package net.disy.commons.swing.layout;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager;

/**
 * A vertical flow layout arranges components in a top-to-bottom flow, much
 * like lines of text in a paragraph. Flow layouts are typically used
 * to arrange buttons in a panel. It will arrange
 * buttons top to bottom until no more buttons fit on the same column.
 * Each line is centered.
 * <p>
 * For example, the following picture shows an applet using the flow
 * layout manager (its default layout manager) to position three buttons:
 * <p>
 * A flow layout lets each component assume its natural (preferred) size.
 *
 * @version   1.0, 06/2001
 * @author   Arthur van Hoff
 * @author   Sami Shaio
 * @author Markus Gebhard
 * @since       JDK1.0
 */
public class VFlowLayout implements LayoutManager, java.io.Serializable {

  /**
   * This value indicates that each row of components
   * should be left-justified.
   */
  public static final int TOP = 0;

  /**
   * This value indicates that each row of components
   * should be centered.
   */
  public static final int CENTER = 1;

  /**
   * This value indicates that each row of components
   * should be right-justified.
   */
  public static final int BOTTOM = 2;

  /**
   * This value indicates that each row of components
   * should be justified to the leading edge of the container's
   * orientation, e.g. to the left in left-to-right orientations.
   *
   * @see     java.awt.Component#getComponentOrientation
   * @see     java.awt.ComponentOrientation
   * @since   1.2
   * Package-private pending API change approval
   */
  public static final int LEADING = 3;

  /**
   * This value indicates that each row of components
   * should be justified to the leading edge of the container's
   * orientation, e.g. to the right in left-to-right orientations.
   *
   * @see     java.awt.Component#getComponentOrientation
   * @see     java.awt.ComponentOrientation
   * @since   1.2
   * Package-private pending API change approval
   */
  public static final int TRAILING = 4;

  /**
   * <code>newAlign</code> is the property that determines
   * how each row distributes empty space for the Java 2 platform, v1.2 and greater.
   * It can be one of the following three values :
   * <code>TOP</code>
   * <code>BOTTOM</code>
   * <code>CENTER</code>
   *
   * @serial
   * @since 1.2
   * @see #getAlignment()
   * @see #setAlignment(int)
   */
  private int align;
  /**
   * The flow layout manager allows a seperation of
   * components with gaps.  The horizontal gap will
   * specify the space between components.
   *
   * @serial
   * @see #getHgap()
   * @see #setHgap(int)
   */
  private int hgap;
  /**
   * The flow layout manager allows a seperation of
   * components with gaps.  The vertical gap will
   * specify the space between rows.
   *
   * @serial
   * @see #getVgap()
   * @see #setVgap(int)
   */
  private int vgap;

  /**
   * Constructs a new Flow Layout with a centered alignment and a
   * default 5-unit horizontal and vertical gap.
   */
  public VFlowLayout() {
    this(CENTER, 5, 5);
  }

  /**
   * Constructs a new Flow Layout with the specified alignment and a
   * default 5-unit horizontal and vertical gap.
   * The value of the alignment argument must be one of
   * <code>VFlowLayout.TOP</code>, <code>VFlowLayout.BOTTOM</code>,
   * or <code>VFlowLayout.CENTER</code>.
   * @param align the alignment value
   */
  public VFlowLayout(int align) {
    this(align, 5, 5);
  }

  /**
   * Creates a new flow layout manager with the indicated alignment
   * and the indicated horizontal and vertical gaps.
   * <p>
   * The value of the alignment argument must be one of
   * <code>VFlowLayout.TOP</code>, <code>VFlowLayout.BOTTOM</code>,
   * or <code>VFlowLayout.CENTER</code>.
   * @param      align   the alignment value.
   * @param      hgap    the horizontal gap between components.
   * @param      vgap    the vertical gap between components.
   */
  public VFlowLayout(int align, int hgap, int vgap) {
    this.hgap = hgap;
    this.vgap = vgap;
    setAlignment(align);
  }

  public VFlowLayout(int hgap, int vgap) {
    this(CENTER, hgap, vgap);
  }

  /**
   * Gets the alignment for this layout.
   * Possible values are <code>VFlowLayout.TOP</code>,
   * <code>VVFlowLayout.BOTTOM</code>, or <code>VFlowLayout.CENTER</code>.
   * @return     the alignment value for this layout.
   * @see        VFlowLayout#setAlignment
   * @since      JDK1.1
   */
  public int getAlignment() {
    return align;
  }

  /**
   * Sets the alignment for this layout.
   * Possible values are <code>VFlowLayout.TOP</code>,
   * <code>VFlowLayout.BOTTOM</code>, and <code>VFlowLayout.CENTER</code>.
   * @param      align the alignment value.
   * @see        #getAlignment()
   * @since      JDK1.1
   */
  public void setAlignment(int align) {
    this.align = align;
  }

  /**
   * Gets the horizontal gap between components.
   * @return     the horizontal gap between components.
   * @see        VFlowLayout#setHgap
   * @since      JDK1.1
   */
  public int getHgap() {
    return hgap;
  }

  /**
   * Sets the horizontal gap between components.
   * @param hgap the horizontal gap between components
   * @see        VFlowLayout#getHgap
   * @since      JDK1.1
   */
  public void setHgap(int hgap) {
    this.hgap = hgap;
  }

  /**
   * Gets the vertical gap between components.
   * @return     the vertical gap between components.
   * @see        VFlowLayout#setVgap
   * @since      JDK1.1
   */
  public int getVgap() {
    return vgap;
  }

  /**
   * Sets the vertical gap between components.
   * @param vgap the vertical gap between components
   * @see        VFlowLayout#getVgap
   * @since      JDK1.1
   */
  public void setVgap(int vgap) {
    this.vgap = vgap;
  }

  /**
   * Adds the specified component to the layout. Not used by this class.
   * @param name the name of the component
   * @param comp the component to be added
   */
  public void addLayoutComponent(String name, Component comp) {
    // nothing to do
  }

  /**
   * Removes the specified component from the layout. Not used by
   * this class.
   * @param comp the component to remove
   * @see       java.awt.Container#removeAll
   */
  public void removeLayoutComponent(Component comp) {
    // nothing to do
  }

  /**
   * Returns the preferred dimensions for this layout given the components
   * in the specified target container.
   * @param target the component which needs to be laid out
   * @return    the preferred dimensions to lay out the
   *                    subcomponents of the specified container.
   * @see Container
   * @see #minimumLayoutSize
   * @see       java.awt.Container#getPreferredSize
   */
  public Dimension preferredLayoutSize(Container target) {
    synchronized (target.getTreeLock()) {
      Dimension dim = new Dimension(0, 0);
      int nmembers = target.getComponentCount();
      boolean firstVisibleComponent = true;

      for (int i = 0; i < nmembers; i++) {
        Component m = target.getComponent(i);
        if (m.isVisible()) {
          Dimension d = m.getPreferredSize();
          dim.width = Math.max(dim.width, d.width);
          if (firstVisibleComponent) {
            firstVisibleComponent = false;
          } else {
            dim.height += vgap;
          }
          dim.height += d.height;
        }
      }
      Insets insets = target.getInsets();
      dim.width += insets.left + insets.right + hgap * 2;
      dim.height += insets.top + insets.bottom + vgap * 2;
      return dim;
    }
  }

  /**
   * Returns the minimum dimensions needed to layout the components
   * contained in the specified target container.
   * @param target the component which needs to be laid out
   * @return    the minimum dimensions to lay out the
   *                    subcomponents of the specified container.
   * @see #preferredLayoutSize
   * @see       java.awt.Container
   * @see       java.awt.Container#doLayout
   */
  public Dimension minimumLayoutSize(Container target) {
    synchronized (target.getTreeLock()) {
      Dimension dim = new Dimension(0, 0);
      int nmembers = target.getComponentCount();

      for (int i = 0; i < nmembers; i++) {
        Component m = target.getComponent(i);
        if (m.isVisible()) {
          Dimension d = m.getMinimumSize();
          dim.width = Math.max(dim.width, d.width);
          if (i > 0) {
            dim.height += vgap;
          }
          dim.height += d.height;
        }
      }
      Insets insets = target.getInsets();
      dim.width += insets.left + insets.right + hgap * 2;
      dim.height += insets.top + insets.bottom + vgap * 2;
      return dim;
    }
  }

  /**
   * Centers the elements in the specified row, if there is any slack.
   * @param target the component which needs to be moved
   * @param x the x coordinate
   * @param y the y coordinate
   * @param width the width dimensions
   * @param height the height dimensions
   * @param rowStart the beginning of the row
   * @param rowEnd the the ending of the row
   */
  private void moveComponents(
    Container target,
    int x,
    int y,
    int width,
    int height,
    int rowStart,
    int rowEnd /*, boolean ltr*/
  ) {
    synchronized (target.getTreeLock()) {
      switch (align) {
        case TOP :
          break;
        case CENTER :
          y += height / 2;
          break;
        case BOTTOM :
          y += height;
          break;
        case LEADING :
          break;
        case TRAILING :
          y += height;
          break;
      }
      for (int i = rowStart; i < rowEnd; i++) {
        Component m = target.getComponent(i);
        if (m.isVisible()) {
          Dimension d = m.getSize();
          //          if (ltr) {
          m.setLocation(x + (width - d.width) / 2, y /* + (height - d.height) / 2*/
          );
          //          } else {
          //            m.setLocation(target.getSize().width - x - d.width, y + (height - d.height) / 2);
          //          }
          y += d.height + vgap;
        }
      }
    }
  }

  /**
   * Lays out the container. This method lets each component take
   * its preferred size by reshaping the components in the
   * target container in order to satisfy the constraints of
   * this <code>VFlowLayout</code> object.
   * @param target the specified component being laid out.
   * @see Container
   * @see       java.awt.Container#doLayout
   */
  public void layoutContainer(Container target) {
    synchronized (target.getTreeLock()) {
      Insets insets = target.getInsets();
      int maxheight = target.getSize().height - (insets.top + insets.bottom + vgap * 2);
      int nmembers = target.getComponentCount();
      int x = insets.left + hgap, y = 0;
      int rowW = 0, start = 0;

      for (int i = 0; i < nmembers; i++) {
        Component m = target.getComponent(i);
        if (m.isVisible()) {
          Dimension d = m.getPreferredSize();
          m.setSize(d.width, d.height);

          if ((y == 0) || ((y + d.height) <= maxheight)) {
            if (y > 0) {
              y += vgap;
            }
            y += d.height;
            rowW = Math.max(rowW, d.width);
          } else {
            //Neue Spalte beginnen
            moveComponents(target, x, insets.top + vgap, rowW, maxheight - y, start, i);
            y = d.height;
            x += hgap + rowW;
            rowW = d.width;
            start = i;
          }
        }
      }
      moveComponents(target, x, insets.top + vgap, rowW, maxheight - y, start, nmembers);
    }
  }

//  //
//  // the internal serial version which says which version was written
//  // - 0 (default) for versions before the Java 2 platform, v1.2
//  // - 1 for version >= Java 2 platform v1.2, which includes "newAlign" field
//  //
//  private static final int currentSerialVersion = 1;
//  /**
//   * This represent the <code>currentSerialVersion</code>
//   * which is bein used.  It will be one of two values :
//   * <code>0</code> versions before Java 2 platform v1.2..
//   * <code>1</code> versions after  Java 2 platform v1.2..
//   *
//   * @serial
//   * @since 1.2
//   */
//  private int serialVersionOnStream = currentSerialVersion;
//
//  /**
//   * Read this object out of a serialization stream, handling
//   * objects written by older versions of the class that didn't contain all
//   * of the fields we use now..
//   */
//  private void readObject(ObjectInputStream stream) throws IOException, ClassNotFoundException {
//    stream.defaultReadObject();
//
//    if (serialVersionOnStream < 1) {
//      // "newAlign" field wasn't present, so use the old "align" field.
//      setAlignment(this.align);
//    }
//    serialVersionOnStream = currentSerialVersion;
//  }

  /**
   * Returns a string representation of this <code>VFlowLayout</code>
   * object and its values.
   * @return     a string representation of this layout.
   */
  public String toString() {
    String str = ""; //$NON-NLS-1$
    switch (align) {
      case TOP :
        str = ",align=top"; //$NON-NLS-1$
        break;
      case CENTER :
        str = ",align=center"; //$NON-NLS-1$
        break;
      case BOTTOM :
        str = ",align=bottom"; //$NON-NLS-1$
        break;
      case LEADING :
        str = ",align=leading"; //$NON-NLS-1$
        break;
      case TRAILING :
        str = ",align=trailing"; //$NON-NLS-1$
        break;
    }
    return getClass().getName() + "[hgap=" + hgap + ",vgap=" + vgap + str + "]"; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}