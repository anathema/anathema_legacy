/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.cardlayout.CardPanel;
import net.disy.commons.swing.layout.cardlayout.CardPanelKey;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class CardPanelDemo extends SwingDemoCase {

  public void demo() {
    final CardPanel cardPanel = new CardPanel();
    final CardPanelKey key1 = new CardPanelKey();
    final CardPanelKey key2 = new CardPanelKey();
    final CardPanelKey key3 = new CardPanelKey();
    cardPanel.add(new JLabel("Content 1"), key1); //$NON-NLS-1$
    cardPanel.add(new JLabel("Content 2"), key2); //$NON-NLS-1$
    cardPanel.add(new JLabel("Content 3"), key3); //$NON-NLS-1$

    final JComboBox comboBox = new JComboBox(new Object[]{ key1, key2, key3 });
    comboBox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        cardPanel.show((CardPanelKey) comboBox.getSelectedItem());
      }
    });

    final JPanel topPanel = new JPanel();
    topPanel.add(new JLabel("Selected Page:")); //$NON-NLS-1$
    topPanel.add(comboBox);

    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(topPanel, BorderLayout.NORTH);
    panel.add(cardPanel.getContent(), BorderLayout.SOUTH);
    show(panel);
  }
}