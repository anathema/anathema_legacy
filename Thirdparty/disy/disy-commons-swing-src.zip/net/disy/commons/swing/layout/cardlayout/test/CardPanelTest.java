/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout.test;

import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.cardlayout.CardPanel;
import net.disy.commons.swing.layout.cardlayout.CardPanelKey;

import org.junit.Test;

@SuppressWarnings("nls")
public class CardPanelTest {
  private final CardPanel cardPanel = new CardPanel();

  @Test
  public void testCreate() {
    final JPanel content = (JPanel) cardPanel.getContent();
    assertEquals(0, content.getComponentCount());
  }

  @Test(expected = IllegalArgumentException.class)
  public void expectsKeyForAddition() {
    cardPanel.add(new JLabel(), (CardPanelKey) null);
  }

  @Test(expected = IllegalArgumentException.class)
  public void expectsComponentForAddition() {
    cardPanel.add(null, new CardPanelKey());
  }

  @Test
  public void testAdd() {
    final JLabel label = new JLabel();
    cardPanel.add(label, new CardPanelKey());
    assertHasComponent(label);
  }

  @Test
  public void testMultipleAdd() {
    final JLabel label1 = new JLabel();
    cardPanel.add(label1, new CardPanelKey());
    final JLabel label2 = new JLabel();
    cardPanel.add(label2, new CardPanelKey());
    final JPanel content = (JPanel) cardPanel.getContent();
    assertEquals(2, content.getComponentCount());
    assertSame(label1, content.getComponent(0));
    assertSame(label2, content.getComponent(1));
  }

  @Test
  public void testSetSelectedPanel() {
    final JLabel label1 = new JLabel();
    final CardPanelKey key1 = new CardPanelKey();
    cardPanel.add(label1, key1);
    final JLabel label2 = new JLabel();
    final CardPanelKey key2 = new CardPanelKey();
    cardPanel.add(label2, key2);
    cardPanel.show(key1);
    assertTrue(label1.isVisible());
    assertFalse(label2.isVisible());
    cardPanel.show(key2);
    assertFalse(label1.isVisible());
    assertTrue(label2.isVisible());
  }

  @Test
  public void addsComponentWithStringKey() throws Exception {
    JLabel label = new JLabel();
    cardPanel.add(label, "Schluessel");
    assertHasComponent(label);
  }

  @Test
  public void showsComponentWithStringKey() throws Exception {
    JLabel label = new JLabel();
    cardPanel.add(new JLabel(), "Schluessel");
    cardPanel.add(label, "Schuessel");
    cardPanel.show("Schuessel");
    assertThat(label.isVisible(), is(true));
  }

  private void assertHasComponent(JComponent component) {
    final JPanel content = (JPanel) cardPanel.getContent();
    assertEquals(1, content.getComponentCount());
    assertSame(component, content.getComponent(0));
  }
}