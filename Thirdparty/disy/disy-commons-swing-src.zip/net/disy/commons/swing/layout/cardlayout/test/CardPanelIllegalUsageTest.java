/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.cardlayout.test;

import javax.swing.JLabel;

import net.disy.commons.swing.layout.cardlayout.CardPanel;
import net.disy.commons.swing.layout.cardlayout.CardPanelKey;

import org.junit.Test;

public class CardPanelIllegalUsageTest {

  @Test(expected = IllegalArgumentException.class)
  public void sameKeyIsBeingUsedTwice() throws Exception {
    final CardPanel panel = new CardPanel();
    final CardPanelKey key = new CardPanelKey();
    panel.add(new JLabel(), key);
    panel.add(new JLabel(), key);
  }

  @Test(expected = IllegalArgumentException.class)
  public void equalKeyIsBeingUsedTwice() throws Exception {
    final CardPanel panel = new CardPanel();
    final CardPanelKey key1 = new CardPanelKey("id"); //$NON-NLS-1$
    final CardPanelKey key2 = new CardPanelKey("id"); //$NON-NLS-1$
    panel.add(new JLabel(), key1);
    panel.add(new JLabel(), key2);
  }

  @Test(expected = IllegalArgumentException.class)
  public void selectingUnknownKey() throws Exception {
    final CardPanel panel = new CardPanel();
    panel.add(new JLabel(), new CardPanelKey());
    panel.show(new CardPanelKey());
  }
}