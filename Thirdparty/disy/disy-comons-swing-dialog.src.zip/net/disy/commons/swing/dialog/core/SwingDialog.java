//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.Container;
import java.awt.Window;
import java.awt.event.WindowListener;

import javax.swing.JDialog;
import javax.swing.JRootPane;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class SwingDialog implements ISwingFrameOrDialog {

  private final JDialog dialog;

  public SwingDialog(JDialog dialog) {
    Ensure.ensureArgumentNotNull(dialog);
    this.dialog = dialog;
  }

  public void setTitle(String title) {
    dialog.setTitle(title);
  }

  public JRootPane getRootPane() {
    return dialog.getRootPane();
  }

  public void pack() {
    dialog.pack();
  }

  public void setModal(boolean modal) {
    dialog.setModal(modal);
  }

  public Container getContentPane() {
    return dialog.getContentPane();
  }

  public void setDefaultCloseOperation(int closeOperation) {
    dialog.setDefaultCloseOperation(closeOperation);
  }

  public void addWindowListener(WindowListener windowListener) {
    dialog.addWindowListener(windowListener);
  }

  public void dispose() {
    dialog.dispose();
  }

  public void validate() {
    dialog.validate();
  }

  public void repaint() {
    dialog.repaint();
  }

  public Window getWindow() {
    return dialog;
  }
  
  public void setResizable(boolean resizable) {
    dialog.setResizable(resizable);
  }

  public void show() {
    dialog.show();
  }

  public void setVisible(boolean visible) {
    dialog.setVisible(visible);
  }

  public boolean isVisible() {
    return dialog.isVisible();
  }
}