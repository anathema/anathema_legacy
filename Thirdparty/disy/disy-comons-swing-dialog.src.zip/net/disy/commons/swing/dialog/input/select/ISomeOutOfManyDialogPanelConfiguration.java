// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.swing.dialog.input.ISelectionDialogPanelConfiguration;
import net.disy.commons.swing.list.ListSelectionMode;

//NOT_PUBLISHED
public interface ISomeOutOfManyDialogPanelConfiguration extends ISelectionDialogPanelConfiguration {
  public ListSelectionMode getListSelectionMode();

}
