//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import javax.swing.JComponent;

// NOT_PUBLISHED
public abstract class AbstractFoldOutPage implements IFoldOutPage {
  private JComponent content; 
  
  //@Overrides
  public JComponent getContent() {
    if (content==null) {
      content = createContent();
    }
    return content;
  }

  protected abstract JComponent createContent();

}