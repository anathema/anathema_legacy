//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog.buttons;

import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.dialog.BasicDialogResources;

// NOT_PUBLISHED
public class AbstractDialogButtonConfiguration implements IDialogButtonConfiguration {

  public boolean isOkayButtonAvailable() {
    return true;
  }

  public boolean isCancelButtonAvailable() {
    return true;
  }

  public String getOkayButtonText() {
    return BasicDialogResources.OK_TEXT_SMART;
  }

  public String getCancelButtonText() {
    return BasicDialogResources.CANCEL_TEXT_SMART;
  }

  public IActionConfiguration getOkActionConfiguration() {
    return isOkayButtonAvailable() ? new ActionConfiguration(getOkayButtonText()) : null;
  }

  public IActionConfiguration getCancelActionConfiguration() {
    return isCancelButtonAvailable() ? new ActionConfiguration(getCancelButtonText()) : null;
  }
}