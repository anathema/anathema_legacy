// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.combo.demo;

import java.awt.Color;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.ISelectionDialogPanelConfiguration;
import net.disy.commons.swing.dialog.input.combo.ComboSelectionDialogPanel;
import net.disy.commons.swing.dialog.input.select.demo.ColorUi;
import net.disy.commons.swing.ui.IObjectUi;

//NOT_PUBLISHED
public class ComboSelectionDialogPanelDemo extends DialogDemoCase {
  public void demo() throws Exception {

    ObjectModel<Color> model = new ObjectModel<Color>();
    ISelectionDialogPanelConfiguration<Color> configuration = new ISelectionDialogPanelConfiguration<Color>() {
      public String getNoItemSelectedErrorMessageText() {
        return "Es wurde keine Farbe ausgew�hlt. Bitte w�hlen Sie eine Farbe aus."; //$NON-NLS-1$
      }

      public IObjectUi getObjectUi() {
        return new ColorUi();
      }

      public Color[] getItems() {
        return new Color[]{
            Color.RED,
            Color.ORANGE,
            Color.YELLOW,
            Color.GREEN,
            Color.BLUE,
            Color.PINK,
            Color.BLACK,
            Color.WHITE };
      }

      public String getDescription() {
        return "Farbe:"; //$NON-NLS-1$
      }

    };
    ComboSelectionDialogPanel panel = new ComboSelectionDialogPanel<Color>(model, configuration);
    show(panel);
  }
}
