// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

//NOT_PUBLISHED
public abstract class AbstractLabeledSmartDialogPanel extends AbstractSmartDialogPanel {

  private final IMessageProducingValidator validator;
  private final String label;

  protected AbstractLabeledSmartDialogPanel(String label, IMessageProducingValidator validator) {
    Ensure.ensureArgumentNotNull(label);
    Ensure.ensureArgumentNotNull(validator);
    this.label = label;
    this.validator = validator;
  }

  public final int getColumnCount() {
    return 1 + getMainComponentColumnCount();
  }

  public final void fillInto(JPanel panel, int columnCount) {
    addLabelComponent(panel);
    fillMainComponentInto(panel, columnCount - 1);
  }

  private void addLabelComponent(JPanel panel) {
    panel.add(new JLabel(label), GridDialogLayoutData.RIGHT);
  }

  public IBasicMessage createOptionalCurrentMessage() {
    return validator.validate();
  }

  protected abstract int getMainComponentColumnCount();

  protected abstract void fillMainComponentInto(JPanel panel, int columnCount);
}