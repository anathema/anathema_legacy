// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import net.disy.commons.core.util.Ensure;

//NOT_PUBLISHED
public class SinglePageWizardConfiguration extends AbstractWizardConfiguration {
  private IWizardPage wizardPage;
  private final IWizardPageFactory pageFactory;

  public SinglePageWizardConfiguration(IWizardPageFactory pageFactory) {
    Ensure.ensureArgumentNotNull(pageFactory);
    this.pageFactory = pageFactory;
  }

  public void addPages() {
    wizardPage = pageFactory.createPage(this);
  }

  public IWizardPage getStartingPage() {
    return wizardPage;
  }

  public IWizardPage getNextPage(IWizardPage page) {
    return null;
  }

  public IWizardPage getPreviousPage(IWizardPage page) {
    return null;
  }

  public boolean isHelpAvailable() {
    return false;
  }
}
