//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

// NOT_PUBLISHED
public class SelectSomeOutOfManyDialogPage extends SmartDialogPage {

  private final ISomeOutOfManyDialogConfiguration configuration;
  private SelectSomeOutOfManyDialogPanel selectionPanel;

  public SelectSomeOutOfManyDialogPage(ISomeOutOfManyDialogConfiguration configuration) {
    super(new BasicMessage(configuration.getDefaultMessageText()));
    this.configuration = configuration;
    Object[] items = configuration.getItems();
    ObjectSelectionModel selectionModel = new ObjectSelectionModel(items);
    if (items.length > 0) {
      selectionModel.setValues(new Object[]{ items[0] });
    }
    selectionPanel = new SelectSomeOutOfManyDialogPanel(selectionModel, configuration);
  }

  public Object[] getSelectedItems() {
    return selectionPanel.getSelectedItems();
  }

  public String getTitle() {
    return configuration.getTitle();
  }

  protected ISmartDialogPanel[] createPanels() {
    List panelList = new ArrayList();
    panelList.add(selectionPanel);
    ISmartDialogPanel[] additionalPanels = configuration.createAdditionalPanels(selectionPanel
        .getSelectedItemModel());
    if (additionalPanels != null) {
      panelList.addAll(Arrays.asList(additionalPanels));
    }
    return (ISmartDialogPanel[]) panelList.toArray(new ISmartDialogPanel[panelList.size()]);
  }

  public void requestFocus() {
    selectionPanel.requestFocus();
  }
}