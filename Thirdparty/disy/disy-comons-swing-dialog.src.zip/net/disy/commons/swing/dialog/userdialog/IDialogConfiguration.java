package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;

import javax.swing.JComponent;

import net.disy.commons.swing.dialog.core.IGenericDialogConfiguration;

/**
 * @author gebhard
 */
public interface IDialogConfiguration extends IGenericDialogConfiguration {

  public IDialogPage getDialogPage();

  public void setUserDialogContainer(IUserDialogContainer userDialog);

  public boolean isModal();

  public boolean performOk(Component parentComponent);

  public JComponent[] createAdditionalButtons();

}