// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.core.IPage;

/**
 * Interface for a wizard page.
 * 
 *  The class {@link AbstractWizardPage} provides an abstract implementation of this interface. However,
 *  clients are also free to implement this interface if WizardPage does not suit their needs.
 */
public interface IWizardPage extends IPage {

  /** Returns whether the next page could be displayed.
   * 
   * @return <code>true</code> if the next page could be displayed, and <code>false</code>
   * otherwise*/
  public boolean canFlipToNextPage();

  /** Returns the wizard page that would to be shown if the user was to press the Next button.*/
  public IWizardPage getNextPage();

  /** Returns the wizard page that would to be shown if the user was to press the Back button.*/
  public IWizardPage getPreviousPage();

  /** Returns whether this page is complete or not.
   * 
   * This information is typically used by the wizard to decide when it is okay to finish.
   * @return <code>true</code> if this page is complete, and <code>false</code> otherwise */
  public boolean canFinish();

  /** Sets the wizard that hosts this wizard page.*/
  public void setWizard(IWizardConfiguration newWizard);

  /** Returns the wizard that hosts this wizard page.*/
  public IWizardConfiguration getWizard();

  /**
   * Sets the current message for this dialog page. May be <code>null</code> to indicate no
   * message. An error message should describe some error state, as opposed to an information
   * message which may simply provide instruction or information to the user.
   * @param message the message
   */
  public void setMessage(IBasicMessage message);

  /** Initializes all widgets from the data attached to this wizard page. This method will be called
   * from the wizard container after creating the content.
   * @deprecated As of 10.12.2004 (gebhard)
   * @see #getContent() */
  public void initializeFromData();

  /** Called from the wizard container when the page has been activated. */
  public void pageActivated();

  /** Called from the wizard container when the page has been deactivated. */
  public void pageDeactivated();

  public void dispose();
}