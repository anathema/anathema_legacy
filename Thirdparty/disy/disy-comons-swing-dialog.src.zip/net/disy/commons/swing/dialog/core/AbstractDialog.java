package net.disy.commons.swing.dialog.core;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.StringModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.core.message.DialogMessageModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.util.GuiUtilities;
import net.disy.commons.swing.widgets.HorizontalLine;

/**
 * @author gebhard
 */
public abstract class AbstractDialog {
  private static final String INITIAL_DIALOG_TITLE = "!Dialog.title!"; //$NON-NLS-1$

  private final DialogMessageModel messageModel= new DialogMessageModel();
  private final StringModel descriptionModel =new StringModel();
  
  private ISwingFrameOrDialog dialog;
  private JPanel contentPanel;
  private JComponent content;
  private DialogHeaderPanel headerPanel;
  
  private IGenericDialogConfiguration genericDialog;
  private Component parent;
  private boolean canceled = false;

  public AbstractDialog(Component parent, IGenericDialogConfiguration genericDialog) {
    Ensure.ensureArgumentNotNull(genericDialog);
    this.parent = parent;
    this.genericDialog = genericDialog;
    dialog = createFrameOrDialog(parent);
    dialog.setModal(true);
    dialog.getContentPane().setLayout(new BorderLayout());
    dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    dialog.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        performCancel();
      }
    });
  }

  private static ISwingFrameOrDialog createFrameOrDialog(Component parent) {
    Window window = GuiUtilities.getWindowForComponent(parent);
    if (window == null || !window.isVisible()) {
      final JFrame frame = new JFrame(INITIAL_DIALOG_TITLE);
      if (window instanceof Frame) {
        Frame originalFrame = (Frame) window;
        frame.setIconImage(originalFrame.getIconImage());
      }
      return new SwingFrame(frame);
    }
    return new SwingDialog(GuiUtilities.createDialog(parent, INITIAL_DIALOG_TITLE));
  }

  public Component getParent() {
    return parent;
  }

  protected final void performCancel() {
    if (cancelPressed()) {
      canceled = true;
      closeDialog();
      genericDialog.performAfterDispose(true);
    }
  }

  /** @deprecated As of 28.07.2005 (gebhard), replaced by {@link #isCanceled()}*/
  @Deprecated
  public final boolean isCancelled() {
    return isCanceled();
  }

  public final boolean isCanceled() {
    return canceled;
  }

  protected IGenericDialogConfiguration getGenericDialog() {
    return genericDialog;
  }

  protected void initialize() {
    if (genericDialog.isHeaderPanelVisible()) {
      headerPanel = new DialogHeaderPanel(messageModel, descriptionModel);
      dialog.getContentPane().add(headerPanel.getContent(), BorderLayout.NORTH);
    }
    dialog.getContentPane().add(createContentPanel(), BorderLayout.CENTER);
    dialog.getContentPane().add(createButtonBar(), BorderLayout.SOUTH);
  }

  private Component createContentPanel() {
    contentPanel = new JPanel(new GridLayout(0, 1));
    contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 8, 10, 8));

    JPanel p = new JPanel(new GridDialogLayout(1, false));
    GridDialogLayoutData data = new GridDialogLayoutData(GridDialogLayoutData.FILL_BOTH);
    data.setWidthHint(IDialogConstants.MINIMUM_CONTENT_SIZE.width);
    data.setHeightHint(IDialogConstants.MINIMUM_CONTENT_SIZE.height);
    p.add(contentPanel, data);
    p.add(new HorizontalLine(), GridDialogLayoutData.FILL_HORIZONTAL);
    return p;
  }

  protected abstract JComponent createButtonBar();

  protected abstract boolean cancelPressed();

  protected void closeDialog() {
    dialog.dispose();
  }

  //  private boolean dialogPacked=false;

  /**
   * Computes the correct dialog size for the current page and resizes itself if nessessary. Also
   * causes the container to refresh its layout.
   */
  public void updateSize() {
    if (getContent() == null) {
      dialog.pack();
      return;
    }
    Dimension preferredSize = contentPanel.getPreferredSize();
    Dimension actualSize = contentPanel.getSize();
    if (preferredSize.width > actualSize.width || preferredSize.height > actualSize.height) {
      dialog.pack();
    }
  }

  protected void setContent(JComponent content) {
    this.content = content;
    contentPanel.removeAll();
    contentPanel.add(content);
    contentPanel.revalidate();
  }

  protected JComponent getContent() {
    return content;
  }

  protected final void setMessage(IBasicMessage message) {
    messageModel.setMessage(message);
    dialog.validate();
    dialog.repaint();
    updateSize();
  }

  protected final void setDescription(String description) {
    descriptionModel.setValue(description);
  }

  protected void setTitle(String title) {
    dialog.setTitle(title);
  }

  protected void setDefaultButton(JButton button) {
    dialog.getRootPane().setDefaultButton(button);
  }

  public final ISwingFrameOrDialog getDialog() {
    return dialog;
  }
}