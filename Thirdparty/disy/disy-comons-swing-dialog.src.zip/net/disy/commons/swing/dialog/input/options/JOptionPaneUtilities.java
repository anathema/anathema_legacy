// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 07.07.2004
package net.disy.commons.swing.dialog.input.options;

import java.awt.Component;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.BasicDialogResources;
import net.disy.commons.swing.dialog.message.MessageUserDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public class JOptionPaneUtilities {

  private final static IDialogButtonConfiguration YES_CANCEL_BUTTON_CONFIGURATION = DialogButtonConfigurationFactory
      .createBothWithOkayText(BasicDialogResources.YES_TEXT);

  private final static IDialogButtonConfiguration YES_NO_BUTTON_CONFIGURATION = DialogButtonConfigurationFactory
      .createBoth(BasicDialogResources.YES_TEXT, BasicDialogResources.NO_TEXT);

  private JOptionPaneUtilities() {
    // nothing to do
  }

  public static boolean confirmUserOperation(Component parent, String message, String title) {
    return showYesNoDialog(parent, new Message(title, message, MessageType.QUESTION));
  }

  public static boolean showYesNoDialog(Component parent, Message message) {
    return showDialog(parent, message, YES_NO_BUTTON_CONFIGURATION);
  }

  public static boolean showYesCancelDialog(Component parent, Message message) {
    return showDialog(parent, message, YES_CANCEL_BUTTON_CONFIGURATION);
  }

  private static boolean showDialog(
      Component parent,
      Message message,
      final IDialogButtonConfiguration buttonConfiguration) {
    MessageUserDialogConfiguration configuration = new MessageUserDialogConfiguration(
        message,
        buttonConfiguration);
    UserDialog userDialog = new UserDialog(parent, configuration);
    userDialog.show();
    return !userDialog.isCanceled();
  }
}