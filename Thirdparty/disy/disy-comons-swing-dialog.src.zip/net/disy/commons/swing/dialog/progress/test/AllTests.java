//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.progress.test;

import junit.framework.Test;
import junit.framework.TestSuite;

// NOT_PUBLISHED
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for de.disy.cadenza.core.operation.progress.dialog.test"); //$NON-NLS-1$
    //$JUnit-BEGIN$
    suite.addTestSuite(ProgressMonitorDialogTest.class);
    suite.addTestSuite(InternalProgressDialogTest.class);
    //$JUnit-END$
    return suite;
  }
}