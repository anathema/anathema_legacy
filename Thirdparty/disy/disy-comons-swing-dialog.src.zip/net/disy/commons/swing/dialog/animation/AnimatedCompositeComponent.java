package net.disy.commons.swing.dialog.animation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.Timer;

import net.disy.commons.core.util.Ensure;

public class AnimatedCompositeComponent extends JPanel {

  private boolean overlaidComponentVisible;
  private int overlayPositionFromBottom = 0;

  private final Timer timer;

  public AnimatedCompositeComponent(JComponent baseComponent, JComponent overlaidComponent) {
    Ensure.ensureArgumentNotNull(baseComponent);
    Ensure.ensureArgumentNotNull(overlaidComponent);
    setLayout(new AnimatedCompositeLayout(baseComponent, overlaidComponent));
    add(overlaidComponent);
    add(baseComponent);

    timer = new Timer(15, new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        updateAnimation();
      }
    });
    timer.setInitialDelay(0);
  }

  public void setOverlaidComponentVisible(boolean overlaidComponentVisible) {
    this.overlaidComponentVisible = overlaidComponentVisible;
    timer.start();
  }

  private void updateAnimation() {
    if (oneStep()) {
      revalidate();
    }
    else {
      timer.stop();
    }
  }

  private boolean oneStep() {
    if (!overlaidComponentVisible) {
      if (overlayPositionFromBottom == 0) {
        return false;
      }
      --overlayPositionFromBottom;
      return true;
    }
    if (overlayPositionFromBottom >= getHeight()) {
      return false;
    }
    ++overlayPositionFromBottom;
    return true;
  }

  public boolean isOverlayVisible() {
    return overlaidComponentVisible;
  }

  public int getOverlayPositionFromBottom() {
    return overlayPositionFromBottom;
  }
}