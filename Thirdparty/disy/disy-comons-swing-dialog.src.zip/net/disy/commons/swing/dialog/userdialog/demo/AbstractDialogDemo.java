//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog.demo;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public abstract class AbstractDialogDemo extends SwingDemoCase {

  private static final BasicMessage WARNING_MESSAGE_TOO_SHORT = new BasicMessage(
      "The name is discouraged, names should be at least 4 characters long.", //$NON-NLS-1$
      MessageType.WARNING);
  private static final BasicMessage ERROR_MESSAGE_EMPTY = new BasicMessage(
      "The name may not be empty. Please enter a valid name.", MessageType.ERROR); //$NON-NLS-1$
  private static final BasicMessage DEFAULT_MESSAGE = new BasicMessage("Message"); //$NON-NLS-1$

  /** @deprecated As of 22.12.2005 (gebhard), replaced by {@link #show(IDialogPage)}, {@link #show(IDialogPage, boolean)}*/
  protected void showDemoUserDialog(IDialogPage dialogPage, final boolean headerPanelVisible) {
    show(dialogPage, headerPanelVisible);
  }

  protected void show(IDialogPage dialogPage, final boolean headerPanelVisible) {
    IDialogConfiguration userDialog = new AbstractDialogConfiguration(dialogPage) {
      public boolean performOk(Component parentComponent) {
        System.out.println("ok"); //$NON-NLS-1$
        return true;
      }

      public boolean isHeaderPanelVisible() {
        return headerPanelVisible;
      }

      public boolean isModal() {
        return false;
      }
    };

    show(new UserDialog(createJFrame(), userDialog).getDialog().getWindow());
  }

  protected void show(IDialogPage dialogPage) {
    show(dialogPage, true);
  }

  protected IDialogPage createDemoDialogPage() {
    IDialogPage dialogPage = new AbstractDialogPage(DEFAULT_MESSAGE) {
      private JTextField textField;

      public JComponent createContent() {
        JPanel panel = new JPanel(new BorderLayout(2, 2));
        panel.add(new JLabel("Name:"), BorderLayout.WEST); //$NON-NLS-1$
        textField = new JTextField(20);
        textField.getDocument().addDocumentListener(getCheckInputValidListener());
        panel.add(textField, BorderLayout.CENTER);
        JPanel p = new JPanel();
        p.add(panel);
        return p;
      }

      public String getDescription() {
        return "Description"; //$NON-NLS-1$
      }

      public String getTitle() {
        return "Title"; //$NON-NLS-1$
      }

      public void requestFocus() {
        textField.requestFocus();
      }

      public IBasicMessage createCurrentMessage() {
        if (textField.getText().length() == 0) {
          return ERROR_MESSAGE_EMPTY;
        }
        else if (textField.getText().length() < 4) {
          return WARNING_MESSAGE_TOO_SHORT;
        }
        else {
          return getDefaultMessage();
        }
      }
    };
    return dialogPage;
  }

}