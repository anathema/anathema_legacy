// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard.demo;


import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPageFactory;
import net.disy.commons.swing.dialog.wizard.SinglePageWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.WizardDialog;

import de.jdemo.extensions.SwingDemoCase;

//NOT_PUBLISHED
public abstract class AbstractWizardDemoCase extends SwingDemoCase {

  protected void show(IWizardPageFactory pageFactory) {
    show(new SinglePageWizardConfiguration(pageFactory));
  }

  protected void show(IWizardConfiguration configuration) {
    WizardDialog dialog = new WizardDialog(
        createParentComponent(),
        configuration);
    show(dialog.getConfiguredDialog().getWindow());
  }

}
