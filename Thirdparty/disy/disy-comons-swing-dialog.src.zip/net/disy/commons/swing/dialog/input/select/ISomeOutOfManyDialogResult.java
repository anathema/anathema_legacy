//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.swing.dialog.input.IInputDialogResult;

// NOT_PUBLISHED
public interface ISomeOutOfManyDialogResult extends IInputDialogResult {

  public Object getSelectedItem();

  public Object[] getSelectedItems();

}