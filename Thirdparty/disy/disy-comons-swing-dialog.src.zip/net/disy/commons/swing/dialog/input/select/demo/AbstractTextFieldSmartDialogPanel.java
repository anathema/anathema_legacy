//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select.demo;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

// NOT_PUBLISHED
public abstract class AbstractTextFieldSmartDialogPanel extends AbstractSmartDialogPanel {

  private final String label;
  private final JTextField textField;
  private final ObjectSelectionModel selectedItemModel;

  public AbstractTextFieldSmartDialogPanel(String label, ObjectSelectionModel selectedItemModel) {
    this.label = label;
    this.selectedItemModel = selectedItemModel;
    textField = doCreateTextField();
  }

  public int getColumnCount() {
    return 2;
  }

  public void fillInto(JPanel panel, int columnCount) {
    panel.add(new JLabel(label), GridDialogLayoutData.RIGHT);
    GridDialogLayoutData remainingLayoutData = new GridDialogLayoutData(
        GridDialogLayoutData.FILL_HORIZONTAL);
    remainingLayoutData.setHorizontalSpan(columnCount - 1);
    panel.add(textField, remainingLayoutData);
  }

  public IBasicMessage createOptionalCurrentMessage() {
    return null;
  }

  protected abstract JTextField doCreateTextField();

  public void addChangeListener(final ChangeListener listener) {
    textField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      protected void documentChanged() {
        listener.stateChanged(new ChangeEvent(this));
      }
    });
  }

  public ObjectSelectionModel getSelectedItemsModel() {
    return selectedItemModel;
  }
}