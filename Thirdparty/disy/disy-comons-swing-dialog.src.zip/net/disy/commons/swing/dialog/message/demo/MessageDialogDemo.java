// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message.demo;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutPage;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class MessageDialogDemo extends SwingDemoCase {

  private final static String LONG_MESSAGE_TEXT = "Beim Schreiben dieses Textes fiel dem Softwareentwickler nicht ein, welcher Fehler denn " //$NON-NLS-1$
      + "tats�chlich aufgetreten ist. Es ist aber ein Fehler aufgetreten."; //$NON-NLS-1$
  private final static String SHORT_MESSAGE_TEXT = "Kurze Meldung."; //$NON-NLS-1$

  public void demoErrorMessageUserDialog() {
    Message message = new Message("Fehlermeldungstitel", LONG_MESSAGE_TEXT, MessageType.ERROR); //$NON-NLS-1$
    UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoInfoMessageUserDialog() {
    Message message = new Message(
        "Fehlermeldungstitel", //$NON-NLS-1$
        SHORT_MESSAGE_TEXT,
        MessageType.INFORMATION);
    UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoWarningMessageUserDialog() {
    Message message = new Message("Fehlermeldungstitel", SHORT_MESSAGE_TEXT, MessageType.WARNING); //$NON-NLS-1$
    UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoFoldOutErrorMessageUserDialog() {
    Message message = new Message("Fehlermeldungstitel", LONG_MESSAGE_TEXT, MessageType.ERROR); //$NON-NLS-1$
    IFoldOutPage foldOutPage = new AbstractFoldOutPage() {
      protected JComponent createContent() {
        return new JScrollPane(new JTextArea(5, 40));
      }

      public void requestFocus() {
        getContent().requestFocus();
      }
    };
    UserDialog dialog = MessageDialogFactory.createFoldOutMessageDialog(
        createJFrame(),
        message,
        foldOutPage);
    show(dialog.getDialog().getWindow());
  }
}