// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import java.awt.Component;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.BasicDialogResources;
import net.disy.commons.swing.dialog.core.AbstractDialog;
import net.disy.commons.swing.dialog.core.IDialogConstants;
import net.disy.commons.swing.dialog.core.ISwingFrameOrDialog;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.util.GuiUtilities;

/**
 * A dialog to show a wizard to the end user. In typical usage, the client instantiates this class
 * with a particular wizard. The dialog serves as the wizard container and orchestrates the
 * presentation of its pages.
 * 
 * The standard layout is roughly as follows: it has an area at the top containing both the
 * wizard's title, description, and image; the actual wizard page appears in the middle; below that
 * is a progress indicator (which is made visible if needed); and at the bottom of the page is
 * message line and a button bar containing Help, Next, Back, Finish, and Cancel buttons (or some
 * subset).
 * 
 * Clients may subclass WizardDialog, although this is rarely required.
 */
public class WizardDialog extends AbstractDialog implements IWizardContainer, IDialogConstants {

  public static final String FINISH_BUTTON_NAME = "WizardDialog.FinishButton.ComponentName"; //$NON-NLS-1$
  private JButton finishButton;
  private JButton backButton;
  private JButton nextButton;
  private JButton helpButton;
  private IWizardPage currentPage;
  private IWizardConfiguration wizard;
  private final Collection pages = new HashSet();

  /**
   * Creates a new wizard dialog for the given wizard.
   * 
   * @param parent a parent component
   * @param wizard the wizard this dialog is working on
   */
  public WizardDialog(Component parent, IWizardConfiguration wizard) {
    super(parent, wizard);
    this.wizard = wizard;
    wizard.setContainer(this);
    wizard.addPages();
    initialize();
  }

  protected JComponent createButtonBar() {
    //SmartAction wegen Mnemonic!
    SmartAction backAction = new SmartAction(BasicDialogResources.WIZARD_BACK_SMART) {
      protected void execute(Component parentComponent) {
        backPressed();
      }
    };

    backButton = new JButton(backAction);

    SmartAction nextAction = new SmartAction(BasicDialogResources.WIZARD_NEXT_SMART) {
      protected void execute(Component parentComponent) {
        nextPressed();
      }
    };

    nextButton = new JButton(nextAction);

    JPanel compactedButtons = new JPanel(new GridLayout(1, 0, 0, 0));
    compactedButtons.add(backButton);
    compactedButtons.add(nextButton);

    IDialogButtonConfiguration buttonConfiguration = getWizard().getButtonConfiguration();

    final IActionConfiguration okActionConfiguration = buttonConfiguration
        .getOkActionConfiguration();
    final SmartAction finishAction = new SmartAction(okActionConfiguration != null
        ? okActionConfiguration
        : new ActionConfiguration()) {
      protected void execute(Component parentComponent) {
        performFinish(parentComponent);
      }
    };

    finishButton = new JButton(finishAction);
    finishButton.setName(FINISH_BUTTON_NAME);

    final IActionConfiguration cancelActionConfiguration = buttonConfiguration
        .getCancelActionConfiguration();
    final SmartAction cancelAction = new SmartAction(cancelActionConfiguration != null
        ? cancelActionConfiguration
        : new ActionConfiguration()) {
      protected void execute(Component parentComponent) {
        performCancel();
      }
    };

    JButton cancelButton = new JButton(cancelAction);

    final SmartAction helpAction = new SmartAction(BasicDialogResources.HELP_TEXT_SMART) {
      protected void execute(Component parentComponent) {
        helpPressed();
      }
    };

    helpButton = new JButton(helpAction);

    List buttonList = new ArrayList();
    buttonList.add(compactedButtons);

    //ggf. hier auch zus�tzliche Buttons zulassen
    JButton[] additionalButtons = createAdditionalButtons();
    buttonList.addAll(Arrays.asList(additionalButtons));

    if (okActionConfiguration != null) {
      buttonList.add(finishButton);
    }
    if (cancelActionConfiguration != null) {
      buttonList.add(cancelButton);
    }
    if (getWizard().isHelpAvailable()) {
      buttonList.add(helpButton);
    }
    ButtonPanelBuilder buttonPanelBuilder = new ButtonPanelBuilder();
    for (int i = 0; i < buttonList.size(); i++) {
      JComponent button = (JComponent) buttonList.get(i);
      buttonPanelBuilder.add(button);
    }
    return buttonPanelBuilder.createPanel();
  }

  private JButton[] createAdditionalButtons() {
    return new JButton[0];
  }

  /** Notifies that the back button of this dialog has been pressed. */
  protected final void backPressed() {
    showPage(getCurrentPage().getPreviousPage());
  }

  /** Notifies that the cancel button of this dialog has been pressed. */
  protected final boolean cancelPressed() {
    return getWizard().performCancel(getDialog().getWindow());
  }

  /** The Finish button has been pressed. */
  protected final boolean finishPressed(Component parentComponent) {
    /*
     * Zur Sicherheit nochmal getNextPage auf der aktuellen Seite aufrufen, um
     */
    // 30.10.2003: Diskussion ob nextPage oder pageDeactivated (mg): Wenn �berhaupt dann sollte 
    // pageDeactivated aufgerufen werden. Die getNextPage() hat semantisch nichts mit finish zu tun, oder?
    getCurrentPage().getNextPage();
    getCurrentPage().pageDeactivated();

    return getWizard().performFinish(parentComponent);
  }

  /** The Help button has been pressed. */
  protected void helpPressed() {
    getCurrentPage().performHelp();
  }

  /** The Next button has been pressed */
  protected void nextPressed() {
    showPage(getCurrentPage().getNextPage());
  }

  //  /** Sets the minimum page size used for the pages.*/
  //  protected void setMinimumPageSize(Dimension size) {
  //    this.minimumPageSize = size;
  //    updateSize();
  //  }

  public void showPage(IWizardPage page) {
    Ensure.ensureArgumentNotNull(page);
    if (currentPage != null) {
      currentPage.pageDeactivated();
    }
    currentPage = page;
    pages.add(page);
    updateContent();
    updateMessage();
    updateDescription();
    updateButtons();
    updateTitle();
    updateSize();
    currentPage.pageActivated();
    currentPage.requestFocus();
  }

  protected void updateContent() {
    setContent(getCurrentPage().getContent());
  }

  public IWizardPage getCurrentPage() {
    return currentPage;
  }

  public void updateButtons() {
    IWizardPage page = getCurrentPage();
    nextButton.setEnabled(page.canFlipToNextPage());
    backButton.setEnabled(page.getPreviousPage() != null);
    finishButton.setEnabled(getWizard().canFinish());
    helpButton.setVisible(getWizard().isHelpAvailable());
    helpButton.setEnabled(page.isHelpAvailable());
    if (finishButton.isEnabled()) {
      setDefaultButton(finishButton);
    }
    else {
      setDefaultButton(nextButton);
    }
  }

  public void updateMessage() {
    setMessage(getCurrentPage().getMessage());
  }

  public void updateDescription() {
    setDescription(getCurrentPage().getDescription());
  }

  public void updateTitle() {
    setTitle(getCurrentPage().getTitle());
  }

  public void show() {
    ISwingFrameOrDialog configuredDialog = getConfiguredDialog();
    GuiUtilities.centerToParent(configuredDialog.getWindow());
    configuredDialog.show();
  }

  /** For internal use only (demos) */
  public ISwingFrameOrDialog getConfiguredDialog() {
    IWizardPage startingPage = getWizard().getStartingPage();
    if (startingPage == null) {
      throw new RuntimeException("Starting page may not be null in IWizard.getStartingPage()"); //$NON-NLS-1$
    }
    showPage(startingPage);
    ISwingFrameOrDialog configuredDialog = getDialog();
    if (configuredDialog == null) {
      throw new IllegalStateException(
          "WizardDialog is already disposed and may not be shown more often than once"); //$NON-NLS-1$
    }
    if (configuredDialog.isVisible()) {
      throw new IllegalStateException("WizardDialog is already visible"); //$NON-NLS-1$
    }
    return configuredDialog;
  }

  protected IWizardConfiguration getWizard() {
    return wizard;
  }

  private final void performFinish(Component parentComponent) {
    if (finishPressed(parentComponent)) {
      closeDialog();
      getGenericDialog().performAfterDispose(false);
    }
  }

  //@Overrides
  public final void requestFinish() {
    performFinish(getDialog().getWindow());
  }

  //@Overrides
  public final void requestNext() {
    if (!getCurrentPage().canFlipToNextPage()) {
      return;
    }
    nextPressed();
  }

  protected void closeDialog() {
    super.closeDialog();
    for (Iterator iter = pages.iterator(); iter.hasNext();) {
      ((IWizardPage) iter.next()).dispose();
    }
  }
}