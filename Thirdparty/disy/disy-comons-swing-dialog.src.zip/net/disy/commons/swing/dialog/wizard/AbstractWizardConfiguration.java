// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import java.awt.Component;
import java.awt.Dimension;

import net.disy.commons.swing.dialog.BasicDialogResources;
import net.disy.commons.swing.dialog.userdialog.buttons.AbstractDialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

/**
 * Abstract superclass that can be extended for {@link IWizardConfiguration}
 * implementations.
 */
public abstract class AbstractWizardConfiguration implements IWizardConfiguration {
  private IWizardContainer container;

  public IWizardContainer getContainer() {
    return container;
  }

  public void setContainer(IWizardContainer container) {
    this.container = container;
  }

  public boolean isHeaderPanelVisible() {
    return true;
  }

  public boolean canFinish() {
    IWizardPage currentPage = getContainer().getCurrentPage();
    return currentPage.canFinish();
  }

  public void updateSize() {
    container.updateSize();
  }

  public Dimension getDialogSize() {
    return null;
  }

  public final IDialogButtonConfiguration getButtonConfiguration() {
    return new AbstractDialogButtonConfiguration() {
      public String getOkayButtonText() {
        return BasicDialogResources.WIZARD_FINISH_SMART;
      }
    };
  }

  public void performAfterDispose(boolean canceled) {
    //nothing to do
  }

  public boolean shallInitializePagesFromData() {
    return false;
  }

  public boolean performFinish(Component parentComponent) {
    return true;
  }

  public boolean performCancel(Component parentComponent) {
    return true;
  }
}