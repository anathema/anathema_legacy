// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 01.03.2004
package net.disy.commons.swing.dialog.userdialog;

import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public final class DefaultUserDialogConfiguration extends AbstractDialogConfiguration {

  public DefaultUserDialogConfiguration(IDialogPage dialogPage) {
    super(dialogPage);
  }

  public DefaultUserDialogConfiguration(IDialogPage dialogPage, IDialogButtonConfiguration buttonConfiguration) {
    super(dialogPage, buttonConfiguration);
  }

}
