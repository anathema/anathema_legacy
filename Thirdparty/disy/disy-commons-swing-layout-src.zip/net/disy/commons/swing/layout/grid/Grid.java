package net.disy.commons.swing.layout.grid;

import java.awt.Insets;
import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.layout.util.GridCellSize;
import net.disy.commons.swing.layout.util.GridCellSizeList;


/**
 * This class is not intended to be used by clients.
 * @author Markus Gebhard
 */
public class Grid {

  private final GridCellSizeList rowSizes;
  private final GridCellSizeList columnSizes;
  private final GridCell[] cells;

  public Grid(GridCellSizeList rowSizes, GridCellSizeList columnSizes, GridCell[] cells) {
    this.rowSizes = rowSizes;
    this.columnSizes = columnSizes;
    this.cells = cells;
  }

  public GridCellSize getColumn(int columnIndex) {
    return columnSizes.get(columnIndex);
  }

  public GridCellSize getRow(int rowIndex) {
    return rowSizes.get(rowIndex);
  }

  public int getRowCount() {
    return rowSizes.size();
  }

  public int getCellCount() {
    return cells.length;
  }

  public GridCell getCell(int i) {
    return cells[i];
  }

  public int getColumnCount() {
    return columnSizes.size();
  }

  public GridCellSizeList getColumns() {
    return columnSizes;
  }

  public GridCellSizeList getRows() {
    return rowSizes;
  }

  public void makeColumnsEqualWidth() {
    int minimumColumnWidth = 0;
    for (int i = 0; i < columnSizes.size(); i++) {
      if (columnSizes.get(i).getMinimumSize() > minimumColumnWidth) {
        minimumColumnWidth = columnSizes.get(i).getMinimumSize();
      }
    }
    for (int i = 0; i < columnSizes.size(); i++) {
      columnSizes.get(i).setMinimumSize(minimumColumnWidth);
    }
    int preferredColumnWidth = 0;
    for (int i = 0; i < columnSizes.size(); i++) {
      if (columnSizes.get(i).getPreferredSize() > preferredColumnWidth) {
        preferredColumnWidth = columnSizes.get(i).getPreferredSize();
      }
    }
    for (int i = 0; i < columnSizes.size(); i++) {
      columnSizes.get(i).setPreferredSize(preferredColumnWidth);
    }
  }

  public int getTotalMinimumWidth(int horizontalSpacing, Insets insets) {
    int totalWidth = 0;
    for (int i = 0; i < getColumnCount(); ++i) {
      GridCellSize column = getColumn(i);
      totalWidth += column.getMinimumSize();
    }
    //Add spacings
    if (getColumnCount() > 0) {
      totalWidth += (getColumnCount() - 1) * horizontalSpacing;
    }
    totalWidth += insets.left + insets.right;
    return totalWidth;
  }

  public int getTotalPreferredWidth(int horizontalSpacing, Insets insets) {
    int totalWidth = 0;
    for (int i = 0; i < getColumnCount(); ++i) {
      GridCellSize column = getColumn(i);
      totalWidth += column.getPreferredSize();
    }
    //Add spacings
    if (getColumnCount() > 0) {
      totalWidth += (getColumnCount() - 1) * horizontalSpacing;
    }
    totalWidth += insets.left + insets.right;
    return totalWidth;
  }

  public int getTotalWidth(int horizontalSpacing, Insets insets) {
    int totalWidth = 0;
    for (int i = 0; i < getColumnCount(); ++i) {
      GridCellSize column = getColumn(i);
      totalWidth += column.getSize();
    }
    //Add spacings
    if (getColumnCount() > 0) {
      totalWidth += (getColumnCount() - 1) * horizontalSpacing;
    }
    totalWidth += insets.left + insets.right;
    return totalWidth;
  }

  public int getTotalMinimumHeight(int verticalSpacing, Insets insets) {
    int totalHeight = 0;
    for (int i = 0; i < getRowCount(); ++i) {
      GridCellSize row = getRow(i);
      totalHeight += row.getMinimumSize();
    }
    //Add spacings
    if (getRowCount() > 0) {
      totalHeight += (getRowCount() - 1) * verticalSpacing;
    }
    totalHeight += insets.top + insets.bottom;
    return totalHeight;
  }

  public int getTotalPreferredHeight(int verticalSpacing, Insets insets) {
    int totalHeight = 0;
    for (int i = 0; i < getRowCount(); ++i) {
      GridCellSize row = getRow(i);
      totalHeight += row.getPreferredSize();
    }
    //Add spacings
    if (getRowCount() > 0) {
      totalHeight += (getRowCount() - 1) * verticalSpacing;
    }
    totalHeight += insets.top + insets.bottom;
    return totalHeight;
  }

  public int getTotalHeight(int verticalSpacing, Insets insets) {
    int totalHeight = 0;
    for (int i = 0; i < getRowCount(); ++i) {
      GridCellSize row = getRow(i);
      totalHeight += row.getSize();
    }
    //Add spacings
    if (getRowCount() > 0) {
      totalHeight += (getRowCount() - 1) * verticalSpacing;
    }
    totalHeight += insets.top + insets.bottom;
    return totalHeight;
  }

  public GridCellSizeList getGrabbingColumnSizes() {
    return getGrabbingColumnSizes(0, getColumnCount());
  }

  public GridCellSizeList getGrabbingColumnSizes(int startIndex, int span) {
    List/*<GridCellSize>*/grabbingColumns = new ArrayList();
    for (int i = startIndex; i < startIndex + span; i++) {
      if (getColumn(i).isGrabExcessSpace()) {
        grabbingColumns.add(getColumn(i));
      }
    }
    return new GridCellSizeList((GridCellSize[]) grabbingColumns.toArray(new GridCellSize[grabbingColumns.size()]));
  }

  public GridCellSizeList getNonGrabbingColumnSizes() {
    List/*<GridCellSize>*/nonGrabbingColumns = new ArrayList();
    for (int i = 0; i < getColumnCount(); i++) {
      if (!getColumn(i).isGrabExcessSpace()) {
        nonGrabbingColumns.add(getColumn(i));
      }
    }
    return new GridCellSizeList((GridCellSize[]) nonGrabbingColumns.toArray(new GridCellSize[nonGrabbingColumns
        .size()]));
  }

  public GridCellSizeList getGrabbingRowSizes() {
    return getGrabbingRowSizes(0, getRowCount());
  }


  public GridCellSizeList getGrabbingRowSizes(int startIndex, int span) {
    List/*<GridCellSize>*/grabbingRows = new ArrayList();
    for (int i = startIndex; i < startIndex + span; i++) {
      if (getRow(i).isGrabExcessSpace()) {
        grabbingRows.add(getRow(i));
      }
    }
    return new GridCellSizeList((GridCellSize[]) grabbingRows.toArray(new GridCellSize[grabbingRows.size()]));
  }

  public GridCellSizeList getNonGrabbingRowSizes() {
    List/*<GridCellSize>*/nonGrabbingRows = new ArrayList();
    for (int i = 0; i < getRowCount(); i++) {
      if (!getRow(i).isGrabExcessSpace()) {
        nonGrabbingRows.add(getRow(i));
      }
    }
    return new GridCellSizeList((GridCellSize[]) nonGrabbingRows
        .toArray(new GridCellSize[nonGrabbingRows.size()]));
  }
}