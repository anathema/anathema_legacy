package net.disy.commons.swing.layout.grid;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.util.LayoutUtilities;


/**
 * @author Markus Gebhard
 */
public class GridDialogPanel implements IGridDialogPanel {

  private static final class VerticalSpacingDialogComponent implements IDialogComponent {
    private final int height;

    private VerticalSpacingDialogComponent(int height) {
      this.height = height;
    }

    public int getColumnCount() {
      return 1;
    }

    public void fillInto(JPanel panel, int columnCount) {
      panel.add(Box.createVerticalStrut(height));
    }
  }

  private final List/*<IDialogComponent>*/components = new ArrayList();
  private final boolean equalWidthColumns;
  private JPanel panel;
  private final int horizontalSpacing;
  private final int verticalSpacing;

  public GridDialogPanel() {
    this(false);
  }

  public GridDialogPanel(boolean equalWidthColumns) {
    this(equalWidthColumns, LayoutUtilities.getComponentSpacing(), LayoutUtilities.getComponentSpacing());
  }

  public GridDialogPanel(int horizontalSpacing, int verticalSpacing) {
    this(false, horizontalSpacing, verticalSpacing);
  }

  public GridDialogPanel(boolean equalWidthColumns, int horizontalSpacing, int verticalSpacing) {
    this.equalWidthColumns = equalWidthColumns;
    this.horizontalSpacing = horizontalSpacing;
    this.verticalSpacing = verticalSpacing;
  }

  public void add(IDialogComponent component) {
    if (panel != null) {
      throw new IllegalStateException("Trying to add a dialog component after content has been created."); //$NON-NLS-1$
    }
    components.add(component);
  }

  public void addVerticalSpacing(final int height) {
    add(new VerticalSpacingDialogComponent(height));
  }

  public JPanel getContent() {
    if (panel == null) {
      int columnCount = getMaximumColumnCount();
      if (columnCount == 0) {
        columnCount = 1;
      }
      GridDialogLayout gridDialogLayout = new GridDialogLayout(columnCount, equalWidthColumns);
      gridDialogLayout.setHorizontalSpacing(horizontalSpacing);
      gridDialogLayout.setVerticalSpacing(verticalSpacing);
      panel = new JPanel(gridDialogLayout);
      for (Iterator iter = components.iterator(); iter.hasNext();) {
        IDialogComponent component = (IDialogComponent) iter.next();
        component.fillInto(panel, columnCount);
        panel.add(new EndOfLineMarkerComponent());
      }
    }
    return panel;
  }

  private int getMaximumColumnCount() {
    int maxColumnCount = 0;
    for (Iterator iter = components.iterator(); iter.hasNext();) {
      IDialogComponent component = (IDialogComponent) iter.next();
      if (component.getColumnCount() > maxColumnCount) {
        maxColumnCount = component.getColumnCount();
      }
    }
    return maxColumnCount;
  }
}