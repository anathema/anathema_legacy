package net.disy.commons.swing.layout.grid;

import javax.swing.JPanel;

/**
 * @author Markus Gebhard
 */
public interface IDialogComponent {

  /** @return the number of columns this dialog component requires. */
  public int getColumnCount();

  /** Fill the contents of this component (its subcomponents) into the given panel.
   * The panel is assumed to have {@link GridDialogLayout} as its layout manager, having
   * at least {@link #getColumnCount()} columns. */
  public void fillInto(JPanel panel, int columnCount);

}