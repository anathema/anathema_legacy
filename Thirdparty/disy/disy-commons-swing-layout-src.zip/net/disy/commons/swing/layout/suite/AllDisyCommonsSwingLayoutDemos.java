package net.disy.commons.swing.layout.suite;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

/**
 * @author Markus Gebhard
 */
public class AllDisyCommonsSwingLayoutDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for de.jave.lib.gui.layout.grid.suite"); //$NON-NLS-1$
    suite.addDemo(net.disy.commons.swing.layout.grid.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.layout.util.demo.AllDemos.suite());
    //$JDemo-BEGIN$

    //$JDemo-END$
    return suite;
  }
}