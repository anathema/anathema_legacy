package net.disy.commons.swing.layout.grid;

import javax.swing.JPanel;

public interface IGridDialogPanel {

  public void add(IDialogComponent component);

  public void addVerticalSpacing(int height);

  public JPanel getContent();
}
