package net.disy.commons.swing.layout.grid.demo;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class BugDemo extends SwingDemoCase {

  public void demoBug1() {
    GridDialogLayoutData leftLayoutData = new GridDialogLayoutData();
    leftLayoutData.setHorizontalSpan(2);
    JCheckBox component1 = new JCheckBox("Linke Grenze"); //$NON-NLS-1$
    JTextField component2 = new JTextField("100.0"); //$NON-NLS-1$
    JComboBox component3 = new JComboBox(new String[]{ "<", "<=" }); //$NON-NLS-1$ //$NON-NLS-2$

    JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(component1, leftLayoutData);
    panel.add(component2);
    panel.add(component3);
    panel.doLayout();
    show(panel);
  }

  public void demoBug2() {
    JPanel panel = new JPanel(new GridDialogLayout(4, false));
    panel.add(new JLabel("Label")); //$NON-NLS-1$
    GridDialogLayoutData grabData = new GridDialogLayoutData(GridDialogLayoutData.FILL_HORIZONTAL);
    grabData.setHorizontalAlignment(GridAlignment.END);
    panel.add(new JLabel("2"), grabData); //$NON-NLS-1$
    GridDialogLayoutData centerData = new GridDialogLayoutData();
    centerData.setHorizontalAlignment(GridAlignment.CENTER);
    panel.add(new JLabel("/"), centerData); //$NON-NLS-1$
    GridDialogLayoutData endData = new GridDialogLayoutData();
    endData.setHorizontalAlignment(GridAlignment.END);
    panel.add(new JLabel("5"), endData); //$NON-NLS-1$

    panel.add(new JLabel("Text")); //$NON-NLS-1$
    GridDialogLayoutData textAreaData = new GridDialogLayoutData();
    textAreaData.setHorizontalSpan(3);
    textAreaData.setHorizontalAlignment(GridAlignment.END);
    panel.add(new JTextArea(1, 14), textAreaData);
    show(panel);
  }

}