package net.disy.commons.swing.layout.grid.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

/**
 * @author Markus Gebhard
 */
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for de.jave.lib.gui.layout.grid.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(PracticalExampleDemo.class));
    suite.addDemo(new DemoSuite(ButtonLayoutDemo.class));
    suite.addDemo(new DemoSuite(AddComponentsDemo.class));
    suite.addDemo(new DemoSuite(GridDialogPanelDemo.class));
    suite.addDemo(new DemoSuite(SimpleGridLayoutDemo.class));
    suite.addDemo(new DemoSuite(BugDemo.class));
    suite.addDemo(new DemoSuite(ToggleVisibilityDemo.class));
    //$JDemo-END$
    return suite;
  }
}