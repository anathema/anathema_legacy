package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import junit.framework.TestCase;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

/**
 * @author Markus Gebhard
 */
public abstract class AbstractGridLayoutTestCase extends TestCase {

  protected static Container createContainer(GridDialogLayout layout) {
    return createContainer(layout, new Insets(0, 0, 0, 0));
  }

  protected static Container createContainer(GridDialogLayout layout, final Insets insets) {
    return new JPanel(layout) {
      public Insets getInsets() {
        return insets;
      }
    };
  }

  protected static Component createComponent(Dimension preferredSize) {
    return createComponent(preferredSize, preferredSize);
  }

  protected static Component createComponent(Dimension preferredSize, Dimension minimumSize) {
    JComponent component = new JLabel();
    component.setPreferredSize(preferredSize);
    component.setMinimumSize(minimumSize);
    component.setMaximumSize(preferredSize);
    return component;
  }

  protected final static void doLayout(GridDialogLayout layout, Container container) {
    container.setSize(layout.preferredLayoutSize(container));
    layout.layoutContainer(container);
  }
}