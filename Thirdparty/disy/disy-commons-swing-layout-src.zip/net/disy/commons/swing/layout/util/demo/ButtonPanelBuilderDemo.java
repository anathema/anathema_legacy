//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.layout.util.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutDirection;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class ButtonPanelBuilderDemo extends SwingDemoCase {

  public void demo() {
    ButtonPanelBuilder builder = new ButtonPanelBuilder();
    builder.add(new AbstractAction("OK") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        //nothing to do  
      }
    });
    builder.add(new AbstractAction("Nice Buttons") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        //nothing to do  
      }
    });
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(new JScrollPane(new JTextArea(5, 20)), BorderLayout.CENTER);
    panel.add(builder.createPanel(), BorderLayout.SOUTH);
    show(panel);
  }

  public void demoVerticalButtons() {
    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.VERTICAL);
    builder.add(new AbstractAction("OK") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        //nothing to do  
      }
    });
    builder.add(new AbstractAction("Nice Buttons") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        //nothing to do  
      }
    });
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(new JScrollPane(new JTextArea(5, 20)), BorderLayout.CENTER);
    panel.add(builder.createPanel(), BorderLayout.EAST);
    show(panel);
  }

}