package net.disy.commons.swing.layout.util;

/**
 * This class is not intended to be used by clients.
 * @author Markus Gebhard
 */
public class GridCellSize {

  private int minimumSize = 0;
  private int preferredSize = 0;
  private int start;
  private int size;
  private boolean grabExcessSpace = false;

  public int getMinimumSize() {
    return minimumSize;
  }

  public int getPreferredSize() {
    return preferredSize;
  }

  public void setMinimumSize(int minimumSize) {
    this.minimumSize = minimumSize;
  }

  public void setPreferredSize(int preferredSize) {
    this.preferredSize = preferredSize;
  }

  public void guaranteeMinimumSize(int minimumSize) {
    if (this.minimumSize < minimumSize) {
      this.minimumSize = minimumSize;
    }
  }

  public void guaranteePreferredSize(int preferredSize) {
    if (this.preferredSize < preferredSize) {
      this.preferredSize = preferredSize;
    }
  }

  public void setStart(int start) {
    this.start = start;
  }

  public int getSize() {
    return size;
  }

  public int getStart() {
    return start;
  }

  public boolean isGrabExcessSpace() {
    return grabExcessSpace;
  }

  public void setGrabExcessSpace(boolean grabExcessSpace) {
    this.grabExcessSpace = grabExcessSpace;
  }

  public void incrementMinimumSize(int increment) {
    this.minimumSize += increment;
    if (minimumSize < 0) {
      minimumSize = 0;
    }
  }

  public void incrementPreferredSize(int increment) {
    this.preferredSize += increment;
    if (preferredSize < 0) {
      preferredSize = 0;
    }
  }

  public void adjustToPreferredSize() {
    this.size = preferredSize;
  }

  public void incrementSize(int increment) {
    this.size += increment;
    if (size < 0) {
      size = 0;
    }
  }

  public void setSize(int size) {
    this.size = size;
  }
}