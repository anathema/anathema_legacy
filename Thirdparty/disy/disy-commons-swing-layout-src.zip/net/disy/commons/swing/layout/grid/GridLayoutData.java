package net.disy.commons.swing.layout.grid;

/** @deprecated As of Oct 30, 2004 (Markus Gebhard), replaced by {@link net.disy.commons.swing.layout.grid.GridDialogLayoutData}*/
public class GridLayoutData extends GridDialogLayoutData {

  /* TODO Oct 30, 2004 (Markus Gebhard): Provide this way for initialization in an independent
   * new class. Also bring back the FILL_XYZ constants. */

  // Style constants
  public static final int VERTICAL_ALIGN_BEGINNING = 1 << 1;
  public static final int VERTICAL_ALIGN_CENTER = 1 << 2;
  public static final int VERTICAL_ALIGN_END = 1 << 3;
  public static final int VERTICAL_ALIGN_FILL = 1 << 4;
  public static final int HORIZONTAL_ALIGN_BEGINNING = 1 << 5;
  public static final int HORIZONTAL_ALIGN_CENTER = 1 << 6;
  public static final int HORIZONTAL_ALIGN_END = 1 << 7;
  public static final int HORIZONTAL_ALIGN_FILL = 1 << 8;
  public static final int GRAB_HORIZONTAL = 1 << 9;
  public static final int GRAB_VERTICAL = 1 << 10;

  public GridLayoutData(int style) {
    if ((style & VERTICAL_ALIGN_BEGINNING) != 0) {
      setVerticalAlignment(GridAlignment.BEGINNING);
    }
    if ((style & VERTICAL_ALIGN_CENTER) != 0) {
      setVerticalAlignment(GridAlignment.CENTER);
    }
    if ((style & VERTICAL_ALIGN_FILL) != 0) {
      setVerticalAlignment(GridAlignment.FILL);
    }
    if ((style & VERTICAL_ALIGN_END) != 0) {
      setVerticalAlignment(GridAlignment.END);
    }

    if ((style & HORIZONTAL_ALIGN_BEGINNING) != 0) {
      setHorizontalAlignment(GridAlignment.BEGINNING);
    }
    if ((style & HORIZONTAL_ALIGN_CENTER) != 0) {
      setHorizontalAlignment(GridAlignment.CENTER);
    }
    if ((style & HORIZONTAL_ALIGN_FILL) != 0) {
      setHorizontalAlignment(GridAlignment.FILL);
    }
    if ((style & HORIZONTAL_ALIGN_END) != 0) {
      setHorizontalAlignment(GridAlignment.END);
    }

    if ((style & GRAB_HORIZONTAL) != 0) {
      setGrabExcessHorizontalSpace(true);
    }
    else {
      setGrabExcessHorizontalSpace(false);
    }
    if ((style & GRAB_VERTICAL) != 0) {
      setGrabExcessVerticalSpace(true);
    }
    else {
      setGrabExcessVerticalSpace(false);
    }
  }

  public GridLayoutData() {
    super();
  }

  public GridLayoutData(IGridDialogLayoutData prototype) {
    super(prototype);
  }
}