package net.disy.commons.swing.layout.grid;

import java.awt.Component;

/**
 * This class is not intended to be used by clients.
 * @author Markus Gebhard
 */
public class EndOfLineMarkerComponent extends Component {

  public boolean isVisible() {
    return false;
  }
}