/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.table.DefaultTableModel;

import junit.framework.AssertionFailedError;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.actions.AbstractTableActionFactory;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;

import org.junit.Before;
import org.junit.Test;

public class SmartTable_DisableTest {

  private SmartTable smartTable;

  @Before
  public void createSmartTable() throws Exception {
    smartTable = new SmartTable(
        new DefaultTableModel(2, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });
  }

  @Test
  public void testDisable() {
    smartTable.setEnabled(false);
    assertFalse(smartTable.isEnabled());
    assertFalse(smartTable.getTable().isEnabled());
  }

  @Test
  public void disableWithCreatedActionNotDisablesActionItself() {
    final Action action = new AbstractAction("name") { //$NON-NLS-1$
      @Override
      public void actionPerformed(ActionEvent e) {
        //nothing to do
      }
    };
    smartTable.addActionFactory(new AbstractTableActionFactory() {
      @Override
      public Action createAction(final SmartTable table) {
        return action;
      }
    });
    smartTable.setEnabled(false);
    assertTrue(action.isEnabled());
  }

  @Test
  public void disableWithNonCreatedActions() {
    smartTable.addActionFactory(new AbstractTableActionFactory() {
      @Override
      public Action createAction(final SmartTable table) {
        throw new AssertionFailedError("Action should not have been created"); //$NON-NLS-1$
      }
    });
    smartTable.setEnabled(false);
  }
}