/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import java.awt.EventQueue;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.label.SmartLabel;
import net.disy.commons.swing.list.AsynchronousFilteredListModel;
import net.disy.commons.swing.list.AsynchronousMutableFilteredListModel;
import net.disy.commons.swing.mousecursor.util.CursorUtilities;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.listtable.ListTable;
import net.disy.commons.swing.text.ClearTextFieldButton;
import net.disy.commons.swing.text.TextWidgetFactory;
import net.disy.commons.swing.util.GuiUtilities;

public class FilteringStrategyNG<T> implements IFilterStrategyNG<T> {

  private final IObjectModel<String> filterTextModel = new ObjectModel<String>();
  private final JTextField filterTextField;
  private AsynchronousFilteredListModel<T> listModel;
  private ListTable<T> filterableListTable;
  private SmartTable smartTable;
  private final Iterable<ITableColumn> columns;

  public FilteringStrategyNG(final Iterable<ITableColumn> columns) {
    filterTextField = TextWidgetFactory.createTextField(filterTextModel, 20);
    this.columns = columns;
  }

  @Override
  public IListModel<T> createListModel(final IListModel<T> originalModel) {
    listModel = new AsynchronousMutableFilteredListModel<T>((IMutableListModel<T>) originalModel);

    filterTextModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateFilter();
      }
    });
    return listModel;
  }

  @Override
  public void updateFilter() {
    listModel.setFilter(createFilter());
  }

  protected IPredicate<T> createFilter() {
    return new TableColumnCompositeFilter<T>(columns, filterTextModel.getValue());
  }

  @Override
  public void addFilterWidgets(final JPanel panel, final JComponent tableComponent) {
    panel.add(new SmartLabel("&Filter:", filterTextField));
    final ClearTextFieldButton button = new ClearTextFieldButton(
        filterTextField,
        "Filter zurücksetzen");
    panel.add(TextWidgetFactory.createInternalComponentWrappedTextFieldComponent(
        null,
        filterTextField,
        button));
    CursorUtilities.attachWaitCursorForBusyModel(tableComponent, (listModel).getBusyModel());
  }

  @Override
  public void attachTo(final ListTable<T> listTable) {
    this.filterableListTable = listTable;
    this.smartTable = listTable.getSmartTable();
    filterTextField.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(final KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) {
          listTable.moveSelectionIndex(-1);
          e.consume();
          return;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
          listTable.moveSelectionIndex(1);
          e.consume();
          return;
        }
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
          if (!StringUtilities.isNullOrEmpty(filterTextModel.getValue())) {
            filterTextModel.setValue("");
            e.consume();
          }
          else {
            final Window window = GuiUtilities.getWindowFor(filterTextField);
            if (window != null) {
              final Toolkit tk = window.getToolkit();
              final EventQueue evtQ = tk.getSystemEventQueue();
              evtQ.postEvent(new WindowEvent(window, WindowEvent.WINDOW_CLOSING));
              e.consume();
            }
          }
        }
      }
    });
  }

  public void clearFilter() {
    filterTextField.setText("");
  }

  public void setFilterText(final String filterText) {
    filterTextField.setText(filterText);
  }

  @Override
  public void requestFocus() {
    filterTextField.requestFocus();
  }

  public JTextField getFilterTextField() {
    return filterTextField;
  }

  public void applySingleFilterResult(final IBlock applySelection) {
    filterableListTable.getSelectionModel().setSelectionInterval(0, 0);
    filterableListTable.updateSelection();
    applySelection.execute();
    clearFilter();
    filterableListTable.requestFocus();
  }

  public void leaveFilter() {
    smartTable.requestFocus();
    if (smartTable.getSelectionModel().isSelectionEmpty() && listModel.getItemCount() > 0) {
      smartTable.getSelectionModel().setSelectionInterval(0, 0);
      smartTable.getTable().setEditingRow(0);
    }
  }

  public void enableEnterActionsOnFilter(final IBlock applySelection) {
    filterTextField.addKeyListener(new EnterActionListenerNG<T>(listModel, applySelection, this));
  }

  @Override
  public void keepSelectionUpToDate(final ObjectModel<T> selectionModel) {
    listModel.addChangeListener(new AsynchronousUpdateSelectionListener<T>(
        filterableListTable,
        listModel,
        selectionModel));
    selectionModel.addChangeListener(new UpdateSelectionListener(filterableListTable));
  }

  @Override
  public void waitForFilteringFinished() {
    listModel.waitForFilteringFinished();
  }

  @Override
  public boolean isFilteringNeeded() {
    return true;
  }
}