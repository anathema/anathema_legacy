/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;

public class ObjectModelToListModelWrapper<T> implements IChangeListener {

  public final IMutableListModel<T> listModel;
  public final ObjectModel<T> objectModel;

  public ObjectModelToListModelWrapper(
      final IMutableListModel<T> listModel,
      final ObjectModel<T> objectModel) {
    Ensure.ensureArgumentNotNull(listModel);
    Ensure.ensureArgumentNotNull(objectModel);
    this.listModel = listModel;
    this.objectModel = objectModel;
    listModel.addChangeListener(this);
    objectModel.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        T value = ObjectModelToListModelWrapper.this.objectModel.getValue();
        if (value == null && ObjectModelToListModelWrapper.this.listModel.getItemCount() > 0) {
          ObjectModelToListModelWrapper.this.listModel.clear();
        }
        else if (value != null
            && (ObjectModelToListModelWrapper.this.listModel.getItemCount() == 0 || ObjectModelToListModelWrapper.this.listModel
                .getItem(0) != value)) {

          ObjectModelToListModelWrapper.this.listModel.add(value, 0);
        }
      }
    });
  }

  public ObjectModelToListModelWrapper(IMutableListModel<T> listModel) {
    this(listModel, new ObjectModel<T>());
  }

  @Override
  public void stateChanged() {
    objectModel.setValue(listModel.getItemCount() == 0 ? null : listModel.getItem(0));
  }

  public ObjectModel<T> getObjectModel() {
    return objectModel;
  }
}
