/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static org.junit.Assert.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;

import org.junit.Test;

public class SmartTable_EmptyTest {

  @Test
  public void testEnterOnEmptyTableBug() throws AWTException {
    final SmartTable smartTable = new SmartTable(
        new DefaultTableModel(0, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });

    final JFrame frame = new JFrame();
    try {
      frame.getContentPane().add(smartTable.getContent());
      frame.pack();
      frame.setVisible(true);
      new Robot().keyPress(KeyEvent.VK_ENTER);
      new Robot().keyRelease(KeyEvent.VK_ENTER);
      assertEquals(-1, smartTable.getSelectedRowIndex());
      assertTrue(smartTable.isSelectionEmpty());
    }
    finally {
      frame.dispose();
    }
  }
}