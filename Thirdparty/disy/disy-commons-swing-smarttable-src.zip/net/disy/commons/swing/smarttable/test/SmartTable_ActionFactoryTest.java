/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static net.disy.commons.swing.testing.ComponentFinder.findButton;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.action.demo.DummySmartAction;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;
import net.disy.commons.swing.smarttable.actions.StaticTableActionFactory;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.testing.DisabledProxyActionPredicate;

import org.junit.Test;

public class SmartTable_ActionFactoryTest {

  private final SmartTable smartTable = new SmartTable(
      new DefaultTableModel(2, 1),
      new ITableColumnViewSettings[]{ new StringTableColumnSettings() });

  @Test
  public void findsButtonForConstructedAction() throws Exception {
    Action constructedAction = new DummySmartAction();
    smartTable.addActionFactory(new StaticTableActionFactory(constructedAction));
    JComponent content = smartTable.getContent();
    IPredicate<Action> predicate = new DisabledProxyActionPredicate(constructedAction, true);
    Component button = findButton(content, predicate);
    assertThat(button, is(not(nullValue())));
  }

  @Test
  public void doesNotCreateButtonIfFactoryHasNoAction() throws Exception {
    ITableActionFactory factory = mock(ITableActionFactory.class);
    smartTable.addActionFactory(factory);
    smartTable.getContent();
    verify(factory, never()).createAction(smartTable);
  }

  @Test
  public void createsButtonIfFactoryHasAction() throws Exception {
    ITableActionFactory factory = mock(ITableActionFactory.class);
    when(factory.hasAction(smartTable)).thenReturn(true);
    when(factory.createAction(smartTable)).thenReturn(new DummySmartAction());
    smartTable.addActionFactory(factory);
    smartTable.getContent();
    verify(factory).createAction(smartTable);
  }
}