//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors.action;


// NOT_PUBLISHED
public interface ICellEditResultVisitor {

  public void visitFinished(FinishedCellEditResult visitedResult);

  public void visitCanceled(CanceledCellEditResult visitedResult);

}
