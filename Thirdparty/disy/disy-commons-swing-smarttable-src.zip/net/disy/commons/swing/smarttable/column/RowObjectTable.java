/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.column;

import java.util.Arrays;

import javax.swing.JComponent;
import javax.swing.table.DefaultTableModel;

import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.SmartTableFactory;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;

public class RowObjectTable<T> {

  private final SmartTable smartTable;
  private final DefaultTableModel tableModel;

  public RowObjectTable(final T[] rowObjects, final IDeprecatedTableColumn<T>... columns) {
    smartTable = SmartTableFactory.create(columns);
    tableModel = (DefaultTableModel) smartTable.getModel();
    update(rowObjects);
  }

  public final void addActionFactory(final ITableActionFactory actionFactory) {
    smartTable.addActionFactory(actionFactory);
  }

  public final JComponent getContent() {
    return smartTable.getContent();
  }

  public final void update(final T[] rowObjects) {
    final int currentRowCount = tableModel.getRowCount();
    final int newItemCount = rowObjects.length;
    final int regularRows = Math.min(newItemCount, currentRowCount);
    for (int rowIndex = 0; rowIndex < regularRows; rowIndex++) {
      for (int columnIndex = 0; columnIndex < tableModel.getColumnCount(); columnIndex++) {
        final T value = rowObjects[rowIndex];
        tableModel.setValueAt(value, rowIndex, columnIndex);
      }
    }
    for (int surplusRowIndex = currentRowCount - 1; surplusRowIndex >= newItemCount; surplusRowIndex--) {
      tableModel.removeRow(surplusRowIndex);
    }
    for (int surplusItemIndex = currentRowCount; surplusItemIndex < newItemCount; surplusItemIndex++) {
      final Object[] row = new Object[tableModel.getColumnCount()];
      Arrays.fill(row, rowObjects[surplusItemIndex]);
      tableModel.addRow(row);
    }
  }
}