/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import java.awt.Color;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.ColorIndicatorTableColumnSettings;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;

public final class DemoColorItemColorColumn extends AbstractReadOnlyListModelColumn<DemoColorItem, Color> {
  public DemoColorItemColorColumn(final IListModel<DemoColorItem> listModel) {
    super(listModel);
  }

  @Override
  protected IListColumnValueConverter<DemoColorItem, Color> createRowToColumnValueAdapter() {
    return new IListColumnValueConverter<DemoColorItem, Color>() {
      @Override
      public Color getValue(final DemoColorItem listValue) {
        return listValue == null ? null : listValue.getColor();
      }
    };
  }

  @Override
  protected TableColumnConfiguration<Color> createConfiguration() {
    final TableColumnConfiguration<Color> configuration = new TableColumnConfiguration<Color>(
        "",
        Color.class,
        new ColorIndicatorTableColumnSettings());
    return configuration;
  }
}