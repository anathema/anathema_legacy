/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public class RemoveRowsTableAction extends SmartAction {

  private final SmartTable table;
  private final ITableRowsRemovePerformer removePerformer;

  public RemoveRowsTableAction(
      final IActionConfiguration configuration,
      final SmartTable table,
      final ITableRowsRemovePerformer removePerformer) {
    super(configuration);
    this.table = table;
    this.removePerformer = removePerformer;
    table.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(final ListSelectionEvent e) {
        updateEnabled();
      }
    });
    updateEnabled();

  }

  private void updateEnabled() {
    setEnabled(!table.isSelectionEmpty());
  }

  @Override
  protected void execute(Component parentComponent) {
    final int[] selectedRows = table.getTable().getSelectedRows();
    table.stopCellEditing();

    if (removePerformer.performRemove(parentComponent, selectedRows)) {
      if (table.getTable().getModel().getRowCount() > 0) {
        final int newRowIndex = Math.min(
            table.getTable().getModel().getRowCount() - 1,
            selectedRows[0]);
        table.scrollToAndSelect(0);
        table.requestFocus();
      }
      else {
        return;
      }
    }
  }

}
