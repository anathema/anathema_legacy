/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static org.junit.Assert.*;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.icon.EmptyIcon;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.TableColumnConfigurator;

import org.easymock.EasyMock;
import org.junit.Test;

public class TableColumnConfiguratorTest {

  @Test
  public void rendersHeaderWithSpecifiedToolTip() throws Exception {
    final Icon icon = new EmptyIcon();
    final ITableColumnViewSettings<?> mock = EasyMock
        .createNiceMock(ITableColumnViewSettings.class);
    EasyMock.expect(mock.getEditor()).andReturn(null).anyTimes();
    EasyMock.expect(mock.getRenderer()).andReturn(null).anyTimes();
    EasyMock.expect(mock.getIcon()).andReturn(icon);
    EasyMock.expect(mock.getToolTipText()).andReturn("tip"); //$NON-NLS-1$
    EasyMock.replay(mock);
    final JTable table = new JTable(1, 1);
    TableColumnConfigurator.configureTableColumns(table, new ITableColumnViewSettings<?>[]{ mock });
    final TableCellRenderer renderer = table.getColumnModel().getColumn(0).getHeaderRenderer();
    final Component component = renderer.getTableCellRendererComponent(
        new JTable(),
        null,
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals("tip", label.getToolTipText()); //$NON-NLS-1$
  }

  @Test
  public void rendersHeaderWithSpecifiedIcon() throws Exception {
    final Icon icon = new EmptyIcon();
    final ITableColumnViewSettings<?> mock = EasyMock
        .createNiceMock(ITableColumnViewSettings.class);
    EasyMock.expect(mock.getEditor()).andReturn(null).anyTimes();
    EasyMock.expect(mock.getRenderer()).andReturn(null).anyTimes();
    EasyMock.expect(mock.getIcon()).andReturn(icon);
    EasyMock.expect(mock.getToolTipText()).andReturn(null);
    EasyMock.replay(mock);
    final JTable table = new JTable(1, 1);
    TableColumnConfigurator.configureTableColumns(table, new ITableColumnViewSettings<?>[]{ mock });
    final TableCellRenderer renderer = table.getColumnModel().getColumn(0).getHeaderRenderer();
    final Component component = renderer.getTableCellRendererComponent(
        new JTable(),
        null,
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals(icon, label.getIcon());
  }
}