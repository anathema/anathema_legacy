/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.column.ITableColumn;

public class ListTableFactory {

  public static <T> ListTable<T> create(
      final List<T> list,
      final Iterable<ITableColumnFactory<T>> columnFactories,
      final ObjectModel<T> selectionModel,
      final IListTableConfiguration tableConfiguration) {
    final IMutableListModel<T> model = new DefaultListModel<T>(list);
    List<ITableColumn> columns = new ArrayList<ITableColumn>();
    for (ITableColumnFactory<T> factory : columnFactories) {
      columns.add(factory.create(model));
    }
    return new ListTable<T>(
        tableConfiguration,
        model,
        columns,
        new DefaultListModel<T>(),
        selectionModel);
  }
}
