/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.table.IListModelTableColumnSettings;
import net.disy.commons.swing.table.SmartTableModel;
import net.disy.commons.swing.util.GuiUtilities;

public class MutableListTableModel<R> extends SmartTableModel {

  private final IListModel<R> listModel;

  private final IMutableListModel<R> selectionModel;

  public MutableListTableModel(
      IListModelTableColumnSettings[] settings,
      IListModel<R> listModel,
      IMutableListModel<R> selectionModel) {
    super(settings, false, listModel);
    this.listModel = listModel;
    this.selectionModel = selectionModel;
    for (IListModelTableColumnSettings setting : settings) {
      setting.setListModel(listModel);
    }
    listModel.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        GuiUtilities.invokeLaterIfNecessary(new Runnable() {
          @Override
          public void run() {
            IMutableListModel<R> selectionModelCopy = new DefaultListModel<R>(
                MutableListTableModel.this.selectionModel.getItemList());

            fireTableDataChanged();

            MutableListTableModel.this.selectionModel.clear();
            MutableListTableModel.this.selectionModel.add(selectionModelCopy.getItemList());
          }
        });
      }
    });
  }

  @Override
  public int getRowCount() {
    return listModel.getItemCount();
  }

  public R getRowAt(int rowIndex) {
    return listModel.getItem(rowIndex);
  }

}
