// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

//NOT_PUBLISHED
public class ConstantValuesProvider implements IComboBoxValuesProvider {

  private final Object[] values;

  public ConstantValuesProvider(Object[] values) {
    this.values = values;
  }

  public Object[] getValues(int rowIndex) {
    return values;
  }

}
