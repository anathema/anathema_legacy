/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.column.test;

import static org.junit.Assert.*;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.TableModel;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.smarttable.column.RowObjectTable;
import net.disy.commons.swing.smarttable.column.SmartTableColumn;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.testing.ComponentFinder;

import org.junit.Test;

public class RowObjectTableTest {

  @SuppressWarnings("unchecked")
  @Test
  public void testBugCAD148() {
    final SmartTableColumn<String> column0 = new SmartTableColumn<String>("0", //$NON-NLS-1$
        new StringTableColumnSettings());
    final SmartTableColumn<String> column1 = new SmartTableColumn<String>("1", //$NON-NLS-1$
        new StringTableColumnSettings());
    final RowObjectTable<String> table = new RowObjectTable<String>(
        new String[]{},
        column0,
        column1);
    table.update(new String[]{ "a", "b", "c" }); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    table.update(new String[]{ "foo", "bar", "foobar" }); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$

    final JTable visualizedTable = (JTable) ComponentFinder.find(table
        .getContent(), new IPredicate<Component>() {
      @Override
      public boolean evaluate(Component value) {
        return value instanceof JTable;
      }
    });
    final TableModel tableModel = visualizedTable.getModel();
    assertEquals("foo", tableModel.getValueAt(0, 0)); //$NON-NLS-1$
    assertEquals("bar", tableModel.getValueAt(1, 0)); //$NON-NLS-1$
    assertEquals("foobar", tableModel.getValueAt(2, 0)); //$NON-NLS-1$
    assertEquals("foo", tableModel.getValueAt(0, 1)); //$NON-NLS-1$
    assertEquals("bar", tableModel.getValueAt(1, 1)); //$NON-NLS-1$
    assertEquals("foobar", tableModel.getValueAt(2, 1)); //$NON-NLS-1$
  }
}