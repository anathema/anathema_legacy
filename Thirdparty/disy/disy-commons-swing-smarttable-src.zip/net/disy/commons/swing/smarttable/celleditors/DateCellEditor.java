/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.text.DateFormat;
import java.text.Format;

import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DateFormatter;

import net.disy.commons.core.util.DateRange;

public class DateCellEditor extends AbstractFormattedCellEditor {

  private DateFormatter formatter;

  public DateCellEditor(final DateFormat format, final CellEditorNullValueStrategy nullValueStrategy) {
    super(format, nullValueStrategy, SwingConstants.LEFT);
  }

  @Override
  protected AbstractFormatter createFormatter(final Format format) {
    formatter = new DateFormatter((DateFormat) format);
    return formatter;
  }

  public void setAllowedRange(final DateRange range) {
    formatter.setMinimum(range.getFirstDay());
    formatter.setMaximum(range.getLastDay());
  }
}
