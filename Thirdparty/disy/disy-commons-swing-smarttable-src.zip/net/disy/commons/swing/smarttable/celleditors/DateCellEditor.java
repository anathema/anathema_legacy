//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import java.text.DateFormat;
import java.text.Format;

import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DateFormatter;

import net.disy.commons.core.util.DateRange;

// NOT_PUBLISHED
public class DateCellEditor extends AbstractFormattedCellEditor {

  private DateFormatter formatter;

  public DateCellEditor(DateFormat format, NullValueStrategy nullValueStrategy) {
    super(format, nullValueStrategy);
  }

  //@Overrides
  @Override
  protected AbstractFormatter createFormatter(Format format) {
    formatter = new DateFormatter((DateFormat) format);
    return formatter;
  }

  public void setAllowedRange(DateRange range) {
    formatter.setMinimum(range.getFirstDay());
    formatter.setMaximum(range.getLastDay());
  }
}
