/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.ui.IObjectUi;

public class ObjectUiStringFilter<T> implements IPredicate<T> {

  private final IObjectUi<T>[] objectUis;
  private final String filterText;

  public ObjectUiStringFilter(final IObjectUi<T>[] objectUis, final String filterText) {
    Ensure.ensureArgumentNotNull(objectUis);
    this.objectUis = objectUis;
    this.filterText = filterText;
  }

  @Override
  public boolean evaluate(final T value) {
    if (StringUtilities.isNullOrEmpty(filterText)) {
      return true;
    }
    for (int i = 0; i < objectUis.length; i++) {
      final String label = objectUis[i].getLabel(value);
      if (StringUtilities.isNullOrEmpty(label)) {
        continue;
      }
      if (label.toLowerCase().indexOf(filterText.toLowerCase()) >= 0) {
        return true;
      }
    }
    return false;
  }
}