//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

/* TODO 12.11.2004 (gebhard): Unfortunately the JSpinner does not work well as Cell Editor :-(
 Try an IntegerField instead?
 */

// NOT_PUBLISHED
public class IntegerCellEditor extends AbstractDelegatingCellEditor {

  private SpinnerNumberModel spinnerNumberModel;

  public IntegerCellEditor(int minimum, int maximum, int stepsize) {
    spinnerNumberModel = new SpinnerNumberModel(minimum, minimum, maximum, stepsize);
  }

  //@Overrides
  @Override
  protected final EditorDelegate createDelegate(JComponent editorComponent) {
    final JSpinner spinner = (JSpinner) editorComponent;
    return new EditorDelegate(this) {
      @Override
      public void setValue(Object value) {
        spinner.setModel(spinnerNumberModel);
        spinnerNumberModel.setValue(value);

        //selectall() Does not work :-(
        //        JComponent editor = spinner.getEditor();
        //        if (editor instanceof JSpinner.DefaultEditor) {
        //          JSpinner.DefaultEditor defaultEditor =(DefaultEditor) editor;
        //          defaultEditor.getTextField().selectAll();
        //        }
      }

      @Override
      public Object getCellEditorValue() {
        return spinnerNumberModel.getNumber();
      }
    };
  }

  //@Overrides
  @Override
  protected JComponent createEditorComponent() {
    return new JSpinner();
  }

}