/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.ui.IObjectUi;

public class UnfilteringStrategy<T> implements IFilterStrategy<T> {

  private SmartTable smartTable;
  private IUpdatableSelection selection;

  @Override
  public IListModel<T> createListModel(IListModel<T> originalModel, IObjectUi<T>[] objectUis) {
    return originalModel;
  }

  @Override
  public void updateFilter(IObjectUi<T>[] objectUis) {
    // nothing to do
  }

  @Override
  public void addFilterWidgets(JPanel panel, JComponent tableComponent) {
    // nothing to do
  }

  @Override
  public void attachTo(DeprecatedListTable<T> filterableListTable, SmartTable smartTable) {
    this.selection = filterableListTable;
    this.smartTable = smartTable;
  }

  @Override
  public void requestFocus() {
    smartTable.requestFocus();
  }

  @Override
  public void keepSelectionUpToDate(ObjectModel<T> selectionModel) {
    selectionModel.addChangeListener(new UpdateSelectionListener(selection));
  }

  @Override
  public void waitForFilteringFinished() {
    //nothing to do
  }
}