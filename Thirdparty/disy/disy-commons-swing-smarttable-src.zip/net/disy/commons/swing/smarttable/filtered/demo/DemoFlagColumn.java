/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.DoubleClickObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NullDoubleClickBehaviour;
import net.disy.commons.swing.smarttable.filtered.AbstractFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.CaseInsensitiveTrivialMatcher;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterMatchingStrategy;
import net.disy.commons.swing.smarttable.filtered.IFilteringValueConverter;
import net.disy.commons.swing.smarttable.filtered.NullFilterConfiguration;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.ui.IObjectUi;

public class DemoFlagColumn extends AbstractReadOnlyListModelColumn<ListTableDemoModelItem, Boolean> {

  private final IFilterConfiguration<Boolean> filterConfiguration;

  public DemoFlagColumn(final IListModel<ListTableDemoModelItem> listModel, final boolean filtered) {
    super(listModel);
    if (filtered) {
      filterConfiguration = new AbstractFilterConfiguration<Boolean>() {
        @Override
        public IFilterMatchingStrategy<Boolean> getMatchingStrategy() {
          return new CaseInsensitiveTrivialMatcher<Boolean>(
              new IFilteringValueConverter<Boolean>() {
                @Override
                public String convert(final Boolean rawValue) {
                  return rawValue ? "+" : "-";
                }
              });
        }
      };
    }
    else {
      filterConfiguration = new NullFilterConfiguration<Boolean>();
    }

  }

  @Override
  protected IListColumnValueConverter<ListTableDemoModelItem, Boolean> createRowToColumnValueAdapter() {
    return new IListColumnValueConverter<ListTableDemoModelItem, Boolean>() {

      @Override
      public Boolean getValue(final ListTableDemoModelItem listValue) {
        return listValue.isFlag();
      }
    };
  }

  @Override
  protected TableColumnConfiguration<Boolean> createConfiguration() {
    final IObjectUi<Boolean> flagUi = new AbstractObjectUi<Boolean>() {

      @Override
      public String getLabel(final Boolean value) {
        return value ? "+" : "-";
      }
    };

    final TableColumnConfiguration<Boolean> configuration = new TableColumnConfiguration<Boolean>(
        "Flag",
        Boolean.class,
        new DoubleClickObjectUiTableColumnSettings<Boolean>(
            flagUi,
            new NullDoubleClickBehaviour<Boolean>()));
    return configuration;
  }

  @Override
  public IFilterConfiguration<Boolean> getFilterConfiguration() {
    return filterConfiguration;
  }
}
