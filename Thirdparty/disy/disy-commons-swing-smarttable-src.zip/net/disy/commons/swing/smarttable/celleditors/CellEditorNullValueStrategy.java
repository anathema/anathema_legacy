/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JFormattedTextField.AbstractFormatter;

import net.disy.commons.swing.text.NullAsEmptyFormatterDecorator;

public enum CellEditorNullValueStrategy {

  EMPTY {
    @Override
    public AbstractFormatter decorateFormatter(final AbstractFormatter formatter) {
      return new NullAsEmptyFormatterDecorator(formatter);
    }
  },
  DISALLOW {
    @Override
    public AbstractFormatter decorateFormatter(final AbstractFormatter formatter) {
      return formatter;
    }
  };
  public abstract AbstractFormatter decorateFormatter(AbstractFormatter formatter);
}