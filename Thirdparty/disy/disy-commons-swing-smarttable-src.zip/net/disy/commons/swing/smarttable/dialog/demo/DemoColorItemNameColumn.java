/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;
import net.disy.commons.swing.smarttable.sorter.StringSorterConfiguration;

public final class DemoColorItemNameColumn extends AbstractReadOnlyListModelColumn<DemoColorItem, String> {
  public DemoColorItemNameColumn(final IListModel<DemoColorItem> listModel) {
    super(listModel);
  }

  @Override
  protected IListColumnValueConverter<DemoColorItem, String> createRowToColumnValueAdapter() {
    return new IListColumnValueConverter<DemoColorItem, String>() {
      @Override
      public String getValue(final DemoColorItem listValue) {
        return listValue == null ? null : listValue.getName();
      }
    };
  }

  @Override
  protected TableColumnConfiguration<String> createConfiguration() {
    final TableColumnConfiguration<String> configuration = new TableColumnConfiguration<String>(
        "Name",
        String.class,
        new StringTableColumnSettings());
    configuration.setSorterConfiguration(new StringSorterConfiguration());
    configuration.setFilterConfiguration(new ColorNameFilterStrategy());
    return configuration;
  }
}