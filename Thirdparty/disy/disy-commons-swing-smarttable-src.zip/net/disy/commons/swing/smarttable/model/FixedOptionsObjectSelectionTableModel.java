/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.model;

import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;

public class FixedOptionsObjectSelectionTableModel<T> extends AbstractTableModel {

  private final String[] columnNames;
  private final FixedOptionsObjectSelectionModel<T> selectionModel;

  public FixedOptionsObjectSelectionTableModel(
      final FixedOptionsObjectSelectionModel<T> selectionModel,
      final String activityColumnName,
      final String itemColumnName) {
    this.selectionModel = selectionModel;
    columnNames = new String[]{ activityColumnName, itemColumnName };
  }

  @Override
  public int getColumnCount() {
    return 2;
  }

  @Override
  public String getColumnName(final int column) {
    return columnNames[column];
  }

  @Override
  public int getRowCount() {
    return selectionModel.getAllValues().length;
  }

  @Override
  public Object getValueAt(final int rowIndex, final int columnIndex) {
    return columnIndex == 0
        ? selectionModel.isSelected(getItemForRow(rowIndex))
        : getItemForRow(rowIndex);
  }

  @Override
  public boolean isCellEditable(final int rowIndex, final int columnIndex) {
    return columnIndex == 0;
  }

  @Override
  public void setValueAt(final Object value, final int rowIndex, final int columnIndex) {
    if (columnIndex == 0) {
      selectionModel.setSelected(getItemForRow(rowIndex), (Boolean) value);
    }
  }

  private T getItemForRow(final int rowIndex) {
    return selectionModel.getAllValues()[rowIndex];
  }

}
