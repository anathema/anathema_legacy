/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;
import java.text.NumberFormat;

import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.SwingConstants;

public class NumberCellRenderer extends StringCellRenderer {

  private final NumberFormat format;

  public NumberCellRenderer() {
    this(NumberFormat.getNumberInstance());
  }

  public NumberCellRenderer(final NumberFormat format) {
    this.format = format;

  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    final JLabel component = (JLabel) super.getTableCellRendererComponent(table, value == null
        ? "" : format.format(value), //$NON-NLS-1$
        isSelected,
        hasFocus,
        row,
        column);
    component.setHorizontalAlignment(SwingConstants.RIGHT);
    return component;
  }
}