/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static java.lang.System.*;
import static org.mockito.Mockito.*;

import java.awt.event.KeyEvent;

import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.smarttable.filtered.EnterActionListener;
import net.disy.commons.swing.smarttable.filtered.FilteringStrategy;

import org.junit.Test;

@SuppressWarnings("unchecked")
public class EnterActionListener_Test {

  private final IListModel<String> listModel = mock(IListModel.class);
  private final IBlock block = mock(IBlock.class);
  private final FilteringStrategy<String> filterStrategy = mock(FilteringStrategy.class);
  private final EnterActionListener<String> listener = new EnterActionListener<String>(
      listModel,
      block,
      filterStrategy);

  @Test
  public void callsApplySingleFilterResultOnEnterWithSingleObjectInList() throws Exception {
    when(listModel.getItemCount()).thenReturn(1);
    sendKeyReleasedEvent(KeyEvent.VK_ENTER);
    verify(filterStrategy).applySingleFilterResult(block);
  }

  @Test
  public void callsLeaveFilterOnEnterWithMultipleObjectsInList() throws Exception {
    when(listModel.getItemCount()).thenReturn(2);
    sendKeyReleasedEvent(KeyEvent.VK_ENTER);
    verify(filterStrategy).leaveFilter();
  }

  @Test
  public void doesNotCallStrategyWhenKeyReleasedIsNotEnter() throws Exception {
    when(listModel.getItemCount()).thenReturn(2);
    sendKeyReleasedEvent(KeyEvent.VK_CANCEL);
    verifyZeroInteractions(filterStrategy);
  }

  @Test
  public void doesNotCallStrategyOnKeyPressed() throws Exception {
    when(listModel.getItemCount()).thenReturn(2);
    sendKeyPressedEvent(KeyEvent.VK_ENTER);
    verifyZeroInteractions(filterStrategy);
  }

  private void sendKeyReleasedEvent(int keyCode) {
    KeyEvent event = new KeyEvent(new JPanel(), 0, currentTimeMillis(), 0, keyCode, '0');
    listener.keyReleased(event);
  }

  private void sendKeyPressedEvent(int keyCode) {
    KeyEvent event = new KeyEvent(new JPanel(), 0, currentTimeMillis(), 0, keyCode, '0');
    listener.keyPressed(event);
  }
}