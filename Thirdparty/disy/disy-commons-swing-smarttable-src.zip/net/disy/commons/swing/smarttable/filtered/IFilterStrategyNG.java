/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.listtable.ListTable;

public interface IFilterStrategyNG<T> {

  public IListModel<T> createListModel(IListModel<T> originalModel);

  public void updateFilter();

  public void addFilterWidgets(JPanel panel, JComponent tableComponent);

  public void attachTo(ListTable<T> listTable);

  public void requestFocus();

  public void keepSelectionUpToDate(ObjectModel<T> selectionModel);

  public void waitForFilteringFinished();

  public boolean isFilteringNeeded();
}