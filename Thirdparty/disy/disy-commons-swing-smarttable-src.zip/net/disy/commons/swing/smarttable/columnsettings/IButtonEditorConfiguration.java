//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.Icon;

import net.disy.commons.swing.smarttable.celleditors.action.CellEditorAction;

// NOT_PUBLISHED
public interface IButtonEditorConfiguration {

  public CellEditorAction createAction(
      IEditStoppedHandler handler,
      int rowIndex,
      int columnIndex,
      Object value);

  public Icon getLargestButtonIcon();

  public String getLongestButtonLabel();

}