/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import static net.disy.commons.swing.layout.grid.GridDialogLayoutData.*;
import static net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory.*;

import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.table.TableModel;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.smarttable.ISmartTableConfiguration;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTableConfigurationBuilder;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.column.TableColumnToModelSettings;
import net.disy.commons.swing.smarttable.column.TableColumnToViewSettings;
import net.disy.commons.swing.smarttable.filtered.FilteringStrategyFactory;
import net.disy.commons.swing.smarttable.filtered.IFilterStrategyNG;
import net.disy.commons.swing.smarttable.sorter.DefaultColumnSorterFactory;
import net.disy.commons.swing.smarttable.sorter.ITableSorterFactory;
import net.disy.commons.swing.table.IListModelTableColumnSettings;

public class ListTable<T> extends SortableListTable<T> {

  public static <T> ListTable<T> createImmutable(
      final IListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel) {
    final DefaultListModel<T> model = new DefaultListModel<T>(listModel.getItemList());
    return new ListTable<T>(
        new ListTableConfigurationBuilder().build(),
        model,
        columns,
        new DefaultListModel<T>(),
        selectionModel);
  }

  public static <T> ListTable<T> createMutable(
      final IMutableListModel<T> model,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel) {
    return new ListTable<T>(
        new ListTableConfigurationBuilder().build(),
        model,
        columns,
        new DefaultListModel<T>(),
        selectionModel);
  }

  public static <T> ListTable<T> createMutable(
      final IListTableConfiguration configuration,
      final IMutableListModel<T> model,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel) {
    return new ListTable<T>(
        configuration,
        model,
        columns,
        new DefaultListModel<T>(),
        selectionModel);
  }

  public static <T> ListTable<T> createMutable(
      final IMutableListModel<T> model,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel) {
    return new ListTable<T>(
        new ListTableConfigurationBuilder().build(),
        model,
        columns,
        selectionModel,
        new ObjectModel<T>());
  }

  public static <T> ListTable<T> createMutable(
      final IMutableListModel<T> model,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final IFilterStrategyNG<T> filterStrategy) {
    return new ListTable<T>(
        model,
        columns,
        selectionModel,
        new ObjectModel<T>(),
        new DefaultColumnSorterFactory(columns),
        filterStrategy);
  }

  public static <T> ListTable<T> createMutable(
      final IMutableListModel<T> model,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel,
      final IFilterStrategyNG<T> filterStrategy) {
    return new ListTable<T>(
        model,
        columns,
        new DefaultListModel<T>(),
        selectionModel,
        new DefaultColumnSorterFactory(columns),
        filterStrategy);
  }

  private final IFilterStrategyNG<T> filterStrategy;
  private final Iterable<ITableColumn> columns;
  private Boolean sortedColumnsExist = null;

  ListTable(
      final IListTableConfiguration configuration,
      final IMutableListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel) {
    this(
        configuration,
        listModel,
        columns,
        selectionModel,
        objectSelectionModel,
        new DefaultColumnSorterFactory(columns));
  }

  protected ListTable(
      final IMutableListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ITableSorterFactory tableSorterFactory) {
    this(
        new ListTableConfigurationBuilder().build(),
        listModel,
        columns,
        selectionModel,
        objectSelectionModel,
        tableSorterFactory);
  }

  private ListTable(
      final IListTableConfiguration configuration,
      final IMutableListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ITableSorterFactory tableSorterFactory) {
    this(
        configuration,
        listModel,
        columns,
        selectionModel,
        objectSelectionModel,
        tableSorterFactory,
        new FilteringStrategyFactory<T>(columns).create());
  }

  private ListTable(
      final IMutableListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ITableSorterFactory tableSorterFactory,
      final IFilterStrategyNG<T> filterStrategy) {
    this(
        new ListTableConfigurationBuilder().build(),
        listModel,
        columns,
        selectionModel,
        objectSelectionModel,
        tableSorterFactory,
        filterStrategy);
  }

  private ListTable(
      final IListTableConfiguration configuration,
      final IMutableListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ITableSorterFactory tableSorterFactory,
      final IFilterStrategyNG<T> filterStrategy) {
    super(
        filterStrategy.createListModel(listModel),
        selectionModel,
        objectSelectionModel,
        buildSmartTableConfiguration(columns, configuration),
        tableSorterFactory,
        new ITableModelCreationStrategy<T>() {

          @Override
          public TableModel createTableModel(
              IListModel<T> aListModel,
              IMutableListModel<T> aSelectionModel) {
            return new MutableListTableModel(
                buildModelSettings(columns),
                aListModel,
                aSelectionModel);
          }

        });
    this.columns = columns;
    this.filterStrategy = filterStrategy;
    filterStrategy.attachTo(this);
    filterStrategy.keepSelectionUpToDate(objectSelectionModel);
    filterStrategy.updateFilter();
    updateSelection();

  }

  @SuppressWarnings({ "rawtypes", "unchecked" })
  private static ISmartTableConfiguration buildSmartTableConfiguration(
      final Iterable<ITableColumn> columns,
      IListTableConfiguration listTableConfiguration) {
    final ITableColumnViewSettings[] viewSettings = CollectionUtilities.toArray(
        columns,
        ITableColumnViewSettings.class,
        new TableColumnToViewSettings());

    final SmartTableConfigurationBuilder builder = new SmartTableConfigurationBuilder(viewSettings);
    builder.setSelectionMode(listTableConfiguration.getSelectionMode());
    for (ITableActionConfiguration actionConfiguration : listTableConfiguration
        .getTableActionConfigurations()) {
      builder.addTableActionConfiguration(actionConfiguration);
    }
    builder.setVisibleRowCount(listTableConfiguration.getVisibleRowCount());
    final ISmartTableConfiguration configuration = builder.build();
    return configuration;
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private static <T> IListModelTableColumnSettings<T, ?>[] buildModelSettings(
      final Iterable<ITableColumn> columns) {
    final List<IListModelTableColumnSettings> modelSettingsList = CollectionUtilities.transform(
        columns,
        new TableColumnToModelSettings());
    final IListModelTableColumnSettings[] modelSettings = CollectionUtilities.toArray(
        modelSettingsList,
        IListModelTableColumnSettings.class);
    return modelSettings;
  }

  @Override
  protected JPanel initTableContentPanel() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    final JComponent tableComponent = smartTable.getContent();
    filterStrategy.addFilterWidgets(panel, tableComponent);
    panel.add(tableComponent, createHorizontalSpanData(2, FILL_BOTH));
    return panel;
  }

  @Override
  public void requestFocus() {
    super.requestFocus();
    filterStrategy.requestFocus();
  }

  @Override
  public IMutableListModel<T> getListModel() {
    return (IMutableListModel<T>) super.getListModel();
  }

  public boolean filteredColumnsExist() {
    return filterStrategy.isFilteringNeeded();
  }

  public boolean sortedColumnsExist() {
    if (sortedColumnsExist == null) {
      sortedColumnsExist = initSortedColumnsExist();
    }
    return sortedColumnsExist;
  }

  private boolean initSortedColumnsExist() {
    boolean draftSorted = false;
    for (final ITableColumn<T, ?> column : columns) {
      if (column.getSorterConfiguration().isSortable()) {
        draftSorted = true;
        break;
      }
    }
    return draftSorted;
  }

  public boolean rowsCanBeMoved() {
    return !filteredColumnsExist() && !sortedColumnsExist();
  }
}