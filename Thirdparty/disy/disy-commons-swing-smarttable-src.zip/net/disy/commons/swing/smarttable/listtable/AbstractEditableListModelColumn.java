/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.swing.smarttable.column.AbstractTableColumn;
import net.disy.commons.swing.smarttable.column.IEditableListModelTableColumn;
import net.disy.commons.swing.smarttable.column.IMutableListColumnValueConverter;
import net.disy.commons.swing.smarttable.columnsettings.EditableListModelTableModelColumnSettings;
import net.disy.commons.swing.table.IListModelTableColumnSettings;

public abstract class AbstractEditableListModelColumn<L, C> extends AbstractTableColumn<L, C>
    implements
    IEditableListModelTableColumn<L, C> {

  private final IMutableListModel<L> listModel;

  private IMutableListColumnValueConverter<L, C> rowToColumnValueAdapter;

  private IListModelTableColumnSettings<L, C> modelSettings;

  public AbstractEditableListModelColumn(IMutableListModel<L> listModel) {
    super();
    this.listModel = listModel;
  }

  protected abstract IMutableListColumnValueConverter<L, C> createRowToColumnValueAdapter();

  @Override
  public IMutableListColumnValueConverter<L, C> getRowToColumnValueAdapter() {
    if (rowToColumnValueAdapter == null) {
      rowToColumnValueAdapter = createRowToColumnValueAdapter();
    }
    return rowToColumnValueAdapter;
  }

  @Override
  public IListModelTableColumnSettings<L, C> getModelSettings() {
    if (modelSettings == null) {
      createModelSettings();
    }
    return modelSettings;
  }

  protected void createModelSettings() {
    this.modelSettings = new EditableListModelTableModelColumnSettings<L, C>(
        listModel,
        getColumnName(),
        getColumnClass(),
        getRowToColumnValueAdapter());
  }

  @Override
  public boolean isEditable() {
    return true;
  }

}