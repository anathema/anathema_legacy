/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.table.IListModelTableColumnSettings;

public class ReadOnlyListModelTableModelColumnSettings<L, V>
    implements
    IListModelTableColumnSettings<L, V> {

  private IListModel<L> listModel;
  private final String columnName;
  private final Class<V> itemClass;
  private final IListColumnValueConverter<L, V> columnValueAdapter;

  public ReadOnlyListModelTableModelColumnSettings(
      IListModel<L> listModel,
      String columnName,
      Class<V> itemClass,
      IListColumnValueConverter<L, V> columnValueAdapter) {
    super();
    this.listModel = listModel;
    this.columnName = columnName;
    this.itemClass = itemClass;
    this.columnValueAdapter = columnValueAdapter;
  }

  @Override
  public String getColumnName() {
    return columnName;
  }

  @Override
  public Class<V> getItemClass() {
    return itemClass;
  }

  @Override
  public V getValueAt(int rowIndex) {
    L listItem = listModel.getItem(rowIndex);
    return columnValueAdapter.getValue(listItem);
  }

  @Override
  public void setValueAt(V value, int rowIndex) {
    // do nothing
  }

  @Override
  public boolean isCellEditable(int rowIndex) {
    return false;
  }

  @Override
  public void setListModel(IListModel<L> listModel) {
    this.listModel = listModel;
  }

}
