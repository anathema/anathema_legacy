//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable;

import javax.swing.Action;


// NOT_PUBLISHED
public interface ITableActionFactory {

  public Action createAction(SmartTable table);

}