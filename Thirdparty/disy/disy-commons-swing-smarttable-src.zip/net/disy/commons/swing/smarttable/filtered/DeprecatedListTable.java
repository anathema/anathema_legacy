/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import static net.disy.commons.swing.layout.grid.GridDialogLayoutData.FILL_BOTH;
import static net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory.createHorizontalSpanData;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.smarttable.ISmartTableConfiguration;
import net.disy.commons.swing.smarttable.listtable.ListTable;
import net.disy.commons.swing.smarttable.listtable.SortableListTable;
import net.disy.commons.swing.smarttable.sorter.DefaultSorterFactory;
import net.disy.commons.swing.smarttable.sorter.ITableSorterFactory;
import net.disy.commons.swing.ui.IObjectUi;

/** @deprecated As of 14.06.2011 (nagypal) Use {@link ListTable} instead */
@Deprecated
public class DeprecatedListTable<T> extends SortableListTable<T> {

  private final IFilterStrategy<T> filterStrategy;

  public DeprecatedListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final IObjectUi<T>[] objectUis,
      final String[] columnNames,
      final ISmartTableConfiguration configuration) {
    this(
        listModel,
        selectionModel,
        objectUis,
        columnNames,
        configuration,
        new FilteringStrategy<T>(),
        new DefaultSorterFactory());
  }

  public DeprecatedListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final IObjectUi<T>[] objectUis,
      final String[] columnNames,
      final ISmartTableConfiguration configuration,
      final IFilterStrategy<T> filterStrategy) {
    this(
        listModel,
        selectionModel,
        objectUis,
        columnNames,
        configuration,
        filterStrategy,
        new DefaultSorterFactory());
  }

  public DeprecatedListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final IObjectUi<T>[] objectUis,
      final String[] columnNames,
      final ISmartTableConfiguration configuration,
      final IFilterStrategy<T> filterStrategy,
      final ITableSorterFactory tableSorterFactory) {
    super(
        filterStrategy.createListModel(listModel, objectUis),
        selectionModel,
        columnNames,
        configuration,
        tableSorterFactory);
    this.filterStrategy = filterStrategy;
    filterStrategy.attachTo(this, smartTable);
    filterStrategy.keepSelectionUpToDate(selectionModel);
    filterStrategy.updateFilter(objectUis);
    updateSelection();
  }

  @Override
  protected JPanel initTableContentPanel() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    final JComponent tableComponent = smartTable.getContent();
    filterStrategy.addFilterWidgets(panel, tableComponent);
    panel.add(tableComponent, createHorizontalSpanData(2, FILL_BOTH));
    return panel;
  }

  @Override
  public void requestFocus() {
    super.requestFocus();
    filterStrategy.requestFocus();
  }
}