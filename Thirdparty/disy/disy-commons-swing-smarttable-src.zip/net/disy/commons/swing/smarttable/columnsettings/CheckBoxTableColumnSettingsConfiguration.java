/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.Icon;

import net.disy.commons.core.util.CastingTransformer;
import net.disy.commons.core.util.ITransformer;

public class CheckBoxTableColumnSettingsConfiguration {

  private int columnWidth;
  private Icon icon;
  private ITransformer<Object, Boolean> valueTransformer;
  private String tooltip;

  public CheckBoxTableColumnSettingsConfiguration() {
    columnWidth = 2;
    icon = null;
    valueTransformer = new CastingTransformer<Object, Boolean>();
    tooltip = null;
  }

  public int getColumnWidth() {
    return columnWidth;
  }

  public CheckBoxTableColumnSettingsConfiguration setColumnWidth(int columnWidth) {
    this.columnWidth = columnWidth;
    return this;
  }

  public Icon getIcon() {
    return icon;
  }

  public CheckBoxTableColumnSettingsConfiguration setIcon(Icon icon) {
    this.icon = icon;
    return this;
  }

  public ITransformer<Object, Boolean> getValueTransformer() {
    return valueTransformer;
  }

  public CheckBoxTableColumnSettingsConfiguration setValueTransformer(
      ITransformer<Object, Boolean> valueTransformer) {
    this.valueTransformer = valueTransformer;
    return this;
  }

  public String getTooltip() {
    return tooltip;
  }

  public CheckBoxTableColumnSettingsConfiguration setTooltip(String tooltip) {
    this.tooltip = tooltip;
    return this;
  }

}
