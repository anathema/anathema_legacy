/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.sorter;

import java.text.Collator;
import java.util.Comparator;

public final class StringSorterConfiguration extends ComparatorSorterConfiguration<String> {

  public StringSorterConfiguration() {
    super(createCollatorComparator());
  }

  private static Comparator<String> createCollatorComparator() {
    final Collator collator = Collator.getInstance();
    return new Comparator<String>() {
      @Override
      public int compare(final String o1, final String o2) {
        return collator.compare(o1, o2);
      }
    };
  }
}