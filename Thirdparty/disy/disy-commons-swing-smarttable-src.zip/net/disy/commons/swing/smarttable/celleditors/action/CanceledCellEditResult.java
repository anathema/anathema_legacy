//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors.action;


// NOT_PUBLISHED
public class CanceledCellEditResult implements ICellEditResult {

  public void accept(ICellEditResultVisitor visitor) {
    visitor.visitCanceled(this);
  }

}