//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors.action;


// NOT_PUBLISHED
public interface ICellEditResult {

  public void accept(ICellEditResultVisitor visitor);

}