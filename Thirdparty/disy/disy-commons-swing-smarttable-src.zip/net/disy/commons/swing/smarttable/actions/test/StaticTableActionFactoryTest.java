/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions.test;

import static org.junit.Assert.*;

import javax.swing.Action;

import net.disy.commons.swing.action.demo.DummySmartAction;
import net.disy.commons.swing.smarttable.actions.StaticTableActionFactory;

import org.junit.Test;

public class StaticTableActionFactoryTest {

  @Test
  public void allwaysCreateInitialAction() throws Exception {
    Action action = new DummySmartAction();
    StaticTableActionFactory factory = new StaticTableActionFactory(action);
    assertSame(action, factory.createAction(null));
    assertSame(action, factory.createAction(null));
  }
}