/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.smarttable.IconTableHeaderRenderer;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.IPreferredWidth;

public abstract class AbstractCheckBoxTableColumnSettings<T> extends AbstractTableColumnSettings<T> {

  public AbstractCheckBoxTableColumnSettings() {
    this(2);
  }

  public AbstractCheckBoxTableColumnSettings(final int columnCount) {
    this(columnCount, null);
  }

  public AbstractCheckBoxTableColumnSettings(final int columnWidth, final Icon icon) {
    super(columnWidth, icon);
  }

  public AbstractCheckBoxTableColumnSettings(final Icon icon) {
    super(new IPreferredWidth() {

      @Override
      public int getPreferredWidth() {
        return (int) (IconTableHeaderRenderer.getDefaultRendererWidth(icon) * 1.5);
      }
    }, icon);
  }

  protected abstract JCheckBox createRenderCheckBox(final Object value);

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return new TableCellRenderer() {
      @Override
      public Component getTableCellRendererComponent(
          final JTable table,
          final Object value,
          final boolean isSelected,
          final boolean hasFocus,
          final int rowIndex,
          final int columnIndex) {
        final JCheckBox checkBox = createRenderCheckBox(value);

        checkBox.setEnabled(table.isEnabled() && table.isCellEditable(rowIndex, columnIndex));
        final JPanel panel = wrapIntoPanel(
            table,
            isSelected,
            hasFocus,
            rowIndex,
            columnIndex,
            checkBox);
        return panel;
      }

    };
  }

  @Override
  public boolean isResizable() {
    return false;
  }

  public static JPanel wrapIntoPanel(
      final JTable table,
      final boolean isSelected,
      final boolean hasFocus,
      final int rowIndex,
      final int columnIndex,
      final Component component) {
    final JPanel panel = WrapInPanelAsCenteredComponentDecorator.wrapInPanelAsCentered(component);

    if (hasFocus && table.isCellEditable(rowIndex, columnIndex)) {
      component.setForeground(SwingColors.getTableFocusCellForegroundColor());
      panel.setForeground(SwingColors.getTableFocusCellForegroundColor());
      component.setBackground(SwingColors.getTableFocusCellBackgroundColor());
      panel.setBackground(SwingColors.getTableFocusCellBackgroundColor());
    }
    else if (isSelected) {
      component.setForeground(table.getSelectionForeground());
      panel.setForeground(table.getSelectionForeground());
      component.setBackground(table.getSelectionBackground());
      panel.setBackground(table.getSelectionBackground());
    }
    else {
      component.setForeground(table.getForeground());
      panel.setForeground(table.getForeground());
      component.setBackground(table.getBackground());
      panel.setBackground(table.getBackground());
    }
    return panel;
  }
}