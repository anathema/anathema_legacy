/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog;

import java.util.List;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

public class TableSelectionDialogPage<T> extends SmartDialogPage {

  private final ITableSelectionDialogConfiguration<T> configuration;
  private final TableSelectionDialogPanel<T> selectionPanel;

  public TableSelectionDialogPage(
      final List<T> items,
      final ITableSelectionDialogConfiguration<T> configuration) {
    this(items, items.size() > 0 ? items.get(0) : null, configuration);
  }

  public TableSelectionDialogPage(
      final List<T> items,
      final T selectedItem,
      final ITableSelectionDialogConfiguration<T> configuration) {
    super(configuration.getDefaultMessageText());
    this.configuration = configuration;
    final FixedOptionsObjectSelectionModel<T> selectionModel = new FixedOptionsObjectSelectionModel<T>(
        items);
    selectionModel.setSelectedValue(selectedItem);
    selectionPanel = new TableSelectionDialogPanel<T>(selectionModel, configuration);
  }

  public List<T> getSelectedItems() {
    return selectionPanel.getSelectedItems();
  }

  @Override
  public String getTitle() {
    return configuration.getTitle();
  }

  @Override
  public String getDescription() {
    return configuration.getDescription();
  }

  @Override
  protected void addPanels(final ISmartDialogPanelsBuilder builder) {
    builder.add(selectionPanel);
    final ISmartDialogPanel[] additionalPanels = configuration
        .createAdditionalPanels(selectionPanel.getSelectedItemModel());
    if (additionalPanels != null) {
      builder.add(additionalPanels);
    }
  }

  @Override
  public void requestFocus() {
    selectionPanel.requestFocus();
  }
}