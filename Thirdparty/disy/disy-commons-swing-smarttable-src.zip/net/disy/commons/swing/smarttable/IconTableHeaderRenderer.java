/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import java.awt.Component;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.RowSorter;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;

import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.icon.CompositeIcon;
import net.disy.commons.swing.icon.TranslatedIcon;

public class IconTableHeaderRenderer extends JLabel implements TableCellRenderer {

  private final Icon icon;
  private final String toolTipText;
  private static final Icon ascendingSortIcon = UIManager.getIcon("Table.ascendingSortIcon");
  private static final Icon descendingSortIcon = UIManager.getIcon("Table.descendingSortIcon");
  private static final Icon naturalSortIcon = UIManager.getIcon("Table.naturalSortIcon");

  public IconTableHeaderRenderer(final Icon icon) {
    this(icon, null);
  }

  public IconTableHeaderRenderer(final Icon icon, final String toolTipText) {
    Ensure.ensureArgumentNotNull(icon);
    this.icon = icon;
    this.toolTipText = toolTipText;
    setBorder(UIManager.getBorder("TableHeader.cellBorder")); //$NON-NLS-1$
    setHorizontalAlignment(SwingConstants.CENTER);
    setIcon(icon);
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    Icon sortIcon = naturalSortIcon;
    if (table.getRowSorter() != null) {
      RowSorter<? extends TableModel> rowSorter = table.getRowSorter();
      java.util.List<? extends RowSorter.SortKey> sortKeys = rowSorter.getSortKeys();
      if (sortKeys.size() > 0
          && sortKeys.get(0).getColumn() == table.convertColumnIndexToModel(column)) {
        switch (sortKeys.get(0).getSortOrder()) {
          case ASCENDING:
            sortIcon = ascendingSortIcon;
            break;
          case DESCENDING:
            sortIcon = descendingSortIcon;
            break;
          case UNSORTED:
            sortIcon = naturalSortIcon;
            break;
        }
      }
    }

    final JTableHeader header = table.getTableHeader();
    if (header != null) {
      setForeground(header.getForeground());
      setBackground(header.getBackground());
      setFont(header.getFont());
    }

    final Icon compositIcon = createIcon(sortIcon, icon);
    setIcon(compositIcon);

    if (toolTipText != null) {
      setToolTipText(toolTipText);
    }
    else {
      final String valueText = value == null ? null : String.valueOf(value);
      if (!StringUtilities.isNullOrEmpty(valueText)) {
        setToolTipText(valueText);
      }
    }

    return this;
  }

  public static Icon createIcon(Icon sortIcon, Icon icon) {
    if (sortIcon == null) {
      return icon;
    }
    final Icon translatedIcon = new TranslatedIcon(
        sortIcon,
        icon.getIconWidth(),
        (icon.getIconHeight() - sortIcon.getIconHeight()) / 2);
    final Icon compositIcon = new CompositeIcon(icon, translatedIcon);
    return compositIcon;
  }

  public static int getDefaultRendererWidth(final Icon icon) {
    Ensure.ensureArgumentNotNull(icon);
    int width = 0;
    List<Icon> list = CollectionUtilities.createList(
        ascendingSortIcon,
        descendingSortIcon,
        naturalSortIcon);

    for (Icon each : list) {
      width = Math.max(
          width,
          new IconTableHeaderRenderer(createIcon(each, icon)).getPreferredSize().width);
    }
    return width;
  }
}