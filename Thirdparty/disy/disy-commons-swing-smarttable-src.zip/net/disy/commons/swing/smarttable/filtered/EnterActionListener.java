/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.util.IBlock;

public final class EnterActionListener<T> extends KeyAdapter {

  private final IListModel<T> listModel;
  private final IBlock applySelection;
  private final FilteringStrategy<T> defaultFilterStrategy;

  public EnterActionListener(
      IListModel<T> listModel,
      IBlock applySelection,
      FilteringStrategy<T> defaultFilterStrategy) {
    this.listModel = listModel;
    this.applySelection = applySelection;
    this.defaultFilterStrategy = defaultFilterStrategy;
  }

  @Override
  public void keyReleased(final KeyEvent e) {
    if (e.getKeyCode() == KeyEvent.VK_ENTER) {
      if (listModel.getItemCount() == 1) {
        defaultFilterStrategy.applySingleFilterResult(applySelection);
      }
      else {
        defaultFilterStrategy.leaveFilter();
      }
      e.consume();
    }
  }
}