package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import net.disy.commons.swing.component.tristate.TriState;

public class DemoObjectFactory {
  private final Random random;

  public DemoObjectFactory(final long seed) {
    this.random = new Random(seed);
  }

  public List<DemoObject> createObjectList(final int numberOfObjects) {
    final List<DemoObject> objects = new ArrayList<DemoObject>();
    for (int i = 0; i < numberOfObjects; i++) {
      objects.add(createObject());
    }
    return objects;
  }

  public DemoObject createObject() {
    final Integer nummer = generateInteger(true);
    final String name = generateString();
    final Double value = generateDouble();
    final Boolean flag = generateBoolean();
    final Color color = generateColor();
    Date date = generateDate();
    final TriState state = generateTriState();
    final int notNullInteger = generateInteger(false);
    return new DemoObject(nummer, name, value, flag, color, date, notNullInteger, state);
  }

  private TriState generateTriState() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    return TriState.values()[this.random.nextInt(2)];
  }

  private Date generateDate() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    final Date date = new Date(random.nextLong());
    Calendar calendar = Calendar.getInstance();
    calendar.setTime(date);
    calendar.set(Calendar.YEAR, random.nextInt(5000) - 2500);
    return calendar.getTime();
  }

  private Color generateColor() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    return new Color(this.random.nextInt(16777215));
  }

  private String generateString() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    final int length = this.random.nextInt(32);
    final StringBuilder builder = new StringBuilder(length);
    for (int i = 0; i < length; i++) {
      builder.append(generateCharacter());
    }
    return builder.toString();
  }

  private char generateCharacter() {
    final int digit = this.random.nextInt(36);
    final char character = Character.forDigit(digit, 36);
    return character;
  }

  private Double generateDouble() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    return Double.valueOf(this.random.nextDouble());
  }

  private Boolean generateBoolean() {
    if (this.random.nextInt() % 17 == 0) {
      return null;
    }
    return Boolean.valueOf(this.random.nextBoolean());
  }

  private Integer generateInteger(boolean isNullable) {
    if (isNullable && this.random.nextInt() % 17 == 0) {
      return null;
    }
    return Integer.valueOf(this.random.nextInt());
  }
}
