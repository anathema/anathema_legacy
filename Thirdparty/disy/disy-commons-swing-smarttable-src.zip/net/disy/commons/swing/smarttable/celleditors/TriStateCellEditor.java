/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;

import net.disy.commons.swing.component.tristate.TriState;
import net.disy.commons.swing.component.tristate.TristateCheckBox;

public class TriStateCellEditor extends AbstractDelegatingCellEditor {

  private final boolean dontCareSelection;

  public TriStateCellEditor(final boolean dontCareSelection) {
    this.dontCareSelection = dontCareSelection;
  }

  @Override
  protected final EditorDelegate createDelegate(final JComponent editorComponent) {
    final TristateCheckBox checkBox = (TristateCheckBox) editorComponent;
    return new EditorDelegate(this, 1) {
      @Override
      public void setValue(final Object value) {
        checkBox.setState((TriState) value);
      }

      @Override
      public Object getCellEditorValue() {
        return checkBox.getState();
      }
    };
  }

  @Override
  protected JComponent createEditorComponent() {
    return new TristateCheckBox(dontCareSelection);
  }
}