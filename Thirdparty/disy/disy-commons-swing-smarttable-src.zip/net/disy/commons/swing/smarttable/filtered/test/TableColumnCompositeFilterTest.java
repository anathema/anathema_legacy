/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.filtered.DefaultFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.TableColumnCompositeFilter;

import org.junit.Test;

@SuppressWarnings("nls")
public class TableColumnCompositeFilterTest {

  public class DummyRow {
    private final String one;
    private final String two;

    public String getOne() {
      return one;
    }

    public String getTwo() {
      return two;
    }

    public DummyRow(String one, String two) {
      this.one = one;
      this.two = two;
    }

  }

  @Test
  public void nullValueDoesNotMatch() throws Exception {
    TableColumnCompositeFilter<DummyRow> cut = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "ggfdiojgfdoigd fdsf ds fdsfsd ");
    assertThat(cut.evaluate(null), is(false));
  }

  @Test
  public void emptyValueDoesNotMatch() throws Exception {
    TableColumnCompositeFilter<DummyRow> cut = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "ggfdiojgfdoigd fdsf ds fdsfsd ");
    assertThat(cut.evaluate(new DummyRow(null, null)), is(false));
    assertThat(cut.evaluate(new DummyRow("", "")), is(false));
  }

  @Test
  public void nullFilterAlwaysMatches() throws Exception {
    TableColumnCompositeFilter<DummyRow> cut = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        null);
    assertThat(cut.evaluate(new DummyRow(null, null)), is(true));
    assertThat(cut.evaluate(new DummyRow("", "")), is(true));
    assertThat(cut.evaluate(new DummyRow("foo", "bar")), is(true));
  }

  @Test
  public void emptylFilterAlwaysMatches() throws Exception {
    TableColumnCompositeFilter<DummyRow> cut = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "");
    assertThat(cut.evaluate(new DummyRow(null, null)), is(true));
    assertThat(cut.evaluate(new DummyRow("", "")), is(true));
    assertThat(cut.evaluate(new DummyRow("foo", "bar")), is(true));
  }

  @Test
  public void oneTokenMatches() throws Exception {

    DummyRow dummyRow = new DummyRow("FooBaz", "BarBaz");

    TableColumnCompositeFilter<DummyRow> filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "foo");
    assertThat(filter.evaluate(dummyRow), is(true));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "fooo");
    assertThat(filter.evaluate(dummyRow), is(false));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "bar");
    assertThat(filter.evaluate(dummyRow), is(true));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "barr");
    assertThat(filter.evaluate(dummyRow), is(false));
  }

  @Test
  public void multipleTokensMatch() throws Exception {

    DummyRow dummyRow = new DummyRow("FooBaz", "BarBaz");

    TableColumnCompositeFilter<DummyRow> filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "foo bar");
    assertThat(filter.evaluate(dummyRow), is(true));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "fooo bar");
    assertThat(filter.evaluate(dummyRow), is(false));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "foo barr");
    assertThat(filter.evaluate(dummyRow), is(false));

    filter = new TableColumnCompositeFilter<TableColumnCompositeFilterTest.DummyRow>(
        createMockTableColumns(),
        "fooo barr");
    assertThat(filter.evaluate(dummyRow), is(false));
  }

  private Iterable<ITableColumn> createMockTableColumns() {
    List<ITableColumn> mockColumns = new ArrayList<ITableColumn>();

    IFilterConfiguration<String> filterConfig = new DefaultFilterConfiguration();

    ITableColumn mockedColumn = mock(ITableColumn.class);
    when(mockedColumn.getFilterConfiguration()).thenReturn(filterConfig);
    when(mockedColumn.getRowToColumnValueAdapter()).thenReturn(
        new IListColumnValueConverter<DummyRow, String>() {
          @Override
          public String getValue(DummyRow listValue) {
            return listValue.getOne();
          }
        });

    mockColumns.add(mockedColumn);

    mockedColumn = mock(ITableColumn.class);
    when(mockedColumn.getFilterConfiguration()).thenReturn(filterConfig);
    when(mockedColumn.getRowToColumnValueAdapter()).thenReturn(
        new IListColumnValueConverter<DummyRow, String>() {
          @Override
          public String getValue(DummyRow listValue) {
            return listValue.getTwo();
          }
        });

    mockColumns.add(mockedColumn);

    return mockColumns;
  }

}