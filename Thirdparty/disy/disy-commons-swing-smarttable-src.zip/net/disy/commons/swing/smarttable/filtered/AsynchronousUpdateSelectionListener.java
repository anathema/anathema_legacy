/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.util.GuiUtilities;

public final class AsynchronousUpdateSelectionListener<T> implements IChangeListener {
  private final ObjectModel<T> selectionModel;
  private final IListModel<T> listModel;
  private final IUpdatableSelection selection;

  public AsynchronousUpdateSelectionListener(
      final IUpdatableSelection selection,
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel) {
    this.selection = selection;
    this.listModel = listModel;
    this.selectionModel = selectionModel;
  }

  @Override
  public void stateChanged() {
    if (listModel.getItemCount() == 0) {
      return;
    }
    GuiUtilities.invokeLaterIfNecessary(new Runnable() {
      @Override
      public void run() {
        if (listModel.getItemCount() == 0) {
          return;
        }
        final T selectedValue = selectionModel.getValue();
        if (!listModel.getItemList().contains(selectedValue)) {
          selectionModel.setValue(listModel.getItem(0));
        }
        selection.updateSelection();
      }
    });
  }
}