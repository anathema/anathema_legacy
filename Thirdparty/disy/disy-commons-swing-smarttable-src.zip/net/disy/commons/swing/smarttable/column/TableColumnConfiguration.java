/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.column;

import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.NullFilterConfiguration;
import net.disy.commons.swing.smarttable.sorter.ITableSorterConfiguration;
import net.disy.commons.swing.smarttable.sorter.NullSorterConfiguration;

public class TableColumnConfiguration<C> {

  private final Class<C> columnClass;

  private final String columnName;

  private final ITableColumnViewSettings<C> columnViewSettings;

  private ITableSorterConfiguration<C> sorterConfiguration;

  private IFilterConfiguration<C> filterConfiguration;

  public TableColumnConfiguration(
      String columnName,
      Class<C> columnClass,
      ITableColumnViewSettings<C> columnViewSettings) {
    this.columnName = columnName;
    this.columnClass = columnClass;
    this.sorterConfiguration = new NullSorterConfiguration<C>();
    this.filterConfiguration = new NullFilterConfiguration<C>();
    this.columnViewSettings = columnViewSettings;
  }

  public ITableSorterConfiguration<C> getSorterConfiguration() {
    return sorterConfiguration;
  }

  public TableColumnConfiguration<C> setSorterConfiguration(
      ITableSorterConfiguration<C> sorterConfiguration) {
    this.sorterConfiguration = sorterConfiguration;
    return this;
  }

  public IFilterConfiguration<C> getFilterConfiguration() {
    return filterConfiguration;
  }

  public TableColumnConfiguration<C> setFilterConfiguration(
      IFilterConfiguration<C> filterConfiguration) {
    this.filterConfiguration = filterConfiguration;
    return this;
  }

  public Class<C> getColumnClass() {
    return columnClass;
  }

  public String getColumnName() {
    return columnName;
  }

  public ITableColumnViewSettings<C> getColumnViewSettings() {
    return columnViewSettings;
  }

}
