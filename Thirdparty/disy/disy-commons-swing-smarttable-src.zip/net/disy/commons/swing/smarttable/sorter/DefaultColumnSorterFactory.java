/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.sorter;

import javax.swing.RowSorter;
import javax.swing.table.TableModel;

import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.column.TableColumnToSorterConfiguration;

public final class DefaultColumnSorterFactory implements ITableSorterFactory {

  private final ITableSorterConfiguration[] sorterConfigs;

  public DefaultColumnSorterFactory(Iterable<ITableColumn> columns) {
    sorterConfigs = (ITableSorterConfiguration[]) CollectionUtilities.toArray(
        columns,
        ITableSorterConfiguration.class,
        new TableColumnToSorterConfiguration());
  }

  @Override
  public RowSorter<TableModel> create(TableModel model) {
    return new SmartTableRowSorter(sorterConfigs, model);
  }
}