/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public final class AddRowTableAction extends SmartAction {
  private final SmartTable table;
  private final IAdditionPerformer additionPerformer;

  public AddRowTableAction(
      final IActionConfiguration configuration,
      final SmartTable table,
      final IAdditionPerformer additionPerformer) {
    super(configuration);
    this.table = table;
    this.additionPerformer = additionPerformer;
  }

  @Override
  protected void execute(final Component parentComponent) {
    table.stopCellEditing();
    if (additionPerformer.performAdd(parentComponent)) {
      table.scrollToAndSelect(table.getTable().getModel().getRowCount() - 1);
      table.requestFocus();
    }
  }
}