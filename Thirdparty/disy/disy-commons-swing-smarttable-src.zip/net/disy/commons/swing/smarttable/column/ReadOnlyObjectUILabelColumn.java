/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.column;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.smarttable.IObjectSelectionStrategy;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.columnsettings.DoubleClickObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NullDoubleClickBehaviour;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;
import net.disy.commons.swing.ui.IObjectUi;

public class ReadOnlyObjectUILabelColumn<L> extends AbstractReadOnlyListModelColumn<L, L> {

  private final IObjectSelectionStrategy<L> doubleClickBehaviour;
  private final IObjectUi<L> objectUi;
  private final String columnName;
  private final Class<L> columnClass;

  public ReadOnlyObjectUILabelColumn(
      IListModel<L> listModel,
      String columnName,
      Class<L> columnClass,
      IObjectUi<L> objectUi) {
    this(listModel, columnName, columnClass, objectUi, null);
  }

  public ReadOnlyObjectUILabelColumn(
      IListModel<L> listModel,
      String columnName,
      Class<L> columnClass,
      IObjectUi<L> objectUi,
      IObjectSelectionStrategy<L> doubleClickBehaviour) {
    super(listModel);
    if (doubleClickBehaviour == null) {
      this.doubleClickBehaviour = new NullDoubleClickBehaviour<L>();
    }
    else {
      this.doubleClickBehaviour = doubleClickBehaviour;
    }
    this.objectUi = objectUi;
    this.columnName = columnName;
    this.columnClass = columnClass;
  }

  @Override
  protected IListColumnValueConverter<L, L> createRowToColumnValueAdapter() {
    return new IdentityListColumnValueConverter<L>();
  }

  @Override
  protected TableColumnConfiguration<L> createConfiguration() {

    ITableColumnViewSettings<L> viewSettings = new DoubleClickObjectUiTableColumnSettings<L>(
        objectUi,
        doubleClickBehaviour);
    TableColumnConfiguration<L> configuration = new TableColumnConfiguration<L>(
        columnName,
        columnClass,
        viewSettings);
    return configuration;
  }

}
