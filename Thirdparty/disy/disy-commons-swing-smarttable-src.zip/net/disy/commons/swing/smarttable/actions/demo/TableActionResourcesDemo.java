//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.actions.demo;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.swing.icon.demo.AbstractIconResourcesDemo;
import net.disy.commons.swing.smarttable.actions.TableActionResources;

// NOT_PUBLISHED
public class TableActionResourcesDemo extends AbstractIconResourcesDemo {
  
  public void demo() throws IllegalAccessException, InvocationTargetException {
    showStaticIcons(TableActionResources.class);
  }

}