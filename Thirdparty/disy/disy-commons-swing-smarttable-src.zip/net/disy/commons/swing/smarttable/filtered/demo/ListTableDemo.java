/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.actions.AddRowTableActionFactory;
import net.disy.commons.swing.smarttable.actions.EditSelectedRowActionFactory;
import net.disy.commons.swing.smarttable.actions.IAdditionPerformer;
import net.disy.commons.swing.smarttable.actions.MoveRowDownTableActionFactory;
import net.disy.commons.swing.smarttable.actions.MoveRowUpTableActionFactory;
import net.disy.commons.swing.smarttable.actions.RemoveRowsTableActionFactory;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.listtable.ListTable;
import net.disy.commons.swing.smarttable.sorter.ISortedRowMapper;
import net.disy.commons.swing.smarttable.sorter.NullSorterConfiguration;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
@SuppressWarnings("nls")
public class ListTableDemo extends SwingDemoCase {

  @Demo
  public void nonSortableEditableTableWithMoveButtons() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, false);
    for (final ITableColumn<ListTableDemoModelItem, ?> column : columns) {
      column.setSorterConfiguration(new NullSorterConfiguration());
    }
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableTable() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, false);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableFilterableTable() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, true);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableTableWithAddRemove() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, false);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableTableWithAddRemoveEdit() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, false);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    addEditAction(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableFilterableTableWithAddRemove() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, true);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableFilterableTableWithAddRemoveEdit() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, true);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    addEditAction(table);
    show(table.getContent());
  }
  
  @Demo
  public void smallSortableEditableFilterableTableWithAddRemoveEdit() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createSmallModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, true);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    addEditAction(table);
    show(table.getContent());
  }

  @Demo
  public void sortableEditableFilterableTableWithAddRemoveEditAndMultipleSelection() {
    final DefaultListModel<ListTableDemoModelItem> model = DemoListTableFactory.createModel();
    final Iterable<ITableColumn> columns = DemoListTableFactory.createColumns(model, true);
    final ListTable<ListTableDemoModelItem> table = createTable(columns, model);
    addMoveActions(table);
    addAddRemoveActions(table);
    addEditAction(table);
    table.getSmartTable().setSelectionMode(ListSelectionMode.MULTIPLE_INTERVAL_SELECTION);
    show(table.getContent());
  }

  private ListTable<ListTableDemoModelItem> createTable(
      final Iterable<ITableColumn> columns,
      final IMutableListModel<ListTableDemoModelItem> model) {
    ObjectModel<ListTableDemoModelItem> selectionModel = new ObjectModel<ListTableDemoModelItem>();
    selectionModel.setValue(model.getItem(2));
    final ListTable<ListTableDemoModelItem> table = ListTable.createMutable(
        model,
        columns,
        selectionModel);
    return table;
  }

  private void addEditAction(final ListTable<ListTableDemoModelItem> table) {
    table.addActionFactory(new EditSelectedRowActionFactory(new IActionConfiguration() {

      @Override
      public String getToolTipText() {
        return "Bearbeiten";
      }

      @Override
      public String getName() {
        return "Bearbeiten";
      }

      @Override
      public Icon getIcon() {
        return null;
      }
    }) {

      @Override
      protected boolean performEditRow(Component parentComponent, int index) {
        final int modelIndex = table.getSortedRowMapper().getModelIndex(index);
        final ListTableDemoModelItem item = table.getListModel().getItem(modelIndex);
        final UserDialog dialog = new UserDialog(parentComponent, new AbstractDialogPage("") {

          @Override
          public JComponent createContent() {
            JPanel panel = new JPanel();
            panel.setLayout(new GridDialogLayout(2, false));
            panel.add(new JLabel("Name"));
            panel.add(new JTextArea(item.getName()));
            panel.add(new JLabel("Nummer"));
            panel.add(new JTextArea("" + item.getNumber()));
            return panel;
          }

          @Override
          public String getTitle() {
            return "Daten anzeigen (Änderungen werden nicht übernommen)";
          }

          @Override
          public IBasicMessage createCurrentMessage() {
            return getDefaultMessage();
          }
        });
        dialog.show();
        return false;
      }
    });
  }

  private void addAddRemoveActions(final ListTable<ListTableDemoModelItem> table) {
    final ISortedRowMapper sortedRowMapper = table.getSortedRowMapper();
    final IMutableListModel<ListTableDemoModelItem> model = table.getListModel();
    table.addActionFactory(new AddRowTableActionFactory(new IAdditionPerformer() {
      @Override
      public boolean performAdd(final Component parent) {
        model.add(new ListTableDemoModelItem("new item", 999, true));
        return true;
      }
    }));
    table.addActionFactory(new RemoveRowsTableActionFactory() {
      @Override
      protected boolean performRemove(final Component parentComponent, final int[] rowIndices) {
        List<ListTableDemoModelItem> itemsToRemove = new ArrayList<ListTableDemoModelItem>(
            rowIndices.length);
        for (int i = 0; i < rowIndices.length; i++) {
          ListTableDemoModelItem item = model.getItem(sortedRowMapper.getModelIndex(rowIndices[i]));
          itemsToRemove.add(item);
        }
        model.remove(itemsToRemove);
        return true;
      }
    });

  }

  private void addMoveActions(final ListTable<ListTableDemoModelItem> table) {
    if (table.rowsCanBeMoved()) {

      final IMutableListModel<ListTableDemoModelItem> model = table.getListModel();
      final ObjectModel<ListTableDemoModelItem> selectionModel = table.getSelectionObjectModel();

      table.addActionFactory(new MoveRowUpTableActionFactory() {

        @Override
        protected boolean performMoveUp(final int rowIndex) {
          final ListTableDemoModelItem value = selectionModel.getValue();
          final int index = model.indexOf(value);
          if (index > 0) {
            final ListTableDemoModelItem valueAbove = model.getItem(index - 1);
            model.setItem(value, index - 1);
            model.setItem(valueAbove, index);
            selectionModel.setValue(value);
            return true;
          }
          return false;
        }
      });

      table.addActionFactory(new MoveRowDownTableActionFactory() {

        @Override
        protected boolean performMoveDown(final int rowIndex) {
          final ListTableDemoModelItem value = selectionModel.getValue();
          final int index = model.indexOf(value);
          if (index < model.getItemCount() - 1) {
            final ListTableDemoModelItem valueBelow = model.getItem(index + 1);
            model.setItem(value, index + 1);
            model.setItem(valueBelow, index);
            selectionModel.setValue(value);
            return true;
          }
          return false;
        }
      });
    }

  }
}