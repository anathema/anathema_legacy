/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import static net.disy.commons.swing.layout.grid.GridDialogLayoutData.FILL_BOTH;
import static net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory.createHorizontalSpanData;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableModel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.ISmartTableConfiguration;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.SmartTableConfigurationBuilder;
import net.disy.commons.swing.smarttable.SortedRowMapper;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.column.TableColumnToColumnName;
import net.disy.commons.swing.smarttable.column.TableColumnToModelSettings;
import net.disy.commons.swing.smarttable.column.TableColumnToViewSettings;
import net.disy.commons.swing.smarttable.filtered.IUpdatableSelection;
import net.disy.commons.swing.smarttable.sorter.DefaultSorterFactory;
import net.disy.commons.swing.smarttable.sorter.ISortedRowMapper;
import net.disy.commons.swing.smarttable.sorter.ITableSorterFactory;
import net.disy.commons.swing.table.IListModelTableColumnSettings;
import net.disy.commons.swing.table.ITableModelColumnSettings;
import net.disy.commons.swing.table.ListTableModel;

public class SortableListTable<T> implements IUpdatableSelection {

  protected final IListModel<T> listModel;
  private final IMutableListModel<T> selectionModel;
  private final ObjectModelToListModelWrapper<T> selectionWrapper;
  protected final SmartTable smartTable;
  private JComponent content;
  private final ISortedRowMapper sortedRowMapper;

  public IListModel<T> getListModel() {
    return listModel;
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel) {
    this(listModel, columns, selectionModel, new DefaultSorterFactory());
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final ObjectModel<T> selectionModel,
      final ITableSorterFactory tableSorterFactory) {
    this(
        listModel,
        selectionModel,
        buildColumnNames(columns),
        buildSmartTableConfiguration(columns),
        tableSorterFactory);
  }

  //  public SortableListTable(
  //      final IListModel<T> listModel,
  //      final Iterable<ITableColumn> columns,
  //      final ObjectModel<T> selectionModel,
  //      final ITableSorterFactory tableSorterFactory,
  //      final ITableModelCreationStrategy creationStrategy) {
  //    this(
  //        listModel,
  //        selectionModel,
  //        buildSmartTableConfiguration(columns),
  //        tableSorterFactory,
  //        creationStrategy);
  //  }

  public SortableListTable(
      final IListModel<T> listModel,
      final Iterable<ITableColumn> columns,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ITableSorterFactory tableSorterFactory,
      final ITableModelCreationStrategy modelCreationStrategy) {
    this(
        listModel,
        selectionModel,
        objectSelectionModel,
        buildSmartTableConfiguration(columns),
        tableSorterFactory,
        modelCreationStrategy);
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final String[] columnNames,
      final ISmartTableConfiguration configuration) {
    this(listModel, selectionModel, columnNames, configuration, new DefaultSorterFactory());
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final String[] columnNames,
      final ISmartTableConfiguration configuration,
      final ITableSorterFactory tableSorterFactory) {
    this(
        listModel,
        selectionModel,
        configuration,
        tableSorterFactory,
        new ITableModelCreationStrategy<T>() {

          @Override
          public TableModel createTableModel(
              IListModel<T> aListModel,
              IMutableListModel<T> selectionModel) {
            return new ListTableModel<T>(aListModel, columnNames);
          }
        });
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final ObjectModel<T> selectionModel,
      final ISmartTableConfiguration configuration,
      final ITableSorterFactory tableSorterFactory,
      final ITableModelCreationStrategy modelCreationStrategy) {
    this(
        listModel,
        new net.disy.commons.core.list.DefaultListModel<T>(),
        selectionModel,
        configuration,
        tableSorterFactory,
        modelCreationStrategy);
  }

  public SortableListTable(
      final IListModel<T> listModel,
      final IMutableListModel<T> selectionModel,
      final ObjectModel<T> objectSelectionModel,
      final ISmartTableConfiguration configuration,
      final ITableSorterFactory tableSorterFactory,
      final ITableModelCreationStrategy modelCreationStrategy) {
    this.listModel = listModel;
    this.selectionModel = selectionModel;
    this.selectionWrapper = new ObjectModelToListModelWrapper<T>(
        selectionModel,
        objectSelectionModel);
    final TableModel tableModel = modelCreationStrategy.createTableModel(listModel, selectionModel);
    final RowSorter<TableModel> tableRowSorter = tableSorterFactory.create(tableModel);
    sortedRowMapper = new SortedRowMapper(tableRowSorter);
    this.listModel.addChangeListener(sortedRowMapper);
    this.smartTable = createSmartTable(configuration, tableModel, tableRowSorter);
    updateSelection();
  }

  @SuppressWarnings({ "rawtypes", "unchecked" })
  private static ISmartTableConfiguration buildSmartTableConfiguration(
      final Iterable<ITableColumn> columns) {
    final ITableColumnViewSettings[] viewSettings = CollectionUtilities.toArray(
        columns,
        ITableColumnViewSettings.class,
        new TableColumnToViewSettings());

    final SmartTableConfigurationBuilder builder = new SmartTableConfigurationBuilder(viewSettings);
    final ISmartTableConfiguration configuration = builder.build();
    return configuration;
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private static ITableModelColumnSettings[] buildModelSettings(final Iterable<ITableColumn> columns) {
    final ITableModelColumnSettings[] modelSettings = CollectionUtilities.toArray(
        columns,
        IListModelTableColumnSettings.class,
        new TableColumnToModelSettings());
    return modelSettings;
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  private static <T> String[] buildColumnNames(final Iterable<ITableColumn> columns) {
    final List<String> columnNamesList = CollectionUtilities.transform(
        columns,
        new TableColumnToColumnName());
    final String[] columnNames = CollectionUtilities.toArray(columnNamesList, String.class);
    return columnNames;
  }

  private SmartTable createSmartTable(
      final ISmartTableConfiguration configuration,
      final TableModel tableModel,
      final RowSorter<TableModel> tableRowSorter) {
    final JTable table = new JTable();
    table.setRowSorter(tableRowSorter);

    final SmartTable draftSmartTable = new SmartTable(table, tableModel, configuration);
    draftSmartTable.setSelectionMode(ListSelectionMode.SINGLE_SELECTION);
    draftSmartTable.addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(final ListSelectionEvent e) {

        List<T> selectedValues = new ArrayList<T>();
        int[] selectedRows = draftSmartTable.getSelectedRows();
        for (int i = 0; i < selectedRows.length; i++) {
          int selectedRowIndex = selectedRows[i];
          final int selectedModelIndex = selectedRowIndex == -1 ? -1 : sortedRowMapper
              .getModelIndex(selectedRowIndex);
          final T value = selectedModelIndex == -1 ? null : listModel.getItem(selectedModelIndex);
          selectedValues.add(value);

        }
        List<T> itemList = selectionModel.getItemList();
        for (T t : itemList) {
          if (!selectedValues.contains(t)) {
            selectionModel.remove(t);
          }
        }
        for (T t : selectedValues) {
          if (!itemList.contains(t)) {
            selectionModel.add(t);
          }
        }
      }
    });
    draftSmartTable.setFocusable(false);
    return draftSmartTable;
  }

  public void moveSelectionIndex(final int distance) {
    final int newRowIndex = smartTable.getSelectedRowIndex() + distance;
    secureScrollToAndSelect(newRowIndex);
  }

  protected void secureScrollToAndSelect(final int newRowIndex) {
    if (newRowIndex >= 0 && newRowIndex < getRowCount()) {
      scrollToAndSelect(newRowIndex);
    }
  }

  protected int getRowCount() {
    return smartTable.getRowCount();
  }

  protected void scrollToAndSelect(final int newRowIndex) {
    smartTable.scrollToAndSelect(newRowIndex);
  }

  public JComponent getContent() {
    if (content == null) {
      final JPanel panel = initTableContentPanel();
      this.content = panel;
    }
    return content;
  }

  protected JPanel initTableContentPanel() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    final JComponent tableComponent = smartTable.getContent();
    panel.add(tableComponent, createHorizontalSpanData(2, FILL_BOTH));
    return panel;
  }

  @Override
  public void updateSelection() {

    if (selectionModel.getItemCount() <= 0) {
      clearSelection();
      return;
    }
    final T selectedValue = selectionModel.getItem(0);
    listModel.doThreadSafe(new IBlock() {
      @Override
      public void execute() throws RuntimeException {
        final int modelIndex = listModel.indexOf(selectedValue);
        final int rowIndex = modelIndex == -1 ? -1 : sortedRowMapper.getSortedRow(modelIndex);
        if (rowIndex == -1) {
          clearSelection();
          return;
        }
        scrollToAndSelect(rowIndex);
      }
    });
  }

  private void clearSelection() {
    smartTable.getTable().getSelectionModel().clearSelection();
  }

  public void addDoubleClickActionListener(final ActionListener listener) {
    smartTable.addSelectionActionListener(listener);
  }

  public void requestFocus() {
    smartTable.assureSelectionVisible();
  }

  public ListSelectionModel getSelectionModel() {
    return smartTable.getSelectionModel();
  }

  public void addActionFactory(final ITableActionFactory actionFactory) {
    smartTable.addActionFactory(actionFactory);
  }

  public void addActions(final List<ITableActionConfiguration> actionConfigurations) {
    for (final ITableActionConfiguration actionConfiguration : actionConfigurations) {
      smartTable.addActionFactory(
          actionConfiguration.getTableActionFactory(),
          actionConfiguration.isDoubleClickOnItemAction());
    }
  }

  public void setToolbarStyleActions(final boolean toolbarStyleActions) {
    smartTable.setToolBarStyleButtons(toolbarStyleActions);
  }

  public void fireChangeEvent() {
    smartTable.fireChangeEvent();
  }

  public SmartTable getSmartTable() {
    return smartTable;
  }

  public ISortedRowMapper getSortedRowMapper() {
    return sortedRowMapper;
  }

  public ObjectModel<T> getSelectionObjectModel() {
    return this.selectionWrapper.getObjectModel();
  }

  public IListModel<T> getSelectionListModel() {
    return selectionModel;
  }
}