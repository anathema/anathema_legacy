/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import net.disy.commons.core.util.StringUtilities;

public class CaseInsensitiveTrivialMatcher<C> implements IFilterMatchingStrategy<C> {

  private final IFilteringValueConverter<C> valueConverter;

  public CaseInsensitiveTrivialMatcher(IFilteringValueConverter<C> valueConverter) {
    super();
    this.valueConverter = valueConverter;
  }

  @Override
  public boolean matches(C value, String filterExpression) {
    if (StringUtilities.isNullOrEmpty(filterExpression)) {
      return true;
    }
    if (value == null) {
      return false;
    }
    String stringValue = valueConverter.convert(value);
    if (stringValue.toLowerCase().indexOf(filterExpression.toLowerCase()) >= 0) {
      return true;
    }
    return false;
  }

}
