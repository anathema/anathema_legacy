/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

public class LongCellEditor extends AbstractDelegatingCellEditor {

  private final SpinnerNumberModel spinnerNumberModel;

  public LongCellEditor(final long minimum, final long maximum, final long stepsize) {
    spinnerNumberModel = new SpinnerNumberModel(minimum, minimum, maximum, stepsize);
  }

  @Override
  protected final EditorDelegate createDelegate(final JComponent editorComponent) {
    final JSpinner spinner = (JSpinner) editorComponent;
    return new EditorDelegate(this) {
      @Override
      public void setValue(final Object value) {
        spinner.setModel(spinnerNumberModel);
        spinnerNumberModel.setValue(value);
      }

      @Override
      public Object getCellEditorValue() {
        return spinnerNumberModel.getNumber();
      }
    };
  }

  @Override
  protected JComponent createEditorComponent() {
    return new JSpinner();
  }
}