package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.util.Date;

import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.component.tristate.TriState;

public class DemoObject {

  private final Integer integerValue;
  private final String name;
  private final Double doubleValue;
  private final Boolean flag;
  private final Color color;
  private final Date date;
  private final TriState state;
  private final int notNullInteger;

  public DemoObject(
      final Integer nummer,
      final String name,
      final Double value,
      final Boolean flag,
      final Color color,
      final Date date,
      final int notNullInteger,
      final TriState state) {
    this.integerValue = nummer;
    this.name = name;
    this.doubleValue = value;
    this.flag = flag;
    this.color = color;
    this.date = date;
    this.notNullInteger = notNullInteger;
    this.state = state;
  }

  public Integer getIntegerValue() {
    return this.integerValue;
  }

  public String getStringValue() {
    return this.name;
  }

  public Double getDoubleValue() {
    return this.doubleValue;
  }

  public Boolean getFlag() {
    return this.flag;
  }

  public Color getColor() {
    return this.color;
  }

  @Override
  public String toString() {
    final StringBuilder builder = new StringBuilder();
    builder.append("[ "); //$NON-NLS-1$
    builder.append(this.integerValue);
    builder.append(", "); //$NON-NLS-1$
    builder.append(this.name);
    builder.append(", "); //$NON-NLS-1$
    builder.append(this.doubleValue);
    builder.append(", "); //$NON-NLS-1$
    builder.append(this.flag);
    builder.append("]"); //$NON-NLS-1$
    return builder.toString();
  }

  public Date getDate() {
    return this.date;
  }

  public TriState getTriState() {
    return state;
  }

  public int getNullSaveNumber() {
    return notNullInteger;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((this.color == null) ? 0 : this.color.hashCode());
    result = prime * result + ((this.date == null) ? 0 : this.date.hashCode());
    result = prime * result + ((this.doubleValue == null) ? 0 : this.doubleValue.hashCode());
    result = prime * result + ((this.flag == null) ? 0 : this.flag.hashCode());
    result = prime * result + ((this.integerValue == null) ? 0 : this.integerValue.hashCode());
    result = prime * result + ((this.name == null) ? 0 : this.name.hashCode());
    result = prime * result + this.notNullInteger;
    result = prime * result + ((this.state == null) ? 0 : this.state.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    DemoObject other = (DemoObject) obj;
    return ObjectUtilities.equals(this.color, other.color)
        && ObjectUtilities.equals(this.date, other.date)
        && ObjectUtilities.equals(this.doubleValue, other.doubleValue)
        && ObjectUtilities.equals(this.flag, other.flag)
        && ObjectUtilities.equals(this.integerValue, other.integerValue)
        && ObjectUtilities.equals(this.name, other.name)
        && ObjectUtilities.equals(this.notNullInteger, other.notNullInteger)
        && ObjectUtilities.equals(this.state, other.state);
  }
}
