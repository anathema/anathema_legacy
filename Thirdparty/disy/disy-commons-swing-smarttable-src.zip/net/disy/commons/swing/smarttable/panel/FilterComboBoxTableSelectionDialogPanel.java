/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.panel;

import java.awt.Component;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.dialog.input.select.ISelectionDialogResult;
import net.disy.commons.swing.dialog.input.text.combobox.FilterComboBox;
import net.disy.commons.swing.dialog.input.text.combobox.IFilterComboBoxConfiguration;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.resources.DisyCommonsSwingIconResources;
import net.disy.commons.swing.smarttable.dialog.ITableSelectionDialogConfiguration;
import net.disy.commons.swing.smarttable.dialog.TableSelectionDialog;

public class FilterComboBoxTableSelectionDialogPanel<T> implements IComponentContainer {

  private final JComponent content;

  public FilterComboBoxTableSelectionDialogPanel(
      final IListModel<T> itemsModel,
      final IObjectModel<T> selectionModel,
      final IFilterComboBoxConfiguration<T> comboBoxConfiguration,
      final ITableSelectionDialogConfiguration<T> tableSelectionConfiguration) {
    final FilterComboBox<T> filterComboBox = new FilterComboBox<T>(
        itemsModel,
        selectionModel,
        comboBoxConfiguration);

    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(filterComboBox.getContent(), GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(ActionWidgetFactory.createButton(new SmartAction(
        DisyCommonsSwingIconResources.ELLIPSIS) {
      @Override
      protected void execute(final Component parentComponent) {
        final List<T> items = itemsModel.getItemList();
        final ISelectionDialogResult<T> result = TableSelectionDialog.showDialog(
            parentComponent,
            items,
            selectionModel.getValue(),
            tableSelectionConfiguration);
        if (result.isCanceled()) {
          return;
        }
        final T selectedItem = result.getSelectedItem();
        selectionModel.setValue(selectedItem);
      }
    }));
    content = panel;
  }

  @Override
  public JComponent getContent() {
    return content;
  }
}