/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.RowSorter;
import javax.swing.table.TableModel;

import net.disy.commons.swing.smarttable.sorter.ISortedRowMapper;

public final class SortedRowMapper implements ISortedRowMapper {
  private final RowSorter<TableModel> tableRowSorter;

  public SortedRowMapper(final RowSorter<TableModel> tableRowSorter) {
    this.tableRowSorter = tableRowSorter;
  }

  @Override
  public int getSortedRow(final int index) {
    if (this.tableRowSorter == null) {
      return index;
    }
    return this.tableRowSorter.convertRowIndexToView(index);
  }

  @Override
  public int getModelIndex(final int row) {
    if (this.tableRowSorter == null) {
      return row;
    }
    return this.tableRowSorter.convertRowIndexToModel(row);
  }

  @Override
  public void stateChanged() {
    tableRowSorter.allRowsChanged();
  }
}