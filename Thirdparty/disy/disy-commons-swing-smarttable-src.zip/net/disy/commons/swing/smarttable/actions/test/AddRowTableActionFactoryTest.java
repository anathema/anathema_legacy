/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions.test;

import static org.junit.Assert.*;
import net.disy.commons.core.testing.Assert;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.smarttable.actions.AddRowTableActionFactory;
import net.disy.commons.swing.smarttable.actions.IAdditionPerformer;

import org.easymock.EasyMock;
import org.junit.Before;
import org.junit.Test;

public class AddRowTableActionFactoryTest {

  private IAdditionPerformer additionPerformer;
  private IActionConfiguration configuration;
  private AddRowTableActionFactory factory;

  @Before
  public void createAddRowTableActionFactory() throws Exception {
    additionPerformer = EasyMock.createMock(IAdditionPerformer.class);
    configuration = EasyMock.createMock(IActionConfiguration.class);
    this.factory = new AddRowTableActionFactory(additionPerformer, configuration);
  }

  @Test
  public void notEqualsNull() throws Exception {
    Assert.assertNotEquals(factory, null);
  }

  @Test
  public void equalsFactoryWithSameConfigurationAndPerformer() throws Exception {
    assertEquals(factory, new AddRowTableActionFactory(additionPerformer, configuration));
  }

  @Test
  public void notEqualsFactoryWithOtherPerformer() throws Exception {
    IAdditionPerformer performer = EasyMock.createMock(IAdditionPerformer.class);
    Assert.assertNotEquals(factory, new AddRowTableActionFactory(performer, configuration));
  }

  @Test
  public void notEqualsFactoryWithOtherConfiguration() throws Exception {
    IActionConfiguration otherConfiguration = EasyMock.createMock(IActionConfiguration.class);
    Assert.assertNotEquals(factory, new AddRowTableActionFactory(
        additionPerformer,
        otherConfiguration));
  }
}