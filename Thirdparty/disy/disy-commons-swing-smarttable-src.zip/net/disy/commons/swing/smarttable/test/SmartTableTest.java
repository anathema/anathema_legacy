//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.test;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JFrame;
import javax.swing.table.DefaultTableModel;

import junit.framework.AssertionFailedError;

import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;

// NOT_PUBLISHED
public class SmartTableTest extends CoreTestCase {

  public void testDisable() {
    SmartTable table = new SmartTable(
        new DefaultTableModel(2, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });
    table.setEnabled(false);
    assertFalse(table.isEnabled());
    assertFalse(table.getTable().isEnabled());
  }

  public void testDisableWithNonCreatedActions() {
    SmartTable smartTable = new SmartTable(
        new DefaultTableModel(2, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });
    smartTable.addActionFactory(new ITableActionFactory() {
      public Action createAction(SmartTable table) {
        throw new AssertionFailedError("Action should not have been created"); //$NON-NLS-1$
      }
    });
    smartTable.setEnabled(false);
  }

  public void testDisableWithCreatedActionNotDisablesActionItself() {
    final Action action = new AbstractAction("name") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        //nothing to do
      }
    };
    SmartTable smartTable = new SmartTable(
        new DefaultTableModel(2, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });
    smartTable.addActionFactory(new ITableActionFactory() {
      public Action createAction(SmartTable table) {
        return action;
      }
    });
    smartTable.setEnabled(false);
    assertTrue(action.isEnabled());
  }

  public void testEnterOnEmptyTableBug() throws AWTException {
    SmartTable smartTable = new SmartTable(
        new DefaultTableModel(0, 1),
        new ITableColumnViewSettings[]{ new StringTableColumnSettings() });

    JFrame frame = new JFrame();
    try {
      frame.getContentPane().add(smartTable.getContent());
      frame.pack();
      frame.setVisible(true);
      new Robot().keyPress(KeyEvent.VK_ENTER);
      new Robot().keyRelease(KeyEvent.VK_ENTER);
      assertEquals(-1, smartTable.getSelectedRowIndex());
      assertTrue(smartTable.isSelectionEmpty());
    }
    finally {
      frame.dispose();
    }
  }
}