/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static org.junit.Assert.assertEquals;
import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTableConfiguration;
import net.disy.commons.swing.smarttable.filtered.DeprecatedListTable;
import net.disy.commons.swing.ui.IObjectUi;

import org.junit.Test;

public class FilterableListTable_SecureSrollToAndSelectTest {

  @Test
  public void selectsFirstItemAndExecutesGivenBlockAndResetsFilter() throws Exception {
    final TestFilterableListTable table = new TestFilterableListTable(4);
    table.secureScrollToAndSelect(1);
    assertEquals(1, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(0);
    assertEquals(0, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(-1);
    assertEquals(0, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(3);
    assertEquals(3, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(4);
    assertEquals(3, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(5);
    assertEquals(3, table.getSelectedRowIndex());
    table.secureScrollToAndSelect(-1);
    assertEquals(3, table.getSelectedRowIndex());
  }

  private class TestFilterableListTable extends DeprecatedListTable<String> {
    private int rowIndex = 0;
    private final int rowCount;

    @SuppressWarnings("unchecked")
    public TestFilterableListTable(int rowCount) {
      super(
          new DefaultListModel(),
          new ObjectModel<String>(),
          new IObjectUi[0],
          new String[0],
          new SmartTableConfiguration(new ITableColumnViewSettings[0]));
      this.rowCount = rowCount;
    }

    @Override
    protected void scrollToAndSelect(int newRowIndex) {
      rowIndex = newRowIndex;
    }

    protected int getSelectedRowIndex() {
      return rowIndex;
    }

    @Override
    protected int getRowCount() {
      return rowCount;
    }

    @Override
    protected void secureScrollToAndSelect(int newRowIndex) {
      super.secureScrollToAndSelect(newRowIndex);
    }
  }

}
