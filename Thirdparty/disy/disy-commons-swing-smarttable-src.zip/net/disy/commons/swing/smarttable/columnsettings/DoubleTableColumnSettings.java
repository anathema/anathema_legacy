//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.celleditors.DoubleCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.DoubleCellRenderer;

// NOT_PUBLISHED
public class DoubleTableColumnSettings extends AbstractTableColumnSettings {

  public DoubleTableColumnSettings() {
    this(6);
  }

  public DoubleTableColumnSettings(int preferredColumnCount) {
    super(preferredColumnCount);
  }

  public TableCellEditor getEditor() {
    return new DoubleCellEditor();
  }
  
  public TableCellRenderer getRenderer() {
    return new DoubleCellRenderer();
  }
}