/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;
import javax.swing.JTextField;

public class UpperCaseStringCellEditor extends AbstractDelegatingCellEditor {

  @Override
  protected final EditorDelegate createDelegate(final JComponent editorComponent) {
    final JTextField textField = (JTextField) editorComponent;
    return new EditorDelegate(this) {
      @Override
      public void setValue(final Object value) {
        textField.setText((value != null) ? value.toString().toUpperCase() : ""); //$NON-NLS-1$
        textField.selectAll();
      }

      @Override
      public Object getCellEditorValue() {
        return textField.getText().toUpperCase();
      }
    };
  }

  @Override
  protected JComponent createEditorComponent() {
    return new JTextField();
  }
}