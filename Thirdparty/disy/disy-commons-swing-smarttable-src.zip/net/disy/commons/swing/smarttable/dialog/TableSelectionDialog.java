/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog;

import java.awt.Component;
import java.util.List;

import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.input.select.ISelectionDialogResult;
import net.disy.commons.swing.dialog.input.select.SelectionDialogResult;
import net.disy.commons.swing.dialog.input.select.internal.AbstractSelectionDialog;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

public class TableSelectionDialog extends AbstractSelectionDialog {

  private TableSelectionDialog() {
    //no instance available
  }

  public static <T> ISelectionDialogResult<T> showDialog(
      final Component parentComponent,
      final List<T> items,
      final T selectedItem,
      final ITableSelectionDialogConfiguration<T> configuration) {
    final TableSelectionDialogPage<T> page = new TableSelectionDialogPage<T>(
        items,
        selectedItem,
        configuration);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    final IDialogResult result = dialog.show();
    final List<T> selectedItems = page.getSelectedItems();
    return new SelectionDialogResult<T>(result, selectedItems);
  }
}