/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.swing.smarttable.column.IMutableListColumnValueConverter;
import net.disy.commons.swing.table.IListModelTableColumnSettings;

public class EditableListModelTableModelColumnSettings<L, V>
    implements
    IListModelTableColumnSettings<L, V> {

  private IMutableListModel<L> listModel;
  private final String columnName;
  private final Class<V> itemClass;
  private final IMutableListColumnValueConverter<L, V> columnValueAdapter;

  public EditableListModelTableModelColumnSettings(
      IMutableListModel<L> listModel,
      String columnName,
      Class<V> itemClass,
      IMutableListColumnValueConverter<L, V> columnValueAdapter) {
    super();
    this.listModel = listModel;
    this.columnName = columnName;
    this.itemClass = itemClass;
    this.columnValueAdapter = columnValueAdapter;
  }

  @Override
  public String getColumnName() {
    return columnName;
  }

  @Override
  public Class<V> getItemClass() {
    return itemClass;
  }

  @Override
  public V getValueAt(int rowIndex) {
    L listItem = listModel.getItem(rowIndex);
    return columnValueAdapter.getValue(listItem);
  }

  @Override
  public void setValueAt(V value, int rowIndex) {
    L oldListItem = listModel.getItem(rowIndex);
    L newListItem = columnValueAdapter.setValue(oldListItem, value);
    listModel.setItem(newListItem, rowIndex);
  }

  @Override
  public boolean isCellEditable(int rowIndex) {
    return true;
  }

  @Override
  public void setListModel(IListModel<L> listModel) {
    this.listModel = (IMutableListModel<L>) listModel;

  }

}
