// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

//NOT_PUBLISHED
public interface IComboBoxValuesProvider {

  public Object[] getValues(int rowIndex);

}
