/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTableConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterStrategy;
import net.disy.commons.swing.smarttable.filtered.DeprecatedListTable;
import net.disy.commons.swing.smarttable.sorter.DefaultSorterFactory;
import net.disy.commons.swing.ui.IObjectUi;

public class TestFilterableListTable extends DeprecatedListTable<String> {

  @SuppressWarnings("unchecked")
  public TestFilterableListTable(final IListModel listModel, IFilterStrategy<String> filterStrategy) {
    super(
        listModel,
        new ObjectModel<String>(),
        new IObjectUi[0],
        new String[0],
        new SmartTableConfiguration(new ITableColumnViewSettings[0]),
        filterStrategy,
        new DefaultSorterFactory());
  }

}