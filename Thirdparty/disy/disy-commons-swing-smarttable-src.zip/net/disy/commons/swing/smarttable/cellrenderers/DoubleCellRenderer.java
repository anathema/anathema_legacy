/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.textfield.DoubleField;

public class DoubleCellRenderer /*extends DoubleField*/implements TableCellRenderer {

  private final DoubleField field = new DoubleField();
  private static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

  public DoubleCellRenderer() {
    field.setBorder(null);
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    field.setValue(((Number) value).doubleValue());
    field.setEnabled(table == null || table.isEnabled());

    //Geklaut aus javax.swing.table.DefaultCellRenderer    
    if (isSelected) {
      field.setForeground(table.getSelectionForeground());
      field.setBackground(table.getSelectionBackground());
    }
    else {
      field.setForeground(table.getForeground());
      field.setBackground(table.getBackground());
    }

    if (hasFocus) {
      field.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder")); //$NON-NLS-1$
      if (table.isCellEditable(row, column)) {
        field.setForeground(SwingColors.getTableFocusCellForegroundColor());
        field.setBackground(SwingColors.getTableFocusCellBackgroundColor());
      }
    }
    else {
      field.setBorder(noFocusBorder);
    }

    return field.getContent();
  }
}