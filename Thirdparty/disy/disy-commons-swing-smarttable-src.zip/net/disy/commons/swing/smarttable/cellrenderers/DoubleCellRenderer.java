//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.textfield.DoubleField;

// NOT_PUBLISHED
public class DoubleCellRenderer /*extends DoubleField*/implements TableCellRenderer {

  private final DoubleField field = new DoubleField();
  private static Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

  public DoubleCellRenderer() {
    field.setBorder(null);
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    field.setValue(((Number) value).doubleValue());
    field.setEnabled(table == null || table.isEnabled());

    //Geklaut aus javax.swing.table.DefaultCellRenderer    
    if (isSelected) {
      field.setForeground(table.getSelectionForeground());
      field.setBackground(table.getSelectionBackground());
    }
    else {
      field.setForeground(table.getForeground());
      field.setBackground(table.getBackground());
    }

    if (hasFocus) {
      field.setBorder(UIManager.getBorder("Table.focusCellHighlightBorder")); //$NON-NLS-1$
      if (table.isCellEditable(row, column)) {
        field.setForeground(SwingColors.getTabelFocusCellForegroundColor());
        field.setBackground(SwingColors.getTabelFocusCellBackgroundColor());
      }
    }
    else {
      field.setBorder(noFocusBorder);
    }

    return field;
  }
}