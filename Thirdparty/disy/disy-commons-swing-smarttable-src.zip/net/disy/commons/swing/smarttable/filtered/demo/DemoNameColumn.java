/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.swing.smarttable.column.IMutableListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.DoubleClickObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NullDoubleClickBehaviour;
import net.disy.commons.swing.smarttable.filtered.DefaultFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.NullFilterConfiguration;
import net.disy.commons.swing.smarttable.listtable.AbstractEditableListModelColumn;
import net.disy.commons.swing.smarttable.sorter.ComparableSorterConfiguration;
import net.disy.commons.swing.ui.ToStringUi;

public class DemoNameColumn extends AbstractEditableListModelColumn<ListTableDemoModelItem, String> {

  private final IFilterConfiguration<String> filterConfiguration;

  public DemoNameColumn(IMutableListModel<ListTableDemoModelItem> listModel, boolean filtered) {
    super(listModel);
    if (filtered) {
      filterConfiguration = new DefaultFilterConfiguration();
    }
    else {
      filterConfiguration = new NullFilterConfiguration<String>();
    }
  }

  @Override
  protected IMutableListColumnValueConverter<ListTableDemoModelItem, String> createRowToColumnValueAdapter() {
    return new IMutableListColumnValueConverter<ListTableDemoModelItem, String>() {

      @Override
      public String getValue(ListTableDemoModelItem listValue) {
        return listValue.getName();
      }

      @Override
      public ListTableDemoModelItem setValue(ListTableDemoModelItem listValue, String columnValue) {
        listValue.setName(columnValue);
        return listValue;
      }
    };
  }

  @Override
  protected TableColumnConfiguration<String> createConfiguration() {
    TableColumnConfiguration<String> configuration = new TableColumnConfiguration<String>(
        "Name",
        String.class,
        new DoubleClickObjectUiTableColumnSettings<String>(
            new ToStringUi<String>(),
            new NullDoubleClickBehaviour<String>()));
    configuration.setSorterConfiguration(new ComparableSorterConfiguration<String>());
    return configuration;
  }

  @Override
  public IFilterConfiguration<String> getFilterConfiguration() {
    return filterConfiguration;
  }

}
