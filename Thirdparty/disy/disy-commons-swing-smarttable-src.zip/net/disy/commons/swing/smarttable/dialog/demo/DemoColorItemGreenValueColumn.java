/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;

public final class DemoColorItemGreenValueColumn extends AbstractDemoColorItemColorValueColumn {
  public DemoColorItemGreenValueColumn(final IListModel<DemoColorItem> listModel) {
    super(listModel, "Green");
  }

  @Override
  protected IListColumnValueConverter<DemoColorItem, Integer> createRowToColumnValueAdapter() {
    return new IListColumnValueConverter<DemoColorItem, Integer>() {
      @Override
      public Integer getValue(final DemoColorItem listValue) {
        return listValue == null ? null : Integer.valueOf(listValue.getColor().getGreen());
      }
    };
  }
}