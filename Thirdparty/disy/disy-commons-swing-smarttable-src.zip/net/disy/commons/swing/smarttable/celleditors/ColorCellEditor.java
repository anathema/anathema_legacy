/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.JTable;
import net.disy.commons.core.model.listener.IChangeListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.ColorChooserLabel;
import net.disy.commons.swing.dialog.color.DefaultColorChooserConfiguration;

public class ColorCellEditor extends AbstractCellEditor
    implements
    TableCellEditor,
    TableCellRenderer {

  private ColorModel colorModel;

  private final boolean enabledIfNotEditable;

  public ColorCellEditor(final boolean enabledIfNotEditable) {
    this.enabledIfNotEditable = enabledIfNotEditable;
  }

  @Override
  public Component getTableCellEditorComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final int rowIndex,
      final int columnIndex) {
    return createColorComponent(table, rowIndex, columnIndex, (Color) value);
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int rowIndex,
      final int columnIndex) {
    return createColorComponent(table, rowIndex, columnIndex, (Color) value);
  }

  @Override
  public boolean shouldSelectCell(final EventObject anEvent) {
    return true;
  }

  @Override
  public boolean isCellEditable(final EventObject anEvent) {
    if (anEvent instanceof MouseEvent) {
      return ((MouseEvent) anEvent).getClickCount() >= 2;
    }
    return true;
  }

  @Override
  public Object getCellEditorValue() {
    return colorModel.getColor();
  }

  private Component createColorComponent(
      final JTable table,
      final int rowIndex,
      final int columnIndex,
      final Color color) {
    colorModel = new ColorModel(color);
    final ColorChooserLabel colorChooseLabel = new ColorChooserLabel(
        colorModel,
        new DefaultColorChooserConfiguration(true));
    colorChooseLabel.setEnabled(table.isEnabled()
        && (enabledIfNotEditable || table.isCellEditable(rowIndex, columnIndex)));

    colorModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        fireEditingStopped();
      }
    });

    colorChooseLabel.getContent().addFocusListener(new FocusListener() {
      @Override
      public void focusGained(final FocusEvent e) {
        //nothing to do
      }

      @Override
      public void focusLost(final FocusEvent e) {
        fireEditingStopped();
      }
    });
    colorChooseLabel.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        fireEditingStopped();
      }
    });
    return colorChooseLabel.getContent();
  }
}