//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.widgets.ColorChooseLabel;
import net.disy.commons.swing.color.widgets.ColorModel;

// NOT_PUBLISHED
public class ColorCellEditor extends AbstractCellEditor
    implements
    TableCellEditor,
    TableCellRenderer {

  private ColorModel colorModel;

  public Component getTableCellEditorComponent(
      JTable table,
      Object value,
      boolean isSelected,
      int row,
      int column) {
    return createColorComponent((Color) value);
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    return createColorComponent((Color) value);
  }

  public boolean shouldSelectCell(EventObject anEvent) {
    return true;
  }
  
  public boolean isCellEditable(EventObject anEvent) {
    if (anEvent instanceof MouseEvent) {
      return ((MouseEvent) anEvent).getClickCount() >= 2;
    }
    return true;
  }

  public Object getCellEditorValue() {
    return colorModel.getColor();
  }

  private Component createColorComponent(Color color) {
    colorModel = new ColorModel(color);
    ColorChooseLabel colorChooseLabel = new ColorChooseLabel(colorModel);
    colorChooseLabel.setTransparencyEnabled(true);

    colorModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        fireEditingStopped();
      }
    });

    colorChooseLabel.getContent().addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
        //nothing to do
      }

      public void focusLost(FocusEvent e) {
        fireEditingStopped();
      }
    });
    colorChooseLabel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
      }
    });
    return colorChooseLabel.getContent();
  }
}