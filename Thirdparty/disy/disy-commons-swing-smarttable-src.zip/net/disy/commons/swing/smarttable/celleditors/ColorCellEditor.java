//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.JTable;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.widgets.ColorChooserLabel;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.color.widgets.DefaultColorChooserConfiguration;

// NOT_PUBLISHED
public class ColorCellEditor extends AbstractCellEditor
    implements
    TableCellEditor,
    TableCellRenderer {

  private ColorModel colorModel;

  private final boolean enabledIfNotEditable;

  public ColorCellEditor(boolean enabledIfNotEditable) {
    this.enabledIfNotEditable = enabledIfNotEditable;
  }

  public Component getTableCellEditorComponent(
      JTable table,
      Object value,
      boolean isSelected,
      int rowIndex,
      int columnIndex) {
    return createColorComponent(table, rowIndex, columnIndex, (Color) value);
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int rowIndex,
      int columnIndex) {
    return createColorComponent(table, rowIndex, columnIndex, (Color) value);
  }

  @Override
  public boolean shouldSelectCell(EventObject anEvent) {
    return true;
  }

  @Override
  public boolean isCellEditable(EventObject anEvent) {
    if (anEvent instanceof MouseEvent) {
      return ((MouseEvent) anEvent).getClickCount() >= 2;
    }
    return true;
  }

  @Override
  public Object getCellEditorValue() {
    return colorModel.getColor();
  }

  private Component createColorComponent(JTable table, int rowIndex, int columnIndex, Color color) {
    colorModel = new ColorModel(color);
    ColorChooserLabel colorChooseLabel = new ColorChooserLabel(
        colorModel,
        new DefaultColorChooserConfiguration(true));
    colorChooseLabel.setEnabled(table.isEnabled()
        && (enabledIfNotEditable || table.isCellEditable(rowIndex, columnIndex)));

    colorModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        fireEditingStopped();
      }
    });

    colorChooseLabel.getContent().addFocusListener(new FocusListener() {
      public void focusGained(FocusEvent e) {
        //nothing to do
      }

      public void focusLost(FocusEvent e) {
        fireEditingStopped();
      }
    });
    colorChooseLabel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireEditingStopped();
      }
    });
    return colorChooseLabel.getContent();
  }
}