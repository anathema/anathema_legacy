/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.Icon;
import javax.swing.JTable;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

public class TableColumnConfigurator {

  public static void configureTableColumns(
      final JTable table,
      final ITableColumnViewSettings<?>[] settings) {
    final TableColumnModel columnModel = table.getColumnModel();
    for (int columnIndex = 0; columnIndex < settings.length; columnIndex++) {
      final TableColumn tableColumn = columnModel.getColumn(columnIndex);
      final ITableColumnViewSettings<?> view = settings[columnIndex];
      tableColumn.setCellEditor(view.getEditor());
      if (view.getRenderer() != null) {
        tableColumn.setCellRenderer(view.getRenderer());
      }
      tableColumn.setPreferredWidth(view.getPreferredWidth());
      tableColumn.setWidth(view.getPreferredWidth());
      if (!view.isResizable()) {
        tableColumn.setResizable(view.isResizable());
        tableColumn.setMinWidth(view.getPreferredWidth());
        tableColumn.setMaxWidth(view.getPreferredWidth());
      }
      final Icon icon = view.getIcon();
      if (icon != null) {
        tableColumn.setHeaderRenderer(new IconTableHeaderRenderer(icon, view.getToolTipText()));
      }
    }
  }
}