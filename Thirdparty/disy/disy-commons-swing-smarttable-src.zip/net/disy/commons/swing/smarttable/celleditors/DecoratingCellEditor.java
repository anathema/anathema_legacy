/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Component;
import java.util.EventObject;

import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.event.CellEditorListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IDecorator;

public class DecoratingCellEditor implements ICellEditor {

  private final ICellEditor cellEditor;
  private final IDecorator<Component> componentDecorator;

  public DecoratingCellEditor(
      final ICellEditor cellEditor,
      final IDecorator<Component> componentDecorator) {
    Ensure.ensureArgumentNotNull(cellEditor);
    Ensure.ensureArgumentNotNull(componentDecorator);
    this.cellEditor = cellEditor;
    this.componentDecorator = componentDecorator;
  }

  @Override
  public Component getTableCellEditorComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final int row,
      final int column) {
    final Component editComponent = cellEditor.getTableCellEditorComponent(
        table,
        value,
        isSelected,
        row,
        column);
    return componentDecorator.decorate(editComponent);
  }

  @Override
  public void addCellEditorListener(final CellEditorListener l) {
    cellEditor.addCellEditorListener(l);
  }

  @Override
  public void cancelCellEditing() {
    cellEditor.cancelCellEditing();
  }

  @Override
  public Object getCellEditorValue() {
    return cellEditor.getCellEditorValue();
  }

  @Override
  public boolean isCellEditable(final EventObject anEvent) {
    return cellEditor.isCellEditable(anEvent);
  }

  @Override
  public void removeCellEditorListener(final CellEditorListener l) {
    cellEditor.removeCellEditorListener(l);
  }

  @Override
  public boolean shouldSelectCell(final EventObject anEvent) {
    return cellEditor.shouldSelectCell(anEvent);
  }

  @Override
  public boolean stopCellEditing() {
    return cellEditor.stopCellEditing();
  }

  @Override
  public Component getTreeCellEditorComponent(
      final JTree tree,
      final Object value,
      final boolean isSelected,
      final boolean expanded,
      final boolean leaf,
      final int row) {
    final Component editComponent = cellEditor.getTreeCellEditorComponent(
        tree,
        value,
        isSelected,
        expanded,
        leaf,
        row);
    return componentDecorator.decorate(editComponent);
  }
}