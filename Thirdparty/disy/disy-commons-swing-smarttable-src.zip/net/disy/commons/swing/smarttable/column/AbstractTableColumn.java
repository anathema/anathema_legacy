/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.column;

import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.sorter.ITableSorterConfiguration;

public abstract class AbstractTableColumn<L, C> implements ITableColumn<L, C> {

  private TableColumnConfiguration<C> columnConfiguration;

  public AbstractTableColumn() {
    super();
  }

  protected abstract TableColumnConfiguration<C> createConfiguration();

  @Override
  public ITableSorterConfiguration<C> getSorterConfiguration() {
    return getColumnConfiguration().getSorterConfiguration();
  }

  @Override
  public ITableColumnViewSettings<C> getViewSettings() {
    return getColumnConfiguration().getColumnViewSettings();
  }

  @Override
  public Class<C> getColumnClass() {
    return getColumnConfiguration().getColumnClass();
  }

  @Override
  public String getColumnName() {
    return getColumnConfiguration().getColumnName();
  }

  public TableColumnConfiguration<C> getColumnConfiguration() {
    if (columnConfiguration == null) {
      columnConfiguration = createConfiguration();
    }
    return columnConfiguration;
  }

  @Override
  public IFilterConfiguration<C> getFilterConfiguration() {
    return getColumnConfiguration().getFilterConfiguration();
  }

  @Override
  public void setFilterConfiguration(IFilterConfiguration<C> filterConfiguration) {
    getColumnConfiguration().setFilterConfiguration(filterConfiguration);
  }

  @Override
  public void setSorterConfiguration(ITableSorterConfiguration<C> sorterConfiguration) {
    getColumnConfiguration().setSorterConfiguration(sorterConfiguration);
  }

}
