/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.celleditors.IntegerCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.NumberCellRenderer;

public class IntegerTableColumnSettings extends AbstractTableColumnSettings<Integer> {

  private final int stepsize;
  private final int maximum;
  private final int minimum;

  public IntegerTableColumnSettings(final int minimum, final int maximum, final int stepsize) {
    super(2 + Math.max(String.valueOf(minimum).length(), String.valueOf(maximum).length()));
    this.minimum = minimum;
    this.maximum = maximum;
    this.stepsize = stepsize;
  }

  @Override
  public TableCellEditor getEditor() {
    return new IntegerCellEditor(minimum, maximum, stepsize);
  }

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return new NumberCellRenderer();
  }
}