//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors.action;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class FinishedCellEditResult implements ICellEditResult {

  private final Object value;

  public FinishedCellEditResult(Object value) {
    Ensure.ensureArgumentNotNull(value);
    this.value = value;
  }

  public void accept(ICellEditResultVisitor visitor) {
    visitor.visitFinished(this);
  }

  public Object getValue() {
    return value;
  }
}