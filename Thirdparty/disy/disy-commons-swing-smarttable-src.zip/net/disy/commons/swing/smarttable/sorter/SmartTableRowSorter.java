/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.sorter;

import java.text.Collator;
import java.util.Comparator;

import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import net.disy.commons.core.util.Ensure;

public class SmartTableRowSorter extends TableRowSorter<TableModel> {

  private static final Comparator<Object> COMPARABLE_COMPARATOR = new ComparableComparator();

  private final ITableSorterConfiguration[] tableSorterConfiguration;

  public SmartTableRowSorter(
      ITableSorterConfiguration[] tableSorterConfiguration,
      TableModel tableModel) {
    super(tableModel);
    Ensure.ensureArgumentNotNull(tableSorterConfiguration);
    this.tableSorterConfiguration = tableSorterConfiguration;
  }

  @Override
  public Comparator<?> getComparator(int column) {
    Comparator<?> comparator = tableSorterConfiguration[column].getComparator();
    if (comparator != null) {
      return comparator;
    }
    Class<?> columnClass = getModel().getColumnClass(column);
    if (columnClass == String.class) {
      return Collator.getInstance();
    }
    if (Comparable.class.isAssignableFrom(columnClass)) {
      return COMPARABLE_COMPARATOR;
    }
    return null;
  }

  @Override
  protected boolean useToString(int column) {
    Comparator<?> comparator = getComparator(column);
    if (comparator != null) {
      return false;
    }
    Class<?> columnClass = getModel().getColumnClass(column);
    if (columnClass == String.class) {
      return false;
    }
    if (Comparable.class.isAssignableFrom(columnClass)) {
      return false;
    }
    return true;
  }

  @Override
  public boolean isSortable(int column) {
    return tableSorterConfiguration[column].isSortable();
  }

  private static class ComparableComparator implements Comparator<Object> {
    @Override
    @SuppressWarnings("unchecked")
    public int compare(Object o1, Object o2) {
      return ((Comparable<Object>) o1).compareTo(o2);
    }
  }
}
