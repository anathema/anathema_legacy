//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.awt.Font;
import java.util.Date;


// NOT_PUBLISHED
public class AddRemoveDemoTableModel extends DemoTableModel {

  public void addRow() {
    addRow(new Object[]{
        new Double(1.0),
        new Integer(20),
        "Text", Color.RED, new Double(4.2), "zwei", new Date(), new Boolean(false), new Integer(42), new Font("Dialog", Font.PLAIN, 11) }); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }

}