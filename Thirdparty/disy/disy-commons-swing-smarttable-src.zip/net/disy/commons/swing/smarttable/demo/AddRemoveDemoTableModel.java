/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.awt.Font;
import java.util.Date;

public class AddRemoveDemoTableModel extends DemoTableModel {

  public void addRow() {
    addRow(new Object[]{
        new Double(1.0),
        new Integer(20),
        "Text", Color.RED, new Double(4.2), "zwei", new Date(), new Boolean(false), new Integer(42), new Font(Font.DIALOG, Font.PLAIN, 11) }); //$NON-NLS-1$ //$NON-NLS-2$
  }
}