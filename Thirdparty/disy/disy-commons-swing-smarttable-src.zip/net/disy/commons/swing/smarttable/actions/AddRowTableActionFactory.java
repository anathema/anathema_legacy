//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

// NOT_PUBLISHED
public abstract class AddRowTableActionFactory implements ITableActionFactory {

  private final IActionConfiguration actionConfiguration;

  public AddRowTableActionFactory() {
    //TODO 24.01.2006 (Markus Gebhard): i18n!
    this(new ActionConfiguration("Hinzuf�gen", null, "Eintrag hinzuf�gen"));
  }

  public AddRowTableActionFactory(IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.actionConfiguration = actionConfiguration;
  }

  //@Overrides
  public Action createAction(final SmartTable table) {
    SmartAction action = new SmartAction(actionConfiguration) {
      @Override
      protected void execute(Component parentComponent) {
        table.stopCellEditing();
        if (performAdd(parentComponent)) {
          scrollToAndSelectLastRow();
        }
      }

      private void scrollToAndSelectLastRow() {
        table.scrollToAndSelect(table.getTable().getModel().getRowCount() - 1);
        table.requestFocus();
      }
    };
    //TODO 24.01.2006 (Markus Gebhard): Anders l�sen!
    if (table.isToolBarStyleButtons()) {
      action.setIcon(TableActionResources.ADD_ROW_ICON);
    }
    return action;
  }

  /** Perform the add operation to add a new item to the table. If this method returns <code>true</code>
   * the table assumes a new line has been added to the end of the table. It might then try to scroll
   * it to visible and select that row.
   * @param parentComponent 
   * @return <code>true</code> if a new line was added. */
  protected abstract boolean performAdd(Component parentComponent);

}