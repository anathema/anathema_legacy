/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import javax.swing.Action;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public class AddRowTableActionFactory extends AbstractTableActionFactory {

  private final IActionConfiguration actionConfiguration;
  private final IAdditionPerformer additionPerformer;

  public AddRowTableActionFactory(final IAdditionPerformer additionPerformer) {
    this(additionPerformer, new ActionConfiguration("Hinzufügen", null, "Hinzufügen"));
  }

  public AddRowTableActionFactory(
      final IAdditionPerformer additionPerformer,
      final IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.additionPerformer = additionPerformer;
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public Action createAction(final SmartTable table) {
    final SmartAction action = new AddRowTableAction(actionConfiguration, table, additionPerformer);
    if (table.isToolBarStyleButtons() && action.getIcon() == null) {
      action.setIcon(TableActionResources.ADD_ROW_ICON);
    }
    return action;
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof AddRowTableActionFactory)) {
      return false;
    }
    final AddRowTableActionFactory other = (AddRowTableActionFactory) obj;
    return ObjectUtilities.equals(additionPerformer, other.additionPerformer)
        && ObjectUtilities.equals(actionConfiguration, other.actionConfiguration);
  }

  @Override
  public int hashCode() {
    return additionPerformer.hashCode();
  }
}