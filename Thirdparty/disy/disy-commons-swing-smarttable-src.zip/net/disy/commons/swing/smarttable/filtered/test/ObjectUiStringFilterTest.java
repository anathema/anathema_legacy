/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static org.junit.Assert.*;
import net.disy.commons.swing.smarttable.filtered.ObjectUiStringFilter;
import net.disy.commons.swing.ui.IObjectUi;

import org.junit.Test;

public class ObjectUiStringFilterTest {

  @Test
  public void emptyValueDoesNotInterfereWithEvaluation() throws Exception {
    IObjectUi<String>[] uis = new IObjectUi[]{ new EmptyObjectUi<String>(), new StringValueUi() };
    assertTrue(new ObjectUiStringFilter<String>(uis, "text").evaluate("text")); //$NON-NLS-1$ //$NON-NLS-2$
  }
}