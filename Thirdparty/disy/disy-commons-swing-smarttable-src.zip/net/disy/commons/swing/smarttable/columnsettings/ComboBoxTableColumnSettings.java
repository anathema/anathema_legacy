//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.laf.LookAndFeelUtilities;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.cellrenderers.ComboBoxTableCellRenderer;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

// NOT_PUBLISHED
public class ComboBoxTableColumnSettings implements ITableColumnViewSettings {

  private class ComboBoxRenderer extends ComboBoxTableCellRenderer {
    public Component getTableCellRendererComponent(
        JTable table,
        Object value,
        boolean isSelected,
        boolean hasFocus,
        int row,
        int column) {
      setDirectValues(valuesProvider.getValues(row));
      return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }

    public void setDirectValues(Object[] values) {
      Ensure.ensureArgumentNotNull(values);
      removeAllItems();
      for (int i = 0; i < values.length; i++) {
        addItem(values[i]);
      }
    }
  }

  private IObjectUi objectUi;
  private final ComboBoxRenderer editComboBox = new ComboBoxRenderer();
  private final ComboBoxRenderer renderComboBox = new ComboBoxRenderer();
  private int preferredWidth;
  private IComboBoxValuesProvider valuesProvider;

  public ComboBoxTableColumnSettings(Object[] values) {
    this(values, defaultPreferredWidth(values));
  }

  private static int defaultPreferredWidth(Object[] values) {
    int width = 0;
    for (int i = 0; i < values.length; i++) {
      width = Math.max(width, values[i].toString().length());
    }
    return width;
  }

  public ComboBoxTableColumnSettings(IComboBoxValuesProvider valuesProvider) {
    this(valuesProvider, null);
  }

  public ComboBoxTableColumnSettings(IComboBoxValuesProvider valuesProvider, IObjectUi renderer) {
    this.valuesProvider = valuesProvider;
    this.objectUi = renderer;
  }

  public ComboBoxTableColumnSettings(Object[] values, int preferredColumnCount) {
    setValues(values);
    this.preferredWidth = (int) new JTextField(preferredColumnCount).getPreferredSize().getWidth();
  }

  public ComboBoxTableColumnSettings(Object[] values,
      int preferredColumnCount,
      IObjectUi renderer) {
    this(values, preferredColumnCount);
    this.objectUi = renderer;
  }

  public ComboBoxTableColumnSettings(Object[] values, IObjectUi renderer) {
    this(values);
    this.objectUi = renderer;
  }

  public TableCellEditor getEditor() {
    if (objectUi != null) {
      editComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
    return new DefaultCellEditor(editComboBox) {
      public Component getTableCellEditorComponent(
          JTable table,
          Object value,
          boolean isSelected,
          int row,
          int column) {
        editComboBox.setDirectValues(valuesProvider.getValues(row));
        LookAndFeelUtilities.adjustCell(editComboBox, table, isSelected, true, true);
        return super.getTableCellEditorComponent(table, value, isSelected, row, column);
      }
    };
  }

  public TableCellRenderer getRenderer() {
    if (objectUi != null) {
      renderComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
    return renderComboBox;
  }

  public void setValues(Object[] values) {
    valuesProvider = new ConstantValuesProvider(values);
  }

  public boolean isResizable() {
    return true;
  }

  public int getPreferredWidth() {
    return preferredWidth > 0 ? preferredWidth : editComboBox.getPreferredSize().width;
  }

}