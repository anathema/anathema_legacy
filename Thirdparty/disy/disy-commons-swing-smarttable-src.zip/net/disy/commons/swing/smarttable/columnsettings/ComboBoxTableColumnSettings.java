//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.number.MaxIntegerValueBuilder;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.laf.LookAndFeelUtilities;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.cellrenderers.ComboBoxTableCellRenderer;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

// NOT_PUBLISHED
public class ComboBoxTableColumnSettings implements ITableColumnViewSettings {

  private class ComboBoxRenderer extends ComboBoxTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(
        JTable table,
        Object value,
        boolean isSelected,
        boolean hasFocus,
        int row,
        int column) {
      setDirectValues(valuesProvider.getValues(row));
      return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }

    public void setDirectValues(Object[] values) {
      Ensure.ensureArgumentNotNull(values);
      removeAllItems();
      for (int i = 0; i < values.length; i++) {
        addItem(values[i]);
      }
    }
  }

  private final ComboBoxRenderer editComboBox = new ComboBoxRenderer();
  private final ComboBoxRenderer renderComboBox = new ComboBoxRenderer();
  private int preferredWidth;
  private IComboBoxValuesProvider valuesProvider;

  public ComboBoxTableColumnSettings(Object[] values) {
    this(values, defaultPreferredColumnCount(values, null));
  }

  private static int defaultPreferredColumnCount(Object[] values, IObjectUi objectUi) {
    MaxIntegerValueBuilder builder = new MaxIntegerValueBuilder(0);
    for (int i = 0; i < values.length; i++) {
      final Object value = values[i];
      final String stringRepresentation = (objectUi == null) ? String.valueOf(value) : objectUi
          .getLabel(value);
      builder.add(stringRepresentation.length());
    }
    return builder.getMaximum();
  }

  public ComboBoxTableColumnSettings(IComboBoxValuesProvider valuesProvider) {
    this(valuesProvider, null);
  }

  public ComboBoxTableColumnSettings(IComboBoxValuesProvider valuesProvider, IObjectUi objectUi) {
    this.valuesProvider = valuesProvider;
    if (objectUi != null) {
      editComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
      renderComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
  }

  public ComboBoxTableColumnSettings(Object[] values, int preferredColumnCount) {
    this(values, preferredColumnCount, (IObjectUi) null);
  }

  public ComboBoxTableColumnSettings(Object[] values, int preferredColumnCount, IObjectUi objectUi) {
    this(new ConstantValuesProvider(values), preferredColumnCount, objectUi);
  }

  public ComboBoxTableColumnSettings(Object[] values, IObjectUi objectUi) {
    this(values, defaultPreferredColumnCount(values, objectUi), objectUi);
  }

  public ComboBoxTableColumnSettings(
      IComboBoxValuesProvider valuesProvider,
      int preferredColumnCount,
      IObjectUi objectUi) {
    this.valuesProvider = valuesProvider;
    this.preferredWidth = (int) new JTextField(preferredColumnCount).getPreferredSize().getWidth();
    if (objectUi != null) {
      editComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
      renderComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
  }

  public TableCellEditor getEditor() {
    return new DefaultCellEditor(editComboBox) {
      @Override
      public Component getTableCellEditorComponent(
          JTable table,
          Object value,
          boolean isSelected,
          int row,
          int column) {
        editComboBox.setDirectValues(valuesProvider.getValues(row));
        LookAndFeelUtilities.adjustCell(editComboBox, table, isSelected, true, true);
        return super.getTableCellEditorComponent(table, value, isSelected, row, column);
      }
    };
  }

  public TableCellRenderer getRenderer() {
    return renderComboBox;
  }

  public void setValues(Object[] values) {
    valuesProvider = new ConstantValuesProvider(values);
  }

  public boolean isResizable() {
    return true;
  }

  public int getPreferredWidth() {
    return preferredWidth > 0 ? preferredWidth : editComboBox.getPreferredSize().width;
  }
  
  public void setTextEditable(boolean textEditable) {
    editComboBox.setEditable(textEditable);
  } 
}