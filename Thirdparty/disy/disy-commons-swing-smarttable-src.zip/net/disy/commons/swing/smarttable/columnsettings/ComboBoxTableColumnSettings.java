/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.Icon;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.number.MaxIntegerValueBuilder;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.laf.LookAndFeelUtilities;
import net.disy.commons.swing.smarttable.IObjectSelectionStrategy;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.cellrenderers.ComboBoxTableCellRenderer;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.ComboBoxPreferredWidth;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.IPreferredWidth;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.TextPreferredWidth;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public class ComboBoxTableColumnSettings<T> implements ITableColumnViewSettings<T> {

  private class ComboBoxRenderer extends ComboBoxTableCellRenderer {
    @Override
    public Component getTableCellRendererComponent(
        final JTable table,
        final Object value,
        final boolean isSelected,
        final boolean hasFocus,
        final int row,
        final int column) {
      setDirectValues(valuesProvider.getValues(row));
      return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
    }

    public void setDirectValues(final T[] values) {
      Ensure.ensureArgumentNotNull(values);
      removeAllItems();
      for (int i = 0; i < values.length; i++) {
        addItem(values[i]);
      }
    }
  }

  private final ComboBoxRenderer editComboBox = new ComboBoxRenderer();
  private final ComboBoxRenderer renderComboBox = new ComboBoxRenderer();
  private int preferredWidth;
  private IComboBoxValuesProvider<T> valuesProvider;

  public ComboBoxTableColumnSettings(final T[] values) {
    this(values, defaultPreferredColumnCount(values, null));
  }

  private static int defaultPreferredColumnCount(
      final Object[] values,
      final IObjectUi<Object> objectUi) {
    final MaxIntegerValueBuilder builder = new MaxIntegerValueBuilder(0);
    for (int i = 0; i < values.length; i++) {
      final Object value = values[i];
      final String stringRepresentation = (objectUi == null) ? String.valueOf(value) : objectUi
          .getLabel(value);
      builder.add(stringRepresentation.length());
    }
    return builder.getMaximum() + 1;
  }

  public ComboBoxTableColumnSettings(final IComboBoxValuesProvider<T> valuesProvider) {
    this(valuesProvider, null);
  }

  public ComboBoxTableColumnSettings(
      final IComboBoxValuesProvider<T> valuesProvider,
      final IObjectUi<T> objectUi) {
    this.valuesProvider = valuesProvider;
    if (objectUi != null) {
      editComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
      renderComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
  }

  public ComboBoxTableColumnSettings(final T[] values, final int preferredColumnCount) {
    this(values, preferredColumnCount, (IObjectUi<T>) null);
  }

  public ComboBoxTableColumnSettings(
      final T[] values,
      final int preferredColumnCount,
      final IObjectUi<T> objectUi) {
    this(new ConstantValuesProvider<T>(values), preferredColumnCount, objectUi);
  }

  public ComboBoxTableColumnSettings(final T[] values, final IObjectUi<T> objectUi) {
    this(
        new ConstantValuesProvider<T>(values),
        new ComboBoxPreferredWidth<T>(values, objectUi),
        objectUi);
  }

  public ComboBoxTableColumnSettings(
      final IComboBoxValuesProvider<T> valuesProvider,
      final int preferredColumnCount,
      final IObjectUi<T> objectUi) {
    this(valuesProvider, new TextPreferredWidth(preferredColumnCount), objectUi);
  }

  private ComboBoxTableColumnSettings(
      final IComboBoxValuesProvider<T> valuesProvider,
      final IPreferredWidth preferredWidth,
      final IObjectUi<T> objectUi) {
    this.valuesProvider = valuesProvider;
    this.preferredWidth = preferredWidth.getPreferredWidth();
    if (objectUi != null) {
      editComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
      renderComboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    }
  }

  @Override
  public TableCellEditor getEditor() {
    return new DefaultCellEditor(editComboBox) {
      @Override
      public Component getTableCellEditorComponent(
          final JTable table,
          final Object value,
          final boolean isSelected,
          final int row,
          final int column) {
        editComboBox.setDirectValues(valuesProvider.getValues(row));
        LookAndFeelUtilities.adjustCell(editComboBox, table, isSelected, true, true);
        return super.getTableCellEditorComponent(table, value, isSelected, row, column);
      }
    };
  }

  @Override
  public TableCellRenderer getRenderer() {
    return renderComboBox;
  }

  public void setValues(final T[] values) {
    valuesProvider = new ConstantValuesProvider<T>(values);
  }

  @Override
  public boolean isResizable() {
    return true;
  }

  @Override
  public int getPreferredWidth() {
    return preferredWidth > 0 ? preferredWidth : editComboBox.getPreferredSize().width;
  }

  public void setTextEditable(final boolean textEditable) {
    editComboBox.setEditable(textEditable);
  }

  @Override
  public IObjectSelectionStrategy<T> getDoubleClickBehaviour() {
    return new NullDoubleClickBehaviour<T>();
  }

  @Override
  public Icon getIcon() {
    return null;
  }

  @Override
  public String getToolTipText() {
    return null;
  }
}