//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

// NOT_PUBLISHED
public interface IEditStoppedHandler {

  public void editCanceled();

  public void editFinished(Object value);

}