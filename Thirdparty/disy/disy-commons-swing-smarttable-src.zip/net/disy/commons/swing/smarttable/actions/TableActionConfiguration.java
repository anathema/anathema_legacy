// Copyright (c) 2010 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.actions;


public final class TableActionConfiguration implements ITableActionConfiguration {
  private final boolean isDoubleClickOnItemAction;
  private final ITableActionFactory tableActionFactory;

  public TableActionConfiguration(
      ITableActionFactory tableActionFactory,
      boolean isDoubleClickOnItemAction) {
    this.isDoubleClickOnItemAction = isDoubleClickOnItemAction;
    this.tableActionFactory = tableActionFactory;
  }

  @Override
  public boolean isDoubleClickOnItemAction() {
    return this.isDoubleClickOnItemAction;
  }

  @Override
  public ITableActionFactory getTableActionFactory() {
    return this.tableActionFactory;
  }
}
