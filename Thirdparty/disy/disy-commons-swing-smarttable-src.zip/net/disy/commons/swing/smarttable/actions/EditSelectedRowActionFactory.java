/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public abstract class EditSelectedRowActionFactory extends AbstractTableActionFactory {

  private final IActionConfiguration actionConfiguration;

  public EditSelectedRowActionFactory() {
    this(new ActionConfiguration("&Bearbeiten..."));
  }

  public EditSelectedRowActionFactory(final IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public Action createAction(final SmartTable table) {
    final SmartAction smartAction = new SmartAction(actionConfiguration) {
      @Override
      protected void execute(Component parentComponent) {
        int index = table.getSelectedRowIndex();
        boolean success = performEditRow(parentComponent, index);
        if (success) {
          table.getTable().getSelectionModel().setSelectionInterval(index, index);
        }
      }
    };
    table.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(final ListSelectionEvent e) {
        updateActionEnabled(table, smartAction);
      }
    });
    updateActionEnabled(table, smartAction);
    return smartAction;
  }

  private void updateActionEnabled(final SmartTable table, final SmartAction smartAction) {
    smartAction.setEnabled(table.getSelectedRowIndex() != -1);
  }

  protected abstract boolean performEditRow(Component parentComponent, int index);
}