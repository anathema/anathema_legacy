/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.model.test;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.smarttable.model.FixedOptionsObjectSelectionTableModel;

import org.junit.Test;

import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

public class FixedOptionsObjectSelectionTableModelTest {
  @Test
  public void columnCount() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[0]);
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    assertThat(tableModel.getColumnCount(), is(2));
  }

  @Test
  public void columnNames() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[0]);
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "column1", //$NON-NLS-1$
        "column2"); //$NON-NLS-1$
    assertThat(tableModel.getColumnName(0), is("column1")); //$NON-NLS-1$
    assertThat(tableModel.getColumnName(1), is("column2")); //$NON-NLS-1$
  }

  @Test
  public void items() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[]{ "value1", "value2" }); //$NON-NLS-1$ //$NON-NLS-2$
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    assertThat(tableModel.getRowCount(), is(2));
    assertThat(tableModel.getValueAt(0, 1), is((Object) "value1")); //$NON-NLS-1$
    assertThat(tableModel.getValueAt(1, 1), is((Object) "value2")); //$NON-NLS-1$
  }

  @Test
  public void editable() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[]{ "value1", "value2" }); //$NON-NLS-1$ //$NON-NLS-2$
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    assertThat(tableModel.isCellEditable(0, 0), is(true));
    assertThat(tableModel.isCellEditable(0, 1), is(false));
    assertThat(tableModel.isCellEditable(1, 0), is(true));
    assertThat(tableModel.isCellEditable(1, 1), is(false));
  }

  @Test
  public void nothingSelected() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[]{ "value1", "value2" }); //$NON-NLS-1$ //$NON-NLS-2$
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    assertThat(tableModel.getValueAt(0, 0), is((Object) false));
    assertThat(tableModel.getValueAt(1, 0), is((Object) false));
  }

  @Test
  public void withSelection() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[]{ "value1", "value2" }); //$NON-NLS-1$ //$NON-NLS-2$
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    selectionModel.setSelected("value2", true); //$NON-NLS-1$
    assertThat(tableModel.getValueAt(0, 0), is((Object) false));
    assertThat(tableModel.getValueAt(1, 0), is((Object) true));
  }

  @Test
  public void setValueAt() throws Exception {
    final FixedOptionsObjectSelectionModel<String> selectionModel = new FixedOptionsObjectSelectionModel<String>(
        new String[]{ "value1", "value2" }); //$NON-NLS-1$ //$NON-NLS-2$
    final FixedOptionsObjectSelectionTableModel<String> tableModel = new FixedOptionsObjectSelectionTableModel<String>(
        selectionModel,
        "a", //$NON-NLS-1$
        "b"); //$NON-NLS-1$
    tableModel.setValueAt(true, 1, 0);
    assertThat(selectionModel.isSelected("value1"), is(false)); //$NON-NLS-1$
    assertThat(selectionModel.isSelected("value2"), is(true)); //$NON-NLS-1$
  }
}
