/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.table.DefaultTableModel;

import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.swing.smarttable.column.HeaderTransformer;
import net.disy.commons.swing.smarttable.column.IDeprecatedTableColumn;
import net.disy.commons.swing.smarttable.column.SettingsTransformer;

public class SmartTableFactory {

  private SmartTableFactory() {
    // nothing to do
  }

  public static SmartTable create(final IDeprecatedTableColumn<?>... columns) {
    final Object[] columnNames = ArrayUtilities.transform(
        columns,
        Object.class,
        new HeaderTransformer());
    final ITableColumnViewSettings<?>[] settings = ArrayUtilities.transform(
        columns,
        getGenericColumnSettingsClass(),
        new SettingsTransformer());
    return new SmartTable(new DefaultTableModel(columnNames, 0), settings);
  }

  @SuppressWarnings({ "unchecked", "cast" })
  private static Class<ITableColumnViewSettings<?>> getGenericColumnSettingsClass() {
    return (Class<ITableColumnViewSettings<?>>) (Class) ITableColumnViewSettings.class;
  }
}