/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.column.AbstractTableColumn;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.columnsettings.ReadOnlyListModelTableModelColumnSettings;
import net.disy.commons.swing.table.IListModelTableColumnSettings;

public abstract class AbstractReadOnlyListModelColumn<L, C> extends AbstractTableColumn<L, C> {

  private final IListModel<L> listModel;
  private IListColumnValueConverter<L, C> rowToColumnValueAdapter;
  private IListModelTableColumnSettings<L, C> modelSettings;

  public AbstractReadOnlyListModelColumn(final IListModel<L> listModel) {
    Ensure.ensureArgumentNotNull(listModel);
    this.listModel = listModel;
  }

  protected abstract IListColumnValueConverter<L, C> createRowToColumnValueAdapter();

  @Override
  public IListColumnValueConverter<L, C> getRowToColumnValueAdapter() {
    if (rowToColumnValueAdapter == null) {
      rowToColumnValueAdapter = createRowToColumnValueAdapter();
    }
    return rowToColumnValueAdapter;
  }

  @Override
  public IListModelTableColumnSettings<L, C> getModelSettings() {
    if (modelSettings == null) {
      createModelSettings();
    }
    return modelSettings;
  }

  protected final void createModelSettings() {
    this.modelSettings = new ReadOnlyListModelTableModelColumnSettings<L, C>(
        listModel,
        getColumnName(),
        getColumnClass(),
        getRowToColumnValueAdapter());
  }

  @Override
  public boolean isEditable() {
    return false;
  }
}