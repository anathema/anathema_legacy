/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;

public class SmartTableConfigurationBuilder {

  private int visibleRowCount = 6;
  private final ITableColumnViewSettings<? extends Object>[] columnViewSettings;
  private List<ITableActionConfiguration> tableActionConfigurations = new ArrayList<ITableActionConfiguration>();
  private ListSelectionMode selectionMode = ListSelectionMode.SINGLE_SELECTION;

  public SmartTableConfigurationBuilder(
      ITableColumnViewSettings<? extends Object>... columnViewSettings) {
    this.columnViewSettings = columnViewSettings;
  }

  public ISmartTableConfiguration build() {
    return new SmartTableConfiguration(
        visibleRowCount,
        selectionMode,
        tableActionConfigurations,
        columnViewSettings);
  }

  public SmartTableConfigurationBuilder setVisibleRowCount(int visibleRowCount) {
    this.visibleRowCount = visibleRowCount;
    return this;
  }

  public SmartTableConfigurationBuilder setTableActionConfigurations(
      List<ITableActionConfiguration> tableActionConfigurations) {
    this.tableActionConfigurations = tableActionConfigurations;
    return this;
  }

  public SmartTableConfigurationBuilder addTableActionConfiguration(
      ITableActionConfiguration tableActionConfiguration) {
    this.tableActionConfigurations.add(tableActionConfiguration);
    return this;
  }

  public SmartTableConfigurationBuilder setSelectionMode(ListSelectionMode selectionMode) {
    this.selectionMode = selectionMode;
    return this;
  }

}
