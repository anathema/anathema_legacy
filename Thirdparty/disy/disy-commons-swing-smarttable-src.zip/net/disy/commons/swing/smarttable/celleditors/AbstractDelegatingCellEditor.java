/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Component;
import java.awt.event.ActionListener;
import java.lang.reflect.Method;
import java.util.EventObject;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.JTree;

public abstract class AbstractDelegatingCellEditor extends AbstractCellEditor
    implements
    ICellEditor {

  private JComponent editorComponent;
  private EditorDelegate delegate;

  private void initialize() {
    if (editorComponent != null) {
      return;
    }
    editorComponent = createEditorComponent();
    delegate = createDelegate(editorComponent);
    attachEditorActionListener(editorComponent, delegate);
  }

  protected void attachEditorActionListener(
      final JComponent editor,
      final ActionListener actionListener) {
    try {
      final Method addActionListener = editor.getClass().getMethod(
          "addActionListener", new Class[]{ ActionListener.class }); //$NON-NLS-1$
      addActionListener.invoke(editor, new Object[]{ actionListener });
    }
    catch (final Exception exception) {
      // ignore problems - we don't know wether an action listener can be registered at all
    }
  }

  @Override
  public final Object getCellEditorValue() {
    initialize();
    return delegate.getCellEditorValue();
  }

  @Override
  public final boolean isCellEditable(final EventObject anEvent) {
    initialize();
    return delegate.isCellEditable(anEvent);
  }

  @Override
  public final boolean shouldSelectCell(final EventObject anEvent) {
    return true;
  }

  @Override
  public final boolean stopCellEditing() {
    initialize();
    return delegate.stopCellEditing();
  }

  @Override
  public final void cancelCellEditing() {
    initialize();
    delegate.cancelCellEditing();
  }

  @Override
  public final Component getTreeCellEditorComponent(
      final JTree tree,
      final Object value,
      final boolean isSelected,
      final boolean expanded,
      final boolean leaf,
      final int row) {
    initialize();
    delegate.setValue(value);
    return editorComponent;
  }

  @Override
  public final Component getTableCellEditorComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final int row,
      final int column) {
    initialize();
    delegate.setValue(value);
    return editorComponent;
  }

  protected JComponent getEditorComponent() {
    initialize();
    return editorComponent;
  }

  protected abstract EditorDelegate createDelegate(JComponent editor);

  protected abstract JComponent createEditorComponent();

}