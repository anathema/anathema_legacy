/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.ImmutableListModel;
import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.listtable.ListTable;

public class TableSelectionDialogPanel<T> extends AbstractSmartDialogPanel {
  private final ITableSelectionPanelConfiguration<T> configuration;
  private final FixedOptionsObjectSelectionModel<T> selectedItemsModel;
  private final ListTable<T> list;

  public TableSelectionDialogPanel(
      final FixedOptionsObjectSelectionModel<T> selectedItemsModel,
      final ITableSelectionPanelConfiguration<T> configuration) {
    Ensure.ensureArgumentNotNull(selectedItemsModel);
    Ensure.ensureArgumentNotNull(configuration);
    this.selectedItemsModel = selectedItemsModel;
    this.configuration = configuration;

    final IListModel<T> listModel = new ImmutableListModel<T>(selectedItemsModel.getAllValues());

    final ObjectModel<T> selectionModel = new ObjectModel<T>();
    selectedItemsModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        selectionModel.setValue(selectedItemsModel.getFirstSelectedValue());
      }
    });
    selectionModel.setValue(selectedItemsModel.getFirstSelectedValue());

    final Iterable<ITableColumn> columns = configuration.createTableColumns(listModel);
    list = ListTable.createImmutable(listModel, columns, selectionModel);
    selectionModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        selectedItemsModel.setSelectedValue(selectionModel.getValue());
      }
    });

    list.addDoubleClickActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        fireRequestFinish();
      }
    });
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    selectedItemsModel.addChangeListener(listener);
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    if (getSelectedItems().size() == 0) {
      final String noItemSelectedErrorMessageText = configuration
          .getNoItemSelectedErrorMessageText();
      if (noItemSelectedErrorMessageText != null) {
        return new BasicMessage(noItemSelectedErrorMessageText, MessageType.ERROR);
      }
    }

    return null;
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_BOTH);
    layoutData.setHorizontalSpan(columnCount);
    panel.add(list.getContent(), layoutData);
  }

  public List<T> getSelectedItems() {
    return selectedItemsModel.getSelectedValues();
  }

  public FixedOptionsObjectSelectionModel<T> getSelectedItemModel() {
    return selectedItemsModel;
  }

  @Override
  public void requestFocus() {
    list.requestFocus();
  }
}