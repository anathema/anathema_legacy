/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.list.AsynchronousFilteredListModel;
import net.disy.commons.swing.mousecursor.util.CursorUtilities;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.text.ClearTextFieldButton;
import net.disy.commons.swing.text.TextWidgetFactory;
import net.disy.commons.swing.ui.IObjectUi;

public class FilteringStrategy<T> implements IFilterStrategy<T> {

  private final IObjectModel<String> filterTextModel = new ObjectModel<String>();
  private final JTextField filterTextField;
  private AsynchronousFilteredListModel<T> listModel;
  private DeprecatedListTable<T> filterableListTable;
  private SmartTable smartTable;

  public FilteringStrategy() {
    filterTextField = TextWidgetFactory.createTextField(filterTextModel, 20);
  }

  @Override
  public IListModel<T> createListModel(IListModel<T> originalModel, final IObjectUi<T>[] objectUis) {
    listModel = new AsynchronousFilteredListModel<T>(originalModel);
    filterTextModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateFilter(objectUis);
      }
    });
    return listModel;
  }

  @Override
  public void updateFilter(IObjectUi<T>[] objectUis) {
    listModel.setFilter(new ObjectUiStringFilter<T>(objectUis, filterTextModel.getValue()));
  }

  @Override
  public void addFilterWidgets(JPanel panel, JComponent tableComponent) {
    panel.add(new JLabel("Filter:"));
    ClearTextFieldButton button = new ClearTextFieldButton(filterTextField, "Filter zurücksetzen");
    panel.add(TextWidgetFactory.createInternalComponentWrappedTextFieldComponent(
        null,
        filterTextField,
        button));
    CursorUtilities.attachWaitCursorForBusyModel(tableComponent, (listModel).getBusyModel());
  }

  @Override
  public void attachTo(final DeprecatedListTable<T> listTable, SmartTable smartTable) {
    this.filterableListTable = listTable;
    this.smartTable = smartTable;
    filterTextField.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(final KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_UP) {
          listTable.moveSelectionIndex(-1);
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
          listTable.moveSelectionIndex(1);
        }
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
          filterTextModel.setValue("");
        }
      }
    });
  }

  public void clearFilter() {
    filterTextField.setText("");
  }

  public void setFilterText(String filterText) {
    filterTextField.setText(filterText);
  }

  @Override
  public void requestFocus() {
    filterTextField.requestFocus();
  }

  public JTextField getFilterTextField() {
    return filterTextField;
  }

  public void applySingleFilterResult(final IBlock applySelection) {
    filterableListTable.getSelectionModel().setSelectionInterval(0, 0);
    filterableListTable.updateSelection();
    applySelection.execute();
    clearFilter();
    filterableListTable.requestFocus();
  }

  public void leaveFilter() {
    smartTable.requestFocus();
    if (smartTable.getSelectionModel().isSelectionEmpty() && listModel.getItemCount() > 0) {
      smartTable.getSelectionModel().setSelectionInterval(0, 0);
      smartTable.getTable().setEditingRow(0);
    }
  }

  public void enableEnterActionsOnFilter(IBlock applySelection) {
    filterTextField.addKeyListener(new EnterActionListener<T>(listModel, applySelection, this));
  }

  @Override
  public void keepSelectionUpToDate(ObjectModel<T> selectionModel) {
    listModel.addChangeListener(new AsynchronousUpdateSelectionListener<T>(
        filterableListTable,
        listModel,
        selectionModel));
  }

  @Override
  public void waitForFilteringFinished() {
    listModel.waitForFilteringFinished();
  }
}