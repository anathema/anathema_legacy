/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

public class ListTableDemoModelItem {

  private String name;

  public void setName(String name) {
    this.name = name;
  }

  private final long number;
  private final boolean flag;

  public ListTableDemoModelItem(String name, long number, boolean flag) {
    super();
    this.name = name;
    this.number = number;
    this.flag = flag;
  }

  public String getName() {
    return name;
  }

  public long getNumber() {
    return number;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + (flag ? 1231 : 1237);
    result = prime * result + ((name == null) ? 0 : name.hashCode());
    result = prime * result + (int) (number ^ (number >>> 32));
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    if (obj == null) {
      return false;
    }
    if (getClass() != obj.getClass()) {
      return false;
    }
    ListTableDemoModelItem other = (ListTableDemoModelItem) obj;
    if (flag != other.flag) {
      return false;
    }
    if (name == null) {
      if (other.name != null) {
        return false;
      }
    }
    else if (!name.equals(other.name)) {
      return false;
    }
    if (number != other.number) {
      return false;
    }
    return true;
  }

  public boolean isFlag() {
    return flag;
  }

  @Override
  public String toString() {
    return "ListTableDemoModelItem [name=" + name + ", number=" + number + ", flag=" + flag + "]";
  }

}
