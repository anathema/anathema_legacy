//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.celleditors.StringCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.StringCellRenderer;

// NOT_PUBLISHED
public class StringTableColumnSettings extends AbstractTableColumnSettings {

  private final TableCellRenderer renderer;

  public StringTableColumnSettings() {
    this(8, new StringCellRenderer());
  }

  public StringTableColumnSettings(int preferredColumnCount) {
    this(preferredColumnCount, new StringCellRenderer());
  }

  public StringTableColumnSettings(TableCellRenderer renderer) {
    this(8, renderer);
  }

  public StringTableColumnSettings(int preferredColumnCount, TableCellRenderer renderer) {
    super(preferredColumnCount);
    this.renderer = renderer;
  }

  public TableCellEditor getEditor() {
    return new StringCellEditor();
  }

  public TableCellRenderer getRenderer() {
    return renderer;
  }
}