/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Color;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.celleditors.StringCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.StringCellRenderer;

public class StringTableColumnSettings extends AbstractTableColumnSettings<String> {

  public static final int PREFERRED_STRING_COLUMN_COUNT = 8;
  final TableCellEditor editor;
  private final TableCellRenderer renderer;

  public StringTableColumnSettings() {
    this(PREFERRED_STRING_COLUMN_COUNT, new StringCellRenderer());
  }

  public StringTableColumnSettings(final int preferredColumnCount) {
    this(preferredColumnCount, new StringCellRenderer());
  }

  public StringTableColumnSettings(int preferredColumnCount, boolean showTooltip) {
    this(preferredColumnCount, new StringCellRenderer(showTooltip));
  }

  public StringTableColumnSettings(final Color background) {
    this(8, new StringCellRenderer(), background);
  }

  public StringTableColumnSettings(final TableCellRenderer renderer) {
    this(8, renderer);
  }

  public StringTableColumnSettings(final int preferredColumnCount, final TableCellRenderer renderer) {
    this(preferredColumnCount, renderer, null);
  }

  public StringTableColumnSettings(
      final int preferredColumnCount,
      final TableCellRenderer renderer,
      final Color background) {
    this(preferredColumnCount, renderer, new StringCellEditor(), background);
  }

  public StringTableColumnSettings(
      final int preferredColumnCount,
      final TableCellRenderer renderer,
      final TableCellEditor editor,
      final Color background) {
    super(preferredColumnCount, background);
    this.renderer = renderer;
    this.editor = editor;
  }

  public StringTableColumnSettings(
      final int preferredColumnCount,
      StringCellRenderer renderer,
      TableCellEditor editor) {
    this(preferredColumnCount, renderer, editor, null);
  }

  @Override
  public TableCellEditor getEditor() {
    return editor;
  }

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return renderer;
  }
}