//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;

import net.disy.commons.swing.textfield.DoubleField;

// NOT_PUBLISHED
public class DoubleCellEditor extends AbstractDelegatingCellEditor {

  //@Overrides
  protected final EditorDelegate createDelegate(JComponent editorComponent) {
    final DoubleField textField = (DoubleField) editorComponent;
    return new EditorDelegate(this) {
      public void setValue(Object value) {
        textField.setValue(((Number)value).doubleValue());
        textField.selectAll();
      }

      public Object getCellEditorValue() {
        return new Double(textField.getValue());
      }
    };
  }

  //@Overrides
  protected JComponent createEditorComponent() {
    return new DoubleField();
  }

}