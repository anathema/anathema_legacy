/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Color;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.celleditors.ColorCellEditor;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.TextPreferredWidth;

/** @see ColorEditorTableColumnSettings */
public class ColorIndicatorTableColumnSettings extends AbstractTableColumnSettings<Color> {

  public ColorIndicatorTableColumnSettings() {
    super(new TextPreferredWidth(3));
  }

  @Override
  public TableCellEditor getEditor() {
    return new ColorCellEditor(true);
  }

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return new ColorCellEditor(true);
  }
}