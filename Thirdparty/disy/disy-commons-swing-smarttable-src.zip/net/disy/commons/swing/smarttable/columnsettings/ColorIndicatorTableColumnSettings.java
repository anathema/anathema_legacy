//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;


import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.celleditors.ColorCellEditor;

// NOT_PUBLISHED
/** @see ColorEditorTableColumnSettings */
public class ColorIndicatorTableColumnSettings implements ITableColumnViewSettings {
  
  public TableCellEditor getEditor() {
    return new ColorCellEditor(true);
  }

  public TableCellRenderer getRenderer() {
    return new ColorCellEditor(true);
  }

  public int getPreferredWidth() {
    return 40;
  }

  public boolean isResizable() {
    return true;
  }
}