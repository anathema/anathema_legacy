//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;
import javax.swing.JTextField;

// NOT_PUBLISHED
public class StringCellEditor extends AbstractDelegatingCellEditor {

  //@Overrides
  protected final EditorDelegate createDelegate(JComponent editorComponent) {
    final JTextField textField = (JTextField) editorComponent;
    return new EditorDelegate(this) {
      public void setValue(Object value) {
        textField.setText((value != null) ? value.toString() : ""); //$NON-NLS-1$
        textField.selectAll();
      }

      public Object getCellEditorValue() {
        return textField.getText();
      }
    };
  }

  //@Overrides
  protected JComponent createEditorComponent() {
    return new JTextField();
  }

}