//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import javax.swing.JComponent;
import javax.swing.JTextField;

// NOT_PUBLISHED
public class StringCellEditor extends AbstractDelegatingCellEditor {

  //@Overrides
  @Override
  protected final EditorDelegate createDelegate(JComponent editorComponent) {
    final JTextField textField = (JTextField) editorComponent;
    return new EditorDelegate(this) {
      @Override
      public void setValue(Object value) {
        textField.setText((value != null) ? value.toString() : ""); //$NON-NLS-1$
        textField.selectAll();
      }

      @Override
      public Object getCellEditorValue() {
        return textField.getText();
      }
    };
  }

  //@Overrides
  @Override
  protected JComponent createEditorComponent() {
    return new JTextField();
  }

}