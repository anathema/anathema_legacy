/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public abstract class RemoveRowsTableActionFactory extends AbstractTableActionFactory {

  private final IActionConfiguration actionConfiguration;

  public RemoveRowsTableActionFactory() {
    this(new ActionConfiguration("Löschen", null, "Auswahl löschen"));
  }

  public RemoveRowsTableActionFactory(final IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public Action createAction(final SmartTable table) {
    final ITableRowsRemovePerformer removePerformer = new ITableRowsRemovePerformer() {
      @Override
      public boolean performRemove(final Component parentComponent, final int[] rowIndex) {
        return RemoveRowsTableActionFactory.this.performRemove(parentComponent, rowIndex);
      }
    };
    final SmartAction action = new RemoveRowsTableAction(
        actionConfiguration,
        table,
        removePerformer);
    if (table.isToolBarStyleButtons()) {
      action.setIcon(TableActionResources.DELETE_ROW_ICON);
    }
    return action;
  }

  protected abstract boolean performRemove(Component parentComponent, int[] rowIndex);
}
