/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import java.util.ArrayList;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;
import net.disy.commons.swing.smarttable.listtable.ListTableConfiguration;

public class SmartTableConfiguration extends ListTableConfiguration
    implements
    ISmartTableConfiguration {

  private final ITableColumnViewSettings<? extends Object>[] columnViewSettings;

  /**
   *  @deprecated As of 20100813 (bartels), replaced by {@link SmartTableConfigurationBuilder}
   */
  @Deprecated
  public SmartTableConfiguration(final ITableColumnViewSettings<?>... columnViewSettings) {
    this(6, columnViewSettings);
  }

  /**
   *  @deprecated As of 20100813 (bartels), replaced by {@link SmartTableConfigurationBuilder}
   */
  @Deprecated
  public SmartTableConfiguration(
      final int visibleRowCount,
      final ITableColumnViewSettings<?>... columnViewSettings) {
    this(visibleRowCount, new ArrayList<ITableActionConfiguration>(), columnViewSettings);
  }

  /**
   *  @deprecated As of 20100813 (bartels), replaced by {@link SmartTableConfigurationBuilder}
   */
  @Deprecated
  public SmartTableConfiguration(
      final int visibleRowCount,
      final Iterable<ITableActionConfiguration> tableActionConfigurations,
      final ITableColumnViewSettings<?>... columnViewSettings) {
    this(
        visibleRowCount,
        ListSelectionMode.SINGLE_SELECTION,
        tableActionConfigurations,
        columnViewSettings);
  }

  SmartTableConfiguration(
      final int visibleRowCount,
      final ListSelectionMode selectionSelection,
      final Iterable<ITableActionConfiguration> tableActionConfigurations,
      final ITableColumnViewSettings<? extends Object>[] columnViewSettings) {
    super(visibleRowCount, tableActionConfigurations, selectionSelection);
    Ensure.ensureArgumentNotNull(columnViewSettings);
    Ensure.ensureArgumentNotNull(tableActionConfigurations);
    this.columnViewSettings = columnViewSettings;
  }

  @Override
  public ITableColumnViewSettings<? extends Object>[] getColumnViewSettings() {
    return columnViewSettings;
  }

}