//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiTableCellRenderer;

// NOT_PUBLISHED
public class ObjectUiTableColumnSettings implements ITableColumnViewSettings {

  private final IObjectUi ui;
  private final TableCellEditor editor;
  private int preferredWidth = 100;

  public ObjectUiTableColumnSettings(IObjectUi ui) {
    this(ui, null);
  }

  public ObjectUiTableColumnSettings(IObjectUi ui, TableCellEditor editor) {
    Ensure.ensureArgumentNotNull(ui);
    this.ui = ui;
    this.editor = editor;
  }

  public TableCellEditor getEditor() {
    return editor;
  }

  public TableCellRenderer getRenderer() {
    return new ObjectUiTableCellRenderer(ui);
  }

  public boolean isResizable() {
    return true;
  }

  public int getPreferredWidth() {
    return preferredWidth;
  }

  public void setPreferredWidth(int preferredWidth) {
    this.preferredWidth = preferredWidth;
  }
}