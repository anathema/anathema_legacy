//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiTableCellRenderer;

// NOT_PUBLISHED
public class ObjectUiTableColumnSettings implements ITableColumnViewSettings {
  
  private final IObjectUi ui;

  public ObjectUiTableColumnSettings(IObjectUi ui) {
    Ensure.ensureArgumentNotNull(ui);
    this.ui = ui;
  }
  
  public TableCellEditor getEditor() {
    return null;
  }

  public TableCellRenderer getRenderer() {
    return new ObjectUiTableCellRenderer(ui);
  }

  public boolean isResizable() {
    return true;
  }

  public int getPreferredWidth() {
    return 100;
  }
}