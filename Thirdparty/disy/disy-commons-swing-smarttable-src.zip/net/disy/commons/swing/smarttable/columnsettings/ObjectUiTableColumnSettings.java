/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.Icon;
import javax.swing.SwingConstants;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.IObjectSelectionStrategy;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiTableCellRenderer;

public class ObjectUiTableColumnSettings<T> implements ITableColumnViewSettings<T> {

  protected final IObjectUi<T> ui;
  private final TableCellEditor editor;
  private int preferredWidth = 100;
  protected int alignment;
  protected boolean showText = true;
  private boolean resizable = true;

  public ObjectUiTableColumnSettings(final IObjectUi<T> ui) {
    this(ui, null);
  }

  public ObjectUiTableColumnSettings(final IObjectUi<T> ui, final int alignment) {
    this(ui, null, alignment);
  }

  public ObjectUiTableColumnSettings(final IObjectUi<T> ui, final TableCellEditor editor) {
    this(ui, editor, SwingConstants.LEFT);
  }

  public ObjectUiTableColumnSettings(
      final IObjectUi<T> ui,
      final TableCellEditor editor,
      final int alignment) {
    Ensure.ensureArgumentNotNull(ui);
    this.ui = ui;
    this.editor = editor;
    this.alignment = alignment;
  }

  @Override
  public TableCellEditor getEditor() {
    return editor;
  }

  @Override
  public TableCellRenderer getRenderer() {
    return new ObjectUiTableCellRenderer<T>(ui, alignment, showText);
  }

  public void setResizable(final boolean resizable) {
    this.resizable = resizable;
  }

  @Override
  public boolean isResizable() {
    return resizable;
  }

  @Override
  public int getPreferredWidth() {
    return preferredWidth;
  }

  public void setPreferredWidth(final int preferredWidth) {
    this.preferredWidth = preferredWidth;
  }

  public void setShowText(final boolean showText) {
    this.showText = showText;
  }

  @Override
  public IObjectSelectionStrategy<T> getDoubleClickBehaviour() {
    return new NullDoubleClickBehaviour<T>();
  }

  @Override
  public Icon getIcon() {
    return null;
  }

  @Override
  public String getToolTipText() {
    return null;
  }

  final protected IObjectUi<T> getUi() {
    return ui;
  }

  final protected int getAlignment() {
    return alignment;
  }

  final protected boolean isShowText() {
    return showText;
  }
}