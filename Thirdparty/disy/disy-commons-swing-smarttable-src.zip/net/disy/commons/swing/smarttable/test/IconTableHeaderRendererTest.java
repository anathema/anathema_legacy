/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertTrue;

import java.awt.Component;
import java.util.ArrayList;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.RowSorter.SortKey;
import javax.swing.SortOrder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import net.disy.commons.swing.icon.EmptyIcon;
import net.disy.commons.swing.smarttable.IconTableHeaderRenderer;

import org.junit.Test;

public class IconTableHeaderRendererTest {

  @Test
  public void renderComponentIsLabelWithIcon() throws Exception {
    final Icon icon = new EmptyIcon();
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(icon, null);
    final Component component = renderer.getTableCellRendererComponent(
        new JTable(),
        null,
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertSame(icon, label.getIcon());
  }

  @Test
  public void renderComponentHasToolTipFromValue() throws Exception {
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(new EmptyIcon(), null);
    final Component component = renderer.getTableCellRendererComponent(new JTable(), "value", //$NON-NLS-1$
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals("value", label.getToolTipText()); //$NON-NLS-1$
  }

  @Test
  public void renderComponentHasNullToolTipOnNullValue() throws Exception {
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(new EmptyIcon(), null);
    final Component component = renderer.getTableCellRendererComponent(
        new JTable(),
        null,
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals(null, label.getToolTipText());
  }

  @Test
  public void renderComponentHasNullToolTipOnEmptyStringValue() throws Exception {
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(new EmptyIcon(), null);
    final Component component = renderer.getTableCellRendererComponent(new JTable(), "", //$NON-NLS-1$
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals(null, label.getToolTipText());
  }

  @Test
  public void renderComponentHasSpecifiedToolTipOnSpecifiedTooltip() throws Exception {
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(new EmptyIcon(), "tip"); //$NON-NLS-1$
    final Component component = renderer.getTableCellRendererComponent(new JTable(), "foo", //$NON-NLS-1$
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertEquals("tip", label.getToolTipText()); //$NON-NLS-1$
  }

  @Test
  public void renderComponentHasSortAscendingIcon() {
    EmptyIcon icon = new EmptyIcon();
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(icon, "tip"); //$NON-NLS-1$
    JTable table = new JTable(new DefaultTableModel(10, 10));
    TableRowSorter<TableModel> rowSorter = new TableRowSorter<TableModel>(table.getModel());
    table.setRowSorter(rowSorter);
    SortKey sortKey = new SortKey(0, SortOrder.ASCENDING);
    ArrayList<SortKey> sortKeys = new ArrayList<SortKey>();
    sortKeys.add(sortKey);
    rowSorter.setSortKeys(sortKeys);
    rowSorter.sort();
    Component component = renderer.getTableCellRendererComponent(table, "foo", //$NON-NLS-1$
        false,
        false,
        0,
        0);
    final JLabel label = (JLabel) component;
    assertTrue(label.getIcon().getIconWidth() > icon.getIconWidth());
    assertTrue(label.getIcon().getIconHeight() > icon.getIconHeight());
    component = renderer.getTableCellRendererComponent(table, "foo", //$NON-NLS-1$
        false,
        false,
        0,
        1);
    assertEquals(icon, label.getIcon());
  }

  @Test
  public void renderComponentHasSortDescendingIcon() {
    EmptyIcon icon = new EmptyIcon();
    final IconTableHeaderRenderer renderer = new IconTableHeaderRenderer(icon, "tip"); //$NON-NLS-1$
    JTable table = new JTable(new DefaultTableModel(10, 10));
    TableRowSorter<TableModel> rowSorter = new TableRowSorter<TableModel>(table.getModel());
    table.setRowSorter(rowSorter);
    SortKey sortKey = new SortKey(1, SortOrder.DESCENDING);
    ArrayList<SortKey> sortKeys = new ArrayList<SortKey>();
    sortKeys.add(sortKey);
    rowSorter.setSortKeys(sortKeys);
    rowSorter.sort();
    Component component = renderer.getTableCellRendererComponent(table, "foo", //$NON-NLS-1$
        false,
        false,
        0,
        1);
    final JLabel label = (JLabel) component;
    assertTrue(label.getIcon().getIconWidth() > icon.getIconWidth());
    assertTrue(label.getIcon().getIconHeight() > icon.getIconHeight());
    component = renderer.getTableCellRendererComponent(table, "foo", //$NON-NLS-1$
        false,
        false,
        0,
        0);
    assertEquals(icon, label.getIcon());
  }
}