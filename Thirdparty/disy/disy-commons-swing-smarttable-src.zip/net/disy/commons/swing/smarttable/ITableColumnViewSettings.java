/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.Icon;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

public interface ITableColumnViewSettings<T> {

  public TableCellEditor getEditor();

  public IObjectSelectionStrategy<T> getDoubleClickBehaviour();

  public TableCellRenderer getRenderer();

  public boolean isResizable();

  public int getPreferredWidth();

  /** @return the icon for the column heading or <code>null</code> if none. */
  public Icon getIcon();

  /** @return the tooltip text for the column heading or <code>null</code> if none. */
  public String getToolTipText();
}