// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 28.06.2004
package net.disy.commons.swing.smarttable.actions;

import javax.swing.Icon;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.swing.image.ImageProvider;

// NOT_PUBLISHED
public class TableActionResources {

  public static final Icon ADD_ROW_ICON = getImageIcon("add_row.gif"); //$NON-NLS-1$
  public static final Icon DELETE_ROW_ICON = getImageIcon("delete_row.gif"); //$NON-NLS-1$

  private TableActionResources() {
    throw new UnreachableCodeReachedException();
  }

  private static Icon getImageIcon(String relativePath) {
    return new ImageProvider("net/disy/commons/swing/smarttable/icons").getImageIcon(relativePath); //$NON-NLS-1$
  }
}