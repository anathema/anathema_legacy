/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import javax.swing.Icon;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.swing.image.ImageProvider;

public class TableActionResources {

  public static final Icon ADD_ROW_ICON = getImageIcon("add.png"); //$NON-NLS-1$
  public static final Icon DELETE_ROW_ICON = getImageIcon("remove.png"); //$NON-NLS-1$

  private TableActionResources() {
    throw new UnreachableCodeReachedException();
  }

  private static Icon getImageIcon(final String relativePath) {
    return new ImageProvider("net/disy/commons/swing/smarttable/icons").getImageIcon(relativePath); //$NON-NLS-1$
  }
}