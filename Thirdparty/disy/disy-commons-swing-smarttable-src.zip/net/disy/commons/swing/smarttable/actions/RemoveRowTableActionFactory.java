//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

// NOT_PUBLISHED
public abstract class RemoveRowTableActionFactory implements ITableActionFactory {

  private final IActionConfiguration actionConfiguration;

  public RemoveRowTableActionFactory() {
    //TODO 24.01.2006 (Markus Gebhard): i18n!
    this(new ActionConfiguration("Entfernen", null, "Ausgew�hlten Eintrag entfernen"));
  }

  public RemoveRowTableActionFactory(IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.actionConfiguration = actionConfiguration;
  }

  public Action createAction(final SmartTable table) {
    final SmartAction action = new SmartAction(actionConfiguration) {
      protected void execute(Component parentComponent) {
        int selectedRowIndex = table.getTable().getSelectedRow();
        table.stopCellEditing();

        if (performRemove(parentComponent, selectedRowIndex)) {
          if (table.getTable().getModel().getRowCount() > 0) {
            int newRowIndex = Math.min(
                table.getTable().getModel().getRowCount() - 1,
                selectedRowIndex);
            table.scrollToAndSelect(newRowIndex);
            table.requestFocus();
          }
        }
      }
    };
    table.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        updateEnabled(table, action);
      }
    });
    updateEnabled(table, action);
    //TODO 24.01.2006 (Markus Gebhard): Anders l�sen!
    if (table.isToolBarStyleButtons()) {
      action.setIcon(TableActionResources.DELETE_ROW_ICON);
    }
    return action;
  }

  private void updateEnabled(SmartTable smartTable, Action action) {
    action.setEnabled(!smartTable.isSelectionEmpty());
  }

  /** Perform the remove operation to remove the selected item from the table. If this method
   * returns <code>true</code> the table assumes the line has been deleted. It might then try
   * to select the next row.
   * @param rowIndex The index of the row to be removed.
   * @return <code>true</code> if the line was removed. */
  protected abstract boolean performRemove(Component parentComponent, int rowIndex);

}