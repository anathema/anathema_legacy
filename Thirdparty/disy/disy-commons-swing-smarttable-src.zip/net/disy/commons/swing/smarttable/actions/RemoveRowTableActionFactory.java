/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public abstract class RemoveRowTableActionFactory extends AbstractTableActionFactory {

  private final IActionConfiguration actionConfiguration;

  public RemoveRowTableActionFactory() {
    this(new ActionConfiguration("Löschen", null, "Auswahl löschen"));
  }

  public RemoveRowTableActionFactory(final IActionConfiguration actionConfiguration) {
    Ensure.ensureArgumentNotNull(actionConfiguration);
    this.actionConfiguration = actionConfiguration;
  }

  @Override
  public Action createAction(final SmartTable table) {
    final ITableRowRemovePerformer removePerformer = new ITableRowRemovePerformer() {
      @Override
      public boolean performRemove(final Component parentComponent, final int rowIndex) {
        return RemoveRowTableActionFactory.this.performRemove(parentComponent, rowIndex);
      }
    };
    final SmartAction action = new RemoveRowTableAction(actionConfiguration, table, removePerformer);
    if (table.isToolBarStyleButtons()) {
      action.setIcon(TableActionResources.DELETE_ROW_ICON);
    }
    return action;
  }

  /**
   * Perform the remove operation to remove the selected item from the table. If this method returns
   * <code>true</code> the table assumes the line has been deleted. It might then try to select the
   * next row.
   * 
   * @param rowIndex The index of the row to be removed.
   * @return <code>true</code> if the line was removed.
   */
  protected abstract boolean performRemove(Component parentComponent, int rowIndex);

}