/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.IntegerTableColumnSettings;
import net.disy.commons.swing.smarttable.filtered.IntegerValueFilterStrategy;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;
import net.disy.commons.swing.smarttable.sorter.ComparableSorterConfiguration;

public abstract class AbstractDemoColorItemColorValueColumn
    extends
    AbstractReadOnlyListModelColumn<DemoColorItem, Integer> {

  private final String columnName;

  public AbstractDemoColorItemColorValueColumn(
      final IListModel<DemoColorItem> listModel,
      final String columnName) {
    super(listModel);
    Ensure.ensureArgumentNotNull(columnName);
    this.columnName = columnName;
  }

  @Override
  protected final TableColumnConfiguration<Integer> createConfiguration() {
    final TableColumnConfiguration<Integer> configuration = new TableColumnConfiguration<Integer>(
        columnName,
        Integer.class,
        new IntegerTableColumnSettings(0, 255, 1));
    configuration.setFilterConfiguration(new IntegerValueFilterStrategy());
    configuration.setSorterConfiguration(new ComparableSorterConfiguration<Integer>());
    return configuration;
  }
}