/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.JComponent;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;

public class SmartTableDialogPage extends AbstractDialogPage {

  private final ITableDialogPageConfiguration configuration;

  public SmartTableDialogPage(ITableDialogPageConfiguration configuration) {
    super(configuration.getDefaultMessageText());
    this.configuration = configuration;
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    return getDefaultMessage();
  }

  @Override
  public JComponent createContent() {
    return new SmartTable(configuration.getTableModel(), configuration.getSmartTableConfiguration())
        .getContent();
  }

  @Override
  public String getTitle() {
    return configuration.getTitle();
  }

}
