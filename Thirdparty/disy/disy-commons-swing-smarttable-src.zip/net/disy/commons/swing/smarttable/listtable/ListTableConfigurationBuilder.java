/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.listtable;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;

public class ListTableConfigurationBuilder {

  private int visibleRowCount = 6;
  private ListSelectionMode selectionMode = ListSelectionMode.SINGLE_SELECTION;
  private List<ITableActionConfiguration> tableActionConfigurations = new ArrayList<ITableActionConfiguration>();

  public IListTableConfiguration build() {
    return new ListTableConfiguration(visibleRowCount, tableActionConfigurations, selectionMode);
  }

  public ListTableConfigurationBuilder setVisibleRowCount(int visibleRowCount) {
    this.visibleRowCount = visibleRowCount;
    return this;
  }

  public ListTableConfigurationBuilder setTableActionConfigurations(
      List<ITableActionConfiguration> tableActionConfigurations) {
    this.tableActionConfigurations = tableActionConfigurations;
    return this;
  }

  public ListTableConfigurationBuilder addTableActionConfiguration(
      ITableActionConfiguration tableActionConfiguration) {
    this.tableActionConfigurations.add(tableActionConfiguration);
    return this;
  }

  public ListTableConfigurationBuilder setSelectionMode(ListSelectionMode selectionMode) {
    this.selectionMode = selectionMode;
    return this;
  }

}
