//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors;

import java.text.Format;
import java.text.ParseException;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DefaultFormatterFactory;

public abstract class AbstractFormattedCellEditor extends AbstractDelegatingCellEditor {

  public AbstractFormattedCellEditor(Format format, NullValueStrategy nullValueStrategy) {
    AbstractFormatter formatter = createFormatter(format);
    formatter = nullValueStrategy.decorateFormatter(formatter);
    ((JFormattedTextField) getEditorComponent()).setFormatterFactory(new DefaultFormatterFactory(
        formatter));
  }

  protected abstract AbstractFormatter createFormatter(Format format);

  //@Overrides
  @Override
  protected final EditorDelegate createDelegate(JComponent editorComponent) {
    final JFormattedTextField textField = (JFormattedTextField) editorComponent;
    return new EditorDelegate(this) {
      @Override
      public void setValue(Object value) {
        textField.setValue(value);
        textField.selectAll();
      }

      @Override
      public Object getCellEditorValue() {
        try {
          textField.commitEdit();
        }
        catch (ParseException e) {
          // nothing to do
        }
        return textField.getValue();
      }
    };
  }

  //@Overrides
  @Override
  protected final JComponent createEditorComponent() {
    return new JFormattedTextField();
  }

}