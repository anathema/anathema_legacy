/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.text.Format;
import java.text.ParseException;

import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.DefaultFormatterFactory;

public abstract class AbstractFormattedCellEditor extends AbstractDelegatingCellEditor {

  private final int alignment;

  public AbstractFormattedCellEditor(
      final Format format,
      final CellEditorNullValueStrategy nullValueStrategy,
      final int alignment) {
    this.alignment = alignment;
    AbstractFormatter formatter = createFormatter(format);
    formatter = nullValueStrategy.decorateFormatter(formatter);
    ((JFormattedTextField) getEditorComponent()).setFormatterFactory(new DefaultFormatterFactory(
        formatter));
  }

  protected abstract AbstractFormatter createFormatter(Format format);

  @Override
  protected final EditorDelegate createDelegate(final JComponent editorComponent) {
    final JFormattedTextField textField = (JFormattedTextField) editorComponent;
    textField.setHorizontalAlignment(alignment);
    return new EditorDelegate(this) {
      @Override
      public void setValue(final Object value) {
        textField.setValue(value);
        textField.selectAll();
      }

      @Override
      public Object getCellEditorValue() {
        try {
          textField.commitEdit();
        }
        catch (final ParseException e) {
          // nothing to do
        }
        return textField.getValue();
      }
    };
  }

  @Override
  protected final JComponent createEditorComponent() {
    return new JFormattedTextField();
  }
}