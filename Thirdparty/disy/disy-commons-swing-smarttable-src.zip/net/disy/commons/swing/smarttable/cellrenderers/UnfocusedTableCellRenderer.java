// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 28.06.2004
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

// NOT_PUBLISHED
public class UnfocusedTableCellRenderer extends DefaultTableCellRenderer {

  @Override
  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    return super.getTableCellRendererComponent(table, value, isSelected, false, row, column);
  }

}