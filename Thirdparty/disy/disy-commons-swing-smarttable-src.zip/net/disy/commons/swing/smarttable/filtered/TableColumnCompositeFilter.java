/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import java.util.StringTokenizer;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.ITableColumn;

public class TableColumnCompositeFilter<R> implements IPredicate<R> {

  private final Iterable<ITableColumn> columns;
  private final String filterExpression;

  public TableColumnCompositeFilter(Iterable<ITableColumn> columns, final String filterExpression) {
    Ensure.ensureArgumentNotNull(columns);
    this.columns = columns;
    this.filterExpression = filterExpression;
  }

  @Override
  public boolean evaluate(final R value) {
    if (StringUtilities.isNullOrEmpty(filterExpression)) {
      return true;
    }
    if (value == null) {
      return false;
    }
    StringTokenizer filterTokenizer = new StringTokenizer(filterExpression);
    while (filterTokenizer.hasMoreTokens()) {
      String filterToken = filterTokenizer.nextToken();
      if (!matchesFilterToken(value, filterToken)) {
        return false;
      }
    }
    return true;
  }

  private boolean matchesFilterToken(final R value, final String filterToken) {
    boolean shouldFilter = false;
    for (ITableColumn column : columns) {
      IListColumnValueConverter<R, ?> valueAdapter = column.getRowToColumnValueAdapter();
      IFilterConfiguration filterConfiguration = column.getFilterConfiguration();
      if (!filterConfiguration.isFilterable()) {
        continue;
      }
      shouldFilter = true;
      IFilterMatchingStrategy matchingStrategy = filterConfiguration.getMatchingStrategy();
      Object columnValue = valueAdapter.getValue(value);
      if (columnValue == null) {
        continue;
      }
      if (matchingStrategy.matches(columnValue, filterToken)) {
        return true;
      }
    }
    return !shouldFilter;
  }
}