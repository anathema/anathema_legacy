//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.suite;

import junit.framework.Test;
import junit.framework.TestSuite;

import de.jdemo.junit.Demo2TestConverter;

// NOT_PUBLISHED
public class AllSmartTableTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.swing.smarttable.suite"); //$NON-NLS-1$
    suite.addTest(Demo2TestConverter.createTest(AllSmartTableDemos.suite()));
    //$JUnit-BEGIN$

    //$JUnit-END$
    return suite;
  }

}
