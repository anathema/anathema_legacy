//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.JTextField;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.smarttable.ITableColumnViewSettings;

// NOT_PUBLISHED
public abstract class AbstractTableColumnSettings implements ITableColumnViewSettings {

  private final int preferredWidth;

  public AbstractTableColumnSettings(int preferredColumnCount) {
    this.preferredWidth = (int) new JTextField(preferredColumnCount).getPreferredSize().getWidth();
  }

  public final int getPreferredWidth() {
    return preferredWidth;
  }

  public TableCellRenderer getRenderer() {
    return null;
  }

  public boolean isResizable() {
    return true;
  }

}