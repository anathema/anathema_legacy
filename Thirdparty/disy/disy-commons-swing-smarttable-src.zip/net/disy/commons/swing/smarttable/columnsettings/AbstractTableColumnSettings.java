/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Color;

import javax.swing.Icon;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.IObjectSelectionStrategy;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.IPreferredWidth;
import net.disy.commons.swing.smarttable.columnsettings.preferredwidth.TextPreferredWidth;

public abstract class AbstractTableColumnSettings<T> implements ITableColumnViewSettings<T> {

  private final int preferredWidth;
  private final Color background;
  private final Icon icon;

  public AbstractTableColumnSettings(final int preferredColumnCount) {
    this(new TextPreferredWidth(preferredColumnCount));
  }

  public AbstractTableColumnSettings(final int preferredColumnCount, final Icon icon) {
    this(new TextPreferredWidth(preferredColumnCount), icon);
  }

  public AbstractTableColumnSettings(final IPreferredWidth preferredWidth) {
    this(preferredWidth, (Icon) null);
  }

  public AbstractTableColumnSettings(final IPreferredWidth preferredWidth, final Icon icon) {
    this(preferredWidth, (Color) null, icon);
  }

  public AbstractTableColumnSettings(final int preferredColumnCount, final Color background) {
    this(new TextPreferredWidth(preferredColumnCount), background);
  }

  public AbstractTableColumnSettings(final IPreferredWidth preferredWidth, final Color background) {
    this(preferredWidth, background, null);
  }

  public AbstractTableColumnSettings(
      final IPreferredWidth preferredWidth,
      final Color background,
      final Icon icon) {
    Ensure.ensureArgumentNotNull(preferredWidth);
    this.preferredWidth = preferredWidth.getPreferredWidth();
    this.background = background;
    this.icon = icon;
  }

  @Override
  public IObjectSelectionStrategy<T> getDoubleClickBehaviour() {
    return new NullDoubleClickBehaviour<T>();
  }

  @Override
  public final int getPreferredWidth() {
    return preferredWidth;
  }

  @Override
  public final TableCellRenderer getRenderer() {
    final TableCellRenderer renderer = getBaseRenderer();
    return background != null
        ? new BackgroundColorTableCellRendererDecorator(renderer, background)
        : renderer;
  }

  protected TableCellRenderer getBaseRenderer() {
    return new DefaultTableCellRenderer();
  }

  @Override
  public boolean isResizable() {
    return true;
  }

  @Override
  public final Icon getIcon() {
    return icon;
  }

  @Override
  public String getToolTipText() {
    return null;
  }
}