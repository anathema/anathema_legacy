/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import net.disy.commons.swing.smarttable.column.ITableColumn;

public class FilteringStrategyFactory<T> {

  private final Iterable<ITableColumn> columns;

  public FilteringStrategyFactory(final Iterable<ITableColumn> columns) {
    this.columns = columns;
  }

  private boolean isFilterable() {
    boolean filterable = false;
    for (final ITableColumn<T, ?> column : columns) {
      if (column.getFilterConfiguration().isFilterable()) {
        filterable = true;
        break;
      }
    }
    return filterable;
  }

  public IFilterStrategyNG<T> create() {
    if (isFilterable()) {
      return new FilteringStrategyNG<T>(columns);
    }
    return new UnfilteringStrategyNG<T>();
  }

  public static void addDefaultFilterForAll(final Iterable<ITableColumn> columns) {
    for (final ITableColumn column : columns) {
      column.setFilterConfiguration(new DefaultFilterConfiguration());
    }
  }

  public static void removeFilterForAll(final Iterable<ITableColumn> columns) {
    for (final ITableColumn column : columns) {
      column.setFilterConfiguration(new NullFilterConfiguration());
    }
  }
}