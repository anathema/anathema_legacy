//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

// NOT_PUBLISHED
public class CheckBoxTableColumnSettings extends AbstractTableColumnSettings {

  public CheckBoxTableColumnSettings() {
    super(2);
  }

  public TableCellEditor getEditor() {
    return new DefaultCellEditor(new JCheckBox()) {
      public Component getComponent() {
        return wrapInPanelAsCentered(super.getComponent());
      }

      public Component getTableCellEditorComponent(
          JTable table,
          Object value,
          boolean isSelected,
          int row,
          int column) {
        return wrapInPanelAsCentered(super.getTableCellEditorComponent(
            table,
            value,
            isSelected,
            row,
            column));
      }

      public Component getTreeCellEditorComponent(
          JTree tree,
          Object value,
          boolean isSelected,
          boolean expanded,
          boolean leaf,
          int row) {
        return wrapInPanelAsCentered(super.getTreeCellEditorComponent(
            tree,
            value,
            isSelected,
            expanded,
            leaf,
            row));
      }
    };
  }

  public TableCellRenderer getRenderer() {
    return new TableCellRenderer() {
      public Component getTableCellRendererComponent(
          JTable table,
          Object value,
          boolean isSelected,
          final boolean hasFocus,
          int row,
          int column) {
        JCheckBox checkBox = new JCheckBox();
        checkBox.setSelected(((Boolean) value).booleanValue());
        JPanel panel = wrapInPanelAsCentered(checkBox);

        if (hasFocus && table.isCellEditable(row, column)) {
          checkBox.setForeground(SwingColors.getTabelFocusCellForegroundColor());
          panel.setForeground(SwingColors.getTabelFocusCellForegroundColor());
          checkBox.setBackground(SwingColors.getTabelFocusCellBackgroundColor());
          panel.setBackground(SwingColors.getTabelFocusCellBackgroundColor());
        }
        else if (isSelected) {
          checkBox.setForeground(table.getSelectionForeground());
          panel.setForeground(table.getSelectionForeground());
          checkBox.setBackground(table.getSelectionBackground());
          panel.setBackground(table.getSelectionBackground());
        }
        else {
          checkBox.setForeground(table.getForeground());
          panel.setForeground(table.getForeground());
          checkBox.setBackground(table.getBackground());
          panel.setBackground(table.getBackground());
        }
        return panel;
      }
    };
  }

  private static JPanel wrapInPanelAsCentered(final Component component) {
    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.CENTER);
    layoutData.setGrabExcessHorizontalSpace(true);
    layoutData.setVerticalAlignment(GridAlignment.CENTER);
    layoutData.setGrabExcessVerticalSpace(true);
    panel.add(component, layoutData);
    return panel;
  }

  public boolean isResizable() {
    return false;
  }
}