/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.table.TableCellEditor;

import net.disy.commons.core.util.ITransformer;

public class CheckBoxTableColumnSettings extends AbstractCheckBoxTableColumnSettings<Boolean> {

  private final ITransformer<? super Object, Boolean> valueTransformer;
  private final String tooltip;

  public CheckBoxTableColumnSettings() {
    this(new CheckBoxTableColumnSettingsConfiguration());
  }

  public CheckBoxTableColumnSettings(CheckBoxTableColumnSettingsConfiguration configuration) {
    super(configuration.getColumnWidth(), configuration.getIcon());
    this.valueTransformer = configuration.getValueTransformer();
    this.tooltip = configuration.getTooltip();
  }

  @Override
  public TableCellEditor getEditor() {
    return new DefaultCellEditor(new JCheckBox()) {
      @Override
      public Component getComponent() {
        return WrapInPanelAsCenteredComponentDecorator.wrapInPanelAsCentered(super.getComponent());
      }

      @Override
      public Component getTableCellEditorComponent(
          final JTable table,
          final Object value,
          final boolean isSelected,
          final int row,
          final int column) {
        return WrapInPanelAsCenteredComponentDecorator.wrapInPanelAsCentered(super
            .getTableCellEditorComponent(table, transform(value), isSelected, row, column));
      }

      @Override
      public Component getTreeCellEditorComponent(
          final JTree tree,
          final Object value,
          final boolean isSelected,
          final boolean expanded,
          final boolean leaf,
          final int row) {
        return WrapInPanelAsCenteredComponentDecorator.wrapInPanelAsCentered(super
            .getTreeCellEditorComponent(tree, transform(value), isSelected, expanded, leaf, row));
      }
    };
  }

  @Override
  protected JCheckBox createRenderCheckBox(final Object value) {
    final JCheckBox checkBox = new JCheckBox();
    checkBox.setSelected(value != null && transform(value));
    return checkBox;
  }

  private Boolean transform(final Object value) {
    return valueTransformer.transform(value);
  }

  @Override
  public String getToolTipText() {
    return tooltip;
  }
}