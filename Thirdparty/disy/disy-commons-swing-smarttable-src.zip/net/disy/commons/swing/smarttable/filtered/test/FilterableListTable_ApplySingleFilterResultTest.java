/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static org.easymock.EasyMock.*;
import static org.junit.Assert.*;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.smarttable.filtered.FilteringStrategy;

import org.junit.Ignore;
import org.junit.Test;

public class FilterableListTable_ApplySingleFilterResultTest {

  @Ignore
  @SuppressWarnings("unchecked")
  @Test
  public void selectsFirstItemAndExecutesGivenBlockAndResetsFilter() throws Exception {
    final IListModel listModel = createNiceMock(IListModel.class);
    makeThreadSafe(listModel, true);
    expect(listModel.getItemCount()).andStubReturn(1);
    expect(listModel.getItem(0)).andStubReturn("auswahl"); //$NON-NLS-1$
    replay(listModel);
    FilteringStrategy<String> filterStrategy = new FilteringStrategy<String>();
    final TestFilterableListTable table = new TestFilterableListTable(listModel, filterStrategy);
    filterStrategy.attachTo(table, null);
    final ObjectModel<Boolean> executeCalled = new ObjectModel<Boolean>(false);
    final IBlock applySelection = new IBlock() {
      @Override
      public void execute() throws RuntimeException {
        executeCalled.setValue(true);
        assertEquals(0, table.getSelectionModel().getMinSelectionIndex());
        assertEquals(0, table.getSelectionModel().getMaxSelectionIndex());
      }
    };
    filterStrategy.applySingleFilterResult(applySelection);
    assertTrue(executeCalled.getValue());
    assertEquals("", filterStrategy.getFilterTextField().getText()); //$NON-NLS-1$
  }
}