/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import java.util.List;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.select.demo.AbstractSelectionDialogDemo;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.dialog.ITableSelectionDialogConfiguration;
import net.disy.commons.swing.smarttable.dialog.TableSelectionDialogPage;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class TableSelectionDialogDemo extends AbstractSelectionDialogDemo {

  @Demo
  public void demoSimpleSmartOneOutOfManySelectionDialog() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    final DemoTableSelectionDialogConfiguration configuration = new DemoTableSelectionDialogConfiguration();
    showDialogFor(items, configuration);
  }

  @Demo
  public void demoSmartOneOutOfManySelectionDialogWithAdditionalPanels() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    final DemoTableSelectionDialogConfiguration configuration = new DemoTableSelectionDialogConfiguration() {
      @Override
      public ISmartDialogPanel[] createAdditionalPanels(
          final FixedOptionsObjectSelectionModel<DemoColorItem> selectionModel) {
        return createAdditionalDemoPanels(selectionModel);
      }
    };
    showDialogFor(items, configuration);
  }

  private void showDialogFor(
      final List<DemoColorItem> items,
      final ITableSelectionDialogConfiguration<DemoColorItem> configuration) {
    final TableSelectionDialogPage<DemoColorItem> page = new TableSelectionDialogPage<DemoColorItem>(
        items,
        configuration);
    show(page);
  }
}