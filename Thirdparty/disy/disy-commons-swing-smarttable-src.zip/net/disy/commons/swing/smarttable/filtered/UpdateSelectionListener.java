package net.disy.commons.swing.smarttable.filtered;

import net.disy.commons.core.model.listener.IChangeListener;

public final class UpdateSelectionListener implements IChangeListener {
  private final IUpdatableSelection selection;

  public UpdateSelectionListener(IUpdatableSelection selection) {
    this.selection = selection;
  }

  @Override
  public void stateChanged() {
    selection.updateSelection();
  }
}