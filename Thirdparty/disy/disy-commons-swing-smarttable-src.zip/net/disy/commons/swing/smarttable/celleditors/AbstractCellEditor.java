/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Component;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.util.EventObject;

import javax.swing.CellEditor;
import javax.swing.event.CellEditorListener;
import javax.swing.event.ChangeEvent;
import javax.swing.event.EventListenerList;

public class AbstractCellEditor implements CellEditor {
  protected EventListenerList listenerList = new EventListenerList();

  @Override
  public Object getCellEditorValue() {
    return null;
  }

  @Override
  public boolean isCellEditable(final EventObject e) {
    return true;
  }

  @Override
  public boolean shouldSelectCell(final EventObject anEvent) {
    return false;
  }

  @Override
  public boolean stopCellEditing() {
    return true;
  }

  @Override
  public void cancelCellEditing() {
    // nothing to do
  }

  protected final void cancelEditOnFocusLost(final Component component) {
    component.addFocusListener(new FocusAdapter() {
      @Override
      public void focusLost(final FocusEvent e) {
        component.setVisible(false);
        fireEditingCanceled();
      }
    });
  }

  @Override
  public void addCellEditorListener(final CellEditorListener l) {
    listenerList.add(CellEditorListener.class, l);
  }

  @Override
  public void removeCellEditorListener(final CellEditorListener l) {
    listenerList.remove(CellEditorListener.class, l);
  }

  protected void fireEditingStopped() {
    final Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == CellEditorListener.class) {
        ((CellEditorListener) listeners[i + 1]).editingStopped(new ChangeEvent(this));
      }
    }
  }

  protected void fireEditingCanceled() {
    final Object[] listeners = listenerList.getListenerList();
    for (int i = listeners.length - 2; i >= 0; i -= 2) {
      if (listeners[i] == CellEditorListener.class) {
        ((CellEditorListener) listeners[i + 1]).editingCanceled(new ChangeEvent(this));
      }
    }
  }
}