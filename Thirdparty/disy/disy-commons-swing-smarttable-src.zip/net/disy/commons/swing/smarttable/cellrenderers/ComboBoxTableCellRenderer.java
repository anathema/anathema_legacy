package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.laf.LookAndFeelUtilities;

public class ComboBoxTableCellRenderer extends JComboBox implements TableCellRenderer {
  public ComboBoxTableCellRenderer(Object[] items) {
    super(items);
  }

  public ComboBoxTableCellRenderer() {
    super();
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    boolean cellEditable = table.isCellEditable(row, column);
    LookAndFeelUtilities.adjustCell(this, table, isSelected, hasFocus, cellEditable);

    /* 22.01.2006 (Markus Gebhard) Workaround: In Text-Editable comboboxes it might happen that the
     entered value is not yet in the ComboBox => is not being displayed correctly */
    if (value instanceof String && !containsItem(value)) {
      addItem(value);
    }
    setSelectedItem(value);
    setEnabled(table.isEnabled() && cellEditable);
    return this;
  }

  private boolean containsItem(Object value) {
    final ComboBoxModel model = getModel();
    for (int i = 0; i < model.getSize(); ++i) {
      if (value.equals(model.getElementAt(i))) {
        return true;
      }
    }
    return false;
  }
}