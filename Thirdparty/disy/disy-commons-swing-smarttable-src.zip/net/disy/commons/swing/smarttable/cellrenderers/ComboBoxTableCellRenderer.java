/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.laf.LookAndFeelUtilities;

public class ComboBoxTableCellRenderer extends JComboBox implements TableCellRenderer {
  public ComboBoxTableCellRenderer(final Object[] items) {
    super(items);
  }

  public ComboBoxTableCellRenderer() {
    super();
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    final boolean cellEditable = table.isCellEditable(row, column);
    LookAndFeelUtilities.adjustCell(this, table, isSelected, hasFocus, cellEditable);

    /* 22.01.2006 (Markus Gebhard) Workaround: In Text-Editable comboboxes it might happen that the
     entered value is not yet in the ComboBox => is not being displayed correctly */
    if (value instanceof String && !containsItem(value)) {
      addItem(value);
    }
    setSelectedItem(value);
    setEnabled(table.isEnabled() && cellEditable);
    return this;
  }

  private boolean containsItem(final Object value) {
    final ComboBoxModel model = getModel();
    for (int i = 0; i < model.getSize(); ++i) {
      if (value.equals(model.getElementAt(i))) {
        return true;
      }
    }
    return false;
  }
}