/*
 * (c) disy Informationssysteme GmbH
 * 
 * Created on Sep 2, 2003
 *
 */
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.swing.laf.LookAndFeelUtilities;

public class ComboBoxTableCellRenderer extends JComboBox implements TableCellRenderer {
  public ComboBoxTableCellRenderer(Object[] items) {
    super(items);
  }

  public ComboBoxTableCellRenderer() {
    super();
  }

  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    boolean cellEditable = table.isCellEditable(row, column);
    LookAndFeelUtilities.adjustCell(this, table, isSelected, hasFocus, cellEditable);
    setSelectedItem(value);
    return this;
  }
}