/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import net.disy.commons.swing.smarttable.filtered.AbstractFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterMatchingStrategy;

public final class ColorNameFilterStrategy extends AbstractFilterConfiguration<String> {

  @Override
  public IFilterMatchingStrategy<String> getMatchingStrategy() {
    return new IFilterMatchingStrategy<String>() {
      @Override
      public boolean matches(final String value, final String filterExpression) {
        if (value == null) {
          return false;
        }
        return value.toLowerCase().contains(filterExpression.toLowerCase());
      }
    };
  }
}