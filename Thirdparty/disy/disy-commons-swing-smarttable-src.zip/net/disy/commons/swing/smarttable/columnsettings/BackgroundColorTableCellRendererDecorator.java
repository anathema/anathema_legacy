/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Color;
import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

public class BackgroundColorTableCellRendererDecorator implements TableCellRenderer {

  private final TableCellRenderer renderer;
  private final Color background;

  public BackgroundColorTableCellRendererDecorator(
      final TableCellRenderer renderer,
      final Color background) {
    this.renderer = renderer;
    this.background = background;
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    final Component component = renderer.getTableCellRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
    if (component.getBackground().equals(table.getBackground())) {
      component.setBackground(background);
    }
    return component;
  }
}