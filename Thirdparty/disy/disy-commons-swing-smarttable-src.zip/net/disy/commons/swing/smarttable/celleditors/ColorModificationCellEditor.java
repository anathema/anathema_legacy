/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.ColorChooserLabel;
import net.disy.commons.swing.dialog.color.DefaultColorChooserConfiguration;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.util.ToggleComponentEnabler;

// NOT_PUBLISHED
public class ColorModificationCellEditor extends AbstractCellEditor
    implements
    TableCellEditor,
    TableCellRenderer {

  private ColorModel colorModel;
  private JCheckBox checkBox;

  @Override
  public Component getTableCellEditorComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final int row,
      final int column) {
    return createCheckboxColorComponent((IColorModificationEntry) value);
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    return createCheckboxColorComponent((IColorModificationEntry) value);
  }

  @Override
  public Object getCellEditorValue() {
    return new IColorModificationEntry() {
      @Override
      public boolean isModified() {
        return checkBox.isSelected();
      }

      @Override
      public Color getColor() {
        return colorModel.getColor();
      }
    };
  }

  private Component createCheckboxColorComponent(final IColorModificationEntry cell) {
    checkBox = new JCheckBox("", cell.isModified()); //$NON-NLS-1$
    colorModel = new ColorModel(cell.getColor());
    final ColorChooserLabel colorChooseButton = new ColorChooserLabel(
        colorModel,
        new DefaultColorChooserConfiguration(true));
    ToggleComponentEnabler.connect(checkBox, colorChooseButton.getContent());

    checkBox.addItemListener(new ItemListener() {
      @Override
      public void itemStateChanged(final ItemEvent e) {
        fireEditingStopped();
      }
    });
    colorModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        fireEditingStopped();
      }
    });
    colorChooseButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        fireEditingStopped();
      }
    });

    final JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(Box.createHorizontalStrut(2));
    panel.add(checkBox);
    panel.add(colorChooseButton.getContent(), GridDialogLayoutData.FILL_HORIZONTAL);
    panel.addFocusListener(new FocusListener() {
      @Override
      public void focusGained(final FocusEvent e) {
        //nothing to do
      }

      @Override
      public void focusLost(final FocusEvent e) {
        fireEditingStopped();
      }
    });
    return panel;
  }
}