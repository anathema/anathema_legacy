/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

public class StringCellRenderer extends DefaultTableCellRenderer {

  private final boolean showTooltip;

  public StringCellRenderer() {
    this(false);
  }

  public StringCellRenderer(boolean showTooltip) {
    this.showTooltip = showTooltip;
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int row,
      final int column) {
    Object nullSafeValue = value == null ? "" : value; //$NON-NLS-1$
    final JComponent component = (JComponent) super.getTableCellRendererComponent(
        table,
        nullSafeValue,
        isSelected,
        hasFocus,
        row,
        column);
    component.setEnabled(table.isEnabled());
    if (showTooltip) {
      component.setToolTipText(nullSafeValue.toString());
    }
    return component;
  }
}