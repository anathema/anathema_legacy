//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.cellrenderers;

import java.awt.Component;

import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

// NOT_PUBLISHED
public class StringCellRenderer extends DefaultTableCellRenderer {

  @Override
  public Component getTableCellRendererComponent(
      JTable table,
      Object value,
      boolean isSelected,
      boolean hasFocus,
      int row,
      int column) {
    final Component component = super.getTableCellRendererComponent(
        table,
        value,
        isSelected,
        hasFocus,
        row,
        column);
    component.setEnabled(table.isEnabled());
    return component;
  }
}