/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.smarttable.column.IListColumnValueConverter;
import net.disy.commons.swing.smarttable.column.TableColumnConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.DoubleClickObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NullDoubleClickBehaviour;
import net.disy.commons.swing.smarttable.filtered.AbstractFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.CaseInsensitiveTrivialMatcher;
import net.disy.commons.swing.smarttable.filtered.IFilterConfiguration;
import net.disy.commons.swing.smarttable.filtered.IFilterMatchingStrategy;
import net.disy.commons.swing.smarttable.filtered.IFilteringValueConverter;
import net.disy.commons.swing.smarttable.filtered.NullFilterConfiguration;
import net.disy.commons.swing.smarttable.listtable.AbstractReadOnlyListModelColumn;
import net.disy.commons.swing.smarttable.sorter.ComparableSorterConfiguration;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.ui.IObjectUi;

public class DemoLongColumn extends AbstractReadOnlyListModelColumn<ListTableDemoModelItem, Long> {

  private final IFilterConfiguration<Long> filterConfiguration;

  public DemoLongColumn(final IListModel<ListTableDemoModelItem> listModel, final boolean filtered) {
    super(listModel);
    if (filtered) {
      filterConfiguration = new AbstractFilterConfiguration<Long>() {
        @Override
        public IFilterMatchingStrategy<Long> getMatchingStrategy() {
          return new CaseInsensitiveTrivialMatcher<Long>(new IFilteringValueConverter<Long>() {
            @Override
            public String convert(final Long rawValue) {
              return rawValue + " (l)";
            }
          });
        }
      };
    }
    else {
      filterConfiguration = new NullFilterConfiguration<Long>();
    }
  }

  @Override
  protected IListColumnValueConverter<ListTableDemoModelItem, Long> createRowToColumnValueAdapter() {
    return new IListColumnValueConverter<ListTableDemoModelItem, Long>() {

      @Override
      public Long getValue(final ListTableDemoModelItem listValue) {
        return listValue.getNumber();
      }
    };
  }

  @Override
  protected TableColumnConfiguration<Long> createConfiguration() {
    final IObjectUi<Long> longUi = new AbstractObjectUi<Long>() {

      @Override
      public String getLabel(final Long value) {
        return value + " (l)"; //$NON-NLS-1$
      }
    };
    final TableColumnConfiguration<Long> configuration = new TableColumnConfiguration<Long>(
        "Number",
        Long.class,
        new DoubleClickObjectUiTableColumnSettings<Long>(
            longUi,
            new NullDoubleClickBehaviour<Long>()));
    configuration.setSorterConfiguration(new ComparableSorterConfiguration<Long>());
    return configuration;
  }

  @Override
  public IFilterConfiguration<Long> getFilterConfiguration() {
    return filterConfiguration;
  }

}
