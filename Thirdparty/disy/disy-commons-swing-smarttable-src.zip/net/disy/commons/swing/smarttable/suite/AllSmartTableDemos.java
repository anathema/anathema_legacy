//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.suite;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllSmartTableDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.smarttable.suite"); //$NON-NLS-1$
    suite.addDemo(net.disy.commons.swing.smarttable.actions.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.smarttable.demo.AllDemos.suite());
    //$JDemo-BEGIN$

    //$JDemo-END$
    return suite;
  }

}
