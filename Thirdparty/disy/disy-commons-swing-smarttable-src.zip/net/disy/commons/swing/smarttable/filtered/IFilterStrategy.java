/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.ui.IObjectUi;

public interface IFilterStrategy<T> {

  public IListModel<T> createListModel(IListModel<T> originalModel, IObjectUi<T>[] objectUis);

  public void updateFilter(IObjectUi<T>[] objectUis);

  public void addFilterWidgets(JPanel panel, JComponent tableComponent);

  public void attachTo(DeprecatedListTable<T> listTable, SmartTable table);

  public void requestFocus();

  public void keepSelectionUpToDate(ObjectModel<T> selectionModel);

  public void waitForFilteringFinished();
}