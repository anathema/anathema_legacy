/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.dialog.demo;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.dialog.AbstractTableSelectionDialogConfiguration;

public class DemoTableSelectionDialogConfiguration
    extends
    AbstractTableSelectionDialogConfiguration<DemoColorItem> {

  @Override
  public String getTitle() {
    return "Color"; //$NON-NLS-1$
  }

  @Override
  public String getNoItemSelectedErrorMessageText() {
    return "There is no color selected. Please select a color."; //$NON-NLS-1$;
  }

  @Override
  public String getDefaultMessageText() {
    return "Please select a color."; //$NON-NLS-1$
  }

  @Override
  public Iterable<ITableColumn> createTableColumns(final IListModel<DemoColorItem> listModel) {
    final List<ITableColumn> columns = new ArrayList<ITableColumn>();
    columns.add(new DemoColorItemColorColumn(listModel));
    columns.add(new DemoColorItemNameColumn(listModel));
    columns.add(new DemoColorItemRedValueColumn(listModel));
    columns.add(new DemoColorItemGreenValueColumn(listModel));
    columns.add(new DemoColorItemBlueValueColumn(listModel));
    return columns;
  }
}