/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import static org.junit.Assert.*;

import java.awt.Color;

import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.SmartTableFactory;
import net.disy.commons.swing.smarttable.column.IDeprecatedTableColumn;
import net.disy.commons.swing.smarttable.column.SmartTableColumn;
import net.disy.commons.swing.smarttable.columnsettings.ColorEditorTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;

import org.junit.Before;
import org.junit.Test;

public class SmartTableFactoryTest {

  private SmartTable smartTable;
  private StringTableColumnSettings stringSettings;
  private ColorEditorTableColumnSettings colorSettings;

  @Before
  public void createSmartTable() throws Exception {
    stringSettings = new StringTableColumnSettings();
    colorSettings = new ColorEditorTableColumnSettings();
    smartTable = SmartTableFactory.create(new IDeprecatedTableColumn<?>[]{
        new SmartTableColumn<String>("String", stringSettings), //$NON-NLS-1$
        new SmartTableColumn<Color>("Color", colorSettings) }); //$NON-NLS-1$
  }

  @Test
  public void tableModelHasColumnNumberAsColumnCount() throws Exception {
    assertEquals(2, smartTable.getModel().getColumnCount());
  }

  @Test
  public void tableModelHasNoRows() throws Exception {
    assertEquals(0, smartTable.getModel().getRowCount());
  }

  @Test
  public void tableModelHasColumnHeaderNames() throws Exception {
    assertEquals("String", smartTable.getModel().getColumnName(0)); //$NON-NLS-1$
    assertEquals("Color", smartTable.getModel().getColumnName(1)); //$NON-NLS-1$
  }

  @Test
  public void tableHasColumnSettings() throws Exception {
    assertArrayEquals(
        new ITableColumnViewSettings<?>[]{ stringSettings, colorSettings },
        smartTable.getSettings());
  }
}