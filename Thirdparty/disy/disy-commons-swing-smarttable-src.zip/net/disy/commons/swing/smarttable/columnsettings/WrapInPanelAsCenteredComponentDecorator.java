/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;

import javax.swing.JPanel;

import net.disy.commons.core.util.IDecorator;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public class WrapInPanelAsCenteredComponentDecorator implements IDecorator<Component> {

  @Override
  public Component decorate(final Component input) {
    return wrapInPanelAsCentered(input);
  }

  public static JPanel wrapInPanelAsCentered(final Component component) {
    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    final GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.CENTER);
    layoutData.setGrabExcessHorizontalSpace(true);
    layoutData.setVerticalAlignment(GridAlignment.CENTER);
    layoutData.setGrabExcessVerticalSpace(true);
    panel.add(component, layoutData);
    return panel;
  }
}