/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings.preferredwidth;

import java.util.List;
import java.util.Vector;

import javax.swing.JComboBox;

import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public class ComboBoxPreferredWidth<T> implements IPreferredWidth {

  private final int preferredWidth;

  public ComboBoxPreferredWidth(final List<T> values) {
    this.preferredWidth = getPreferredSize(new JComboBox(new Vector<T>(values)));
  }

  private int getPreferredSize(JComboBox comboBox) {
    return comboBox.getPreferredSize().width;
  }

  public ComboBoxPreferredWidth(final List<T> values, final IObjectUi<T> objectUi) {
    final JComboBox comboBox = new JComboBox(new Vector<T>(values));
    comboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    this.preferredWidth = getPreferredSize(comboBox) + 2;
  }

  public ComboBoxPreferredWidth(final T[] values, final IObjectUi<T> objectUi) {
    final JComboBox comboBox = new JComboBox(values);
    comboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    this.preferredWidth = getPreferredSize(comboBox) + 2;
  }

  @Override
  public int getPreferredWidth() {
    return preferredWidth;
  }
}