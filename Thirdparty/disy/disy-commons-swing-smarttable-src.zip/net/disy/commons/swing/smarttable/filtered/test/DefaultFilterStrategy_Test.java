/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import javax.swing.JTextField;

import net.disy.commons.swing.smarttable.filtered.FilteringStrategy;
import net.disy.commons.swing.smarttable.filtered.EnterActionListener;

import org.junit.Before;
import org.junit.Test;

public class DefaultFilterStrategy_Test {

  private FilteringStrategy<String> filterStrategy;

  @Before
  public void init() throws Exception {
    filterStrategy = new FilteringStrategy<String>();
  }

  @Test
  public void setsListenerOnFilterTextField() throws Exception {
    filterStrategy.enableEnterActionsOnFilter(null);
    JTextField filterTextField = filterStrategy.getFilterTextField();
    assertThat(filterTextField.getKeyListeners()[0], instanceOf(EnterActionListener.class));
  }

  @Test
  public void doesNotSetEnterActionListenerWhenEnableEnterActionsOnFilterIsNotCalled()
      throws Exception {
    JTextField filterTextField = filterStrategy.getFilterTextField();
    assertThat(filterTextField.getKeyListeners().length, is(0));
  }
}