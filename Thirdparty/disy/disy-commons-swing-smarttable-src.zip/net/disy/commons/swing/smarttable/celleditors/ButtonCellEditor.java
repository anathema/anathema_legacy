/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.awt.Component;
import java.awt.Insets;
import java.awt.event.MouseEvent;
import java.util.EventObject;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.columnsettings.IButtonEditorConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.IEditStoppedHandler;

public class ButtonCellEditor extends AbstractCellEditor
    implements
    TableCellEditor,
    TableCellRenderer {

  private final IButtonEditorConfiguration configuration;
  private Object editorValue;

  public ButtonCellEditor(final IButtonEditorConfiguration configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
  }

  @Override
  public Component getTableCellEditorComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final int rowIndex,
      final int columnIndex) {
    return createButtonComponent(table, rowIndex, columnIndex, value);
  }

  @Override
  public Component getTableCellRendererComponent(
      final JTable table,
      final Object value,
      final boolean isSelected,
      final boolean hasFocus,
      final int rowIndex,
      final int columnIndex) {
    return createButtonComponent(table, rowIndex, columnIndex, value);
  }

  @Override
  public boolean shouldSelectCell(final EventObject anEvent) {
    return true;
  }

  @Override
  public boolean isCellEditable(final EventObject anEvent) {
    if (anEvent instanceof MouseEvent) {
      return ((MouseEvent) anEvent).getClickCount() >= 1;
    }
    return true;
  }

  @Override
  public Object getCellEditorValue() {
    return editorValue;
  }

  private Component createButtonComponent(
      final JTable table,
      final int rowIndex,
      final int columnIndex,
      final Object value) {
    editorValue = value;
    final SmartAction action = configuration.createAction(new IEditStoppedHandler() {
      @Override
      public void editCanceled() {
        fireEditingCanceled();
      }

      @Override
      public void editFinished(Object newValue) {
        editorValue = newValue;
        fireEditingStopped();
      }
    }, rowIndex, columnIndex, value);
    final JButton button = createButton(action);
    button.setEnabled(table.isEnabled() && table.isCellEditable(rowIndex, columnIndex));
    return button;
  }

  private static JButton createButton(final SmartAction action) {
    final JButton button = new JButton(action);
    if (action.getIcon() != null && action.getName() == null) {
      button.setMargin(new Insets(0, 0, 0, 0));
    }
    return button;
  }

  public static int getButtonWidth(final String longestButtonLabel, final Icon largestButtonIcon) {
    return createButton(new SmartAction(longestButtonLabel, largestButtonIcon) {
      @Override
      protected void execute(final Component parentComponent) {
        //nothing to do
      }
    }).getPreferredSize().width;
  }
}