/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.demo;

import java.awt.Component;

import javax.swing.Icon;

import net.disy.commons.swing.smarttable.celleditors.action.CellEditorAction;
import net.disy.commons.swing.smarttable.celleditors.action.FinishedCellEditResult;
import net.disy.commons.swing.smarttable.celleditors.action.ICellEditResult;
import net.disy.commons.swing.smarttable.columnsettings.IButtonEditorConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.IEditStoppedHandler;

public class DemoButtonEditorConfiguration implements IButtonEditorConfiguration {

  @Override
  public Icon getLargestButtonIcon() {
    return null;
  }

  @Override
  public String getLongestButtonLabel() {
    return "..."; //$NON-NLS-1$
  }

  @Override
  public CellEditorAction createAction(
      final IEditStoppedHandler handler,
      final int rowIndex,
      final int columnIndex,
      final Object value) {

    final CellEditorAction action = new CellEditorAction(handler) {
      @Override
      protected ICellEditResult performCellEdit(Component parentComponent) {
        System.err.println("Editing object " + value); //$NON-NLS-1$
        return new FinishedCellEditResult(value);
      }
    };
    action.setName("..."); //$NON-NLS-1$
    action.setToolTipText(String.valueOf(value));
    return action;
  }
}