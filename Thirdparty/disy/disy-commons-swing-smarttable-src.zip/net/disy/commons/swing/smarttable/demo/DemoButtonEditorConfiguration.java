//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.demo;

import java.awt.Component;

import javax.swing.Icon;

import net.disy.commons.swing.smarttable.celleditors.action.CellEditorAction;
import net.disy.commons.swing.smarttable.celleditors.action.FinishedCellEditResult;
import net.disy.commons.swing.smarttable.celleditors.action.ICellEditResult;
import net.disy.commons.swing.smarttable.columnsettings.IButtonEditorConfiguration;
import net.disy.commons.swing.smarttable.columnsettings.IEditStoppedHandler;

// NOT_PUBLISHED
public class DemoButtonEditorConfiguration implements IButtonEditorConfiguration {

  public Icon getLargestButtonIcon() {
    return null;
  }

  public String getLongestButtonLabel() {
    return "..."; //$NON-NLS-1$
  }

  public CellEditorAction createAction(
      final IEditStoppedHandler handler,
      int rowIndex,
      int columnIndex,
      final Object value) {
    
    CellEditorAction action= new CellEditorAction(handler) {
      @Override
      protected ICellEditResult performCellEdit(Component parentComponent) {
        System.err.println("Editing object " + value); //$NON-NLS-1$
        return new FinishedCellEditResult(value);
      }
    };
    action.setName("..."); //$NON-NLS-1$
    action.setToolTipText(String.valueOf(value));
    return action;
  }
}