/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Color;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.celleditors.CellEditorNullValueStrategy;
import net.disy.commons.swing.smarttable.celleditors.NumberCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.NumberCellRenderer;

public class NumberTableColumnSettings extends AbstractTableColumnSettings<Number> {

  private final NumberFormat format;
  private final CellEditorNullValueStrategy nullValueStrategy;
  private final Class<? extends Number> valueClass;

  public static NumberTableColumnSettings getDoubleInstance(
      final String format,
      final CellEditorNullValueStrategy nullValueStrategy) {
    return new NumberTableColumnSettings(new DecimalFormat(format), Double.class, nullValueStrategy);
  }

  public static NumberTableColumnSettings getWholeNumberInstance(final Class<? extends Number> clazz) {
    return getWholeNumberInstance(clazz, null);
  }

  public static NumberTableColumnSettings getWholeNumberInstance(
      final Class<? extends Number> clazz,
      final Color background) {
    return new NumberTableColumnSettings(new DecimalFormat("####"), //$NON-NLS-1$
        clazz,
        CellEditorNullValueStrategy.EMPTY,
        background);
  }

  public static NumberTableColumnSettings getDoubleNumberInstance(
      final Class<? extends Number> clazz,
      final Color background) {
    return new NumberTableColumnSettings(
        new DecimalFormat(),
        clazz,
        CellEditorNullValueStrategy.EMPTY,
        background);
  }

  public static NumberTableColumnSettings getIntegerInstance(
      final String format,
      final CellEditorNullValueStrategy nullValueStrategy) {
    return new NumberTableColumnSettings(
        new DecimalFormat(format),
        Integer.class,
        nullValueStrategy);
  }

  public NumberTableColumnSettings(
      final NumberFormat format,
      final Class<? extends Number> valueClass) {
    this(format, valueClass, CellEditorNullValueStrategy.DISALLOW);
  }

  public NumberTableColumnSettings(
      final NumberFormat format,
      final Class<? extends Number> valueClass,
      final CellEditorNullValueStrategy nullValueStrategy) {
    this(format, valueClass, nullValueStrategy, null);
  }

  public NumberTableColumnSettings(
      final NumberFormat format,
      final Class<? extends Number> valueClass,
      final CellEditorNullValueStrategy nullValueStrategy,
      final Color background) {
    super(format.getMinimumIntegerDigits() + format.getMinimumFractionDigits() + 2, background);
    Ensure.ensureArgumentNotNull(format);
    Ensure.ensureArgumentNotNull(valueClass);
    Ensure.ensureArgumentNotNull(nullValueStrategy);
    this.format = format;
    this.valueClass = valueClass;
    this.nullValueStrategy = nullValueStrategy;
  }

  @Override
  public TableCellEditor getEditor() {
    return new NumberCellEditor(format, valueClass, nullValueStrategy);
  }

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return new NumberCellRenderer(format);
  }

}