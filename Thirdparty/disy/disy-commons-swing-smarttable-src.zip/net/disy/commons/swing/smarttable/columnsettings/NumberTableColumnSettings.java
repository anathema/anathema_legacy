//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;
import java.text.DecimalFormat;
import java.text.NumberFormat;

import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.celleditors.NullValueStrategy;
import net.disy.commons.swing.smarttable.celleditors.NumberCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.StringCellRenderer;

// NOT_PUBLISHED
public class NumberTableColumnSettings extends AbstractTableColumnSettings {

  private final NumberFormat format;
  private final NullValueStrategy nullValueStrategy;
  private final Class valueClass;

  public static NumberTableColumnSettings getDoubleInstance(
      String format,
      NullValueStrategy nullValueStrategy) {
    return new NumberTableColumnSettings(new DecimalFormat(format), Double.class, nullValueStrategy);
  }

  public static NumberTableColumnSettings getIntegerInstance(
      String format,
      NullValueStrategy nullValueStrategy) {
    return new NumberTableColumnSettings(
        new DecimalFormat(format),
        Integer.class,
        nullValueStrategy);
  }

  public NumberTableColumnSettings(NumberFormat format, Class valueClass) {
    this(format, valueClass, NullValueStrategy.DISALLOW);
  }

  public NumberTableColumnSettings(
      NumberFormat format,
      Class valueClass,
      NullValueStrategy nullValueStrategy) {
    super(format.getMinimumIntegerDigits() + format.getMinimumFractionDigits() + 2);
    Ensure.ensureArgumentNotNull(format);
    Ensure.ensureArgumentNotNull(valueClass);
    Ensure.ensureArgumentNotNull(nullValueStrategy);
    this.format = format;
    this.valueClass = valueClass;
    this.nullValueStrategy = nullValueStrategy;
  }

  //@Overrides
  public TableCellEditor getEditor() {
    return new NumberCellEditor(format, valueClass, nullValueStrategy);
  }

  //@Overrides
  public TableCellRenderer getRenderer() {
    return new StringCellRenderer() {
      public Component getTableCellRendererComponent(
          JTable table,
          Object value,
          boolean isSelected,
          boolean hasFocus,
          int row,
          int column) {
        return super.getTableCellRendererComponent(
            table,
            value == null ? "" : format.format(value), //$NON-NLS-1$
            isSelected,
            hasFocus,
            row,
            column);
      }
    };
  }
}