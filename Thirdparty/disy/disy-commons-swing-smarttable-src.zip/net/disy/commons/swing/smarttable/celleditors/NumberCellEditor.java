/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors;

import java.text.Format;
import java.text.NumberFormat;

import javax.swing.SwingConstants;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.text.NumberFormatter;

public class NumberCellEditor extends AbstractFormattedCellEditor {

  private NumberFormatter formatter;

  public NumberCellEditor(
      final NumberFormat format,
      final Class<?> valueClass,
      final CellEditorNullValueStrategy nullValueStrategy) {
    super(format, nullValueStrategy, SwingConstants.RIGHT);
    formatter.setValueClass(valueClass);
  }

  @Override
  protected AbstractFormatter createFormatter(final Format format) {
    formatter = new NumberFormatter((NumberFormat) format);
    formatter.setAllowsInvalid(false);
    formatter.setCommitsOnValidEdit(true);
    return formatter;
  }
}