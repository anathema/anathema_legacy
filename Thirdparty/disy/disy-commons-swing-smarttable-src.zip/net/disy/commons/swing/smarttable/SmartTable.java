/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;

import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;
import net.disy.commons.swing.action.DisableableProxyAction;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutDirection;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.actions.ITableActionConfiguration;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;
import net.disy.commons.swing.table.AbstractTableCellRendererDecorator;
import net.disy.commons.swing.table.DefaultTableHeaderToolTipProvider;
import net.disy.commons.swing.table.ITableHeaderToolTipProvider;
import net.disy.commons.swing.table.ToolTipCellRendererDecorator;
import net.disy.commons.swing.toolbar.ToolBarUtilities;
import net.disy.commons.swing.util.IEnableableComponentContainer;

public class SmartTable implements IEnableableComponentContainer, IComponentContainer {

  private boolean enabled = true;
  private final JTable table;
  private JComponent content;
  private final ListenerList<ActionListener> selectionActionListeners = new ListenerList<ActionListener>();

  private final List<ITableActionFactory> actionFactories = new ArrayList<ITableActionFactory>();
  private ITableActionFactory doubleClickOnItemActionFactory;
  private boolean toolBarStyleButtons = false;
  private Action[] actions = new Action[0];
  private final ISmartTableConfiguration configuration;

  /**
   * @deprecated as of 20.07.2009 (beck), use {@link SmartTable#SmartTable(TableModel, ISmartTableConfiguration)} instead
   */
  @Deprecated
  public SmartTable(final TableModel tableModel, final ITableColumnViewSettings<?>... settings) {
    this(tableModel, new SmartTableConfiguration(settings));
  }

  public SmartTable(final TableModel tableModel, final ISmartTableConfiguration configuration) {
    this(tableModel, configuration, null);
  }

  public SmartTable(
      final TableModel tableModel,
      final ISmartTableConfiguration configuration,
      final RowSorter<TableModel> tableRowSorter) {
    this(new JTable() {
      {
        if (tableRowSorter != null) {
          setRowSorter(tableRowSorter);
        }
      }
    }, tableModel, configuration);
  }

  public SmartTable(
      final JTable table,
      final TableModel tableModel,
      final ISmartTableConfiguration configuration) {
    Ensure.ensureArgumentNotNull(table);
    Ensure.ensureArgumentNotNull(tableModel);
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
    this.table = table;
    table.setModel(tableModel);
    tableModel.addTableModelListener(new TableModelListener() {
      @Override
      public void tableChanged(final TableModelEvent e) {
        cancelCellEditing();
      }
    });

    table.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseClicked(final MouseEvent e) {
        if (e.getClickCount() != 2 || e.isMetaDown()) {
          return;
        }
        if (table.getSelectedRowCount() == 0) {
          return;
        }
        final int rowIndex = table.getSelectedRow();
        final int columnIndex = table.getColumnModel().getColumnIndexAtX(e.getX());
        handleDoubleClickOnCell(rowIndex, columnIndex);
        fireSelectionActionEvent();
      }
    });

    //TODO 09.11.2004 (gebhard): Minimum row height should be maximum of all minimum row heights from all settings
    table.setRowHeight(Math.max(table.getRowHeight(), 21));
    TableColumnConfigurator.configureTableColumns(table, configuration.getColumnViewSettings());

    setHeaderToolTipProvider(new DefaultTableHeaderToolTipProvider());
    setSelectionMode(configuration.getSelectionMode());
    for (ITableActionConfiguration tableActionConfiguration : configuration
        .getTableActionConfigurations()) {
      addActionFactory(
          tableActionConfiguration.getTableActionFactory(),
          tableActionConfiguration.isDoubleClickOnItemAction());
    }
  }

  protected void handleDoubleClickOnCell(final int rowIndex, final int columnIndex) {
    final Object cellValue = table.getModel().getValueAt(rowIndex, columnIndex);
    final ITableColumnViewSettings<Object>[] columnViewSettings = (ITableColumnViewSettings<Object>[]) configuration
        .getColumnViewSettings();
    columnViewSettings[columnIndex].getDoubleClickBehaviour().invokeForValue(
        table,
        cellValue,
        new IClosure<Object>() {
          @Override
          public void execute(final Object newValue) throws RuntimeException {
            if (cellValue != newValue) {
              table.getModel().setValueAt(newValue, rowIndex, columnIndex);
            }
          }
        });
  }

  /**
  * @deprecated As of 20100812 (bartels, beck), replaced by {@link ISmartTableConfiguration#getTableActionConfigurations()}
  */
  @Deprecated
  public void addActionFactory(final ITableActionFactory actionFactory) {
    addActionFactory(actionFactory, false);
  }

  /**
   * @deprecated As of 20100812 (bartels, beck), replaced by {@link ISmartTableConfiguration#getTableActionConfigurations()}
   */
  @Deprecated
  public void addActionFactory(
      final ITableActionFactory actionFactory,
      final boolean activateOnDoubleClickOnItem) {
    Ensure.ensureArgumentNotNull(actionFactory);
    if (content != null) {
      throw new IllegalStateException(
          "Adding action factories after creating content is not allowed."); //$NON-NLS-1$
    }
    actionFactories.add(actionFactory);
    if (activateOnDoubleClickOnItem) {
      doubleClickOnItemActionFactory = actionFactory;
    }
  }

  public void setSelectionMode(final ListSelectionMode selectionMode) {
    table.setSelectionMode(selectionMode.getListSelectionMode());
  }

  public JTable getTable() {
    return table;
  }

  public TableModel getModel() {
    return table.getModel();
  }

  @Override
  public void setEnabled(final boolean enabled) {
    this.enabled = enabled;
    if (!enabled) {
      final TableCellEditor cellEditor = table.getCellEditor();
      if (cellEditor != null) {
        cellEditor.stopCellEditing();
      }
    }
    updateEnabled();
  }

  public boolean isEnabled() {
    return enabled;
  }

  protected void updateEnabled() {
    table.setEnabled(enabled);
    if (!enabled) {
      table.getSelectionModel().clearSelection();
    }
    for (Action action : actions) {
      action.setEnabled(enabled);
    }
  }

  @Override
  public final JComponent getContent() {
    if (content == null) {
      content = createContent();
      updateEnabled();
    }
    return content;
  }

  private JComponent createContent() {
    final JPanel tablePanel = new JPanel(new BorderLayout());
    tablePanel.add(table);
    final JScrollPane scrollPane = new JScrollPane(tablePanel) {
      @Override
      public void setEnabled(final boolean enabled) {
        super.setEnabled(enabled);
        SmartTable.this.setEnabled(enabled);
      }
    };
    scrollPane.getVerticalScrollBar().setUnitIncrement(table.getRowHeight());
    final JTableHeader tableHeader = table.getTableHeader();
    scrollPane.setColumnHeaderView(tableHeader);
    final int preferredWidth = table.getPreferredSize().width
        + scrollPane.getInsets().left
        + scrollPane.getInsets().right;

    final int headerHeight = tableHeader == null ? 0 : tableHeader.getPreferredSize().height;
    final int preferredHeigth = (table.getRowHeight() * configuration.getVisibleRowCount())
        + headerHeight
        + scrollPane.getInsets().bottom
        + scrollPane.getInsets().top;
    scrollPane.setPreferredSize(new Dimension(preferredWidth, preferredHeigth));

    this.actions = createTableActions();
    if (actions.length == 0) {
      return scrollPane;
    }
    final JPanel panel = new JPanel(new BorderLayout(
        LayoutUtilities.getComponentSpacing(),
        LayoutUtilities.getComponentSpacing())) {
      @Override
      public void setEnabled(final boolean enabled) {
        SmartTable.this.setEnabled(enabled);
        if (!enabled) {
          final TableCellEditor cellEditor = getTable().getCellEditor();
          if (cellEditor != null) {
            cellEditor.stopCellEditing();
          }
        }
      }
    };
    panel.add(scrollPane, BorderLayout.CENTER);
    panel.add(createButtonPanel(actions), BorderLayout.EAST);
    return panel;
  }

  private Action[] createTableActions() {
    List<Action> createdActions = new ArrayList<Action>();
    for (ITableActionFactory factory : actionFactories) {
      if (!factory.hasAction(this)) {
        continue;
      }
      Action internalAction = factory.createAction(this);
      DisableableProxyAction action = new DisableableProxyAction(internalAction);
      if (factory == doubleClickOnItemActionFactory) {
        addSelectionActionListener(action);
      }
      createdActions.add(action);
    }
    return createdActions.toArray(new Action[createdActions.size()]);
  }

  private JPanel createButtonPanel(final Action[] additionalActions) {
    return isToolBarStyleButtons()
        ? createToolbarStyleButtons(additionalActions)
        : createNonToolbarStyleButtons(additionalActions);
  }

  private JPanel createNonToolbarStyleButtons(final Action[] additionalActions) {
    final ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.VERTICAL);
    for (Action additionalAction : additionalActions) {
      builder.add(additionalAction);
    }
    final JPanel panel = builder.createPanel();
    panel.setBorder(null);
    return panel;
  }

  private JPanel createToolbarStyleButtons(final Action[] additionalActions) {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    final JPanel buttonPanel = new JPanel(new GridDialogLayout(1, false));
    for (Action additionalAction : additionalActions) {
      buttonPanel.add(ToolBarUtilities.createToolBarButton(additionalAction), layoutData);
    }
    return buttonPanel;
  }

  public void requestFocus() {
    table.requestFocus();
  }

  public void setHeaderToolTipProvider(final ITableHeaderToolTipProvider provider) {
    addTableHeaderRendererDecorator(new ToolTipCellRendererDecorator(provider));
  }

  public void addTableHeaderRendererDecorator(final AbstractTableCellRendererDecorator decorator) {
    final JTableHeader tableHeader = table.getTableHeader();
    decorator.setDelegate(tableHeader.getDefaultRenderer());
    tableHeader.setDefaultRenderer(decorator);
  }

  public synchronized void addSelectionActionListener(final ActionListener listener) {
    selectionActionListeners.add(listener);
  }

  public synchronized void removeSelectionActionListener(final ActionListener listener) {
    selectionActionListeners.remove(listener);
  }

  private void fireSelectionActionEvent() {
    final ActionEvent actionEvent = new ActionEvent(table, -1, "select"); //$NON-NLS-1$
    selectionActionListeners.forAllDo(new IClosure<ActionListener>() {
      @Override
      public void execute(final ActionListener listener) {
        listener.actionPerformed(actionEvent);
      }
    });
  }

  public final void scrollToAndSelect(final int rowIndex) {
    getTable().getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
    assureSelectionVisible();
  }

  public void stopCellEditing() {
    final TableCellEditor cellEditor = getTable().getCellEditor();
    if (cellEditor != null) {
      cellEditor.stopCellEditing();
    }
  }

  public void cancelCellEditing() {
    final TableCellEditor cellEditor = getTable().getCellEditor();
    if (cellEditor != null) {
      cellEditor.cancelCellEditing();
    }
  }

  public boolean isToolBarStyleButtons() {
    return toolBarStyleButtons;
  }

  public void setToolBarStyleButtons(final boolean toolBarStyleButtons) {
    this.toolBarStyleButtons = toolBarStyleButtons;
  }

  public int getSelectedRowIndex() {
    //Bugfix for JDK1.4 JTable Bug 4905083: Pressing enter on empty table moves selection to 1
    // (fixed in Java 1.5 / Tiger)
    final int selectedRowIndex = table.getSelectedRow();
    return selectedRowIndex > table.getRowCount() ? -1 : selectedRowIndex;
  }

  public int[] getSelectedRows() {
    final int[] selectedRows = table.getSelectedRows();
    return selectedRows;
  }

  public boolean isSelectionEmpty() {
    return getSelectedRowIndex() == -1;
  }

  public void addListSelectionListener(final ListSelectionListener listener) {
    final ListSelectionModel selectionModel = getTable().getSelectionModel();
    selectionModel.addListSelectionListener(listener);
  }

  public void assureSelectionVisible() {
    final int rowIndex = getTable().getSelectedRow();
    if (rowIndex != -1) {
      getTable().scrollRectToVisible(getTable().getCellRect(rowIndex, 0, true));
    }
  }

  @Override
  public JComponent[] getComponents() {
    return new JComponent[]{ getContent() };
  }

  public ITableColumnViewSettings<?>[] getSettings() {
    final ITableColumnViewSettings<?>[] settings = configuration.getColumnViewSettings();
    return Arrays.copyOf(settings, settings.length);
  }

  public void setBackground(final Color background) {
    table.setBackground(background);
  }

  public void hideHeader() {
    table.setTableHeader(null);
  }

  public void setName(final String name) {
    table.setName(name);
  }

  public ListSelectionModel getSelectionModel() {
    return table.getSelectionModel();
  }

  public void setFocusable(final boolean focusable) {
    table.setFocusable(focusable);
  }

  public int getRowCount() {
    return table.getRowCount();
  }

  public void fireChangeEvent() {
    getTable().tableChanged(new TableModelEvent(getModel()));
  }
}