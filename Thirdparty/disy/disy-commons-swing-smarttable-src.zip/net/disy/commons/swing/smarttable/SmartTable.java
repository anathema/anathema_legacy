//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableModel;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.DisableableProxyAction;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutDirection;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.table.AbstractTableCellRendererDecorator;
import net.disy.commons.swing.table.DefaultTableHeaderToolTipProvider;
import net.disy.commons.swing.table.ITableHeaderToolTipProvider;
import net.disy.commons.swing.table.ToolTipCellRendererDecorator;
import net.disy.commons.swing.toolbar.ToolBarUtilities;

// NOT_PUBLISHED
public class SmartTable implements IComponentContainer {

  private boolean enabled = true;
  private final JTable table;
  private JComponent content;
  private final List/*<ActionListener>*/selectionActionListeners = new ArrayList();
  private final List/*<ITableActionFactory>*/actionFactories = new ArrayList();
  private boolean toobarStyleButtons = true;

  private Action[] actions = new Action[0];

  public SmartTable(TableModel tableModel, ITableColumnViewSettings[] settings) {
    Ensure.ensureArgumentNotNull(tableModel);
    Ensure.ensureArgumentNotNull(settings);

    table = new JTable(tableModel);
    tableModel.addTableModelListener(new TableModelListener() {
      public void tableChanged(TableModelEvent e) {
        cancelCellEditing();
      }
    });

    table.addMouseListener(new MouseAdapter() {
      public void mouseClicked(MouseEvent e) {
        if (e.getClickCount() != 2 || e.isMetaDown()) {
          return;
        }
        if (table.getSelectedRowCount() == 0) {
          return;
        }
        fireSelectionActionEvent();
      }
    });

    //TODO 09.11.2004 (gebhard): Minimum row height should be maximum of all minimum row heights from all settings
    table.setRowHeight(Math.max(table.getRowHeight(), 21));
    TableColumnConfigurator.configureTableColumns(table, settings);

    setHeaderToolTipProvider(new DefaultTableHeaderToolTipProvider());
    setSelectionMode(ListSelectionMode.SINGLE_SELECTION);
  }

  public void addActionFactory(ITableActionFactory actionFactory) {
    Ensure.ensureArgumentNotNull(actionFactory);
    if (content != null) {
      throw new IllegalStateException("Adding actions after creating content."); //$NON-NLS-1$
    }
    actionFactories.add(actionFactory);
  }

  public void setSelectionMode(ListSelectionMode selectionMode) {
    table.setSelectionMode(selectionMode.getListSelectionMode());
  }

  public JTable getTable() {
    return table;
  }

  public TableModel getModel() {
    return table.getModel();
  }

  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
    updateEnabled();
  }

  public boolean isEnabled() {
    return enabled;
  }

  protected void updateEnabled() {
    table.setEnabled(enabled);
    if (!enabled) {
      table.getSelectionModel().clearSelection();
    }
    for (int i = 0; i < actions.length; i++) {
      actions[i].setEnabled(enabled);
    }
  }

  public final JComponent getContent() {
    if (content == null) {
      content = createContent();
      updateEnabled();
    }
    return content;
  }

  private JComponent createContent() {
    JPanel tablePanel = new JPanel(new BorderLayout());
    tablePanel.add(table);
    JScrollPane scrollPane = new JScrollPane(tablePanel) {
      public void setEnabled(boolean enabled) {
        super.setEnabled(enabled);
        SmartTable.this.setEnabled(enabled);
      }
    };
    scrollPane.setColumnHeaderView(table.getTableHeader());
    int preferredWidth = table.getPreferredSize().width
        + scrollPane.getInsets().left
        + scrollPane.getInsets().right;
    scrollPane.setPreferredSize(new Dimension(preferredWidth, 150));

    this.actions = createTableActions();
    if (actions.length <= 0) {
      return scrollPane;
    }
    JPanel panel = new JPanel(new BorderLayout(
        LayoutUtilities.getComponentSpacing(),
        LayoutUtilities.getComponentSpacing())) {
      public void setEnabled(boolean enabled) {
        SmartTable.this.setEnabled(enabled);
        if (!enabled) {
          TableCellEditor cellEditor = getTable().getCellEditor();
          if (cellEditor != null) {
            cellEditor.stopCellEditing();
          }
        }
      }
    };
    panel.add(scrollPane, BorderLayout.CENTER);
    panel.add(createButtonPanel(actions), BorderLayout.EAST);
    return panel;
  }

  private Action[] createTableActions() {
    Action[] createdActions = new Action[actionFactories.size()];
    for (int i = 0; i < createdActions.length; i++) {
      ITableActionFactory factory = (ITableActionFactory) actionFactories.get(i);
      createdActions[i] = new DisableableProxyAction(factory.createAction(this));
    }
    return createdActions;
  }

  private JPanel createButtonPanel(Action[] additionalActions) {
    return isToolbarStyleButtons()
        ? createToolbarStyleButtons(additionalActions)
        : createNonToolbarStyleButtons(additionalActions);
  }

  private JPanel createNonToolbarStyleButtons(Action[] additionalActions) {
    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.VERTICAL);
    for (int i = 0; i < additionalActions.length; i++) {
      builder.add(additionalActions[i]);
    }
    JPanel panel = builder.createPanel();
    panel.setBorder(null);
    return panel;
  }

  private JPanel createToolbarStyleButtons(Action[] additionalActions) {
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    JPanel buttonPanel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < additionalActions.length; i++) {
      buttonPanel.add(ToolBarUtilities.createToolBarButton(additionalActions[i]), layoutData);
    }
    return buttonPanel;
  }

  public void requestFocus() {
    table.requestFocus();
  }

  public void setHeaderToolTipProvider(ITableHeaderToolTipProvider provider) {
    addTableHeaderRendererDecorator(new ToolTipCellRendererDecorator(provider));
  }

  public void addTableHeaderRendererDecorator(AbstractTableCellRendererDecorator decorator) {
    JTableHeader tableHeader = table.getTableHeader();
    decorator.setDelegate(tableHeader.getDefaultRenderer());
    tableHeader.setDefaultRenderer(decorator);
  }

  public synchronized void addSelectionActionListener(ActionListener listener) {
    selectionActionListeners.add(listener);
  }

  public synchronized void removeSelectionActionListener(ActionListener listener) {
    selectionActionListeners.remove(listener);
  }

  private void fireSelectionActionEvent() {
    List clone;
    synchronized (this) {
      clone = new ArrayList(selectionActionListeners);
    }
    ActionEvent actionEvent = new ActionEvent(table, -1, "select"); //$NON-NLS-1$
    for (Iterator iter = clone.iterator(); iter.hasNext();) {
      ActionListener element = (ActionListener) iter.next();
      element.actionPerformed(actionEvent);
    }
  }

  public final void scrollToAndSelect(int rowIndex) {
    getTable().scrollRectToVisible(getTable().getCellRect(rowIndex, 0, true));
    getTable().getSelectionModel().setSelectionInterval(rowIndex, rowIndex);
    getTable().requestFocus();
  }

  public void stopCellEditing() {
    TableCellEditor cellEditor = getTable().getCellEditor();
    if (cellEditor != null) {
      cellEditor.stopCellEditing();
    }
  }

  public void cancelCellEditing() {
    TableCellEditor cellEditor = getTable().getCellEditor();
    if (cellEditor != null) {
      cellEditor.cancelCellEditing();
    }
  }

  public boolean isToolbarStyleButtons() {
    return toobarStyleButtons;
  }

  public void setToobarStyleButtons(boolean toobarStyleButtons) {
    this.toobarStyleButtons = toobarStyleButtons;
  }

  public int getSelectedRowIndex() {
    //Bugfix for JDK1.4 JTable Bug 4905083: Pressing enter on empty table moves selection to 1
    // (fixed in Java 1.5 / Tiger)
    int selectedRowIndex = table.getSelectedRow();
    return selectedRowIndex > table.getRowCount() ? -1 : selectedRowIndex;
  }

  public boolean isSelectionEmpty() {
    return getSelectedRowIndex() == -1;
  }
}