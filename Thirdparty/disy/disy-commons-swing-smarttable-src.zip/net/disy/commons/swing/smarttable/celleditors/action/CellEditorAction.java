/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.celleditors.action;

import java.awt.Component;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.columnsettings.IEditStoppedHandler;

public abstract class CellEditorAction extends SmartAction {

  private final IEditStoppedHandler handler;

  public CellEditorAction(final IEditStoppedHandler handler) {
    Ensure.ensureArgumentNotNull(handler);
    this.handler = handler;
  }

  @Override
  protected void execute(final Component parentComponent) {
    final ICellEditResult result = performCellEdit(parentComponent);
    result.accept(new ICellEditResultVisitor() {
      @Override
      public void visitFinished(final FinishedCellEditResult visitedResult) {
        handler.editFinished(visitedResult.getValue());
      }

      @Override
      public void visitCanceled(final CanceledCellEditResult visitedResult) {
        handler.editCanceled();
      }
    });
  }

  protected abstract ICellEditResult performCellEdit(Component parentComponent);

}