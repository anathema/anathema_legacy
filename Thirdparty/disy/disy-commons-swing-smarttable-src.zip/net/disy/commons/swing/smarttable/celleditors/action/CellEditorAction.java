//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.celleditors.action;

import java.awt.Component;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.columnsettings.IEditStoppedHandler;

// NOT_PUBLISHED
public abstract class CellEditorAction extends SmartAction {

  private final IEditStoppedHandler handler;

  public CellEditorAction(IEditStoppedHandler handler) {
    Ensure.ensureArgumentNotNull(handler);
    this.handler = handler;
  }

  protected void execute(Component parentComponent) {
    ICellEditResult result = performCellEdit(parentComponent);
    result.accept(new ICellEditResultVisitor() {
      public void visitFinished(FinishedCellEditResult visitedResult) {
        handler.editFinished(visitedResult.getValue());
      }

      public void visitCanceled(CanceledCellEditResult visitedResult) {
        handler.editCanceled();
      }
    });
  }

  protected abstract ICellEditResult performCellEdit(Component parentComponent);

}