/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.DateRange;
import net.disy.commons.swing.smarttable.celleditors.CellEditorNullValueStrategy;
import net.disy.commons.swing.smarttable.celleditors.DateCellEditor;
import net.disy.commons.swing.smarttable.cellrenderers.StringCellRenderer;

public class DateTableColumnSettings extends AbstractTableColumnSettings<Date> {

  private static final String DEFAULT_FORMAT = "dd.MM.yyyy"; //$NON-NLS-1$

  private final DateCellEditor editor;

  private final DateFormat format;

  public DateTableColumnSettings() {
    this(CellEditorNullValueStrategy.DISALLOW);
  }

  public DateTableColumnSettings(final CellEditorNullValueStrategy cellEditorNullValueStrategy) {
    this(DEFAULT_FORMAT, cellEditorNullValueStrategy);
  }

  public DateTableColumnSettings(
      final String formatString,
      final CellEditorNullValueStrategy cellEditorNullValueStrategy) {
    super(formatString.length());
    format = new SimpleDateFormat(formatString);
    editor = new DateCellEditor(format, cellEditorNullValueStrategy);
  }

  @Override
  public TableCellEditor getEditor() {
    return editor;
  }

  @Override
  protected TableCellRenderer getBaseRenderer() {
    return new StringCellRenderer() {
      @Override
      public Component getTableCellRendererComponent(
          final JTable table,
          final Object valueObject,
          final boolean isSelected,
          final boolean hasFocus,
          final int row,
          final int column) {
        final Object value = valueObject == null ? "" : format.format(valueObject); //$NON-NLS-1$
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
      }
    };
  }

  public void setAllowedRange(final DateRange range) {
    editor.setAllowedRange(range);
  }
}