//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import java.awt.Component;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import javax.swing.JTable;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.DateRange;
import net.disy.commons.swing.smarttable.celleditors.DateCellEditor;
import net.disy.commons.swing.smarttable.celleditors.NullValueStrategy;
import net.disy.commons.swing.smarttable.cellrenderers.StringCellRenderer;

// NOT_PUBLISHED
public class DateTableColumnSettings extends AbstractTableColumnSettings {

  private static final String DEFAULT_FORMAT = "dd.MM.yyyy"; //$NON-NLS-1$

  private final NullValueStrategy nullValueStrategy;
  private DateCellEditor editor;

  private final DateFormat format;

  public DateTableColumnSettings() {
    this(NullValueStrategy.DISALLOW);
  }

  public DateTableColumnSettings(NullValueStrategy nullValueStrategy) {
    this(DEFAULT_FORMAT, nullValueStrategy);
  }

  public DateTableColumnSettings(String formatString, NullValueStrategy nullValueStrategy) {
    super(10);
    this.nullValueStrategy = nullValueStrategy;
    format = new SimpleDateFormat(formatString);
    editor = new DateCellEditor(format, nullValueStrategy);
  }

  //@Overrides
  public TableCellEditor getEditor() {
    return editor;
  }

  //@Overrides
  public TableCellRenderer getRenderer() {
    return new StringCellRenderer() {
      //@Overrides
      public Component getTableCellRendererComponent(
          JTable table,
          Object value,
          boolean isSelected,
          boolean hasFocus,
          int row,
          int column) {
        value = (value == null) ? nullValueStrategy.getStringValue() : format.format(value);
        return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
      }
    };
  }

  public void setAllowedRange(DateRange range) {
    editor.setAllowedRange(range);
  }
}