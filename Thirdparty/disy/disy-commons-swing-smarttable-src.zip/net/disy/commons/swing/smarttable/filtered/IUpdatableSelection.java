package net.disy.commons.swing.smarttable.filtered;

public interface IUpdatableSelection {

  void updateSelection();
}