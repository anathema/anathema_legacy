/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.Icon;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.IObjectSelectionStrategy;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.celleditors.ButtonCellEditor;

public final class ButtonTableColumnSettings implements ITableColumnViewSettings<Object> {

  private final IButtonEditorConfiguration configuration;

  public ButtonTableColumnSettings(final IButtonEditorConfiguration configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
  }

  @Override
  public TableCellEditor getEditor() {
    return new ButtonCellEditor(configuration);
  }

  @Override
  public TableCellRenderer getRenderer() {
    return new ButtonCellEditor(configuration);
  }

  @Override
  public boolean isResizable() {
    return false;
  }

  @Override
  public int getPreferredWidth() {
    return ButtonCellEditor.getButtonWidth(configuration.getLongestButtonLabel(), configuration
        .getLargestButtonIcon());
  }

  @Override
  public IObjectSelectionStrategy<Object> getDoubleClickBehaviour() {
    return new NullDoubleClickBehaviour<Object>();
  }

  @Override
  public Icon getIcon() {
    return null;
  }

  @Override
  public String getToolTipText() {
    return null;
  }
}