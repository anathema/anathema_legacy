//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.celleditors.ButtonCellEditor;

// NOT_PUBLISHED
public final class ButtonTableColumnSettings implements ITableColumnViewSettings {

  private final IButtonEditorConfiguration configuration;

  public ButtonTableColumnSettings(IButtonEditorConfiguration configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
  }

  public TableCellEditor getEditor() {
    return new ButtonCellEditor(configuration);
  }

  public TableCellRenderer getRenderer() {
    return new ButtonCellEditor(configuration);
  }

  public boolean isResizable() {
    return false;
  }

  public int getPreferredWidth() {
    return ButtonCellEditor.getButtonWidth(configuration.getLongestButtonLabel(), configuration
        .getLargestButtonIcon());
  }
}