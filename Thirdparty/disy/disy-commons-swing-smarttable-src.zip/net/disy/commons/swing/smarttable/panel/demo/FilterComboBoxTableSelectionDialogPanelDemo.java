/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.panel.demo;

import java.awt.Component;
import java.util.List;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.text.combobox.IFilterComboBoxConfiguration;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoFilterComboBoxConfiguration;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.smarttable.dialog.ITableSelectionDialogConfiguration;
import net.disy.commons.swing.smarttable.dialog.demo.DemoTableSelectionDialogConfiguration;
import net.disy.commons.swing.smarttable.panel.FilterComboBoxTableSelectionDialogPanel;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class FilterComboBoxTableSelectionDialogPanelDemo extends SwingDemoCase {

  @Demo
  public void demo() {
    final FilterComboBoxTableSelectionDialogPanel<DemoColorItem> panel = createPanel();
    show(panel.getContent());
  }

  @Demo
  public void demo2Panels() {
    final FilterComboBoxTableSelectionDialogPanel<DemoColorItem> panel1 = createPanel();
    final FilterComboBoxTableSelectionDialogPanel<DemoColorItem> panel2 = createPanel();
    show(
        new Component[]{ panel1.getContent(), panel2.getContent() },
        new GridDialogLayout(1, false));
  }

  private FilterComboBoxTableSelectionDialogPanel<DemoColorItem> createPanel() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    final IListModel<DemoColorItem> itemsModel = new DefaultListModel<DemoColorItem>(items);
    final ObjectModel<DemoColorItem> selectionModel = new ObjectModel<DemoColorItem>(items.get(2));
    final IFilterComboBoxConfiguration<DemoColorItem> comboBoxConfiguration = new DemoFilterComboBoxConfiguration();
    final ITableSelectionDialogConfiguration<DemoColorItem> tableSelectionConfiguration = new DemoTableSelectionDialogConfiguration();
    final FilterComboBoxTableSelectionDialogPanel<DemoColorItem> panel = new FilterComboBoxTableSelectionDialogPanel<DemoColorItem>(
        itemsModel,
        selectionModel,
        comboBoxConfiguration,
        tableSelectionConfiguration);
    return panel;
  }
}