/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.test;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.swing.component.tristate.TriState;
import net.disy.commons.swing.smarttable.demo.DemoObject;
import net.disy.commons.swing.smarttable.demo.DemoObjectFactory;

public class TestTableModel extends AbstractTableModel {

  List<DemoObject> objects = new ArrayList<DemoObject>();

  DemoObjectFactory factory = new DemoObjectFactory(4711);
  private static final String[] COLUMN_NAMES = new String[]{ "Double", //$NON-NLS-1$
      "Integer", //$NON-NLS-1$
      "Name", //$NON-NLS-1$
      "Farbe", //$NON-NLS-1$
      "Datum", //$NON-NLS-1$
      "C", //$NON-NLS-1$
      "Alter", //$NON-NLS-1$
      "TriState" }; //$NON-NLS-1$
  private static final Class[] COLUMN_CLASSES = new Class[]{
      Number.class,
      Number.class,
      String.class,
      Color.class,
      Date.class,
      Boolean.class,
      Number.class,
      TriState.class };

  public TestTableModel() {
    addRandomRow();
  }

  @Override
  public Class<?> getColumnClass(int columnIndex) {
    return columnIndex < COLUMN_CLASSES.length ? COLUMN_CLASSES[columnIndex] : Object.class;
  }

  @Override
  public String getColumnName(int columnIndex) {
    return columnIndex < COLUMN_NAMES.length ? COLUMN_NAMES[columnIndex] : "UNKOWN"; //$NON-NLS-1$
  }

  public void addRandomRows(int number) {
    for (int i = 0; i < number; ++i) {
      addRandomRow();
    }
  }

  public void addRandomRow() {
    final DemoObject createObject = factory.createObject();
    addObject(createObject);
  }

  public void addObject(final DemoObject createObject) {
    final int rows = getRowCount();
    objects.add(createObject);
    fireTableRowsInserted(rows, rows);
  }

  @Override
  public boolean isCellEditable(final int row, final int column) {
    return row < getRowCount() && column < getColumnCount();
  }

  @Override
  public int getRowCount() {
    return objects.size();
  }

  @Override
  public int getColumnCount() {
    return COLUMN_NAMES.length;
  }

  @Override
  public void setValueAt(Object value, int rowIndex, int columnIndex) {
    DemoObject object = createObject(value, rowIndex, columnIndex);
    objects.set(rowIndex, object);
    fireTableRowsUpdated(rowIndex, rowIndex);
  }

  private DemoObject createObject(Object value, int rowIndex, int columnIndex) {
    DemoObject object = objects.get(rowIndex);
    switch (columnIndex) {
      case 0: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            (Double) value,
            object.getFlag(),
            object.getColor(),
            object.getDate(),
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 1: {
        return new DemoObject(
            (Integer) value,
            object.getStringValue(),
            object.getDoubleValue(),
            object.getFlag(),
            object.getColor(),
            object.getDate(),
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 2: {
        return new DemoObject(
            object.getIntegerValue(),
            (String) value,
            object.getDoubleValue(),
            object.getFlag(),
            object.getColor(),
            object.getDate(),
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 3: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            object.getDoubleValue(),
            object.getFlag(),
            (Color) value,
            object.getDate(),
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 4: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            object.getDoubleValue(),
            object.getFlag(),
            object.getColor(),
            (Date) value,
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 5: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            object.getDoubleValue(),
            (Boolean) value,
            object.getColor(),
            object.getDate(),
            object.getNullSaveNumber(),
            object.getTriState());
      }
      case 6: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            object.getDoubleValue(),
            object.getFlag(),
            object.getColor(),
            object.getDate(),
            (Integer) value,
            object.getTriState());
      }
      case 7: {
        return new DemoObject(
            object.getIntegerValue(),
            object.getStringValue(),
            object.getDoubleValue(),
            object.getFlag(),
            object.getColor(),
            object.getDate(),
            object.getNullSaveNumber(),
            (TriState) value);
      }
    }
    throw new UnreachableCodeReachedException();
  }

  public void removeRow(int rowIndex) {
    if (rowIndex < 0 && rowIndex >= getRowCount()) {
      return;
    }
    objects.remove(rowIndex);
    fireTableRowsDeleted(rowIndex, rowIndex);
  }

  @Override
  public Object getValueAt(int rowIndex, int columnIndex) {
    DemoObject object = objects.get(rowIndex);
    switch (columnIndex) {
      case 0: {
        return object.getDoubleValue();
      }
      case 1: {
        return object.getIntegerValue();
      }
      case 2: {
        return object.getStringValue();
      }
      case 3: {
        return object.getColor();
      }
      case 4: {
        return object.getDate();
      }
      case 5: {
        return object.getFlag();
      }
      case 6: {
        return object.getNullSaveNumber();
      }
      case 7: {
        return object.getTriState();
      }
    }
    return null;
  }
}