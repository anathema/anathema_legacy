//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ISimpleBlock;

/**
 * Abstract base class for any {@link IChangeableModel} that shall be adapted as {@link TableModel}.
 */
public abstract class AbstractChangeableModelTableModel extends AbstractTableModel {

  /* 22.01.2006 (Markus Gebhard): 
   Flag to suppress change event propagation while already firing dedicated events for certain
   rows/cells (otherwise selection would get lost in JTable!) */
  private boolean autoEventsSuppressed = false;
  private final IChangeableModel model;

  protected AbstractChangeableModelTableModel(IChangeableModel model) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        if (!autoEventsSuppressed) {
          fireTableDataChanged();
        }
      }
    });
  }

  protected final IChangeableModel getModel() {
    return model;
  }

  protected final void commitRowModification(int rowIndex, ISimpleBlock commitBlock) {
    synchronized (model) {
      try {
        autoEventsSuppressed = true;
        commitBlock.execute();
        fireTableRowsUpdated(rowIndex, rowIndex);
      }
      finally {
        autoEventsSuppressed = false;
      }
    }
  }

  protected final void commitCellModification(int rowIndex, int columnIndex, ISimpleBlock commitBlock) {
    synchronized (model) {
      try {
        autoEventsSuppressed = true;
        commitBlock.execute();
        fireTableCellUpdated(rowIndex, columnIndex);
      }
      finally {
        autoEventsSuppressed = false;
      }
    }
  }
}