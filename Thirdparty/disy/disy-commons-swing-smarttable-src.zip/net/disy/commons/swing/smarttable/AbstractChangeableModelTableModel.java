/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable;

import javax.swing.table.AbstractTableModel;
import javax.swing.table.TableModel;

import net.disy.commons.core.model.IChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IExceptionThrowingBlock;

/**
 * Abstract base class for any {@link IChangeableModel} that shall be adapted as {@link TableModel}.
 */
public abstract class AbstractChangeableModelTableModel<T extends IChangeableModel>
    extends
    AbstractTableModel {

  /* 22.01.2006 (Markus Gebhard): 
   Flag to suppress change event propagation while already firing dedicated events for certain
   rows/cells (otherwise selection would get lost in JTable!) */
  private boolean autoEventsSuppressed = false;
  private final T model;

  protected AbstractChangeableModelTableModel(final T model) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        if (!autoEventsSuppressed) {
          fireTableDataChanged();
        }
      }
    });
  }

  protected final T getModel() {
    return model;
  }

  protected final void commitRowModification(
      final int rowIndex,
      final IExceptionThrowingBlock<RuntimeException> commitBlock) {
    synchronized (model) {
      try {
        autoEventsSuppressed = true;
        commitBlock.execute();
        fireTableRowsUpdated(rowIndex, rowIndex);
      }
      finally {
        autoEventsSuppressed = false;
      }
    }
  }

  protected final void commitCellModification(
      final int rowIndex,
      final int columnIndex,
      final IExceptionThrowingBlock<RuntimeException> commitBlock) {
    synchronized (model) {
      try {
        autoEventsSuppressed = true;
        commitBlock.execute();
        fireTableCellUpdated(rowIndex, columnIndex);
      }
      finally {
        autoEventsSuppressed = false;
      }
    }
  }
}