//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.demo;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.Action;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.actions.ITableActionFactory;
import net.disy.commons.swing.smarttable.celleditors.NullValueStrategy;
import net.disy.commons.swing.smarttable.columnsettings.ButtonTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.CheckBoxTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.ColorEditorTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.ComboBoxTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.DateTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.DoubleTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.IntegerTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NumberTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.table.ITableHeaderToolTipProvider;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SmartTableDemo extends SwingDemoCase {

  public void demo() {
    final DemoTableModel tableModel = new DemoTableModel();
    ITableColumnViewSettings[] columnSettings = createTableColumnSettings();
    SmartTable table = new SmartTable(tableModel, columnSettings);
    show(table.getContent());
  }

  public void demoWithCustomHeaderToolTipProvider() {
    final DemoTableModel tableModel = new DemoTableModel();
    ITableColumnViewSettings[] columnSettings = createTableColumnSettings();
    SmartTable table = new SmartTable(tableModel, columnSettings);
    table.setHeaderToolTipProvider(new ITableHeaderToolTipProvider() {
      public String getToolTip(Object value, int columnIndex) {
        return "Tooltip " + columnIndex; //$NON-NLS-1$
      }
    });
    show(table.getContent());
  }

  public void demoEnableAndDisable() {
    final DemoTableModel tableModel = new DemoTableModel();
    ITableColumnViewSettings[] columnSettings = createTableColumnSettings();

    SmartTable table = new SmartTable(tableModel, columnSettings);
    final JComponent tableContent = table.getContent();
    final JCheckBox checkBox = new JCheckBox("enabled"); //$NON-NLS-1$
    checkBox.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        tableContent.setEnabled(checkBox.isSelected());
      }
    });
    checkBox.setSelected(true);
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(checkBox, BorderLayout.NORTH);
    panel.add(tableContent, BorderLayout.CENTER);
    show(panel);
  }

  private ITableColumnViewSettings[] createTableColumnSettings() {
    return new ITableColumnViewSettings[]{
        new DoubleTableColumnSettings(),
        new IntegerTableColumnSettings(-5, 200, 1),
        new StringTableColumnSettings(),
        new ColorEditorTableColumnSettings(),
        NumberTableColumnSettings.getDoubleInstance("#0.00", NullValueStrategy.DISALLOW), //$NON-NLS-1$
        new ComboBoxTableColumnSettings(new String[]{ "eins", "zwei", "drei" }), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        new DateTableColumnSettings(NullValueStrategy.EMPTY),
        new CheckBoxTableColumnSettings(),
        NumberTableColumnSettings.getIntegerInstance("###0", NullValueStrategy.DISALLOW), //$NON-NLS-1$
        new ButtonTableColumnSettings(new DemoButtonEditorConfiguration()) };
  }

  public void demoSmartTableWithAdditionalAction() {
    final DemoTableModel tableModel = new DemoTableModel();
    ITableColumnViewSettings[] columnSettings = createTableColumnSettings();
    SmartTable table = new SmartTable(tableModel, columnSettings);
    table.addActionFactory(new ITableActionFactory() {
      //@Overrides
      public Action createAction(SmartTable myTable) {
        return new SmartAction("Foo...") { //$NON-NLS-1$
          protected void execute(Component parentComponent) {
            //nothing to do
          }
        };
      }
    });
    show(table.getContent());
  }

}