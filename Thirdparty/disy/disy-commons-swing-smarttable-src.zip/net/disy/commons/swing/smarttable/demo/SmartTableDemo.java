/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.demo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.SmartTableConfiguration;
import net.disy.commons.swing.smarttable.actions.AbstractTableActionFactory;
import net.disy.commons.swing.smarttable.actions.AddRowTableActionFactory;
import net.disy.commons.swing.smarttable.actions.IAdditionPerformer;
import net.disy.commons.swing.smarttable.celleditors.CellEditorNullValueStrategy;
import net.disy.commons.swing.smarttable.columnsettings.ButtonTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.CheckBoxTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.ColorEditorTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.ComboBoxTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.DateTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.DoubleTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.IntegerTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.NumberTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.TriStateTableColumnSettings;
import net.disy.commons.swing.table.ITableHeaderToolTipProvider;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class SmartTableDemo extends SwingDemoCase {

  public void demo() {
    final DemoTableModel tableModel = new DemoTableModel();
    final ITableColumnViewSettings<?>[] columnSettings = createTableColumnSettings();
    final SmartTable table = new SmartTable(tableModel, columnSettings);
    show(table.getContent());
  }

  public void demoWithCustomBackgroundColor() {
    final DemoTableModel tableModel = new DemoTableModel();
    final ITableColumnViewSettings<?>[] columnSettings = createTableColumnSettings();
    final SmartTable table = new SmartTable(tableModel, columnSettings);
    table.setBackground(Color.CYAN);
    show(table.getContent());
  }

  public void demoWithCustomHeaderToolTipProvider() {
    final DemoTableModel tableModel = new DemoTableModel();
    final ITableColumnViewSettings<?>[] columnSettings = createTableColumnSettings();
    final SmartTable table = new SmartTable(tableModel, columnSettings);
    table.setHeaderToolTipProvider(new ITableHeaderToolTipProvider() {
      @Override
      public String getToolTip(final Object value, final int columnIndex) {
        return "Tooltip " + columnIndex; //$NON-NLS-1$
      }

      @Override
      public Icon getIcon(final int columnIndex) {
        return null;
      }
    });
    show(table.getContent());
  }

  public void demoEnableAndDisable() {
    final DemoTableModel tableModel = new DemoTableModel();
    final ITableColumnViewSettings<?>[] columnSettings = createTableColumnSettings();

    final SmartTable table = new SmartTable(tableModel, columnSettings);
    final JComponent tableContent = table.getContent();
    final JCheckBox checkBox = new JCheckBox("enabled"); //$NON-NLS-1$
    checkBox.addChangeListener(new javax.swing.event.ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent e) {
        tableContent.setEnabled(checkBox.isSelected());
      }
    });
    checkBox.setSelected(true);
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(checkBox, BorderLayout.NORTH);
    panel.add(tableContent, BorderLayout.CENTER);
    show(panel);
  }

  private ITableColumnViewSettings<?>[] createTableColumnSettings() {
    return new ITableColumnViewSettings[]{
        new DoubleTableColumnSettings(),
        new IntegerTableColumnSettings(-5, 200, 1),
        new StringTableColumnSettings(),
        new ColorEditorTableColumnSettings(),
        NumberTableColumnSettings.getDoubleInstance("#0.00", CellEditorNullValueStrategy.DISALLOW), //$NON-NLS-1$
        new ComboBoxTableColumnSettings<String>(new String[]{ "eins", "zwei", "drei" }), //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
        new DateTableColumnSettings("dd.MM.yyyy G", CellEditorNullValueStrategy.EMPTY), //$NON-NLS-1$
        new CheckBoxTableColumnSettings(),
        NumberTableColumnSettings.getIntegerInstance("###0", CellEditorNullValueStrategy.DISALLOW), //$NON-NLS-1$
        new ButtonTableColumnSettings(new DemoButtonEditorConfiguration()),
        new DemoDoubleClickTableColumnSettings(),
        new TriStateTableColumnSettings(false),
        new TriStateTableColumnSettings(true) };
  }

  public void demoSmartTableWithAdditionalAction() {
    final DemoTableModel tableModel = new DemoTableModel();
    final ITableColumnViewSettings<?>[] columnSettings = createTableColumnSettings();
    final SmartTable table = new SmartTable(tableModel, new SmartTableConfiguration(columnSettings));
    table.addActionFactory(new AddRowTableActionFactory(new IAdditionPerformer() {
      @Override
      public boolean performAdd(final Component parent) {
        tableModel.addRandomRow();
        return true;
      }
    }));
    table.addActionFactory(new AbstractTableActionFactory() {
      @Override
      public Action createAction(final SmartTable myTable) {
        return new SmartAction("Foo...") { //$NON-NLS-1$
          @Override
          protected void execute(final Component parentComponent) {
            //nothing to do
          }
        };
      }
    });
    show(table.getContent());
  }
}