/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.awt.Font;
import java.util.Date;

import javax.swing.table.DefaultTableModel;

import net.disy.commons.swing.component.tristate.TriState;

public class DemoTableModel extends DefaultTableModel {

  private static final String[] COLUMN_NAMES = new String[]{ "Double", //$NON-NLS-1$
      "Integer", //$NON-NLS-1$
      "Name", //$NON-NLS-1$
      "Farbe", //$NON-NLS-1$
      "Wert", //$NON-NLS-1$
      "Feld", //$NON-NLS-1$
      "Datum", //$NON-NLS-1$
      "C", //$NON-NLS-1$
      "Alter", //$NON-NLS-1$
      "Font", //$NON-NLS-1$
      "Doppelklick", //$NON-NLS-1$
      "TriState (false)", //$NON-NLS-1$
      "TriState (true)" }; //$NON-NLS-1$
  private static final Class[] COLUMN_CLASSES = new Class[]{
      Number.class,
      Number.class,
      String.class,
      Color.class,
      Number.class,
      String.class,
      Date.class,
      Boolean.class,
      Number.class,
      Font.class,
      String.class,
      TriState.class,
      TriState.class };

  DemoObjectFactory factory = new DemoObjectFactory(4711);

  public DemoTableModel() {
    super(COLUMN_NAMES, 0);
    addRandomRow();
  }

  @Override
  public Class<?> getColumnClass(int columnIndex) {
    return columnIndex < COLUMN_CLASSES.length ? COLUMN_CLASSES[columnIndex] : Object.class;
  }

  public void addRandomRows(int number) {
    for (int i = 0; i < number; ++i) {
      addRandomRow();
    }
  }

  public void addRandomRow() {
    DemoObject object = factory.createObject();
    addRow(new Object[]{
        object.getDoubleValue(),
        object.getIntegerValue(),
        object.getStringValue(),
        object.getColor(),
        new Double(4.2),
        "zwei", //$NON-NLS-1$
        object.getDate(),
        object.getFlag(),
        new Integer(40 + object.getNullSaveNumber()),
        new Font(Font.DIALOG, Font.PLAIN, 11),
        "Klick", //$NON-NLS-1$
        object.getTriState(),
        TriState.DONT_CARE });
  }

  @Override
  public boolean isCellEditable(final int row, final int column) {
    return column != 10;
  }
}