//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.smarttable.demo;

import java.awt.Color;
import java.awt.Font;
import java.util.Date;

import javax.swing.table.DefaultTableModel;

// NOT_PUBLISHED
public class DemoTableModel extends DefaultTableModel {

  public DemoTableModel() {
    super(new String[]{
        "Double", "Integer", "Name", "Farbe", "Wert", "Feld", "Datum", "C", "Alter", "Font" }, 0); //$NON-NLS-1$//$NON-NLS-2$//$NON-NLS-3$ //$NON-NLS-4$ //$NON-NLS-5$ //$NON-NLS-6$ //$NON-NLS-7$ //$NON-NLS-8$ //$NON-NLS-9$ //$NON-NLS-10$
    addRow(new Object[]{
        new Double(1.0),
        new Integer(10),
        "Text", Color.RED, new Double(4.2), "zwei", new Date(), new Boolean(false), new Integer(42), new Font("Dialog", Font.PLAIN, 11) }); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
  }
}