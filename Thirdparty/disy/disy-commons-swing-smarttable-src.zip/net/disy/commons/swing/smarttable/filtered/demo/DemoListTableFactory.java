/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.filtered.demo;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.IMutableListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTableConfigurationBuilder;
import net.disy.commons.swing.smarttable.column.ITableColumn;
import net.disy.commons.swing.smarttable.columnsettings.ObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.filtered.DeprecatedListTable;
import net.disy.commons.swing.smarttable.filtered.IFilterStrategy;
import net.disy.commons.swing.smarttable.sorter.ITableSorterFactory;
import net.disy.commons.swing.ui.IObjectUi;

public class DemoListTableFactory {

  public static DefaultListModel<ListTableDemoModelItem> createAddModel() {
    final ListTableDemoModelItem[] items = createUniqueItems(2);
    return new DefaultListModel<ListTableDemoModelItem>(items);
  }

  public static DefaultListModel<ListTableDemoModelItem> createModel() {
    final ListTableDemoModelItem[] items = createUniqueItems(2000);
    return new DefaultListModel<ListTableDemoModelItem>(items);
  }
  
  public static DefaultListModel<ListTableDemoModelItem> createSmallModel() {
    final ListTableDemoModelItem[] items = createUniqueItems(5);
    return new DefaultListModel<ListTableDemoModelItem>(items);
  }

  public static Iterable<ITableColumn> createColumns(
      IMutableListModel<ListTableDemoModelItem> model,
      boolean filtered) {
    ITableColumn<ListTableDemoModelItem, String> nameColumn = new DemoNameColumn(model, filtered);
    ITableColumn<ListTableDemoModelItem, Long> numberColumn = new DemoLongColumn(model, filtered);
//    ITableColumn<ListTableDemoModelItem, Boolean> flagColumn = new DemoFlagColumn(model, filtered);
    List<ITableColumn> columnsList = new ArrayList<ITableColumn>();
    columnsList.add(nameColumn);
    columnsList.add(numberColumn);
//    columnsList.add(flagColumn);
    return columnsList;
  }

  private static ListTableDemoModelItem[] createUniqueItems(final int count) {
    final ListTableDemoModelItem[] items = new ListTableDemoModelItem[count];
    for (int i = 0; i < items.length; ++i) {
      String name = "Zeile " + (i + 1); //$NON-NLS-1$
      long number = i + 1;
      boolean flag = (number % 2) == 0;
      items[i] = new ListTableDemoModelItem(name, number, flag);
    }
    return items;
  }

  public static DeprecatedListTable<ListTableDemoModelItem> createListTable(
      final IFilterStrategy<ListTableDemoModelItem> filterStrategy,
      final ITableSorterFactory tableSorterFactory) {
    return createListTable(createModel(), filterStrategy, tableSorterFactory);
  }

  public static DeprecatedListTable<ListTableDemoModelItem> createListTable(
      final IListModel<ListTableDemoModelItem> model,
      final IFilterStrategy<ListTableDemoModelItem> filterStrategy,
      final ITableSorterFactory tableSorterFactory) {
    final String[] columnNames = new String[]{ "Name", "Zahl", "Flag" }; //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    final IObjectUi<ListTableDemoModelItem>[] objectUis = DemoListTableFactory.createUiArray();
    final ITableColumnViewSettings<?>[] tableColumnViewSettings = new ITableColumnViewSettings[]{
        new ObjectUiTableColumnSettings<ListTableDemoModelItem>(objectUis[0]),
        new ObjectUiTableColumnSettings<ListTableDemoModelItem>(objectUis[1]),
        new ObjectUiTableColumnSettings<ListTableDemoModelItem>(objectUis[2]) };
    SmartTableConfigurationBuilder builder = new SmartTableConfigurationBuilder(
        tableColumnViewSettings);
    final DeprecatedListTable<ListTableDemoModelItem> table = new DeprecatedListTable<ListTableDemoModelItem>(
        model,
        new ObjectModel<ListTableDemoModelItem>(),
        objectUis,
        columnNames,
        builder.build(),
        filterStrategy,
        tableSorterFactory);
    return table;
  }

  @SuppressWarnings("unchecked")
  private static IObjectUi<ListTableDemoModelItem>[] createUiArray() {
    return new IObjectUi[]{ new ToNameObjectUi(), new ToNumberObjectUi(), new ToFlagObjectUi() };
  }

}
