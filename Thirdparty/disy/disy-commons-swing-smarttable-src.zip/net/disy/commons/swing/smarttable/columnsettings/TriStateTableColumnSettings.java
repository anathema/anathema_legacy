/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.columnsettings;

import javax.swing.JCheckBox;
import javax.swing.table.TableCellEditor;

import net.disy.commons.swing.component.tristate.TriState;
import net.disy.commons.swing.component.tristate.TristateCheckBox;
import net.disy.commons.swing.smarttable.celleditors.DecoratingCellEditor;
import net.disy.commons.swing.smarttable.celleditors.TriStateCellEditor;

public class TriStateTableColumnSettings extends AbstractCheckBoxTableColumnSettings<TriState> {

  private final boolean dontCareSelectionState;

  public TriStateTableColumnSettings(final boolean dontCareSelectionState) {
    this.dontCareSelectionState = dontCareSelectionState;
  }

  @Override
  protected JCheckBox createRenderCheckBox(final Object value) {
    final TristateCheckBox checkBox = new TristateCheckBox(dontCareSelectionState);
    checkBox.setState((TriState) value);
    return checkBox;
  }

  @Override
  public TableCellEditor getEditor() {
    return new DecoratingCellEditor(
        new TriStateCellEditor(dontCareSelectionState),
        new WrapInPanelAsCenteredComponentDecorator());
  }
}