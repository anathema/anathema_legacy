/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.smarttable.actions;

import java.awt.Component;

import javax.swing.Action;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.smarttable.SmartTable;

public abstract class MoveRowDownTableActionFactory extends AbstractTableActionFactory {

  @Override
  public Action createAction(final SmartTable table) {
    final SmartAction action = new SmartAction("Nach unten") {
      @Override
      protected void execute(Component parentComponent) {
        int rowIndex = table.getTable().getSelectedRow();
        table.stopCellEditing();
        boolean success = performMoveDown(rowIndex);
        if (success) {
          table.scrollToAndSelect(rowIndex + 1);
          table.requestFocus();
        }
      }
    };

    table.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(final ListSelectionEvent e) {
        updateEnabled(action, table);
      }
    });
    updateEnabled(action, table);

    return action;
  }

  private void updateEnabled(final Action action, final SmartTable smartTable) {
    final int rowIndex = smartTable.getSelectedRowIndex();
    final boolean hasSelection = rowIndex != -1;
    boolean lastRowSelected = rowIndex == smartTable.getTable().getRowCount() - 1;
    action.setEnabled(hasSelection && !lastRowSelected);
  }

  protected abstract boolean performMoveDown(int rowIndex);
}