package net.disy.commons.swing.layout.grid;

import java.awt.Component;
import java.awt.Dimension;

/**
 * This class is not intended to be used by clients.
 * @author Markus Gebhard
 */
public class GridCell {

  private static final Dimension EMPTY_DIMENSION = new Dimension(0, 0);

  private final int columnIndex;
  private final int rowIndex;
  private final IGridDialogLayoutData layoutData;

  private final Component component;

  private final Dimension preferredSize;
  private final Dimension preferredComponentSize;
  private final Dimension minimumSize;

  public GridCell(
      Component component,
      IGridDialogLayoutData layoutData,
      int columnIndex,
      int rowIndex) {
    this.component = component;
    this.layoutData = layoutData;
    this.columnIndex = columnIndex;
    this.rowIndex = rowIndex;
    preferredComponentSize = component.getPreferredSize();
    minimumSize = computeMinimumSize();
    preferredSize = computePreferredSize();
  }

  private Dimension computeMinimumSize() {
    Dimension minimumComponentSize = component.getMinimumSize();
    int width = minimumComponentSize.width + layoutData.getHorizontalIndent();
    if (layoutData.getWidthHint() > width) {
      width = layoutData.getWidthHint();
    }
    int height = minimumComponentSize.height;
    if (layoutData.getHeightHint() > height) {
      height = layoutData.getHeightHint();
    }
    return new Dimension(width, height);
  }

  private Dimension computePreferredSize() {
    int width = preferredComponentSize.width + layoutData.getHorizontalIndent();
    if (layoutData.getWidthHint() > width) {
      width = layoutData.getWidthHint();
    }
    int height = preferredComponentSize.height;
    if (layoutData.getHeightHint() > height) {
      height = layoutData.getHeightHint();
    }
    return new Dimension(width, height);
  }

  public IGridDialogLayoutData getLayoutData() {
    return layoutData;
  }

  public boolean covers(int columnIndex, int rowIndex) {
    return this.columnIndex <= columnIndex
        && this.rowIndex <= rowIndex
        && this.columnIndex + layoutData.getHorizontalSpan() - 1 >= columnIndex
        && this.rowIndex + layoutData.getVerticalSpan() - 1 >= rowIndex;
  }

  public int getRowIndex() {
    return rowIndex;
  }

  public int getRowSpan() {
    return layoutData.getVerticalSpan();
  }

  public int getColumnIndex() {
    return columnIndex;
  }

  public int getColumnSpan() {
    return layoutData.getHorizontalSpan();
  }

  public Dimension getMinimumSize() {
    if (component.isVisible()) {
      return minimumSize;
    }
    return EMPTY_DIMENSION;
  }

  public Dimension getPreferredSize() {
    if (component.isVisible()) {
      return preferredSize;
    }
    return EMPTY_DIMENSION;
  }

  public Dimension getPreferredComponentSize() {
    if (component.isVisible()) {
      return preferredComponentSize;
    }
    return EMPTY_DIMENSION;
  }

  public Component getComponent() {
    return component;
  }
}