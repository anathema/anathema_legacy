package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JPanel;

import junit.framework.Test;

import net.disy.commons.swing.layout.grid.GridDialogPanel;
import net.disy.commons.swing.layout.grid.IDialogComponent;

import org.hansel.CoverageDecorator;

/**
 * @author Markus Gebhard
 */
public class GridDialogPanelTest extends AbstractGridLayoutTestCase {
  public static Test suite() {
    return new CoverageDecorator(GridDialogPanelTest.class, new Class[]{ GridDialogPanel.class });
  }

  public void testGetContentWithoutAdding() {
    GridDialogPanel panel = new GridDialogPanel();
    JPanel content = panel.getContent();
    assertEquals(0, content.getComponentCount());
    assertEquals(new Dimension(0, 0), content.getPreferredSize());
  }

  public void testGetContentReturnsSameInstance() {
    GridDialogPanel panel = new GridDialogPanel();
    assertSame(panel.getContent(), panel.getContent());
  }

  public void testAddingAfterGetContentThrowsIllegalStateException() {
    GridDialogPanel dialogPanel = new GridDialogPanel();
    dialogPanel.getContent();
    try {
      dialogPanel.add(new IDialogComponent() {
        public int getColumnCount() {
          return 0;
        }

        public void fillInto(JPanel panel, int columnCount) {
          //nothing to do
        }
      });
      fail();
    }
    catch (IllegalStateException expected) {
      //expected
    }
  }

  public void testSingleDialogComponentAddedWithPreferredColumnCount() {
    GridDialogPanel panel = new GridDialogPanel();
    MockDialogComponent mockDialogComponent = new MockDialogComponent(3, 3);
    panel.add(mockDialogComponent);
    panel.getContent();
    mockDialogComponent.verify();
  }

  public void testMultipleDialogComponentsAddedWithPreferredColumnCount() {
    GridDialogPanel panel = new GridDialogPanel();

    MockDialogComponent mockDialogComponent1 = new MockDialogComponent(2, 4);
    panel.add(mockDialogComponent1);
    MockDialogComponent mockDialogComponent2 = new MockDialogComponent(4, 4);
    panel.add(mockDialogComponent2);
    MockDialogComponent mockDialogComponent3 = new MockDialogComponent(1, 4);
    panel.add(mockDialogComponent3);

    panel.getContent();

    mockDialogComponent1.verify();
    mockDialogComponent2.verify();
    mockDialogComponent3.verify();
  }

  public void testRespectsHorizontalSpacing() {
    GridDialogPanel dialogPanel = new GridDialogPanel(42, 0);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10 + 10 + 42, 10), dialogPanel.getContent().getPreferredSize());
  }

  public void testRespectsVerticalSpacing() {
    GridDialogPanel dialogPanel = new GridDialogPanel(0, 13);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10, 10 + 10 + 13), dialogPanel.getContent().getPreferredSize());
  }

  public void testAddVerticalSpacing() {
    GridDialogPanel dialogPanel = new GridDialogPanel(0, 0);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    dialogPanel.addVerticalSpacing(4);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10, 10 + 10 + 4), dialogPanel.getContent().getPreferredSize());
  }

  public void testLaysOutDialogComponents() {
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    final Component component3 = createComponent(new Dimension(10, 10));

    GridDialogPanel dialogPanel = new GridDialogPanel(0, 0);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(component1);
        panel.add(component2);
      }
    });
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(component3);
      }
    });
    doLayout(dialogPanel);

    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  private static void doLayout(GridDialogPanel panel) {
    panel.getContent().setSize(panel.getContent().getPreferredSize());
    panel.getContent().doLayout();
  }

  public void testMovesToNewLineAfterEachDialogComponent() {
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));

    GridDialogPanel dialogPanel = new GridDialogPanel(0, 0);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(component1);
      }
    });
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(component2);
      }
    });
    doLayout(dialogPanel);

    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component2.getBounds());
  }
}