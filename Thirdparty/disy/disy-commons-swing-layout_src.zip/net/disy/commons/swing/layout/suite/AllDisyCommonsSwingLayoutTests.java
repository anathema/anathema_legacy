package net.disy.commons.swing.layout.suite;

import junit.framework.Test;
import junit.framework.TestSuite;

import de.jdemo.junit.Demo2TestConverter;

/**
 * @author Markus Gebhard
 */
public class AllDisyCommonsSwingLayoutTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for de.jave.lib.gui.layout.grid.suite"); //$NON-NLS-1$
    suite.addTest(Demo2TestConverter.createTest(AllDisyCommonsSwingLayoutDemos.suite()));
    suite.addTest(net.disy.commons.swing.layout.grid.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.layout.util.test.AllTests.suite());
    //$JUnit-BEGIN$

    //$JUnit-END$
    return suite;
  }
}
