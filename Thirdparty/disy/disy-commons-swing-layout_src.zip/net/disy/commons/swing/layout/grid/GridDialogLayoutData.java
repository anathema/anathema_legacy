/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayoutData implements IGridDialogLayoutData {

  private GridAlignment verticalAlignment = GridAlignment.CENTER;
  private GridAlignment horizontalAlignment = GridAlignment.BEGINNING;
  private int widthHint = DEFAULT;
  private int heightHint = DEFAULT;
  private int horizontalIndent = 0;
  private int horizontalSpan = 1;
  private int verticalSpan = 1;
  private boolean grabExcessHorizontalSpace = false;
  private boolean grabExcessVerticalSpace = false;

  public static final IGridDialogLayoutData RIGHT = createRight();

  /**
   * Default layout data for filled vertical alignment, grabs vertically.
   */
  public static final IGridDialogLayoutData FILL_VERTICAL = createFillVertical();

  /**
   * Default layout data for filled horizontal alignment, grabs horizontally.
   */
  public static final IGridDialogLayoutData FILL_HORIZONTAL = createFillHorizontal();

  /**
   * A combination of {@link #FILL_VERTICAL} and {@link #FILL_HORIZONTAL}.
   */
  public static final IGridDialogLayoutData FILL_BOTH = createFillBoth();
  public static final IGridDialogLayoutData CENTER = createCenter();
  public static final IGridDialogLayoutData TOP_RIGHT = createRight().setVerticalAlignment(
      GridAlignment.BEGINNING);

  private static GridDialogLayoutData createRight() {
    final GridDialogLayoutData rightData = new GridDialogLayoutData();
    rightData.setHorizontalAlignment(GridAlignment.END);
    return rightData;
  }

  private static GridDialogLayoutData createCenter() {
    final GridDialogLayoutData centerData = new GridDialogLayoutData();
    centerData.setHorizontalAlignment(GridAlignment.CENTER);
    return centerData;
  }

  private static GridDialogLayoutData createFillVertical() {
    final GridDialogLayoutData fillVerticalData = new GridDialogLayoutData();
    fillVerticalData.setVerticalAlignment(GridAlignment.FILL);
    fillVerticalData.setGrabExcessVerticalSpace(true);
    return fillVerticalData;
  }

  private static GridDialogLayoutData createFillHorizontal() {
    final GridDialogLayoutData fillHorizontalData = new GridDialogLayoutData();
    fillHorizontalData.setHorizontalAlignment(GridAlignment.FILL);
    fillHorizontalData.setGrabExcessHorizontalSpace(true);
    return fillHorizontalData;
  }

  private static GridDialogLayoutData createFillBoth() {
    final GridDialogLayoutData fillBothData = new GridDialogLayoutData();
    fillBothData.setHorizontalAlignment(GridAlignment.FILL);
    fillBothData.setVerticalAlignment(GridAlignment.FILL);
    fillBothData.setGrabExcessHorizontalSpace(true);
    fillBothData.setGrabExcessVerticalSpace(true);
    return fillBothData;
  }

  public GridDialogLayoutData() {
    //nothing to do
  }

  /**
   * Creates a new layout data object containing the same layout options as in the given prototype
   * object.
   */
  public GridDialogLayoutData(final IGridDialogLayoutData prototype) {
    this.heightHint = prototype.getHeightHint();
    this.horizontalAlignment = prototype.getHorizontalAlignment();
    this.horizontalIndent = prototype.getHorizontalIndent();
    this.horizontalSpan = prototype.getHorizontalSpan();
    this.verticalAlignment = prototype.getVerticalAlignment();
    this.verticalSpan = prototype.getVerticalSpan();
    this.widthHint = prototype.getWidthHint();
    this.grabExcessHorizontalSpace = prototype.isGrabExcessHorizontalSpace();
    this.grabExcessVerticalSpace = prototype.isGrabExcessVerticalSpace();
  }

  @Override
  public int getHorizontalSpan() {
    return horizontalSpan;
  }

  @Override
  public int getVerticalSpan() {
    return verticalSpan;
  }

  @Override
  public int getHorizontalIndent() {
    return horizontalIndent;
  }

  @Override
  public int getWidthHint() {
    return widthHint;
  }

  @Override
  public int getHeightHint() {
    return heightHint;
  }

  @Override
  public GridAlignment getHorizontalAlignment() {
    return horizontalAlignment;
  }

  @Override
  public GridAlignment getVerticalAlignment() {
    return verticalAlignment;
  }

  @Override
  public boolean isGrabExcessHorizontalSpace() {
    return grabExcessHorizontalSpace;
  }

  @Override
  public boolean isGrabExcessVerticalSpace() {
    return grabExcessVerticalSpace;
  }

  public GridDialogLayoutData setGrabExcessHorizontalSpace(final boolean grabExcessHorizontalSpace) {
    this.grabExcessHorizontalSpace = grabExcessHorizontalSpace;
    return this;
  }

  public GridDialogLayoutData setGrabExcessVerticalSpace(final boolean grabExcessVerticalSpace) {
    this.grabExcessVerticalSpace = grabExcessVerticalSpace;
    return this;
  }

  public GridDialogLayoutData setHeightHint(final int heightHint) {
    this.heightHint = heightHint;
    return this;
  }

  public GridDialogLayoutData setHorizontalAlignment(final GridAlignment horizontalAlignment) {
    this.horizontalAlignment = horizontalAlignment;
    return this;
  }

  public GridDialogLayoutData setHorizontalIndent(final int horizontalIndent) {
    this.horizontalIndent = horizontalIndent;
    return this;
  }

  public GridDialogLayoutData setHorizontalSpan(final int horizontalSpan) {
    this.horizontalSpan = horizontalSpan;
    return this;
  }

  public GridDialogLayoutData setVerticalAlignment(final GridAlignment verticalAlignment) {
    this.verticalAlignment = verticalAlignment;
    return this;
  }

  public GridDialogLayoutData setVerticalSpan(final int verticalSpan) {
    this.verticalSpan = verticalSpan;
    return this;
  }

  public GridDialogLayoutData setWidthHint(final int widthHint) {
    this.widthHint = widthHint;
    return this;
  }
}