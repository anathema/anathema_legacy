package net.disy.commons.swing.layout.grid;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayoutData implements IGridDialogLayoutData {

  private GridAlignment verticalAlignment = GridAlignment.CENTER;
  private GridAlignment horizontalAlignment = GridAlignment.BEGINNING;
  private int widthHint = DEFAULT;
  private int heightHint = DEFAULT;
  private int horizontalIndent = 0;
  private int horizontalSpan = 1;
  private int verticalSpan = 1;
  private boolean grabExcessHorizontalSpace = false;
  private boolean grabExcessVerticalSpace = false;

  public static final IGridDialogLayoutData RIGHT = createRight();

  /**
   * Default layout data for filled vertical alignment, grabs vertically.
   */
  public static final IGridDialogLayoutData FILL_VERTICAL = createFillVertical();

  /**
   * Default layout data for filled horizontal alignment, grabs horizontally.
   */
  public static final IGridDialogLayoutData FILL_HORIZONTAL = createFillHorizontal();

  /**
   * A combination of {@link #FILL_VERTICAL} and {@link #FILL_HORIZONTAL}.
   */
  public static final IGridDialogLayoutData FILL_BOTH = createFillBoth();
  public static final IGridDialogLayoutData CENTER = createCenter();

  private static IGridDialogLayoutData createRight() {
    GridDialogLayoutData rightData = new GridDialogLayoutData();
    rightData.setHorizontalAlignment(GridAlignment.END);
    return rightData;
  }

  private static IGridDialogLayoutData createCenter() {
    GridDialogLayoutData centerData = new GridDialogLayoutData();
    centerData.setHorizontalAlignment(GridAlignment.CENTER);
    return centerData;
  }

  private static IGridDialogLayoutData createFillVertical() {
    GridDialogLayoutData fillVerticalData = new GridDialogLayoutData();
    fillVerticalData.setVerticalAlignment(GridAlignment.FILL);
    fillVerticalData.setGrabExcessVerticalSpace(true);
    return fillVerticalData;
  }

  private static IGridDialogLayoutData createFillHorizontal() {
    GridDialogLayoutData fillHorizontalData = new GridDialogLayoutData();
    fillHorizontalData.setHorizontalAlignment(GridAlignment.FILL);
    fillHorizontalData.setGrabExcessHorizontalSpace(true);
    return fillHorizontalData;
  }

  private static IGridDialogLayoutData createFillBoth() {
    GridDialogLayoutData fillBothData = new GridDialogLayoutData();
    fillBothData.setHorizontalAlignment(GridAlignment.FILL);
    fillBothData.setVerticalAlignment(GridAlignment.FILL);
    fillBothData.setGrabExcessHorizontalSpace(true);
    fillBothData.setGrabExcessVerticalSpace(true);
    return fillBothData;
  }

  public GridDialogLayoutData() {
    //nothing to do
  }

  /** Creates a new layout data object containing the same layout options as in the given
   * prototype object.*/
  public GridDialogLayoutData(IGridDialogLayoutData prototype) {
    this.heightHint = prototype.getHeightHint();
    this.horizontalAlignment = prototype.getHorizontalAlignment();
    this.horizontalIndent = prototype.getHorizontalIndent();
    this.horizontalSpan = prototype.getHorizontalSpan();
    this.verticalAlignment = prototype.getVerticalAlignment();
    this.verticalSpan = prototype.getVerticalSpan();
    this.widthHint = prototype.getWidthHint();
    this.grabExcessHorizontalSpace = prototype.isGrabExcessHorizontalSpace();
    this.grabExcessVerticalSpace = prototype.isGrabExcessVerticalSpace();
  }

  public int getHorizontalSpan() {
    return horizontalSpan;
  }

  public int getVerticalSpan() {
    return verticalSpan;
  }

  public int getHorizontalIndent() {
    return horizontalIndent;
  }

  public int getWidthHint() {
    return widthHint;
  }

  public int getHeightHint() {
    return heightHint;
  }

  public GridAlignment getHorizontalAlignment() {
    return horizontalAlignment;
  }

  public GridAlignment getVerticalAlignment() {
    return verticalAlignment;
  }

  public boolean isGrabExcessHorizontalSpace() {
    return grabExcessHorizontalSpace;
  }

  public boolean isGrabExcessVerticalSpace() {
    return grabExcessVerticalSpace;
  }

  public void setGrabExcessHorizontalSpace(boolean grabExcessHorizontalSpace) {
    this.grabExcessHorizontalSpace = grabExcessHorizontalSpace;
  }

  public void setGrabExcessVerticalSpace(boolean grabExcessVerticalSpace) {
    this.grabExcessVerticalSpace = grabExcessVerticalSpace;
  }

  public void setHeightHint(int heightHint) {
    this.heightHint = heightHint;
  }

  public void setHorizontalAlignment(GridAlignment horizontalAlignment) {
    this.horizontalAlignment = horizontalAlignment;
  }

  public void setHorizontalIndent(int horizontalIndent) {
    this.horizontalIndent = horizontalIndent;
  }

  public void setHorizontalSpan(int horizontalSpan) {
    this.horizontalSpan = horizontalSpan;
  }

  public void setVerticalAlignment(GridAlignment verticalAlignment) {
    this.verticalAlignment = verticalAlignment;
  }

  public void setVerticalSpan(int verticalSpan) {
    this.verticalSpan = verticalSpan;
  }

  public void setWidthHint(int widthHint) {
    this.widthHint = widthHint;
  }
}