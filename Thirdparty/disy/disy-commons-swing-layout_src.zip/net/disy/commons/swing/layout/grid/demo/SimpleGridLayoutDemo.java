/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import javax.swing.JButton;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class SimpleGridLayoutDemo extends SwingDemoCase {

  public void demo1ComponentFillingBothDirections() {
    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.add(new JButton("Button"), GridDialogLayoutData.FILL_BOTH); //$NON-NLS-1$
    show(panel);
  }

}