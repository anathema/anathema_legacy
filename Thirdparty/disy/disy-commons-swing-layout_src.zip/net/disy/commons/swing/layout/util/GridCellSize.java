/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.util;

/**
 * This class is not intended to be used by clients.
 * @author Markus Gebhard
 */
public class GridCellSize {

  private int minimumSize = 0;
  private int preferredSize = 0;
  private int start;
  private int size;
  private boolean grabExcessSpace = false;

  public int getMinimumSize() {
    return minimumSize;
  }

  public int getPreferredSize() {
    return preferredSize;
  }

  public void setMinimumSize(final int minimumSize) {
    this.minimumSize = minimumSize;
  }

  public void setPreferredSize(final int preferredSize) {
    this.preferredSize = preferredSize;
  }

  public void guaranteeMinimumSize(final int minimum) {
    if (this.minimumSize < minimum) {
      this.minimumSize = minimum;
    }
  }

  public void guaranteePreferredSize(final int preferred) {
    if (this.preferredSize < preferred) {
      this.preferredSize = preferred;
    }
  }

  public void setStart(final int start) {
    this.start = start;
  }

  public int getSize() {
    return size;
  }

  public int getStart() {
    return start;
  }

  public boolean isGrabExcessSpace() {
    return grabExcessSpace;
  }

  public void setGrabExcessSpace(final boolean grabExcessSpace) {
    this.grabExcessSpace = grabExcessSpace;
  }

  public void incrementMinimumSize(final int increment) {
    this.minimumSize += increment;
    if (minimumSize < 0) {
      minimumSize = 0;
    }
  }

  public void incrementPreferredSize(final int increment) {
    this.preferredSize += increment;
    if (preferredSize < 0) {
      preferredSize = 0;
    }
  }

  public void adjustToPreferredSize() {
    this.size = preferredSize;
  }

  public void incrementSize(final int increment) {
    this.size += increment;
    if (size < 0) {
      size = 0;
    }
  }

  public void setSize(final int size) {
    this.size = size;
  }
}