/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.grid.IDialogComponent;

public class GridDialogPanelBuilderTest extends AbstractGridLayoutTestCase {

  public void testGetContentWithoutAdding() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    final JPanel content = builder.createPanel();
    assertEquals(0, content.getComponentCount());
    assertEquals(new Dimension(0, 0), content.getPreferredSize());
  }

  public void testGetContentReturnsSameInstance() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    assertSame(builder.createPanel(), builder.createPanel());
  }

  public void testAddingAfterGetContentThrowsIllegalStateException() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    builder.createPanel();
    try {
      builder.add(new IDialogComponent() {
        @Override
        public int getColumnCount() {
          return 0;
        }

        @Override
        public void fillInto(final JPanel panel, final int columnCount) {
          //nothing to do
        }
      });
      fail();
    }
    catch (final IllegalStateException expected) {
      //expected
    }
  }

  public void testSingleDialogComponentAddedWithPreferredColumnCount() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    final MockDialogComponent mockDialogComponent = new MockDialogComponent(3, 3);
    builder.add(mockDialogComponent);
    builder.createPanel();
    mockDialogComponent.verify();
  }

  public void testMultipleDialogComponentsAddedWithPreferredColumnCount() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();

    final MockDialogComponent mockDialogComponent1 = new MockDialogComponent(2, 4);
    builder.add(mockDialogComponent1);
    final MockDialogComponent mockDialogComponent2 = new MockDialogComponent(4, 4);
    builder.add(mockDialogComponent2);
    final MockDialogComponent mockDialogComponent3 = new MockDialogComponent(1, 4);
    builder.add(mockDialogComponent3);

    builder.createPanel();

    mockDialogComponent1.verify();
    mockDialogComponent2.verify();
    mockDialogComponent3.verify();
  }

  public void testRespectsHorizontalSpacing() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder(42, 0);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10 + 10 + 42, 10), builder.createPanel().getPreferredSize());
  }

  public void testRespectsVerticalSpacing() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder(0, 13);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10, 10 + 10 + 13), builder.createPanel().getPreferredSize());
  }

  public void testAddVerticalSpacing() {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder(0, 0);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    builder.addVerticalSpacing(4);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(createComponent(new Dimension(10, 10)));
      }
    });
    assertEquals(new Dimension(10, 10 + 10 + 4), builder.createPanel().getPreferredSize());
  }

  public void testLaysOutDialogComponents() {
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    final Component component3 = createComponent(new Dimension(10, 10));

    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder(0, 0);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(component1);
        panel.add(component2);
      }
    });
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(component3);
      }
    });
    doLayout(builder);

    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  private static void doLayout(final GridDialogPanelBuilder builder) {
    builder.createPanel().setSize(builder.createPanel().getPreferredSize());
    builder.createPanel().doLayout();
  }

  public void testMovesToNewLineAfterEachDialogComponent() {
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));

    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder(0, 0);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(component1);
      }
    });
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(final JPanel panel, final int columnCount) {
        panel.add(component2);
      }
    });
    doLayout(builder);

    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component2.getBounds());
  }
}