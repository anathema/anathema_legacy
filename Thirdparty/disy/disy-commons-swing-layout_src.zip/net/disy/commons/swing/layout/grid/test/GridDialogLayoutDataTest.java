/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.test;

import junit.framework.TestCase;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayoutDataTest extends TestCase {

  public void testConstants() throws Exception {
    assertEquals(GridAlignment.END, GridDialogLayoutData.RIGHT.getHorizontalAlignment());
    assertEquals(GridAlignment.CENTER, GridDialogLayoutData.RIGHT.getVerticalAlignment());

    assertEquals(GridAlignment.CENTER, GridDialogLayoutData.CENTER.getHorizontalAlignment());
    assertEquals(GridAlignment.CENTER, GridDialogLayoutData.CENTER.getVerticalAlignment());

    assertEquals(GridAlignment.FILL, GridDialogLayoutData.FILL_HORIZONTAL.getHorizontalAlignment());
    assertEquals(GridAlignment.CENTER, GridDialogLayoutData.FILL_HORIZONTAL.getVerticalAlignment());
    assertTrue(GridDialogLayoutData.FILL_HORIZONTAL.isGrabExcessHorizontalSpace());
    assertFalse(GridDialogLayoutData.FILL_HORIZONTAL.isGrabExcessVerticalSpace());

    assertEquals(GridAlignment.FILL, GridDialogLayoutData.FILL_BOTH.getHorizontalAlignment());
    assertEquals(GridAlignment.FILL, GridDialogLayoutData.FILL_BOTH.getVerticalAlignment());
    assertTrue(GridDialogLayoutData.FILL_BOTH.isGrabExcessHorizontalSpace());
    assertTrue(GridDialogLayoutData.FILL_BOTH.isGrabExcessVerticalSpace());

    assertEquals(GridAlignment.BEGINNING, GridDialogLayoutData.FILL_VERTICAL
        .getHorizontalAlignment());
    assertEquals(GridAlignment.FILL, GridDialogLayoutData.FILL_VERTICAL.getVerticalAlignment());
    assertFalse(GridDialogLayoutData.FILL_VERTICAL.isGrabExcessHorizontalSpace());
    assertTrue(GridDialogLayoutData.FILL_VERTICAL.isGrabExcessVerticalSpace());
  }
}