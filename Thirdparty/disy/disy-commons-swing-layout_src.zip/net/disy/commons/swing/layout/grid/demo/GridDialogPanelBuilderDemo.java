/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class GridDialogPanelBuilderDemo extends SwingDemoCase {

  public void demo() {
    GridDialogPanelBuilder builder = new GridDialogPanelBuilder(false);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(JPanel panel, int columnCount) {
        GridDialogLayoutData gridLayoutData = new GridDialogLayoutData(
            GridDialogLayoutData.FILL_HORIZONTAL);
        gridLayoutData.setHorizontalSpan(columnCount);
        panel.add(new JTextField("full span textfield"), gridLayoutData); //$NON-NLS-1$
      }
    });
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(JPanel panel, int columnCount) {
        panel.add(new JLabel("Label"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
        panel.add(new JTextField("textfield 2"), GridDialogLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$
      }
    });
    show(builder.createPanel());
  }

  public void demoComponentsNotCoveringAllColumns() {
    GridDialogPanelBuilder builder = new GridDialogPanelBuilder(false);
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 1;
      }

      @Override
      public void fillInto(JPanel panel, int columnCount) {
        IGridDialogLayoutData gridLayoutData = GridDialogLayoutData.FILL_HORIZONTAL;
        panel.add(new JTextField("full span textfield"), gridLayoutData); //$NON-NLS-1$
      }
    });
    builder.add(new IDialogComponent() {
      @Override
      public int getColumnCount() {
        return 2;
      }

      @Override
      public void fillInto(JPanel panel, int columnCount) {
        panel.add(new JLabel("Label"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
        panel.add(new JTextField("textfield 2"), GridDialogLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$
      }
    });
    show(builder.createPanel());
  }

}