/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Point;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayoutBugsTest extends AbstractGridLayoutTestCase {

  public void testBug1() {
    GridDialogLayout layout = new GridDialogLayout(2, false);

    Component component1 = createComponent(new Dimension(99, 10));
    Component component2 = createComponent(new Dimension(35, 10));
    Component component3 = createComponent(new Dimension(42, 10));

    Container container = createContainer(layout);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalSpan(2);
    container.add(component1, layoutData);
    container.add(component2);
    container.add(component3);

    container.setSize(layout.preferredLayoutSize(container));
    layout.layoutContainer(container);

    assertEquals(new Dimension(99, 10), component1.getSize());
  }

  public void testBug2() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    Container container = createContainer(layout);
    container.setSize(10, 10);
    layout.layoutContainer(container);
  }

  public void testBug3() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    Container container = createContainer(layout, new Insets(4, 4, 4, 4));
    container.setSize(2, 2);
    layout.layoutContainer(container);
  }

  public void testBug4() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    Container container = createContainer(layout, new Insets(4, 4, 4, 4));
    container.setSize(2, 2);

    container.add(createComponent(new Dimension(1, 1)), GridDialogLayoutData.FILL_BOTH);
    layout.layoutContainer(container);
  }

  public void testBugComponentVisibilityIgnored() {
    GridDialogLayout layout = new GridDialogLayout(1, false, 0, 0);

    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));

    Container container = createContainer(layout);
    container.add(component1);
    container.add(component2);

    container.setSize(layout.preferredLayoutSize(container));
    layout.layoutContainer(container);

    assertEquals(new Dimension(10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10, 10), component1.getSize());
    assertEquals(new Point(0, 0), component1.getLocation());
    assertEquals(new Dimension(10, 10), component2.getSize());
    assertEquals(new Point(0, 10), component2.getLocation());

    component1.setVisible(false);

    container.setSize(layout.preferredLayoutSize(container));
    layout.layoutContainer(container);

    assertEquals(new Dimension(10, 10), layout.preferredLayoutSize(container));
    //Important: Size of invisible component not changed! Setting it to 0,0 might cause problems (e.g. disy GISterm display class)
    assertEquals(new Dimension(10, 10), component1.getSize());
    assertEquals(new Dimension(10, 10), component2.getSize());
    assertEquals(new Point(0, 0), component2.getLocation());
  }
}