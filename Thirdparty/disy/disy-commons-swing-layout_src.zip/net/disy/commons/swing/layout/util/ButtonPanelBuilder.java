package net.disy.commons.swing.layout.util;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

/**
 * @author Markus Gebhard
 */
public class ButtonPanelBuilder {

  private static final int MINIMUM_BUTTON_WIDTH = 70;
  private final List/*<Component>*/components = new ArrayList();
  private final LayoutDirection direction;

  public ButtonPanelBuilder() {
    this(LayoutDirection.HORIZONTAL);
  }

  public ButtonPanelBuilder(LayoutDirection direction) {
    this.direction = direction;
  }

  public void add(Component component) {
    components.add(component);
  }

  public void add(Action action) {
    components.add(new JButton(action));
  }

  public JPanel createPanel() {
    if (direction == LayoutDirection.HORIZONTAL) {
      return createHorizontalButtonPanel();
    }
    else {
      return createVerticalButtonPanel();
    }
  }

  private JPanel createVerticalButtonPanel() {
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setWidthHint(MINIMUM_BUTTON_WIDTH);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);

    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.setBorder(new EmptyBorder(LayoutUtilities.getDpiAdjusted(4), LayoutUtilities
        .getDpiAdjusted(8), LayoutUtilities.getDpiAdjusted(10), LayoutUtilities.getDpiAdjusted(4)));
    for (int i = 0; i < components.size(); i++) {
      panel.add((Component) components.get(i), layoutData);
    }
    return panel;
  }

  private JPanel createHorizontalButtonPanel() {
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setWidthHint(MINIMUM_BUTTON_WIDTH);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);

    JPanel panel = new JPanel(new GridDialogLayout(components.size() + 1, false));
    panel.setBorder(new EmptyBorder(LayoutUtilities.getDpiAdjusted(10), LayoutUtilities
        .getDpiAdjusted(20), LayoutUtilities.getDpiAdjusted(4), LayoutUtilities.getDpiAdjusted(4)));
    panel.add(Box.createGlue(), GridDialogLayoutData.FILL_HORIZONTAL);
    for (int i = 0; i < components.size(); i++) {
      panel.add((Component) components.get(i), layoutData);
    }
    return panel;
  }
}