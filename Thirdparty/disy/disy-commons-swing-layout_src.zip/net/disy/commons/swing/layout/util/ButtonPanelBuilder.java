/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.util;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Action;
import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

/**
 * @author Markus Gebhard
 */
public class ButtonPanelBuilder {

  private static final int MINIMUM_BUTTON_WIDTH = 70;
  private final List<Component> components = new ArrayList<Component>();
  private final LayoutDirection direction;

  public ButtonPanelBuilder() {
    this(LayoutDirection.HORIZONTAL);
  }

  public ButtonPanelBuilder(final LayoutDirection direction) {
    this.direction = direction;
  }

  public ButtonPanelBuilder add(final Component... newComponents) {
    for (final Component component : newComponents) {
      components.add(component);
    }
    return this;
  }

  public ButtonPanelBuilder add(final Action... actions) {
    for (final Action action : actions) {
      add(new JButton(action));
    }
    return this;
  }

  public JPanel createPanel() {
    if (direction == LayoutDirection.HORIZONTAL) {
      return createHorizontalButtonPanel();
    }
    return createVerticalButtonPanel();
  }

  private JPanel createVerticalButtonPanel() {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setWidthHint(MINIMUM_BUTTON_WIDTH);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);

    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.setBorder(new EmptyBorder(LayoutUtilities.getDpiAdjusted(4), LayoutUtilities
        .getDpiAdjusted(8), LayoutUtilities.getDpiAdjusted(10), LayoutUtilities.getDpiAdjusted(4)));
    for (int i = 0; i < components.size(); i++) {
      panel.add(components.get(i), layoutData);
    }
    return panel;
  }

  private JPanel createHorizontalButtonPanel() {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setWidthHint(MINIMUM_BUTTON_WIDTH);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);

    final JPanel panel = new JPanel(new GridDialogLayout(components.size() + 1, false));
    panel.setBorder(new EmptyBorder(LayoutUtilities.getDpiAdjusted(10), LayoutUtilities
        .getDpiAdjusted(20), LayoutUtilities.getDpiAdjusted(4), LayoutUtilities.getDpiAdjusted(4)));
    panel.add(Box.createGlue(), GridDialogLayoutData.FILL_HORIZONTAL);
    for (int i = 0; i < components.size(); i++) {
      panel.add(components.get(i), layoutData);
    }
    return panel;
  }
}