/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;
import java.util.HashMap;
import java.util.Map;

import net.disy.commons.swing.layout.util.GridCellSizeList;
import net.disy.commons.swing.layout.util.LayoutUtilities;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayout implements LayoutManager2 {

  private final Map<Component, IGridDialogLayoutData> constraints = new HashMap<Component, IGridDialogLayoutData>();
  private final int columnCount;
  /**
   * horizontalSpacing specifies the number of pixels between the right edge of one cell and the
   * left edge of its neighbouring cell to the right. The default value is
   * {@link LayoutUtilities#getComponentSpacing()}.
   */
  private int horizontalSpacing = LayoutUtilities.getComponentSpacing();

  /**
   * verticalSpacing specifies the number of pixels between the bottom edge of one cell and the top
   * edge of its neighbouring cell underneath. The default value is
   * {@link LayoutUtilities#getComponentSpacing()}.
   */
  private int verticalSpacing = LayoutUtilities.getComponentSpacing();

  private final boolean equalWidthColumns;
  private Grid grid;

  public GridDialogLayout(final int columnCount, final boolean equalWidthColumns) {
    if (columnCount < 1) {
      throw new IllegalArgumentException("ColumnCount must be >=1, was " + columnCount); //$NON-NLS-1$
    }
    this.columnCount = columnCount;
    this.equalWidthColumns = equalWidthColumns;
  }

  public GridDialogLayout(
      final int columnCount,
      final boolean equalWidthColumns,
      final int horizontalSpacing,
      final int verticalSpacing) {
    this(columnCount, equalWidthColumns);
    setHorizontalSpacing(horizontalSpacing);
    setVerticalSpacing(verticalSpacing);
  }

  public void setHorizontalSpacing(final int horizontalSpacing) {
    this.horizontalSpacing = horizontalSpacing;
  }

  public int getHorizontalSpacing() {
    return horizontalSpacing;
  }

  public void setVerticalSpacing(final int verticalSpacing) {
    this.verticalSpacing = verticalSpacing;
  }

  public int getVerticalSpacing() {
    return verticalSpacing;
  }

  @Override
  public float getLayoutAlignmentX(final Container target) {
    return 0.5f;
  }

  @Override
  public float getLayoutAlignmentY(final Container target) {
    return 0.5f;
  }

  @Override
  public void invalidateLayout(final Container target) {
    grid = null;
  }

  @Override
  public void addLayoutComponent(final Component comp, final Object constraint) {
    Object finalConstraint = constraint;
    if (finalConstraint == null) {
      finalConstraint = new GridDialogLayoutData();
    }
    else if (!(finalConstraint instanceof IGridDialogLayoutData)) {
      throw new IllegalArgumentException(
          "GridDialogLayout expectes layout constraints to be instance of IGridDialogLayoutData, was " + finalConstraint); //$NON-NLS-1$
    }
    constraints.put(comp, (IGridDialogLayoutData) finalConstraint);
  }

  @Override
  public void removeLayoutComponent(final Component comp) {
    constraints.remove(comp);
  }

  @Override
  public void layoutContainer(final Container parent) {
    synchronized (parent.getTreeLock()) {
      if (grid == null) {
        grid = createGrid(parent);
      }
      final Insets insets = parent.getInsets();

      adjustColumnWidths(parent.getWidth(), insets);
      adjustRowHeights(parent.getHeight(), insets);

      int x = insets.left;
      for (int i = 0; i < grid.getColumnCount(); ++i) {
        if (i > 0) {
          x += horizontalSpacing;
        }
        grid.getColumn(i).setStart(x);
        final int size = grid.getColumn(i).getSize();
        x += size;
      }

      int y = insets.top;
      for (int i = 0; i < grid.getRowCount(); ++i) {
        if (i > 0) {
          y += verticalSpacing;
        }
        grid.getRow(i).setStart(y);
        final int size = grid.getRow(i).getSize();
        y += size;
      }

      for (int i = 0; i < grid.getCellCount(); ++i) {
        final GridCell cell = grid.getCell(i);
        final int x0 = grid.getColumn(cell.getColumnIndex()).getStart();
        final int y0 = grid.getRow(cell.getRowIndex()).getStart();
        final int width = getActualSize(
            grid.getColumns(),
            cell.getColumnIndex(),
            cell.getColumnSpan(),
            horizontalSpacing);
        final int height = getActualSize(
            grid.getRows(),
            cell.getRowIndex(),
            cell.getRowSpan(),
            verticalSpacing);
        layoutCell(cell, new Rectangle(x0, y0, width, height));
      }
    }
  }

  private void adjustColumnWidths(final int availableWidth, final Insets insets) {
    if (equalWidthColumns) {
      adjustColumnWidthsForEqualWidthColumns(availableWidth, insets);
    }
    else {
      adjustColumnWidthsForNonEqualWidthColumns(availableWidth, insets);
    }
  }

  private void adjustColumnWidthsForNonEqualWidthColumns(
      final int availableWidth,
      final Insets insets) {
    grid.getColumns().adjustToPreferredSizes();

    int remainder = availableWidth - grid.getTotalPreferredWidth(horizontalSpacing, insets);
    if (remainder < 0) {
      //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!
      //Wir schrumpfen
      final GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
      //Wachsende Zellen? => erst die schrumpfen
      if (grabbingColumns.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingColumns.increaseSizes(remainder);
        //Reicht nicht? Dann alle Zellen schrumpfen
        remainder = availableWidth - grid.getTotalWidth(horizontalSpacing, insets);
        if (remainder < 0 && grid.getNonGrabbingColumnSizes().size() > 0) {
          grid.getNonGrabbingColumnSizes().increaseSizes(remainder);
        }
      }
      else {
        //Dann halt alle Zellen
        grid.getColumns().increaseSizes(remainder);
      }
    }
    else if (remainder > 0) {
      final GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
      if (grabbingColumns.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingColumns.increaseSizes(remainder);
      }
    }
  }

  private void adjustColumnWidthsForEqualWidthColumns(final int availableWidth, final Insets insets) {
    grid.makeColumnsEqualWidth();
    grid.getColumns().adjustToPreferredSizes();

    final int remainder = availableWidth - grid.getTotalPreferredWidth(horizontalSpacing, insets);
    if (remainder < 0) {
      //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!

      //Wir schrumpfen alle Zellen gleichmäßig
      grid.getColumns().increaseSizes(remainder);
    }
    else if (remainder > 0) {
      //Wachsen, falls mindestens eine Zelle wächst
      final GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
      if (grabbingColumns.size() > 0) {
        grid.getColumns().increaseSizes(remainder);
      }
    }
  }

  private void adjustRowHeights(final int availableHeight, final Insets insets) {
    final GridCellSizeList rows = grid.getRows();
    if (rows.size() == 0) {
      return;
    }
    rows.adjustToPreferredSizes();

    int verticalRemainder = availableHeight - grid.getTotalPreferredHeight(verticalSpacing, insets);
    if (verticalRemainder < 0) {
      //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!

      //Wir schrumpfen
      final GridCellSizeList grabbingRows = grid.getGrabbingRowSizes();
      //Wachsende Zellen? => erst die schrumpfen
      if (grabbingRows.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingRows.increaseSizes(verticalRemainder);
        //Reicht nicht? Dann alle Zellen schrumpfen
        verticalRemainder = availableHeight - grid.getTotalHeight(verticalSpacing, insets);
        if (verticalRemainder < 0 && grid.getNonGrabbingRowSizes().size() > 0) {
          grid.getNonGrabbingRowSizes().increaseSizes(verticalRemainder);
        }
      }
      else {
        //Dann halt alle Zellen
        rows.increaseSizes(verticalRemainder);
      }
    }
    else if (verticalRemainder > 0) {
      final GridCellSizeList grabbingRows = grid.getGrabbingRowSizes();
      if (grabbingRows.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingRows.increaseSizes(verticalRemainder);
      }
    }
  }

  private void layoutCell(final GridCell cell, final Rectangle rectangle) {
    if (!cell.getComponent().isVisible()) {
      return;
    }
    final int width;
    final int height;
    final int x;
    final int y;

    final Dimension preferredSize = cell.getPreferredComponentSize();
    final int preferredHeight = preferredSize.height;
    final int preferredWidth = preferredSize.width;

    final IGridDialogLayoutData layoutData = cell.getLayoutData();
    if (layoutData.getHorizontalIndent() < rectangle.width) {
      rectangle.x += layoutData.getHorizontalIndent();
      rectangle.width -= layoutData.getHorizontalIndent();
    }

    if (layoutData.getHorizontalAlignment() == GridAlignment.BEGINNING) {
      x = rectangle.x;
      width = min(preferredWidth, rectangle.width);
    }
    else if (layoutData.getHorizontalAlignment() == GridAlignment.CENTER) {
      width = min(preferredWidth, rectangle.width);
      x = rectangle.x + (rectangle.width - width) / 2;
    }
    else if (layoutData.getHorizontalAlignment() == GridAlignment.END) {
      width = min(preferredWidth, rectangle.width);
      x = rectangle.x + rectangle.width - width;
    }
    else {
      width = rectangle.width;
      x = rectangle.x;
    }

    if (layoutData.getVerticalAlignment() == GridAlignment.BEGINNING) {
      y = rectangle.y;
      height = min(preferredHeight, rectangle.height);
    }
    else if (layoutData.getVerticalAlignment() == GridAlignment.CENTER) {
      height = min(preferredHeight, rectangle.height);
      y = rectangle.y + (rectangle.height - height) / 2;
    }
    else if (layoutData.getVerticalAlignment() == GridAlignment.END) {
      height = min(preferredHeight, rectangle.height);
      y = rectangle.y + rectangle.height - height;
    }
    else {
      height = rectangle.height;
      y = rectangle.y;
    }

    cell.getComponent().setBounds(x, y, width, height);
  }

  private int min(final int a, final int b) {
    return a < b ? a : b;
  }

  private static int getActualSize(
      final GridCellSizeList sizes,
      final int startIndex,
      final int span,
      final int spacing) {
    int size = 0;
    for (int i = startIndex; i < startIndex + span; i++) {
      size += sizes.get(i).getSize();
    }
    return size + (span - 1) * spacing;
  }

  @Override
  public void addLayoutComponent(final String name, final Component comp) {
    throw new UnsupportedOperationException();
  }

  @Override
  public Dimension minimumLayoutSize(final Container parent) {
    return getLayoutSize(parent, true);
  }

  @Override
  public Dimension preferredLayoutSize(final Container parent) {
    return getLayoutSize(parent, false);
  }

  @Override
  public Dimension maximumLayoutSize(final Container target) {
    return new Dimension(Short.MAX_VALUE, Short.MAX_VALUE);
  }

  private Dimension getLayoutSize(final Container parent, final boolean minimumSize) {
    synchronized (parent.getTreeLock()) {
      if (grid == null) {
        grid = createGrid(parent);
      }
      final Insets insets = parent.getInsets();
      final int totalWidth = minimumSize
          ? grid.getTotalMinimumWidth(horizontalSpacing, insets)
          : grid.getTotalPreferredWidth(horizontalSpacing, insets);
      final int totalHeight = minimumSize
          ? grid.getTotalMinimumHeight(verticalSpacing, insets)
          : grid.getTotalPreferredHeight(verticalSpacing, insets);

      return new Dimension(totalWidth, totalHeight);
    }
  }

  private Grid createGrid(final Container parent) {
    final GridBuilder builder = new GridBuilder(columnCount);
    for (int i = 0; i < parent.getComponentCount(); i++) {
      final Component component = parent.getComponent(i);
      final IGridDialogLayoutData layoutData = constraints.get(component);
      builder.add(component, layoutData);
    }
    final Grid myGrid = builder.createGrid(horizontalSpacing, verticalSpacing);
    if (equalWidthColumns) {
      myGrid.makeColumnsEqualWidth();
    }
    return myGrid;
  }
}