package net.disy.commons.swing.layout.grid;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;
import java.awt.Rectangle;
import java.util.HashMap;
import java.util.Map;

import net.disy.commons.swing.layout.util.GridCellSizeList;
import net.disy.commons.swing.layout.util.LayoutUtilities;

/**
 * @author Markus Gebhard
 */
public class GridDialogLayout implements LayoutManager2 {

  private Map/*<Component, GridLayoutData>*/constraints = new HashMap();
  private final int columnCount;
  /**
   * horizontalSpacing specifies the number of pixels between the right
   * edge of one cell and the left edge of its neighbouring cell to
   * the right.
   *
   * The default value is {@link LayoutUtilities#getComponentSpacing()}.
   */
  private int horizontalSpacing = LayoutUtilities.getComponentSpacing();

  /**
   * verticalSpacing specifies the number of pixels between the bottom
   * edge of one cell and the top edge of its neighbouring cell underneath.
   *
   * The default value is {@link LayoutUtilities#getComponentSpacing()}.
   */
  private int verticalSpacing = LayoutUtilities.getComponentSpacing();

  private final boolean equalWidthColumns;
  private Grid grid;

  public GridDialogLayout(int columnCount, boolean equalWidthColumns) {
    if (columnCount < 1) {
      throw new IllegalArgumentException("ColumnCount must be >=1, was " + columnCount); //$NON-NLS-1$
    }
    this.columnCount = columnCount;
    this.equalWidthColumns = equalWidthColumns;
  }

  public GridDialogLayout(
      int columnCount,
      boolean equalWidthColumns,
      int horizontalSpacing,
      int verticalSpacing) {
    this(columnCount, equalWidthColumns);
    setHorizontalSpacing(horizontalSpacing);
    setVerticalSpacing(verticalSpacing);
  }

  public void setHorizontalSpacing(int horizontalSpacing) {
    this.horizontalSpacing = horizontalSpacing;
  }

  public int getHorizontalSpacing() {
    return horizontalSpacing;
  }

  public void setVerticalSpacing(int verticalSpacing) {
    this.verticalSpacing = verticalSpacing;
  }

  public int getVerticalSpacing() {
    return verticalSpacing;
  }

  public float getLayoutAlignmentX(Container target) {
    return 0.5f;
  }

  public float getLayoutAlignmentY(Container target) {
    return 0.5f;
  }

  public void invalidateLayout(Container target) {
    grid = null;
  }

  public void addLayoutComponent(Component comp, Object constraint) {
    if (constraint == null) {
      constraint = new GridDialogLayoutData();
    }
    else if (!(constraint instanceof IGridDialogLayoutData)) {
      throw new IllegalArgumentException(
          "GridDialogLayout expectes layout constraints to be instance of IGridDialogLayoutData, was " + constraint); //$NON-NLS-1$
    }
    constraints.put(comp, constraint);
  }

  public void removeLayoutComponent(Component comp) {
    constraints.remove(comp);
  }

  public void layoutContainer(Container parent) {
    synchronized (parent.getTreeLock()) {
      if (grid == null) {
        grid = createGrid(parent);
      }
      Insets insets = parent.getInsets();

      adjustColumnWidths(parent.getWidth(), insets);
      adjustRowHeights(parent.getHeight(), insets);

      int x = insets.left;
      for (int i = 0; i < grid.getColumnCount(); ++i) {
        if (i > 0) {
          x += horizontalSpacing;
        }
        grid.getColumn(i).setStart(x);
        int size = grid.getColumn(i).getSize();
        x += size;
      }

      int y = insets.top;
      for (int i = 0; i < grid.getRowCount(); ++i) {
        if (i > 0) {
          y += verticalSpacing;
        }
        grid.getRow(i).setStart(y);
        int size = grid.getRow(i).getSize();
        y += size;
      }

      for (int i = 0; i < grid.getCellCount(); ++i) {
        GridCell cell = grid.getCell(i);
        int x0 = grid.getColumn(cell.getColumnIndex()).getStart();
        int y0 = grid.getRow(cell.getRowIndex()).getStart();
        int width = getActualSize(
            grid.getColumns(),
            cell.getColumnIndex(),
            cell.getColumnSpan(),
            horizontalSpacing);
        int height = getActualSize(
            grid.getRows(),
            cell.getRowIndex(),
            cell.getRowSpan(),
            verticalSpacing);
        layoutCell(cell, new Rectangle(x0, y0, width, height));
      }
    }
  }

  private void adjustColumnWidths(int availableWidth, Insets insets) {
    if (grid.getColumns().size() == 0) {
      return;
    }

    if (equalWidthColumns) {
      grid.makeColumnsEqualWidth();
      grid.getColumns().adjustToPreferredSizes();

      int remainder = availableWidth - grid.getTotalPreferredWidth(horizontalSpacing, insets);
      if (remainder < 0) {
        //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!

        //Wir schrumpfen alle Zellen gleichm��ig
        grid.getColumns().increaseSizes(remainder);
      }
      else if (remainder > 0) {
        //Wachsen, falls mindestens eine Zelle w�chst
        GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
        if (grabbingColumns.size() > 0) {
          grid.getColumns().increaseSizes(remainder);
        }
      }
    }
    else {
      grid.getColumns().adjustToPreferredSizes();

      int remainder = availableWidth - grid.getTotalPreferredWidth(horizontalSpacing, insets);
      if (remainder < 0) {
        //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!
        //Wir schrumpfen
        GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
        //Wachsende Zellen? => erst die schrumpfen
        if (grabbingColumns.size() > 0) {
          //Nur die als wachsend angegebenen Zellen wachsen lassen
          grabbingColumns.increaseSizes(remainder);
          //Reicht nicht? Dann alle Zellen schrumpfen
          remainder = availableWidth - grid.getTotalWidth(horizontalSpacing, insets);
          if (remainder < 0 && grid.getNonGrabbingColumnSizes().size() > 0) {
            grid.getNonGrabbingColumnSizes().increaseSizes(remainder);
          }
        }
        else {
          //Dann halt alle Zellen
          grid.getColumns().increaseSizes(remainder);
        }
      }
      else if (remainder > 0) {
        GridCellSizeList grabbingColumns = grid.getGrabbingColumnSizes();
        if (grabbingColumns.size() > 0) {
          //Nur die als wachsend angegebenen Zellen wachsen lassen
          grabbingColumns.increaseSizes(remainder);
        }
      }
    }
  }

  private void adjustRowHeights(int availableHeight, Insets insets) {
    GridCellSizeList rows = grid.getRows();
    if (rows.size() == 0) {
      return;
    }
    rows.adjustToPreferredSizes();

    int verticalRemainder = availableHeight - grid.getTotalPreferredHeight(verticalSpacing, insets);
    if (verticalRemainder < 0) {
      //TODO Oct 23, 2004 (Markus Gebhard): Retry with minimumSize!

      //Wir schrumpfen
      GridCellSizeList grabbingRows = grid.getGrabbingRowSizes();
      //Wachsende Zellen? => erst die schrumpfen
      if (grabbingRows.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingRows.increaseSizes(verticalRemainder);
        //Reicht nicht? Dann alle Zellen schrumpfen
        verticalRemainder = availableHeight - grid.getTotalHeight(verticalSpacing, insets);
        if (verticalRemainder < 0 && grid.getNonGrabbingRowSizes().size() > 0) {
          grid.getNonGrabbingRowSizes().increaseSizes(verticalRemainder);
        }
      }
      else {
        //Dann halt alle Zellen
        rows.increaseSizes(verticalRemainder);
      }
    }
    else if (verticalRemainder > 0) {
      GridCellSizeList grabbingRows = grid.getGrabbingRowSizes();
      if (grabbingRows.size() > 0) {
        //Nur die als wachsend angegebenen Zellen wachsen lassen
        grabbingRows.increaseSizes(verticalRemainder);
      }
    }
  }

  private void layoutCell(GridCell cell, Rectangle rectangle) {
    if (!cell.getComponent().isVisible()) {
      return;
    }
    final int width;
    final int height;
    final int x;
    final int y;

    Dimension preferredSize = cell.getPreferredComponentSize();
    int preferredHeight = preferredSize.height;
    int preferredWidth = preferredSize.width;

    IGridDialogLayoutData layoutData = cell.getLayoutData();
    if (layoutData.getHorizontalIndent() < rectangle.width) {
      rectangle.x += layoutData.getHorizontalIndent();
      rectangle.width -= layoutData.getHorizontalIndent();
    }

    if (layoutData.getHorizontalAlignment() == GridAlignment.BEGINNING) {
      x = rectangle.x;
      width = min(preferredWidth, rectangle.width);
    }
    else if (layoutData.getHorizontalAlignment() == GridAlignment.CENTER) {
      width = min(preferredWidth, rectangle.width);
      x = rectangle.x + (rectangle.width - width) / 2;
    }
    else if (layoutData.getHorizontalAlignment() == GridAlignment.END) {
      width = min(preferredWidth, rectangle.width);
      x = rectangle.x + rectangle.width - width;
    }
    else {
      width = rectangle.width;
      x = rectangle.x;
    }

    if (layoutData.getVerticalAlignment() == GridAlignment.BEGINNING) {
      y = rectangle.y;
      height = min(preferredHeight, rectangle.height);
    }
    else if (layoutData.getVerticalAlignment() == GridAlignment.CENTER) {
      height = min(preferredHeight, rectangle.height);
      y = rectangle.y + (rectangle.height - height) / 2;
    }
    else if (layoutData.getVerticalAlignment() == GridAlignment.END) {
      height = min(preferredHeight, rectangle.height);
      y = rectangle.y + rectangle.height - height;
    }
    else {
      height = rectangle.height;
      y = rectangle.y;
    }

    cell.getComponent().setBounds(x, y, width, height);
  }

  private int min(int a, int b) {
    return a < b ? a : b;
  }

  private static int getActualSize(GridCellSizeList sizes, int startIndex, int span, int spacing) {
    int size = 0;
    for (int i = startIndex; i < startIndex + span; i++) {
      size += sizes.get(i).getSize();
    }
    return size + (span - 1) * spacing;
  }

  public void addLayoutComponent(String name, Component comp) {
    throw new UnsupportedOperationException();
  }

  public Dimension minimumLayoutSize(Container parent) {
    return getLayoutSize(parent, true);
  }

  public Dimension preferredLayoutSize(Container parent) {
    return getLayoutSize(parent, false);
  }

  public Dimension maximumLayoutSize(Container target) {
    return new Dimension(Short.MAX_VALUE, Short.MAX_VALUE);
  }

  private Dimension getLayoutSize(Container parent, boolean minimumSize) {
    synchronized (parent.getTreeLock()) {
      if (grid == null) {
        grid = createGrid(parent);
      }
      Insets insets = parent.getInsets();
      int totalWidth = minimumSize ? grid.getTotalMinimumWidth(horizontalSpacing, insets) : grid
          .getTotalPreferredWidth(horizontalSpacing, insets);
      int totalHeight = minimumSize ? grid.getTotalMinimumHeight(verticalSpacing, insets) : grid
          .getTotalPreferredHeight(verticalSpacing, insets);

      return new Dimension(totalWidth, totalHeight);
    }
  }

  private Grid createGrid(Container parent) {
    GridBuilder builder = new GridBuilder(columnCount);
    for (int i = 0; i < parent.getComponentCount(); i++) {
      Component component = parent.getComponent(i);
      IGridDialogLayoutData layoutData = (IGridDialogLayoutData) constraints.get(component);
      builder.add(component, layoutData);
    }
    Grid myGrid = builder.createGrid(horizontalSpacing, verticalSpacing);
    if (equalWidthColumns) {
      myGrid.makeColumnsEqualWidth();
    }
    return myGrid;
  }
}