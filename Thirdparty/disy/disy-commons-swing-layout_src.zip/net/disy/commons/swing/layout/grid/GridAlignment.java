/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

/**
 * Alignment constants.
 * @author Markus Gebhard
 */
public class GridAlignment {

  public static final GridAlignment BEGINNING = new GridAlignment("beginning"); //$NON-NLS-1$
  public static final GridAlignment CENTER = new GridAlignment("center"); //$NON-NLS-1$
  public static final GridAlignment END = new GridAlignment("end"); //$NON-NLS-1$
  public static final GridAlignment FILL = new GridAlignment("fill"); //$NON-NLS-1$

  private final String name;

  private GridAlignment(String name) {
    this.name = name;
  }

  @Override
  public String toString() {
    return "GridAlignment{" + name + "}"; //$NON-NLS-1$//$NON-NLS-2$
  }
}