package net.disy.commons.swing.layout.grid;

/**
 * Alignment constants.
 * @author Markus Gebhard
 */
public class GridAlignment {

  public static final GridAlignment BEGINNING = new GridAlignment("beginning"); //$NON-NLS-1$
  public static final GridAlignment CENTER = new GridAlignment("center"); //$NON-NLS-1$
  public static final GridAlignment END = new GridAlignment("end"); //$NON-NLS-1$
  public static final GridAlignment FILL = new GridAlignment("fill"); //$NON-NLS-1$

  private final String name;

  private GridAlignment(String name) {
    this.name = name;
  }

  public String toString() {
    return "GridAlignment{" + name + "}";  //$NON-NLS-1$//$NON-NLS-2$
  }
}