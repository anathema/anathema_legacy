package net.disy.commons.swing.layout.grid;

import java.awt.Component;
import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.layout.util.GridCellSizeList;


/**
 * @author Markus Gebhard
 */
public class GridBuilder {

  private int columnIndex = 0;
  private int rowIndex = 0;

  private final GridCoverage gridCoverage;
  private final List/* <GridCell> */gridCells = new ArrayList();
  private final int columnCount;

  public GridBuilder(int columnCount) {
    this.columnCount = columnCount;
    this.gridCoverage = new GridCoverage(columnCount);
  }

  public void add(Component component, IGridDialogLayoutData layoutData) {
    if (component instanceof EndOfLineMarkerComponent) {
      if (columnIndex != 0) {
        columnIndex = 0;
        ++rowIndex;
      }
      return;
    }
    while (gridCoverage.isCovered(columnIndex, rowIndex)) {
      gotoNextCell(1);
    }
    if (columnIndex + layoutData.getHorizontalSpan() > columnCount) {
      throw new IllegalArgumentException("Illegal horizontal span " //$NON-NLS-1$
          + layoutData.getHorizontalSpan() + " in GridLayoutData for component at column " //$NON-NLS-1$
          + columnIndex + " in " //$NON-NLS-1$
          + columnCount + " columns GridDialogLayout."); //$NON-NLS-1$
    }
    GridCell gridCell = new GridCell(component, layoutData, columnIndex, rowIndex);
    gridCells.add(gridCell);
    gridCoverage.add(gridCell);
    gotoNextCell(layoutData.getHorizontalSpan());
  }

  private void gotoNextCell(int count) {
    columnIndex += count;
    if (columnIndex >= columnCount) {
      columnIndex = 0;
      ++rowIndex;
    }
  }

  public Grid createGrid(int horizontalSpacing, int verticalSpacing) {
    int rowCount = 0;
    for (int i = 0; i < gridCells.size(); i++) {
      GridCell cell = (GridCell) gridCells.get(i);
      int maxRowIndex = cell.getRowIndex() + cell.getRowSpan() - 1;
      if (maxRowIndex + 1 > rowCount) {
        rowCount = maxRowIndex + 1;
      }
    }

    GridCellSizeList rowSizes = new GridCellSizeList(rowCount);
    GridCellSizeList columnSizes = new GridCellSizeList(columnCount);
    Grid grid = new Grid(rowSizes, columnSizes, (GridCell[]) gridCells.toArray(new GridCell[gridCells.size()]));

    initializeExcessFlags(rowSizes, columnSizes);

    // Use single row/column components to find initial size for rows/columns
    for (int i = 0; i < gridCells.size(); i++) {
      GridCell cell = (GridCell) gridCells.get(i);
      if (cell.getColumnSpan() == 1) {
        int minimumWidth = cell.getMinimumSize().width;
        columnSizes.get(cell.getColumnIndex()).guaranteeMinimumSize(minimumWidth);
        int preferredWidth = cell.getPreferredSize().width;
        columnSizes.get(cell.getColumnIndex()).guaranteePreferredSize(preferredWidth);
      }
      if (cell.getRowSpan() == 1) {
        int minimumHeight = cell.getMinimumSize().height;
        rowSizes.get(cell.getRowIndex()).guaranteeMinimumSize(minimumHeight);
        int preferredHeight = cell.getPreferredSize().height;
        rowSizes.get(cell.getRowIndex()).guaranteePreferredSize(preferredHeight);
      }
    }

    // Use multi row/column components to guarantee combined size of rows/columns
    for (int i = 0; i < gridCells.size(); i++) {
      GridCell cell = (GridCell) gridCells.get(i);
      if (cell.getColumnSpan() > 1) {
        int availableMinimumWidth = columnSizes.getAvailableMinimumSize(cell.getColumnIndex(), cell
            .getColumnSpan(), horizontalSpacing);
        if (cell.getMinimumSize().width > availableMinimumWidth) {
          GridCellSizeList grabbingColumnSizes = grid.getGrabbingColumnSizes(cell.getColumnIndex(), cell
              .getColumnSpan());
          if (grabbingColumnSizes.size() > 0) {
            grabbingColumnSizes.increaseMinimumSizes(0, grabbingColumnSizes.size(), cell.getMinimumSize().width
                - availableMinimumWidth);
          }
          else {
            columnSizes.increaseMinimumSizes(
                cell.getColumnIndex(),
                cell.getColumnSpan(),
                cell.getMinimumSize().width - availableMinimumWidth);
          }
        }
        int availablePreferredWidth = columnSizes.getAvailablePreferredSize(cell.getColumnIndex(), cell
            .getColumnSpan(), horizontalSpacing);
        if (cell.getPreferredSize().width > availablePreferredWidth) {
          GridCellSizeList grabbingColumnSizes = grid.getGrabbingColumnSizes(cell.getColumnIndex(), cell
              .getColumnSpan());
          if (grabbingColumnSizes.size() > 0) {
            grabbingColumnSizes.increasePreferredSizes(
                0,
                grabbingColumnSizes.size(),
                cell.getPreferredSize().width - availablePreferredWidth);
          }
          else {
            columnSizes.increasePreferredSizes(cell.getColumnIndex(), cell.getColumnSpan(), cell
                .getPreferredSize().width
                - availablePreferredWidth);
          }
        }
      }
      if (cell.getRowSpan() > 1) {
        int availableMinimumHeight = rowSizes.getAvailableMinimumSize(
            cell.getRowIndex(),
            cell.getRowSpan(),
            verticalSpacing);
        if (cell.getMinimumSize().height > availableMinimumHeight) {
          GridCellSizeList grabbingRowSizes = grid.getGrabbingRowSizes(cell.getRowIndex(), cell.getRowSpan());
          if (grabbingRowSizes.size() > 0) {
            grabbingRowSizes.increaseMinimumSizes(0, grabbingRowSizes.size(), cell.getMinimumSize().height
                - availableMinimumHeight);
          }
          else {
            rowSizes.increaseMinimumSizes(cell.getRowIndex(), cell.getRowSpan(), cell.getMinimumSize().height
                - availableMinimumHeight);
          }
        }
        int availablePreferredHeight = rowSizes.getAvailablePreferredSize(
            cell.getRowIndex(),
            cell.getRowSpan(),
            verticalSpacing);
        if (cell.getPreferredSize().height > availablePreferredHeight) {
          GridCellSizeList grabbingRowSizes = grid.getGrabbingRowSizes(cell.getRowIndex(), cell.getRowSpan());
          if (grabbingRowSizes.size() > 0) {
            grabbingRowSizes.increasePreferredSizes(0, grabbingRowSizes.size(), cell.getPreferredSize().height
                - availablePreferredHeight);
          }
          else {
            rowSizes.increasePreferredSizes(cell.getRowIndex(), cell.getRowSpan(), cell.getPreferredSize().height
                - availablePreferredHeight);
          }
        }
      }
    }

    return grid;
  }

  private void initializeExcessFlags(GridCellSizeList rowSizes, GridCellSizeList columnSizes) {
    for (int i = 0; i < gridCells.size(); i++) {
      GridCell cell = (GridCell) gridCells.get(i);
      if (cell.getLayoutData().isGrabExcessHorizontalSpace()) {
        columnSizes.get(cell.getColumnIndex() + cell.getColumnSpan() - 1).setGrabExcessSpace(true);
      }
      if (cell.getLayoutData().isGrabExcessVerticalSpace()) {
        rowSizes.get(cell.getRowIndex() + cell.getRowSpan() - 1).setGrabExcessSpace(true);
      }
    }
  }
}