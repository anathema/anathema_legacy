package net.disy.commons.swing.layout.util.test;

import junit.framework.Test;
import junit.framework.TestCase;

import net.disy.commons.swing.layout.util.GridCellSize;
import net.disy.commons.swing.layout.util.GridCellSizeList;

import org.hansel.CoverageDecorator;

/**
 * @author Markus Gebhard
 */
public class GridCellSizeListTest extends TestCase {

  public static Test suite() {
    return new CoverageDecorator(GridCellSizeListTest.class, new Class[]{ GridCellSizeList.class });
  }

  public void testCreateBySize() {
    GridCellSizeList list = new GridCellSizeList(2);
    assertEquals(2, list.size());
    assertNotNull(list.get(0));
    assertNotNull(list.get(1));
  }

  public void testCreateByEntries() {
    GridCellSize size1 = new GridCellSize();
    GridCellSize size2 = new GridCellSize();
    GridCellSizeList list = new GridCellSizeList(new GridCellSize[]{ size1, size2 });
    assertEquals(2, list.size());
    assertSame(size1, list.get(0));
    assertSame(size2, list.get(1));
  }

  public void testIllegalSpanForIncreaseMinimumSizes() {
    try {
      new GridCellSizeList(1).increaseMinimumSizes(0, 0, 1);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testIllegalSpanForIncreasePreferredSizes() {
    try {
      new GridCellSizeList(1).increasePreferredSizes(0, 0, 1);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testIllegalSpanForIncreaseSizes() {
    try {
      new GridCellSizeList(1).increaseSizes(0, 0, 1);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testIncreaseSizesWithOneGridSizeObject() {
    GridCellSizeList sizes = new GridCellSizeList(1);
    sizes.get(0).setPreferredSize(5);
    sizes.adjustToPreferredSizes();
    sizes.increaseSizes(10);
    assertEquals(5 + 10, sizes.get(0).getSize());
  }

  public void testIncreaseSizesWithUnevenDistribution() {
    GridCellSizeList sizes = new GridCellSizeList(2);
    sizes.get(0).setPreferredSize(0);
    sizes.get(1).setPreferredSize(0);

    sizes.adjustToPreferredSizes();
    sizes.increaseSizes(3);

    assertEquals(1, sizes.get(0).getSize());
    assertEquals(2, sizes.get(1).getSize());
  }

  public void testIncreaseSizesWithMultiplyUnevenDistribution() {
    GridCellSizeList sizes = new GridCellSizeList(3);
    sizes.get(0).setPreferredSize(0);
    sizes.get(1).setPreferredSize(0);
    sizes.get(2).setPreferredSize(0);

    sizes.adjustToPreferredSizes();
    sizes.increaseSizes(2);

    assertEquals(0, sizes.get(0).getSize());
    assertEquals(1, sizes.get(1).getSize());
    assertEquals(1, sizes.get(2).getSize());
  }

    public void testIncreaseMinimumSizesWithOneGridSizeObject() {
      GridCellSizeList sizes = new GridCellSizeList(1);
      sizes.get(0).setMinimumSize(5);
      sizes.increaseMinimumSizes(0, sizes.size(), 10);
      assertEquals(5 + 10, sizes.get(0).getMinimumSize());
    }
  
    public void testIncreaseMinimumSizesWithUnevenDistribution() {
      GridCellSizeList sizes = new GridCellSizeList(2);
      sizes.get(0).setMinimumSize(0);
      sizes.get(1).setMinimumSize(0);
  
      sizes.increaseMinimumSizes(0, sizes.size(), 3);
  
      assertEquals(1, sizes.get(0).getMinimumSize());
      assertEquals(2, sizes.get(1).getMinimumSize());
    }
  
    public void testIncreaseMinimumSizesWithMultiplyUnevenDistribution() {
      GridCellSizeList sizes = new GridCellSizeList(3);
      sizes.get(0).setMinimumSize(0);
      sizes.get(1).setMinimumSize(0);
      sizes.get(2).setMinimumSize(0);
  
      sizes.increaseMinimumSizes(0, sizes.size(), 2);
  
      assertEquals(0, sizes.get(0).getMinimumSize());
      assertEquals(1, sizes.get(1).getMinimumSize());
      assertEquals(1, sizes.get(2).getMinimumSize());
    }

    public void testIncreasePreferredSizesWithOneGridSizeObject() {
      GridCellSizeList sizes = new GridCellSizeList(1);
      sizes.get(0).setPreferredSize(5);
  
      sizes.increasePreferredSizes(0, sizes.size(), 10);
  
      assertEquals(5 + 10, sizes.get(0).getPreferredSize());
    }
  
    public void testIncreasePreferredSizesWithUnevenDistribution() {
      GridCellSizeList sizes = new GridCellSizeList(2);
      sizes.get(0).setPreferredSize(0);
      sizes.get(1).setPreferredSize(0);
  
      sizes.increasePreferredSizes(0, sizes.size(), 3);
  
      assertEquals(1, sizes.get(0).getPreferredSize());
      assertEquals(2, sizes.get(1).getPreferredSize());
    }
  
    public void testIncreasePreferredSizesWithMultiplyUnevenDistribution() {
      GridCellSizeList sizes = new GridCellSizeList(3);
      sizes.get(0).setPreferredSize(0);
      sizes.get(1).setPreferredSize(0);
      sizes.get(2).setPreferredSize(0);
  
      sizes.increasePreferredSizes(0, sizes.size(), 2);
  
      assertEquals(0, sizes.get(0).getPreferredSize());
      assertEquals(1, sizes.get(1).getPreferredSize());
      assertEquals(1, sizes.get(2).getPreferredSize());
    }

  public void testIllegalSpanForGetAvailableMinimumSizes() {
    try {
      new GridCellSizeList(1).getAvailableMinimumSize(0, -1, 4);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testGetAvailableMinimumSize() {
    GridCellSizeList sizes = new GridCellSizeList(2);
    sizes.get(0).setMinimumSize(1);
    sizes.get(1).setMinimumSize(2);

    assertEquals(7, sizes.getAvailableMinimumSize(0, 2, 4));
    assertEquals(1, sizes.getAvailableMinimumSize(0, 1, 4));
    assertEquals(2, sizes.getAvailableMinimumSize(1, 1, 4));
  }

  public void testIllegalSpanForGetAvailablePreferredSizes() {
    try {
      new GridCellSizeList(1).getAvailablePreferredSize(0, -1, 4);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testGetAvailablePreferredSize() {
    GridCellSizeList sizes = new GridCellSizeList(2);
    sizes.get(0).setPreferredSize(1);
    sizes.get(1).setPreferredSize(2);

    assertEquals(7, sizes.getAvailablePreferredSize(0, 2, 4));
    assertEquals(1, sizes.getAvailablePreferredSize(0, 1, 4));
    assertEquals(2, sizes.getAvailablePreferredSize(1, 1, 4));
  }
}