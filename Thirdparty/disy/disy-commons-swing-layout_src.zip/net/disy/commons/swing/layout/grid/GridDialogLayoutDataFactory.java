/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

public class GridDialogLayoutDataFactory {

  public static GridDialogLayoutData createHorizontalSpanData(
      final int columnCount,
      final IGridDialogLayoutData prototype) {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData(prototype);
    layoutData.setHorizontalSpan(columnCount);
    return layoutData;
  }

  public static GridDialogLayoutData createHorizontalSpanData(final int columnCount) {
    return createHorizontalSpanData(columnCount, new GridDialogLayoutData());
  }

  public static GridDialogLayoutData createHorizontalFillNoGrab() {
    final GridDialogLayoutData horizontalFillNoGrab = new GridDialogLayoutData();
    horizontalFillNoGrab.setHorizontalAlignment(GridAlignment.FILL);
    return horizontalFillNoGrab;
  }

  public static GridDialogLayoutData createHorizontalGrabNoFill() {
    final GridDialogLayoutData horizontalFillNoGrab = new GridDialogLayoutData();
    horizontalFillNoGrab.setGrabExcessHorizontalSpace(true);
    return horizontalFillNoGrab;
  }

  public static GridDialogLayoutData createFillNoGrab() {
    final GridDialogLayoutData fillNoGrab = new GridDialogLayoutData();
    fillNoGrab.setHorizontalAlignment(GridAlignment.FILL);
    fillNoGrab.setVerticalAlignment(GridAlignment.FILL);
    return fillNoGrab;
  }

  public static GridDialogLayoutData createTopData() {
    return createTopData(new GridDialogLayoutData());
  }

  public static GridDialogLayoutData createTopData(final IGridDialogLayoutData prototyp) {
    final GridDialogLayoutData topData = new GridDialogLayoutData(prototyp);
    topData.setVerticalAlignment(GridAlignment.BEGINNING);
    return topData;
  }

  public static GridDialogLayoutData createRightData() {
    final GridDialogLayoutData data = new GridDialogLayoutData();
    data.setHorizontalAlignment(GridAlignment.END);
    return data;
  }
}