package net.disy.commons.swing.layout.util;

/**
 * @author Markus Gebhard
 */
public class LayoutDirection {

  public final static LayoutDirection VERTICAL = new LayoutDirection("vertical"); //$NON-NLS-1$
  public final static LayoutDirection HORIZONTAL = new LayoutDirection("horizontal"); //$NON-NLS-1$

  private final String name;

  private LayoutDirection(String name) {
    this.name = name;
  }

  public String toString() {
    return name;
  }
}