package net.disy.commons.swing.layout.grid;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Markus Gebhard
 */
public class GridCoverage {

  private List/*<boolean[]>*/coverageRows = new ArrayList();
  private final int columnCount;

  public GridCoverage(int columnCount) {
    this.columnCount = columnCount;
  }

  public void add(GridCell gridCell) {
    for (int columnIndex = gridCell.getColumnIndex(); columnIndex < gridCell.getColumnIndex()
        + gridCell.getColumnSpan(); ++columnIndex) {
      for (int rowIndex = gridCell.getRowIndex(); rowIndex < gridCell.getRowIndex() + gridCell.getRowSpan(); ++rowIndex) {
        setCovered(columnIndex, rowIndex);
      }
    }
  }

  private void setCovered(int columnIndex, int rowIndex) {
    getRow(rowIndex)[columnIndex] = true;
  }

  private boolean[] getRow(int rowIndex) {
    while (coverageRows.size() < rowIndex + 1) {
      coverageRows.add(new boolean[columnCount]);
    }
    return (boolean[]) coverageRows.get(rowIndex);
  }

  public boolean isCovered(int columnIndex, int rowIndex) {
    return getRow(rowIndex)[columnIndex];
  }

}