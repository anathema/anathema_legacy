/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Markus Gebhard
 */
public class GridCoverage {

  private List<boolean[]> coverageRows = new ArrayList<boolean[]>();
  private final int columnCount;

  public GridCoverage(int columnCount) {
    this.columnCount = columnCount;
  }

  public void add(GridCell gridCell) {
    for (int columnIndex = gridCell.getColumnIndex(); columnIndex < gridCell.getColumnIndex()
        + gridCell.getColumnSpan(); ++columnIndex) {
      for (int rowIndex = gridCell.getRowIndex(); rowIndex < gridCell.getRowIndex()
          + gridCell.getRowSpan(); ++rowIndex) {
        setCovered(columnIndex, rowIndex);
      }
    }
  }

  private void setCovered(int columnIndex, int rowIndex) {
    getRow(rowIndex)[columnIndex] = true;
  }

  private boolean[] getRow(int rowIndex) {
    while (coverageRows.size() < rowIndex + 1) {
      coverageRows.add(new boolean[columnCount]);
    }
    return coverageRows.get(rowIndex);
  }

  public boolean isCovered(int columnIndex, int rowIndex) {
    return getRow(rowIndex)[columnIndex];
  }

}