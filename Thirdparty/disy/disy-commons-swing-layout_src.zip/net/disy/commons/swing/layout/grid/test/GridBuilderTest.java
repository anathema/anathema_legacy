package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Dimension;

import junit.framework.Test;

import net.disy.commons.swing.layout.grid.EndOfLineMarkerComponent;
import net.disy.commons.swing.layout.grid.Grid;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridBuilder;
import net.disy.commons.swing.layout.grid.GridCell;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.GridCellSize;
import net.disy.commons.swing.layout.util.GridCellSizeList;

import org.hansel.CoverageDecorator;


/**
 * @author Markus Gebhard
 */
public class GridBuilderTest extends AbstractGridLayoutTestCase {

  public static Test suite() {
    return new CoverageDecorator(GridBuilderTest.class, new Class[] { GridBuilder.class });
  }

  public void testBugInitialHorizontalGrabAndSpan() {
    GridBuilder gridBuilder = new GridBuilder(2);

    Component component1 = createComponent(new Dimension(15, 10));
    GridDialogLayoutData grabData = new GridDialogLayoutData();
    grabData.setGrabExcessHorizontalSpace(true);
    grabData.setHorizontalAlignment(GridAlignment.FILL);
    gridBuilder.add(component1, grabData);

    Component component2 = createComponent(new Dimension(15, 10));
    GridDialogLayoutData fillData = new GridDialogLayoutData();
    grabData.setHorizontalAlignment(GridAlignment.FILL);
    gridBuilder.add(component2, fillData);

    Component secondRow = createComponent(new Dimension(40, 10));
    GridDialogLayoutData secondRowData = new GridDialogLayoutData();
    secondRowData.setHorizontalSpan(2);
    secondRowData.setHorizontalAlignment(GridAlignment.FILL);
    gridBuilder.add(secondRow, secondRowData);

    Grid grid = gridBuilder.createGrid(0, 0);
    GridCellSizeList columns = grid.getColumns();
    assertEquals(25, columns.get(0).getPreferredSize());
    assertEquals(15, columns.get(1).getPreferredSize());
  }

  public void testCreateEmptyGrid() {
    GridBuilder builder = new GridBuilder(1);
    Grid grid = builder.createGrid(2, 2);

    assertEquals(0, grid.getCellCount());
    assertEquals(1, grid.getColumnCount());
    assertEquals(0, grid.getRowCount());
    assertEquals(1, grid.getColumns().size());
    assertEquals(0, grid.getRows().size());
    GridCellSize column = grid.getColumn(0);
    assertEquals(0, column.getMinimumSize());
    assertEquals(0, column.getPreferredSize());
  }

  public void testSingleComponentInSingleCell() {
    GridBuilder builder = new GridBuilder(1);
    Dimension preferredSize = new Dimension(10, 12);
    Dimension minimumSize = new Dimension(15, 20);
    Component component = createComponent(preferredSize, minimumSize);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    builder.add(component, layoutData);
    Grid grid = builder.createGrid(2, 2);

    assertEquals(1, grid.getCellCount());
    assertEquals(1, grid.getColumnCount());
    assertEquals(1, grid.getRowCount());
    assertEquals(1, grid.getColumns().size());
    assertEquals(1, grid.getRows().size());

    GridCellSize column = grid.getColumn(0);
    assertEquals(minimumSize.width, column.getMinimumSize());
    assertEquals(preferredSize.width, column.getPreferredSize());

    GridCellSize row = grid.getRow(0);
    assertEquals(minimumSize.height, row.getMinimumSize());
    assertEquals(preferredSize.height, row.getPreferredSize());

    GridCell cell = grid.getCell(0);
    assertEquals(1, cell.getColumnSpan());
    assertEquals(1, cell.getRowSpan());
    assertEquals(0, cell.getColumnIndex());
    assertEquals(0, cell.getRowIndex());
    assertSame(component, cell.getComponent());
    assertSame(layoutData, cell.getLayoutData());
    assertEquals(minimumSize.height, cell.getMinimumSize().height);
    assertEquals(minimumSize.width, cell.getMinimumSize().width);
    assertEquals(preferredSize.width, cell.getPreferredSize().width);
    assertEquals(preferredSize.height, cell.getPreferredSize().height);
  }

  public void testIllegalColumnSpan() {
    GridBuilder builder = new GridBuilder(1);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalSpan(2);
    Component component = createComponent(new Dimension(10, 10));
    try {
      builder.add(component, layoutData);
      fail();
    }
    catch (IllegalArgumentException expected) {
      // expected
    }
  }

  public void testSingleComponentCoveringTwoCells() {
    GridBuilder builder = new GridBuilder(2);
    Dimension preferredSize = new Dimension(10, 12);
    Dimension minimumSize = new Dimension(14, 20);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setHorizontalSpan(2);
    Component component = createComponent(preferredSize, minimumSize);
    builder.add(component, layoutData);
    Grid grid = builder.createGrid(0, 0);

    assertEquals(1, grid.getCellCount());
    assertEquals(2, grid.getColumnCount());
    assertEquals(1, grid.getRowCount());
    assertEquals(2, grid.getColumns().size());
    assertEquals(1, grid.getRows().size());

    GridCellSize column1 = grid.getColumn(0);
    assertEquals(minimumSize.width / 2, column1.getMinimumSize());
    assertEquals(preferredSize.width / 2, column1.getPreferredSize());

    GridCellSize column2 = grid.getColumn(1);
    assertEquals(minimumSize.width / 2, column2.getMinimumSize());
    assertEquals(preferredSize.width / 2, column2.getPreferredSize());

    GridCellSize row = grid.getRow(0);
    assertEquals(minimumSize.height, row.getMinimumSize());
    assertEquals(preferredSize.height, row.getPreferredSize());

    GridCell cell = grid.getCell(0);
    assertEquals(2, cell.getColumnSpan());
    assertEquals(1, cell.getRowSpan());
    assertEquals(0, cell.getColumnIndex());
    assertEquals(0, cell.getRowIndex());
    assertSame(component, cell.getComponent());
    assertSame(layoutData, cell.getLayoutData());
    assertEquals(minimumSize.height, cell.getMinimumSize().height);
    assertEquals(minimumSize.width, cell.getMinimumSize().width);
    assertEquals(preferredSize.width, cell.getPreferredSize().width);
    assertEquals(preferredSize.height, cell.getPreferredSize().height);
  }

  public void testTwoRows() {
    GridBuilder builder = new GridBuilder(1);
    Component component1 = createComponent(new Dimension(10, 10));
    GridDialogLayoutData layoutData2 = new GridDialogLayoutData();
    GridDialogLayoutData layoutData1 = new GridDialogLayoutData();
    builder.add(component1, layoutData1);
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, layoutData2);
    Grid grid = builder.createGrid(0, 0);

    assertEquals(2, grid.getCellCount());
    assertEquals(1, grid.getColumnCount());
    assertEquals(2, grid.getRowCount());
    assertEquals(1, grid.getColumns().size());
    assertEquals(2, grid.getRows().size());

    GridCellSize column = grid.getColumn(0);
    assertEquals(10, column.getMinimumSize());
    assertEquals(10, column.getPreferredSize());

    GridCellSize row1 = grid.getRow(0);
    assertEquals(10, row1.getMinimumSize());
    assertEquals(10, row1.getPreferredSize());

    GridCellSize row2 = grid.getRow(0);
    assertEquals(10, row2.getMinimumSize());
    assertEquals(10, row2.getPreferredSize());

    GridCell cell1 = grid.getCell(0);
    assertEquals(1, cell1.getColumnSpan());
    assertEquals(1, cell1.getRowSpan());
    assertEquals(0, cell1.getColumnIndex());
    assertEquals(0, cell1.getRowIndex());
    assertSame(component1, cell1.getComponent());
    assertSame(layoutData1, cell1.getLayoutData());
    assertEquals(10, cell1.getMinimumSize().height);
    assertEquals(10, cell1.getMinimumSize().width);
    assertEquals(10, cell1.getPreferredSize().width);
    assertEquals(10, cell1.getPreferredSize().height);

    GridCell cell2 = grid.getCell(1);
    assertEquals(1, cell2.getColumnSpan());
    assertEquals(1, cell2.getRowSpan());
    assertEquals(0, cell2.getColumnIndex());
    assertEquals(1, cell2.getRowIndex());
    assertSame(component2, cell2.getComponent());
    assertSame(layoutData2, cell2.getLayoutData());
    assertEquals(10, cell2.getMinimumSize().height);
    assertEquals(10, cell2.getMinimumSize().width);
    assertEquals(10, cell2.getPreferredSize().width);
    assertEquals(10, cell2.getPreferredSize().height);
  }

  public void testAddComponentWhenCellAlreadyCovered() {
    GridBuilder builder = new GridBuilder(1);
    Component component1 = createComponent(new Dimension(10, 10));
    GridDialogLayoutData layoutData1 = new GridDialogLayoutData();
    layoutData1.setVerticalSpan(2);
    builder.add(component1, layoutData1);

    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    assertEquals(2, grid.getCellCount());
    assertEquals(1, grid.getColumnCount());
    assertEquals(3, grid.getRowCount());
    assertEquals(1, grid.getColumns().size());
    assertEquals(3, grid.getRows().size());

    GridCell cell1 = grid.getCell(0);
    assertEquals(1, cell1.getColumnSpan());
    assertEquals(2, cell1.getRowSpan());
    assertEquals(0, cell1.getColumnIndex());
    assertEquals(0, cell1.getRowIndex());
    assertSame(component1, cell1.getComponent());
    assertSame(layoutData1, cell1.getLayoutData());

    GridCell cell2 = grid.getCell(1);
    assertEquals(1, cell2.getColumnSpan());
    assertEquals(1, cell2.getRowSpan());
    assertEquals(0, cell2.getColumnIndex());
    assertEquals(2, cell2.getRowIndex());
    assertSame(component2, cell2.getComponent());
  }

  public void testTwoComponentsInSameRow() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    assertEquals(2, grid.getCellCount());
    assertEquals(2, grid.getColumnCount());
    assertEquals(1, grid.getRowCount());
    assertEquals(2, grid.getColumns().size());
    assertEquals(1, grid.getRows().size());

    GridCell cell1 = grid.getCell(0);
    assertEquals(1, cell1.getColumnSpan());
    assertEquals(1, cell1.getRowSpan());
    assertEquals(0, cell1.getColumnIndex());
    assertEquals(0, cell1.getRowIndex());
    assertSame(component1, cell1.getComponent());

    GridCell cell2 = grid.getCell(1);
    assertEquals(1, cell2.getColumnSpan());
    assertEquals(1, cell2.getRowSpan());
    assertEquals(1, cell2.getColumnIndex());
    assertEquals(0, cell2.getRowIndex());
    assertSame(component2, cell2.getComponent());
  }

  public void testLargeMultiColumnSpanComponentIncreasesSize() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());

    GridDialogLayoutData gridLayoutData3 = new GridDialogLayoutData();
    gridLayoutData3.setHorizontalSpan(2);
    Component component3 = createComponent(new Dimension(30, 10));
    builder.add(component3, gridLayoutData3);
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertEquals(15, column1.getMinimumSize());
    assertEquals(15, column1.getPreferredSize());

    GridCellSize column2 = grid.getColumn(1);
    assertEquals(15, column2.getMinimumSize());
    assertEquals(15, column2.getPreferredSize());
  }

  public void testSmallMultiColumnSpanComponentDoesntChangeSize() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());

    GridDialogLayoutData gridLayoutData3 = new GridDialogLayoutData();
    gridLayoutData3.setHorizontalSpan(2);
    Component component3 = createComponent(new Dimension(15, 10));
    builder.add(component3, gridLayoutData3);
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertEquals(10, column1.getMinimumSize());
    assertEquals(10, column1.getPreferredSize());

    GridCellSize column2 = grid.getColumn(1);
    assertEquals(10, column2.getMinimumSize());
    assertEquals(10, column2.getPreferredSize());
  }

  public void testLargeMultiRowSpanComponentIncreasesSize() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());

    GridDialogLayoutData gridLayoutData2 = new GridDialogLayoutData();
    gridLayoutData2.setVerticalSpan(2);
    Component component2 = createComponent(new Dimension(10, 30));
    builder.add(component2, gridLayoutData2);

    Component component3 = createComponent(new Dimension(10, 10));
    builder.add(component3, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize row1 = grid.getRow(0);
    assertEquals(15, row1.getMinimumSize());
    assertEquals(15, row1.getPreferredSize());

    GridCellSize row2 = grid.getRow(1);
    assertEquals(15, row2.getMinimumSize());
    assertEquals(15, row2.getPreferredSize());
  }

  public void testSmallMultiRowSpanComponentDoesntChangeSize() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());

    GridDialogLayoutData gridLayoutData2 = new GridDialogLayoutData();
    gridLayoutData2.setVerticalSpan(2);
    Component component2 = createComponent(new Dimension(10, 15));
    builder.add(component2, gridLayoutData2);

    Component component3 = createComponent(new Dimension(10, 10));
    builder.add(component3, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize row1 = grid.getRow(0);
    assertEquals(10, row1.getMinimumSize());
    assertEquals(10, row1.getPreferredSize());

    GridCellSize row2 = grid.getRow(1);
    assertEquals(10, row2.getMinimumSize());
    assertEquals(10, row2.getPreferredSize());
  }

  public void testGrabExcessHorizontalSpaceSetsExcessFlagForColumn() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(20, 10));
    builder.add(component1, GridDialogLayoutData.FILL_HORIZONTAL);
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertTrue(column1.isGrabExcessSpace());

    GridCellSize column2 = grid.getColumn(1);
    assertFalse(column2.isGrabExcessSpace());

    GridCellSize row = grid.getRow(0);
    assertFalse(row.isGrabExcessSpace());
  }

  public void testGrabExcessHorizontalSpaceSetsExcessFlagForLastCoveredColumn() {
    GridBuilder builder = new GridBuilder(3);
    Component component1 = createComponent(new Dimension(20, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_HORIZONTAL);
    gridLayoutData.setHorizontalSpan(2);
    builder.add(component1, gridLayoutData);
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertFalse(column1.isGrabExcessSpace());

    GridCellSize column2 = grid.getColumn(1);
    assertTrue(column2.isGrabExcessSpace());

    GridCellSize column3 = grid.getColumn(2);
    assertFalse(column3.isGrabExcessSpace());

    GridCellSize row = grid.getRow(0);
    assertFalse(row.isGrabExcessSpace());
  }

  public void testGrabExcessVerticalSpaceSetsExcessFlagForRow() {
    GridBuilder builder = new GridBuilder(1);
    Component component1 = createComponent(new Dimension(20, 10));
    builder.add(component1, GridDialogLayoutData.FILL_VERTICAL);
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertFalse(column1.isGrabExcessSpace());

    GridCellSize row1 = grid.getRow(0);
    assertTrue(row1.isGrabExcessSpace());

    GridCellSize row2 = grid.getRow(1);
    assertFalse(row2.isGrabExcessSpace());
  }

  public void testGrabExcessVerticalSpaceSetsExcessFlagForLastCoveredRow() {
    GridBuilder builder = new GridBuilder(1);
    Component component1 = createComponent(new Dimension(20, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_VERTICAL);
    gridLayoutData.setVerticalSpan(2);
    builder.add(component1, gridLayoutData);
    Component component2 = createComponent(new Dimension(10, 10));
    builder.add(component2, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    GridCellSize column1 = grid.getColumn(0);
    assertFalse(column1.isGrabExcessSpace());

    GridCellSize row1 = grid.getRow(0);
    assertFalse(row1.isGrabExcessSpace());

    GridCellSize row2 = grid.getRow(1);
    assertTrue(row2.isGrabExcessSpace());

    GridCellSize row3 = grid.getRow(2);
    assertFalse(row3.isGrabExcessSpace());
  }

  public void testIgnoresEndOfLineMarkerComponentsAfterEndOfLine() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    Component component3 = createComponent(new Dimension(10, 10));
    Component component4 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());
    builder.add(component2, new GridDialogLayoutData());
    builder.add(new EndOfLineMarkerComponent(), new GridDialogLayoutData());
    builder.add(component3, new GridDialogLayoutData());
    builder.add(component4, new GridDialogLayoutData());
    builder.add(new EndOfLineMarkerComponent(), new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    assertEquals(2, grid.getColumnCount());
    assertEquals(2, grid.getRowCount());
    assertEquals(4, grid.getCellCount());

    assertSame(component1, grid.getCell(0).getComponent());
    assertEquals(0, grid.getCell(0).getColumnIndex());
    assertEquals(0, grid.getCell(0).getRowIndex());

    assertSame(component2, grid.getCell(1).getComponent());
    assertEquals(1, grid.getCell(1).getColumnIndex());
    assertEquals(0, grid.getCell(1).getRowIndex());

    assertSame(component3, grid.getCell(2).getComponent());
    assertEquals(0, grid.getCell(2).getColumnIndex());
    assertEquals(1, grid.getCell(2).getRowIndex());

    assertSame(component4, grid.getCell(3).getComponent());
    assertEquals(1, grid.getCell(3).getColumnIndex());
    assertEquals(1, grid.getCell(3).getRowIndex());
  }

  public void testRespectsEndOfLineMarkerComponentsBeforeEndOfLine() {
    GridBuilder builder = new GridBuilder(2);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component3 = createComponent(new Dimension(10, 10));
    Component component4 = createComponent(new Dimension(10, 10));
    builder.add(component1, new GridDialogLayoutData());
    builder.add(new EndOfLineMarkerComponent(), new GridDialogLayoutData());
    builder.add(component3, new GridDialogLayoutData());
    builder.add(component4, new GridDialogLayoutData());
    Grid grid = builder.createGrid(0, 0);

    assertEquals(2, grid.getColumnCount());
    assertEquals(2, grid.getRowCount());
    assertEquals(3, grid.getCellCount());

    assertSame(component1, grid.getCell(0).getComponent());
    assertEquals(0, grid.getCell(0).getColumnIndex());
    assertEquals(0, grid.getCell(0).getRowIndex());

    assertSame(component3, grid.getCell(1).getComponent());
    assertEquals(0, grid.getCell(1).getColumnIndex());
    assertEquals(1, grid.getCell(1).getRowIndex());

    assertSame(component4, grid.getCell(2).getComponent());
    assertEquals(1, grid.getCell(2).getColumnIndex());
    assertEquals(1, grid.getCell(2).getRowIndex());
  }
}