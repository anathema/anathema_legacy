//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.layout.util.test;

import junit.framework.TestCase;

import net.disy.commons.swing.layout.util.LayoutUtilities;

// NOT_PUBLISHED
public class LayoutUtilitiesTest extends TestCase {

  public void testGetComponentsSpacing() {
    assertEquals(4, LayoutUtilities.getComponentSpacing(70));
    assertEquals(6, LayoutUtilities.getComponentSpacing(96));
    assertEquals(9, LayoutUtilities.getComponentSpacing(144));
  }

  public void testGetComponentGroupsSpacing() {
    assertEquals(8, LayoutUtilities.getComponentGroupsSpacing(70));
    assertEquals(11, LayoutUtilities.getComponentGroupsSpacing(96));
    assertEquals(16, LayoutUtilities.getComponentGroupsSpacing(144));
  }

}