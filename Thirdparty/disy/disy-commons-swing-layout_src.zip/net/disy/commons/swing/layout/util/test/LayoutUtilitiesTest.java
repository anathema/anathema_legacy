/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.util.test;

import junit.framework.TestCase;

import net.disy.commons.swing.layout.util.LayoutUtilities;

public class LayoutUtilitiesTest extends TestCase {

  public void testGetComponentsSpacing() {
    assertEquals(4, LayoutUtilities.getComponentSpacing(70));
    assertEquals(6, LayoutUtilities.getComponentSpacing(96));
    assertEquals(9, LayoutUtilities.getComponentSpacing(144));
  }

  public void testGetComponentGroupsSpacing() {
    assertEquals(8, LayoutUtilities.getComponentGroupsSpacing(70));
    assertEquals(11, LayoutUtilities.getComponentGroupsSpacing(96));
    assertEquals(16, LayoutUtilities.getComponentGroupsSpacing(144));
  }

}