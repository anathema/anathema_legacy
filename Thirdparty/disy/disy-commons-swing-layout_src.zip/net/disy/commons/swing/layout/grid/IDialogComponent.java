/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

import javax.swing.JPanel;

/**
 * @author Markus Gebhard
 */
public interface IDialogComponent {

  /** @return the number of columns this dialog component requires. */
  public int getColumnCount();

  /** Fill the contents of this component (its subcomponents) into the given panel.
   * The panel is assumed to have {@link GridDialogLayout} as its layout manager, having
   * at least {@link #getColumnCount()} columns. */
  public void fillInto(JPanel panel, int columnCount);

}