/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

public class ToggleVisibilityDemo extends SwingDemoCase {

  public void demoToggleVisibilityWithBorderLayout() {
    final JPanel panel = new JPanel(new BorderLayout());
    final JLabel label = new JLabel("Visibility Toggling Component"); //$NON-NLS-1$
    panel.add(label, BorderLayout.NORTH);
    panel.add(new JTextArea("bla\nblub"), BorderLayout.CENTER); //$NON-NLS-1$
    panel.add(new JButton(new AbstractAction("Toggle Visibility") { //$NON-NLS-1$
          @Override
          public void actionPerformed(ActionEvent e) {
            label.setVisible(!label.isVisible());
            panel.revalidate();
          }
        }), BorderLayout.SOUTH);
    show(panel);
  }

  public void demoToggleVisibilityWithGridDialogLayout() {
    final JPanel panel = new JPanel(new GridDialogLayout(1, false, 0, 0));
    final JLabel label = new JLabel("Visibility Toggling Component"); //$NON-NLS-1$
    panel.add(label, GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(new JTextArea("bla\nblub"), GridDialogLayoutData.FILL_BOTH); //$NON-NLS-1$
    panel.add(new JButton(new AbstractAction("Toggle Visibility") { //$NON-NLS-1$
          @Override
          public void actionPerformed(ActionEvent e) {
            label.setVisible(!label.isVisible());
            panel.revalidate();
          }
        }), GridDialogLayoutData.FILL_HORIZONTAL);
    show(panel);
  }
}