/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.Box;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.util.LayoutUtilities;

public class GridDialogPanelBuilder implements IGridDialogPanelBuilder {

  private static final class VerticalSpacingDialogComponent implements IDialogComponent {
    private final int height;

    private VerticalSpacingDialogComponent(int height) {
      this.height = height;
    }

    @Override
    public int getColumnCount() {
      return 1;
    }

    @Override
    public void fillInto(JPanel panel, int columnCount) {
      panel.add(Box.createVerticalStrut(height));
    }
  }

  private final List<IDialogComponent> components = new ArrayList<IDialogComponent>();
  private final boolean equalWidthColumns;
  private JPanel panel;
  private final int horizontalSpacing;
  private final int verticalSpacing;

  public GridDialogPanelBuilder() {
    this(false);
  }

  public GridDialogPanelBuilder(boolean equalWidthColumns) {
    this(equalWidthColumns, LayoutUtilities.getComponentSpacing(), LayoutUtilities
        .getComponentSpacing());
  }

  public GridDialogPanelBuilder(int horizontalSpacing, int verticalSpacing) {
    this(false, horizontalSpacing, verticalSpacing);
  }

  public GridDialogPanelBuilder(
      boolean equalWidthColumns,
      int horizontalSpacing,
      int verticalSpacing) {
    this.equalWidthColumns = equalWidthColumns;
    this.horizontalSpacing = horizontalSpacing;
    this.verticalSpacing = verticalSpacing;
  }

  @Override
  public void add(IDialogComponent component) {
    if (panel != null) {
      throw new IllegalStateException(
          "Trying to add a dialog component after content has been created."); //$NON-NLS-1$
    }
    components.add(component);
  }

  @Override
  public void addVerticalSpacing(final int height) {
    add(new VerticalSpacingDialogComponent(height));
  }

  @Override
  public JPanel createPanel() {
    if (panel == null) {
      int columnCount = getMaximumColumnCount();
      if (columnCount == 0) {
        columnCount = 1;
      }
      GridDialogLayout gridDialogLayout = new GridDialogLayout(columnCount, equalWidthColumns);
      gridDialogLayout.setHorizontalSpacing(horizontalSpacing);
      gridDialogLayout.setVerticalSpacing(verticalSpacing);
      panel = new JPanel(gridDialogLayout);
      for (Iterator<IDialogComponent> iter = components.iterator(); iter.hasNext();) {
        IDialogComponent component = iter.next();
        component.fillInto(panel, columnCount);
        panel.add(new EndOfLineMarkerComponent());
      }
    }
    return panel;
  }

  private int getMaximumColumnCount() {
    int maxColumnCount = 0;
    for (Iterator<IDialogComponent> iter = components.iterator(); iter.hasNext();) {
      IDialogComponent component = iter.next();
      if (component.getColumnCount() > maxColumnCount) {
        maxColumnCount = component.getColumnCount();
      }
    }
    return maxColumnCount;
  }
}