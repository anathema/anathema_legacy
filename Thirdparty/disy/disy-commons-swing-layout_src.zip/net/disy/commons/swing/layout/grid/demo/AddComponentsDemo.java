package net.disy.commons.swing.layout.grid.demo;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class AddComponentsDemo extends SwingDemoCase {

  public void demo() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JButton(new AbstractAction("Add") { //$NON-NLS-1$
      public void actionPerformed(ActionEvent e) {
        panel.add(new JLabel("Added")); //$NON-NLS-1$
        panel.revalidate();
      }
    }));
    show(new JScrollPane(panel));
  }
}
