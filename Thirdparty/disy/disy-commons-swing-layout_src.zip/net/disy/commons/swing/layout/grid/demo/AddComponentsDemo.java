/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.swing.layout.grid.GridDialogLayout;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class AddComponentsDemo extends SwingDemoCase {

  public void demo() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JButton(new AbstractAction("Add") { //$NON-NLS-1$
          @Override
          public void actionPerformed(ActionEvent e) {
            panel.add(new JLabel("Added")); //$NON-NLS-1$
            panel.revalidate();
          }
        }));
    show(new JScrollPane(panel));
  }
}
