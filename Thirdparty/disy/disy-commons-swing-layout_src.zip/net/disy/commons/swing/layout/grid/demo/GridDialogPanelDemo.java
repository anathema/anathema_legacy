package net.disy.commons.swing.layout.grid.demo;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogPanel;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class GridDialogPanelDemo extends SwingDemoCase {

  public void demo() {
    GridDialogPanel dialogPanel = new GridDialogPanel(false);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        GridDialogLayoutData gridLayoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_HORIZONTAL);
        gridLayoutData.setHorizontalSpan(columnCount);
        panel.add(new JTextField("full span textfield"), gridLayoutData); //$NON-NLS-1$
      }
    });
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(new JLabel("Label"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
        panel.add(new JTextField("textfield 2"), GridDialogLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$
      }
    });
    show(dialogPanel.getContent());
  }

  public void demoComponentsNotCoveringAllColumns() {
    GridDialogPanel dialogPanel = new GridDialogPanel(false);
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 1;
      }

      public void fillInto(JPanel panel, int columnCount) {
        IGridDialogLayoutData gridLayoutData = GridDialogLayoutData.FILL_HORIZONTAL;
        panel.add(new JTextField("full span textfield"), gridLayoutData); //$NON-NLS-1$
      }
    });
    dialogPanel.add(new IDialogComponent() {
      public int getColumnCount() {
        return 2;
      }

      public void fillInto(JPanel panel, int columnCount) {
        panel.add(new JLabel("Label"), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
        panel.add(new JTextField("textfield 2"), GridDialogLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$
      }
    });
    show(dialogPanel.getContent());
  }

}