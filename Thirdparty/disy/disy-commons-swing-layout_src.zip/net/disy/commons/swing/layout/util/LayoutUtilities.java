/**
 * A set of static methods for gui layouts. 
 * @author gebhard@disy.net
 */
package net.disy.commons.swing.layout.util;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

public class LayoutUtilities {

  private static final int DEFAULT_SCREEN_RESOLUTION = 96;

  public final static Dimension TOOLBAR_BUTTON_SIZE = new Dimension(22, 21);

  private static final EmptyBorder DEFAULT_EMPTY_BORDER = new EmptyBorder(
      getDpiAdjusted(5),
      getDpiAdjusted(6),
      getDpiAdjusted(5),
      getDpiAdjusted(6));

  /**
   * Creates a panel by laying out the given components like buttons at the bottom of dialog.
   * It is recommended to add the resulting panel to the parent container using the
   * {@link java.awt.BorderLayout}.
   * The components will all have the same width and hight and a minimum width of 70 pixels
   * is guaranteed.
   * <p>Example:
   * <pre>
   * .....................................
   * :              ________   ________  :
   * :             |___Ok___| |_Cancel_| :
   * :...................................:
   * </pre>
   * <p>Example code:
   *<pre>
   *  JPanel panel = LayoutTools.buildButtonPanel(new Component[]{ new JButton("Ok"), new
   *  JButton("Cancel"), }); //Show demo in frame JFrame frame = new JFrame();
   *  frame.getContentPane().setLayout(new BorderLayout()); frame.getContentPane().add(new
   *  JTextArea("Nice buttons..")), BorderLayout.CENTER); frame.getContentPane().add(panel,
   *  BorderLayout.SOUTH); frame.pack(); frame.show();
   *</pre>
   *
   * @param components The components to be layed out.
   * @return The panel containing the well layout out components.
   * @throws IllegalArgumentException if the provided components array is null or empty.
   * @deprecated As of Oct 4, 2004 (Markus Gebhard), replaced by {@link ButtonPanelBuilder}
   */
  public static JPanel buildButtonPanel(Component[] components) {
    if (components == null || components.length == 0) {
      throw new IllegalArgumentException(
          "At least one component has to be specified for laying out as Button panel."); //$NON-NLS-1$
    }

    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.HORIZONTAL);
    for (int i = 0; i < components.length; i++) {
      builder.add(components[i]);
    }
    return builder.createPanel();
  }

  public static int getScreenResolution() {
    try {
      return Toolkit.getDefaultToolkit().getScreenResolution();
    }
    catch (Exception e) {
      return DEFAULT_SCREEN_RESOLUTION;
    }
  }

  public static int getComponentSpacing() {
    return getComponentSpacing(getScreenResolution());
  }

  public static int getComponentSpacing(int screenResolutionInDpi) {
    return getDpiAdjusted(6, screenResolutionInDpi);
  }

  public static int getDpiAdjusted(int pixels, int screenResolutionInDpi) {
    return pixels * screenResolutionInDpi / DEFAULT_SCREEN_RESOLUTION;
  }

  public static int getDpiAdjusted(int pixels) {
    return pixels * getScreenResolution() / DEFAULT_SCREEN_RESOLUTION;
  }

  public static int getComponentGroupsSpacing() {
    return getComponentGroupsSpacing(getScreenResolution());
  }

  public static int getComponentGroupsSpacing(int screenResolutionInDpi) {
    return getDpiAdjusted(11, screenResolutionInDpi);
  }

  public static Border getDefaultEmptyBorder() {
    return DEFAULT_EMPTY_BORDER;
  }

  public BorderLayout createDefaultBorderLayout() {
    return new BorderLayout(getComponentSpacing(), getComponentSpacing());
  }
}