/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.util;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;

/**
 * A set of static methods for gui layouts. 
 * @author gebhard@disy.net
 */
public class LayoutUtilities {

  private static final int DEFAULT_SCREEN_RESOLUTION = 96;

  private static final int DEFAULT_TEXT_INPUT_FIELD_SIZE = 14;

  public final static Dimension TOOLBAR_BUTTON_SIZE = new Dimension(22, 21);

  private static final EmptyBorder DEFAULT_EMPTY_BORDER = new EmptyBorder(
      getDpiAdjusted(5),
      getDpiAdjusted(6),
      getDpiAdjusted(5),
      getDpiAdjusted(6));

  public static int getScreenResolution() {
    try {
      return Toolkit.getDefaultToolkit().getScreenResolution();
    }
    catch (final Exception e) {
      return DEFAULT_SCREEN_RESOLUTION;
    }
  }

  public static int getComponentSpacing() {
    return getComponentSpacing(getScreenResolution());
  }

  public static int getComponentSpacing(final int screenResolutionInDpi) {
    return getDpiAdjusted(6, screenResolutionInDpi);
  }

  public static int getDpiAdjusted(final int pixels, final int screenResolutionInDpi) {
    return pixels * screenResolutionInDpi / DEFAULT_SCREEN_RESOLUTION;
  }

  public static int getDpiAdjusted(final int pixels) {
    return pixels * getScreenResolution() / DEFAULT_SCREEN_RESOLUTION;
  }

  public static int getComponentGroupsSpacing() {
    return getComponentGroupsSpacing(getScreenResolution());
  }

  public static int getComponentGroupsSpacing(final int screenResolutionInDpi) {
    return getDpiAdjusted(11, screenResolutionInDpi);
  }

  public static Border getDefaultEmptyBorder() {
    return DEFAULT_EMPTY_BORDER;
  }

  public static BorderLayout createDefaultBorderLayout() {
    return new BorderLayout(getComponentSpacing(), getComponentSpacing());
  }

  public static int getDefaultTextInputFieldSize() {
    return DEFAULT_TEXT_INPUT_FIELD_SIZE;
  }
}