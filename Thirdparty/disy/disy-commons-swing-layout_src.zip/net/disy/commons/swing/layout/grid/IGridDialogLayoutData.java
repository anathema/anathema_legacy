/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid;

/**
 * Layout constraints associated with {@link net.disy.commons.swing.layout.grid.GridDialogLayout}.
 * @author Markus Gebhard
 */
public interface IGridDialogLayoutData {

  public final static int DEFAULT = -1;

  /**
   * horizontalSpan specifies the number of column cells that the control
   * will take up.
   *
   * The default value should be 1.
   */
  public int getHorizontalSpan();

  /**
   * verticalSpan specifies the number of row cells that the control
   * will take up.
   *
   * The default value should be 1.
   */
  public int getVerticalSpan();

  /**
   * horizontalIndent specifies the number of pixels of indentation
   * that will be placed along the left side of the cell.
   *
   * The default value should be 0.
   */
  public int getHorizontalIndent();

  /**
   * widthHint specifies a minimum width for the column. A value of 
   * {@link #DEFAULT} indicates that no minimum width is specified.
   *
   * The default value should be {@link #DEFAULT}.
   */
  public int getWidthHint();

  /**
   * heightHint specifies a minimum height for the row. A value of
   * {@link #DEFAULT} indicates that no minimum height is specified.
   *
   * The default value should be {@link #DEFAULT}.
   */
  public int getHeightHint();

  /**
   * horizontalAlignment specifies how controls will be positioned 
   * horizontally within a cell. 
   *
   * The default value should be {@link GridAlignment#BEGINNING}.
   *
   * Possible values are:
   *
   * {@link GridAlignment#BEGINNING}: Position the control at the left of the cell
   * {@link GridAlignment#CENTER}: Position the control in the horizontal center of the cell
   * {@link GridAlignment#END}: Position the control at the right of the cell
   * {@link GridAlignment#FILL}: Resize the control to fill the cell horizontally
   */
  public GridAlignment getHorizontalAlignment();

  /**
   * verticalAlignment specifies how controls will be positioned 
   * vertically within a cell. 
   *
   * The default value should be  {@link GridAlignment#CENTER}.
   *
   * Possible values are:
   *
   * {@link GridAlignment#BEGINNING}: Position the control at the top of the cell
   * {@link GridAlignment#CENTER}: Position the control in the vertical center of the cell
   * {@link GridAlignment#END}: Position the control at the bottom of the cell
   * {@link GridAlignment#FILL}: Resize the control to fill the cell vertically
   */
  public GridAlignment getVerticalAlignment();

  /**
   * grabExcessHorizontalSpace specifies whether the cell will be made
   * wide enough to fit the remaining horizontal space.
   *
   * The default value should be false.
   */
  public boolean isGrabExcessHorizontalSpace();

  /**
   * grabExcessVerticalSpace specifies whether the cell will be made
   * tall enough to fit the remaining vertical space.
   *
   * The default value should be false.
   */
  public boolean isGrabExcessVerticalSpace();

}