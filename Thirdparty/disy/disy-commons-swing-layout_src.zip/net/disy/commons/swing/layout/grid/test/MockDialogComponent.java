package net.disy.commons.swing.layout.grid.test;

import javax.swing.JPanel;

import junit.framework.AssertionFailedError;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.IDialogComponent;


/**
 * @author Markus Gebhard
 */
public class MockDialogComponent implements IDialogComponent {

  private final int componentColumnCount;
  private boolean columnCountCalled = false;
  private boolean fillIntoCalled = false;
  private final int totalColumnCount;

  public MockDialogComponent(int componentColumnCount, int totalColumnCount) {
    this.componentColumnCount = componentColumnCount;
    this.totalColumnCount = totalColumnCount;
  }

  public int getColumnCount() {
    columnCountCalled = true;
    return componentColumnCount;
  }

  public void fillInto(JPanel panel, int columnCount) {
    if (!(panel.getLayout() instanceof GridDialogLayout)) {
      throw new AssertionFailedError("panel expected to have GridDialogLayout, but was " + panel.getLayout()); //$NON-NLS-1$
    }
    if (fillIntoCalled) {
      throw new AssertionFailedError("fillInto method has already been called"); //$NON-NLS-1$
    }
    fillIntoCalled = true;
    if (columnCount != totalColumnCount) {
      throw new AssertionFailedError("Actual columnCount " //$NON-NLS-1$
          + columnCount + " not equal to expected column count " //$NON-NLS-1$
          + totalColumnCount);
    }
  }

  public void verify() {
    if (!fillIntoCalled) {
      throw new AssertionFailedError("fillInto method was not called"); //$NON-NLS-1$
    }
    if (!columnCountCalled) {
      throw new AssertionFailedError("getColumnCount method was not called"); //$NON-NLS-1$
    }
  }
}