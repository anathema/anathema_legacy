/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.test;

import javax.swing.JPanel;

import junit.framework.AssertionFailedError;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.IDialogComponent;

/**
 * @author Markus Gebhard
 */
public class MockDialogComponent implements IDialogComponent {

  private final int componentColumnCount;
  private boolean columnCountCalled = false;
  private boolean fillIntoCalled = false;
  private final int totalColumnCount;

  public MockDialogComponent(int componentColumnCount, int totalColumnCount) {
    this.componentColumnCount = componentColumnCount;
    this.totalColumnCount = totalColumnCount;
  }

  @Override
  public int getColumnCount() {
    columnCountCalled = true;
    return componentColumnCount;
  }

  @Override
  public void fillInto(JPanel panel, int columnCount) {
    if (!(panel.getLayout() instanceof GridDialogLayout)) {
      throw new AssertionFailedError(
          "panel expected to have GridDialogLayout, but was " + panel.getLayout()); //$NON-NLS-1$
    }
    if (fillIntoCalled) {
      throw new AssertionFailedError("fillInto method has already been called"); //$NON-NLS-1$
    }
    fillIntoCalled = true;
    if (columnCount != totalColumnCount) {
      throw new AssertionFailedError("Actual columnCount " //$NON-NLS-1$
          + columnCount
          + " not equal to expected column count " //$NON-NLS-1$
          + totalColumnCount);
    }
  }

  public void verify() {
    if (!fillIntoCalled) {
      throw new AssertionFailedError("fillInto method was not called"); //$NON-NLS-1$
    }
    if (!columnCountCalled) {
      throw new AssertionFailedError("getColumnCount method was not called"); //$NON-NLS-1$
    }
  }
}