/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class PracticalExampleDemo extends SwingDemoCase {

  public void demo() {
    JPanel panel = new JPanel(new GridDialogLayout(5, false));

    GridDialogLayoutData twoColumnSpanningLayoutData = new GridDialogLayoutData();
    twoColumnSpanningLayoutData.setHorizontalSpan(2);
    panel.add(new JCheckBox("Linke Grenze"), twoColumnSpanningLayoutData); //$NON-NLS-1$
    panel.add(Box.createHorizontalGlue());
    panel.add(new JCheckBox("Rechte Grenze"), twoColumnSpanningLayoutData); //$NON-NLS-1$

    panel.add(new JTextField("100.0", 10));//, GridLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$
    panel.add(new JComboBox(new String[]{ "<", "<=" })); //$NON-NLS-1$//$NON-NLS-2$
    panel.add(new JLabel("Wert"), GridDialogLayoutData.CENTER); //$NON-NLS-1$
    panel.add(new JComboBox(new String[]{ "<", "<=" })); //$NON-NLS-1$ //$NON-NLS-2$
    panel.add(new JTextField("200.0", 10));//, GridLayoutData.FILL_HORIZONTAL); //$NON-NLS-1$

    show(panel);
  }

}