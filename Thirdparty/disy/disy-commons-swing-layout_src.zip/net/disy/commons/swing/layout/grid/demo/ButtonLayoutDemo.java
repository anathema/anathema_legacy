/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.demo;

import javax.swing.JButton;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class ButtonLayoutDemo extends SwingDemoCase {

  public void demo1Column() {
    showButtons(1, false);
  }

  public void demo2Columns() {
    showButtons(2, false);
  }

  public void demo3Columns() {
    showButtons(3, false);
  }

  public void demo2ColumnsEqualWidth() {
    showButtons(2, true);
  }

  public void demo3ColumnsEqualWidth() {
    showButtons(3, true);
  }

  private void showButtons(int columnCount, boolean equalWidth) {
    JPanel panel = new JPanel(new GridDialogLayout(columnCount, equalWidth));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$
    panel.add(new JButton("Button 3")); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    panel.add(new JButton("Button 5")); //$NON-NLS-1$
    show(panel);
  }

  public void demoHorizontalAlignmentBeginning() {
    showHorizontalAlignedButtons(GridAlignment.BEGINNING, 0);
  }

  public void demoHorizontalAlignmentCenter() {
    showHorizontalAlignedButtons(GridAlignment.CENTER, 0);
  }

  public void demoHorizontalAlignmentEnd() {
    showHorizontalAlignedButtons(GridAlignment.END, 0);
  }

  public void demoHorizontalAlignmentFill() {
    showHorizontalAlignedButtons(GridAlignment.FILL, 0);
  }

  public void demoHorizontalAlignmentBeginningAndIndent4() {
    showHorizontalAlignedButtons(GridAlignment.BEGINNING, 4);
  }

  public void demoHorizontalAlignmentCenterAndIndent4() {
    showHorizontalAlignedButtons(GridAlignment.CENTER, 4);
  }

  public void demoHorizontalAlignmentEndAndIndent4() {
    showHorizontalAlignedButtons(GridAlignment.END, 4);
  }

  public void demoHorizontalAlignmentFillAndIndent4() {
    showHorizontalAlignedButtons(GridAlignment.FILL, 4);
  }

  private void showHorizontalAlignedButtons(GridAlignment horizontalAlignment, int horizontalIndent) {
    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$
    panel.add(new JButton("Button 3")); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalIndent(horizontalIndent);
    gridLayoutData.setHorizontalAlignment(horizontalAlignment);
    panel.add(new JButton("Button 5"), gridLayoutData); //$NON-NLS-1$
    show(panel);
  }

  public void demoButton5HorizontalSpan2() {
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalAlignment(GridAlignment.FILL);
    gridLayoutData.setHorizontalSpan(2);

    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$
    panel.add(new JButton("Button 3")); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    panel.add(new JButton("Button 5"), gridLayoutData); //$NON-NLS-1$
    show(panel);
  }

  public void demoButton2HorizontalSpan2() {
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalAlignment(GridAlignment.FILL);
    gridLayoutData.setHorizontalSpan(2);

    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2"), gridLayoutData); //$NON-NLS-1$
    panel.add(new JButton("Button 3")); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    panel.add(new JButton("Button 5")); //$NON-NLS-1$
    show(panel);
  }

  public void demoButton3VerticalSpan2() {
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setVerticalAlignment(GridAlignment.FILL);
    gridLayoutData.setVerticalSpan(2);

    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$
    panel.add(new JButton("Button 3"), gridLayoutData); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    panel.add(new JButton("Button 5")); //$NON-NLS-1$
    show(panel);
  }

  public void demoGrabExcessSpace() {
    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1"), GridDialogLayoutData.FILL_VERTICAL); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$

    GridDialogLayoutData gridLayoutData3 = new GridDialogLayoutData();
    gridLayoutData3.setVerticalAlignment(GridAlignment.FILL);
    gridLayoutData3.setHorizontalAlignment(GridAlignment.FILL);
    gridLayoutData3.setVerticalSpan(2);
    gridLayoutData3.setGrabExcessHorizontalSpace(true);
    gridLayoutData3.setGrabExcessVerticalSpace(true);
    panel.add(new JButton("Button 3"), gridLayoutData3); //$NON-NLS-1$

    panel.add(new JButton("B4"), GridDialogLayoutData.FILL_VERTICAL); //$NON-NLS-1$
    panel.add(new JButton("Button 5")); //$NON-NLS-1$
    show(panel);
  }

  public void demoWidthAndHeightHints() {
    JPanel panel = new JPanel(new GridDialogLayout(3, false));
    panel.add(new JButton("B1")); //$NON-NLS-1$
    panel.add(new JButton("Wide Button 2")); //$NON-NLS-1$
    panel.add(new JButton("Button 3")); //$NON-NLS-1$
    panel.add(new JButton("B4")); //$NON-NLS-1$
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData(
        GridDialogLayoutData.FILL_VERTICAL);
    gridLayoutData.setWidthHint(70);
    gridLayoutData.setHeightHint(40);
    panel.add(new JButton("Button 5"), gridLayoutData); //$NON-NLS-1$
    show(panel);
  }

}