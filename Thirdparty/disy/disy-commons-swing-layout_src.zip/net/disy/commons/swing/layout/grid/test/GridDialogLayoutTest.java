/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;

public class GridDialogLayoutTest extends AbstractGridLayoutTestCase {

  public void testInvalidateKeepsSize() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    container.add(createComponent(new Dimension(10, 11)));
    assertEquals(new Dimension(10, 11), layout.preferredLayoutSize(container));
    layout.invalidateLayout(container);
    assertEquals(new Dimension(10, 11), layout.preferredLayoutSize(container));
  }

  public void testInvalidateLaysOutCorrectly() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(10, 11));
    container.add(component);
    layout.invalidateLayout(container);
    container.setSize(10, 11);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 10, 11), component.getBounds());
  }

  public void testRemoveLayoutComponent() {
    //TODO 31.05.2006 (Markus Gebhard): check behavior
    //Just for coverage, behavior is not being checked yet
    new GridDialogLayout(1, false).removeLayoutComponent(new JLabel());
  }

  public void testIllegalAddLayoutComponent() {
    try {
      new GridDialogLayout(1, false).addLayoutComponent(new JLabel(), "illegal"); //$NON-NLS-1$
      fail();
    }
    catch (final IllegalArgumentException expected) {
      //expected
    }
  }

  public void testIllegalCreate() {
    try {
      new GridDialogLayout(0, false);
      fail();
    }
    catch (final IllegalArgumentException expected) {
      //expected
    }
    try {
      new GridDialogLayout(-1, false);
      fail();
    }
    catch (final IllegalArgumentException expected) {
      //expected
    }
  }

  public void testLayoutEmptyComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    assertEquals(new Dimension(0, 0), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(0, 0), layout.minimumLayoutSize(container));
  }

  public void testUsesDefaultSpacings() throws Exception {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    assertEquals(LayoutUtilities.getComponentSpacing(), layout.getHorizontalSpacing());
    assertEquals(LayoutUtilities.getComponentSpacing(), layout.getVerticalSpacing());
  }

  public void testUsesSpecifiedSpacings() throws Exception {
    final GridDialogLayout layout = new GridDialogLayout(1, false, 13, 17);
    assertEquals(13, layout.getHorizontalSpacing());
    assertEquals(17, layout.getVerticalSpacing());
  }

  public void testLayoutSizeForSingleComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(20, 10), new Dimension(18, 7));
    container.add(component);
    assertEquals(new Dimension(20, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(18, 7), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component.getBounds());
  }

  public void testAsksForPreferredSizeOnlyOnce() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final int[] counter = new int[]{ 0 };
    final Component component = new JLabel() {
      @Override
      public Dimension getPreferredSize() {
        ++counter[0];
        return new Dimension(20, 10);
      }
    };
    container.add(component);
    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component.getBounds());
    assertEquals(1, counter[0]);
  }

  public void testRespectsContainerInsets() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final JPanel container = new JPanel(layout) {
      @Override
      public Insets getInsets() {
        return new Insets(1, 2, 4, 8);
      }
    };
    final Component component = createComponent(new Dimension(20, 10));
    container.add(component);

    assertEquals(new Dimension(20 + 2 + 8, 10 + 1 + 4), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(20 + 2 + 8, 10 + 1 + 4), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(2, 1, 20, 10), component.getBounds());
  }

  public void testRespectsColumnCount() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    final Component component3 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);
    container.add(component3);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  public void testRespectsHorizontalSpacing() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    final int spacing = layout.getHorizontalSpacing();
    assertEquals(new Dimension(10 + spacing + 10, 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + spacing + 10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10 + spacing, 0, 10, 10), component2.getBounds());
  }

  public void testRespectsVerticalSpacing() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    final int spacing = layout.getVerticalSpacing();
    assertEquals(new Dimension(10, 10 + spacing + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10, 10 + spacing + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10 + spacing, 10, 10), component2.getBounds());
  }

  public void testEqualWidthColumns() {
    final GridDialogLayout layout = new GridDialogLayout(2, true);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(20, 10));
    container.add(component1);
    container.add(component2);

    assertEquals(new Dimension(20 + 20, 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20 + 20, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(20, 0, 20, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentBeginning() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentCenter() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.CENTER);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(5, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentEnd() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.RIGHT);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentFill() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 20, 10), component2.getBounds());
  }

  public void testVerticalAlignmentBeginning() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 20));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.BEGINNING);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentCenter() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 20));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.CENTER);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 5, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentEnd() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 20));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.END);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 10, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentFill() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 20));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 20), component2.getBounds());
  }

  public void testHorizontalIndent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalIndent(7);
    container.add(component2, gridLayoutData);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(7, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalSpan() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 10));
    final Component component3 = createComponent(new Dimension(15, 10));
    container.add(component1);
    container.add(component2);
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalSpan(2);
    container.add(component3, gridLayoutData);

    assertEquals(new Dimension(10 + 10, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 15, 10), component3.getBounds());
  }

  public void testVerticalSpan() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(10, 10));
    final Component component2 = createComponent(new Dimension(10, 15));
    final Component component3 = createComponent(new Dimension(10, 10));
    container.add(component1);
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setVerticalSpan(2);
    gridLayoutData.setVerticalAlignment(GridAlignment.BEGINNING);
    container.add(component2, gridLayoutData);
    container.add(component3);

    assertEquals(new Dimension(10 + 10, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 15), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  public void testWidthHintGreaterThanComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(10, 10));
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setWidthHint(15);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(15, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(15, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testWidthHintWhenLessThanComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(10, 10));
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setWidthHint(5);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testHeightHintWhenGreaterThanComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(10, 10));
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHeightHint(14);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 14), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 14), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 2, 10, 10), component.getBounds());
  }

  public void testHeightHintWhenLessThanComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(10, 10));
    final GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHeightHint(5);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testShrinksComponentToSmallerContainer() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component);
    assertEquals(new Dimension(20, 20), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(20, 20), layout.minimumLayoutSize(container));

    container.setSize(16, 15);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 16, 15), component.getBounds());
  }

  public void testShrinksRowsEqually() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 30);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 15), component1.getBounds());
    assertEquals(new Rectangle(0, 15, 20, 15), component2.getBounds());
  }

  public void testShrinksResizingRowBeforeOthers() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 30);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 20), component1.getBounds());
    assertEquals(new Rectangle(0, 20, 20, 10), component2.getBounds());
  }

  public void testShrinksColumnsEqually() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 15, 20), component1.getBounds());
    assertEquals(new Rectangle(15, 0, 15, 20), component2.getBounds());
  }

  public void testShrinksColumnsWithEqualWidth() {
    final GridDialogLayout layout = new GridDialogLayout(2, true);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 15, 20), component1.getBounds());
    assertEquals(new Rectangle(15, 0, 15, 20), component2.getBounds());
  }

  public void testShrinksResizingColumnsBeforeOthers() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 20), component1.getBounds());
    assertEquals(new Rectangle(20, 0, 10, 20), component2.getBounds());
  }

  public void testShrinksNonResizingColumnsAfterResizingIfNecessary() {
    final GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(10, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 0, 20), component2.getBounds());
  }

  public void testShrinksNonResizingRowsAfterResizingIfNecessary() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 10);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 20, 0), component2.getBounds());
  }

  public void testExpandsComponentsHorizontallyWhenExtraSpaceForGrabbingComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, true);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component, GridDialogLayoutData.FILL_HORIZONTAL);
    container.setSize(40, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 40, 20), component.getBounds());
  }

  public void testExpandsComponentsHorizontallyWhenExtraSpaceForNonGrabbingComponent() {
    final GridDialogLayout layout = new GridDialogLayout(1, true);
    final Container container = createContainer(layout);
    final Component component = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component);
    container.setSize(40, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 20), component.getBounds());
  }

  public void testShrinksGrabbingComponentHorizontallyForDifferentWidthColumnsWhenNotEnoughSpace() {
    final GridDialogLayout layout = new GridDialogLayout(2, false, 0, 0);
    final Container container = createContainer(layout);
    final Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    final Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);
    container.setSize(10, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 0, 20), component2.getBounds());
  }

  public void testAddComponentByStringIsIllegal() {
    final GridDialogLayout layout = new GridDialogLayout(1, false);
    try {
      layout.addLayoutComponent("name", new JLabel()); //$NON-NLS-1$
      fail();
    }
    catch (final UnsupportedOperationException expected) {
      //expected
    }
  }
}