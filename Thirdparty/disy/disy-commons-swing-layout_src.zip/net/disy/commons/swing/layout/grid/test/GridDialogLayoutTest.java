package net.disy.commons.swing.layout.grid.test;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.Rectangle;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;


/**
 * @author Markus Gebhard
 */
public class GridDialogLayoutTest extends AbstractGridLayoutTestCase {

  //TODO Sep 11, 2004 (Markus Gebhard): Add code coverage testing
  //  public static Test suite() {
  //    return new CoverageDecorator(GridDialogLayoutTest.class, new Class[]{ GridDialogLayout.class });
  //  }

  public void testIllegalCreate() {
    try {
      new GridDialogLayout(0, false);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
    try {
      new GridDialogLayout(-1, false);
      fail();
    }
    catch (IllegalArgumentException expected) {
      //expected
    }
  }

  public void testLayoutEmptyComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    assertEquals(new Dimension(0, 0), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(0, 0), layout.minimumLayoutSize(container));
  }

  public void testUsesDefaultSpacings() throws Exception {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    assertEquals(LayoutUtilities.getComponentSpacing(), layout.getHorizontalSpacing());
    assertEquals(LayoutUtilities.getComponentSpacing(), layout.getVerticalSpacing());
  }

  public void testUsesSpecifiedSpacings() throws Exception {
    GridDialogLayout layout = new GridDialogLayout(1, false, 13, 17);
    assertEquals(13, layout.getHorizontalSpacing());
    assertEquals(17, layout.getVerticalSpacing());
  }

  public void testLayoutSizeForSingleComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(20, 10), new Dimension(18, 7));
    container.add(component);
    assertEquals(new Dimension(20, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(18, 7), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component.getBounds());
  }

  public void testAsksForPreferredSizeOnlyOnce() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    final int[] counter = new int[]{ 0 };
    Component component = new JLabel() {
      public Dimension getPreferredSize() {
        ++counter[0];
        return new Dimension(20, 10);
      }
    };
    container.add(component);
    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component.getBounds());
    assertEquals(1, counter[0]);
  }

  public void testRespectsContainerInsets() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    JPanel container = new JPanel(layout) {
      public Insets getInsets() {
        return new Insets(1, 2, 4, 8);
      }
    };
    Component component = createComponent(new Dimension(20, 10));
    container.add(component);

    assertEquals(new Dimension(20 + 2 + 8, 10 + 1 + 4), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(20 + 2 + 8, 10 + 1 + 4), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(2, 1, 20, 10), component.getBounds());
  }

  public void testRespectsColumnCount() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    Component component3 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);
    container.add(component3);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  public void testRespectsHorizontalSpacing() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    int spacing = layout.getHorizontalSpacing();
    assertEquals(new Dimension(10 + spacing + 10, 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + spacing + 10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10 + spacing, 0, 10, 10), component2.getBounds());
  }

  public void testRespectsVerticalSpacing() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    int spacing = layout.getVerticalSpacing();
    assertEquals(new Dimension(10, 10 + spacing + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10, 10 + spacing + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10 + spacing, 10, 10), component2.getBounds());
  }

  public void testEqualWidthColumns() {
    GridDialogLayout layout = new GridDialogLayout(2, true);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(20, 10));
    container.add(component1);
    container.add(component2);

    assertEquals(new Dimension(20 + 20, 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20 + 20, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(20, 0, 20, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentBeginning() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentCenter() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.CENTER);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(5, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentEnd() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.RIGHT);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalAlignmentFill() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 20, 10), component2.getBounds());
  }

  public void testVerticalAlignmentBeginning() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 20));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.BEGINNING);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentCenter() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 20));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.CENTER);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 5, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentEnd() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 20));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setVerticalAlignment(GridAlignment.END);
    container.add(component2, layoutData);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 10, 10, 10), component2.getBounds());
  }

  public void testVerticalAlignmentFill() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 20));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(10 + 10, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 20), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 20), component2.getBounds());
  }

  public void testHorizontalIndent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    container.add(component1);
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalIndent(7);
    container.add(component2, gridLayoutData);

    assertEquals(new Dimension(20, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(7, 10, 10, 10), component2.getBounds());
  }

  public void testHorizontalSpan() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 10));
    Component component3 = createComponent(new Dimension(15, 10));
    container.add(component1);
    container.add(component2);
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalSpan(2);
    container.add(component3, gridLayoutData);

    assertEquals(new Dimension(10 + 10, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 10), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 15, 10), component3.getBounds());
  }

  public void testVerticalSpan() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(10, 10));
    Component component2 = createComponent(new Dimension(10, 15));
    Component component3 = createComponent(new Dimension(10, 10));
    container.add(component1);
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setVerticalSpan(2);
    gridLayoutData.setVerticalAlignment(GridAlignment.BEGINNING);
    container.add(component2, gridLayoutData);
    container.add(component3);

    assertEquals(new Dimension(10 + 10, 10 + 10), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(10 + 10, 10 + 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 10, 15), component2.getBounds());
    assertEquals(new Rectangle(0, 10, 10, 10), component3.getBounds());
  }

  public void testWidthHintGreaterThanComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(10, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setWidthHint(15);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(15, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(15, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testWidthHintWhenLessThanComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(10, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setWidthHint(5);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testHeightHintWhenGreaterThanComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(10, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHeightHint(14);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 14), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 14), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 2, 10, 10), component.getBounds());
  }

  public void testHeightHintWhenLessThanComponent() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(10, 10));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHeightHint(5);
    container.add(component, gridLayoutData);

    assertEquals(new Dimension(10, 10), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(10, 10), layout.minimumLayoutSize(container));

    doLayout(layout, container);
    assertEquals(new Rectangle(0, 0, 10, 10), component.getBounds());
  }

  public void testShrinksComponentToSmallerContainer() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    Container container = createContainer(layout);
    Component component = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component);
    assertEquals(new Dimension(20, 20), layout.preferredLayoutSize(container));

    assertEquals(new Dimension(20, 20), layout.minimumLayoutSize(container));

    container.setSize(16, 15);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 16, 15), component.getBounds());
  }

  public void testShrinksRowsEqually() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 30);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 15), component1.getBounds());
    assertEquals(new Rectangle(0, 15, 20, 15), component2.getBounds());
  }

  public void testShrinksResizingRowBeforeOthers() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 30);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 20), component1.getBounds());
    assertEquals(new Rectangle(0, 20, 20, 10), component2.getBounds());
  }

  public void testShrinksColumnsEqually() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 15, 20), component1.getBounds());
    assertEquals(new Rectangle(15, 0, 15, 20), component2.getBounds());
  }

  public void testShrinksColumnsWithEqualWidth() {
    GridDialogLayout layout = new GridDialogLayout(2, true);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 15, 20), component1.getBounds());
    assertEquals(new Rectangle(15, 0, 15, 20), component2.getBounds());
  }

  public void testShrinksResizingColumnsBeforeOthers() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(30, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 20), component1.getBounds());
    assertEquals(new Rectangle(20, 0, 10, 20), component2.getBounds());
  }

  public void testShrinksNonResizingColumnsAfterResizingIfNecessary() {
    GridDialogLayout layout = new GridDialogLayout(2, false);
    layout.setHorizontalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_HORIZONTAL);

    assertEquals(new Dimension(40, 20), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(40, 20), layout.minimumLayoutSize(container));

    container.setSize(10, 20);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 10, 20), component1.getBounds());
    assertEquals(new Rectangle(10, 0, 0, 20), component2.getBounds());
  }

  public void testShrinksNonResizingRowsAfterResizingIfNecessary() {
    GridDialogLayout layout = new GridDialogLayout(1, false);
    layout.setVerticalSpacing(0);
    Container container = createContainer(layout);
    Component component1 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component1);
    Component component2 = createComponent(new Dimension(20, 20), new Dimension(20, 20));
    container.add(component2, GridDialogLayoutData.FILL_VERTICAL);

    assertEquals(new Dimension(20, 40), layout.preferredLayoutSize(container));
    assertEquals(new Dimension(20, 40), layout.minimumLayoutSize(container));

    container.setSize(20, 10);
    layout.layoutContainer(container);
    assertEquals(new Rectangle(0, 0, 20, 10), component1.getBounds());
    assertEquals(new Rectangle(0, 10, 20, 0), component2.getBounds());
  }
}