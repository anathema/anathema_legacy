/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.layout.util;

/**
 * @author Markus Gebhard
 */
public class GridCellSizeList {

  private final GridCellSize[] sizes;

  public GridCellSizeList(int size) {
    this.sizes = new GridCellSize[size];
    for (int i = 0; i < sizes.length; i++) {
      sizes[i] = new GridCellSize();
    }
  }

  public GridCellSizeList(GridCellSize[] sizes) {
    this.sizes = sizes;
  }

  public GridCellSize get(int index) {
    return sizes[index];
  }

  public int size() {
    return sizes.length;
  }

  public void increaseMinimumSizes(int startIndex, int span, int totalIncrement) {
    if (span < 1) {
      throw new IllegalArgumentException("Illegal span " + span); //$NON-NLS-1$
    }
    int increment = totalIncrement / span;
    for (int i = startIndex; i < startIndex + span; i++) {
      sizes[i].incrementMinimumSize(increment);
    }
    int remainder = totalIncrement - (increment * span);
    for (int i = 0; i < remainder; ++i) {
      int sizeIndex = startIndex + span - 1 - i;
      sizes[sizeIndex].incrementMinimumSize(1);
    }
  }

  public void increasePreferredSizes(int startIndex, int span, int totalIncrement) {
    if (span < 1) {
      throw new IllegalArgumentException("Illegal span " + span); //$NON-NLS-1$
    }
    int increment = totalIncrement / span;
    for (int i = startIndex; i < startIndex + span; i++) {
      sizes[i].incrementPreferredSize(increment);
    }
    int remainder = totalIncrement - (increment * span);
    for (int i = 0; i < remainder; ++i) {
      int sizeIndex = startIndex + span - 1 - i;
      sizes[sizeIndex].incrementPreferredSize(1);
    }
  }

  public void increaseSizes(int startIndex, int span, int totalIncrement) {
    if (span < 1) {
      throw new IllegalArgumentException("Illegal span " + span); //$NON-NLS-1$
    }
    int increment = totalIncrement / span;
    for (int i = startIndex; i < startIndex + span; i++) {
      sizes[i].incrementSize(increment);
    }
    int remainder = totalIncrement - (increment * span);
    for (int i = 0; i < remainder; ++i) {
      int sizeIndex = startIndex + span - 1 - i;
      sizes[sizeIndex].incrementSize(1);
    }
  }

  public int getAvailableMinimumSize(int startIndex, int span, int spacing) {
    if (span < 0) {
      throw new IllegalArgumentException("Illegal span " + span); //$NON-NLS-1$
    }
    int size = 0;
    for (int i = startIndex; i < startIndex + span; i++) {
      size += sizes[i].getMinimumSize();
    }
    size += (span - 1) * spacing;
    return size;
  }

  public int getAvailablePreferredSize(int startIndex, int span, int spacing) {
    if (span < 0) {
      throw new IllegalArgumentException("Illegal span " + span); //$NON-NLS-1$
    }
    int size = 0;
    for (int i = startIndex; i < startIndex + span; i++) {
      size += sizes[i].getPreferredSize();
    }
    size += (span - 1) * spacing;
    return size;
  }

  public void increaseSizes(int totalIncrement) {
    increaseSizes(0, size(), totalIncrement);
  }

  public void adjustToPreferredSizes() {
    for (int i = 0; i < sizes.length; i++) {
      sizes[i].adjustToPreferredSize();
    }
  }

}