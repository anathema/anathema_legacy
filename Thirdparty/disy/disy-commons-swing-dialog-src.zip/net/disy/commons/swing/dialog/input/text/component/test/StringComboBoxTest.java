/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.input.text.component.StringComboBox;

import org.junit.Before;
import org.junit.Test;

public class StringComboBoxTest {

  private ObjectModel<Boolean> called;
  private IAttributeValueListFactory<String> valueListFactory;
  private IAttributeContext attributeContext;

  @SuppressWarnings("unchecked")
  @Before
  public void init() throws Exception {
    called = new ObjectModel<Boolean>(false);
    valueListFactory = createNiceMock(IAttributeValueListFactory.class);
    attributeContext = createNiceMock(IAttributeContext.class);
    replay(valueListFactory, attributeContext);
  }

  @Test
  public void requestFocusDelegatesToComboBox() throws Exception {
    createStringComboBox(new JComboBox() {
      @Override
      public void requestFocus() {
        called.setValue(true);
      }
    }).requestFocus();
    assertTrue(called.getValue());
  }

  @Test
  public void setEditableDelegatesToComboBox() throws Exception {
    createStringComboBox(new JComboBox() {
      @Override
      public void setEditable(final boolean editable) {
        assertTrue(editable);
        called.setValue(true);
      }
    }).setEditable(true);
    assertTrue(called.getValue());
  }

  @Test
  public void isEditableDelegatesToComboBox() throws Exception {
    createStringComboBox(new JComboBox() {
      @Override
      public boolean isEditable() {
        called.setValue(true);
        return true;
      }
    }).isEditable();
    assertTrue(called.getValue());
  }

  @Test
  public void setEnabledDelegatesToComboBox() throws Exception {
    createStringComboBox(new JComboBox() {
      @Override
      public void setEnabled(final boolean enabled) {
        assertTrue(enabled);
        called.setValue(true);
      }
    }).setEnabled(true);
    assertTrue(called.getValue());
  }

  @Test
  public void getValueReturnsSelectedItemOfComboBox() throws Exception {
    final String value = createStringComboBox(new JComboBox() {
      @Override
      public Object getSelectedItem() {
        return "selectedItem"; //$NON-NLS-1$
      }
    }).getValue();
    assertThat(value, is("selectedItem")); //$NON-NLS-1$
  }

  @Test
  public void setValueSetsSelectedItemOnComboBox() throws Exception {
    createStringComboBox(new JComboBox() {
      @Override
      public void setSelectedItem(final Object selectedItem) {
        assertEquals("selectedItem", selectedItem); //$NON-NLS-1$
        called.setValue(true);
      }
    }).setValue("selectedItem"); //$NON-NLS-1$
    assertTrue(called.getValue());
  }

  @Test
  public void changeListenerGetsNotifiedOnSelection() throws Exception {
    final ChangeListener changeListener = createMock(ChangeListener.class);
    changeListener.stateChanged(isA(ChangeEvent.class));
    replay(changeListener);
    final JComboBox comboBox = new JComboBox();
    comboBox.addItem("value"); //$NON-NLS-1$
    createStringComboBox(comboBox).addChangeListener(changeListener);
    comboBox.setSelectedItem("value"); //$NON-NLS-1$
    verify(changeListener);
  }

  @Test
  public void getComponentReturnsGivenComboBox() throws Exception {
    final JComboBox comboBox = new JComboBox();
    assertSame(comboBox, createStringComboBox(comboBox).getComponent());
  }

  private StringComboBox createStringComboBox(final JComboBox comboBox) {
    return new StringComboBox(valueListFactory, attributeContext) {
      @Override
      protected JComboBox createComboBox() {
        return comboBox;
      }
    };
  }
}
