/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.util.GuiUtilities;

public class OptionalMessageButton implements IComponentContainer {

  private final JButton button;

  public OptionalMessageButton(final ObjectModel<IMessage> model) {
    button = new JButton();
    updateButton(model);
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateButton(model);
      }
    });
    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        MessageDialogFactory.showMessageDialog(GuiUtilities.getWindowFor(e), model.getValue());
      }
    });
  }

  private void updateButton(final ObjectModel<IMessage> model) {
    final IMessage message = model.getValue();
    if (message == null) {
      button.setVisible(false);
      return;
    }
    button.setIcon(MessageTypeUi.getInstance().getIcon(message.getType()));
    button.setText(message.getTitle());
    button.setVisible(true);
  }

  @Override
  public JComponent getContent() {
    return button;
  }
}