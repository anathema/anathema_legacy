package net.disy.commons.swing.dialog.wizard;

import java.awt.Component;

import net.disy.commons.swing.dialog.core.IDeprecatedGenericDialogConfiguration;

// Copyright (c) 2003 by disy Informationssysteme GmbH

/**
 * Interface for a wizard. A wizard maintains a list of wizard pages, stacked on top of each other
 * in card layout fashion.
 * 
 * The class Wizard provides an abstract implementation of this interface. However, clients are
 * also free to implement this interface if Wizard does not suit their needs. 
 * 
 * @see AbstractWizardConfiguration */
public interface IWizardConfiguration
    extends
    IBasicWizardConfiguration,
    IDeprecatedGenericDialogConfiguration {

  /** Adds any last-minute pages to this wizard.
   * This method is called just before the wizard becomes visible, to give the wizard the
   * opportunity to add any lazily created pages.*/
  public void addPages();

  /** Performs any actions appropriate in response to the user having pressed the Finish button, or
   * refuse if finishing now is not permitted. Normally this method is only called on the
   * container's current wizard. However if the current wizard is a nested wizard this method will
   * also be called on all wizards in its parent chain. Such parents may use this notification to
   * save state etc.
   * 
   * However, the value the parents return from this method is ignored.
   * @return true to indicate the finish request was accepted, and false to indicate that
   * the finish request was refused
   * @deprecated as of 29.03.2006 (sieroux), replaced by model/view separation
   */
  public boolean performFinish(Component parentComponent);

  /**
   * Returns whether the wizard container shall initialize the wizard pages after creating them from
   * the data. Usually this method will return true if the wizard is started with an already
   * preconfigured model and false otherwise.
   * @see IWizardPage#initializeFromData() 
   */
  /** @deprecated As of 10.12.2004 (gebhard)} */
  public boolean shallInitializePagesFromData();

  /** Returns the successor of the given page.
   * This method is typically called by a wizard page
   * @param page the page
   * @return the next page, or null if none */
  public IBasicWizardPage getNextPage(IWizardPage page);

  /** Returns the predecessor of the given page.
   * This method is typically called by a wizard page
   * @param page the page
   * @return the previous page, or null if none */

  public IBasicWizardPage getPreviousPage(IWizardPage page);
}