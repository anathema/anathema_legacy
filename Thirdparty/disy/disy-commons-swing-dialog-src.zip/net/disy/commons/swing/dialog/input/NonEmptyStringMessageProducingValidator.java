/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.StringUtilities;

public class NonEmptyStringMessageProducingValidator implements IMessageProducingValidator {
  private final ObjectModel<String> model;
  private final String errorMessageText;

  public NonEmptyStringMessageProducingValidator(
      final ObjectModel<String> model,
      final String errorMessageText) {
    this.model = model;
    this.errorMessageText = errorMessageText;
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return StringUtilities.isNullOrEmpty(model.getValue()) ? new BasicMessage(
        errorMessageText,
        MessageType.ERROR) : null;
  }
}
