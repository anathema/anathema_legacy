// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import net.disy.commons.swing.dialog.userdialog.AbstractUserDialog;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.message.IMessage;

// NOT_PUBLISHED
public class MessageUserDialog extends AbstractUserDialog {

  public MessageUserDialog(IMessage message) {
    this(message, DialogButtonConfiguration.createOnlyOkay());
  }

  public MessageUserDialog(IMessage message, IDialogButtonConfiguration buttonConfiguration) {
    super(new MessageDialogPage(message), buttonConfiguration);
  }

  public boolean isHeaderPanelVisible() {
    return false;
  }

  public boolean isModal() {
    return true;
  }
}