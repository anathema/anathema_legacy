//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.AWTEvent;
import java.awt.ActiveEvent;
import java.awt.Component;
import java.awt.Container;
import java.awt.EventQueue;
import java.awt.MenuComponent;
import java.awt.Window;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class SwingFrame implements ISwingFrameOrDialog {

  private final JFrame frame;
  private boolean modal = false;

  public SwingFrame(JFrame frame) {
    Ensure.ensureArgumentNotNull(frame);
    this.frame = frame;
  }

  public void setTitle(String title) {
    frame.setTitle(title);
  }

  public JRootPane getRootPane() {
    return frame.getRootPane();
  }

  public void pack() {
    frame.pack();
  }

  public void setModal(boolean modal) {
    this.modal = modal;
  }

  public Container getContentPane() {
    return frame.getContentPane();
  }

  public void setDefaultCloseOperation(int closeOperation) {
    frame.setDefaultCloseOperation(closeOperation);
  }

  public void addWindowListener(WindowListener windowListener) {
    frame.addWindowListener(windowListener);
  }

  public void dispose() {
    setVisible(false);
    frame.dispose();
  }

  public void validate() {
    frame.validate();
  }

  public void repaint() {
    frame.repaint();
  }

  public Window getWindow() {
    return frame;
  }

  public void setResizable(boolean resizable) {
    frame.setResizable(resizable);
  }

  public void show() {
    setVisible(true);
  }

  public void setVisible(boolean visible) {
    frame.setVisible(visible);
    if (!modal) {
      return;
    }
    if (visible) {
      startModal();
    }
    else {
      stopModal();
    }
  }

  private synchronized void startModal() {
    try {
      if (SwingUtilities.isEventDispatchThread()) {
        EventQueue theQueue = frame.getToolkit().getSystemEventQueue();
        while (isVisible()) {
          AWTEvent event = theQueue.getNextEvent();
          Object source = event.getSource();
          if (event instanceof ActiveEvent) {
            ((ActiveEvent) event).dispatch();
          }
          else if (source instanceof Component) {
            ((Component) source).dispatchEvent(event);
          }
          else if (source instanceof MenuComponent) {
            ((MenuComponent) source).dispatchEvent(event);
          }
          else {
            System.err.println("Unable to dispatch: " + event);
          }
        }
      }
      else {
        while (isVisible()) {
          wait();
        }
      }
    }
    catch (InterruptedException ignored) {
      //nothing to do
    }
  }

  private synchronized void stopModal() {
    notifyAll();
  }

  public boolean isVisible() {
    return frame.isVisible();
  }
}