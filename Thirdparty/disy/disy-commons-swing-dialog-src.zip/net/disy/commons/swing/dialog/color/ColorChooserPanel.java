/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;
import javax.swing.colorchooser.AbstractColorChooserPanel;
import javax.swing.event.ChangeEvent;

import net.disy.commons.core.model.listener.IChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutUtilities;

public class ColorChooserPanel {

  private final Color initialColor;
  private final JPanel panel;
  private final ColorModel colorModel;

  public ColorChooserPanel(final ColorModel colorModel, final boolean hasTransparencyChangePanel) {
    Ensure.ensureArgumentNotNull(colorModel);
    this.initialColor = colorModel.getColor();
    this.colorModel = colorModel;

    final JComponent mainContent = createMainContent();

    final JPanel additionalControls = createAdditionalControls(hasTransparencyChangePanel);
    additionalControls.setBorder(new EmptyBorder(6, 5, 6, 5));

    panel = new JPanel();
    panel.setLayout(new BorderLayout(LayoutUtilities.getComponentGroupsSpacing(), LayoutUtilities
        .getComponentGroupsSpacing()));
    panel.add(mainContent, BorderLayout.CENTER);
    panel.add(additionalControls, BorderLayout.SOUTH);
  }

  private JPanel createAdditionalControls(final boolean hasTransparencyChangePanel) {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    if (hasTransparencyChangePanel) {
      builder.add(new TransparencyBarPanel(this.colorModel));
    }
    builder.add(new ColorPreviewPanel(this.colorModel));
    final JPanel additionalContent = builder.createPanel();
    return additionalContent;
  }

  private JComponent createMainContent() {
    final JColorChooser colorChooser = new JColorChooser();
    colorChooser.setColor(colorModel.getColor());
    colorChooser.getSelectionModel().addChangeListener(new javax.swing.event.ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent changeEvent) {
        final Color plainColor = colorChooser.getColor();
        final Color color = new Color(plainColor.getRed(), plainColor.getGreen(), plainColor
            .getBlue(), colorModel.getColor().getAlpha());
        colorModel.setColor(color);
      }
    });
    colorModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        colorChooser.setColor(colorModel.getColor());
      }
    });

    final JTabbedPane tabPane = new JTabbedPane();
    final AbstractColorChooserPanel[] oldPanels = colorChooser.getChooserPanels();
    final GridBagConstraints constraints = new GridBagConstraints();
    constraints.gridwidth = 1;
    constraints.gridheight = 1;
    final GridBagLayout layout = new GridBagLayout();
    for (int i = 0; i < oldPanels.length; i++) {
      final JPanel layoutPanel = new JPanel();
      layoutPanel.setLayout(layout);
      layout.setConstraints(oldPanels[i], constraints);
      layoutPanel.add(oldPanels[i]);
      tabPane.addTab(oldPanels[i].getDisplayName(), layoutPanel);
    }
    return tabPane;
  }

  public JComponent getContent() {
    return panel;
  }

  public void resetColor() {
    colorModel.setColor(initialColor);
  }
}