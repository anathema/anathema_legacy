package net.disy.commons.swing.dialog.file;

import java.io.File;

import javax.swing.filechooser.FileSystemView;

/**
 * @author Markus Gebhard
 */
public interface IFileSystemContext {

  public FileSystemView getFileSystemView();
  
  public void setBusy(boolean busy);

  public void registerNode(File file, FolderNode node);
}
