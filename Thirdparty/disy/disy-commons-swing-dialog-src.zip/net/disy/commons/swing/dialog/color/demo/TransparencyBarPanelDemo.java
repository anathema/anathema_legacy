/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color.demo;

import org.junit.runner.RunWith;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.TransparencyBarPanel;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class TransparencyBarPanelDemo extends SwingDemoCase {

  public void demo() {
    final GridDialogPanelBuilder panel = new GridDialogPanelBuilder();
    panel.add(new TransparencyBarPanel(new ColorModel()));
    show(panel.createPanel());
  }
}