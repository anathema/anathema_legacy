//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.suite;

import junit.framework.Test;
import junit.framework.TestSuite;
import junit.textui.ResultPrinter;
import junit.textui.TestRunner;

import de.jdemo.junit.Demo2TestConverter;

// NOT_PUBLISHED
public class AllDisyCommonsSwingDialogTests {

  public static void main(String[] args) {
    TestRunner runner = new TestRunner(new ResultPrinter(System.out) {
      public void startTest(Test test) {
        getWriter().println(test);
      }
    });
    while (true)
      runner.doRun(AllDisyCommonsSwingDialogTests.suite());
  }

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for net.disy.commons.swing.dialog.suite"); //$NON-NLS-1$
    suite.addTest(Demo2TestConverter.createTest(AllDisyCommonsSwingDialogDemos.suite()));
    suite.addTest(net.disy.commons.swing.dialog.progress.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.dialog.message.test.AllTests.suite());
    suite.addTest(net.disy.commons.swing.dialog.file.test.AllTests.suite());    
    //$JUnit-BEGIN$
    //$JUnit-END$
    return suite;
  }
}
