/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.combobox.demo;

import net.disy.commons.swing.dialog.input.text.combobox.AbstractFilterComboBoxConfiguration;
import net.disy.commons.swing.ui.IObjectUi;

@SuppressWarnings("nls")
public class DemoFilterComboBoxConfiguration
    extends
    AbstractFilterComboBoxConfiguration<DemoColorItem> {
  @Override
  public String getToolTipText() {
    return "Please type a color name";
  }

  @Override
  public IObjectUi<DemoColorItem> getObjectUi() {
    return new DemoColorItemUi();
  }

  @Override
  public String getNoResultLabelText() {
    return "No hits";
  }
}