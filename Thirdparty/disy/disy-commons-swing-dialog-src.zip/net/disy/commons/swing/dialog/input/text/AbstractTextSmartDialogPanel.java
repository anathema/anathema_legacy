/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.swing.dialog.input.object.AbstractObjectSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.component.IStringAttributeInputComponentFactory;

public abstract class AbstractTextSmartDialogPanel extends AbstractObjectSmartDialogPanel<String> {

  public AbstractTextSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory<?> componentFactory,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    super(label, toolTipText, stringModel, componentFactory, validator, grabSpace);
  }
}