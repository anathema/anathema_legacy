/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.labeled;

import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.ui.AbstractObjectUi;

public class LabeledValueUi extends AbstractObjectUi<ILabeledValue> {

  private static final String NOTHING_CHOSEN_LABEL = DisyCommonsSwingMessages
      .getString("ToStringUi.DefaultNothingChosenLabel"); //$NON-NLS-1$

  private final String nullValueText;

  public LabeledValueUi() {
    this(NOTHING_CHOSEN_LABEL);
  }

  public LabeledValueUi(final String nullValueText) {
    this.nullValueText = nullValueText;
  }

  @Override
  public String getLabel(final ILabeledValue value) {
    if (value == null) {
      return nullValueText;
    }
    return value.getLabel();
  }
}