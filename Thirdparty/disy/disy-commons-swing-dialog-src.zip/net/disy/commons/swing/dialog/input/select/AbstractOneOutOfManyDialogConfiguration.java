//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.list.ListSelectionMode;

// NOT_PUBLISHED
public abstract class AbstractOneOutOfManyDialogConfiguration
    implements
    ISomeOutOfManyDialogConfiguration {

  //@Overrides
  public String getDescription() {
    return null;
  }
  
  //@Overrides
  public ISmartDialogPanel[] createAdditionalPanels(ObjectSelectionModel selectionModel) {
    return new ISmartDialogPanel[0];
  }
  
  public ListSelectionMode getListSelectionMode() {
    return ListSelectionMode.SINGLE_SELECTION;
  }
}