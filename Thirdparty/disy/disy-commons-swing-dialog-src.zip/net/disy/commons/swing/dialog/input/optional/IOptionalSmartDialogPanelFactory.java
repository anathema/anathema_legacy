/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional;

import java.util.Date;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;

public interface IOptionalSmartDialogPanelFactory {

  public IOptionalSmartDialogPanel createBytePanel(final ObjectModel<Byte> model, boolean mandatory);

  public IOptionalSmartDialogPanel createDatePanel(
      final ObjectModel<Date> model,
      boolean mandatory,
      final String formatPattern);

  public IOptionalSmartDialogPanel createDoublePanel(
      final ObjectModel<Double> model,
      boolean mandatory);

  public IOptionalSmartDialogPanel createIntegerPanel(
      final ObjectModel<Integer> model,
      boolean mandatory);

  public IOptionalSmartDialogPanel createLongPanel(final ObjectModel<Long> model, boolean mandatory);

  public IOptionalSmartDialogPanel createShortPanel(
      final ObjectModel<Short> model,
      boolean mandatory);

  public IOptionalSmartDialogPanel createStringPanel(
      final ObjectModel<String> model,
      boolean mandatory,
      final IAttributeValueListFactory<String> valueListFactory,
      final IAttributeContext attributeContext);

  public IOptionalSmartDialogPanel createBooleanPanel(
      final ObjectModel<Boolean> model,
      boolean mandatory);

}