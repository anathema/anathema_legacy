/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.builder.test;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.builder.DialogConfigurationBuilder;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

import org.junit.Before;
import org.junit.Test;

public class DialogConfigurationBuilderTest {

  private DialogConfigurationBuilder builder;

  @Before
  public void createUnconfiguredDialogConfiguration() throws Exception {
    builder = new DialogConfigurationBuilder();
  }

  @Test
  public void unconfiguredConfiguratonHasVisibleHeaderPanel() throws Exception {
    assertTrue(builder.create(null).getHeaderPanelConfiguration().isHeaderPanelVisible());
  }

  @Test
  public void configuredHeaderPanelIsNotVisible() throws Exception {
    assertFalse(builder
        .invisibleHeaderPanel()
        .create(null)
        .getHeaderPanelConfiguration()
        .isHeaderPanelVisible());
  }

  @Test
  public void configuredHeaderPanelIsSetFalse() throws Exception {
    final IDialogConfiguration<IDialogPage> configuration = builder.invisibleHeaderPanel().create(
        null);
    assertFalse(configuration.getHeaderPanelConfiguration().isHeaderPanelVisible());
  }

  @Test
  public void configuredHeaderPanelIsSetFalseForCreationWithButtonConfiguration() throws Exception {
    final IDialogConfiguration<IDialogPage> configuration = builder.invisibleHeaderPanel().create(
        null,
        DialogButtonConfigurationFactory.createNone());
    assertFalse(configuration.getHeaderPanelConfiguration().isHeaderPanelVisible());
  }
}