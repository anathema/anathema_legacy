//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.progress.test;

import junit.framework.TestCase;

import net.disy.commons.swing.dialog.progress.InternalProgressDialog;

// NOT_PUBLISHED
public class InternalProgressDialogTest extends TestCase {

  public void testAddTaskLabelEllipsis() {
    assertEquals("", InternalProgressDialog.addTaskLabelEllipsis("")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("test...", InternalProgressDialog.addTaskLabelEllipsis("test")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("bla...", InternalProgressDialog.addTaskLabelEllipsis("bla...")); //$NON-NLS-1$ //$NON-NLS-2$
  }
}