/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.test;

import static org.junit.Assert.*;

import javax.swing.JFrame;

import net.disy.commons.swing.dialog.progress.InternalProgressDialog;
import net.disy.commons.swing.dialog.progress.InternalProgressDialogModel;
import net.disy.commons.swing.dialog.progress.ProgressMonitorComponent;

import org.junit.Ignore;
import org.junit.Test;

public class InternalProgressDialogTest {

  private static Thread createDisposeThread(final InternalProgressDialog progressDialog) {
    final Thread thread = new Thread() {
      @Override
      public void run() {
        progressDialog.dispose();
      }
    };
    return thread;
  }

  private static Thread createShowThread(final InternalProgressDialog progressDialog) {
    final Thread showThread = new Thread() {
      @Override
      public void run() {
        progressDialog.show();
      }
    };
    return showThread;
  }

  @SuppressWarnings("deprecation")
  private static void stopThreads(final Thread... threads) {
    for (final Thread thread : threads) {
      thread.stop();
    }
  }

  @Test
  @Ignore
  public void disposeDoesNotBlockWhenAlreadyClosedByParent() throws Exception {
    final JFrame parent = new JFrame();
    parent.setVisible(true);
    final InternalProgressDialog progressDialog = new InternalProgressDialog(
        parent,
        "title", new InternalProgressDialogModel()); //$NON-NLS-1$
    final Thread showThread = createShowThread(progressDialog);
    final Thread disposeThread = createDisposeThread(progressDialog);
    try {
      showThread.start();
      while (!parent.isVisible()) {
        Thread.yield();
      }
      parent.setVisible(false);
      disposeThread.start();
      disposeThread.join(10000);
      assertFalse(disposeThread.isAlive());
    }
    finally {
      stopThreads(showThread, disposeThread);
    }
  }

  @Test
  public void testAddTaskLabelEllipsis() {
    assertEquals("", ProgressMonitorComponent.addTaskLabelEllipsis("")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("test...", ProgressMonitorComponent.addTaskLabelEllipsis("test")); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("bla...", ProgressMonitorComponent.addTaskLabelEllipsis("bla...")); //$NON-NLS-1$ //$NON-NLS-2$
  }
}