// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

//NOT_PUBLISHED
public interface IRequestFinishListener {

  public void requestFinish();

}
