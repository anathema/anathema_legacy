//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutDialogConfiguration;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.userdialog.buttons.AbstractDialogButtonConfiguration;

// NOT_PUBLISHED
public class FoldOutMessageDialogConfiguration extends AbstractFoldOutDialogConfiguration {

  public FoldOutMessageDialogConfiguration(IMessage message, IFoldOutPage foldOutPage) {
    super(new MessageDialogPage(message), foldOutPage, new AbstractDialogButtonConfiguration() {
      @Override
      public boolean isCancelButtonAvailable() {
        return false;
      }
    });
  }

  @Override
  public boolean isHeaderPanelVisible() {
    return false;
  }
}