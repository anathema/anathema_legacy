// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;
import java.util.Comparator;

import javax.swing.filechooser.FileSystemView;

//NOT_PUBLISHED
public class FileComparator implements Comparator {
  private final FileSystemView fileSystemView;

  public FileComparator(FileSystemView fileSystemView) {
    this.fileSystemView = fileSystemView;
  }

  public int compare(Object o1, Object o2) {
    File file1 = (File) o1;
    File file2 = (File) o2;
    if (file1.isDirectory() && !file2.isDirectory()) {
      return -1;
    }
    if (!file1.isDirectory() && file2.isDirectory()) {
      return 1;
    }
    return fileSystemView.getSystemDisplayName(file1).compareToIgnoreCase(
        fileSystemView.getSystemDisplayName(file2));
  }
}