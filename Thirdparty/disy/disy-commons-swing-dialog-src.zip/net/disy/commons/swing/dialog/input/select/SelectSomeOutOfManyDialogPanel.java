// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import java.awt.BorderLayout;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectSelectionModel;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.list.IListMouseHandler;
import net.disy.commons.swing.list.JListMouseListener;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

//NOT_PUBLISHED
public class SelectSomeOutOfManyDialogPanel extends AbstractSmartDialogPanel {
  private final JList list;
  private final ISomeOutOfManyDialogPanelConfiguration configuration;
  private final ObjectSelectionModel selectedItemsModel;

  public SelectSomeOutOfManyDialogPanel(
      final ObjectSelectionModel selectedItemsModel,
      ISomeOutOfManyDialogPanelConfiguration configuration) {
    this.selectedItemsModel = selectedItemsModel;
    this.configuration = configuration;
    list = new JList(configuration.getItems());
    list.setCellRenderer(new ObjectUiListCellRenderer(configuration.getObjectUi()));
    list.getSelectionModel().setSelectionMode(
        configuration.getListSelectionMode().getListSelectionMode());

    list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
          selectedItemsModel.setValues(list.getSelectedValues());
        }
      }
    });

    selectedItemsModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateListSelection();
      }
    });
    updateListSelection();

    JListMouseListener.attachTo(list, new IListMouseHandler() {
      public void handleDoubleClick(Object[] arg0) {
        fireRequestFinish();
      }

      public void handleContextMenuClick(Object[] arg0) {
        //nothing to do
      }
    });
  }

  private void updateListSelection() {
    list.getSelectionModel().setValueIsAdjusting(true);
    list.setSelectedIndices(selectedItemsModel.getSelectedIndices());
    list.getSelectionModel().setValueIsAdjusting(false);
  }

  public void addChangeListener(final ChangeListener listener) {
    list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        listener.stateChanged(new ChangeEvent(SelectSomeOutOfManyDialogPanel.this));
      }
    });
  }

  public IBasicMessage createOptionalCurrentMessage() {
    if (getSelectedItems().length == 0) {
      return new BasicMessage(configuration.getNoItemSelectedErrorMessageText(), MessageType.ERROR);
    }

    return null;
  }

  public int getColumnCount() {
    return 1;
  }

  public void fillInto(JPanel panel, int columnCount) {
    GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_BOTH);
    layoutData.setHorizontalSpan(columnCount);
    panel.add(createMainPanel(), layoutData);
  }

  private JPanel createMainPanel() {
    JPanel mainPanel = new JPanel(new BorderLayout());
    String listTitle = configuration.getDescription();
    if (listTitle != null) {
      mainPanel.add(new JLabel(listTitle), BorderLayout.NORTH);
    }
    mainPanel.add(new JScrollPane(list), BorderLayout.CENTER);
    return mainPanel;
  }

  public Object[] getSelectedItems() {
    return list.getSelectedValues();
  }

  public ObjectSelectionModel getSelectedItemModel() {
    return selectedItemsModel;
  }

  public void requestFocus() {
    list.requestFocus();
  }
}
