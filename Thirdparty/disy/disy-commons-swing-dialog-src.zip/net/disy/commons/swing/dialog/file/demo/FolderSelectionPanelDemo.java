package net.disy.commons.swing.dialog.file.demo;

import java.io.File;

import net.disy.commons.core.io.FileModel;
import net.disy.commons.swing.dialog.file.FolderSelectionPanel;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class FolderSelectionPanelDemo extends SwingDemoCase {

  public void demo() {
    show(new FolderSelectionPanel(new FileModel()).getContent());
  }

  public void demoFolderSelectionPanelWithSelectedPath() {
    FolderSelectionPanel folderSelectionPanel = new FolderSelectionPanel(new FileModel());
    show(folderSelectionPanel.getContent());
    folderSelectionPanel.setSelectedFolder(new File("./")); //$NON-NLS-1$
  }

  public void demoFolderSelectionPanelWithExplicitRoot() {
    FolderSelectionPanel panel = new FolderSelectionPanel(new FileModel(), new File[]{ new File(
        "./src") }); //$NON-NLS-1$
    show(panel.getContent());
  }
}