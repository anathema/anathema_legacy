//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message.demo;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.message.MessageDialogPage;
import net.disy.commons.swing.dialog.userdialog.DialogPageControl;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class MessageDialogPageDemo extends SwingDemoCase {
  public void demo() {
    show(new DialogPageControl(new MessageDialogPage(new Message(
        "An error has occured while doing some things and stuff.", //$NON-NLS-1$
        MessageType.ERROR))).getContent());
  }
}
