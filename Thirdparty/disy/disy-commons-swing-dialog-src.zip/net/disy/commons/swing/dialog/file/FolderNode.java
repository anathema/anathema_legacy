package net.disy.commons.swing.dialog.file;

import java.io.File;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * @author Markus Gebhard
 */
public class FolderNode extends DefaultMutableTreeNode {

  private final IFileSystemContext context;

  public FolderNode(IFileSystemContext context, File file) {
    super(file);
    context.registerNode(file, this);
    this.context = context;
  }

  public File getFile() {
    return (File) getUserObject();
  }

  public boolean getAllowsChildren() {
    return true;
  }

  public int getChildCount() {
    asureChildrenLoaded();
    return super.getChildCount();
  }

  
  public boolean isLeaf() {
    if (children!=null) {
      return children.size()==0;
    }
    if (context.getFileSystemView().isFloppyDrive(getFile())) {
      return false;
    }
    return getChildCount()==0;
  }
  
  private void asureChildrenLoaded() {
    if (children != null) {
      return;
    }
    context.setBusy(true);
    try {
      children = new Vector();
      File[] childFiles = context.getFileSystemView().getFiles(getFile(), true);
      Arrays.sort(childFiles, new FileComparator(context.getFileSystemView()));
      for (int i = 0; i < childFiles.length; i++) {
        if (childFiles[i].isDirectory()) {
          FolderNode node = new FolderNode(context, childFiles[i]);
          children.add(node);
          node.setParent(this);
        }
      }
    }
    finally {
      context.setBusy(false);
    }
  }
}