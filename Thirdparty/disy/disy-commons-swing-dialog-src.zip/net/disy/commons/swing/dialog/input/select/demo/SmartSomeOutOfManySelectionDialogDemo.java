//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select.demo;

import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.select.SmartSomeOutOfManySelectionDialog;
import net.disy.commons.swing.list.ListSelectionMode;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SmartSomeOutOfManySelectionDialogDemo extends SwingDemoCase {

  public void demoSimpleSmartOneOutOfManySelectionDialog() {
    show(SmartSomeOutOfManySelectionDialog.createDemoDialog(
        createParentComponent(),
        new DemoSomeOutOfManyDialogConfiguration()).getDialog().getWindow());
  }

  public void demoSmartOneOutOfManySelectionDialogWithAdditionalPanels() {
    show(SmartSomeOutOfManySelectionDialog.createDemoDialog(
        createParentComponent(),
        new DemoSomeOutOfManyDialogConfiguration() {
          //@Overrides
          @Override
          public ISmartDialogPanel[] createAdditionalPanels(FixedOptionsObjectSelectionModel selectionModel) {
            return createDialogPanels(selectionModel);
          }
        }).getDialog().getWindow());
  }

  public void demoSimpleSmartSomeOutOfManySelectionDialog() {
    show(SmartSomeOutOfManySelectionDialog.createDemoDialog(
        createParentComponent(),
        new DemoSomeOutOfManyDialogConfiguration() {
          @Override
          public ListSelectionMode getListSelectionMode() {
            return ListSelectionMode.MULTIPLE_INTERVAL_SELECTION;
          }
        }).getDialog().getWindow());
  }

  public void demoSmartSomeOutOfManySelectionDialogWithAdditionalPanels() {
    show(SmartSomeOutOfManySelectionDialog.createDemoDialog(
        createParentComponent(),
        new DemoSomeOutOfManyDialogConfiguration() {
          //@Overrides
          @Override
          public ISmartDialogPanel[] createAdditionalPanels(FixedOptionsObjectSelectionModel selectionModel) {
            return createDialogPanels(selectionModel);
          }

          @Override
          public ListSelectionMode getListSelectionMode() {
            return ListSelectionMode.MULTIPLE_INTERVAL_SELECTION;
          }
        }).getDialog().getWindow());
  }

  private ISmartDialogPanel[] createDialogPanels(FixedOptionsObjectSelectionModel selectionModel) {
    return new ISmartDialogPanel[]{
        new AdjustingToSelectionDialogPanel("Selected Color:", selectionModel), //$NON-NLS-1$
        new TextFieldDialogPanel("Name:"), }; //$NON-NLS-1$
  }

  private final class TextFieldDialogPanel extends AbstractTextFieldSmartDialogPanel {
    private  JTextField textField;

    public TextFieldDialogPanel(String label) {
      super(label, new FixedOptionsObjectSelectionModel(new Object[0]));
    }

    @Override
    protected JTextField doCreateTextField() {
      textField = new JTextField();
      return textField;
    }

    @Override
    public IBasicMessage createOptionalCurrentMessage() {
      if (textField.getText().length() == 0) {
        return new BasicMessage("The name field is empty. Please enter a name for the color.", //$NON-NLS-1$
            MessageType.ERROR);
      }
      if (textField.getText().length() > 30) {
        return new BasicMessage(
            "The specified name for the color is discouraged: Names should not be longer than 30 characters.", //$NON-NLS-1$
            MessageType.WARNING);
      }
      return null;
    }
  }

  private final class AdjustingToSelectionDialogPanel extends AbstractTextFieldSmartDialogPanel {
    public AdjustingToSelectionDialogPanel(String label, FixedOptionsObjectSelectionModel selectedItemModel) {
      super(label, selectedItemModel);
    }

    @Override
    protected JTextField doCreateTextField() {
      final JTextField textField = new JTextField();
      textField.setEditable(false);
      getSelectedItemsModel().addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          adjustTextFieldToSelectedColor(textField);
        }
      });
      adjustTextFieldToSelectedColor(textField);
      return textField;
    }

    private void adjustTextFieldToSelectedColor(final JTextField textField) {
      Color selectedColor = (Color) getSelectedItemsModel().getFirstSelectedValue();
      textField.setText(selectedColor == null ? "" : selectedColor.toString()); //$NON-NLS-1$
    }
  }
}