/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JComponent;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.component.IComponentContainer;

public abstract class AbstractColorChoosingComponent extends AbstractActionComponent
    implements
    IComponentContainer {

  private final static Font FONT = new Font(Font.DIALOG, Font.PLAIN, 10);

  private final ColorModel model;
  private final IColorChooserConfiguration configuration;
  private final JComponent content;
  private boolean editable = true;

  public AbstractColorChoosingComponent(
      final ColorModel model,
      final IColorChooserConfiguration configuration) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(configuration);
    this.model = model;
    this.configuration = configuration;
    //TODO 01.10.2004 (gebhard): Listener wird nie mehr entfernt. An setVisible() koppeln?
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateView();
      }
    });
    content = createContent();
    updateView();
  }

  protected abstract JComponent createContent();

  public AbstractColorChoosingComponent(final ColorModel model) {
    this(model, new DefaultColorChooserConfiguration());
  }

  public void setEditable(final boolean editable) {
    this.editable = editable;
  }

  protected final void performColorChooseDialog() {
    if (!editable) {
      return;
    }
    final Color newColor = ColorChooserDialog.showDialog(getContent(), configuration, model
        .getColor());
    if (newColor != null) {
      model.setColor(newColor);
    }
    fireActionEvent();
  }

  public ColorModel getModel() {
    return model;
  }

  protected final void paintColorRectangle(
      final Graphics g,
      final int x,
      final int y,
      final Dimension size,
      final boolean enabled) {
    paintColorRectangle(model.getColor(), g, x, y, size, enabled);
  }

  private final void paintColorRectangle(
      final Color rectColor,
      final Graphics g,
      final int x,
      final int y,
      final Dimension size,
      final boolean enabled) {
    final int h = size.height;
    final int w = size.width;
    final Color oldColor = g.getColor();
    g.setFont(FONT);
    g.setColor(Color.white);
    g.fillRect(x + 1, y + 1, w - 2, h - 2);
    if (configuration.isTransparencyEnabled()) {
      g.setColor(SwingColors.getTextAreaForegroundColor());
      final int alphaPercentage = (100 - (int) Math.round(getModel().getColor().getAlpha() / 2.55));
      g.drawString(alphaPercentage + " %", x + w / 2 - 10, y + h / 2 + 4); //$NON-NLS-1$
    }
    if (enabled) {
      g.setColor(rectColor);
    }
    else {
      g.setColor(SwingColors.getControlColor());
    }
    g.fillRect(x + 1, y + 1, w - 2, h - 2);
    if (enabled) {
      g.setColor(Color.black);
    }
    else {
      g.setColor(SwingColors.getControlShadowColor());
    }
    g.drawRect(x, y, w - 1, h - 1);
    g.setColor(oldColor);
  }

  protected void updateView() {
    content.repaint();
  }

  @Override
  public JComponent getContent() {
    return content;
  }

  public final void setEnabled(final boolean enabled) {
    content.setEnabled(enabled);
  }
}