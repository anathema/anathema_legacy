//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import net.disy.commons.swing.dialog.foldout.AbstractFoldOutUserDialog;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.message.IMessage;

// NOT_PUBLISHED
public class FoldOutMessageUserDialog extends AbstractFoldOutUserDialog {

  public FoldOutMessageUserDialog(IMessage message, IFoldOutPage foldOutPage) {
    super(new MessageDialogPage(message), foldOutPage);
  }

  public boolean performOk() {
    return true;
  }

  public boolean isHeaderPanelVisible() {
    return false;
  }

  public boolean isModal() {
    return true;
  }
  
  public boolean isCancelAvailable() {
    return false;
  }
}