/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.animation.demo;

import java.awt.Frame;

import javax.swing.JDialog;
import javax.swing.JLabel;

import net.disy.commons.swing.dialog.animation.AnimatedCompositeComponent;

import de.jdemo.framework.PlainDemoCase;

public class AnimatedCompositeComponentVisibilityDemo extends PlainDemoCase {
  public void demoSetOverlaidComponentWhenVisible() throws Exception {
    final AnimatedCompositeComponent component = new AnimatedCompositeComponent(new JLabel(
        "BaseComponent"), new JLabel("OverlaidComponent")); //$NON-NLS-1$ //$NON-NLS-2$
    final JDialog dialog = new JDialog((Frame) null, false);
    dialog.getContentPane().add(component);
    dialog.pack();
    dialog.setVisible(true);
    component.setOverlaidComponentVisible(true);
  }

  public void demoSetOverlaidComponentWhenInvisible() throws Exception {
    final AnimatedCompositeComponent component = new AnimatedCompositeComponent(new JLabel(
        "BaseComponent"), new JLabel("OverlaidComponent")); //$NON-NLS-1$ //$NON-NLS-2$
    component.setOverlaidComponentVisible(true);
    final JDialog dialog = new JDialog((Frame) null, false);
    dialog.getContentPane().add(component);
    dialog.pack();
    dialog.setVisible(true);
  }
}
