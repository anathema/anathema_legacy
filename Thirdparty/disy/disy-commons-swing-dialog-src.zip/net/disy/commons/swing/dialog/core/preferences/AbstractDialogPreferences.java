/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core.preferences;

import java.awt.Rectangle;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.preferences.IPreferences;

public abstract class AbstractDialogPreferences implements IDialogPreferences {

  private static final String LOCATION_X = "X"; //$NON-NLS-1$
  private static final String LOCATION_Y = "Y"; //$NON-NLS-1$
  private static final String SIZE_WIDTH = "WIDTH"; //$NON-NLS-1$
  private static final String SIZE_HEIGHT = "HEIGHT"; //$NON-NLS-1$
  private final IPreferences locationPreferences;
  private final IPreferences sizePreferences;

  public AbstractDialogPreferences(final IPreferences preferences) {
    this(preferences, preferences);
  }

  public AbstractDialogPreferences(final IPreferences locationPreferences, IPreferences sizePreferences) {
    Ensure.ensureArgumentNotNull(locationPreferences);
    Ensure.ensureArgumentNotNull(sizePreferences);
    this.locationPreferences = locationPreferences;
    this.sizePreferences = sizePreferences;
  }

  @Override
  public Rectangle getBounds() {
    final int x = locationPreferences.getInt(LOCATION_X, -1);
    final int y = locationPreferences.getInt(LOCATION_Y, -1);
    final int width = sizePreferences.getInt(SIZE_WIDTH, -1);
    final int height = sizePreferences.getInt(SIZE_HEIGHT, -1);
    if (x == -1 || y == -1 || width == -1 || height == -1) {
      return null;
    }
    return new Rectangle(x, y, width, height);
  }

  @Override
  public void setBounds(final Rectangle rectangle) {
    final int x = rectangle.x;
    final int y = rectangle.y;
    final int width = rectangle.width;
    final int height = rectangle.height;
    if (width == 0 || height == 0) {
      return;
    }
    locationPreferences.putInt(LOCATION_X, x, -1);
    locationPreferences.putInt(LOCATION_Y, y, -1);
    locationPreferences.flush();
    sizePreferences.putInt(SIZE_WIDTH, width, -1);
    sizePreferences.putInt(SIZE_HEIGHT, height, -1);
    sizePreferences.flush();
  }
}