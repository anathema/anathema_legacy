/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

/** @deprecated As of 14.06.2011 (gebhard), replaced by {@link ListSelectionDialogPage} */
@Deprecated
public class SelectSomeOutOfManyDialogPage<T> extends ListSelectionDialogPage<T> {

  public SelectSomeOutOfManyDialogPage(final ISomeOutOfManyDialogConfiguration<T> configuration) {
    super(configuration);
  }
}