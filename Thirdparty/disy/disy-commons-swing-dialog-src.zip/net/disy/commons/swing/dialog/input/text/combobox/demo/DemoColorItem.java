//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox.demo;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class DemoColorItem {

  public static List<DemoColorItem> createDemoItems() {
    final DemoColorItem[] rawItems = new DemoColorItem[]{ new DemoColorItem("Red", Color.RED), //$NON-NLS-1$
        new DemoColorItem("Green", Color.GREEN), //$NON-NLS-1$
        new DemoColorItem("Blue", Color.BLUE), //$NON-NLS-1$
        new DemoColorItem("Yellow", Color.YELLOW), //$NON-NLS-1$
        new DemoColorItem("Cyan", Color.CYAN), //$NON-NLS-1$
        new DemoColorItem("Dark gray", Color.DARK_GRAY), //$NON-NLS-1$
        new DemoColorItem("Gray", Color.GRAY), //$NON-NLS-1$
        new DemoColorItem("Light gray", Color.LIGHT_GRAY), //$NON-NLS-1$
        new DemoColorItem("Magenta", Color.MAGENTA), //$NON-NLS-1$
        new DemoColorItem("Orange", Color.ORANGE), //$NON-NLS-1$
        new DemoColorItem("Pink", Color.PINK), //$NON-NLS-1$
        new DemoColorItem("White", Color.WHITE), }; //$NON-NLS-1$
    final List<DemoColorItem> items = new ArrayList<DemoColorItem>();
    for (final DemoColorItem item : rawItems) {
      items.add(item);
      items.add(new DemoColorItem(item.getName() + " - brighter", item.getColor().brighter())); //$NON-NLS-1$
      items.add(new DemoColorItem(item.getName() + " - darker", item.getColor().darker())); //$NON-NLS-1$
    }
    return items;
  }

  private final String name;
  private final Color color;

  public DemoColorItem(final String name, final Color color) {
    Ensure.ensureArgumentNotNull(name);
    Ensure.ensureArgumentNotNull(color);
    this.name = name;
    this.color = color;
  }

  @Override
  public int hashCode() {
    return color.hashCode();
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof DemoColorItem)) {
      return false;
    }
    final DemoColorItem other = (DemoColorItem) obj;
    return name.equals(other.name) && color.equals(other.color);
  }

  public String getName() {
    return name;
  }

  public Color getColor() {
    return color;
  }
}