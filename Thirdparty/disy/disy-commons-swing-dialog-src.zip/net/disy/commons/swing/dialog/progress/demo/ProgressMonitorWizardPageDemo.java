/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.demo;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPage;
import net.disy.commons.swing.dialog.wizard.IWizardPageFactory;
import net.disy.commons.swing.dialog.wizard.demo.AbstractWizardDemoCase;

import de.jdemo.annotation.Demo;

public class ProgressMonitorWizardPageDemo extends AbstractWizardDemoCase {
  @Demo
  public void unknownWork() {
    show(new IWizardPageFactory() {
      @Override
      public IWizardPage createPage(final IWizardConfiguration configuration) {
        return new DemoWizardProgressMonitorPage("A ProgressMonitor Wizard Page", //$NON-NLS-1$
            "Progress Bar", //$NON-NLS-1$
            "I do some hard work", //$NON-NLS-1$
            "I 've done my hard work", //$NON-NLS-1$
            configuration,
            new INonInterruptableRunnableWithProgress() {
              @Override
              public void run(final IProgressMonitor monitor) throws InvocationTargetException {
                monitor.beginTask("Unknown work", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
                try {
                  Thread.sleep(5000);
                }
                catch (final InterruptedException e) {
                  // nothing to do
                }
                monitor.done();
              }
            });
      }
    });
  }

  @Demo
  public void knownWork() {
    show(new IWizardPageFactory() {
      @Override
      public IWizardPage createPage(final IWizardConfiguration configuration) {
        return new DemoWizardProgressMonitorPage(
            "A ProgressMonitor Wizard Page which knows how much work has to be done", //$NON-NLS-1$
            "Progress Bar", //$NON-NLS-1$
            "I do some hard work", //$NON-NLS-1$
            "I 've done my hard work", //$NON-NLS-1$
            configuration,
            new INonInterruptableRunnableWithProgress() {
              @Override
              public void run(final IProgressMonitor monitor) throws InvocationTargetException {
                monitor.beginTask("Known work", 10); //$NON-NLS-1$
                for (int i = 0; i < 10; i++) {
                  try {
                    Thread.sleep(500);
                  }
                  catch (final InterruptedException e) {
                    // nothing to do
                  }
                  monitor.worked(1);
                }
                monitor.done();
              }
            });
      }
    });
  }
}
