/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import net.disy.commons.swing.dialog.userdialog.page.AbstractBasicDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.IBasicDialogPage;
import net.disy.commons.swing.events.ICheckInputValidListener;

public abstract class AbstractAggregationDialogPage extends AbstractBasicDialogPage {

  protected final String title;

  protected interface IPageClosure {
    public void execute(IBasicDialogPage page);
  }

  public AbstractAggregationDialogPage(final String title) {
    this.title = title;
  }

  protected abstract IBasicDialogPage[] getPages();

  @Override
  public final String getTitle() {
    return title;
  }

  @Override
  public final void setInputValidListener(final ICheckInputValidListener inputValidListener) {
    super.setInputValidListener(inputValidListener);
    forAllPages(new IPageClosure() {
      @Override
      public void execute(final IBasicDialogPage page) {
        page.setInputValidListener(getCheckInputValidListener());
      }
    });
  }

  @Override
  public void updateInputValid() {
    forAllPages(new IPageClosure() {
      @Override
      public void execute(final IBasicDialogPage page) {
        page.updateInputValid();
      }
    });
  }

  protected final void forAllPages(final IPageClosure closure) {
    for (final IBasicDialogPage page : getPages()) {
      closure.execute(page);
    }
  }

  @Override
  public final void dispose() {
    super.dispose();
    for (final IBasicDialogPage page : getPages()) {
      page.dispose();
    }
  }

  @Override
  public final void enter() {
    for (final IBasicDialogPage page : getPages()) {
      page.enter();
    }
  }

  @Override
  public final void leave() {
    for (final IBasicDialogPage page : getPages()) {
      page.leave();
    }
  }
}