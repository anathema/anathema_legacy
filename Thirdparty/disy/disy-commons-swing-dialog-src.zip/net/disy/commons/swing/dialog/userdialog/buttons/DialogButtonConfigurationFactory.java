// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.05.2005
package net.disy.commons.swing.dialog.userdialog.buttons;

import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.dialog.BasicDialogResources;

// NOT_PUBLISHED
public class DialogButtonConfigurationFactory {

  public static IDialogButtonConfiguration createBoth() {
    return new AbstractDialogButtonConfiguration() {
      //nothing to do
    };
  }

  public static IDialogButtonConfiguration createOnlyOkay() {
    return new AbstractDialogButtonConfiguration() {
      @Override
      public boolean isCancelButtonAvailable() {
        return false;
      }
    };
  }

  public static IDialogButtonConfiguration createOnlyOkay(final String okayText) {
    return new AbstractDialogButtonConfiguration() {
      @Override
      public String getOkayButtonText() {
        return okayText;
      }

      @Override
      public boolean isCancelButtonAvailable() {
        return false;
      }
    };
  }

  public static IDialogButtonConfiguration createCloseOnly() {
    return new AbstractDialogButtonConfiguration() {
      @Override
      public IActionConfiguration getCancelActionConfiguration() {
        return null;
      }

      @Override
      public IActionConfiguration getOkActionConfiguration() {
        return new ActionConfiguration(BasicDialogResources.CLOSE_TEXT_SMART);
      }
    };
  } 
  
  public static IDialogButtonConfiguration createBothWithCancelText(String cancelText) {
    return createBoth(BasicDialogResources.OK_TEXT_SMART, cancelText);
  }

  public static IDialogButtonConfiguration createBothWithOkayText(String okayText) {
    return createBoth(okayText, BasicDialogResources.CANCEL_TEXT_SMART);
  }

  public static IDialogButtonConfiguration createBoth(final String okayText, final String cancelText) {
    return new AbstractDialogButtonConfiguration() {
      @Override
      public String getOkayButtonText() {
        return okayText;
      }

      @Override
      public String getCancelButtonText() {
        return cancelText;
      }
    };
  }
}