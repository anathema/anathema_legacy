/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.optional.OptionalSmartDialogPanel;

public class OptionalIntegerSmartDialogPanel extends OptionalSmartDialogPanel<Integer> {
  public OptionalIntegerSmartDialogPanel(
      final ObjectModel<Integer> model,
      final IMessageProducingValidator messageProducingValidator,
      final String checkBoxLabel,
      final String fieldLabel,
      final int nullValue,
      final int minValue,
      final int maxValue) {
    this(
        model,
        messageProducingValidator,
        checkBoxLabel,
        fieldLabel,
        nullValue,
        minValue,
        maxValue,
        new ObjectModel<Integer>(nullValue));
  }

  private OptionalIntegerSmartDialogPanel(
      final ObjectModel<Integer> model,
      final IMessageProducingValidator messageProducingValidator,
      final String checkBoxLabel,
      final String fieldLabel,
      final int nullValue,
      final int minValue,
      final int maxValue,
      final ObjectModel<Integer> fieldModel) {
    super(model, checkBoxLabel, new IntegerModelSmartDialogPanel(
        fieldLabel,
        null,
        fieldModel,
        messageProducingValidator,
        nullValue,
        minValue,
        maxValue), fieldModel, false);

  }
}