// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Arrays;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.filechooser.FileFilter;
import javax.swing.filechooser.FileSystemView;

import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.smarttable.ITableColumnViewSettings;
import net.disy.commons.swing.smarttable.SmartTable;
import net.disy.commons.swing.smarttable.columnsettings.ObjectUiTableColumnSettings;
import net.disy.commons.swing.smarttable.columnsettings.StringTableColumnSettings;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

import org.apache.commons.collections.Predicate;

//NOT_PUBLISHED
public class FileSelectionPanel extends AbstractActionComponent {
  private final JComponent content;
  private final FileSystemView fileSystemView;
  private FileTableModel fileTableModel;
  private SmartTable fileTable;
  private final FileChooserModel model;

  public FileSelectionPanel(FileChooserModel model) {
    this(model, FileSystemView.getFileSystemView());
  }

  public FileSelectionPanel(final FileChooserModel model, FileSystemView fileSystemView) {
    this.model = model;
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(fileSystemView);
    this.fileSystemView = fileSystemView;
    content = createContent();
    showFiles();
    updateListSelection();

    initListeners();
  }

  private void initListeners() {
    model.getFolderModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        showFiles();
      }
    });

    model.getFileModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateListSelection();
      }
    });

    model.getFileFilterModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        showFiles();
      }
    });

    fileTable.getTable().getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        int selectedRowIndex = fileTable.getSelectedRowIndex();
        if (selectedRowIndex == -1) {
          model.getFileModel().setFile(null);
        }
        else {
          File selectedFile = fileTableModel.getFile(selectedRowIndex);
          model.getFileModel().setFile(selectedFile);
        }
      }
    });

    fileTable.addSelectionActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fireActionEvent();
      }
    });
  }

  private void showFiles() {
    File folder = model.getFolderModel().getFile();
    File[] files = listFiles(folder);
    Arrays.sort(files, new FileComparator(fileSystemView));
    fileTableModel.setFiles(files);
  }

  private File[] listFiles(File folder) {
    if (folder == null) {
      return new File[0];
    }
    final File[] allVisibleFiles = fileSystemView.getFiles(folder, true);
    final FileFilter fileFilter = model.getFileFilterModel().getFileFilter();
    if (fileFilter == null) {
      return allVisibleFiles;
    }
    return (File[]) ArrayUtilities.select(allVisibleFiles, new Predicate() {
      public boolean evaluate(Object object) {
        return fileFilter.accept((File) object);
      }
    });
  }

  private JComponent createContent() {
    fileTableModel = new FileTableModel();
    ITableColumnViewSettings fileNameTableColumnSettings = new ObjectUiTableColumnSettings(
        new FileObjectUi(fileSystemView));
    ITableColumnViewSettings fileSizeTableColumnSettings = new StringTableColumnSettings();
    ITableColumnViewSettings[] viewSettings = new ITableColumnViewSettings[]{
        fileNameTableColumnSettings,
        fileSizeTableColumnSettings };
    fileTable = new SmartTable(fileTableModel, viewSettings);
    fileTable.setSelectionMode(ListSelectionMode.SINGLE_SELECTION);
    JScrollPane scrollPane = new JScrollPane(fileTable.getContent());
    scrollPane.setPreferredSize(new Dimension(250, 250));
    return scrollPane;
  }

  public JComponent getContent() {
    return content;
  }

  public void refresh() {
    showFiles();
  }

  private void updateListSelection() {
    File file = model.getFileModel().getFile();
    if (file != null) {
      model.getFolderModel().setFile(file.getParentFile());
    }

    for (int index = 0; index < fileTableModel.getRowCount(); index++) {
      if (fileTableModel.getFile(index).equals(file)) {
        fileTable.scrollToAndSelect(index);
        return;
      }
    }
    fileTable.getTable().clearSelection();
  }

}
