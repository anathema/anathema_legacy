// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;

import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;

//NOT_PUBLISHED
public class FileSaveDialogPage extends AbstractFileChooserDialogPage {
  private static final IBasicMessage DEFAULT_MESSAGE = new BasicMessage(
      "Bitte w�hlen Sie einen Dateinamen zum Speichern aus.");
  private static final IBasicMessage NO_FILE_SELECTED_MESSAGE = new BasicMessage(
      "Es ist kein Dateiname ausgew�hlt. Bitte w�hlen Sie einen Dateinamen aus.",
      MessageType.ERROR);
  private static final IBasicMessage DIRECTORY_SELECTED_MESSAGE = new BasicMessage(
      "Es ist ein Verzeichnis ausgew�hlt. Bitte w�hlen Sie einen anderen Namen aus.",
      MessageType.ERROR);

  public FileSaveDialogPage(FileChooserModel model, FileChooserDialogConfiguration configuration) {
    super(model, configuration, DEFAULT_MESSAGE);
  }

  public IBasicMessage createCurrentMessage() {
    File file = getModel().getFileModel().getFile();
    if (file == null) {
      return NO_FILE_SELECTED_MESSAGE;
    }
    if (file.isDirectory()) {
      return DIRECTORY_SELECTED_MESSAGE;
    }
    return DEFAULT_MESSAGE;
  }

  public String getTitle() {
    return "Datei speichern";
  }
}