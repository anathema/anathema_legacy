/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog;

import java.awt.Component;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.dialog.action.DialogAction;
import net.disy.commons.swing.dialog.action.IDialogInput;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.SmartDialogPanelsBuildResult;
import net.disy.commons.swing.dialog.input.SmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class DialogUtilities {

  public static DialogAction createAction(
      final String name,
      final String title,
      final IBlock block,
      final ISmartDialogPanel... panels) {
    SmartDialogPanelsBuilder builder = new SmartDialogPanelsBuilder();
    builder.add(panels);
    return createAction(name, title, builder.createResult(), block);
  }

  public static DialogAction createAction(
      final String name,
      final String title,
      final SmartDialogPanelsBuildResult result,
      final IBlock block) {
    return new DialogAction(new ActionConfiguration(name), createDialogInput(title, result, block));
  }

  public static IDialogInput createDialogInput(
      final String title,
      final SmartDialogPanelsBuildResult result,
      final IBlock block) {
    return new IDialogInput() {

      @Override
      public IDialogPage createPage() {
        return createDialogPage(title, result);
      }

      @Override
      public void confirm() {
        block.execute();
      }
    };
  }

  public static IDialogPage createDialogPage(final String title, final ISmartDialogPanel... panels) {
    SmartDialogPanelsBuilder builder = new SmartDialogPanelsBuilder();
    builder.add(panels);
    return createDialogPage(title, builder.createResult());
  }

  public static IDialogPage createDialogPage(
      final String title,
      final SmartDialogPanelsBuildResult result) {
    final AbstractDialogPage abstractDialogPage = new AbstractDialogPage("") { //$NON-NLS-1$

      private JPanel contentPanel;

      @Override
      public String getTitle() {
        return title;
      }

      @Override
      public JComponent createContent() {
        if (contentPanel == null) {
          for (ISmartDialogPanel panel : result.getPanels()) {
            panel.addChangeListener(getCheckInputValidListener());
          }
          contentPanel = result.getCompletePanel();
        }
        return contentPanel;
      }

      @Override
      public IBasicMessage createCurrentMessage() {
        for (ISmartDialogPanel panel : result.getPanels()) {
          IBasicMessage message = panel.createOptionalCurrentMessage();
          if (message != null) {
            return message;
          }
        }
        return getDefaultMessage();
      }
    };
    return abstractDialogPage;
  }

  public static UserDialog createDialog(
      Component parentComponent,
      String title,
      ISmartDialogPanel... panels) {
    IDialogPage dialogPage = createDialogPage(title, panels);
    final UserDialog userDialog = new UserDialog(parentComponent, dialogPage);
    return userDialog;
  }
}
