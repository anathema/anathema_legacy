/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.managed;

import java.awt.Component;

import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.core.IVetoDialogCloseHandler;
import net.disy.commons.swing.dialog.wizard.AbstractWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPage;
import net.disy.commons.swing.dialog.wizard.WizardDialog;

public abstract class AbstractManagedWizardConfiguration extends AbstractWizardConfiguration {

  private WizardDialog dialog;
  private IWizardPageManager pageManager;

  protected abstract IWizardPageManager createPageManager();

  @Override
  public final IWizardPage getStartingPage() {
    return pageManager.getStartPage();
  }

  @Override
  public final IWizardPage getNextPage(final IWizardPage page) {
    return pageManager.getNextPage(page);
  }

  @Override
  public final IWizardPage getPreviousPage(final IWizardPage page) {
    return pageManager.getPreviousPage(page);
  }

  @Override
  public IVetoDialogCloseHandler getVetoCloseHandler() {
    return new IVetoDialogCloseHandler() {
      @Override
      public boolean handleDialogAboutToClose(
          final IDialogResult result,
          final Component parentComponent) {
        if (result.isCanceled()) {
          return true;
        }
        if (pageManager instanceof IFinishingWizardPageManager) {
          return ((IFinishingWizardPageManager) pageManager).performFinish(parentComponent);
        }
        return true;
      }
    };
  }

  @Override
  public final void addPages() {
    pageManager = createPageManager();
  }

  public void show(final Component parentComponent) {
    if (dialog == null) {
      dialog = new WizardDialog(parentComponent, this);
    }
    dialog.show();
  }
}