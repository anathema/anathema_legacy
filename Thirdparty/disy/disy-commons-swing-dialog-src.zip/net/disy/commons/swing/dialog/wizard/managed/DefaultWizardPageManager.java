/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.managed;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.dialog.wizard.IWizardPage;

public class DefaultWizardPageManager implements IWizardPageManager {

  private final List<IManagedWizardPage> pages = new ArrayList<IManagedWizardPage>();

  public final void addPage(final IManagedWizardPage page) {
    pages.add(page);
  }

  private int getIndex(final IWizardPage page) {
    return pages.indexOf(page);
  }

  private IWizardPage getNextApplicablePage(final int startingIndex, final int increment) {
    for (int index = startingIndex; index < pages.size() && index > -1; index += increment) {
      final IManagedWizardPage currentPage = pages.get(index);
      if (currentPage.isApplicable()) {
        return currentPage;
      }
    }
    return null;
  }

  @Override
  public final IWizardPage getNextPage(final IWizardPage page) {
    return getNextApplicablePage(getIndex(page) + 1, +1);
  }

  @Override
  public final IWizardPage getPreviousPage(final IWizardPage page) {
    return getNextApplicablePage(getIndex(page) - 1, -1);
  }

  @Override
  public final IWizardPage getStartPage() {
    return getNextApplicablePage(0, +1);
  }
}