/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core.preferences;

import java.awt.Rectangle;

import javax.swing.JFrame;

import net.disy.commons.core.util.Ensure;

public class FrameBoundsState {

  public static FrameBoundsState createFrom(final JFrame frame) {
    return new FrameBoundsState(frame.getBounds(), frame.getExtendedState());
  }

  private final int extendedFrameState;
  private final Rectangle bounds;

  public FrameBoundsState(final Rectangle bounds, final int extendedFrameState) {
    Ensure.ensureArgumentNotNull(bounds);
    this.bounds = bounds;
    this.extendedFrameState = extendedFrameState;
  }

  public Rectangle getBounds() {
    return bounds;
  }

  public int getExtendedFrameState() {
    return extendedFrameState;
  }

  public void applyTo(final JFrame frame) {
    frame.setBounds(bounds);
    frame.setExtendedState(extendedFrameState);
  }
}