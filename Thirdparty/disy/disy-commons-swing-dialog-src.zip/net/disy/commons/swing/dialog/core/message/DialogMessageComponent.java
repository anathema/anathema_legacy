package net.disy.commons.swing.dialog.core.message;

import java.awt.BorderLayout;

import javax.swing.Box;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.core.IDialogConstants;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.widgets.AutoWrappingLabel;

public class DialogMessageComponent extends JPanel {

  private final AutoWrappingLabel messageLabel;
  private final JLabel iconLabel;

  public DialogMessageComponent(boolean withIcon) {
    super(new BorderLayout());

    setBackground(IDialogConstants.HEADER_BACKGROUND_COLOR);

    iconLabel = new JLabel();
    messageLabel = new AutoWrappingLabel("!Dialog.message!", 330); //$NON-NLS-1$
    messageLabel.setBackground(IDialogConstants.HEADER_BACKGROUND_COLOR);
    messageLabel.setForeground(IDialogConstants.HEADER_TEXT_COLOR);
    messageLabel.setFont(IDialogConstants.MESSAGE_LABEL_FONT);

    JPanel iconPanel = new JPanel(new GridDialogLayout(1, false, 3, 0));
    iconPanel.add(iconLabel);
    iconPanel.setBackground(IDialogConstants.HEADER_BACKGROUND_COLOR);
    if (withIcon) {
      add(iconPanel, BorderLayout.WEST);
    }
    else {
      add(Box.createHorizontalStrut(10), BorderLayout.WEST);
    }
    add(messageLabel.getContent(), BorderLayout.CENTER);
  }

  public void setMessage(IBasicMessage message) {
    if (message == null) {
      return;
    }
    iconLabel.setIcon(MessageTypeUi.getSmallIcon(message.getType()));
    messageLabel.setForeground(MessageTypeUi.getColor(message.getType()));
    messageLabel.setText(message.getText());
  }
}