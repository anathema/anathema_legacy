/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress;

import java.lang.reflect.InvocationTargetException;

import javax.swing.JComponent;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.swing.dialog.wizard.AbstractWizardPage;
import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;

public abstract class AbstractProgressMonitorWizardPage extends AbstractWizardPage {

  private final BooleanModel taskDoneModel = new BooleanModel();
  private final ProgressMonitorComponent progressMonitorComponent;

  public AbstractProgressMonitorWizardPage(
      final String description,
      final String title,
      final String runningMessageText,
      final IWizardConfiguration wizardConfiguration) {
    super(description, title, runningMessageText, wizardConfiguration);
    progressMonitorComponent = new ProgressMonitorComponent();
  }

  @Override
  protected final JComponent createContent() {
    taskDoneModel.addChangeListener(getCheckInputValidListener());
    return progressMonitorComponent.getContent();
  }

  @Override
  protected final IBasicMessage createCurrentMessage() {
    if (isTaskDone()) {
      return new BasicMessage(getDoneMessageText());
    }
    return getDefaultMessage();
  }

  protected boolean isTaskDone() {
    return taskDoneModel.getValue();
  }

  @Override
  public final void requestFocus() {
    // nothing to do
  }

  @Override
  public final void enter() {
    try {
      executeTaskInProgressMonitor();
    }
    catch (final InvocationTargetException e) {
      final Throwable cause = e.getCause();
      if (cause instanceof RuntimeException) {
        throw (RuntimeException) cause;
      }
      throw new RuntimeException(cause);
    }
  }

  private void executeTaskInProgressMonitor() throws InvocationTargetException {
    final ProgressMonitorExecutor progressMonitorExecutor = new ProgressMonitorExecutor(
        new InternalProgressDialogModel(),
        new IProgressComponent() {
          @Override
          public void show() {
            taskDoneModel.setValue(false);
          }

          @Override
          public void dispose() {
            taskDoneModel.setValue(true);
          }
        });
    final INonInterruptableRunnableWithProgress runnable = new INonInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor) throws InvocationTargetException {
        executeWithProgress(monitor);
      }
    };
    progressMonitorExecutor.run(runnable, progressMonitorComponent);
  }

  protected abstract void executeWithProgress(final IProgressMonitor monitor)
      throws InvocationTargetException;

  protected abstract String getDoneMessageText();
}
