//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.test;


import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.testing.ReflectionArgumentMatcher;
import net.disy.commons.swing.dialog.file.FileFilterModel;

import org.easymock.MockControl;

// NOT_PUBLISHED
public class FileFilterModelTest extends AbstractFileFilterTest {
  
  FileFilterModel fileFilterModel;
  private MockControl listenerControl;
  private ChangeListener listener;
  
  protected void setUp() throws Exception {
    super.setUp();
    fileFilterModel = new FileFilterModel();
    listenerControl = MockControl.createControl(ChangeListener.class);
    listener = (ChangeListener) listenerControl.getMock();
    fileFilterModel.addChangeListener(listener);

  }
  
  public void testSetSameFileFilter() throws Exception {
    listenerControl.replay();
    fileFilterModel.setFileFilter(null);
    listenerControl.verify();
  }
  
  public void testSetDifferentFileFilter() throws Exception {
    listener.stateChanged(new ChangeEvent(fileFilterModel));
    listenerControl.setDefaultMatcher(new ReflectionArgumentMatcher());
    listenerControl.replay();
    fileFilterModel.setFileFilter(createDummyFileFilter());
    listenerControl.verify();
  }

}
