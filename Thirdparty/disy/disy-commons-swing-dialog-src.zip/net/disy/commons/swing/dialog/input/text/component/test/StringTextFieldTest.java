/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.*;

import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.text.component.StringTextField;

import org.junit.Test;

public class StringTextFieldTest {

  @Test
  public void requestFocusDelegatesToTextField() throws Exception {
    final ObjectModel<Boolean> called = new ObjectModel<Boolean>(false);
    new StringTextField<JTextField>(new JTextField() {
      @Override
      public void requestFocus() {
        called.setValue(true);
      }
    }).requestFocus();
    assertTrue(called.getValue());
  }

  @Test
  public void setEditableDelegatesToTextField() throws Exception {
    final ObjectModel<Boolean> called = new ObjectModel<Boolean>(false);
    new StringTextField<JTextField>(new JTextField() {
      @Override
      public void setEditable(final boolean editable) {
        assertTrue(editable);
        called.setValue(true);
      }
    }).setEditable(true);
    assertTrue(called.getValue());
  }

  @Test
  public void isEditableDelegatesToTextField() throws Exception {
    final ObjectModel<Boolean> called = new ObjectModel<Boolean>(false);
    new StringTextField<JTextField>(new JTextField() {
      @Override
      public boolean isEditable() {
        called.setValue(true);
        return true;
      }
    }).isEditable();
    assertTrue(called.getValue());
  }

  @Test
  public void setEnabledDelegatesToTextField() throws Exception {
    final ObjectModel<Boolean> called = new ObjectModel<Boolean>(false);
    new StringTextField<JTextField>(new JTextField() {
      @Override
      public void setEnabled(final boolean enabled) {
        assertTrue(enabled);
        called.setValue(true);
      }
    }).setEnabled(true);
    assertTrue(called.getValue());
  }

  @Test
  public void getValueReturnsTextOfTextField() throws Exception {
    final String value = new StringTextField<JTextField>(new JTextField() {
      @Override
      public String getText() {
        return "text"; //$NON-NLS-1$
      }
    }).getValue();
    assertThat(value, is("text")); //$NON-NLS-1$
  }

  @Test
  public void setValueSetsTextOnTextField() throws Exception {
    final ObjectModel<Boolean> called = new ObjectModel<Boolean>(false);
    new StringTextField<JTextField>(new JTextField() {
      @Override
      public void setText(final String text) {
        assertEquals("text", text); //$NON-NLS-1$
        called.setValue(true);
      }
    }).setValue("text"); //$NON-NLS-1$
    assertTrue(called.getValue());
  }

  @Test
  public void changeListenerGetsNotifiedOnSelection() throws Exception {
    final ChangeListener changeListener = createMock(ChangeListener.class);
    changeListener.stateChanged(isA(ChangeEvent.class));
    replay(changeListener);
    final JTextField textField = new JTextField();
    new StringTextField<JTextField>(textField).addChangeListener(changeListener);
    textField.setText("text"); //$NON-NLS-1$
    verify(changeListener);
  }

  @Test
  public void getComponentReturnsGivenTextField() throws Exception {
    final JTextField textField = new JTextField();
    assertSame(textField, new StringTextField<JTextField>(textField).getComponent());
  }
}
