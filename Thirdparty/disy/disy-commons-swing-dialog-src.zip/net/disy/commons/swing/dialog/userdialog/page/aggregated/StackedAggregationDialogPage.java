/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import java.awt.BorderLayout;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.component.Gap;
import net.disy.commons.swing.dialog.userdialog.page.IBasicDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class StackedAggregationDialogPage extends AbstractCompositeDialogPage
    implements
    IDialogPage {

  private final IDialogPage upperPage;
  private final IBasicDialogPage lowerPage;
  private final JComponent seperator;

  public StackedAggregationDialogPage(
      final String title,
      final IDialogPage upperPage,
      final IBasicDialogPage lowerPage) {
    this(title, upperPage, lowerPage, new Gap(0, 0));
  }

  public StackedAggregationDialogPage(
      final String title,
      final IDialogPage upperPage,
      final IBasicDialogPage lowerPage,
      final JComponent seperator) {
    super(title);
    this.upperPage = upperPage;
    this.lowerPage = lowerPage;
    this.seperator = seperator;
  }

  @Override
  public final IBasicDialogPage[] getPages() {
    return new IBasicDialogPage[]{ upperPage, lowerPage };
  }

  @Override
  public IBasicMessage getDefaultCurrentMessage() {
    return upperPage.createCurrentMessage();
  }

  @Override
  public JComponent createContent() {
    final JPanel panel = new JPanel(new BorderLayout());
    final JPanel upperPanel = new JPanel(new BorderLayout());
    upperPanel.add(upperPage.createContent(), BorderLayout.CENTER);
    upperPanel.add(seperator, BorderLayout.SOUTH);
    panel.add(upperPanel, BorderLayout.NORTH);
    panel.add(lowerPage.createContent(), BorderLayout.CENTER);
    return panel;
  }

  @Override
  public IBasicMessage getDefaultMessage() {
    return upperPage.getDefaultMessage();
  }

  @Override
  public void requestFocus() {
    upperPage.requestFocus();
  }
}
