// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.input.text.ITextInputDialogConfiguration;
import net.disy.commons.swing.dialog.input.text.ITextInputDialogResult;
import net.disy.commons.swing.dialog.input.text.SmartTextInputDialog;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.icon.CommonIcons;
import net.disy.commons.swing.icon.SwingIcons;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.toolbar.ToolBarBuilder;
import net.disy.commons.swing.util.JOptionPaneUtilities;

import org.apache.commons.io.FileUtils;

//NOT_PUBLISHED
public abstract class AbstractFileChooserDialogPage extends AbstractDialogPage {

  private FileChooserPanel fileChooserPanel;
  private final FileChooserModel model;
  private final FileChooserDialogConfiguration configuration;

  public AbstractFileChooserDialogPage(
      FileChooserModel model,
      FileChooserDialogConfiguration configuration,
      IBasicMessage defaultMessage) {
    super(defaultMessage);
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(configuration);
    this.model = model;
    this.configuration = getConfiguration(configuration);
    fileChooserPanel = new FileChooserPanel(model, this.configuration);
  }

  protected FileChooserDialogConfiguration getConfiguration(
      FileChooserDialogConfiguration configuration) {
    return configuration;
  }

  public JComponent createContent() {
    fileChooserPanel.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        fileChooserPanelActionPerformed();
      }
    });
    getModel().getFileModel().addChangeListener(getCheckInputValidListener());

    JPanel panel = new JPanel(new BorderLayout(
        LayoutUtilities.getComponentSpacing(),
        LayoutUtilities.getComponentSpacing()));

    ToolBarBuilder builder = new ToolBarBuilder();
    builder.add(createRefreshAction());
    builder.addSeparator();
    builder.add(createDeleteAction());
    builder.add(createNewFolderAction(panel));

    IFileModelActionFactory[] actionFactories = getConfiguration().getActionFactories();
    for (int i = 0; i < actionFactories.length; ++i) {
      builder.add(actionFactories[i].createAction(getModel().getFileModel()));
    }

    panel.add(builder.getToolBar(), BorderLayout.NORTH);
    panel.add(getFileChooserPanel().getContent(), BorderLayout.CENTER);
    return panel;
  }

  private Action createDeleteAction() {
    final Action deleteAction = new SmartAction(
        "Ausgew�hlte Datei oder Verzeichnis l�schen",
        CommonIcons.DELETE) {
      protected void execute(Component parentComponent) {
        executeDelete(parentComponent);
      }
    };
    getModel().getFileModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateDeleteActionEnabled(deleteAction);
      }
    });
    updateDeleteActionEnabled(deleteAction);

    return deleteAction;
  }

  private void executeDelete(Component parentComponent) {
    File file = getModel().getFileModel().getFile();
    if (file.isDirectory()) {
      if (!JOptionPaneUtilities
          .confirmUserOperation(
              parentComponent,
              "Wollen Sie das ausgew�hlte Verzeichnis und alle Dateien, die darin enthalten sind, wirklich l�schen?",
              "Best�tigen")) {
        return;
      }
      try {
        FileUtils.deleteDirectory(file);
        getModel().refresh();
      }
      catch (IOException e) {
        // nothing to do
      }
    }
    else {
      if (!JOptionPaneUtilities.confirmUserOperation(
          parentComponent,
          "Wollen Sie die ausgew�hlte Datei wirklich l�schen?",
          "Best�tigen")) {
        return;
      }
      if (file.delete()) {
        getModel().refresh();
      }
    }
  }

  private Action createRefreshAction() {
    return new SmartAction("Ansicht aktualisieren", CommonIcons.REFRESH) {
      protected void execute(Component parentComponent) {
        getModel().refresh();
      }
    };
  }

  private Action createNewFolderAction(final Component parent) {
    final Action newFolderAction = new SmartAction("Neuen Ordner anlegen", SwingIcons
        .getFileViewNewFolderIcon()) {
      protected void execute(Component parentComponent) {
        executeCreateNewFolder(parent);
      }
    };
    return newFolderAction;
  }

  private void executeCreateNewFolder(final Component parent) {
    final File folder = getModel().getFolderModel().getFile();
    ITextInputDialogConfiguration dialogConfiguration = new NewFolderInputDialogConfiguration(
        folder);
    ITextInputDialogResult result = SmartTextInputDialog.showTextInputDialog(
        parent,
        dialogConfiguration,
        createNonExistingFileName(folder, "Neuer Ordner"));
    if (!result.isCanceled()) {
      File file = new File(folder, result.getText().trim());
      file.mkdir();
      getModel().refresh();
      getModel().getFileModel().setFile(file);
    }
  }

  private String createNonExistingFileName(File folder, String name) {
    if (!new File(folder, name).exists()) {
      return name;
    }

    for (int index = 1;; index++) {
      String newName = name + " " + index;
      if (!new File(folder, newName).exists()) {
        return newName;
      }
    }
  }

  private void updateDeleteActionEnabled(Action deleteAction) {
    File file = getModel().getFileModel().getFile();
    deleteAction.setEnabled(file != null && file.exists());
  }

  protected void fileChooserPanelActionPerformed() {
    requestFinish();
  }

  public FileChooserModel getModel() {
    return model;
  }

  protected FileChooserPanel getFileChooserPanel() {
    return fileChooserPanel;
  }

  protected FileChooserDialogConfiguration getConfiguration() {
    return configuration;
  }
}