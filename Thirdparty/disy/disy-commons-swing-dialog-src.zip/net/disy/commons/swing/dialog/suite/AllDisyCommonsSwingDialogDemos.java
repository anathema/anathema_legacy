//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.suite;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDisyCommonsSwingDialogDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for net.disy.commons.swing.dialog.suite"); //$NON-NLS-1$
    suite.addDemo(net.disy.commons.swing.dialog.input.select.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.input.text.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.progress.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.wizard.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.userdialog.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.foldout.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.message.demo.AllDemos.suite());
    suite.addDemo(net.disy.commons.swing.dialog.input.combo.demo.AllDemos.suite());
    //$JDemo-BEGIN$

    //$JDemo-END$
    return suite;
  }
}
