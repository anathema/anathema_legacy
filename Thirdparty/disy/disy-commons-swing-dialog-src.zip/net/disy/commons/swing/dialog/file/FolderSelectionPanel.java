package net.disy.commons.swing.dialog.file;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

import net.disy.commons.core.io.FileModel;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.tree.ITreeNodeActionListener;
import net.disy.commons.swing.tree.SmartTree;

/**
 * @author Markus Gebhard
 */
public class FolderSelectionPanel extends AbstractActionComponent implements IFileSystemContext {

  private SmartTree tree;

  private final JComponent content;
  private final FileSystemView fileSystemView;
  private final Map/*<File, FolderNode>*/nodesByFile = new HashMap();

  private File[] roots;

  private final FileModel folderModel;

  public FolderSelectionPanel(final FileModel folderModel) {
    this(folderModel, FileSystemView.getFileSystemView());
  }

  public FolderSelectionPanel(final FileModel folderModel, FileSystemView fileSystemView) {
    this(folderModel, fileSystemView, fileSystemView.getRoots());
  }

  public FolderSelectionPanel(final FileModel folderModel, File[] roots) {
    this(folderModel, FileSystemView.getFileSystemView(), roots);
  }

  public FolderSelectionPanel(
      final FileModel folderModel,
      FileSystemView fileSystemView,
      File[] roots) {
    this.folderModel = folderModel;
    this.fileSystemView = fileSystemView;
    this.roots = roots;
    this.content = createDirectoryPanel();

    if (folderModel.getFile() != null) {
      setSelectedFolder(folderModel.getFile());
    }
    folderModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        setSelectedFolder(folderModel.getFile());
      }
    });

    tree.getSelectionModel().addTreeSelectionListener(new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
        File selectedFolder = getSelectedFolder();
        if (selectedFolder == null) {
          return;
        }
        folderModel.setFile(selectedFolder);
      }
    });
  }

  public void setSelectedFolder(File file) {
    if (file == null || file.equals(getSelectedFolder())) {
      return;
    }
    file = file.getAbsoluteFile();
    List/*<File>*/files = new ArrayList();
    while (file != null) {
      files.add(file);
      if (isRoot(file)) {
        break;
      }
      file = file.getParentFile();
    }
    reverseSelect(files, files.size() - 1);
  }

  private boolean isRoot(File file) {
    for (int index = 0; index < roots.length; index++) {
      if (roots[index].getAbsoluteFile().equals(file)) {
        return true;
      }
    }

    return false;
  }

  private void reverseSelect(List files, int index) {
    FolderNode node = (FolderNode) nodesByFile.get(files.get(index));

    if (node == null) {
      return;
    }
    TreeNode[] path = node.getPath();
    TreePath treePath = new TreePath(path);
    tree.expandPath(treePath);
    if (index > 0) {
      reverseSelect(files, index - 1);
    }
    else {
      tree.setSelectionPath(treePath);
      tree.scrollPathToVisible(treePath);
    }
  }

  private JComponent createDirectoryPanel() {
    tree = new SmartTree(createRootNode());

    if (roots.length > 1) {
      tree.setRootVisible(false);
    }

    tree.setCellRenderer(new FileTreeCellRenderer(fileSystemView));
    tree.addNodeActionListener(new ITreeNodeActionListener() {
      public void nodeActionPerformed(Component parentComponent, TreeNode node) {
        if (node.getChildCount() == 0) {
          fireActionEvent();
        }
      }
    });

    JScrollPane scrollPane = new JScrollPane(tree);
    scrollPane.setPreferredSize(new Dimension(150, 250));
    return scrollPane;
  }

  private DefaultMutableTreeNode createRootNode() {
    DefaultMutableTreeNode root;
    if (roots.length == 1) {
      root = new FolderNode(this, roots[0]);
    }
    else {
      root = new DefaultMutableTreeNode("root"); //$NON-NLS-1$
      for (int i = 0; i < roots.length; i++) {
        root.add(new FolderNode(this, roots[i]));
      }
    }
    return root;
  }

  private File getSelectedFolder() {
    FolderNode node = getSelectedNode();
    if (node == null) {
      return null;
    }
    return node.getFile();
  }

  private FolderNode getSelectedNode() {
    TreePath selectionPath = tree.getSelectionPath();
    if (selectionPath == null) {
      return null;
    }
    return (FolderNode) selectionPath.getLastPathComponent();
  }

  public JComponent getContent() {
    return content;
  }

  public FileSystemView getFileSystemView() {
    return fileSystemView;
  }

  public void setBusy(boolean busy) {
    if (content == null) {
      return;
    }
    if (busy) {
      content.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    }
    else {
      content.setCursor(null);
    }
  }

  public void registerNode(File file, FolderNode node) {
    nodesByFile.put(file, node);
  }

  public void refresh() {
    nodesByFile.clear();
    tree.setModel(new DefaultTreeModel(createRootNode()));
    setSelectedFolder(folderModel.getFile());
  }
}