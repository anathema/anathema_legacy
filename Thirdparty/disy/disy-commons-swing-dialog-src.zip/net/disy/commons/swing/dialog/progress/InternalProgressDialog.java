package net.disy.commons.swing.dialog.progress;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.progress.ICanceledListener;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.BasicDialogResources;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.util.GuiUtilities;
import net.disy.commons.swing.widgets.AutoWrappingLabel;

/** Not intended to be used by clients!
 * @see net.disy.commons.swing.dialog.progress.ProgressMonitorDialog 
 */
public class InternalProgressDialog implements IProgressMonitor {

  private static final String TASK_LABEL_ELLIPSIS = "..."; //$NON-NLS-1$
  private final ProgressMonitorBar progressBar;
  private JDialog dialog;
  private final SmartAction cancelAction;
  private final AutoWrappingLabel taskNameLabel;
  private final JLabel subTaskNameLabel;
  private boolean cancelable = false;
  private final InternalProgressDialogModel model;
  private boolean disposed = false;
  private boolean showing = false;
  private final Component parentComponent;
  private final String title;
  private final Collection canceledListeners = new ArrayList();

  public InternalProgressDialog(
      Component parentComponent,
      String title,
      final InternalProgressDialogModel model) {
    Ensure.ensureArgumentNotNull(model);
    this.parentComponent = parentComponent;
    this.title = title;
    this.model = model;

    cancelAction = new SmartAction(BasicDialogResources.CANCEL_TEXT_SMART) {
      @Override
      protected void execute(Component parent) {
        performCancel();
      }
    };

    taskNameLabel = new AutoWrappingLabel();
    taskNameLabel.setOpaque(false);

    subTaskNameLabel = new JLabel("", SwingConstants.LEFT); //$NON-NLS-1$
    subTaskNameLabel.setPreferredSize(new Dimension(subTaskNameLabel.getPreferredSize().width, 25));

    progressBar = new ProgressMonitorBar();
    progressBar.setBorderPainted(true);
  }

  private void performCancel() {
    if (cancelable) {
      setCanceled(true);
      cancelAction.setEnabled(false);
    }
    yield();
  }

  public void setCancelable(boolean cancelable) {
    this.cancelable = cancelable;
    cancelAction.setEnabled(cancelable);
  }

  public void show() {
    synchronized (this) {
      if (disposed) {
        return;
      }
      showing = true;
      dialog = createDialog();
    }
    GuiUtilities.centerToParent(dialog);
    dialog.setVisible(true);
  }

  private JDialog createDialog() {
    JButton cancelButton = new JButton(cancelAction);
    ButtonPanelBuilder builder = new ButtonPanelBuilder();
    builder.add(cancelButton);

    Icon icon = MessageTypeUi.getIcon(MessageType.INFORMATION);

    JPanel topPanel = new JPanel(new BorderLayout(10, 8));
    topPanel.add(new JLabel(icon), BorderLayout.WEST);
    topPanel.add(taskNameLabel.getContent(), BorderLayout.CENTER);
    topPanel.setBorder(new EmptyBorder(8, 0, 0, 0));

    JPanel mainPanel = new JPanel(new GridDialogLayout(1, false));
    mainPanel.add(topPanel, GridDialogLayoutData.FILL_HORIZONTAL);
    mainPanel.add(progressBar, GridDialogLayoutData.FILL_HORIZONTAL);
    mainPanel.add(subTaskNameLabel, GridDialogLayoutData.FILL_HORIZONTAL);
    mainPanel.setBorder(new EmptyBorder(5, 7, 0, 7));

    JDialog newDialog = GuiUtilities.createDialog(parentComponent, title);
    newDialog.getContentPane().setLayout(new BorderLayout(2, 2));
    newDialog.getContentPane().add(mainPanel, BorderLayout.CENTER);

    newDialog.getContentPane().add(builder.createPanel(), BorderLayout.SOUTH);
    newDialog.pack();

    newDialog.setSize(Math.max(newDialog.getWidth(), 450), newDialog.getHeight());

    newDialog.setResizable(false);
    newDialog.setModal(true);
    newDialog.getRootPane().setDefaultButton(cancelButton);
    newDialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

    newDialog.addWindowListener(new WindowAdapter() {
      @Override
      public void windowClosing(WindowEvent e) {
        performCancel();
      }
    });

    return newDialog;
  }

  public void dispose() {
    synchronized (this) {
      disposed = true;
      if (showing) {
        while (dialog == null || !dialog.isVisible()) {
          try {
            Thread.sleep(50);
          }
          catch (InterruptedException e) {
            //nothing to do
          }
        }
      }
    }
    if (dialog != null) {
      dialog.dispose();
    }
  }

  public void beginTask(final String name, final int totalWork) {
    final String taskName = addTaskLabelEllipsis(name);
    subTask(""); //$NON-NLS-1$
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        progressBar.beginTask(taskName, totalWork);
        taskNameLabel.setText(taskName);
      }
    });
    yield();
  }

  public static String addTaskLabelEllipsis(String name) {
    if (name.length() == 0) {
      return name;
    }
    if (name.endsWith(TASK_LABEL_ELLIPSIS)) {
      return name;
    }
    return name + TASK_LABEL_ELLIPSIS;
  }

  public void done() {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        progressBar.done();
      }
    });
    yield();
  }

  public void setCanceled(boolean canceled) {
    model.setCanceled(canceled);
    if (canceled) {
      fireCanceled();
    }
    yield();
  }

  public synchronized void addCanceledListener(ICanceledListener listener) {
    Ensure.ensureNotNull(listener);
    canceledListeners.add(listener);
  }

  public synchronized void removeCanceledListener(ICanceledListener listener) {
    canceledListeners.remove(listener);
  }

  private void fireCanceled() {
    List clonedListeners;
    synchronized (this) {
      clonedListeners = new ArrayList(canceledListeners);
    }
    for (Iterator iter = clonedListeners.iterator(); iter.hasNext();) {
      ICanceledListener listener = (ICanceledListener) iter.next();
      listener.canceled();
    }
  }

  public void subTask(final String name) {
    SwingUtilities.invokeLater(new Runnable() {
      public void run() {
        subTaskNameLabel.setText(name);
      }
    });
    yield();
  }

  public void worked(int work) {
    progressBar.worked(work);
    yield();
  }

  public boolean isCanceled() {
    yield();
    return model.isCanceled();
  }

  private void yield() {
    if (dialog != null) {
      /* (gebhard) 07.03.2006: Bugfix: Only request focus if we are not already an 'active' window.
       * Otherwise focus from the 'Cancel' Button might be stolen while user clicks this button
       * (happened with frequent subsequent calls to subTask()). */
      if (!dialog.isActive()) {
        /* Bugfix/Workaround (gebhard) 15.12.2005: Bug 2802: 
         Modal progress dialog can be hidden behind other frame in same JVM.
         The frame is blocked, but no progress dialog is visible.
         So we just request focus as often as possible in order to stay on top of hiding window. */
        dialog.requestFocus();
      }
    }
    Thread.yield();
  }

  /** Only to be called from within unit tests! */
  public boolean getTestIsDialogVisible() {
    return dialog != null && dialog.isVisible();
  }

  /** Only to be called from within unit tests! 
   */
  public boolean getTestIsCancelable() {
    return cancelable;
  }
}