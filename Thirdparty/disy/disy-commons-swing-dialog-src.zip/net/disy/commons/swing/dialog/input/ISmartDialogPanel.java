//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.layout.grid.IDialogComponent;

// NOT_PUBLISHED
public interface ISmartDialogPanel extends IDialogComponent {

  public void addChangeListener(ChangeListener listener);

  public IBasicMessage createOptionalCurrentMessage();

  public void addRequestFinishListener(IRequestFinishListener requestFinishListener);

}