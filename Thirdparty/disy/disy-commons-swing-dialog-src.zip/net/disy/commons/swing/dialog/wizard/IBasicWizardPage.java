// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 28.04.2006
package net.disy.commons.swing.dialog.wizard;

import net.disy.commons.swing.dialog.core.IPage;

// NOT_PUBLISHED
public interface IBasicWizardPage extends IPage {

  /** Returns whether the next page could be displayed.
   * 
   * @return <code>true</code> if the next page could be displayed, and <code>false</code>
   * otherwise*/
  public boolean canFlipToNextPage();

  /** Returns the wizard page that would to be shown if the user was to press the Next button.*/
  public IBasicWizardPage getNextPage();

  /** Returns the wizard page that would to be shown if the user was to press the Back button.*/
  public IBasicWizardPage getPreviousPage();

  /** Returns whether this page is complete or not.
   * 
   * This information is typically used by the wizard to decide when it is okay to finish.
   * @return <code>true</code> if this page is complete, and <code>false</code> otherwise */
  public boolean canFinish();
}