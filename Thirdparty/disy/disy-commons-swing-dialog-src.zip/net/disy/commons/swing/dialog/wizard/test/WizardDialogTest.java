/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.test;

import static org.easymock.EasyMock.createNiceMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IPageContent;
import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPage;
import net.disy.commons.swing.dialog.wizard.WizardDialog;

import org.junit.Test;

public class WizardDialogTest {

  @Test
  public void showPageCallsLeaveOnCurrentPage() throws Exception {
    final IWizardPage currentPage = createNiceMock(IWizardPage.class);
    currentPage.leave();
    final IPageContent pageContent = createNiceMock(IPageContent.class);
    final IWizardPage newPage = createNiceMock(IWizardPage.class);
    expect(newPage.getPageContent()).andReturn(pageContent);
    final IWizardConfiguration configuration = createNiceMock(IWizardConfiguration.class);
    expect(configuration.getHeaderPanelConfiguration()).andReturn(
        DialogHeaderPanelConfiguration.createInvisible());
    replay(configuration, currentPage, newPage, pageContent);
    new TestWizardDialog(configuration, currentPage) {
      @Override
      protected void updateContent() {
        // nothing to do
      }

      @Override
      public void updateMessage() {
        // nothing to do
      }

      @Override
      public void updateDescription() {
        // nothing to do
      }

      @Override
      public void updateButtons() {
        // nothing to do
      }

      @Override
      public void updateTitle() {
        // nothing to do
      }
    }.showPage(newPage);
    verify(configuration, currentPage, newPage, pageContent);
  }

  private class TestWizardDialog extends WizardDialog {
    public TestWizardDialog(final IWizardConfiguration configuration, final IWizardPage currentPage) {
      super(new JPanel(), configuration);
      setCurrentPage(currentPage);
    }

    @Override
    protected JComponent createButtonBar() {
      return new JPanel();
    }
  }
}