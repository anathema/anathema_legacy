// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

/**
 * Interface for a wizard page.
 * 
 *  The class {@link AbstractWizardPage} provides an abstract implementation of this interface. However,
 *  clients are also free to implement this interface if WizardPage does not suit their needs.
 */
public interface IWizardPage extends IBasicWizardPage {

  /** Initializes all widgets from the data attached to this wizard page. This method will be called
   * from the wizard container after creating the content.
   * @deprecated As of 10.12.2004 (gebhard)
   * @see #getContent() */
  public void initializeFromData();

  /** Called from the wizard container when the page has been activated. */
  public void pageActivated();

  /** Called from the wizard container when the page has been deactivated. */
  public void pageDeactivated();
}