/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.button.DropDownButton;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.icon.CompositeIcon;
import net.disy.commons.swing.image.DisyCommonsSwingImageProvider;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;
import net.disy.commons.swing.toolbar.ToolBarBuilder;

public class IconedColorChooserButton extends AbstractActionComponent {

  public static interface IChooseStrategy {
    JComponent[] createContent(JButton button, IconedColorChooserButton chooserButton, ColorModel colorModel);

    ColorModel createColorModel(ColorModel model);

    void execute(Component parentComponent, ColorModel model, IconedColorChooserButton button);

    String amendName(String name);
  }

  public static class DropDownStrategy implements IChooseStrategy {
    private final boolean showTransparent;

    public DropDownStrategy(final boolean showTransparent) {
      this.showTransparent = showTransparent;
    }

    @Override
    public ColorModel createColorModel(final ColorModel model) {
      return new ColorModel(model.getColor());
    }

    @Override
    public JComponent[] createContent(
        final JButton button,
        final IconedColorChooserButton chooserButton,
        final ColorModel colorModel) {
      final DropDownButton dropDownButton = new DropDownButton(button);
      final JPopupMenu popupMenu = new ColorPopupMenu(showTransparent) {
        @Override
        protected void performColorChooserDialog(final Component parentComponent) {
          chooserButton.performColorChooserDialog(parentComponent);
          applyColor(chooserButton, colorModel);
        }

        @Override
        protected void setColor(final Color color) {
          chooserButton.buttonModel.setColor(color);
          applyColor(chooserButton, colorModel);
        }
      };
      dropDownButton.setMenu(popupMenu);
      return dropDownButton.getSeparateComponents();
    }

    @Override
    public void execute(
        final Component parentComponent,
        final ColorModel model,
        final IconedColorChooserButton button) {
      applyColor(button, model);
    }

    private void applyColor(final IconedColorChooserButton button, final ColorModel model) {
      model.setColor(button.buttonModel.getColor());
    }

    @Override
    public String amendName(final String name) {
      return name;
    }
  }

  public static final IChooseStrategy DIRECT = new IChooseStrategy() {
    @Override
    public ColorModel createColorModel(final ColorModel model) {
      return model;
    }

    @Override
    public JComponent[] createContent(
        final JButton button,
        final IconedColorChooserButton chooserButton,
        final ColorModel colorModel) {
      return new JComponent[]{ button };
    }

    @Override
    public void execute(
        final Component parentComponent,
        final ColorModel model,
        final IconedColorChooserButton button) {
      button.performColorChooserDialog(parentComponent);
    }

    @Override
    public String amendName(final String name) {
      return name + "..."; //$NON-NLS-1$
    }
  };

  private static final Icon TEXT_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/text_color.gif"); //$NON-NLS-1$
  private static final Icon MARKER_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/marked_background_color.gif"); //$NON-NLS-1$
  private static final Icon BACKGROUND_ICON = DisyCommonsSwingImageProvider.getInstance().getImageIcon(
      "color/background_color.gif"); //$NON-NLS-1$

  public final static IconedColorChooserButton createTextColorChooserButton(
      final ColorModel colorModel,
      final IChooseStrategy strategy) {
    return new IconedColorChooserButton(TEXT_ICON, colorModel, DisyCommonsSwingMessages
        .getString("ColorChooserButton.FontColor.tooltip"), strategy); //$NON-NLS-1$
  }

  public final static IconedColorChooserButton createMarkerColorChooserButton(
      final ColorModel colorModel,
      final IChooseStrategy strategy) {
    return new IconedColorChooserButton(MARKER_ICON, colorModel, DisyCommonsSwingMessages
        .getString("ColorChooserButton.MarkerColor.tooltip"), strategy); //$NON-NLS-1$
  }

  public final static IconedColorChooserButton createBackgroundColorChooserButton(
      final ColorModel colorModel,
      final IChooseStrategy strategy) {
    return new IconedColorChooserButton(BACKGROUND_ICON, colorModel, DisyCommonsSwingMessages
        .getString("ColorChooserButton.BackgroundColor.tooltip"), strategy); //$NON-NLS-1$
  }

  private final JComponent content;
  private final JComponent[] components;
  private final ColorModel buttonModel;

  private final DefaultColorChooserConfiguration colorChooserConfiguration;

  private final JButton button;

  public IconedColorChooserButton(
      final Icon baseIcon,
      final ColorModel model,
      final String name,
      final IChooseStrategy strategy) {
    Ensure.ensureArgumentNotNull(baseIcon);
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(strategy);
    this.buttonModel = strategy.createColorModel(model);
    final SmartAction action = new SmartAction(strategy.amendName(name), createColorIcon(baseIcon)) {
      @Override
      protected void execute(final Component parentComponent) {
        strategy.execute(parentComponent, model, IconedColorChooserButton.this);
      }
    };
    button = new JButton(action);
    button.setPreferredSize(LayoutUtilities.TOOLBAR_BUTTON_SIZE);
    button.setFocusPainted(false);
    this.components = strategy.createContent(button, this, model);
    final ToolBarBuilder builder = new ToolBarBuilder();
    builder.add(components);
    this.content = builder.createToolBar();
    colorChooserConfiguration = new DefaultColorChooserConfiguration(name, false);
  }

  private Icon createColorIcon(final Icon baseIcon) {
    class ColorIcon extends AbstractChangeableModel implements Icon {
      public ColorIcon() {
        buttonModel.addChangeListener(new IChangeListener() {
          @Override
          public void stateChanged() {
            fireChangeEvent();
            button.repaint();
          }
        });
      }

      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        g.setColor(buttonModel.getColor());
        g.fillRect(x + 0, y + 16 - 4, 16, 4);
      }

      @Override
      public int getIconWidth() {
        return 16;
      }

      @Override
      public int getIconHeight() {
        return 16;
      }
    }
    return new CompositeIcon(new ColorIcon(), baseIcon);
  }

  private void performColorChooserDialog(final Component parentComponent) {
    Color color = buttonModel.getColor();
    if (color.getAlpha() == 0) {
      color = Color.WHITE;
    }
    final Color newColor = ColorChooserDialog.showDialog(parentComponent, colorChooserConfiguration, color);
    if (newColor != null) {
      buttonModel.setColor(newColor);
    }
    fireActionEvent();
  }

  public JComponent getContent() {
    return content;
  }
}