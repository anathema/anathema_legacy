/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.demo;

import java.io.IOException;
import java.util.ArrayList;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.core.text.ISuggestionsForStringProvider;
import net.disy.commons.core.text.SuggestionResult;

@SuppressWarnings("nls")
public final class DemoStringSuggestionsProvider implements ISuggestionsForStringProvider<String> {

  @Override
  public SuggestionResult<String> querySuggestions(final String text, final ICancelable cancelable)
      throws IOException,
      InterruptedException {
    if ("error".equals(text)) {
      throw new IOException("Unable to query values for the input text 'error'.");
    }
    for (int i = 0; i < 8; ++i) {
      ProgressUtilities.checkInterrupted(cancelable);
      try {
        Thread.sleep(100);
      }
      catch (final InterruptedException e) {
        //nothing to do
      }
    }
    if ("empty".equals(text)) {
      return new SuggestionResult<String>(new ArrayList<String>());
    }

    final ArrayList<String> list = new ArrayList<String>();
    list.add(text);
    list.add(text + "bla");
    list.add(text + "fasel");
    list.add(text + "blafasel");
    if (text.startsWith("lo")) {
      list.add(text + " - A longer text is provided here.");
    }
    if (text.startsWith("long")) {
      list
          .add(text
              + " text is provided here, in order to see what happens with long result texts in search results.");
    }
    list.add(text + "1");
    list.add(text + "12");
    list.add(text + "123");
    list.add(text + "123 blubb");
    list.add(text + "1234 blubb");
    list.add(text + "1235 blubb");
    list.add(text + "1236 blubb");
    list.add(text + "1237 blubb");
    list.add(text + "1238 blubb");
    list.add(text + "1239 blubb");
    list.add(text + "1230 blubb");
    list.add(text + "12310 blubb");
    return text.startsWith("a") ? new SuggestionResult<String>(list, new Message(
        "optional message",
        "The texts start with an 'a'.",
        MessageType.INFORMATION)) : new SuggestionResult<String>(list);
  }
}