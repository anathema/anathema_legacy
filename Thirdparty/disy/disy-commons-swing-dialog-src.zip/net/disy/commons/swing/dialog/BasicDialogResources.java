//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

// NOT_PUBLISHED
public class BasicDialogResources {

  protected BasicDialogResources() {
    throw new UnreachableCodeReachedException();
  }

  public static final String ADD_TEXT_PLAIN = Messages.getString("Dialog.AddButtonText"); //$NON-NLS-1$
  
  /** @deprecated As of 20.06.2005 (gebhard), replaced ONLY FOR SmartActions (!) by {@link #APPLY_TEXT_SMART}*/
  @Deprecated
  public static final String APPLY_TEXT_PLAIN = Messages.getString("Dialog.ApplyButtonText"); //$NON-NLS-1$
  
  /** @deprecated As of 20.06.2005 (gebhard), replaced by {@link #CANCEL_TEXT_SMART}*/
  @Deprecated
  public static final String CANCEL_TEXT_PLAIN = Messages.getString("Dialog.CancelButtonText"); //$NON-NLS-1$
  
  /** @deprecated As of 20.06.2005 (gebhard), replaced ONLY FOR SmartActions (!) by {@link #HELP_TEXT_SMART}*/
  @Deprecated
  public static final String HELP_TEXT_PLAIN = Messages.getString("Dialog.HelpButtonText"); //$NON-NLS-1$
  
  public static final String LESS_TEXT_PLAIN = Messages.getString("Dialog.LessButtonText"); //$NON-NLS-1$
  
  public static final String MORE_TEXT_PLAIN = Messages.getString("Dialog.MoreButtonText"); //$NON-NLS-1$

  /** @deprecated As of 20.06.2005 (gebhard), replaced ONLY FOR SmartActions (!) by {@link #OK_TEXT_SMART}*/
  @Deprecated
  public static final String OK_TEXT_PLAIN = Messages.getString("Dialog.OkayButtonText"); //$NON-NLS-1$
  
  public static final String APPLY_TEXT_SMART = Messages.getString("SmartAction.apply"); //$NON-NLS-1$
  public static final String CANCEL_TEXT_SMART = Messages.getString("SmartAction.cancel"); //$NON-NLS-1$
  public static final String CLOSE_TEXT_SMART = Messages.getString("SmartAction.close"); //$NON-NLS-1$
  public static final String HELP_TEXT_SMART = Messages.getString("SmartAction.help"); //$NON-NLS-1$
  public static final String OK_TEXT_SMART = Messages.getString("SmartAction.okay"); //$NON-NLS-1$
  
  public static final String WIZARD_NEXT_SMART = Messages.getString("Wizard.SmartNext"); //$NON-NLS-1$
  public static final String WIZARD_BACK_SMART = Messages.getString("Wizard.SmartBack"); //$NON-NLS-1$
  public static final String WIZARD_FINISH_SMART = Messages.getString("Wizard.SmartFinish"); //$NON-NLS-1$

  public static final String YES_TEXT = Messages.getString("SmartAction.Yes"); //$NON-NLS-1$
  public static final String NO_TEXT = Messages.getString("SmartAction.No"); //$NON-NLS-1$

}