/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.demo;

import java.awt.Component;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.text.ISuggestionsForStringProvider;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogIconResources;
import net.disy.commons.swing.dialog.input.text.suggest.AbstractSuggestionTextFieldConfiguration;
import net.disy.commons.swing.dialog.input.text.suggest.ISuggestionActionHandler;
import net.disy.commons.swing.dialog.input.text.suggest.ISwingIOExceptionHandler;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.message.MessageTypeUi;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.ui.IObjectUi;

public final class DemoSuggestionTextFieldConfiguration
    extends
    AbstractSuggestionTextFieldConfiguration<String> {
  private final ISwingIOExceptionHandler errorHandler = new DemoSwingIOExceptionHandler();
  private final ISuggestionsForStringProvider<String> provider = new DemoStringSuggestionsProvider();

  @Override
  public IObjectUi<String> getObjectUi() {
    return new AbstractObjectUi<String>() {
      @Override
      public String getLabel(final String value) {
        return "<html>" + "<b>Name:</b> " + value + "</html>";
      }

      @Override
      public Icon getIcon(final String value) {
        if ("1".equals(value)) {
          return MessageTypeUi.errorIcon;
        }
        return null;
      }
    };
  }

  @Override
  public String getRawSearchText(final String value) {
    return value;
  }

  @Override
  public String getBusyLabelText() {
    return "Lade Daten...";
  }

  @Override
  public String getNoResultLabelText() {
    return "Keine Suchtreffer.";
  }

  @Override
  public ISuggestionActionHandler<String> getActionHandler() {
    return new ISuggestionActionHandler<String>() {
      @Override
      public void handle(final Component parentComponent, final String selection) {
        MessageDialogFactory.showMessageDialog(parentComponent, new Message("Selected '"
            + selection
            + "'", MessageType.INFORMATION));
      }
    };
  }

  @Override
  public String getToolTipText() {
    return "Suchfeld - bitte Suchtext eingeben";
  }

  @Override
  public ISwingIOExceptionHandler getErrorHandler() {
    return errorHandler;
  }

  @Override
  public ISuggestionsForStringProvider<String> getSuggestionsForStringProvider() {
    return provider;
  }

  @Override
  public JComponent createOptionalLeftInsideTextFieldComponent() {
    return new JLabel(DisyCommonsSwingDialogIconResources.SEARCH_TEXTFIELD);
  }
}