package net.disy.commons.swing.dialog.userdialog;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.core.IDialogContainer;
import net.disy.commons.swing.events.CheckInputValidListener;

public abstract class AbstractDialogPage implements IDialogPage {
  private final IBasicMessage defaultMessage;
  private CheckInputValidListener inputValidListener;
  private IDialogContainer container;

  public AbstractDialogPage(IBasicMessage defaultMessage) {
    Ensure.ensureArgumentNotNull("DefaultMessage must not be null.", defaultMessage); //$NON-NLS-1$
    this.defaultMessage = defaultMessage;
  }

  public void setContainer(IDialogContainer container) {
    this.container = container;
  }

  //@Overrides
  public final IBasicMessage getDefaultMessage() {
    return defaultMessage;
  }

  //@Overrides
  public void setInputValidListener(CheckInputValidListener inputValidListener) {
    this.inputValidListener = inputValidListener;
  }

  //@Overrides
  public void performHelp() {
    throw new UnsupportedOperationException();
  }

  /**
   * @deprecated
   */
  //@Overrides
  public boolean performOk() {
    return true;
  }

  /**
   * @deprecated
   */
  //@Overrides
  public boolean performCancel() {
    return true;
  }

  //@Overrides
  public String getDescription() {
    return getTitle();
  }

  //@Overrides
  public boolean isHelpAvailable() {
    return false;
  }

  //@Overrides
  public void requestFocus() {
    // nothing to do
  }

  protected final CheckInputValidListener getCheckInputValidListener() {
    Ensure.ensureNotNull("CheckInputValidListener not yet set.", inputValidListener); //$NON-NLS-1$
    return inputValidListener;
  }

  protected final void checkInputValid() {
    inputValidListener.checkInputValid();
  }

  protected final void requestFinish() {
    //23.01.2006 (gebhard) Workaround: container==null bei In Wizards eingebetteten DialogPages
    if (container != null) {
      container.requestFinish();
    }
  }

  public void updateInputValid() {
    // nothing to do
  }

  public void dispose() {
    // nothing to do
  }
  
  public boolean canFinish() {
    return true;
  }
}