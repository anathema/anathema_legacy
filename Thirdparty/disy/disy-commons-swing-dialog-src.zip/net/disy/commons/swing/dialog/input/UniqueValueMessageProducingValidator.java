/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.ArrayUtilities;

public class UniqueValueMessageProducingValidator<T> implements IMessageProducingValidator {
  private final ObjectModel<T> model;
  private final String errorMessageText;
  private final T[] values;

  public UniqueValueMessageProducingValidator(
      final ObjectModel<T> model,
      final T[] values,
      final String errorMessageText) {
    this.model = model;
    this.values = values;
    this.errorMessageText = errorMessageText;
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return ArrayUtilities.containsValue(values, model.getValue()) ? new BasicMessage(
        errorMessageText,
        MessageType.ERROR) : null;
  }
}
