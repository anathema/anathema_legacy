/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JSpinner.DefaultEditor;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;

public abstract class IntegralNumberSmartDialogPanel<T extends Number>
    extends
    AbstractLabeledSmartDialogPanel {

  private final ObjectModel<T> model;
  private final JSpinner spinner;

  public IntegralNumberSmartDialogPanel(
      final String label,
      final ObjectModel<T> model,
      final IMessageProducingValidator validator,
      final T nullValue,
      final T minimum,
      final T maximum) {
    this(label, null, model, validator, nullValue, minimum, maximum);
  }

  public IntegralNumberSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<T> model,
      final IMessageProducingValidator validator,
      final T nullValue,
      final T minimum,
      final T maximum) {
    super(label, toolTipText, validator);
    this.model = model;
    //04.05.2006 (gebhard): Wert muss vom Typ Long sein, damit der Spinner sich an die eingestellten Min/Max-Werte halten kann 
    final Long initialValue = getNonNullValue(nullValue);
    final SpinnerNumberModel spinnerNumberModel = new SpinnerNumberModel(
        initialValue,
        minimum == null ? null : Long.valueOf(minimum.longValue()),
        maximum == null ? null : Long.valueOf(maximum.longValue()),
        new Integer(1));
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        spinnerNumberModel.setValue(getNonNullValue(nullValue));
      }
    });
    spinnerNumberModel.addChangeListener(new javax.swing.event.ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent changeEvent) {
        model.setValue(convertToNumber((Long) spinnerNumberModel.getValue()));
      }
    });
    spinner = new JSpinner(spinnerNumberModel);
    final JComponent editor = spinner.getEditor();
    //Adjust layout: width should not be to large/small for numbers
    if (editor instanceof DefaultEditor) {
      final DefaultEditor numberEditor = (DefaultEditor) editor;
      numberEditor.getTextField().setColumns(12);
    }
  }

  protected abstract T convertToNumber(Long value);

  private Long getNonNullValue(final T nullValue) {
    return model.getValue() == null ? new Long(nullValue.longValue()) : new Long(model
        .getValue()
        .longValue());
  }

  @Override
  public final void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  protected final int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  protected final JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    panel.add(spinner);
    return spinner;
  }

  @Override
  public final void requestFocus() {
    spinner.requestFocus();
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    spinner.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ spinner };
  }
}