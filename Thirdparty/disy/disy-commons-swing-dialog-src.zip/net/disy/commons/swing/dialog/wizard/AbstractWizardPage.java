// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import javax.swing.JComponent;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.core.IPageContent;
import net.disy.commons.swing.events.CheckInputValidListener;
import net.disy.commons.swing.events.IInputValidCheckable;

/**
 * An abstract base implementation of a wizard page.
 * Subclasses must implement the createContent method to create the specific controls for the
 * wizard page.
 * 
 * Subclasses may call the following methods to configure the wizard page:
 * <ul>
 * <li><code>setDescription</code>
 * <li><code>setImageDescriptor</code>
 * <li><code>setMessage</code>
 * <li><code>setPageComplete</code>
 * <li><code>setTitle</code>
 * </ul>
 * 
 * Subclasses may override these methods if required:
 * 
 * <ul>
 * <li><code>performHelp</code> - may be reimplemented to display help for the page
 * <li><code>canFlipToNextPage</code> - may be extended or reimplemented
 * <li><code>isPageComplete</code> - may be extended
 * <li><code>setDescription</code> - may be extended
 * <li><code>setTitle</code> - may be extended
 * <li><code>dispose</code> - may be extended to dispose resources
 * </ul>
 * 
 * Note that clients are free to implement {@link IWizardPage} from scratch instead of subclassing
 * <code>WizardPage</code>. Correct implementations of <code>IWizardPage</code> will work with
 * any correct implementation of {@link IWizardConfiguration}.
 */
public abstract class AbstractWizardPage implements IWizardPage, IInputValidCheckable, IPageContent {
  private CheckInputValidListener checkInputValidListener;
  private final IBasicMessage defaultMessage;
  private String title;
  private IBasicMessage message;
  private String description;
  private IWizardConfiguration wizard;
  private JComponent content;

  /** Creates a new wizard page with the given name, and with no title or image.*/
  protected AbstractWizardPage(String description, IBasicMessage defaultMessage) {
    this(description, null, defaultMessage);
  }

  /** Creates a new wizard page with the given name and title.*/
  protected AbstractWizardPage(String description, String title, IBasicMessage defaultMessage) {
    Ensure.ensureArgumentNotNull(
        "The default message page may not be null (" + this + ")", defaultMessage); //$NON-NLS-1$ //$NON-NLS-2$
    this.defaultMessage = defaultMessage;
    setMessage(defaultMessage);
    this.description = description;
    this.title = title;
  }

  protected AbstractWizardPage(
      String description,
      String title,
      IBasicMessage defaultMessage,
      IWizardConfiguration wizard) {
    this(description, title, defaultMessage);
    setWizard(wizard);
  }

  protected final IBasicMessage getDefaultMessage() {
    return defaultMessage;
  }

  protected final CheckInputValidListener getCheckInputValidListener() {
    if (checkInputValidListener == null) {
      checkInputValidListener = new CheckInputValidListener(this);
    }
    return checkInputValidListener;
  }

  public void checkInputValid() {
    setMessage(createCurrentMessage());
  }

  protected abstract IBasicMessage createCurrentMessage();

  public String getTitle() {
    return title == null ? getDescription() : title;
  }

  public final void setWizard(IWizardConfiguration newWizard) {
    this.wizard = newWizard;
  }

  public final IWizardConfiguration getWizard() {
    return wizard;
  }

  private void updateMessage() {
    if (getWizard() == null || getWizard().getContainer() == null) {
      return;
    }
    getWizard().getContainer().updateMessage();
    getWizard().getContainer().updateButtons();
  }

  public final JComponent getContent() {
    if (content == null) {
      content = createContent();
      if (getWizard() != null && getWizard().shallInitializePagesFromData()) {
        initializeFromData();
      }
    }
    return content;
  }

  protected abstract JComponent createContent();

  protected final void setDescription(String description) {
    this.description = description;
  }

  public final void setMessage(IBasicMessage message) {
    Ensure.ensureArgumentNotNull(message);
    this.message = message;
    updateMessage();
  }

  public final String getDescription() {
    return description;
  }

  public final IBasicMessage getMessage() {
    return message;
  }

  public IBasicWizardPage getNextPage() {
    return getWizard().getNextPage(this);
  }

  public IBasicWizardPage getPreviousPage() {
    return getWizard().getPreviousPage(this);
  }

  public boolean canFlipToNextPage() {
    return getNextPage() != null;
  }

  /** Convenience method for setting an error message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.ERROR));</code> */
  protected void setErrorMessage(String text) {
    setMessage(new BasicMessage(text, MessageType.ERROR));
  }

  /** Convenience method for setting an information message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.INFORMATION));</code> */
  protected void setInformationMessage(String text) {
    setMessage(new BasicMessage(text, MessageType.INFORMATION));
  }

  /** Convenience method for setting a warning message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.WARNING));</code> */
  protected void setWarningMessage(String text) {
    setMessage(new BasicMessage(text, MessageType.WARNING));
  }

  /** @deprecated As of 10.12.2004 (gebhard)} */
  @Deprecated
  public void initializeFromData() {
    //nothing to do
  }

  protected final boolean isActivePage() {
    return getWizard().getContainer().getCurrentPage() == this;
  }

  public void dispose() {
    return;
  }

  public void pageActivated() {
    // nothing to do
  }

  public void pageDeactivated() {
    // nothing to do
  }
  
  public IPageContent getPageContent() {
    return this;
  }
}