/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard;

import javax.swing.JComponent;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IClosure;
import net.disy.commons.swing.dialog.core.IPageContent;
import net.disy.commons.swing.dialog.core.internal.AbstractPage;
import net.disy.commons.swing.dialog.input.IRequestFinishListener;
import net.disy.commons.swing.events.CheckInputValidListener;
import net.disy.commons.swing.events.IInputValidCheckable;

/**
 * An abstract base implementation of a wizard page. Subclasses must implement the createContent
 * method to create the specific controls for the wizard page. Subclasses may call the following
 * methods to configure the wizard page:
 * <ul>
 * <li><code>setDescription</code>
 * <li><code>setImageDescriptor</code>
 * <li><code>setMessage</code>
 * <li><code>setPageComplete</code>
 * <li><code>setTitle</code>
 * </ul>
 * Subclasses may override these methods if required:
 * <ul>
 * <li><code>performHelp</code> - may be reimplemented to display help for the page
 * <li><code>canFlipToNextPage</code> - may be extended or reimplemented
 * <li><code>isPageComplete</code> - may be extended
 * <li><code>setDescription</code> - may be extended
 * <li><code>setTitle</code> - may be extended
 * <li><code>dispose</code> - may be extended to dispose resources
 * </ul>
 * Note that clients are free to implement {@link IWizardPage} from scratch instead of subclassing
 * <code>WizardPage</code>. Correct implementations of <code>IWizardPage</code> will work with any
 * correct implementation of {@link IWizardConfiguration}.
 */
public abstract class AbstractWizardPage extends AbstractPage
    implements
    IWizardPage,
    IInputValidCheckable,
    IPageContent {

  private final ListenerList<IRequestFinishListener> requestFinishListeners = new ListenerList<IRequestFinishListener>();

  private CheckInputValidListener checkInputValidListener;
  private final IBasicMessage defaultMessage;
  private final String title;
  private IBasicMessage message;
  private String description;

  /**
   * @deprecated As of 01.08.2006 (gebhard) - use listers or other ways to retrieve the required
   *             information
   */
  @Deprecated
  private IWizardConfiguration wizard;

  private JComponent content;

  /** Creates a new wizard page with the given name, and with no title or image. */
  protected AbstractWizardPage(final String description, final String defaultMessageText) {
    this(description, null, defaultMessageText);
  }

  protected AbstractWizardPage(
      final String description,
      final String title,
      final String defaultMessageText,
      final IWizardConfiguration wizard) {
    this(description, title, defaultMessageText);
    setWizard(wizard);
  }

  /** Creates a new wizard page with the given name and title. */
  protected AbstractWizardPage(
      final String description,
      final String title,
      final String defaultMessageText) {
    Ensure.ensureArgumentNotNull(
        "The default message page may not be null (" + this + ")", defaultMessageText); //$NON-NLS-1$ //$NON-NLS-2$
    defaultMessage = new BasicMessage(defaultMessageText);
    setMessage(defaultMessage);
    this.description = description;
    this.title = title;
  }

  protected final IBasicMessage getDefaultMessage() {
    return defaultMessage;
  }

  protected final CheckInputValidListener getCheckInputValidListener() {
    if (checkInputValidListener == null) {
      checkInputValidListener = new CheckInputValidListener(this);
    }
    return checkInputValidListener;
  }

  @Override
  public void checkInputValid() {
    setMessage(createCurrentMessage());
  }

  protected abstract IBasicMessage createCurrentMessage();

  @Override
  public String getTitle() {
    return title == null ? getDescription() : title;
  }

  @Override
  public final void setWizard(final IWizardConfiguration newWizard) {
    wizard = newWizard;
  }

  /**
   * @deprecated As of 01.08.2006 (gebhard) - use listeners or other ways to retrieve the required
   *             information
   */
  @Override
  @Deprecated
  public final IWizardConfiguration getWizard() {
    return wizard;
  }

  private void updateMessage() {
    if (getWizard() == null || getWizard().getContainer() == null) {
      return;
    }
    getWizard().getContainer().updateMessage();
    getWizard().getContainer().updateButtons();
  }

  @Override
  public final JComponent getContent() {
    if (content == null) {
      content = createContent();
      if (getWizard() != null && getWizard().shallInitializePagesFromData()) {
        initializeFromData();
      }
    }
    return content;
  }

  protected abstract JComponent createContent();

  protected final void setDescription(final String description) {
    this.description = description;
  }

  @Override
  public final void setMessage(final IBasicMessage message) {
    Ensure.ensureArgumentNotNull(message);
    this.message = message;
    updateMessage();
  }

  @Override
  public final String getDescription() {
    return description;
  }

  @Override
  public final IBasicMessage getMessage() {
    return message;
  }

  @Override
  public IWizardPage getNextPage() {
    return getWizard().getNextPage(this);
  }

  @Override
  public IWizardPage getPreviousPage() {
    return getWizard().getPreviousPage(this);
  }

  @Override
  public boolean canFlipToNextPage() {
    //15.03.2007 (gebhard, bartels): Reihenfolge der Bedingungen ist absicht, damit ggf. die nächste Page so spät wie möglich abgefragt (und damit dann ggf. lazy erzeugt wird)
    return !createCurrentMessage().isErrorMessage() && getNextPage() != null;
  }

  /**
   * Convenience method for setting an error message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.ERROR));</code>
   */
  protected void setErrorMessage(final String text) {
    setMessage(new BasicMessage(text, MessageType.ERROR));
  }

  /**
   * Convenience method for setting an information message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.INFORMATION));</code>
   */
  protected void setInformationMessage(final String text) {
    setMessage(new BasicMessage(text, MessageType.INFORMATION));
  }

  /**
   * Convenience method for setting a warning message. Executes:
   * <code>setMessage(new BasicMessage(text, MessageType.WARNING));</code>
   */
  protected void setWarningMessage(final String text) {
    setMessage(new BasicMessage(text, MessageType.WARNING));
  }

  /** @deprecated As of 10.12.2004 (gebhard)} */
  @Override
  @Deprecated
  public void initializeFromData() {
    //nothing to do
  }

  protected final boolean isActivePage() {
    return getWizard().getContainer().getCurrentPage() == this;
  }

  @Override
  public void enter() {
    // nothing to do
  }

  @Override
  public void leave() {
    // nothing to do
  }

  @Override
  public IPageContent getPageContent() {
    return this;
  }

  @Override
  public void addRequestFinishListener(final IRequestFinishListener requestFinishListener) {
    requestFinishListeners.add(requestFinishListener);
  }

  @Override
  public void removeRequestFinishListener(final IRequestFinishListener requestFinishListener) {
    requestFinishListeners.remove(requestFinishListener);
  }

  protected final void fireRequestFinish() {
    requestFinishListeners.forAllDo(new IClosure<IRequestFinishListener>() {
      @Override
      public void execute(final IRequestFinishListener listener) {
        listener.requestFinish();
      }
    });
  }

  @Override
  public boolean canCancel() {
    return true;
  }

  public final void pageDeactivated() {
    // nothing to do
  }
}