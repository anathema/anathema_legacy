/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.component;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.ConfigurationException;
import net.disy.commons.core.message.Message;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public abstract class AbstractObjectComboBox<O> implements IObjectInputComponent<O, JComboBox> {

  private final IAttributeValueListFactory<O> valueListFactory;
  private final IAttributeContext attributeContext;
  private final IObjectUi<O> objectUi;
  private final JComboBox comboBox;

  public AbstractObjectComboBox(
      final IAttributeValueListFactory<O> valueListFactory,
      final IAttributeContext attributeContext,
      final IObjectUi<O> objectUi) {
    this.valueListFactory = valueListFactory;
    this.attributeContext = attributeContext;
    this.objectUi = objectUi;
    this.comboBox = createComboBox();
  }

  private DefaultComboBoxModel createComboBoxModel() {
    List<O> values = new ArrayList<O>();
    try {
      values = valueListFactory.createList(attributeContext);
    }
    catch (final ConfigurationException e) {
      MessageDialogFactory.createMessageDialog(null, new Message(e.getMessage(), e)).show();
    }
    if (values == null) {
      return new DefaultComboBoxModel();
    }
    return new DefaultComboBoxModel(values.toArray());
  }

  protected JComboBox createComboBox() {
    final DefaultComboBoxModel comboBoxModel = createComboBoxModel();
    final JComboBox combobox = new JComboBox(comboBoxModel);
    if (objectUi.getLabel(null) != null) {
      combobox.setPrototypeDisplayValue(objectUi.getLabel(null));
    }
    combobox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    return combobox;
  }

  @Override
  public void addChangeListener(final ChangeListener changeListener) {
    comboBox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        changeListener.stateChanged(new ChangeEvent(comboBox));
      }
    });
  }

  @Override
  public void setValue(final O value) {
    comboBox.setSelectedItem(value);
  }

  @SuppressWarnings("unchecked")
  @Override
  public O getValue() {
    return ((O) comboBox.getSelectedItem());
  }

  @Override
  public JComboBox getComponent() {
    return comboBox;
  }

  @Override
  public boolean isEditable() {
    return comboBox.isEditable();
  }

  @Override
  public void setEditable(final boolean editable) {
    comboBox.setEditable(editable);
  }

  @Override
  public void selectAll() {
    // nothing to do
  }

  @Override
  public void requestFocus() {
    comboBox.requestFocus();
  }

  @Override
  public final void setEnabled(final boolean enabled) {
    comboBox.setEnabled(enabled);
  }

  @Override
  public void update() {
    //nothing to do
  }
}