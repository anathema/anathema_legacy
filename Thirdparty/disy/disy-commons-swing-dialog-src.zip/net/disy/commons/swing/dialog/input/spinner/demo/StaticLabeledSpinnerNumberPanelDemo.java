/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.spinner.demo;

import javax.swing.SpinnerNumberModel;

import net.disy.commons.swing.dialog.input.spinner.StaticLabeledSpinnerNumberPanel;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.grid.IGridDialogPanelBuilder;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
@SuppressWarnings("nls")
public class StaticLabeledSpinnerNumberPanelDemo extends SwingDemoCase {

  public void demo() {
    StaticLabeledSpinnerNumberPanel spinnerNumberPanel = new StaticLabeledSpinnerNumberPanel(
        new SpinnerNumberModel(1, 0, 20, 1),
        "Label:",
        "Tooltip");
    final IGridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    builder.add(spinnerNumberPanel);
    show(builder.createPanel());
  }

}