/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import java.awt.BorderLayout;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.label.SmartLabel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.list.AbstractListMouseHandler;
import net.disy.commons.swing.list.JListMouseListener;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public class ListSelectionDialogPanel<T> extends AbstractSmartDialogPanel {

  private final JList list;
  private final IListSelectionDialogPanelConfiguration<T> configuration;
  private final FixedOptionsObjectSelectionModel<T> selectedItemsModel;

  public ListSelectionDialogPanel(
      final FixedOptionsObjectSelectionModel<T> selectedItemsModel,
      final IListSelectionDialogPanelConfiguration<T> configuration) {
    Ensure.ensureArgumentNotNull(selectedItemsModel);
    Ensure.ensureArgumentNotNull(configuration);
    this.selectedItemsModel = selectedItemsModel;
    this.configuration = configuration;

    list = new JList(configuration.getItems());
    list.setCellRenderer(new ObjectUiListCellRenderer(configuration.getObjectUi()));
    list.getSelectionModel().setSelectionMode(
        configuration.getListSelectionMode().getListSelectionMode());

    list.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      @Override
      public void valueChanged(final ListSelectionEvent e) {
        if (!e.getValueIsAdjusting()) {
          final Object[] selectedValues = list.getSelectedValues();
          final Set<T> valuesSet = new HashSet<T>();
          for (final Object object : selectedValues) {
            CollectionUtilities.addCasted(valuesSet, object);
          }
          selectedItemsModel.setSelectedValues(valuesSet);
        }
      }
    });

    selectedItemsModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateListSelection();
      }
    });
    updateListSelection();

    JListMouseListener.attachTo(list, new AbstractListMouseHandler() {
      @Override
      public void handleDoubleClick(final Object[] arg0) {
        fireRequestFinish();
      }
    });
  }

  private void updateListSelection() {
    list.getSelectionModel().setValueIsAdjusting(true);
    list.setSelectedIndices(selectedItemsModel.getSelectedIndices());
    list.getSelectionModel().setValueIsAdjusting(false);
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    selectedItemsModel.addChangeListener(listener);
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    if (getSelectedItems().size() == 0) {
      final String noItemSelectedErrorMessageText = configuration
          .getNoItemSelectedErrorMessageText();
      if (noItemSelectedErrorMessageText != null) {
        return new BasicMessage(noItemSelectedErrorMessageText, MessageType.ERROR);
      }
    }

    return null;
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.FILL_BOTH);
    layoutData.setHorizontalSpan(columnCount);
    panel.add(createMainPanel(), layoutData);
  }

  private JPanel createMainPanel() {
    final JPanel mainPanel = new JPanel(new BorderLayout());
    final String listTitle = configuration.getLabel();
    if (listTitle != null) {
      final JLabel label = new SmartLabel(listTitle);
      mainPanel.add(label, BorderLayout.NORTH);
      label.setLabelFor(list);
    }
    mainPanel.add(new JScrollPane(list), BorderLayout.CENTER);
    return mainPanel;
  }

  public List<T> getSelectedItems() {
    final Object[] selectedValues = list.getSelectedValues();
    final List<T> valueList = new ArrayList<T>();
    for (final Object object : selectedValues) {
      CollectionUtilities.addCasted(valueList, object);
    }
    return valueList;
  }

  public FixedOptionsObjectSelectionModel<T> getSelectedItemModel() {
    return selectedItemsModel;
  }

  @Override
  public void requestFocus() {
    list.requestFocus();
  }
}