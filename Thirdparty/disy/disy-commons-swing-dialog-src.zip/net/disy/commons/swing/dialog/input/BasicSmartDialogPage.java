/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import javax.swing.JComponent;

import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IOptionalCurrentMessageFactory;
import net.disy.commons.swing.dialog.userdialog.page.AbstractBasicDialogPage;

public abstract class BasicSmartDialogPage extends AbstractBasicDialogPage {

  private SmartDialogPanelsBuildResult panelBuildResult;

  @Override
  public final IBasicMessage createCurrentMessage() {
    return createHighestPriorityMessage();
  }

  private IBasicMessage createHighestPriorityMessage() {
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    final IOptionalCurrentMessageFactory[] panels = getPanels();
    for (IOptionalCurrentMessageFactory panel : panels) {
      final IBasicMessage message = panel.createOptionalCurrentMessage();
      if (message != null) {
        builder.addMessage(message);
      }
    }

    addAdditionalMessages(builder);

    return builder.getHighestPriorityMessage();
  }

  public boolean isErrorMessage() {
    return createHighestPriorityMessage().isErrorMessage();
  }

  protected void addAdditionalMessages(final HighestPriorityMessageBuilder builder) {
    // nothing to do
  }

  @Override
  public final JComponent createContent() {
    final SmartDialogPanelsBuildResult panelResult = getPanelBuildResult();
    final IRequestFinishListener requestFinishListener = new IRequestFinishListener() {
      @Override
      public void requestFinish() {
        BasicSmartDialogPage.this.fireRequestFinish();
      }
    };
    final ISmartDialogPanel[] panels = panelResult.getPanels();
    for (ISmartDialogPanel panel : panels) {
      panel.addChangeListener(getCheckInputValidListener());
      panel.addRequestFinishListener(requestFinishListener);
    }
    return panelResult.getCompletePanel();
  }

  private SmartDialogPanelsBuildResult getPanelBuildResult() {
    if (panelBuildResult == null) {
      final SmartDialogPanelsBuilder builder = new SmartDialogPanelsBuilder();
      addPanels(builder);
      panelBuildResult = builder.createResult();
    }
    return panelBuildResult;
  }

  private ISmartDialogPanel[] getPanels() {
    return getPanelBuildResult().getPanels();
  }

  protected abstract void addPanels(ISmartDialogPanelsBuilder builder);

  @Override
  public void requestFocus() {
    final ISmartDialogPanel[] panels = getPanels();
    if (panels.length > 0) {
      panels[0].requestFocus();
    }
  }
}