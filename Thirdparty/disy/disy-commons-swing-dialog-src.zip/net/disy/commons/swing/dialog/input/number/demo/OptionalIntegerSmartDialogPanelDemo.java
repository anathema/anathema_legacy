/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number.demo;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.NullMessageProducingValidator;
import net.disy.commons.swing.dialog.input.SmartDialogPage;
import net.disy.commons.swing.dialog.input.number.OptionalIntegerSmartDialogPanel;
import net.disy.commons.swing.dialog.userdialog.demo.DialogPageDemoCase;

import de.jdemo.annotation.Demo;

public class OptionalIntegerSmartDialogPanelDemo extends DialogPageDemoCase {
  @Demo
  public void demoWithCheckboxLabel() throws Exception {
    show(new SmartDialogPage("Default Message") { //$NON-NLS-1$
      @Override
      public String getTitle() {
        return "Demo with checkbox label"; //$NON-NLS-1$
      }

      @Override
      protected void addPanels(final ISmartDialogPanelsBuilder builder) {
        builder.add(new OptionalIntegerSmartDialogPanel(
            new ObjectModel<Integer>(),
            new NullMessageProducingValidator(),
            "CheckBoxLabel", //$NON-NLS-1$
            "FieldLabel", //$NON-NLS-1$
            0,
            0,
            10));
      }
    });
  }

  @Demo
  public void demoWithoutCheckboxLabel() throws Exception {
    show(new SmartDialogPage("Default Message") { //$NON-NLS-1$
      @Override
      public String getTitle() {
        return "Demo without checkbox label"; //$NON-NLS-1$
      }

      @Override
      protected void addPanels(final ISmartDialogPanelsBuilder builder) {
        builder.add(new OptionalIntegerSmartDialogPanel(
            new ObjectModel<Integer>(),
            new NullMessageProducingValidator(),
            null,
            "FieldLabel", //$NON-NLS-1$
            0,
            0,
            10));
      }
    });
  }
}