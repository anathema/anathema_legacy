package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;

import net.disy.commons.swing.dialog.core.IGenericDialog;

/**
 * @author gebhard
 */
public interface IUserDialog extends IGenericDialog {

  public IDialogPage getDialogPage();

  public void setUserDialogContainer(IUserDialogContainer userDialog);

  public boolean isModal();

  public boolean performOk();

  public Component[] createAdditionalButtons();

}