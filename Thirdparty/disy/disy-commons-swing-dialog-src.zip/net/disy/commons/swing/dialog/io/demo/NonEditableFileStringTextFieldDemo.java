/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.io.demo;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.io.NonEditableFileStringTextField;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class NonEditableFileStringTextFieldDemo extends SwingDemoCase {

  public void demoEmptyName() {
    showFileNameTextField(null);
  }

  public void demoShortName() {
    showFileNameTextField("file.txt"); //$NON-NLS-1$
  }

  public void demoLongName() {
    showFileNameTextField("C:\\Programme\\Gemeinsame Dateien\\blafasel\\filename.bin"); //$NON-NLS-1$
  }

  private void showFileNameTextField(final String fileName) {
    show(new NonEditableFileStringTextField(new ObjectModel<String>(fileName)).getContent());
  }
}