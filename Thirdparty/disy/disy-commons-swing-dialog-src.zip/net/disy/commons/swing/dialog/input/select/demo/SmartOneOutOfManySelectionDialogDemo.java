//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.swing.dialog.input.select.IOneOutOfManyDialogConfiguration;
import net.disy.commons.swing.dialog.input.select.SmartOneOutOfManySelectionDialog;
import net.disy.commons.swing.ui.IObjectUi;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SmartOneOutOfManySelectionDialogDemo extends SwingDemoCase {

  public void demo() {
    show(SmartOneOutOfManySelectionDialog.createDemoDialog(
        createParentComponent(),
        new IOneOutOfManyDialogConfiguration() {
          public String getTitle() {
            return "Color"; //$NON-NLS-1$
          }

          public String getNoItemSelectedErrorMessageText() {
            return "There is no color selected. Please select a color."; //$NON-NLS-1$
          }

          public String getDefaultMessageText() {
            return "Please select a color."; //$NON-NLS-1$
          }

          public IObjectUi getObjectUi() {
            return new ColorUi();
          }

          public Object[] getItems() {
            return new Color[]{ Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA };
          }
        }).getDialog().getWindow());
  }

  private final class ColorUi implements IObjectUi {
    public String getLabel(Object value) {
      Color color = (Color) value;
      return color.getRed() + " " + color.getGreen() + " " + color.getBlue(); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public Icon getIcon(Object value) {
      final Color color = (Color) value;
      return new Icon() {
        public int getIconHeight() {
          return 16;
        }

        public int getIconWidth() {
          return 16;
        }

        public void paintIcon(Component c, Graphics g, int x, int y) {
          g.setColor(color);
          g.fillRect(2, 2, 14, 10);
          g.setColor(Color.BLACK);
          g.drawRect(2, 2, 14, 10);
        }
      };
    }
  }
}