/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;
import net.disy.commons.swing.ui.AbstractObjectUi;

public class BooleanRadioButtonComponent extends AbstractSmartDialogPanel {

  private static final class BooleanModelDecoratorModel extends ObjectModel<Boolean> {
    private final BooleanModel model;

    private BooleanModelDecoratorModel(final BooleanModel model) {
      this.model = model;
    }

    @Override
    public Boolean getValue() {
      return Boolean.valueOf(model.getValue());
    }

    @Override
    public void setValue(final Boolean value) {
      model.setValue(value.booleanValue());
    }

    @Override
    public void addChangeListener(final IChangeListener listener) {
      model.addChangeListener(listener);
    }

    @Override
    public void removeChangeListener(final IChangeListener listener) {
      model.removeChangeListener(listener);
    }
  }

  private final RadioButtonPanel<Boolean> booleanRadioButtonPanel;
  private final BooleanModel model;

  public BooleanRadioButtonComponent(
      final BooleanModel model,
      final String trueValueLabel,
      final String falseValueLabel) {
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    booleanRadioButtonPanel = new RadioButtonPanel<Boolean>(new Boolean[]{
        Boolean.TRUE,
        Boolean.FALSE }, new BooleanModelDecoratorModel(model), new AbstractObjectUi<Boolean>() {

      @Override
      public String getLabel(final Boolean value) {
        if (value.booleanValue()) {
          return trueValueLabel;
        }
        return falseValueLabel;
      }
    });
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  public void requestFocus() {
    booleanRadioButtonPanel.getContent().requestFocus();
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    panel.add(booleanRadioButtonPanel.getContent(), GridDialogLayoutDataFactory
        .createHorizontalSpanData(columnCount, GridDialogLayoutData.FILL_BOTH));
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return null;
  }

  public void setEnabled(final boolean isEnabled) {
    booleanRadioButtonPanel.setEnabled(isEnabled);
  }
}
