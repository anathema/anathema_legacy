/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component;

import javax.swing.JComboBox;

import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.object.component.AbstractObjectComboBox;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.ui.ToStringUi;

public class StringComboBox extends AbstractObjectComboBox<String>
    implements
    IStringInputComponent<JComboBox> {

  public StringComboBox(
      final IAttributeValueListFactory<String> presetValuesFactory,
      final IAttributeContext attributeContext) {
    super(presetValuesFactory, attributeContext, new ToStringUi<String>());
  }
}