/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.Dimension;
import java.awt.Rectangle;

import javax.swing.JComponent;
import javax.swing.JWindow;

import net.disy.commons.swing.util.GuiUtilities;

public class WindowToComponentOnScreenPositioner {

  public static void packAndAdjustPosition(final JComponent hookComponent, final JWindow window) {
    final Rectangle componentBounds = getBoundsOnScreen(hookComponent);
    final Rectangle screenBounds = GuiUtilities.calculateScreenBounds(hookComponent);
    final Dimension windowSize = window.getPreferredSize();

    final int newWidth = Math.max(windowSize.width, componentBounds.width);
    final int newHeight = windowSize.height;

    final int newY;
    if (doesNotFitBelow(windowSize, componentBounds, screenBounds)
        && isMoreSpaceAboveThanBelow(componentBounds, screenBounds)) {
      newY = componentBounds.y - windowSize.height;
    }
    else {
      newY = componentBounds.y + componentBounds.height;
    }
    final int newX = Math.min(componentBounds.x, screenBounds.x
        + screenBounds.width
        - windowSize.width);
    window.setBounds(newX, newY, newWidth, newHeight);
  }

  private static boolean isMoreSpaceAboveThanBelow(
      final Rectangle componentBounds,
      final Rectangle screenBounds) {
    final int spaceAbove = Math.max(0, componentBounds.y - screenBounds.y);
    final int spaceBelow = getSpaceBelow(componentBounds, screenBounds);
    return spaceAbove > spaceBelow;
  }

  private static int getSpaceBelow(final Rectangle componentBounds, final Rectangle screenBounds) {
    final int spaceBelow = Math.max(0, screenBounds.y
        + screenBounds.height
        - componentBounds.y
        - componentBounds.height);
    return spaceBelow;
  }

  private static boolean doesNotFitBelow(
      final Dimension windowSize,
      final Rectangle componentBounds,
      final Rectangle screenBounds) {
    return getSpaceBelow(componentBounds, screenBounds) < windowSize.height;
  }

  private static Rectangle getBoundsOnScreen(final JComponent component) {
    return new Rectangle(component.getLocationOnScreen(), component.getSize());
  }
}