// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard.demo;

import net.disy.commons.swing.dialog.wizard.WizardDialog;

import de.jdemo.extensions.SwingDemoCase;

public class WizardDemo extends SwingDemoCase {

  public void demo() {
    WizardDialog dialog = new WizardDialog(createJFrame(), new DemoWizard());
    show(dialog.getConfiguredDialog().getWindow());
  }
}