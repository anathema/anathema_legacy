/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.demo;

import net.disy.commons.swing.dialog.wizard.WizardDialog;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class WizardDemo extends SwingDemoCase {

  public void demo() {
    final WizardDialog dialog = new WizardDialog(createJFrame(), new DemoWizardConfiguration());
    show(dialog.getConfiguredDialog().getWindow());
  }

  public void demoWithHelp() {
    final WizardDialog dialog = new WizardDialog(createJFrame(), new DemoWizardConfiguration() {
      @Override
      public boolean isHelpAvailable() {
        return true;
      }
    });
    show(dialog.getConfiguredDialog().getWindow());
  }
}