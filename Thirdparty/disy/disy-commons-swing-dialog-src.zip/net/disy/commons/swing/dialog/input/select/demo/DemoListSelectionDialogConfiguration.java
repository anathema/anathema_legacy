/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select.demo;

import java.util.List;

import net.disy.commons.swing.dialog.input.select.AbstractListSelectionDialogConfiguration;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItemUi;
import net.disy.commons.swing.ui.IObjectUi;

public class DemoListSelectionDialogConfiguration
    extends
    AbstractListSelectionDialogConfiguration<DemoColorItem> {
  @Override
  public String getTitle() {
    return "Color"; //$NON-NLS-1$
  }

  @Override
  public String getNoItemSelectedErrorMessageText() {
    return "There is no color selected. Please select a color."; //$NON-NLS-1$
  }

  @Override
  public String getDefaultMessageText() {
    return "Please select a color."; //$NON-NLS-1$
  }

  @Override
  public IObjectUi<DemoColorItem> getObjectUi() {
    return new DemoColorItemUi();
  }

  @Override
  public DemoColorItem[] getItems() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    return items.toArray(new DemoColorItem[items.size()]);
  }

  @Override
  public String getLabel() {
    return "Available &Colors:"; //$NON-NLS-1$
  }
}