//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.swing.dialog.input.IInputDialogConfiguration;
import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public interface IOneOutOfManyDialogConfiguration extends IInputDialogConfiguration {

  public Object[] getItems();

  public IObjectUi getObjectUi();

  public String getNoItemSelectedErrorMessageText();

}