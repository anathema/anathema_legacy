package net.disy.commons.swing.dialog.core;

import net.disy.commons.core.message.IBasicMessage;

/**
 * @author gebhard
 */
public interface IPage {
  /** Returns the current message for this dialog page.
   * A message provides either instruction or information to the user, or an error
   * description which should describe some error state.
   * @return the message, or <code>null</code> if none */
  public IBasicMessage getMessage();

  /** Returns this dialog page's title.
  @return the title of this dialog page, or <code>null</code> if none */
  public String getTitle();
  
  /** Returns this dialog page's description text.
   * @return the description text for this dialog page, or <code>null</code> if none */
  public String getDescription();

  /** Notifies that help has been requested for this dialog page. */
  public void performHelp();
  
  /** Returns whether help is available for this DIALOG page.
   * The result of this method is typically used by the container to enable or disable the help
   * button. Note that the help button will only by visible if the coresponding Wizard returns
   * <code>true</code> in <code>isHelpAvailable</code>.
   *  
   * @return <code>true</code> if help is available, and <code>false</code> if this wizard page is
   * helpless */
  public boolean isHelpAvailable();
  
  public IPageContent getPageContent();
}