/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.ArrayList;

import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;

import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.input.text.component.StringComboBox;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class StringComboBox_updateValueList_Test {

  private IAttributeValueListFactory<String> valueListFactory;
  private IAttributeContext attributeContext;

  @SuppressWarnings("unchecked")
  @Before
  public void init() throws Exception {
    valueListFactory = createMock(IAttributeValueListFactory.class);
    attributeContext = createNiceMock(IAttributeContext.class);
    final ArrayList<String> firstList = new ArrayList<String>();
    firstList.add("an item"); //$NON-NLS-1$
    firstList.add("item"); //$NON-NLS-1$
    expect(valueListFactory.createList(attributeContext)).andReturn(firstList);
    final ArrayList<String> secondList = new ArrayList<String>();
    secondList.add("another item"); //$NON-NLS-1$
    secondList.add("some item"); //$NON-NLS-1$
    secondList.add("item"); //$NON-NLS-1$
    expect(valueListFactory.createList(attributeContext)).andReturn(secondList);
    replay(valueListFactory);
  }

  /** @see {@link StringComboBox_updateValueList_Test#updateDoesNotChangeValueList} */
  @Ignore("CAD-1380: Disabled due to performance reasons.")
  @Test
  public void updateCreatesNewValueList() throws Exception {
    final StringComboBox stringComboBox = new StringComboBox(valueListFactory, attributeContext);
    assertThat(stringComboBox.getComponent().getModel().getSize(), is(2));
    stringComboBox.update();
    final ComboBoxModel updatedComboBoxModel = stringComboBox.getComponent().getModel();
    assertThat(updatedComboBoxModel.getSize(), is(3));
    assertThat(updatedComboBoxModel.getElementAt(0), is((Object) "another item")); //$NON-NLS-1$
    assertThat(updatedComboBoxModel.getElementAt(1), is((Object) "some item")); //$NON-NLS-1$
    assertThat(updatedComboBoxModel.getElementAt(2), is((Object) "item")); //$NON-NLS-1$
    verify(valueListFactory);
  }

  /** @see {@link StringComboBox_updateValueList_Test#updateCreatesNewValueList} */
  @Test
  public void updateDoesNotChangeValueList() throws Exception {
    final StringComboBox stringComboBox = new StringComboBox(valueListFactory, attributeContext);
    assertThat(stringComboBox.getComponent().getModel().getSize(), is(2));
    stringComboBox.update();
    final ComboBoxModel updatedComboBoxModel = stringComboBox.getComponent().getModel();
    assertThat(updatedComboBoxModel.getSize(), is(2));
    assertThat(updatedComboBoxModel.getElementAt(0), is((Object) "an item")); //$NON-NLS-1$
    assertThat(updatedComboBoxModel.getElementAt(1), is((Object) "item")); //$NON-NLS-1$
  }

  @Test
  public void updateKeepsSelection() throws Exception {
    final StringComboBox stringComboBox = new StringComboBox(valueListFactory, attributeContext);
    stringComboBox.setValue("item"); //$NON-NLS-1$
    stringComboBox.update();
    final JComboBox comboBox = stringComboBox.getComponent();
    assertThat(comboBox.getSelectedItem(), is((Object) "item")); //$NON-NLS-1$
  }

  @Test
  public void updateSelectsFirstItemIfPreviouslySelectedItemIsNoLongerInList() throws Exception {
    final StringComboBox stringComboBox = new StringComboBox(valueListFactory, attributeContext);
    stringComboBox.setValue("an item"); //$NON-NLS-1$
    stringComboBox.update();
    final JComboBox comboBox = stringComboBox.getComponent();
    assertThat(comboBox.getSelectedIndex(), is(0));
  }
}