/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.event.ChangeListener;

public class GeneralTextAreaAttributeInputComponentFactory
    implements
    IStringAttributeInputComponentFactory<JScrollPane> {

  private final int rows;

  public GeneralTextAreaAttributeInputComponentFactory(int lines) {
    this.rows = lines;
  }

  @Override
  public IStringInputComponent<JScrollPane> createComponent() {
    final JTextArea textArea = new JTextArea();
    textArea.setAutoscrolls(true);
    textArea.setRows(this.rows);
    final StringTextField<JTextArea> stringTextField = new StringTextField<JTextArea>(textArea);
    final JScrollPane scrollPane = new JScrollPane(textArea);
    return new IStringInputComponent<JScrollPane>() {

      @Override
      public void update() {
        stringTextField.update();
      }

      @Override
      public void setValue(String value) {
        stringTextField.setValue(value);
      }

      @Override
      public void setEnabled(boolean enabled) {
        stringTextField.setEnabled(enabled);
      }

      @Override
      public void setEditable(boolean editable) {
        stringTextField.setEditable(editable);
      }

      @Override
      public void selectAll() {
        stringTextField.selectAll();
      }

      @Override
      public void requestFocus() {
        stringTextField.requestFocus();
      }

      @Override
      public boolean isEditable() {
        return stringTextField.isEditable();
      }

      @Override
      public String getValue() {
        return stringTextField.getValue();
      }

      @Override
      public JScrollPane getComponent() {
        return scrollPane;
      }

      @Override
      public void addChangeListener(ChangeListener changeListener) {
        stringTextField.addChangeListener(changeListener);
      }
    };
  }

}