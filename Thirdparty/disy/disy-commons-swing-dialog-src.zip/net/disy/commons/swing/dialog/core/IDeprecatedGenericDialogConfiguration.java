// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 28.04.2006
package net.disy.commons.swing.dialog.core;

import java.awt.Component;
import java.awt.Dimension;

// NOT_PUBLISHED
public interface IDeprecatedGenericDialogConfiguration extends IGenericDialogConfiguration {

  /** Performs any actions appropriate in response to the user having pressed the Cancel button,
   * or refuse if canceling now is not permitted.
   * 
   * @return <code>true</code> to indicate the cancel request was accepted, and <code>false</code>
   * to indicate that the cancel request was refused.
   * @deprecated as of 29.03.2006 (sieroux), replaced by model/view separation
   */
  @Deprecated
  public boolean performCancel(Component parentComponent);

  /** @deprecated As of 24.04.2006 (gebhard) - For modal dialogs just ask the dialog container
   * whether it was canceled() after showing it. For non-modal dialogs this should be connected to the
   * dialog buttons. */
  @Deprecated
  public void performAfterDispose(boolean canceled);

  /** @deprecated As of 18.03.2005 (gebhard). Adjust the layout of the contents instead. */
  @Deprecated
  public Dimension getDialogSize();
}