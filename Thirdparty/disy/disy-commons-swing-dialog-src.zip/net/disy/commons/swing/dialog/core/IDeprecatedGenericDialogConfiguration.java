// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 26.04.2006
package net.disy.commons.swing.dialog.core;

import java.awt.Component;

// NOT_PUBLISHED
public interface IDeprecatedGenericDialogConfiguration extends IGenericDialogConfiguration {

  /** Performs any actions appropriate in response to the user having pressed the Cancel button,
   * or refuse if canceling now is not permitted.
   * 
   * @return <code>true</code> to indicate the cancel request was accepted, and <code>false</code>
   * to indicate that the cancel request was refused.
   * @deprecated as of 29.03.2006 (sieroux), replaced by model/view separation
   */
  public boolean performCancel(Component parentComponent);
}