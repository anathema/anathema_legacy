/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core;

import java.awt.Image;
import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.util.Ensure;

public class DialogDefaults {

  private final static DialogDefaults instance = new DialogDefaults();

  public static DialogDefaults getInstance() {
    return instance;
  }

  private final List<Image> frameIconImages = new ArrayList<Image>();

  private DialogDefaults() {
    //nothing to do 
  }

  public void setFrameIconImage(final Image frameIconImage) {
    frameIconImages.clear();
    if (frameIconImage != null) {
      frameIconImages.add(frameIconImage);
    }
  }

  /** @deprecated As of 18.05.2010 (gebhard), replaced by {@link #getFrameIconImages()} */
  @Deprecated
  public Image getFrameIconImage() {
    return frameIconImages.isEmpty() ? null : frameIconImages.get(0);
  }

  public void setFrameIconImages(final List<? extends Image> frameIconImages) {
    Ensure.ensureArgumentNotNull(frameIconImages);
    this.frameIconImages.clear();
    this.frameIconImages.addAll(frameIconImages);
  }

  public List<Image> getFrameIconImages() {
    return frameIconImages;
  }
}