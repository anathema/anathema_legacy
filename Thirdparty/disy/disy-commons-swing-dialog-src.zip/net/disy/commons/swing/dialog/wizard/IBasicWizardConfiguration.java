// Copyright (c) 2006 by disy Informationssysteme GmbH
// Created on 26.04.2006
package net.disy.commons.swing.dialog.wizard;

import net.disy.commons.swing.dialog.core.IGenericDialogConfiguration;

// NOT_PUBLISHED
public interface IBasicWizardConfiguration extends IGenericDialogConfiguration {

  /** Returns the first page to be shown in this wizard.
   * @return the first wizard page */
  public IBasicWizardPage getStartingPage();

  /** Returns the container of this wizard.
   * @return the wizard container, or <code>null</code> if this wizard has yet to be added to
   * a container */
  public IWizardContainer getContainer();

  /** Sets or clears the container of this wizard.
   * @param wizardContainer the wizard container, or <code>null</code> */
  public void setContainer(IWizardContainer wizardContainer);

  /** Returns whether this wizard could be finished without further user interaction.
   * The result of this method is typically used by the wizard container to enable or disable
   * the Finish button.
   * 
   * @return <code>true</code> if the wizard could be finished, and <code>false</code> otherwise */
  public boolean canFinish();

  /** Returns whether help is available for this wizard.
   * The result of this method is typically used by the container to show or hide the Help button.
   * 
   * @return <code>true</code> if help is available, and <code>false</code> if this wizard is
   * helpless */
  public boolean isHelpAvailable();
}