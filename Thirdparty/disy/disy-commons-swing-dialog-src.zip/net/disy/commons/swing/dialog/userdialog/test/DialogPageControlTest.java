/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import net.disy.commons.swing.dialog.userdialog.DialogPageControl;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.test.TestDialogPage;

import org.junit.Test;

public class DialogPageControlTest {

  @Test
  public void delegatesCanFinishToDialogPage() throws Exception {
    assertThat(new DialogPageControl(createDialogPage(false)).canFinish(), is(false));
    assertThat(new DialogPageControl(createDialogPage(true)).canFinish(), is(true));
  }

  private IDialogPage createDialogPage(final boolean canFinish) {
    return new TestDialogPage() {
      @Override
      public boolean canFinish() {
        return canFinish;
      }
    };
  }
}