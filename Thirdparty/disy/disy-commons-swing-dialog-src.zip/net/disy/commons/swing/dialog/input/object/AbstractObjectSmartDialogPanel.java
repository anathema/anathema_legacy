/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.component.Gap;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.object.component.IObjectAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.object.component.IObjectInputComponent;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public abstract class AbstractObjectSmartDialogPanel<O> extends AbstractLabeledSmartDialogPanel {

  private final IObjectModel<O> stringModel;
  private final IObjectInputComponent<O, ?> inputComponent;
  private final IMessageProducingValidator validator;
  private final boolean grabSpace;

  public AbstractObjectSmartDialogPanel(
      final String label,
      final String toolTipText,
      final IObjectModel<O> stringModel,
      final IObjectAttributeInputComponentFactory<O, ?> componentFactory,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, stringModel, componentFactory, validator, true);
  }

  public AbstractObjectSmartDialogPanel(
      final String label,
      final String toolTipText,
      final IObjectModel<O> stringModel,
      final IObjectAttributeInputComponentFactory<O, ?> componentFactory,
      final IMessageProducingValidator validator,
      final boolean grabSpace) {
    super(label, toolTipText, validator);
    Ensure.ensureArgumentNotNull(stringModel);
    Ensure.ensureArgumentNotNull(validator);
    this.stringModel = stringModel;
    this.validator = validator;
    this.grabSpace = grabSpace;
    inputComponent = componentFactory.createComponent();
    inputComponent.addChangeListener(new ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent e) {
        stringModel.setValue(inputComponent.getValue());
      }
    });

    stringModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateInputComponent();
      }
    });
    updateInputComponent();
  }

  private void updateInputComponent() {
    if (ObjectUtilities.equals(inputComponent.getValue(), stringModel.getValue())) {
      return;
    }
    inputComponent.setValue(stringModel.getValue());
  }

  @Override
  protected int getMainComponentColumnCount() {
    return grabSpace ? 1 : 2;
  }

  @Override
  protected JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setGrabExcessHorizontalSpace(grabSpace);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    if (grabSpace) {
      layoutData.setHorizontalSpan(columnCount);
    }
    else {
      layoutData.setHorizontalSpan(columnCount - 1);
    }
    panel.add(inputComponent.getComponent(), layoutData);
    if (!grabSpace) {
      panel.add(new Gap());
    }
    return inputComponent.getComponent();
  }

  @Override
  public final IBasicMessage createOptionalCurrentMessage() {
    return validator.createOptionalCurrentMessage();
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    stringModel.addChangeListener(listener);
  }

  public void selectAll() {
    inputComponent.selectAll();
  }

  @Override
  public void requestFocus() {
    inputComponent.requestFocus();
  }

  public void setEditable(final boolean editable) {
    inputComponent.setEditable(editable);
  }

  public boolean isEditable() {
    return inputComponent.isEditable();
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    inputComponent.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ inputComponent.getComponent() };
  }

  @Override
  public void update() {
    inputComponent.update();
  }

}