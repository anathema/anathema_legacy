/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.combobox.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.core.util.Ensure;

public final class DemoColorIcon implements Icon {
  private final Color color;

  public DemoColorIcon(final Color color) {
    Ensure.ensureArgumentNotNull(color);
    this.color = color;
  }

  @Override
  public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
    g.setColor(color);
    g.fillRect(2, 2, 14, 12);
    g.setColor(Color.BLACK);
    g.drawRect(2, 2, 14, 12);
  }

  @Override
  public int getIconWidth() {
    return 16;
  }

  @Override
  public int getIconHeight() {
    return 16;
  }
}