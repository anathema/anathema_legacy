/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.date.demo;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;

import org.junit.runner.RunWith;

import net.disy.commons.core.date.DateConfiguration;
import net.disy.commons.core.date.IDateConfiguration;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.date.CalendarDialogPage;
import net.disy.commons.swing.dialog.userdialog.demo.AbstractDialogDemo;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class CalendarDialogPageDemo extends AbstractDialogDemo {

  private void showCalendarPage(final IDateConfiguration configuration) {
    final ObjectModel<Calendar> model = new ObjectModel<Calendar>(new GregorianCalendar());
    final CalendarDialogPage page = new CalendarDialogPage(model, configuration);
    show(page);
  }

  public void demoDateWithoutDay() throws Exception {
    showCalendarPage(new DateConfiguration("MMyyy")); //$NON-NLS-1$
  }

  public void demoDateOnly() throws Exception {
    showCalendarPage(new DateConfiguration("ddMMyyy")); //$NON-NLS-1$
  }

  public void demoTimeOnly() throws Exception {
    showCalendarPage(new DateConfiguration("HH:mm:ssss")); //$NON-NLS-1$
  }

  public void demoCompleteCalendarInGerman() throws Exception {
    Locale.setDefault(Locale.GERMAN);
    showCalendarPage(new DateConfiguration("ddMMyyy HH:mm:ssss")); //$NON-NLS-1$
  }

  public void demoCompleteCalendarInEnglish() throws Exception {
    Locale.setDefault(Locale.ENGLISH);
    showCalendarPage(new DateConfiguration("ddMMyyy HH:mm:ssss")); //$NON-NLS-1$
  }
}