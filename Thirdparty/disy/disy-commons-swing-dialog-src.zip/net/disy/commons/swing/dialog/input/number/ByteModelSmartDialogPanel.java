/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;

public class ByteModelSmartDialogPanel extends IntegralNumberSmartDialogPanel<Byte> {

  public ByteModelSmartDialogPanel(
      final String label,
      final ObjectModel<Byte> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public ByteModelSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<Byte> model,
      final IMessageProducingValidator validator) {
    super(
        label,
        toolTipText,
        model,
        validator,
        new Byte((byte) 0),
        Byte.valueOf(Byte.MIN_VALUE),
        Byte.valueOf(Byte.MAX_VALUE));
  }

  @Override
  protected Byte convertToNumber(final Long value) {
    return Byte.valueOf(value.byteValue());
  }
}