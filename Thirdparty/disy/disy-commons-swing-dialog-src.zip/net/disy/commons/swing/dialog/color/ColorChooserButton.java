/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class ColorChooserButton extends AbstractColorChoosingComponent {

  public ColorChooserButton() {
    this(new ColorModel());
  }

  public ColorChooserButton(final ColorModel model) {
    super(model);
  }

  public ColorChooserButton(final ColorModel model, final IColorChooserConfiguration configuration) {
    super(model, configuration);
  }

  @Override
  protected final JComponent createContent() {
    final JButton button = createButton();
    button.setOpaque(false);
    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        performColorChooseDialog();
      }
    });
    button.setToolTipText(getTooltipText());
    return button;
  }

  private String getTooltipText() {
    return DisyCommonsSwingMessages.getString("ColorChooseButton.ToolTip"); //$NON-NLS-1$
  }

  private JButton createButton() {
    final JButton button = new JButton();
    /* 02.11.2005 (gebhard): Color rectangle must be painted as Icon: Overriding paint...() will
     * not work, since some look and feels will add decorations. 
     */
    final Icon icon = createIcon(button);
    button.setIcon(icon);
    final int twoPixels = LayoutUtilities.getDpiAdjusted(2);
    button.setMargin(new Insets(twoPixels, twoPixels, twoPixels, twoPixels));
    return button;
  }

  private Icon createIcon(final JButton button) {
    return new Icon() {
      @Override
      public int getIconHeight() {
        return 13;
      }

      @Override
      public int getIconWidth() {
        return 49;
      }

      @Override
      public void paintIcon(final Component c, final Graphics g, final int x, final int y) {
        paintColorRectangle(g, x, y, new Dimension(getIconWidth(), getIconHeight()), button
            .isEnabled());
      }
    };
  }
}