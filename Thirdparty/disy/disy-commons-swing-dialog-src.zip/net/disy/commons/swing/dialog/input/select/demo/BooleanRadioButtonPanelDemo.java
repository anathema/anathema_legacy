/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select.demo;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.SmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.check.CheckBoxSmartDialogPanel;
import net.disy.commons.swing.dialog.input.select.BooleanRadioButtonComponent;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class BooleanRadioButtonPanelDemo extends SwingDemoCase {

  public void demo() {
    final boolean defaultValue = true;
    final BooleanModel model = new BooleanModel(defaultValue);
    final BooleanRadioButtonComponent radioButtonComponent = new BooleanRadioButtonComponent(
        model,
        "Model auf TRUE (Checkbox aktiviert)", //$NON-NLS-1$
        "Model auf FALSE (Checkbox deaktiviert)"); //$NON-NLS-1$
    final CheckBoxSmartDialogPanel checkBoxSmartDialogPanel = new CheckBoxSmartDialogPanel(
        new BooleanModel(true),
        "test"); //$NON-NLS-1$
    final IChangeListener listener = new IChangeListener() {

      @Override
      public void stateChanged() {
        checkBoxSmartDialogPanel.setEnabled(model.getValue());
      }

    };
    radioButtonComponent.addChangeListener(listener);
    final SmartDialogPanelsBuilder builder = new SmartDialogPanelsBuilder();
    builder.add(radioButtonComponent);
    builder.add(checkBoxSmartDialogPanel);
    show(builder.createResult().getCompletePanel());
  }
}