package net.disy.commons.swing.dialog.userdialog;

import net.disy.commons.swing.dialog.core.IDialogContainer;

/**
 * @author gebhard
 */
public interface IUserDialogContainer extends IDialogContainer {
  public void setVisible(boolean visible);

}