/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.demo;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;

import net.disy.commons.swing.dialog.input.text.suggest.ISuggestionTextFieldConfiguration;
import net.disy.commons.swing.dialog.input.text.suggest.SuggestionTextField;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;
import net.disy.commons.swing.widgets.AutoWrappingLabel;
import de.jdemo.extensions.SwingDemoCase;

@SuppressWarnings("nls")
public class SuggestionTextFieldDemo extends SwingDemoCase {

  public void demo() {
    final ISuggestionTextFieldConfiguration<String> configuration = new DemoSuggestionTextFieldConfiguration();
    final SuggestionTextField<String> textField = new SuggestionTextField<String>(configuration);

    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(textField.getContent());
    panel.add(new JTextField("other textfield"));
    panel.add(
        new AutoWrappingLabel("Type any text to get dummy search results.\n"
            + "Type \"long...\" to get long results.\n"
            + "Type \"empty\" to get empty results.\n"
            + "Type \"a...\" to get results with a message.\n"
            + "Type \"error\" to get an error requesting the results.").getContent(),
        GridDialogLayoutDataFactory.createHorizontalSpanData(2, GridDialogLayoutData.FILL_BOTH));
    show(panel);
  }

  public void demoSuggestionTextInSplitPane() {
    final ISuggestionTextFieldConfiguration<String> configuration = new DemoSuggestionTextFieldConfiguration();
    final SuggestionTextField<String> textField = new SuggestionTextField<String>(configuration);

    final JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JLabel(
        "Left component"), textField.getContent());
    show(splitPane);
  }

  public void demoWithIconInsideTextField() {
    final ISuggestionTextFieldConfiguration<String> configuration = new DemoSuggestionTextFieldConfiguration();
    final SuggestionTextField<String> textField = new SuggestionTextField<String>(configuration);
    show(textField.getContent());
  }
}