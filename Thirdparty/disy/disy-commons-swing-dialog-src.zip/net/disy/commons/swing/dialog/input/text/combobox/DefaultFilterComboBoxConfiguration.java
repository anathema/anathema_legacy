/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.combobox;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.ui.IObjectUi;

public class DefaultFilterComboBoxConfiguration<T> extends AbstractFilterComboBoxConfiguration<T> {

  private final IObjectUi<T> objectUi;

  public DefaultFilterComboBoxConfiguration(IObjectUi<T> objectUi) {
    Ensure.ensureArgumentNotNull(objectUi);
    this.objectUi = objectUi;
  }

  @Override
  public String getToolTipText() {
    return null;
  }

  @Override
  public IObjectUi<T> getObjectUi() {
    return objectUi;
  }

  @Override
  public String getNoResultLabelText() {
    return "Keine Treffer";
  }

  @Override
  public boolean isClearButtonVisible() {
    return false;
  }

}
