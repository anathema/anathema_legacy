//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.Dimension;

// NOT_PUBLISHED
public interface IGenericDialog {
  /** Performs any actions appropriate in response to the user having pressed the Cancel button,
   * or refuse if canceling now is not permitted.
   * 
   * @return <code>true</code> to indicate the cancel request was accepted, and <code>false</code>
   * to indicate that the cancel request was refused.
   */
  public boolean performCancel();
  
  public void performAfterDispose(boolean canceled);

  /** @return whether the header panel in the dialog shall be visible or not. */
  public boolean isHeaderPanelVisible();
  
  /** @deprecated As of 18.03.2005 (gebhard). Adjust the layout of the contents instead. */
  public Dimension getDialogSize();

  //TODO 20.11.2003 (gebhard): Umbenennen in isCancelButtonAvailable()
  public boolean isCancelAvailable();

  public String getCancelButtonText();

  public boolean isOkButtonAvailable();

  public String getOkButtonText();

}