package net.disy.commons.swing.dialog.input;

import javax.swing.JButton;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;

public final class ButtonSmartDialogPanel extends AbstractSmartDialogPanel {
  private final JButton button;

  public ButtonSmartDialogPanel(final SmartAction action) {
    Ensure.ensureArgumentNotNull(action);
    button = new JButton(action);
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData data = GridDialogLayoutDataFactory
        .createHorizontalSpanData(columnCount);
    panel.add(button, data);
  }

  @Override
  public void requestFocus() {
    button.requestFocus();
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return null;
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    //nothing to do
  }
}