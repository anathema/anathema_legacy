/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.message;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.Ensure;

public class DialogMessageHandler implements IDialogMessageHandler {

  private final IBasicMessage defaultMessage;
  private final IErrorMessageProvider errorMessageProvider;

  public DialogMessageHandler(
      final String defaultMessageText,
      final IErrorMessageProvider errorMessageProvider) {
    Ensure.ensureArgumentNotNull("DefaultMessage must not be null.", defaultMessageText); //$NON-NLS-1$
    Ensure.ensureArgumentNotNull("ErrorMessageHandler must not be null.", errorMessageProvider); //$NON-NLS-1$
    this.defaultMessage = new BasicMessage(defaultMessageText);
    this.errorMessageProvider = errorMessageProvider;
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    final IBasicMessage errorMessage = errorMessageProvider.getErrorMessage();
    if (errorMessage != null) {
      return errorMessage;
    }
    return getDefaultMessage();
  }

  @Override
  public IBasicMessage getDefaultMessage() {
    return defaultMessage;
  }
}