/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.managed;

import javax.swing.JComponent;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.core.IDialogHelpHandler;
import net.disy.commons.swing.dialog.input.IRequestFinishListener;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;
import net.disy.commons.swing.dialog.wizard.AbstractWizardPage;
import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;

public class DialogWizardPageAdapter extends AbstractWizardPage implements IManagedWizardPage {

  private final IDialogPage dialogPage;

  public DialogWizardPageAdapter(final IDialogPage dialogPage, final IWizardConfiguration wizard) {
    super(dialogPage.getDescription(), dialogPage.getTitle(), dialogPage
        .getDefaultMessage()
        .getText(), wizard);
    this.dialogPage = dialogPage;
    dialogPage.setInputValidListener(getCheckInputValidListener());
    dialogPage.addRequestFinishListener(new IRequestFinishListener() {
      @Override
      public void requestFinish() {
        DialogWizardPageAdapter.this.fireRequestFinish();
      }
    });
    addDisposable(dialogPage);
  }

  @Override
  protected final IBasicMessage createCurrentMessage() {
    return dialogPage.createCurrentMessage();
  }

  @Override
  protected final JComponent createContent() {
    return dialogPage.createContent();
  }

  @Override
  public IDialogHelpHandler getHelpHandler() {
    return dialogPage.getHelpHandler();
  }

  @Override
  public final void requestFocus() {
    dialogPage.requestFocus();
  }

  @Override
  public boolean isApplicable() {
    return true;
  }

  @Override
  public void enter() {
    dialogPage.enter();
  }

  @Override
  public void leave() {
    dialogPage.leave();
  }

  @Override
  public boolean canFinish() {
    // TODO (gebhard) 19.03.2007: Stimmt nur, wenn die Seite die letzte Seite sein darf (ip, rc)
    return dialogPage.canFinish();
  }
}