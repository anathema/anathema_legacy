/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional;

import java.util.Date;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.combo.BooleanModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.date.DateSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.ByteModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.DoubleModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.IntegerModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.LongModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.ShortModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.DefaultTextSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.component.StringInputComponentFactoryFactory;

public class OptionalSmartDialogPanelFactory implements IOptionalSmartDialogPanelFactory {

  private final String printName;
  private final IMessageProducingValidator validator;
  private final String toolTipText;

  public OptionalSmartDialogPanelFactory(
      final String printName,
      final IMessageProducingValidator validator) {
    this(printName, null, validator);
  }

  public OptionalSmartDialogPanelFactory(
      final String printName,
      final String toolTipText,
      final IMessageProducingValidator validator) {
    this.printName = printName;
    this.toolTipText = toolTipText;
    this.validator = validator;
  }

  @Override
  public IOptionalSmartDialogPanel createBytePanel(
      final ObjectModel<Byte> model,
      final boolean mandatory) {
    Byte initialFieldValue = model.getValue() == null ? new Byte((byte) 0) : model.getValue();
    final ObjectModel<Byte> fieldModel = new ObjectModel<Byte>(initialFieldValue);
    final ByteModelSmartDialogPanel dialogPanel = new ByteModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createDatePanel(
      final ObjectModel<Date> model,
      final boolean mandatory,
      final String formatPattern) {
    final ObjectModel<Date> fieldModel = new ObjectModel<Date>(model.getValue());
    final DateSmartDialogPanel dialogPanel = new DateSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator,
        formatPattern,
        false);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createDoublePanel(
      final ObjectModel<Double> model,
      final boolean mandatory) {
    Double initialFieldValue = model.getValue() == null ? new Double(0) : model.getValue();
    final ObjectModel<Double> fieldModel = new ObjectModel<Double>(initialFieldValue);
    final DoubleModelSmartDialogPanel dialogPanel = new DoubleModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createIntegerPanel(
      final ObjectModel<Integer> model,
      final boolean mandatory) {
    Integer initialFieldValue = model.getValue() == null ? new Integer(0) : model.getValue();
    final ObjectModel<Integer> fieldModel = new ObjectModel<Integer>(initialFieldValue);
    final IntegerModelSmartDialogPanel dialogPanel = new IntegerModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createLongPanel(
      final ObjectModel<Long> model,
      final boolean mandatory) {
    Long initialFieldValue = model.getValue() == null ? new Long(0) : model.getValue();
    final ObjectModel<Long> fieldModel = new ObjectModel<Long>(initialFieldValue);
    final LongModelSmartDialogPanel dialogPanel = new LongModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createShortPanel(
      final ObjectModel<Short> model,
      final boolean mandatory) {
    Short initialFieldValue = model.getValue() == null ? new Short((short) 0) : model.getValue();
    final ObjectModel<Short> fieldModel = new ObjectModel<Short>(initialFieldValue);
    final ShortModelSmartDialogPanel dialogPanel = new ShortModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createStringPanel(
      final ObjectModel<String> model,
      final boolean mandatory,
      final IAttributeValueListFactory<String> valueListFactory,
      final IAttributeContext attributeContext) {
    final ObjectModel<String> fieldModel = new ObjectModel<String>(model.getValue());
    final DefaultTextSmartDialogPanel dialogPanel = new DefaultTextSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        new StringInputComponentFactoryFactory().createFactory(valueListFactory, attributeContext),
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  @Override
  public IOptionalSmartDialogPanel createBooleanPanel(
      final ObjectModel<Boolean> model,
      final boolean mandatory) {
    final ObjectModel<Boolean> fieldModel = new ObjectModel<Boolean>(model.getValue());
    final BooleanModelSmartDialogPanel dialogPanel = new BooleanModelSmartDialogPanel(
        getLabel(),
        toolTipText,
        fieldModel,
        validator);
    return createOptionalPanel(model, mandatory, dialogPanel, fieldModel);
  }

  protected <T extends Object> IOptionalSmartDialogPanel createOptionalPanel(
      final ObjectModel<T> model,
      final boolean mandatory,
      final IUpdatableSmartDialogPanel dialogPanel,
      final ObjectModel<T> fieldModel) {
    return new OptionalSmartDialogPanel<T>(model, dialogPanel, fieldModel, mandatory);
  }

  private String getLabel() {
    return printName + ':';
  }
}
