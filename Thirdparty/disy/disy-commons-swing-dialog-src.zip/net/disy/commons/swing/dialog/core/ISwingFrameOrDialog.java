//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.Container;
import java.awt.Window;
import java.awt.event.WindowListener;

import javax.swing.JRootPane;

// NOT_PUBLISHED
public interface ISwingFrameOrDialog {

  public void setTitle(String title);

  public JRootPane getRootPane();

  public void pack();

  public void setModal(boolean modal);

  public Container getContentPane();

  public void setDefaultCloseOperation(int closeOperation);

  public void addWindowListener(WindowListener windowListener);

  public void dispose();

  public void validate();

  public void repaint();

  public Window getWindow();

  public void setResizable(boolean resizable);

  public void show();

  public void setVisible(boolean visible);

  public boolean isVisible();

}