//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;

import javax.swing.Icon;

import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class ColorUi implements IObjectUi {
  public String getLabel(Object value) {
    Color color = (Color) value;
    if (color == null) {
      return null;
    }
    return color.getRed() + " " + color.getGreen() + " " + color.getBlue(); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public Icon getIcon(Object value) {
    final Color color = (Color) value;
    if (color == null) {
      return null;
    }
    return new Icon() {
      public int getIconHeight() {
        return 16;
      }

      public int getIconWidth() {
        return 16;
      }

      public void paintIcon(Component c, Graphics g, int x, int y) {
        g.setColor(color);
        g.fillRect(2, 2, 14, 10);
        g.setColor(Color.BLACK);
        g.drawRect(2, 2, 14, 10);
      }
    };
  }
}