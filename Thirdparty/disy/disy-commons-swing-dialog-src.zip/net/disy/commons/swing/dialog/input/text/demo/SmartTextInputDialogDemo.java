//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.demo;

import net.disy.commons.swing.dialog.input.text.ITextInputDialogConfiguration;
import net.disy.commons.swing.dialog.input.text.SmartTextInputDialog;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class SmartTextInputDialogDemo extends SwingDemoCase {

  public void demoWithoutMessage() {
    show(SmartTextInputDialog.createDemoDialog(
        createParentComponent(),
        new ITextInputDialogConfiguration() {
          public String getLabelText() {
            return "Name:"; //$NON-NLS-1$
          }

          public String getTitle() {
            return "Text Input"; //$NON-NLS-1$
          }

          public String getDefaultMessageText() {
            return "Please enter some text."; //$NON-NLS-1$
          }

          public IBasicMessage createCurrentMessage(String selectedText) {
            return null;
          }
        },
        "initialText").getDialog().getWindow()); //$NON-NLS-1$
  }

  public void demoWithMessage() {
    show(SmartTextInputDialog.createDemoDialog(
        createParentComponent(),
        new ITextInputDialogConfiguration() {
          public String getLabelText() {
            return "Name:"; //$NON-NLS-1$
          }

          public String getTitle() {
            return "Text Input"; //$NON-NLS-1$
          }

          public String getDefaultMessageText() {
            return "Please enter some text."; //$NON-NLS-1$
          }

          public IBasicMessage createCurrentMessage(String selectedText) {
            if (selectedText == null || selectedText.equals("")) { //$NON-NLS-1$
              return new BasicMessage(
                  "The text is empty. Please enter some text.", //$NON-NLS-1$
                  MessageType.ERROR);
            }

            return null;
          }
        },
        "initialText").getDialog().getWindow()); //$NON-NLS-1$
  }
}
