/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.demo;

import org.junit.runner.RunWith;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.input.text.ITextInputDialogConfiguration;
import net.disy.commons.swing.dialog.input.text.SmartTextInputDialog;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class SmartTextInputDialogDemo extends SwingDemoCase {

  public void demoWithoutMessage() {
    final ITextInputDialogConfiguration configuration = new ITextInputDialogConfiguration() {
      @Override
      public String getLabelText() {
        return "&Name:"; //$NON-NLS-1$
      }

      @Override
      public String getTitle() {
        return "Text Input"; //$NON-NLS-1$
      }

      @Override
      public String getDefaultMessageText() {
        return "Please enter some text."; //$NON-NLS-1$
      }

      @Override
      public IBasicMessage createCurrentMessage(String selectedText) {
        return null;
      }
    };
    show(SmartTextInputDialog.createDemoDialog(
        createParentComponent(),
        configuration,
        "initialText").getDialog().getWindow()); //$NON-NLS-1$
  }

  public void demoWithMessage() {
    final ITextInputDialogConfiguration configuration = new ITextInputDialogConfiguration() {
      @Override
      public String getLabelText() {
        return "&Name:"; //$NON-NLS-1$
      }

      @Override
      public String getTitle() {
        return "Text Input"; //$NON-NLS-1$
      }

      @Override
      public String getDefaultMessageText() {
        return "Please enter some text."; //$NON-NLS-1$
      }

      @Override
      public IBasicMessage createCurrentMessage(String selectedText) {
        if (selectedText == null || selectedText.equals("")) { //$NON-NLS-1$
          return new BasicMessage("The text is empty. Please enter some text.", //$NON-NLS-1$
              MessageType.ERROR);
        }

        return null;
      }
    };
    show(SmartTextInputDialog.createDemoDialog(
        createParentComponent(),
        configuration,
        "initialText").getDialog().getWindow()); //$NON-NLS-1$
  }
}
