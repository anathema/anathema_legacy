/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.date;

import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public class HorizontalCenteredPanel extends JPanel {

  public HorizontalCenteredPanel(final JPanel content) {
    setLayout(new GridDialogLayout(1, false));
    final GridDialogLayoutData layoutData = new GridDialogLayoutData(GridDialogLayoutData.CENTER);
    layoutData.setGrabExcessHorizontalSpace(true);
    add(content, layoutData);
  }
}