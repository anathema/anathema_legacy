/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core.preferences;

import java.awt.Frame;
import java.awt.Rectangle;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.preferences.IPreferences;

public abstract class AbstractFramePreferences {

  private static final String KEY_X = "X"; //$NON-NLS-1$
  private static final String KEY_Y = "Y"; //$NON-NLS-1$
  private static final String KEY_WIDTH = "WIDTH"; //$NON-NLS-1$
  private static final String KEY_HEIGHT = "HEIGHT"; //$NON-NLS-1$
  private static final String KEY_STATE = "STATE"; //$NON-NLS-1$

  private final IPreferences preferences;
  private final FrameBoundsState defaultState;

  public AbstractFramePreferences(
      final IPreferences preferences,
      final FrameBoundsState defaultState) {
    Ensure.ensureArgumentNotNull(preferences);
    Ensure.ensureArgumentNotNull(defaultState);
    this.preferences = preferences;
    this.defaultState = defaultState;
  }

  public FrameBoundsState loadFrameBoundsState() {
    final int x = preferences.getInt(KEY_X, defaultState.getBounds().x);
    final int y = preferences.getInt(KEY_Y, defaultState.getBounds().y);
    final int width = preferences.getInt(KEY_WIDTH, defaultState.getBounds().width);
    final int height = preferences.getInt(KEY_HEIGHT, defaultState.getBounds().height);
    final int extendedState = preferences.getInt(KEY_STATE, defaultState.getExtendedFrameState());
    return new FrameBoundsState(new Rectangle(x, y, width, height), extendedState);
  }

  public void saveFrameBoundsState(final FrameBoundsState state) {
    preferences.putInt(KEY_STATE, state.getExtendedFrameState(), defaultState
        .getExtendedFrameState());
    if (state.getExtendedFrameState() != Frame.MAXIMIZED_BOTH) {
      preferences.putInt(KEY_X, state.getBounds().x, defaultState.getBounds().x);
      preferences.putInt(KEY_Y, state.getBounds().y, defaultState.getBounds().y);
      preferences.putInt(KEY_WIDTH, state.getBounds().width, defaultState.getBounds().width);
      preferences.putInt(KEY_HEIGHT, state.getBounds().height, defaultState.getBounds().height);
    }
    preferences.flush();
  }
}