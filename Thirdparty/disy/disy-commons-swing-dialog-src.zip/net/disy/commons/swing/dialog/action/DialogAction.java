/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.action;

import java.awt.Component;

import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class DialogAction extends SmartAction {

  private final IDialogInput input;

  public DialogAction(final IActionConfiguration configuration, final IDialogInput input) {
    super(configuration);
    this.input = input;
  }

  @Override
  protected void execute(final Component parentComponent) {
    final IDialogPage dialogPage = input.createPage();
    final UserDialog userDialog = new UserDialog(parentComponent, dialogPage);
    final IDialogResult result = userDialog.show();
    if (result.isCanceled()) {
      return;
    }
    input.confirm();
  }

  public boolean evaluateInput(final IPredicate<IDialogInput> predicate) {
    return predicate.evaluate(input);
  }
}