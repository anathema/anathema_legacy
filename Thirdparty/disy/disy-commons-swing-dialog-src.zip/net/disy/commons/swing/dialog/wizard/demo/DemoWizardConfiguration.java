// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard.demo;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.dialog.wizard.AbstractWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPage;

public class DemoWizardConfiguration extends AbstractWizardConfiguration {
  private List pages = new ArrayList();

  public void addPages() {
    int pageCount = 5;
    for (int i = 0; i < pageCount; ++i) {
      add(new DemoWizardPage(i + 1, pageCount));
    }
  }

  private void add(DemoWizardPage page) {
    pages.add(page);
    page.setWizard(this);
  }

  public IWizardPage getStartingPage() {
    return (IWizardPage) pages.get(0);
  }

  public IWizardPage getNextPage(IWizardPage page) {
    int i = pages.indexOf(page);
    if (i == pages.size() - 1) {
      return null;
    }
    return (IWizardPage) pages.get(i + 1);
  }

  public IWizardPage getPreviousPage(IWizardPage page) {
    int i = pages.indexOf(page);
    if (i == 0) {
      return null;
    }
    return (IWizardPage) pages.get(i - 1);
  }

  public boolean canFinish() {
    return false;
  }

  public boolean isHelpAvailable() {
    return false;
  }
}