/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.demo;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.swing.dialog.wizard.AbstractWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.AbstractWizardPage;
import net.disy.commons.swing.dialog.wizard.IWizardPage;

public class DemoWizardConfiguration extends AbstractWizardConfiguration {
  private final List<AbstractWizardPage> pages = new ArrayList<AbstractWizardPage>();

  @Override
  public void addPages() {
    final int pageCount = 2;
    for (int i = 0; i < pageCount; ++i) {
      add(new DemoWizardPage(i + 1));
    }
  }

  private void add(final AbstractWizardPage page) {
    pages.add(page);
    page.setWizard(this);
  }

  @Override
  public IWizardPage getStartingPage() {
    return pages.get(0);
  }

  @Override
  public IWizardPage getNextPage(final IWizardPage page) {
    final int i = pages.indexOf(page);
    if (i == pages.size() - 1) {
      return null;
    }
    return pages.get(i + 1);
  }

  @Override
  public IWizardPage getPreviousPage(final IWizardPage page) {
    final int i = pages.indexOf(page);
    if (i == 0) {
      return null;
    }
    return pages.get(i - 1);
  }

  @Override
  public boolean canFinish() {
    return false;
  }

  @Override
  public boolean isHelpAvailable() {
    return false;
  }
}