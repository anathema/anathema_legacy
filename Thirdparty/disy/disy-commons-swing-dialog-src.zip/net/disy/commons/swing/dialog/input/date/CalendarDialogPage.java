/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.date;

import java.util.Calendar;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.date.IDateConfiguration;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.calendar.SmartCalendarFieldChooser;
import net.disy.commons.swing.calendar.SmartDayChooser;
import net.disy.commons.swing.calendar.SmartMonthChooser;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogMessages;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;
import net.disy.commons.swing.label.SmartLabel;
import net.disy.commons.swing.layout.grid.EndOfLineMarkerComponent;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;

public class CalendarDialogPage extends AbstractDialogPage {

  private final ObjectModel<Calendar> calendarModel;
  private final IDateConfiguration dateConfiguration;

  public CalendarDialogPage(
      final ObjectModel<Calendar> calendar,
      final IDateConfiguration dateConfiguration) {
    super(DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.DefaultMessage")); //$NON-NLS-1$
    this.calendarModel = calendar;
    this.dateConfiguration = dateConfiguration;
  }

  @Override
  public JComponent createContent() {
    final JPanel panel = new JPanel(new GridDialogLayout(3, false));
    if (dateConfiguration.isDayEnabled()) {
      final JComponent chooser = new SmartDayChooser(calendarModel).getContent();
      panel
          .add(
              new SmartLabel(DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.DayLabel"), chooser), GridDialogLayoutDataFactory.createTopData()); //$NON-NLS-1$
      panel.add(chooser, GridDialogLayoutDataFactory.createHorizontalSpanData(2));
    }
    if (dateConfiguration.isMonthEnabled()) {
      final JComponent chooser = new SmartMonthChooser(calendarModel).getContent();
      panel.add(new SmartLabel(DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.MonthLabel"), chooser)); //$NON-NLS-1$
      panel.add(chooser, GridDialogLayoutDataFactory.createFillNoGrab());
      panel.add(new EndOfLineMarkerComponent());
    }
    if (dateConfiguration.isYearEnabled()) {
      final JComponent chooser = SmartCalendarFieldChooser
          .createYearChooser(calendarModel)
          .getContent();
      panel.add(new SmartLabel(DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.YearLabel"), chooser)); //$NON-NLS-1$
      panel.add(chooser, GridDialogLayoutDataFactory.createFillNoGrab());
      panel.add(new EndOfLineMarkerComponent());
    }
    if (dateConfiguration.isTimeEnabled()) {
      addTimePanel(panel);
    }
    return new HorizontalCenteredPanel(panel);
  }

  private void addTimePanel(final JPanel parentPanel) {
    parentPanel.add(new SmartLabel(DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.TimeLabel"))); //$NON-NLS-1$
    String labelString = ""; //$NON-NLS-1$
    final JPanel timePanel = new JPanel(new GridDialogLayout(getTimeColumnCount(), false));
    timePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
    if (dateConfiguration.isHourEnabled()) {
      final JComponent chooser = SmartCalendarFieldChooser
          .createHourChooser(calendarModel)
          .getContent();
      timePanel.add(chooser, GridDialogLayoutData.FILL_HORIZONTAL);
      labelString += "dd"; //$NON-NLS-1$
    }
    if (!StringUtilities.isNullOrEmpty(labelString)) {
      timePanel.add(new SmartLabel(":")); //$NON-NLS-1$
      labelString += ":"; //$NON-NLS-1$
    }
    if (dateConfiguration.isMinuteEnabled()) {
      final JComponent chooser = SmartCalendarFieldChooser
          .createMinuteChooser(calendarModel)
          .getContent();
      timePanel.add(chooser, GridDialogLayoutData.FILL_HORIZONTAL);
      labelString += "mm"; //$NON-NLS-1$
    }
    if (!StringUtilities.isNullOrEmpty(labelString)) {
      timePanel.add(new SmartLabel(":")); //$NON-NLS-1$
      labelString += ":"; //$NON-NLS-1$
    }
    if (dateConfiguration.isSecondEnabled()) {
      final JComponent chooser = SmartCalendarFieldChooser
          .createSecondChooser(calendarModel)
          .getContent();
      timePanel.add(chooser, GridDialogLayoutData.FILL_HORIZONTAL);
      labelString += "ss"; //$NON-NLS-1$
    }
    parentPanel.add(timePanel, GridDialogLayoutDataFactory.createFillNoGrab());
    parentPanel.add(new SmartLabel("(" + labelString + ")")); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private int getTimeColumnCount() {
    int fieldCount = 0;
    if (dateConfiguration.isHourEnabled()) {
      fieldCount++;
    }
    if (dateConfiguration.isMinuteEnabled()) {
      fieldCount++;
    }
    if (dateConfiguration.isSecondEnabled()) {
      fieldCount++;
    }
    return 2 * fieldCount;
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    return getDefaultMessage();
  }

  @Override
  public String getTitle() {
    return DisyCommonsSwingDialogMessages.getString("CalendarDialogPage.Title"); //$NON-NLS-1$
  }
}