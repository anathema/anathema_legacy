/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.demo;

import java.lang.reflect.InvocationTargetException;

import javax.swing.JOptionPane;
import javax.swing.ProgressMonitor;

import net.disy.commons.core.progress.IInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IObservableCancelable;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.swing.dialog.progress.ProgressMonitorDialog;

import de.jdemo.framework.PlainDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
@SuppressWarnings("nls")
public class ProgressMonitorDialogDemo extends PlainDemoCase {

  private static final int TOTAL_WORK = 25;

  public void demoSwingProgressMonitor() {
    final ProgressMonitor monitor = new ProgressMonitor(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige",
        "Berechne Werte...",
        0,
        TOTAL_WORK);
    monitor.setNote("Berechne Werte");
    for (int i = 0; i < TOTAL_WORK; ++i) {
      performWork(70);
      monitor.setProgress(i);
    }
    monitor.setProgress(monitor.getMaximum());
  }

  public void demoUnknownWorkNotCancelable() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new INonInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor) {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            performWork(60);
          }
          monitor.done();
        }
      });
    }
    finally {
      exit();
    }
  }

  public void demoUnknownWorkCancelable() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InterruptedException {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            ProgressUtilities.checkInterrupted(cancelable);
            performWork(60);
          }
          monitor.done();
        }
      });
    }
    catch (final InterruptedException e) {
      // nothing to do
    }
    finally {
      exit();
    }
  }

  public void demoWellKnownWorkNotCancelable() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new INonInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor) {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            performWork(50);
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    finally {
      exit();
    }
  }

  public void demoWellKnownWorkWithSubTasks() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new INonInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor) {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            monitor.subTask((i + 1) + " ter Wert");
            performWork(60);
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    finally {
      exit();
    }
  }

  public void demoWellKnownWorkCancelable() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InterruptedException {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            ProgressUtilities.checkInterrupted(cancelable);
            performWork(60);
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    catch (final InterruptedException e) {
      // nothing to do
    }
    finally {
      exit();
    }
  }

  public void demoWellKnownWorkTakingTooLongAndCausingExpiration() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InterruptedException {
          final int count = 2;
          monitor.beginTask("Berechne " + count + " Werte", count);
          for (int i = 0; i < count; ++i) {
            ProgressUtilities.checkInterrupted(cancelable);
            performWork(6000);
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    catch (final InterruptedException e) {
      // nothing to do
    }
    finally {
      exit();
    }
  }

  public void demoDivisionByZeroDuringWork() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new INonInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor) {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN);
          for (int i = 0; i < TOTAL_WORK; ++i) {
            performWork(40);
            if (i == TOTAL_WORK / 2) {
              i /= 0;
            }
          }
          monitor.done();
        }
      });
    }
    catch (final ArithmeticException expected) {
      // nothing to do
    }
    finally {
      exit();
    }
  }

  private void performWork(final int millis) {
    try {
      Thread.sleep(millis);
    }
    catch (final InterruptedException e) {
      //nothing to do
    }
  }

  public void demoEagerRunnable() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige");
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InterruptedException {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN);
          Thread.sleep(6000);
        }
      });
    }
    catch (final InterruptedException e) {
      // nothing to do
    }
    finally {
      exit();
    }
  }
}