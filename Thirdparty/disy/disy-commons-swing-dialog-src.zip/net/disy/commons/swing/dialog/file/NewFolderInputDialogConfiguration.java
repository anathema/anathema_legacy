// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;

import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.dialog.input.text.ITextInputDialogConfiguration;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;

//NOT_PUBLISHED
public class NewFolderInputDialogConfiguration implements ITextInputDialogConfiguration {
  private static final BasicMessage NAME_EXISTS_MESSAGE = new BasicMessage(
            "Es existiert bereits ein Ordner mit diesem Namen. Bitte geben Sie einen anderen Namen ein.",
            MessageType.ERROR);
  private static final BasicMessage NO_NAME_SELECTED_MESSAGE = new BasicMessage(
            "Der Ordner-Name ist leer. Bitte geben Sie den Namen des Ordners ein.",
            MessageType.ERROR);

  private final File folder;

  public NewFolderInputDialogConfiguration(File folder) {
    this.folder = folder;
  }

  public String getTitle() {
    return "Neuer Ordner";
  }

  public String getDefaultMessageText() {
    return "Bitte geben Sie den Namen des neuen Ordners ein.";
  }

  public String getLabelText() {
    return "Name des Ordners";
  }

  public IBasicMessage createCurrentMessage(String selectedText) {
    String fileName = selectedText.trim();
    if (StringUtilities.isNullOrEmpty(fileName)) {
      return NO_NAME_SELECTED_MESSAGE;
    }
    if (new File(folder, fileName).exists()) {
      return NAME_EXISTS_MESSAGE;
    }
    return null;
  }
}