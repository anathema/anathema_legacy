/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.Cursor;

import net.disy.commons.swing.icon.CommonIcons;

public class SuggestionWindowBusyComponent extends AbstractSuggestionWindowLabelComponent {

  public SuggestionWindowBusyComponent(final String busyLabelText) {
    super(busyLabelText, CommonIcons.REFRESH_ANIMATION);
  }

  @Override
  protected Cursor getCursor() {
    return Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR);
  }
}