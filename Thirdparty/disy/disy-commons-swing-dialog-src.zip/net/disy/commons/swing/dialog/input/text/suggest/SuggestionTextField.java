/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest;

import java.awt.Cursor;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.IOException;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import net.disy.commons.core.asynchronous.AsynchronousDroppingJobProcessor;
import net.disy.commons.core.asynchronous.IJobProcessor;
import net.disy.commons.core.exception.IExceptionHandler;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.core.text.SuggestionResult;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.dialog.input.text.suggest.internal.SuggestionWindow;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.text.ClearTextFieldButton;
import net.disy.commons.swing.text.TextWidgetFactory;

public class SuggestionTextField<T> implements IComponentContainer {

  private final JTextField textField = new JTextField(
      LayoutUtilities.getDefaultTextInputFieldSize());
  private final SuggestionWindow<T> window;
  private final ISuggestionTextFieldConfiguration<T> configuration;
  private final AbstractDocumentChangeListener documentListener;
  private final AsynchronousDroppingJobProcessor<String> textUpdateProcessor;
  private JComponent textFieldComponent;

  public SuggestionTextField(final ISuggestionTextFieldConfiguration<T> configuration) {
    Ensure.ensureArgumentNotNull(configuration);
    this.configuration = configuration;
    final JComponent optionalRightInsideTextFieldComponent = createOptionalInsideTextFieldRightComponent();
    textFieldComponent = TextWidgetFactory.createInternalComponentWrappedTextFieldComponent(
        configuration.createOptionalLeftInsideTextFieldComponent(),
        textField,
        optionalRightInsideTextFieldComponent);

    final String toolTipText = configuration.getToolTipText();
    textField.setToolTipText(StringUtilities.isNullOrEmpty(toolTipText) ? null : toolTipText);
    final IBlock doubleClickCallback = new IBlock() {
      @Override
      public void execute() {
        confirmSelection();
      }
    };
    window = new SuggestionWindow<T>(
        textFieldComponent,
        textField,
        configuration,
        doubleClickCallback);
    final IExceptionHandler exceptionHandler = new IExceptionHandler() {
      @Override
      public void handle(final Throwable exception) {
        //All relevant exceptions are being handled in the job processor -> only runtime exceptions remain
        if (exception instanceof Error) {
          throw (Error) exception;
        }
        if (exception instanceof RuntimeException) {
          throw (RuntimeException) exception;
        }
        throw new RuntimeException(exception);
      }
    };
    final IJobProcessor<String> textUpdateHandler = new IJobProcessor<String>() {
      @Override
      public void process(final ICancelable cancelable, final String text)
          throws InterruptedException {
        SwingUtilities.invokeLater(new Runnable() {
          @Override
          public void run() {
            window.showWithQueryStarted();
            textField.requestFocus();
          }
        });

        final SuggestionResult<T> suggestionResult;
        try {
          suggestionResult = configuration.getSuggestionsForStringProvider().querySuggestions(
              text,
              cancelable);
        }
        catch (final IOException e) {
          ProgressUtilities.checkInterrupted(cancelable);
          SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
              window.dispose();
              configuration.getErrorHandler().handleError(textField, e);
            }
          });
          return;
        }
        SwingUtilities.invokeLater(new Runnable() {
          @Override
          public void run() {
            window.showLoadedSuggestions(suggestionResult);
            textField.requestFocus();
          }
        });
      }
    };
    textUpdateProcessor = new AsynchronousDroppingJobProcessor<String>(
        textUpdateHandler,
        exceptionHandler);
    connectWaitCursorForBusy(textUpdateProcessor.getBusyModel());

    documentListener = new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        startQueryForCurrentText();
      }
    };
    textField.getDocument().addDocumentListener(documentListener);
    textField.addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(final KeyEvent e) {
        if (e.getKeyChar() == KeyEvent.VK_ENTER) {
          confirmSelection();
          return;
        }
      }

      @Override
      public void keyPressed(final KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ENTER) {
          if (window.isVisible()) {
            e.consume(); //Bugfix (gebhard) 21.06.2011: User dialog closes when hitting enter while list popup is open
          }
        }
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
          window.dispose();
          return;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
          window.moveSelectionDown();
          e.consume();
          return;
        }
        if (e.getKeyCode() == KeyEvent.VK_UP) {
          window.moveSelectionUp();
          e.consume();
          return;
        }
      }
    });
  }

  private JComponent createOptionalInsideTextFieldRightComponent() {
    final JComponent optionalRightComponent = configuration
        .createOptionalRightInsideTextFieldComponent();
    if (!configuration.isClearButtonVisible()) {
      return optionalRightComponent;
    }
    if (optionalRightComponent == null) {
      return new ClearTextFieldButton(textField, null);
    }
    final JPanel panel = new JPanel(new GridDialogLayout(2, false, 0, 0));
    panel.setFocusable(false);
    panel.setBackground(SwingColors.getTextAreaBackgroundColor());
    panel.add(new ClearTextFieldButton(textField, null), GridDialogLayoutData.FILL_VERTICAL);
    panel.add(optionalRightComponent);
    return panel;

  }

  private void connectWaitCursorForBusy(final BooleanModel busyModel) {
    busyModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        if (busyModel.getValue()) {
          textField.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
          textFieldComponent.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        }
        else {
          textField.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
          textFieldComponent.setCursor(null);
        }
      }
    });
  }

  @Override
  public JComponent getContent() {
    return textFieldComponent;
  }

  private void confirmSelection() {
    if (!window.isVisible()) {
      startQueryForCurrentText();
      return;
    }
    final T item = window.getSelectedItem();
    if (item == null) {
      textField.getToolkit().beep();
      return;
    }
    textField.getDocument().removeDocumentListener(documentListener);
    final String searchText = configuration.getRawSearchText(item);
    if (searchText != null) {
      textField.setText(searchText);
    }
    selectAllWithCaretAtFirstPosition(textField);
    textField.getDocument().addDocumentListener(documentListener);
    window.dispose();
    final ISuggestionActionHandler<T> actionHandler = configuration.getActionHandler();
    actionHandler.handle(textField, item);
  }

  private static void selectAllWithCaretAtFirstPosition(final JTextField textField) {
    textField.setCaretPosition(textField.getText().length());
    textField.moveCaretPosition(0);
  }

  public void setText(final String text) {
    textField.getDocument().removeDocumentListener(documentListener);
    textField.setText(text);
    window.dispose();
    textField.getDocument().addDocumentListener(documentListener);
  }

  private void startQueryForCurrentText() {
    final String text = textField.getText();
    if (StringUtilities.isNullOrEmpty(text)) {
      textUpdateProcessor.cancelCurrentJob();
      window.dispose();
      if (configuration.isClearButtonVisible()) {
        configuration.getActionHandler().handle(textField, null);
      }
      return;
    }
    textUpdateProcessor.startJob(text);
  }

  public SuggestionWindow<T> getWindow() {
    return window;
  }

  public void requestFocus() {
    textField.requestFocus();
  }

  public void addKeyListener(final KeyListener listener) {
    textField.addKeyListener(listener);
  }

  public void removeKeyListener(final KeyListener listener) {
    textField.removeKeyListener(listener);
  }

  public void addFocusListener(final FocusListener listener) {
    textField.addFocusListener(listener);
  }

  public void removeFocusListener(final FocusListener listener) {
    textField.removeFocusListener(listener);
  }

  /**
   * Only for internal use!
   */
  public void _disableTextFieldSelectAllInJGoodiesLooks() {
    textField.putClientProperty("JGoodies.selectAllOnFocusGain", Boolean.FALSE); //$NON-NLS-1$
  }
}