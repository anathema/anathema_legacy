/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.textfield.DoubleModelTextField;

public class DoubleModelSmartDialogPanel extends AbstractLabeledSmartDialogPanel {

  private final ObjectModel<Double> model;
  private final DoubleModelTextField doubleField;

  public DoubleModelSmartDialogPanel(
      final String label,
      final ObjectModel<Double> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public DoubleModelSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<Double> model,
      final IMessageProducingValidator validator) {
    super(label, toolTipText, validator);
    this.model = model;
    doubleField = new DoubleModelTextField(12, model);
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  protected JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    panel.add(doubleField.getContent());
    return doubleField.getContent();
  }

  @Override
  public void requestFocus() {
    doubleField.requestFocus();
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    doubleField.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ doubleField.getContent() };
  }
}