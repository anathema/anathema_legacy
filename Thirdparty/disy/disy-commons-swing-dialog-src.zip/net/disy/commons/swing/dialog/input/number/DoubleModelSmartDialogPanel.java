//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.number;

import javax.swing.JPanel;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.IMessageProducingValidator;
import net.disy.commons.swing.textfield.DoubleModelTextField;

// NOT_PUBLISHED
public class DoubleModelSmartDialogPanel extends AbstractLabeledSmartDialogPanel {

  private final ObjectModel<Double> model;
  private final DoubleModelTextField doubleField;

  public DoubleModelSmartDialogPanel(
      String label,
      final ObjectModel<Double> model,
      IMessageProducingValidator validator) {
    super(label, validator);
    this.model = model;
    doubleField = new DoubleModelTextField(12, model);
  }

  public void addChangeListener(ChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  protected void fillMainComponentInto(JPanel panel, int columnCount) {
    panel.add(doubleField.getContent());
  }
}