/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog;

import java.awt.Dimension;

import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.preferences.IDialogPreferences;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class DefaultDialogConfigurationBuilder<P extends IDialogPage> {

  private final P dialogPage;
  private IDialogButtonConfiguration buttonConfiguration = DialogButtonConfigurationFactory
      .createOkCancel();
  private IDialogHeaderPanelConfiguration headerPanelConfiguration = DialogHeaderPanelConfiguration
      .createVisibleWithoutIcon();
  private Dimension customizedPreferedSize = null;
  private IDialogPreferences preferences = null;

  public DefaultDialogConfigurationBuilder(P dialogPage) {
    this.dialogPage = dialogPage;
  }

  public DefaultDialogConfiguration<P> build() {
    return new DefaultDialogConfiguration<P>(
        dialogPage,
        buttonConfiguration,
        headerPanelConfiguration,
        customizedPreferedSize,
        preferences);
  }

  public void setButtonConfiguration(IDialogButtonConfiguration buttonConfiguration) {
    this.buttonConfiguration = buttonConfiguration;
  }

  public void setHeaderPanelConfiguration(IDialogHeaderPanelConfiguration headerPanelConfiguration) {
    this.headerPanelConfiguration = headerPanelConfiguration;
  }

  public void setCustomizedPreferedSize(Dimension customizedPreferedSize) {
    this.customizedPreferedSize = customizedPreferedSize;
  }

  public void setPreferences(IDialogPreferences preferences) {
    this.preferences = preferences;
  }
}
