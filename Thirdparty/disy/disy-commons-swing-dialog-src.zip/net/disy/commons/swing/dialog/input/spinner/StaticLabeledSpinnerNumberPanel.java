/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.spinner;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;
import net.disy.commons.swing.layout.grid.IDialogComponent;

public class StaticLabeledSpinnerNumberPanel implements IDialogComponent {

  private final JSpinner spinner;
  private final JLabel label;

  public StaticLabeledSpinnerNumberPanel(
      final SpinnerNumberModel model,
      String labelText,
      String toolTipText) {
    label = new JLabel(labelText);
    spinner = new JSpinner(model);
    spinner.setToolTipText(toolTipText);
    label.setToolTipText(toolTipText);
    JSpinnerUtilities.setNotEditableForNumberSpinner(spinner);
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    panel.add(label, GridDialogLayoutDataFactory.createRightData());
    panel.add(spinner);
  }

  @Override
  public int getColumnCount() {
    return 2;
  }

  public JComponent[] getComponents() {
    return new JComponent[]{ label, spinner };
  }

  public void setEnabled(final boolean enabled) {
    label.setEnabled(enabled);
    spinner.setEnabled(enabled);
  }
}