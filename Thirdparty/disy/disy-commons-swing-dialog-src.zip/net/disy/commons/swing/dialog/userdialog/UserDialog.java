package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.swing.action.ActionConfiguration;
import net.disy.commons.swing.action.IActionConfiguration;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.BasicDialogResources;
import net.disy.commons.swing.dialog.core.AbstractDialog;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutDirection;
import net.disy.commons.swing.util.GuiUtilities;
import net.disy.commons.swing.util.RelativePosition;

public class UserDialog extends AbstractDialog implements IUserDialogContainer {
  private DialogPageControl dialogControl;
  private JButton okButton;
  private JButton cancelButton;
  private boolean neverVisualized = true;
  private final RelativePosition relativePosition;

  public UserDialog(Component parentComponent, IDialogConfiguration userDialog) {
    this(parentComponent, userDialog, RelativePosition.CENTER);
  }

  public UserDialog(
      Component parentComponent,
      IDialogConfiguration userDialog,
      RelativePosition relativePosition) {
    super(parentComponent, userDialog);
    this.dialogControl = new DialogPageControl(userDialog.getDialogPage());
    userDialog.setUserDialogContainer(this);
    dialogControl.setUserDialogContainer(this);
    initialize();
    setContent(dialogControl.getContent());
    updateAll();
    dialogControl.requestFocus();
    this.relativePosition = relativePosition;
  }

  public UserDialog(Component parentComponent, IDialogPage dialogPage) {
    this(parentComponent, new DefaultUserDialogConfiguration(dialogPage));
  }

  protected IDialogConfiguration getConfiguration() {
    return (IDialogConfiguration) getGenericDialog();
  }

  private void updateAll() {
    updateDescription();
    updateTitle();
    updateMessage();
    updateButtons();
    setModal(getConfiguration().isModal());
  }

  public void updateDescription() {
    setDescription(getDialogControl().getDescription());
  }

  public void updateTitle() {
    setTitle(getDialogControl().getTitle());
  }

  public void updateMessage() {
    setMessage(getDialogControl().getMessage());
  }

  public void updateButtons() {
    okButton.setEnabled(getDialogControl().canFinish());
  }

  protected JComponent createButtonBar() {
    JComponent[] createdButtons = createButtons();

    if (createdButtons.length > 0 && createdButtons[0] instanceof JButton) {
      setDefaultButton((JButton) createdButtons[0]);
    }

    ButtonPanelBuilder buttonPanelBuilder = new ButtonPanelBuilder(LayoutDirection.HORIZONTAL);
    for (int i = 0; i < createdButtons.length; i++) {
      buttonPanelBuilder.add(createdButtons[i]);
    }
    return buttonPanelBuilder.createPanel();
  }

  protected final JComponent[] createButtons() {
    IDialogButtonConfiguration buttonConfiguration = getConfiguration().getButtonConfiguration();
    IActionConfiguration okActionConfiguration = buttonConfiguration.getOkActionConfiguration();

    final SmartAction okAction = new SmartAction(okActionConfiguration != null
        ? okActionConfiguration
        : new ActionConfiguration()) {
      protected void execute(Component parentComponent) {
        requestFinish();
      }
    };

    okButton = new JButton(okAction);

    IActionConfiguration cancelActionConfiguration = buttonConfiguration
        .getCancelActionConfiguration();
    final SmartAction cancelAction = new SmartAction(cancelActionConfiguration != null
        ? cancelActionConfiguration
        : new ActionConfiguration()) {
      protected void execute(Component parentComponent) {
        performCancel();
      }
    };
    cancelButton = new JButton(cancelAction);

    final SmartAction helpAction = new SmartAction(BasicDialogResources.HELP_TEXT_SMART) {
      protected void execute(Component parentComponent) {
        helpPressed();
      }
    };
    JButton helpButton = new JButton(helpAction);

    List buttonList = new ArrayList();
    if (okActionConfiguration != null) {
      buttonList.add(okButton);
    }

    JComponent[] additionalButtons = getConfiguration().createAdditionalButtons();
    buttonList.addAll(Arrays.asList(additionalButtons));
    buttonList.addAll(Arrays.asList(createAdditionalButtons()));

    if (cancelActionConfiguration != null) {
      buttonList.add(cancelButton);
    }
    if (getDialogControl().isHelpAvailable()) {
      buttonList.add(helpButton);
    }
    return (JComponent[]) buttonList.toArray(new JComponent[buttonList.size()]);
  }

  protected JComponent[] createAdditionalButtons() {
    return new JComponent[0];
  }

  protected boolean okPressed() {
    if (!getDialogControl().performOk()) {
      return false;
    }
    return getConfiguration().performOk(getDialog().getWindow());
  }

  protected void helpPressed() {
    getDialogControl().performHelp();
  }

  public DialogPageControl getDialogControl() {
    return dialogControl;
  }

  protected boolean cancelPressed() {
    if (!getDialogControl().performCancel()) {
      return false;
    }
    return getConfiguration().performCancel(getDialog().getWindow());
  }

  public void setVisible(boolean visible) {
    if (visible) {
      if (neverVisualized) {
        GuiUtilities.placeRelativeToOwner(getDialog().getWindow(), relativePosition);
        getDialog().show();
        neverVisualized = false;
      }
      else {
        getDialog().show();
      }
    }
    else {
      getDialog().setVisible(false);
    }
  }

  public void show() {
    setVisible(true);
  }

  private void setModal(boolean modal) {
    getDialog().setModal(modal);
  }

  public final void requestFinish() {
    if (!getDialogControl().canFinish()) {
      return;
    }
    if (okPressed()) {
      closeDialog();
      getConfiguration().performAfterDispose(false);
    }
  }

  protected void closeDialog() {
    super.closeDialog();
    getConfiguration().getDialogPage().dispose();
  }
}