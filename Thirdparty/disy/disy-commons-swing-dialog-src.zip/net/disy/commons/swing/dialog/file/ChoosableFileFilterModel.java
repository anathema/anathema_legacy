//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class ChoosableFileFilterModel extends AbstractChangeableModel {

  public static final FileFilter ACCEPT_ALL_FILE_FILTER = new FileFilter() {

    public String getDescription() {
      return UIManager.getString("FileChooser.acceptAllFileFilterText"); //$NON-NLS-1$
    }

    public boolean accept(File f) {
      return true;
    }

  };

  final List/*<FileFilter>*/fileFilters = new ArrayList();

  public void addFileFilter(FileFilter filter) {
    Ensure.ensureArgumentNotNull(filter);
    if (fileFilters.contains(filter)) {
      return;
    }
    fileFilters.add(filter);
    fireChangeEvent();
  }

  public FileFilter[] getFileFilters() {
    return (FileFilter[]) fileFilters.toArray(new FileFilter[fileFilters.size()]);
  }

  public void clear() {
    fileFilters.clear();
    fireChangeEvent();
  }

  public void removeFileFilter(FileFilter fileFilter) {
    if (fileFilters.remove(fileFilter)) {
      fireChangeEvent();
    }
  }

  public boolean isEmpty() {
    return fileFilters.isEmpty();
  }

}
