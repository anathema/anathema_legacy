// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import java.awt.Dimension;

import net.disy.commons.swing.dialog.BasicDialogUi;

/**
 * Abstract superclass that can be extended for {@link IWizard}
 * implementations.
 */
public abstract class AbstractWizard implements IWizard {
  private IWizardContainer container;

  public IWizardContainer getContainer() {
    return container;
  }

  public void setContainer(IWizardContainer container) {
    this.container = container;
  }

  public boolean isHeaderPanelVisible() {
    return true;
  }

  public boolean canFinish() {
    IWizardPage currentPage = getContainer().getCurrentPage();
    return currentPage.canFinish();
  }

  public void updateSize() {
    container.updateSize();
  }

  public Dimension getDialogSize() {
    return null;
  }

  public String getCancelButtonText() {
    return BasicDialogUi.CANCEL_TEXT_SMART;
  }

  public boolean isCancelAvailable() {
    return true;
  }

  public boolean isOkButtonAvailable() {
    return true;
  }

  public String getOkButtonText() {
    return BasicDialogUi.WIZARD_FINISH_SMART;
  }

  public void performAfterDispose(boolean canceled) {
    //nothing to do
  }
  
  public boolean shallInitializePagesFromData() {
    return false;
  }
}