/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard;

import net.disy.commons.core.util.Ensure;

public class SinglePageWizardConfiguration extends AbstractWizardConfiguration {
  private IWizardPage wizardPage;
  private final IWizardPageFactory pageFactory;

  public SinglePageWizardConfiguration(final IWizardPageFactory pageFactory) {
    Ensure.ensureArgumentNotNull(pageFactory);
    this.pageFactory = pageFactory;
  }

  @Override
  public void addPages() {
    wizardPage = pageFactory.createPage(this);
  }

  @Override
  public IWizardPage getStartingPage() {
    return wizardPage;
  }

  @Override
  public IWizardPage getNextPage(final IWizardPage page) {
    return null;
  }

  @Override
  public IWizardPage getPreviousPage(final IWizardPage page) {
    return null;
  }

  @Override
  public boolean isHelpAvailable() {
    return false;
  }
}
