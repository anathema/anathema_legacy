/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.awt.Component;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.optional.OptionalSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;

import org.junit.Before;
import org.junit.Test;

public class OptionalSmartDialogPanel_NonMandatoryTest {

  private ObjectModel<Integer> model;
  private final String checkboxLabel = "checkboxLabel"; //$NON-NLS-1$
  private IUpdatableSmartDialogPanel delegate;
  private ObjectModel<Integer> fieldModel;

  @Before
  public void init() throws Exception {
    model = new ObjectModel<Integer>();
    delegate = createMock(IUpdatableSmartDialogPanel.class);
    fieldModel = new ObjectModel<Integer>();
    delegate.addChangeListener(isA(IChangeListener.class));
  }

  @Test
  public void fillIntoAddsCheckboxThenDelegatesToDelegate() throws Exception {
    final JPanel jPanel = new JPanel();
    delegate.fillInto(jPanel, 1);
    expect(delegate.getComponents()).andReturn(new JComponent[0]);
    delegate.setEnabled(false);
    replay(delegate);
    final TestOptionalSmartDialogPanel<Integer> panel = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel);
    panel.fillInto(jPanel, 3);
    assertThat(jPanel.getComponent(0), is((Component) panel.getCheckbox()));
    verify(delegate);
  }

  @Test
  public void fillIntoEnablesContainerIfCheckboxIsSelected() throws Exception {
    final JPanel jPanel = new JPanel();
    delegate.fillInto(jPanel, 1);
    expect(delegate.getComponents()).andReturn(new JComponent[0]);
    delegate.setEnabled(true);
    replay(delegate);
    final TestOptionalSmartDialogPanel<Integer> panel = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel);
    panel.getCheckbox().setSelected(true);
    panel.fillInto(jPanel, 3);
    assertThat(jPanel.getComponent(0), is((Component) panel.getCheckbox()));
    verify(delegate);
  }

  @Test
  public void updateViewSetsModelValueToFieldModel() throws Exception {
    model.setValue(42);
    replay(delegate);
    new TestOptionalSmartDialogPanel<Integer>(model, checkboxLabel, delegate, fieldModel)
        .updateView();
    assertThat(fieldModel.getValue(), is(42));
    verify(delegate);
  }

  @Test
  public void updateViewDoesNothingIfModelValueIsNull() throws Exception {
    fieldModel.setValue(42);
    model.setValue(null);
    replay(delegate);
    new TestOptionalSmartDialogPanel<Integer>(model, checkboxLabel, delegate, fieldModel)
        .updateView();
    assertThat(fieldModel.getValue(), is(42));
    verify(delegate);
  }

  @Test
  public void updateModelSetsFieldModelValueToModel() throws Exception {
    replay(delegate);
    final TestOptionalSmartDialogPanel<Integer> panel = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel);
    panel.getCheckbox().setSelected(true);
    fieldModel.setValue(42);
    panel.updateModel();
    assertThat(model.getValue(), is(42));
    verify(delegate);
  }

  @Test
  public void updateModelSetsModelValueToNullIfCheckboxIsNotSelected() throws Exception {
    replay(delegate);
    final TestOptionalSmartDialogPanel<Integer> panel = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel);
    panel.getCheckbox().setSelected(false);
    fieldModel.setValue(42);
    panel.updateModel();
    assertThat(model.getValue(), nullValue());
    verify(delegate);
  }

  @Test
  public void addChangeListenerDelegatesToDelegate() throws Exception {
    final IChangeListener changeListener = createMock(IChangeListener.class);
    delegate.addChangeListener(changeListener);
    replay(delegate, changeListener);
    new TestOptionalSmartDialogPanel<Integer>(model, checkboxLabel, delegate, fieldModel)
        .addChangeListener(changeListener);
    verify(delegate, changeListener);
  }

  @Test
  public void requestFocusDelegatesToDelegate() throws Exception {
    delegate.requestFocus();
    replay(delegate);
    new TestOptionalSmartDialogPanel<Integer>(model, checkboxLabel, delegate, fieldModel)
        .requestFocus();
    verify(delegate);
  }

  @Test
  public void createOptionalCurrentMessageDelegatesToDelegate() throws Exception {
    final IBasicMessage message = createMock(IBasicMessage.class);
    expect(delegate.createOptionalCurrentMessage()).andReturn(message);
    replay(delegate, message);
    final IBasicMessage actualMessage = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel).createOptionalCurrentMessage();
    assertSame(message, actualMessage);
    verify(delegate, message);
  }

  @Test
  public void columnCountIsColumnCountOfDelegatePlusTwo() throws Exception {
    expect(delegate.getColumnCount()).andReturn(1);
    replay(delegate);
    final int columnCount = new TestOptionalSmartDialogPanel<Integer>(
        model,
        checkboxLabel,
        delegate,
        fieldModel).getColumnCount();
    assertThat(columnCount, is(3));
    verify(delegate);
  }

  private class TestOptionalSmartDialogPanel<T extends Object> extends OptionalSmartDialogPanel<T> {

    public TestOptionalSmartDialogPanel(
        final ObjectModel<T> model,
        final String checkBoxLabel,
        final IUpdatableSmartDialogPanel delegate,
        final ObjectModel<T> fieldModel) {
      super(model, checkBoxLabel, delegate, fieldModel, false);
    }

    @Override
    public void updateModel() {
      super.updateModel();
    }

    @Override
    public void updateView() {
      super.updateView();
    }

    @Override
    public JCheckBox getCheckbox() {
      return super.getCheckbox();
    }

  }

}
