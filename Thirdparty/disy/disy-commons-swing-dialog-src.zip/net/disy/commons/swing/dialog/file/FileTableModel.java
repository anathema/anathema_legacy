// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;

import javax.swing.table.AbstractTableModel;

import net.disy.commons.core.io.IOUtilities;

//NOT_PUBLISHED
public class FileTableModel extends AbstractTableModel {
  private static final String[] COLUMN_NAMES = new String[]{ "Name", "Gr��e" };
  private static final Class[] COLUMN_CLASSES = new Class[]{ File.class, String.class };

  private File[] files = new File[0];

  public void setFiles(File[] files) {
    this.files = files;
    fireTableDataChanged();
  }

  public int getColumnCount() {
    return 2;
  }

  public int getRowCount() {
    return files.length;
  }

  public Object getValueAt(int rowIndex, int columnIndex) {
    File file = getFile(rowIndex);

    if (columnIndex == 0) {
      return file;
    }

    if (file.isDirectory()) {
      return ""; //$NON-NLS-1$
    }
    
    return IOUtilities.byteCountToDisplaySize(file.length());
  }

  public File getFile(int rowIndex) {
    return files[rowIndex];
  }

  public Class getColumnClass(int columnIndex) {
    return COLUMN_CLASSES[columnIndex];
  }

  public String getColumnName(int column) {
    return COLUMN_NAMES[column];
  }

  public boolean isCellEditable(int rowIndex, int columnIndex) {
    return false;
  }
}
