/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class TabbedAggregationDialogPage extends TabbedAggregationBasicDialogPage
    implements
    IDialogPage {

  private final IBasicMessage defaultMessage;

  public TabbedAggregationDialogPage(final String title, final IDialogPage... pages) {
    super(title, pages);
    defaultMessage = pages[0].getDefaultMessage();
  }

  @Override
  public IBasicMessage getDefaultMessage() {
    return defaultMessage;
  }
}