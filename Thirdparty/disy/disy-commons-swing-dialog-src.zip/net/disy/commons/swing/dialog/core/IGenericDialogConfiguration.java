//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public interface IGenericDialogConfiguration {

  public void performAfterDispose(boolean canceled);

  /** @return whether the header panel in the dialog shall be visible or not. */
  public boolean isHeaderPanelVisible();

  public IDialogButtonConfiguration getButtonConfiguration();
}