//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import javax.swing.Icon;

import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public interface IGenericDialogConfiguration {

  /** @return whether the header panel in the dialog shall be visible or not. */
  public boolean isHeaderPanelVisible();

  public IDialogButtonConfiguration getButtonConfiguration();

  /** An optional icon of 75x66 pixels for the top right corner of the dialog header panel.
   * @return An icon or <code>null</code> if none. */
  public Icon getLargeDialogIcon();
}