/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import java.util.ArrayList;
import java.util.List;

import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;

public class CompoundMessageProducingValidator implements IMessageProducingValidator {
  private final List<IMessageProducingValidator> validators = new ArrayList<IMessageProducingValidator>();

  public void addValidator(final IMessageProducingValidator validator) {
    validators.add(validator);
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    final HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    for (final IMessageProducingValidator validator : validators) {
      builder.addMessage(validator.createOptionalCurrentMessage());
    }

    return builder.getHighestPriorityMessage();
  }

}
