// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import javax.swing.JComponent;

import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.layout.grid.GridDialogPanel;

//NOT_PUBLISHED
public abstract class SmartDialogPage extends AbstractDialogPage {

  private ISmartDialogPanel[] panels;

  public SmartDialogPage(IBasicMessage defaultMessage) {
    super(defaultMessage);
  }

  public final IBasicMessage createCurrentMessage() {
    HighestPriorityMessageBuilder builder = new HighestPriorityMessageBuilder();
    builder.addMessage(getDefaultMessage());
    for (int i = 0; i < panels.length; i++) {
      IBasicMessage message = panels[i].createOptionalCurrentMessage();
      if (message != null) {
        builder.addMessage(message);
      }
    }
    
    addAdditionalMessages(builder);
    
    return builder.getHighestPriorityMessage();
  }

  protected void addAdditionalMessages(HighestPriorityMessageBuilder builder) {
    // nothing to do
  }

  public final JComponent createContent() {
    panels = createPanels();
    GridDialogPanel panel = new GridDialogPanel();
    for (int i = 0; i < panels.length; i++) {
      panel.add(panels[i]);
    }
    IRequestFinishListener requestFinishListener = new IRequestFinishListener() {
      public void requestFinish() {
        SmartDialogPage.this.requestFinish();
      }
    };
    for (int i = 0; i < panels.length; i++) {
      panels[i].addChangeListener(getCheckInputValidListener());
      panels[i].addRequestFinishListener(requestFinishListener);
    }
    return panel.getContent();
  }

  protected abstract ISmartDialogPanel[] createPanels();

}
