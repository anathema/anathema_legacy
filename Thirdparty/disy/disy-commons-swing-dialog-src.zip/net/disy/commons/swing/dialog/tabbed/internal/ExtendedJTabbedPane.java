/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed.internal;

import javax.swing.JTabbedPane;

import net.disy.commons.swing.dialog.tabbed.TabPlacement;

public class ExtendedJTabbedPane extends JTabbedPane {

  private boolean popupMenuVisible;
  private final TabPlacement placement;

  public ExtendedJTabbedPane(final TabPlacement placement, final int tabLayoutPolicy) {
    super(placement.getSwingValue(), tabLayoutPolicy);
    this.placement = placement;
  }

  public void setHasPopupMenuVisible(final boolean popupMenuVisible) {
    this.popupMenuVisible = popupMenuVisible;
  }

  public boolean isPopupMenuVisible() {
    return popupMenuVisible;
  }

  public TabPlacement getTabTitlePlacement() {
    return placement;
  }
}