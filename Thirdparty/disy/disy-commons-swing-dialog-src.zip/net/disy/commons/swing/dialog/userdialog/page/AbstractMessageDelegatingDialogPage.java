/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.userdialog.message.DialogMessageHandler;
import net.disy.commons.swing.dialog.userdialog.message.IDialogMessageHandler;
import net.disy.commons.swing.dialog.userdialog.message.IErrorMessageProvider;

public abstract class AbstractMessageDelegatingDialogPage extends AbstractBasicDialogPage
    implements
    IDialogPage {

  private final IDialogMessageHandler messageHandler;

  protected AbstractMessageDelegatingDialogPage(
      final String defaultMessageText,
      final IErrorMessageProvider errorMessageProvider) {
    this(new DialogMessageHandler(defaultMessageText, errorMessageProvider));
  }

  protected AbstractMessageDelegatingDialogPage(final IDialogMessageHandler messageHandler) {
    Ensure.ensureArgumentNotNull("MessageHandler must not be null.", messageHandler); //$NON-NLS-1$
    this.messageHandler = messageHandler;
  }

  @Override
  public final IBasicMessage getDefaultMessage() {
    return messageHandler.getDefaultMessage();
  }

  @Override
  public final IBasicMessage createCurrentMessage() {
    return messageHandler.createCurrentMessage();
  }
}