/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import java.awt.BorderLayout;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IOptionalCurrentMessageFactory;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.panel.FixedIncrementVerticalScrollablePanel;

public class VerticalScrollingSmartDialogPanel extends AbstractSmartDialogPanel {

  private final ISmartDialogPanel[] panels;
  private final int preferredViewportHeight;
  private final IOptionalCurrentMessageFactory[] optionalCurrentMessageFactories;

  public VerticalScrollingSmartDialogPanel(final ISmartDialogPanel[] panels) {
    this(panels, new IOptionalCurrentMessageFactory[0], LayoutUtilities.getDpiAdjusted(200));
  }

  public VerticalScrollingSmartDialogPanel(
      final ISmartDialogPanel[] panels,
      final IOptionalCurrentMessageFactory[] additionalOptionalCurrentMessageFactories) {
    this(panels, ArrayUtilities.concat(
        IOptionalCurrentMessageFactory.class,
        panels,
        additionalOptionalCurrentMessageFactories), LayoutUtilities.getDpiAdjusted(200));
  }

  private VerticalScrollingSmartDialogPanel(
      final ISmartDialogPanel[] panels,
      final IOptionalCurrentMessageFactory[] optionalCurrentMessageFactories,
      final int preferredViewportHeight) {
    Ensure.ensureArgumentNotNull(panels);
    this.panels = panels;
    this.optionalCurrentMessageFactories = optionalCurrentMessageFactories;
    this.preferredViewportHeight = preferredViewportHeight;
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    for (final ISmartDialogPanel panel : panels) {
      panel.addChangeListener(listener);
    }
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    final HighestPriorityMessageBuilder messageBuilder = new HighestPriorityMessageBuilder();
    for (final IOptionalCurrentMessageFactory panel : optionalCurrentMessageFactories) {
      messageBuilder.addMessage(panel.createOptionalCurrentMessage());
    }
    return messageBuilder.getHighestPriorityMessage();
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final FixedIncrementVerticalScrollablePanel container = new FixedIncrementVerticalScrollablePanel(
        new BorderLayout(),
        preferredViewportHeight);
    final GridDialogPanelBuilder dialogPanel = new GridDialogPanelBuilder();
    for (final ISmartDialogPanel smartDialogPanel : panels) {
      addDialogPanel(smartDialogPanel, dialogPanel);
    }

    container.add(dialogPanel.createPanel(), BorderLayout.CENTER);
    container.setBorder(new EmptyBorder(0, 0, 0, LayoutUtilities.getDpiAdjusted(6)));
    final JScrollPane scrollPane = new JScrollPane(container);
    scrollPane.setBorder(null);
    panel.add(scrollPane, GridDialogLayoutData.FILL_BOTH);
  }

  private void addDialogPanel(
      final ISmartDialogPanel dialogPanel,
      final GridDialogPanelBuilder panel) {
    panel.add(dialogPanel);
  }

  @Override
  public void requestFocus() {
    if (panels.length > 0) {
      panels[0].requestFocus();
    }
  }
}