/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

import net.disy.commons.swing.color.widgets.ColorModel;

public class ColorChooserLabel extends AbstractColorChoosingComponent {

  public ColorChooserLabel(final ColorModel model) {
    this(model, new DefaultColorChooserConfiguration());
  }

  public ColorChooserLabel(final ColorModel model, final IColorChooserConfiguration configuration) {
    super(model, configuration);
  }

  @Override
  protected JComponent createContent() {
    final JComponent label = new JComponent() {
      @Override
      public Dimension getPreferredSize() {
        return new Dimension(50, 20);
      }

      @Override
      public void paint(Graphics g) {
        paintColorRectangle(g, 0, 0, getSize(), isEnabled());
        super.paint(g);
      }
    };
    label.setOpaque(false);
    label.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseReleased(final MouseEvent e) {
        if (e.getClickCount() == 2 && !e.isMetaDown()) {
          performColorChooseDialog();
        }
      }
    });
    label.addKeyListener(new KeyAdapter() {
      @Override
      public void keyReleased(final KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_F2) {
          performColorChooseDialog();
        }
      }
    });
    return label;
  }
}