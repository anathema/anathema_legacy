//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import net.disy.commons.core.message.IBasicMessage;

// NOT_PUBLISHED
public interface IMessageProducingValidator {

  /** @return A message describing the error or warning for the current state or <code>null</code> if none. */
  public IBasicMessage validate();

}