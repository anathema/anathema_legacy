//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog;

import javax.swing.JComponent;
import javax.swing.JTabbedPane;

import net.disy.commons.swing.events.CheckInputValidListener;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;
import net.disy.commons.swing.message.gui.MessageTypeUi;

// NOT_PUBLISHED
public class TabbedAggregationDialogPage extends AbstractDialogPage {

  private interface IPageClosure {
    void execute(IDialogPage page);
  }

  private final IDialogPage[] pages;
  private final String title;
  private JTabbedPane tabbedPane;

  public TabbedAggregationDialogPage(String title, IDialogPage[] pages) {
    super(pages[0].getDefaultMessage());
    this.pages = pages;
    this.title = title;
  }

  public IBasicMessage createCurrentMessage() {
    class CurrentMessageClosure implements IPageClosure {
      IBasicMessage message = getCurrentPage().createCurrentMessage();

      public void execute(IDialogPage page) {
        IBasicMessage pageMessage = page.createCurrentMessage();
        if (pageMessage.getType().getPriority().compareTo(message.getType().getPriority()) > 0) {
          message = pageMessage;
        }
      }
    }
    CurrentMessageClosure closure = new CurrentMessageClosure();
    forAllPages(closure);
    return closure.message;
  }

  public void updateInputValid() {
    super.updateInputValid();
    for (int i = 0; i < pages.length; i++) {
      MessageType messageType = pages[i].createCurrentMessage().getType();
      tabbedPane.setIconAt(i, messageType == MessageType.NORMAL ? null : MessageTypeUi
          .getSmallIcon(messageType));
    }
  }

  private IDialogPage getCurrentPage() {
    return pages[tabbedPane.getSelectedIndex()];
  }

  public String getTitle() {
    return title;
  }

  public JComponent createContent() {
    tabbedPane = new JTabbedPane();
    forAllPages(new IPageClosure() {
      public void execute(IDialogPage dialogPage) {
        tabbedPane.addTab(dialogPage.getTitle(), dialogPage.createContent());
      }
    });
    tabbedPane.addChangeListener(getCheckInputValidListener());
    return tabbedPane;
  }

  private void forAllPages(IPageClosure closure) {
    for (int i = 0; i < pages.length; i++) {
      closure.execute(pages[i]);
    }
  }

  public void setInputValidListener(final CheckInputValidListener inputValidListener) {
    super.setInputValidListener(inputValidListener);
    forAllPages(new IPageClosure() {
      public void execute(IDialogPage page) {
        page.setInputValidListener(inputValidListener);
      }
    });
  }
}
