/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import java.util.List;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.core.IDialogResult;

public final class SelectionDialogResult<T> implements ISomeOutOfManyDialogResult<T> {
  private final List<T> selectedItems;
  private final IDialogResult result;

  public SelectionDialogResult(final IDialogResult result, final List<T> selectedItems) {
    Ensure.ensureArgumentNotNull(result);
    Ensure.ensureArgumentNotNull(selectedItems);
    this.selectedItems = selectedItems;
    this.result = result;
  }

  @Override
  public boolean isCanceled() {
    return result.isCanceled();
  }

  @Override
  public List<T> getSelectedItems() {
    return selectedItems;
  }

  @Override
  public T getSelectedItem() {
    return selectedItems.size() == 0 ? null : selectedItems.get(0);
  }
}