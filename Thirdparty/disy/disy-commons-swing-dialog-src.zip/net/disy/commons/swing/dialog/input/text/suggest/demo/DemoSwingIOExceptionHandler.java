/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.demo;

import java.awt.Component;
import java.io.IOException;

import net.disy.commons.core.message.Message;
import net.disy.commons.swing.dialog.input.text.suggest.ISwingIOExceptionHandler;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;

public final class DemoSwingIOExceptionHandler implements ISwingIOExceptionHandler {

  @Override
  public void handleError(final Component parentComponent, final IOException exception) {
    MessageDialogFactory.showMessageDialog(parentComponent, new Message(
        "Demo error querying strings.", //$NON-NLS-1$
        exception));
  }
}