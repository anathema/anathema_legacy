//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox.internal;

// NOT_PUBLISHED
public class TextualMatchRanker {

  public static int rank(final String text, final String pattern) {
    if (text.equals(pattern)) {
      return 10;
    }
    if (text.startsWith(pattern)) {
      return 9;
    }
    if (text.contains(' ' + pattern)) {
      return 8;
    }
    if (text.contains(pattern)) {
      return 7;
    }
    if (text.equalsIgnoreCase(pattern)) {
      return 6;
    }
    if (text.toLowerCase().startsWith(pattern.toLowerCase())) {
      return 5;
    }
    if (text.toLowerCase().contains(pattern.toLowerCase())) {
      return 4;
    }
    return 0;
  }
}