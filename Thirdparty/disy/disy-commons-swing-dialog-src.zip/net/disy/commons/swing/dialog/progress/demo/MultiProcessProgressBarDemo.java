/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.demo;

import net.disy.commons.swing.dialog.progress.MultiProcessProgressBar;
import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;

public class MultiProcessProgressBarDemo extends SwingDemoCase {

  @Demo
  public void doNothing() {
    MultiProcessProgressBar progressBar = new MultiProcessProgressBar();
    show(progressBar.getContent());
  }

  public void demoWithOneProcess() {
    MultiProcessProgressBar progressBar = new MultiProcessProgressBar();
    progressBar.getSetModel().add(new Object());
    show(progressBar.getContent());
  }

  public void demoWithOneTerminatingProcess() {
    final MultiProcessProgressBar progressBar = new MultiProcessProgressBar();
    final Object object = new Object();
    progressBar.getSetModel().add(object);
    Runnable runnable = new Runnable() {
      @Override
      public void run() {
        try {
          Thread.sleep(3000);
          progressBar.getSetModel().remove(object);
        }
        catch (InterruptedException exception) {
        }
      }
    };
    new Thread(runnable).start();
    show(progressBar.getContent());
  }

  public void demoMoreThanOneTerminatingProcess() {
    final MultiProcessProgressBar progressBar = new MultiProcessProgressBar();
    final Object object0 = new Object();
    final Object object1 = new Object();
    final Object object2 = new Object();
    Runnable runnable = new Runnable() {
      @Override
      public void run() {
        try {
          progressBar.getSetModel().add(object0);
          Thread.sleep(1000);
          progressBar.getSetModel().add(object1);
          Thread.sleep(3000);
          progressBar.getSetModel().remove(object0);
          Thread.sleep(1000);
          progressBar.getSetModel().remove(object1);
          Thread.sleep(3000);
          progressBar.getSetModel().add(object2);
          Thread.sleep(3000);
          progressBar.getSetModel().remove(object2);
        }
        catch (InterruptedException exception) {
        }
      }
    };
    new Thread(runnable).start();
    show(progressBar.getContent());
  }
}
