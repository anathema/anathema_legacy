/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.combo;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.reflection.RefectionEnumUtilities;
import net.disy.commons.swing.dialog.input.ISelectableItemsPanelConfiguration;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.ui.IObjectUi;

public class EnumSelectionDialogPanel<T extends Enum<T>> extends ComboSelectionDialogPanel<T> {

  public static final class SelectableItemsPanelConfiguration<T extends Enum<T>>
      implements
      ISelectableItemsPanelConfiguration<T> {
    private final T enumeration;

    public SelectableItemsPanelConfiguration(final T enumeration) {
      this.enumeration = enumeration;
    }

    @Override
    public T[] getItems() {
      return RefectionEnumUtilities.getEnumConstants(enumeration);
    }

    @Override
    public IObjectUi<T> getObjectUi() {
      return new AbstractObjectUi<T>() {
        @Override
        public String getLabel(final T value) {
          return value == null ? " " : value.name(); //$NON-NLS-1$
        }
      };
    }
  }

  public EnumSelectionDialogPanel(
      final String label,
      final String toolTipText,
      final T enumeration,
      final ObjectModel<T> model,
      final IMessageProducingValidator validator) {
    super(
        label,
        toolTipText,
        model,
        new SelectableItemsPanelConfiguration<T>(enumeration),
        validator);
  }
}