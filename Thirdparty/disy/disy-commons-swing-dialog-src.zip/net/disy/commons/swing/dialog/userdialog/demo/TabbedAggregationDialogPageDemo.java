//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog.demo;

import net.disy.commons.swing.dialog.userdialog.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.TabbedAggregationDialogPage;

// NOT_PUBLISHED
public class TabbedAggregationDialogPageDemo extends AbstractDialogDemo {

  public void demo() {
    show(new TabbedAggregationDialogPage("DialogTitle", new IDialogPage[]{ //$NON-NLS-1$
        createDemoDialogPage(), createDemoDialogPage() }));
  }

}
