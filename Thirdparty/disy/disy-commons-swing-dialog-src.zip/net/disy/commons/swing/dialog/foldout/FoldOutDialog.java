// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;

// NOT_PUBLISHED
public class FoldOutDialog extends UserDialog {
  private JButton foldOutButton;
  private boolean isFoldedOut = false;
  private JPanel foldOutPanel;

  public FoldOutDialog(Component parent, IFoldOutDialogConfiguration userDialog) {
    super(parent, userDialog);
    isFoldedOut = userDialog.isInitiallyFoldedOut();
  }

  private IFoldOutDialogConfiguration getFoldOutUserDialog() {
    return (IFoldOutDialogConfiguration) getConfiguration();
  }

  @Override
  protected JComponent[] createAdditionalButtons() {
    foldOutButton = new JButton();
    foldOutButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        toggleFoldOut();
      }
    });
    updateButtonText();
    return new JComponent[] { foldOutButton };
  }

  private void toggleFoldOut() {
    isFoldedOut = !isFoldedOut;
    foldOutPanel.setVisible(isFoldedOut);
    updateButtonText();
    if (isFoldedOut) {
      getFoldOutUserDialog().getFoldOutPage().requestFocus();
    }
    else {
      getConfiguration().getDialogPage().requestFocus();
    }
    getDialog().pack();
  }

  private void updateButtonText() {
    if (isFoldedOut) {
      foldOutButton.setText(getFoldOutUserDialog().getFoldInButtonText());
    }
    else {
      foldOutButton.setText(getFoldOutUserDialog().getFoldOutButtonText());
    }
  }

  @Override
  protected JComponent createButtonBar() {
    JComponent foldOutContent = getFoldOutUserDialog().getFoldOutPage().getContent();
    
    JPanel bottomPanel = new JPanel(new BorderLayout());
    foldOutPanel = new JPanel(new BorderLayout());
    foldOutPanel.setVisible(false);
    foldOutPanel.setBorder(BorderFactory.createEmptyBorder(10, 8, 0, 8));
    foldOutPanel.add(foldOutContent, BorderLayout.CENTER);
    
    JComponent[] createdButtons = createButtons();
    if (createdButtons.length > 0 && createdButtons[0] instanceof JButton) {
      setDefaultButton((JButton) createdButtons[0]);
    }
    ButtonPanelBuilder buttonPanelBuilder = new ButtonPanelBuilder();
    for (int i = 0; i < createdButtons.length; i++) {
      buttonPanelBuilder.add(createdButtons[i]);
    }
    bottomPanel.add(buttonPanelBuilder.createPanel(), BorderLayout.NORTH);
    bottomPanel.add(foldOutPanel, BorderLayout.CENTER);
    return bottomPanel;
  }
}