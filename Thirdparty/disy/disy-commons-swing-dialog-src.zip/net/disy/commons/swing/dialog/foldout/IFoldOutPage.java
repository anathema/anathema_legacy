//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import net.disy.commons.swing.dialog.core.IPageContent;

// NOT_PUBLISHED
public interface IFoldOutPage extends IPageContent {

}