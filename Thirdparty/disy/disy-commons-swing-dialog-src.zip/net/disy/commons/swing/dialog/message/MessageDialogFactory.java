//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import java.awt.Component;
import java.awt.Font;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.swing.dialog.foldout.FoldOutDialog;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

// NOT_PUBLISHED
public class MessageDialogFactory {

  private static final Font FIXEDWIDTH_FONT = new Font("Monospaced", Font.PLAIN, 11); //$NON-NLS-1$

  public static FoldOutDialog createFoldOutMessageDialog(
      Component parentComponent,
      IMessage message,
      IFoldOutPage foldOutPage) {
    return new FoldOutDialog(parentComponent, new FoldOutMessageDialogConfiguration(message, foldOutPage));
  }

  public static UserDialog createMessageDialog(Component parentComponent, final IMessage message) {
    UserDialog userDialog;
    if (message.getDetail() == null) {
      userDialog = new UserDialog(parentComponent, new MessageUserDialogConfiguration(message));
    }
    else {
      IFoldOutPage foldOutPage = new IFoldOutPage() {
        private JComponent content;

        public void requestFocus() {
          //nothing to do
        }
        
        public void dispose() {
          // nothing to do
        }

        public JComponent getContent() {
          if (content == null) {
            JTextArea textArea = new JTextArea(12, 70);
            textArea.setFont(FIXEDWIDTH_FONT);
            textArea.setText(message.getDetail());
            content = new JScrollPane(textArea);
          }
          return content;
        }
      };
      userDialog = new FoldOutDialog(parentComponent, new FoldOutMessageDialogConfiguration(message, foldOutPage));
    }
    userDialog.getDialog().setResizable(false);
    return userDialog;
  }

  public static void showMessageDialog(Component parent, IMessage message) {
    createMessageDialog(parent, message).show();
  }
}