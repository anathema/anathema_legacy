/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed;

import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.model.listener.NotifyChangeListenerClosure;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.dialog.tabbed.internal.ExtendedJTabbedPane;
import net.disy.commons.swing.dialog.tabbed.internal.ITabCloseRequestHandler;
import net.disy.commons.swing.dialog.tabbed.internal.SmartTabbedPaneUi;
import net.disy.commons.swing.dialog.tabbed.internal.TabTitleComponent;
import net.disy.commons.swing.util.GuiUtilities;

public class SmartTabbedPane implements IComponentContainer {

  private final ListenerList<IChangeListener> selectionChangeListenerList = new ListenerList<IChangeListener>();
  private final ExtendedJTabbedPane tabbedPane;
  private ISmartTabbedPanePopupMenuFactory popupMenuFactory;
  private final ISmartTabbedPaneCloseHandler optionalCloseHandler;

  public SmartTabbedPane(final ISmartTabbedPaneCloseHandler closeHandler) {
    this(TabPlacement.TOP, closeHandler);
  }

  public SmartTabbedPane(
      final TabPlacement placement,
      final ISmartTabbedPaneCloseHandler optionalCloseHandler) {
    Ensure.ensureArgumentNotNull(placement);
    this.optionalCloseHandler = optionalCloseHandler;
    tabbedPane = new ExtendedJTabbedPane(placement, JTabbedPane.SCROLL_TAB_LAYOUT);
    tabbedPane.addChangeListener(new ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent e) {
        selectionChangeListenerList.forAllDo(NotifyChangeListenerClosure.INSTANCE);
        updateAllTitleComponentsForActive();
      }
    });
    final SmartTabbedPaneUi ui = new SmartTabbedPaneUi();
    tabbedPane.setUI(ui);
  }

  private void updateAllTitleComponentsForActive() {
    final int selectedTabIndex = tabbedPane.getSelectedIndex();
    for (int index = 0; index < tabbedPane.getTabCount(); ++index) {
      final TabTitleComponent titleComponent = (TabTitleComponent) tabbedPane
          .getTabComponentAt(index);
      if (titleComponent == null) {
        // Happens when adding a new tab
        continue;
      }
      titleComponent.setIsActiveTab(index == selectedTabIndex);
    }
  }

  public void addTabSelectionChangeListener(final IChangeListener listener) {
    selectionChangeListenerList.add(listener);
  }

  @Override
  public JComponent getContent() {
    return tabbedPane;
  }

  public void addTab(final String title, final Icon icon, final JComponent content) {
    tabbedPane.addTab(null, content);
    final int tabIndex = tabbedPane.getTabCount() - 1;
    final ITabCloseRequestHandler closeRequestHandler = optionalCloseHandler == null
        ? null
        : new ITabCloseRequestHandler() {
          @Override
          public void handleCloseRequested(final TabTitleComponent titleComponent) {
            final int index = getTabIndexByTitleComponent(titleComponent);
            optionalCloseHandler.handleTabClosing(SmartTabbedPane.this, index);
          }
        };
    final TabTitleComponent tabTitleComponent = new TabTitleComponent(
        title,
        icon,
        closeRequestHandler);
    tabbedPane.setTabComponentAt(tabIndex, tabTitleComponent);
    updateAllTitleComponentsForActive();
    tabTitleComponent.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        if (e.isMetaDown()) {
          return;
        }
        final int index = getTabIndexByTitleComponent(tabTitleComponent);
        tabbedPane.setSelectedIndex(index);
        if (!GuiUtilities.containsFocusOwner(tabbedPane)) {
          tabbedPane.getComponentAt(index).requestFocusInWindow();
        }
      }

      @Override
      public void mouseReleased(final MouseEvent e) {
        if (!e.isMetaDown()) {
          return;
        }
        if (popupMenuFactory == null) {
          return;
        }
        final int currentTabIndex = getTabIndexByTitleComponent(tabTitleComponent);
        final JPopupMenu popupMenu = popupMenuFactory.createPopupMenu(currentTabIndex);
        if (popupMenu == null) {
          return;
        }
        tabbedPane.setHasPopupMenuVisible(true);
        try {
          popupMenu.show(tabTitleComponent, e.getX(), e.getY());
        }
        finally {
          tabbedPane.setHasPopupMenuVisible(true);
        }
      }
    });
  }

  private int getTabIndexByTitleComponent(final TabTitleComponent component) {
    for (int index = 0; index < tabbedPane.getTabCount(); ++index) {
      if (tabbedPane.getTabComponentAt(index) == component) {
        return index;
      }
    }
    return -1;
  }

  public void setTitleAt(final int tabIndex, final String title) {
    final TabTitleComponent titleComponent = (TabTitleComponent) tabbedPane
        .getTabComponentAt(tabIndex);
    titleComponent.setText(title);
  }

  public void setIconAt(final int tabIndex, final Icon icon) {
    final TabTitleComponent titleComponent = (TabTitleComponent) tabbedPane
        .getTabComponentAt(tabIndex);
    titleComponent.setIcon(icon);
  }

  public void setSelectedTabIndex(final int tabIndex) {
    tabbedPane.setSelectedIndex(tabIndex);
  }

  public int getSelectedTabIndex() {
    return tabbedPane.getSelectedIndex();
  }

  public void removeTab(final int tabIndex) {
    tabbedPane.removeTabAt(tabIndex);
  }

  public void setPopupMenuFactory(final ISmartTabbedPanePopupMenuFactory popupMenuFactory) {
    this.popupMenuFactory = popupMenuFactory;
  }

  public void setSelectedComponent(final JComponent component) {
    tabbedPane.setSelectedComponent(component);
  }

  public Component getSelectedComponent() {
    return tabbedPane.getSelectedComponent();
  }
}