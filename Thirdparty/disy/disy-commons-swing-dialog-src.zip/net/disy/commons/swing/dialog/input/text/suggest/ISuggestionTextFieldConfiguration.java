/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest;

import javax.swing.JComponent;

import net.disy.commons.core.text.ISuggestionsForStringProvider;
import net.disy.commons.swing.ui.IObjectUi;

/** Clients should not implement this interface, but rather extend {@link AbstractSuggestionTextFieldConfiguration} */
public interface ISuggestionTextFieldConfiguration<T> {

  /** @return a text for the textfield tool tip or <code>null</code> if none. */
  public String getToolTipText();

  public String getBusyLabelText();

  /** @return a label to be shown or <code>null</code> if there shall not be a window with no results. */
  public String getNoResultLabelText();

  public IObjectUi<T> getObjectUi();

  /** @return a text that will be taken over to the search textfield, when the given item is selected
   * from the dropdown list, or <code>null</code> if the textfield content shall stay the same. */
  public String getRawSearchText(T value);

  public ISuggestionActionHandler<T> getActionHandler();

  public ISuggestionsForStringProvider<T> getSuggestionsForStringProvider();

  public ISwingIOExceptionHandler getErrorHandler();

  public boolean isClearButtonVisible();

  public JComponent createOptionalLeftInsideTextFieldComponent();

  public JComponent createOptionalRightInsideTextFieldComponent();
}