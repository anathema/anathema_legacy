//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox.internal;

import java.util.Comparator;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class TextualMatchRankerComparator<T> implements Comparator<T> {

  private final IObjectUi<T> objectUi;
  private final String pattern;

  public TextualMatchRankerComparator(final IObjectUi<T> objectUi, final String pattern) {
    Ensure.ensureArgumentNotNull(objectUi);
    Ensure.ensureArgumentNotNull(pattern);
    this.objectUi = objectUi;
    this.pattern = pattern;
  }

  @Override
  public int compare(final T o1, final T o2) {
    final String text1 = objectUi.getLabel(o1);
    final String text2 = objectUi.getLabel(o2);
    return TextualMatchRanker.rank(text2, pattern) - TextualMatchRanker.rank(text1, pattern);
  }
}