// Copyright (c) 2004 by disy Informationssysteme GmbH
// Created on 01.03.2004
package net.disy.commons.swing.dialog.userdialog;

import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public final class DefaultUserDialog extends AbstractUserDialog {

  public DefaultUserDialog(IDialogPage dialogPage) {
    super(dialogPage);
  }

  public DefaultUserDialog(IDialogPage dialogPage, IDialogButtonConfiguration buttonConfiguration) {
    super(dialogPage, buttonConfiguration);
  }

}
