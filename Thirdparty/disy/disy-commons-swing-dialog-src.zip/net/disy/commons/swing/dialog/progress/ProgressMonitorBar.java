package net.disy.commons.swing.dialog.progress;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.swing.JProgressBar;

import net.disy.commons.core.progress.ICanceledListener;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.util.Ensure;

public class ProgressMonitorBar extends JProgressBar implements IProgressMonitor {

  private boolean unknownTotalWork;
  private final Collection canceledListeners = new ArrayList();
  private boolean canceled = false;

  /**
   * Creates a TimeSlider and register ist as a GisTermService
   */
  public ProgressMonitorBar() {
    setOpaque(true);
    setDoubleBuffered(false);
    setBorderPainted(false);
    setStringPainted(false);
  }

  public void beginTask(String name, int totalWork) {
    canceled = false;
    setMinimum(0);

    unknownTotalWork = (totalWork == UNKNOWN);
    setIndeterminate(unknownTotalWork);
    setStringPainted(!unknownTotalWork);
    if (!unknownTotalWork) {
      super.setMaximum(totalWork);
    }
    setValue(0);
  }

  public void done() {
    setIndeterminate(false);
    setStringPainted(false);
    setValue(0);
  }

  public boolean isCanceled() {
    return canceled;
  }

  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
    if (canceled) {
      fireCanceled();
    }
  }

  public void subTask(String name) {
    //nothing to do
  }

  public void worked(int work) {
    if (!unknownTotalWork) {
      super.setValue(getValue() + work);
    }
  }

  public synchronized void addCanceledListener(ICanceledListener listener) {
    Ensure.ensureNotNull(listener);
    canceledListeners.add(listener);
  }

  public synchronized void removeCanceledListener(ICanceledListener listener) {
    canceledListeners.remove(listener);
  }

  private void fireCanceled() {
    List clonedListeners;
    synchronized (this) {
      clonedListeners = new ArrayList(canceledListeners);
    }
    for (Iterator iter = clonedListeners.iterator(); iter.hasNext();) {
      ICanceledListener listener = (ICanceledListener) iter.next();
      listener.canceled();
    }
  }
}