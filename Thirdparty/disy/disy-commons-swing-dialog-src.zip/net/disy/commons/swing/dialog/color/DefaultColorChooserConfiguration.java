/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class DefaultColorChooserConfiguration implements IColorChooserConfiguration {

  private String colorChooserDialogTitle;
  private boolean transparencyEnabled;

  public DefaultColorChooserConfiguration() {
    this(DisyCommonsSwingMessages.getString("ColorChooserButton.DefaultTitle"), false); //$NON-NLS-1$
  }

  public DefaultColorChooserConfiguration(final boolean transparencyEnabled) {
    this(DisyCommonsSwingMessages.getString("ColorChooserButton.DefaultTitle"), transparencyEnabled); //$NON-NLS-1$
  }

  public DefaultColorChooserConfiguration(
      final String colorChooserDialogTitle,
      final boolean transparencyEnabled) {
    Ensure.ensureArgumentNotNull(colorChooserDialogTitle);
    this.colorChooserDialogTitle = colorChooserDialogTitle;
    this.transparencyEnabled = transparencyEnabled;
  }

  @Override
  public boolean isTransparencyEnabled() {
    return transparencyEnabled;
  }

  @Override
  public String getColorChooserDialogTitle() {
    return colorChooserDialogTitle;
  }

  public void setColorChooserDialogTitle(final String colorChooserDialogTitle) {
    Ensure.ensureArgumentNotNull(colorChooserDialogTitle);
    this.colorChooserDialogTitle = colorChooserDialogTitle;
  }

  public void setTransparencyEnabled(final boolean transparencyEnabled) {
    this.transparencyEnabled = transparencyEnabled;
  }
}