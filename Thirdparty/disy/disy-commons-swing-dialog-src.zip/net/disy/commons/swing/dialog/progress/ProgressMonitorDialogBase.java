/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.core.progress.IInterruptableResultReturningRunnableWithProgress;
import net.disy.commons.core.progress.IInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.INonInterruptableResultReturningRunnableWithProgress;
import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IObservableCancelable;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.progress.IRunnableContext;
import net.disy.commons.core.util.Ensure;

/**
 * A modal dialog that displays progress during a long running operation.
 *
 * @author gebhard
 */
public abstract class ProgressMonitorDialogBase
    implements
    IRunnableContext,
    IProgressMonitorStrategie {

  private boolean first = true;

  @Override
  public void run(final INonInterruptableRunnableWithProgress runnable)
      throws InvocationTargetException {
    Ensure.ensureArgumentNotNull(runnable);
    synchronized (this) {
      if (!first) {
        throw new IllegalStateException("Progress monitor dialog can only be run once."); //$NON-NLS-1$
      }
      first = false;
    }
  }

  @Override
  public void run(final IInterruptableRunnableWithProgress runnable)
      throws InterruptedException,
      InvocationTargetException {
    Ensure.ensureArgumentNotNull(runnable);
    synchronized (this) {
      if (!first) {
        throw new IllegalStateException("Progress monitor dialog can only be run once."); //$NON-NLS-1$
      }
      first = false;
    }
  }

  @Override
  public <R, E extends Exception> R run(
      final INonInterruptableResultReturningRunnableWithProgress<R, E> runnable) throws E {
    class ResultReturningRunnable implements INonInterruptableRunnableWithProgress {
      private R result;

      @Override
      public void run(final IProgressMonitor monitor) throws InvocationTargetException {
        try {
          result = runnable.run(monitor);
        }
        catch (final RuntimeException e) {
          throw e;
        }
        catch (final Exception e) {
          throw new InvocationTargetException(e);
        }
      }

      public R finish() {
        return result;
      }
    }
    final ResultReturningRunnable resultReturningRunnable = new ResultReturningRunnable();
    try {
      run(resultReturningRunnable);
    }
    catch (final InvocationTargetException e) {
      throw (E) e.getTargetException();
    }
    return resultReturningRunnable.finish();
  }

  @Override
  public <R, E extends Exception> R run(
      final IInterruptableResultReturningRunnableWithProgress<R, E> runnable)
      throws E,
      InterruptedException {
    class ResultReturningRunnable implements IInterruptableRunnableWithProgress {
      private R result;

      @Override
      public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
          throws InvocationTargetException {
        try {
          result = runnable.run(monitor, cancelable);
        }
        catch (final RuntimeException e) {
          throw e;
        }
        catch (final Exception e) {
          throw new InvocationTargetException(e);
        }
      }

      public R finish() {
        return result;
      }
    }
    final ResultReturningRunnable resultReturningRunnable = new ResultReturningRunnable();
    try {
      run(resultReturningRunnable);
    }
    catch (final InvocationTargetException e) {
      if (e.getTargetException() instanceof InterruptedException) {
        throw (InterruptedException) e.getTargetException();
      }
      throw (E) e.getTargetException();
    }
    return resultReturningRunnable.finish();
  }
}