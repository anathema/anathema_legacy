//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.swing.dialog.input.IInputDialogConfiguration;
import net.disy.commons.swing.message.IBasicMessage;

// NOT_PUBLISHED
public interface ITextInputDialogConfiguration extends IInputDialogConfiguration {

  public String getLabelText();

  public IBasicMessage createCurrentMessage(String selectedText);

}