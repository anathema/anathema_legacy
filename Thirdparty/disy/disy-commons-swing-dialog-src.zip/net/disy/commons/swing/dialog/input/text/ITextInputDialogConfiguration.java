//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.input.IInputDialogConfiguration;

// NOT_PUBLISHED
public interface ITextInputDialogConfiguration extends IInputDialogConfiguration {

  public String getLabelText();

  public IBasicMessage createCurrentMessage(String selectedText);

}