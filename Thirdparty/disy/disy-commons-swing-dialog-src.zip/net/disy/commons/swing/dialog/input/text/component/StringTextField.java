/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.text.JTextComponent;

import net.disy.commons.swing.events.AbstractDocumentChangeListener;

public class StringTextField<T extends JTextComponent> implements IStringInputComponent<T> {

  private final T textField;

  public StringTextField(final T textField) {
    this.textField = textField;
  }

  @Override
  public void addChangeListener(final ChangeListener changeListener) {
    textField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      @Override
      protected void documentChanged() {
        changeListener.stateChanged(new ChangeEvent(textField));
      }
    });
  }

  @Override
  public T getComponent() {
    return textField;
  }

  @Override
  public String getValue() {
    return textField.getText();
  }

  @Override
  public void setValue(final String value) {
    textField.setText(value);
  }

  @Override
  public boolean isEditable() {
    return textField.isEditable();
  }

  @Override
  public void setEditable(final boolean editable) {
    textField.setEditable(editable);
  }

  @Override
  public void selectAll() {
    textField.selectAll();
  }

  @Override
  public void requestFocus() {
    textField.requestFocus();
  }

  @Override
  public void setEnabled(final boolean enabled) {
    textField.setEnabled(enabled);
  }

  @Override
  public void update() {
    // nothing to do    
  }
}
