/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JComponent;

import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.core.IGenericDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public interface IDialogConfiguration<P extends IDialogPage> extends IGenericDialogConfiguration {

  public P getDialogPage();

  public void setUserDialogContainer(IUserDialogContainer userDialog);

  public JComponent[] createAdditionalButtons();

  public JComponent createOptionalButtonPanelLeftComponent();

  /** 
   * Performs any actions appropriate in response to the user having pressed the ok button, or
   * refuse if closing now is not permitted.
   * 
   * @deprecated As of 11.11.2009 (gebhard), replaced by either implementing {@link #getVetoCloseHandler()}
   * if veto is required.
   * Otherwise perform those operations on the {@link IDialogResult} after showing the dialog
   * via {@link UserDialog#show()} or implement a {@link IDialogCloseHandler} for a call to
   * {@link UserDialog#showNonModal(IDialogCloseHandler)}.
   * 
   * @return <code>true</code> to indicate the ok request was accepted, and <code>false</code>
   *         to indicate that the ok request was refused.
   */
  @Deprecated
  public boolean performOk(Component parentComponent);

  /**
   * Performs any actions appropriate in response to the user having pressed the Cancel button, or
   * refuse if canceling now is not permitted.
   * 
   * @deprecated As of 11.11.2009 (gebhard), replaced by either implementing {@link #getVetoCloseHandler()}
   * if veto is required.
   * Otherwise perform those operations on the {@link IDialogResult} after showing the dialog
   * via {@link UserDialog#show()} or implement a {@link IDialogCloseHandler} for a call to
   * {@link UserDialog#showNonModal(IDialogCloseHandler)}.
   * 
   * @return <code>true</code> to indicate the cancel request was accepted, and <code>false</code>
   *         to indicate that the cancel request was refused.
   */
  @Deprecated
  public boolean performCancel(Component parentComponent);

  public Dimension getCustomizedPreferedSize();
}