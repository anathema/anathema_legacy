// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.demo;

import java.io.File;

import javax.swing.filechooser.FileSystemView;

import net.disy.commons.swing.dialog.file.FileChooserDialogConfiguration;
import net.disy.commons.swing.dialog.file.FileChooserModel;
import net.disy.commons.swing.dialog.file.FileChooserUtilities;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

//NOT_PUBLISHED
public class FileChooserDialogDemo extends AbstractFileChooserDemo {
  private FileChooserModel model;

  protected void setUp() throws Exception {
    model = new FileChooserModel();
    model.getFolderModel().setFile(new File(System.getProperty("user.home"))); //$NON-NLS-1$
  }

  public void demoOpenDialogWithoutRoots() throws Exception {
    show(FileChooserUtilities
        .createOpenFileDialog(createParentComponent(), model)
        .getDialog()
        .getWindow());
  }

  public void demoOpenDialogWithRoots() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    show(FileChooserUtilities.createOpenFileDialog(
        createParentComponent(),
        model,
        new FileChooserDialogConfiguration(roots)).getDialog().getWindow());
  }

  public void demoOpenDialogWithSelectedFile() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    selectFirstPlainFile();
    show(FileChooserUtilities.createOpenFileDialog(
        createParentComponent(),
        model,
        new FileChooserDialogConfiguration(roots)).getDialog().getWindow());
  }

  public void demoOpenDialogWithSelectAndDeselectFile() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    selectFirstPlainFile();
    UserDialog dialog = FileChooserUtilities.createOpenFileDialog(
        createParentComponent(),
        model,
        new FileChooserDialogConfiguration(roots));
    model.getFileModel().setFile(null);
    show(dialog.getDialog().getWindow());
  }

  private void selectFirstPlainFile() {
    File folder = model.getFolderModel().getFile();
    final FileSystemView fileSystemView = FileSystemView.getFileSystemView();
    File[] files = fileSystemView.getFiles(folder, true);
    for (int index = 0; index < files.length; index++) {
      if (!files[index].isDirectory()) {
        model.getFileModel().setFile(files[index]);
        break;
      }
    }
  }

  public void demoOpenDialogWithFileFilters() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    UserDialog dialog = FileChooserUtilities.createOpenFileDialog(
        createParentComponent(),
        model,
        new FileChooserDialogConfiguration(roots));
    addFileFilters(model);
    show(dialog.getDialog().getWindow());
  }

  public void demoSaveDialogWithoutRoots() throws Exception {
    show(FileChooserUtilities
        .createSaveFileDialog(createParentComponent(), model)
        .getDialog()
        .getWindow());
  }

  public void demoSaveDialogWithRoots() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    show(FileChooserUtilities.createSaveFileDialog(
        createParentComponent(),
        model,
        new FileChooserDialogConfiguration(roots)).getDialog().getWindow());
  }
}