// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.demo;

import java.io.File;

import net.disy.commons.swing.dialog.file.FileChooserDialogConfiguration;
import net.disy.commons.swing.dialog.file.FileChooserModel;
import net.disy.commons.swing.dialog.file.FileChooserPanel;

//NOT_PUBLISHED
public class FileChooserPanelDemo extends AbstractFileChooserDemo {
  private FileChooserModel model;

  protected void setUp() throws Exception {
    model = new FileChooserModel();
    model.getFolderModel().setFile(new File(System.getProperty("user.home"))); //$NON-NLS-1$
  }

  public void demoWithoutRoots() throws Exception {
    show(new FileChooserPanel(model, new FileChooserDialogConfiguration()).getContent());
  }

  public void demoWithRoots() throws Exception {
    File[] roots = new File[]{ new File(System.getProperty("user.home")) }; //$NON-NLS-1$
    show(new FileChooserPanel(model, new FileChooserDialogConfiguration(roots)).getContent());
  }

  public void demoFileFilters() throws Exception {
    addFileFilters(model);
    show(new FileChooserPanel(model, new FileChooserDialogConfiguration()).getContent());
  }
}
