//Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select.demo;

import java.awt.Color;

import net.disy.commons.swing.dialog.input.select.AbstractOneOutOfManyDialogConfiguration;
import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class DemoSomeOutOfManyDialogConfiguration extends AbstractOneOutOfManyDialogConfiguration {
  public String getTitle() {
    return "Color"; //$NON-NLS-1$
  }

  public String getNoItemSelectedErrorMessageText() {
    return "There is no color selected. Please select a color."; //$NON-NLS-1$
  }

  public String getDefaultMessageText() {
    return "Please select a color."; //$NON-NLS-1$
  }

  public IObjectUi getObjectUi() {
    return new ColorUi();
  }

  public Object[] getItems() {
    return new Color[]{ Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA };
  }

  @Override
  public String getDescription() {
    return "Available Colors:"; //$NON-NLS-1$
  }
}