/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;
import net.disy.commons.swing.label.SmartLabel;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public abstract class AbstractLabeledSmartDialogPanel extends AbstractValidatingSmartDialogPanel
    implements
    IUpdatableSmartDialogPanel {

  private final SmartLabel label;
  private final GridAlignment verticalLabelAlignment;
  private String toolTipText;

  public AbstractLabeledSmartDialogPanel(
      final String label,
      final String toolTipText,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, validator, GridAlignment.CENTER);
  }

  protected AbstractLabeledSmartDialogPanel(
      final String label,
      final String toolTipText,
      final IMessageProducingValidator validator,
      final GridAlignment verticalLabelAlignment) {
    super(validator);
    this.toolTipText = toolTipText;
    Ensure.ensureArgumentNotNull(label);
    Ensure.ensureArgumentNotNull(verticalLabelAlignment);
    this.label = new SmartLabel(label);
    this.label.setToolTipText(toolTipText);
    this.verticalLabelAlignment = verticalLabelAlignment;
  }

  protected void setLabelAndToolTip(String labelStr, final String toolTipText) {
    this.toolTipText = toolTipText;
    this.label.setText(labelStr);
    this.label.setToolTipText(toolTipText);
  }

  @Override
  public final int getColumnCount() {
    return 1 + getMainComponentColumnCount();
  }

  @Override
  public final void fillInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData labelLayout = new GridDialogLayoutData();
    labelLayout.setHorizontalAlignment(GridAlignment.END);
    labelLayout.setVerticalAlignment(verticalLabelAlignment);
    panel.add(label, labelLayout);
    final JComponent focusComponent = fillMainComponentInto(panel, columnCount - 1);
    fillToolTips();
    if (focusComponent != null) {
      label.setLabelFor(focusComponent);
    }
  }

  private void fillToolTips() {
    for (JComponent components : this.getOtherComponents()) {
      if (components.getToolTipText() == null) {
        components.setToolTipText(this.toolTipText);
      }
    }
  }

  @Override
  public final void setEnabled(final boolean enabled) {
    label.setEnabled(enabled);
    setMainComponentEnabled(enabled);
  }

  protected abstract int getMainComponentColumnCount();

  protected abstract JComponent fillMainComponentInto(JPanel panel, int columnCount);

  protected abstract void setMainComponentEnabled(boolean enabled);

  @Override
  public JComponent[] getComponents() {
    return ArrayUtilities.concat(label, getOtherComponents(), JComponent.class);
  }

  protected abstract JComponent[] getOtherComponents();

  @Override
  public void update() {
    // nothing to do
  }
}