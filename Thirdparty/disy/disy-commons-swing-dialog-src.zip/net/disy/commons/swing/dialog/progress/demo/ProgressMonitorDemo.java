// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.progress.demo;

import java.lang.reflect.InvocationTargetException;

import javax.swing.JOptionPane;
import javax.swing.ProgressMonitor;

import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.progress.IRunnableWithProgress;
import net.disy.commons.core.progress.ProgressUtilities;
import net.disy.commons.swing.dialog.progress.ProgressMonitorDialog;

import de.jdemo.framework.PlainDemoCase;

/**
 * @author gebhard
 */
public class ProgressMonitorDemo extends PlainDemoCase {

  private static final int TOTAL_WORK = 25;

  public void demoSwingProgressMonitor() {
    ProgressMonitor monitor = new ProgressMonitor(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige", "Berechne Werte...", 0, TOTAL_WORK); //$NON-NLS-1$ //$NON-NLS-2$
    monitor.setNote("Berechne Werte"); //$NON-NLS-1$
    for (int i = 0; i < TOTAL_WORK; ++i) {
      performWork();
      monitor.setProgress(i);
    }
    monitor.setProgress(monitor.getMaximum());
  }

  public void demoUnknownWorkNotCancelable() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(false, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            ProgressUtilities.checkInterrupted(monitor);
            performWork();
          }
          monitor.done();
        }
      });
    }
    catch (InterruptedException e) {
      e.printStackTrace(); //Kann eigentlich nicht passieren, da nicht cancelable
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  public void demoUnknownWorkCancelable() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            ProgressUtilities.checkInterrupted(monitor);
            performWork();
          }
          monitor.done();
        }
      });
    }
    catch (InterruptedException e) {
      System.err.println("Berechnung abgebrochen"); //$NON-NLS-1$
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  public void demoWellKnownWorkNotCancelable() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(false, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK); //$NON-NLS-1$ //$NON-NLS-2$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            performWork();
            monitor.worked(1);
          }
          monitor.done();
        }

      });
    }
    catch (InterruptedException e) {
      e.printStackTrace(); //Kann eigentlich nicht passieren, da nicht cancelable
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  public void demoWellKnownWorkWithSubTasks() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(false, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK); //$NON-NLS-1$ //$NON-NLS-2$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            monitor.subTask((i + 1) + " ter Wert"); //$NON-NLS-1$
            performWork();
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    catch (InterruptedException e) {
      e.printStackTrace(); //Kann eigentlich nicht passieren, da nicht cancelable
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  public void demoWellKnownWorkCancelable() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException {
          monitor.beginTask("Berechne " + TOTAL_WORK + " Werte", TOTAL_WORK); //$NON-NLS-1$ //$NON-NLS-2$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            ProgressUtilities.checkInterrupted(monitor);
            performWork();
            monitor.worked(1);
          }
          monitor.done();
        }
      });
    }
    catch (InterruptedException e) {
      System.err.println("Berechnung abgebrochen"); //$NON-NLS-1$
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  public void demoDivisionByZeroDuringWork() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(false, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
          for (int i = 0; i < TOTAL_WORK; ++i) {
            performWork();
            if (i == TOTAL_WORK / 2) {
              i /= 0;
            }
          }
          monitor.done();
        }
      });
    }
    catch (InterruptedException e) {
      e.printStackTrace(); //Kann eigentlich nicht passieren, da nicht cancelable
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

  private void performWork() {
    try {
      Thread.sleep(200);
    }
    catch (InterruptedException e) {
      //nothing to do
    }
  }

  public void demoEagerRunnable() {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(
        JOptionPane.getRootFrame(),
        "Fortschrittsanzeige"); //$NON-NLS-1$
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException {
          monitor.beginTask("Berechne Werte", IProgressMonitor.UNKNOWN); //$NON-NLS-1$
          Thread.sleep(10000);
        }
      });
    }
    catch (InterruptedException e) {
      System.err.println("Berechnung abgebrochen"); //$NON-NLS-1$
    }
    catch (InvocationTargetException e) {
      System.err.println("Fehler bei der Ausf�hrung:"); //$NON-NLS-1$
      e.printStackTrace();
    }
    exit();
  }

}