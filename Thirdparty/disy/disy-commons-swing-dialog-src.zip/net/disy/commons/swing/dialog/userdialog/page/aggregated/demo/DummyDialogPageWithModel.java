/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated.demo;

import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.aggregated.IDialogPageWithModel;

public class DummyDialogPageWithModel implements IDialogPageWithModel<Void> {

  private final IDialogPage dialogPage;

  public DummyDialogPageWithModel(final IDialogPage dialogPage) {
    this.dialogPage = dialogPage;
  }

  @Override
  public IDialogPage getDialogPage() {
    return dialogPage;
  }

  @Override
  public Void getModel() {
    return null;
  }

  @Override
  public String getLabel() {
    return "Label"; //$NON-NLS-1$
  }
}
