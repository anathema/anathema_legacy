/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.combo.demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.ISelectableItemsPanelConfiguration;
import net.disy.commons.swing.dialog.input.StaticComponentSmartDialogPanel;
import net.disy.commons.swing.dialog.input.combo.ComboSelectionDialogPanel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItemUi;
import net.disy.commons.swing.ui.IObjectUi;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class ComboSelectionDialogPanelDemo extends DialogDemoCase {

  private static DemoColorItem[] createDemoItems() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    return items.toArray(new DemoColorItem[items.size()]);
  }

  private static DemoColorItem[] createResucedDemoItems() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems().subList(0, 2);
    return items.toArray(new DemoColorItem[items.size()]);
  }

  @Demo
  public void immutable() throws Exception {
    final ObjectModel<DemoColorItem> model = new ObjectModel<DemoColorItem>();
    final ISelectableItemsPanelConfiguration<DemoColorItem> configuration = new ISelectableItemsPanelConfiguration<DemoColorItem>() {
      @Override
      public IObjectUi<DemoColorItem> getObjectUi() {
        return new DemoColorItemUi();
      }

      @Override
      public DemoColorItem[] getItems() {
        return createDemoItems();
      }

    };
    final IMessageProducingValidator validator = createValidator(model);
    final ComboSelectionDialogPanel<DemoColorItem> panel = new ComboSelectionDialogPanel<DemoColorItem>(
        "&Color:", //$NON-NLS-1$
        model,
        configuration,
        validator);
    show(panel);
  }

  private IMessageProducingValidator createValidator(final ObjectModel<DemoColorItem> model) {
    final IMessageProducingValidator validator = new IMessageProducingValidator() {
      @Override
      public IBasicMessage createOptionalCurrentMessage() {
        if (model.getValue() == null) {
          return new BasicMessage(
              "There is no color item selected. Please select a color item.", MessageType.ERROR); //$NON-NLS-1$
        }
        return null;
      }
    };
    return validator;
  }

  @Demo
  public void mutable() {
    final ObjectModel<DemoColorItem> model = new ObjectModel<DemoColorItem>();

    final JRadioButton radioButton1 = new JRadioButton("Reduced color set"); //$NON-NLS-1$
    final JRadioButton radioButton2 = new JRadioButton("Full color set"); //$NON-NLS-1$

    final ButtonGroup buttonGroup = new ButtonGroup();
    buttonGroup.add(radioButton1);
    buttonGroup.add(radioButton2);

    radioButton2.setSelected(true);

    final DefaultListModel<DemoColorItem> itemsModel = new DefaultListModel<DemoColorItem>(
        createDemoItems());

    radioButton1.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        itemsModel.setItems(createResucedDemoItems());
      }
    });
    radioButton2.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        itemsModel.setItems(createDemoItems());
      }
    });
    final ComboSelectionDialogPanel<DemoColorItem> panel = new ComboSelectionDialogPanel<DemoColorItem>(
        "&Color:", //$NON-NLS-1$
        model,
        itemsModel,
        new DemoColorItemUi(),
        createValidator(model));

    show(new StaticComponentSmartDialogPanel(radioButton1), new StaticComponentSmartDialogPanel(
        radioButton2), panel);
  }
}