//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JScrollPane;

import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.list.IListMouseHandler;
import net.disy.commons.swing.list.JListMouseListener;
import net.disy.commons.swing.list.ListSelectionMode;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

// NOT_PUBLISHED
public class SelectOneOutOfManyDialogPage extends AbstractDialogPage {

  private final JList list;
  private final IOneOutOfManyDialogConfiguration configuration;

  public SelectOneOutOfManyDialogPage(IOneOutOfManyDialogConfiguration configuration) {
    super(new BasicMessage(configuration.getDefaultMessageText()));
    this.configuration = configuration;
    list = new JList(configuration.getItems());
    list.setCellRenderer(new ObjectUiListCellRenderer(configuration.getObjectUi()));
  }

  public Object getSelectedItem() {
    return list.getSelectedValue();
  }

  public IBasicMessage createCurrentMessage() {
    if (getSelectedItem() == null) {
      return new BasicMessage(configuration.getNoItemSelectedErrorMessageText(),

      MessageType.ERROR);
    }
    return getDefaultMessage();
  }

  public String getTitle() {
    return configuration.getTitle();
  }

  public JComponent createContent() {
    list.setSelectedIndex(0);
    list.getSelectionModel().addListSelectionListener(getCheckInputValidListener());
    list.getSelectionModel().setSelectionMode(
        ListSelectionMode.SINGLE_SELECTION.getListSelectionMode());
    JListMouseListener.attachTo(list, new IListMouseHandler() {
      public void handleDoubleClick(Object[] arg0) {
        requestFinish();
      }

      public void handleContextMenuClick(Object[] arg0) {
        //nothing to do
      }
    });
    return new JScrollPane(list);
  }
}