/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page;

import net.disy.commons.core.util.IReturningClosure;

public class DialogPageClosureAssociation<R> {

  private final IDialogPage dialogPage;
  private final IReturningClosure<R, RuntimeException> closure;
  private final String description;

  public DialogPageClosureAssociation(
      IDialogPage dialogPage,
      IReturningClosure<R, RuntimeException> closure,
      String description) {
    super();
    this.dialogPage = dialogPage;
    this.closure = closure;
    this.description = description;
  }

  public IDialogPage getDialogPage() {
    return dialogPage;
  }

  public IReturningClosure<R, RuntimeException> getClosure() {
    return closure;
  }

  public String getDescription() {
    return description;
  }

}
