/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.combo;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.ISelectableItemsPanelConfiguration;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.ui.DefaultObjectUi;
import net.disy.commons.swing.ui.IObjectUi;

public class BooleanModelSmartDialogPanel extends ComboSelectionDialogPanel<Boolean> {

  private final static ISelectableItemsPanelConfiguration<Boolean> CONFIGURATION = new ISelectableItemsPanelConfiguration<Boolean>() {
    @Override
    public Boolean[] getItems() {
      return new Boolean[]{ null, Boolean.TRUE, Boolean.FALSE };
    }

    @Override
    public IObjectUi<Boolean> getObjectUi() {
      return new AbstractObjectUi<Boolean>() {
        @Override
        public String getLabel(final Boolean value) {
          return value == null ? " " : new DefaultObjectUi<Boolean>().getLabel(value); //$NON-NLS-1$
        }
      };
    }
  };

  public BooleanModelSmartDialogPanel(
      final String label,
      final ObjectModel<Boolean> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public BooleanModelSmartDialogPanel(
      final String label,
      final String toolTipText,
      final ObjectModel<Boolean> model,
      final IMessageProducingValidator validator) {
    super(label, toolTipText, model, CONFIGURATION, validator);
  }
}