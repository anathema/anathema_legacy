// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.awt.Component;

import net.disy.commons.swing.dialog.userdialog.UserDialog;

//NOT_PUBLISHED
public class FileChooserUtilities {
  private FileChooserUtilities() {
    throw new UnsupportedOperationException();
  }

  public static UserDialog createOpenFileDialog(Component parent, FileChooserModel model) {
    return new UserDialog(parent, new FileOpenDialogPage(
        model,
        new FileChooserDialogConfiguration()));
  }

  public static UserDialog createOpenFileDialog(
      Component parent,
      FileChooserModel model,
      FileChooserDialogConfiguration configuration) {
    return new UserDialog(parent, new FileOpenDialogPage(model, configuration));
  }

  public static UserDialog createSaveFileDialog(Component parent, FileChooserModel model) {
    return new UserDialog(parent, new FileSaveDialogPage(
        model,
        new FileChooserDialogConfiguration()));
  }

  public static UserDialog createSaveFileDialog(
      Component parent,
      FileChooserModel model,
      FileChooserDialogConfiguration configuration) {
    return new UserDialog(parent, new FileSaveDialogPage(model, configuration));
  }

}
