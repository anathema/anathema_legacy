// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import net.disy.commons.swing.ui.IObjectUi;

//NOT_PUBLISHED
public interface ISelectionDialogPanelConfiguration<T> {
  public String getDescription();

  public T[] getItems();

  public IObjectUi getObjectUi();

  public String getNoItemSelectedErrorMessageText();

}
