/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.ArrayUtilities;
import net.disy.commons.core.util.ITransformer;
import net.disy.commons.swing.component.Gap;
import net.disy.commons.swing.dialog.userdialog.page.IBasicDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.util.GuiUtilities;
import net.disy.commons.swing.util.ToggleComponentEnabler;

public class RadioButtonAggregationDialogPage<M> extends AbstractAggregationDialogPage
    implements
    IDialogPage {

  private final IDialogPageWithModel<M>[] dialogPages;
  private final JRadioButton[] radioButtons;
  private JComponent[] contents;
  private final String defaultMessage;

  public RadioButtonAggregationDialogPage(
      final String title,
      final String defaultMessage,
      final IDialogPageWithModel<M>... dialogPages) {
    super(title);
    this.defaultMessage = defaultMessage;
    this.dialogPages = dialogPages;
    this.radioButtons = new JRadioButton[dialogPages.length];
    final ButtonGroup buttonGroup = new ButtonGroup();
    for (int i = 0; i < radioButtons.length; i++) {
      radioButtons[i] = new JRadioButton();
      radioButtons[i].addActionListener(getCheckInputValidListener());
      buttonGroup.add(radioButtons[i]);
    }
    radioButtons[0].setSelected(true);
  }

  protected void updateComponents() {
    for (int i = 0; i < dialogPages.length; i++) {
      GuiUtilities.setContainerEnabled(contents[i], radioButtons[i].isSelected());
    }
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    final HighestPriorityMessageBuilder messageBuilder = new HighestPriorityMessageBuilder();
    messageBuilder.addMessage(getDefaultMessage());
    messageBuilder.addMessage(getCurrentPage().getDialogPage().createCurrentMessage());
    return messageBuilder.getHighestPriorityMessage();
  }

  @Override
  protected IBasicDialogPage[] getPages() {
    return ArrayUtilities.transform(
        dialogPages,
        IBasicDialogPage.class,
        new ITransformer<IDialogPageWithModel<M>, IBasicDialogPage>() {
          @Override
          public IBasicDialogPage transform(final IDialogPageWithModel<M> input) {
            return input.getDialogPage();
          }
        });
  }

  @Override
  public JComponent createContent() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    contents = new JComponent[dialogPages.length];
    for (int i = 0; i < dialogPages.length; i++) {
      panel.add(radioButtons[i]);
      final JLabel label = new JLabel(dialogPages[i].getLabel());
      panel.add(label);
      contents[i] = dialogPages[i].getDialogPage().createContent();
      panel.add(new Gap());
      panel.add(contents[i], new GridDialogLayoutData()
          .setGrabExcessHorizontalSpace(true)
          .setHorizontalAlignment(GridAlignment.FILL));
      ToggleComponentEnabler.connectWithDecoration(radioButtons[i], contents[i], label);
    }
    updateComponents();
    return panel;
  }

  @Override
  public IBasicMessage getDefaultMessage() {
    return new BasicMessage(defaultMessage);
  }

  public IDialogPageWithModel<M> getCurrentPage() {
    for (int i = 0; i < radioButtons.length; i++) {
      if (radioButtons[i].isSelected()) {
        return dialogPages[i];
      }
    }
    throw new UnreachableCodeReachedException("ip"); //$NON-NLS-1$
  }
}
