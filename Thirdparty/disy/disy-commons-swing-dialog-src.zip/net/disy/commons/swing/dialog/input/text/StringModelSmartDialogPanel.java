// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.StringModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.IMessageProducingValidator;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

//NOT_PUBLISHED
public class StringModelSmartDialogPanel extends AbstractLabeledSmartDialogPanel {

  private final StringModel stringModel;
  private final JTextField textField;
  private final IMessageProducingValidator validator;

  public StringModelSmartDialogPanel(
      String label,
      final StringModel stringModel,
      IMessageProducingValidator validator) {
    super(label, validator);
    Ensure.ensureArgumentNotNull(stringModel);
    Ensure.ensureArgumentNotNull(validator);
    this.stringModel = stringModel;
    this.validator = validator;
    textField = new JTextField();
    textField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      protected void documentChanged() {
        stringModel.setValue(textField.getText());
      }
    });

    stringModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateTextField();
      }
    });
    updateTextField();
  }

  private void updateTextField() {
    if (ObjectUtilities.equals(textField.getText(), stringModel.getValue())) {
      return;
    }
    textField.setText(stringModel.getValue());
  }

  protected int getMainComponentColumnCount() {
    return 1;
  }

  protected void fillMainComponentInto(JPanel panel, int columnCount) {
    GridDialogLayoutData layoutData = new GridDialogLayoutData();
    layoutData.setGrabExcessHorizontalSpace(true);
    layoutData.setHorizontalAlignment(GridAlignment.FILL);
    layoutData.setHorizontalSpan(columnCount);
    panel.add(textField, layoutData);
  }

  public final IBasicMessage createOptionalCurrentMessage() {
    return validator.validate();
  }

  public void addChangeListener(ChangeListener listener) {
    stringModel.addChangeListener(listener);
  }

  public void selectAll() {
    textField.selectAll();
  }

  public void requestFocus() {
    textField.requestFocus();
  }
}