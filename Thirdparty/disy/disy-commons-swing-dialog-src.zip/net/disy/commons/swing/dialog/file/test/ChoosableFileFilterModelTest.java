//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.test;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import net.disy.commons.core.testing.ReflectionArgumentMatcher;
import net.disy.commons.swing.dialog.file.ChoosableFileFilterModel;

import org.easymock.MockControl;

// NOT_PUBLISHED
public class ChoosableFileFilterModelTest extends AbstractFileFilterTest {
  private ChoosableFileFilterModel choosableFileFilterModel;
  private MockControl listenerControl;
  private ChangeListener listener;

  protected void setUp() throws Exception {
    super.setUp();
    choosableFileFilterModel = new ChoosableFileFilterModel();
    listenerControl = MockControl.createControl(ChangeListener.class);
    listener = (ChangeListener) listenerControl.getMock();
    listenerControl.setDefaultMatcher(new ReflectionArgumentMatcher());
  }

  public void testEmpty() throws Exception {
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(0, filters.length);
    assertTrue(choosableFileFilterModel.isEmpty());
  }

  public void testAddFileFilter() throws Exception {
    listener.stateChanged(new ChangeEvent(choosableFileFilterModel));
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    FileFilter fileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(fileFilter);
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(1, filters.length);
    assertSame(fileFilter, filters[0]);
    assertFalse(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }

  public void testExceptionOnAddNull() throws Exception {
    try {
      choosableFileFilterModel.addFileFilter(null);
      fail();
    }
    catch (IllegalArgumentException expected) {
      // nothing to do
    }
  }

  public void testAddTwoDifferentFileFilters() throws Exception {
    listener.stateChanged(new ChangeEvent(choosableFileFilterModel));
    listenerControl.setVoidCallable(2);
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    FileFilter fileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(fileFilter);
    FileFilter secondFileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(secondFileFilter);
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(2, filters.length);
    assertSame(fileFilter, filters[0]);
    assertSame(secondFileFilter, filters[1]);
    assertFalse(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }
  
  public void testAddTwoEqualFileFilters() throws Exception {
    listener.stateChanged(new ChangeEvent(choosableFileFilterModel));
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    FileFilter fileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(fileFilter);
    choosableFileFilterModel.addFileFilter(fileFilter);
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(1, filters.length);
    assertSame(fileFilter, filters[0]);
    assertFalse(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }

  public void testClear() throws Exception {
    FileFilter fileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(fileFilter);
    listener.stateChanged(new ChangeEvent(choosableFileFilterModel));
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    choosableFileFilterModel.clear();
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(0, filters.length);
    assertTrue(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }
  
  public void testRemoveContainedFileFilter() throws Exception {
    FileFilter fileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(fileFilter);
    FileFilter secondFileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(secondFileFilter);
    listener.stateChanged(new ChangeEvent(choosableFileFilterModel));
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    choosableFileFilterModel.removeFileFilter(fileFilter);
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(1, filters.length);
    assertSame(secondFileFilter, filters[0]);
    assertFalse(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }
  
  public void testRemoveNotContainedFileFilter() throws Exception {
    FileFilter fileFilter = createDummyFileFilter();
    FileFilter secondFileFilter = createDummyFileFilter();
    choosableFileFilterModel.addFileFilter(secondFileFilter);
    listenerControl.replay();
    choosableFileFilterModel.addChangeListener(listener);
    choosableFileFilterModel.removeFileFilter(fileFilter);
    FileFilter[] filters = choosableFileFilterModel.getFileFilters();
    assertEquals(1, filters.length);
    assertSame(secondFileFilter, filters[0]);
    assertFalse(choosableFileFilterModel.isEmpty());
    listenerControl.verify();
  }
}
