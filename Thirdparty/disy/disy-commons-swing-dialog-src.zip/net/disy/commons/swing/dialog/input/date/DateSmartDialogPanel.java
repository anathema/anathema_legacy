/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.date;

import java.awt.Component;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.swing.AbstractButton;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JFormattedTextField.AbstractFormatter;
import javax.swing.JPanel;

import net.disy.commons.core.date.DateConfiguration;
import net.disy.commons.core.date.IDateConfiguration;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.DateUtilities;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.calendar.CalendarIcons;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogMessages;
import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.icon.CommonIcons;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;
import net.disy.commons.swing.toolbar.ToolBarUtilities;

public class DateSmartDialogPanel extends AbstractLabeledSmartDialogPanel {

  private final ObjectModel<Date> dateModel;
  private final SimpleDateFormat dateFormat;
  private final IDateConfiguration dateConfiguration;
  private AbstractButton editButton;
  private final boolean enableDelete;
  private JFormattedTextField textField;

  public DateSmartDialogPanel(
      final String label,
      final ObjectModel<Date> dateModel,
      final IMessageProducingValidator validator,
      final String pattern,
      final boolean enableDelete) {
    this(label, null, dateModel, validator, pattern, enableDelete);
  }

  public DateSmartDialogPanel(
      final String label,
      String toolTiptext,
      final ObjectModel<Date> dateModel,
      final IMessageProducingValidator validator,
      final String pattern) {
    this(label, toolTiptext, dateModel, validator, pattern, true);
  }

  public DateSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<Date> dateModel,
      final IMessageProducingValidator validator,
      final String pattern,
      final boolean enableDelete) {
    super(label, toolTipText, validator);
    this.enableDelete = enableDelete;
    dateConfiguration = new DateConfiguration(pattern);
    dateFormat = new SimpleDateFormat(dateConfiguration.getFormatPattern());
    this.dateModel = dateModel;
  }

  @Override
  protected JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    final JPanel editPanel = new JPanel(new GridDialogLayout(enableDelete ? 3 : 2, false));
    editPanel.add(createDateTextField(), GridDialogLayoutData.FILL_HORIZONTAL);
    editButton = createEditButton();
    editPanel.add(editButton, GridDialogLayoutDataFactory.createFillNoGrab());
    if (enableDelete) {
      editPanel.add(createDeleteButton());
    }
    panel.add(editPanel, GridDialogLayoutDataFactory.createHorizontalSpanData(
        columnCount,
        GridDialogLayoutData.FILL_HORIZONTAL));
    return editButton;
  }

  private AbstractButton createDeleteButton() {
    final AbstractButton button = ToolBarUtilities.createToolBarButton(new SmartAction(
        DisyCommonsSwingDialogMessages.getString("DateSmartDialogPanel.Tooltip.Delete"), //$NON-NLS-1$
        CommonIcons.DELETE) {
      @Override
      protected void execute(final Component parentComponent) {
        dateModel.setValue(null);
      }
    });
    dateModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        button.setEnabled(dateModel.getValue() != null);
      }
    });
    button.setEnabled(dateModel.getValue() != null);
    return button;
  }

  private AbstractButton createEditButton() {
    return ToolBarUtilities.createToolBarButton(new SmartAction(DisyCommonsSwingDialogMessages
        .getString("DateSmartDialogPanel.Tooltip.Edit"), //$NON-NLS-1$
        CalendarIcons.DATE_ICON) {
      @Override
      protected void execute(final Component parentComponent) {
        final Date date = dateModel.getValue();
        final ObjectModel<Calendar> calendarModel = new ObjectModel<Calendar>();
        calendarModel.setValue(date == null ? new GregorianCalendar() : DateUtilities
            .toCalendar(date));
        final UserDialog userDialog = new UserDialog(parentComponent, new CalendarDialogPage(
            calendarModel,
            dateConfiguration));
        final IDialogResult result = userDialog.show();
        if (result.isCanceled()) {
          return;
        }
        dateModel.setValue(calendarModel.getValue().getTime());
      }
    });
  }

  private JFormattedTextField createDateTextField() {
    textField = new JFormattedTextField(new AbstractFormatter() {
      @Override
      public Object stringToValue(final String text) {
        throw new UnsupportedOperationException("Text field not editable."); //$NON-NLS-1$
      }

      @Override
      public String valueToString(final Object value) {
        if (value == null) {
          return ""; //$NON-NLS-1$
        }
        return dateFormat.format(dateModel.getValue());
      }
    });
    dateModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        textField.setValue(dateModel.getValue());
      }
    });
    textField.setValue(dateModel.getValue());
    textField.setEditable(false);
    return textField;
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    dateModel.addChangeListener(listener);
  }

  @Override
  public void requestFocus() {
    if (editButton != null) {
      editButton.requestFocus();
    }
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    textField.setEnabled(enabled);
    editButton.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ textField, editButton };
  }
}