/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.demo;

import java.lang.reflect.InvocationTargetException;

import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.swing.dialog.progress.AbstractProgressMonitorWizardPage;
import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;

public class DemoWizardProgressMonitorPage extends AbstractProgressMonitorWizardPage {

  private final String doneMessageText;
  private final INonInterruptableRunnableWithProgress runnable;

  public DemoWizardProgressMonitorPage(
      final String description,
      final String title,
      final String runningMessageText,
      final String doneMessageText,
      final IWizardConfiguration wizardConfiguration,
      final INonInterruptableRunnableWithProgress runnable) {
    super(description, title, runningMessageText, wizardConfiguration);
    this.doneMessageText = doneMessageText;
    this.runnable = runnable;
  }

  @Override
  protected void executeWithProgress(final IProgressMonitor monitor)
      throws InvocationTargetException {
    runnable.run(monitor);
  }

  @Override
  protected String getDoneMessageText() {
    return doneMessageText;
  }

  @Override
  public boolean canFinish() {
    return false;
  }
}