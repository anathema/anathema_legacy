/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;

public class LongModelSmartDialogPanel extends IntegralNumberSmartDialogPanel<Long> {

  public LongModelSmartDialogPanel(
      final String label,
      final ObjectModel<Long> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public LongModelSmartDialogPanel(
      final String label,
      final String toolTipText,
      final ObjectModel<Long> model,
      final IMessageProducingValidator validator) {
    super(label, toolTipText, model, validator, new Long(0), Long.valueOf(Long.MIN_VALUE), Long
        .valueOf(Long.MAX_VALUE));
  }

  @Override
  protected Long convertToNumber(final Long value) {
    return value;
  }
}