//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox.demo;

import javax.swing.Icon;

import net.disy.commons.swing.ui.AbstractObjectUi;

// NOT_PUBLISHED
public final class DemoColorItemUi extends AbstractObjectUi<DemoColorItem> {
  @Override
  public Icon getIcon(final DemoColorItem value) {
    if (value == null) {
      return null;
    }
    return new DemoColorIcon(value.getColor());
  }

  @Override
  public String getLabel(final DemoColorItem value) {
    if (value == null) {
      return null;
    }
    return value.getName();
  }
}