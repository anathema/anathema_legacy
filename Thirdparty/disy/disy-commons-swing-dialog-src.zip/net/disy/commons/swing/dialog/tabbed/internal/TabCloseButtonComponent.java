/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed.internal;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.SimpleBlock;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogIconResources;

public final class TabCloseButtonComponent extends JComponent {

  private TabCloseButtonState state = TabCloseButtonState.HIDDEN;
  private final BooleanModel isActiveTabModel;

  public TabCloseButtonComponent(
      final JComponent container,
      final BooleanModel isActiveTabModel,
      final SimpleBlock closeHandlerBlock) {
    Ensure.ensureArgumentNotNull(container);
    Ensure.ensureArgumentNotNull(isActiveTabModel);
    Ensure.ensureArgumentNotNull(closeHandlerBlock);
    this.isActiveTabModel = isActiveTabModel;

    container.addMouseListener(new MouseAdapter() {
      @Override
      public void mouseExited(final MouseEvent e) {
        setState(TabCloseButtonState.HIDDEN);
      }

      @Override
      public void mouseEntered(final MouseEvent e) {
        setState(TabCloseButtonState.INACTIVE);
      }
    });
    addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        if (e.isMetaDown()) {
          return;
        }
        setState(TabCloseButtonState.PRESSED);
      }

      @Override
      public void mouseReleased(final MouseEvent e) {
        if (state == TabCloseButtonState.PRESSED) {
          setState(TabCloseButtonState.ACTIVE);
          closeHandlerBlock.execute();
        }
      }

      @Override
      public void mouseEntered(final MouseEvent e) {
        setState(TabCloseButtonState.ACTIVE);
      }

      @Override
      public void mouseExited(final MouseEvent e) {
        setState(TabCloseButtonState.HIDDEN);
      }
    });
  }

  private void setState(final TabCloseButtonState state) {
    if (this.state == state) {
      return;
    }
    this.state = state;
    repaint();
  }

  @Override
  public Dimension getPreferredSize() {
    return new Dimension(16, 16);
  }

  @Override
  protected void paintComponent(final Graphics g) {
    switch (state) {
      case ACTIVE:
        DisyCommonsSwingDialogIconResources.TAB_CLOSE_ACTIVE.paintIcon(this, g, 0, 0);
        break;
      case INACTIVE:
        DisyCommonsSwingDialogIconResources.TAB_CLOSE_INACTIVE.paintIcon(this, g, 0, 0);
        break;
      case HIDDEN:
        if (isActiveTab()) {
          DisyCommonsSwingDialogIconResources.TAB_CLOSE_INACTIVE.paintIcon(this, g, 0, 0);
        }
        break;
      case PRESSED:
        DisyCommonsSwingDialogIconResources.TAB_CLOSE_ACTIVE.paintIcon(this, g, 1, 1);
        break;
    }
  }

  private boolean isActiveTab() {
    return isActiveTabModel.getValue();
  }
}