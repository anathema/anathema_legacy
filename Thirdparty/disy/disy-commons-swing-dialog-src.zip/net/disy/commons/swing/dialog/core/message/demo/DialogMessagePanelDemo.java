/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core.message.demo;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JPanel;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.core.message.DialogMessageModel;
import net.disy.commons.swing.dialog.core.message.DialogMessagePanel;

import de.jdemo.extensions.SwingDemoCase;

public class DialogMessagePanelDemo extends SwingDemoCase {
  public void demoBaseComponent() throws Exception {
    final DialogMessageModel messageModel = new DialogMessageModel();
    messageModel.setMessage(new BasicMessage("Warning", MessageType.WARNING)); //$NON-NLS-1$
    messageModel.setMessage(new BasicMessage("Information", MessageType.NORMAL)); //$NON-NLS-1$
    show(new DialogMessagePanel(messageModel).getContent());
  }

  public void demoOverlaidComponent() throws Exception {
    final DialogMessageModel messageModel = new DialogMessageModel();
    messageModel.setMessage(new BasicMessage("Information", MessageType.NORMAL)); //$NON-NLS-1$
    messageModel.setMessage(new BasicMessage("Warning", MessageType.WARNING)); //$NON-NLS-1$
    show(new DialogMessagePanel(messageModel).getContent());
  }

  public void demoInteractive() throws Exception {
    final DialogMessageModel messageModel = new DialogMessageModel();
    messageModel.setMessage(new BasicMessage("Information", MessageType.NORMAL)); //$NON-NLS-1$
    final DialogMessagePanel dialogMessagePanel = new DialogMessagePanel(messageModel);
    final JButton button = new JButton(new SmartAction("Toggle") { //$NON-NLS-1$
          private boolean warning = false;

          @Override
          protected void execute(Component parentComponent) {
            warning = !warning;
            if (warning) {
              messageModel.setMessage(new BasicMessage("Warning", MessageType.WARNING)); //$NON-NLS-1$
            }
            else {
              messageModel.setMessage(new BasicMessage("Information", MessageType.NORMAL)); //$NON-NLS-1$
            }
          }
        });
    final JPanel panel = new JPanel(new BorderLayout());
    panel.add(dialogMessagePanel.getContent(), BorderLayout.NORTH);
    panel.add(button, BorderLayout.CENTER);
    show(panel);
  }

}
