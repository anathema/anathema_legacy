/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.labeled;

import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.object.AbstractObjectSmartDialogPanel;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.object.component.IObjectAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.object.component.IObjectInputComponent;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;

public class LabeledValueComboDialogPanel<T> extends AbstractObjectSmartDialogPanel<T> {

  public LabeledValueComboDialogPanel(
      final String label,
      final ObjectModel<T> model,
      final IMessageProducingValidator validator,
      final IAttributeValueListFactory<ILabeledValue> presetValuesFactory,
      final IAttributeContext attributeContext) {
    this(label, null, model, validator, presetValuesFactory, attributeContext);
  }

  public LabeledValueComboDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<T> model,
      final IMessageProducingValidator validator,
      final IAttributeValueListFactory<ILabeledValue> presetValuesFactory,
      final IAttributeContext attributeContext) {
    super(label, toolTipText, model, new IObjectAttributeInputComponentFactory<T, JComboBox>() {

      @Override
      public IObjectInputComponent<T, JComboBox> createComponent() {
        final LabeledValueComboBox<T> labeledValueComboBox = new LabeledValueComboBox<T>(
            presetValuesFactory,
            attributeContext);
        labeledValueComboBox.setValue(model.getValue());
        labeledValueComboBox.addChangeListener(new ChangeListener() {

          @Override
          public void stateChanged(final ChangeEvent event) {
            model.setValue(labeledValueComboBox.getValue());
          }
        });
        return labeledValueComboBox;
      }
    }, validator);
  }
}