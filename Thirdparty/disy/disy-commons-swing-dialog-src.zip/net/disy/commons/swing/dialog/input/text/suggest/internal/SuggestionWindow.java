/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.BorderLayout;
import java.awt.Window;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JComponent;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JWindow;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.ListenerList;
import net.disy.commons.core.text.SuggestionResult;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.core.util.IClosure;
import net.disy.commons.swing.dialog.input.text.suggest.ISuggestionTextFieldConfiguration;
import net.disy.commons.swing.dispose.IDisposable;
import net.disy.commons.swing.layout.cardlayout.CardPanel;
import net.disy.commons.swing.layout.cardlayout.CardPanelKey;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.list.AbstractListMouseHandler;
import net.disy.commons.swing.list.IListMouseHandler;
import net.disy.commons.swing.list.JListMouseListener;
import net.disy.commons.swing.list.TypeSafeListModel;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;
import net.disy.commons.swing.util.EventDispatchThreadUtilities;
import net.disy.commons.swing.util.GuiUtilities;

public class SuggestionWindow<T> implements IDisposable {

  private final static CardPanelKey LIST_COMPONENT_KEY = new CardPanelKey();
  private final static CardPanelKey BUSY_COMPONENT_KEY = new CardPanelKey();
  private final static CardPanelKey NO_RESULTS_COMPONENT_KEY = new CardPanelKey();

  private final FocusAdapter focusLossListener = new FocusAdapter() {
    @Override
    public void focusLost(final FocusEvent e) {
      if (e.isTemporary()) {
        return;
      }
      handleFokusLossInWindowOrTextField();
    }
  };

  private final ListenerList<IBlock> windowDisposeListeners = new ListenerList<IBlock>();
  private final ObjectModel<IMessage> optionalStateMessageModel = new ObjectModel<IMessage>();
  private final JList list = new JList();
  private final CardPanel cardPanel = new CardPanel();
  private final JComponent hookComponent;

  private final ISuggestionTextFieldConfiguration<T> configuration;

  private JWindow window;
  private TypeSafeListModel<T> listModel;
  private boolean busy = false;
  private final SuggestionWindowDisposeListener disposeListener;

  public SuggestionWindow(
      final JComponent hookComponent,
      final JTextField textField,
      final ISuggestionTextFieldConfiguration<T> configuration,
      final IBlock selectionClickCallback) {
    Ensure.ensureArgumentNotNull(hookComponent);
    Ensure.ensureArgumentNotNull(textField);
    Ensure.ensureArgumentNotNull(configuration);
    Ensure.ensureArgumentNotNull(selectionClickCallback);
    disposeListener = new SuggestionWindowDisposeListener(this);
    this.hookComponent = hookComponent;
    this.configuration = configuration;
    list.setCellRenderer(new ObjectUiListCellRenderer(configuration.getObjectUi()));

    final IListMouseHandler listMouseHandler = new AbstractListMouseHandler() {
      @Override
      public void handleClick(final Object[] selectedValues) {
        selectionClickCallback.execute();
      }

      @Override
      public void handleDoubleClick(final Object[] selectedValues) {
        selectionClickCallback.execute();
      }
    };
    JListMouseListener.attachTo(list, listMouseHandler);
    list.addMouseListener(new MouseAdapter() {
      @Override
      public void mousePressed(final MouseEvent e) {
        hookComponent.requestFocus();
      }
    });

    textField.addFocusListener(focusLossListener);
  }

  public void showWithQueryStarted() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    if (window == null) {
      final JScrollPane listScrollPane = new SuggestionWindowScrollPane(list);

      cardPanel.add(createOptionalMessageDecoratedPanel(listScrollPane), LIST_COMPONENT_KEY);
      if (configuration.getBusyLabelText() != null) {
        cardPanel.add(
            new SuggestionWindowBusyComponent(configuration.getBusyLabelText()).getContent(),
            BUSY_COMPONENT_KEY);
      }
      final String noResultLabelText = configuration.getNoResultLabelText();
      if (noResultLabelText != null) {
        cardPanel.add(createOptionalMessageDecoratedPanel(new SuggestionWindowNoResultsComponent(
            noResultLabelText).getContent()), NO_RESULTS_COMPONENT_KEY);
      }
      final Window parentWindow = GuiUtilities.getWindowFor(hookComponent);
      window = new JWindow(parentWindow);
      window.getContentPane().setLayout(new BorderLayout());
      window.getContentPane().add(cardPanel.getContent(), BorderLayout.CENTER);
      window.addFocusListener(focusLossListener);
    }

    if (configuration.getBusyLabelText() != null) {
      cardPanel.show(BUSY_COMPONENT_KEY);
    }
    else {
      cardPanel.show(LIST_COMPONENT_KEY);
    }
    WindowToComponentOnScreenPositioner.packAndAdjustPosition(hookComponent, window);
    window.setVisible(true);
    disposeListener.attachTo(hookComponent);

    this.busy = true;
  }

  private JComponent createOptionalMessageDecoratedPanel(final JComponent component) {
    final JPanel panel = new JPanel(new GridDialogLayout(1, true, 0, 0));
    panel.add(component, GridDialogLayoutData.FILL_BOTH);
    panel.add(
        new OptionalMessageButton(optionalStateMessageModel).getContent(),
        GridDialogLayoutData.FILL_HORIZONTAL);
    return panel;
  }

  protected void handleFokusLossInWindowOrTextField() {
    if (window == null || !window.isVisible()) {
      return;
    }
    if (!hookComponent.hasFocus() && !window.hasFocus()) {
      dispose();
    }
  }

  public void showLoadedSuggestions(final SuggestionResult<T> suggestionResult) {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    listModel = new TypeSafeListModel<T>(suggestionResult.getItems());
    list.setModel(listModel);
    this.busy = false;
    if (suggestionResult.getItems().isEmpty()) {
      if (configuration.getNoResultLabelText() == null) {
        dispose();
        return;
      }
      cardPanel.show(NO_RESULTS_COMPONENT_KEY);
    }
    else {
      cardPanel.show(LIST_COMPONENT_KEY);
    }
    final IMessage stateMessage = suggestionResult.getOptionalStateMessage();
    optionalStateMessageModel.setValue(stateMessage);
    selectFirst();
    WindowToComponentOnScreenPositioner.packAndAdjustPosition(hookComponent, window);
  }

  private void setSelectedIndexAndAssureVisible(final int selectionIndex) {
    list.setSelectedIndex(selectionIndex);
    list.ensureIndexIsVisible(selectionIndex);
  }

  @Override
  public void dispose() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    if (window == null) {
      return;
    }
    disposeListener.detachFrom(hookComponent);
    window.setVisible(false);
    windowDisposeListeners.forAllDo(new IClosure<IBlock>() {
      @Override
      public void execute(final IBlock each) throws RuntimeException {
        each.execute();
      }
    });
  }

  public void moveSelectionUp() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    if (window == null) {
      return;
    }
    final int selectedIndex = list.getSelectedIndex();
    if (selectedIndex < 0) {
      window.getToolkit().beep();
      return;
    }
    if (selectedIndex == 0) {
      selectLast();
      return;
    }
    setSelectedIndexAndAssureVisible(selectedIndex - 1);
  }

  public void selectLast() {
    setSelectedIndexAndAssureVisible(list.getModel().getSize() - 1);
  }

  public void moveSelectionDown() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    if (window == null) {
      return;
    }
    final int selectedIndex = list.getSelectedIndex();
    if (selectedIndex < 0) {
      window.getToolkit().beep();
      return;
    }
    if (selectedIndex >= list.getModel().getSize() - 1) {
      selectFirst();
      return;
    }
    setSelectedIndexAndAssureVisible(selectedIndex + 1);
  }

  public void selectFirst() {
    setSelectedIndexAndAssureVisible(0);
  }

  public T getSelectedItem() {
    EventDispatchThreadUtilities.ensureIsEventDispatchThread();
    if (busy) {
      return null;
    }
    if (window == null) {
      return null;
    }
    final int selectedIndex = list.getSelectedIndex();
    if (selectedIndex == -1) {
      return null;
    }
    final T item = listModel.getElementAt(selectedIndex);
    return item;
  }

  public boolean isVisible() {
    return window != null && window.isVisible();
  }

  public void addWindowDisposeListener(final IBlock listener) {
    windowDisposeListeners.add(listener);
  }

  public void removeWindowDisposeListener(final IBlock listener) {
    windowDisposeListeners.remove(listener);
  }
}