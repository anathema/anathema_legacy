//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.IInputDialogConfiguration;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;

// NOT_PUBLISHED
public interface ISomeOutOfManyDialogConfiguration
    extends
    IInputDialogConfiguration,
    ISomeOutOfManyDialogPanelConfiguration {

  public ISmartDialogPanel[] createAdditionalPanels(FixedOptionsObjectSelectionModel selectionModel);

}