/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.message.demo;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import org.junit.runner.RunWith;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutPage;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class MessageDialogDemo extends SwingDemoCase {

  private final static String LONG_MESSAGE_TEXT = "Beim Schreiben dieses Textes fiel dem Softwareentwickler nicht ein, welcher Fehler denn " //$NON-NLS-1$
      + "tatsächlich aufgetreten ist. Es ist aber ein Fehler aufgetreten."; //$NON-NLS-1$
  private final static String SHORT_MESSAGE_TEXT = "Kurze Meldung."; //$NON-NLS-1$

  public void demoErrorMessageUserDialog() {
    final Message message = new Message("Fehlermeldungstitel", LONG_MESSAGE_TEXT, MessageType.ERROR); //$NON-NLS-1$
    final UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoInfoMessageUserDialog() {
    final Message message = new Message("Fehlermeldungstitel", //$NON-NLS-1$
        SHORT_MESSAGE_TEXT,
        MessageType.INFORMATION);
    final UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoWarningMessageUserDialog() {
    final Message message = new Message(
        "Fehlermeldungstitel", SHORT_MESSAGE_TEXT, MessageType.WARNING); //$NON-NLS-1$
    final UserDialog dialog = MessageDialogFactory.createMessageDialog(createJFrame(), message);
    show(dialog.getDialog().getWindow());
  }

  public void demoFoldOutErrorMessageUserDialog() {
    final Message message = new Message("Fehlermeldungstitel", LONG_MESSAGE_TEXT, MessageType.ERROR); //$NON-NLS-1$
    final IFoldOutPage foldOutPage = new AbstractFoldOutPage() {
      @Override
      protected JComponent createContent() {
        return new JScrollPane(new JTextArea(5, 40));
      }

      @Override
      public void requestFocus() {
        getContent().requestFocus();
      }
    };
    final UserDialog dialog = MessageDialogFactory.createFoldOutMessageDialog(
        createJFrame(),
        message,
        foldOutPage);
    show(dialog.getDialog().getWindow());
  }
}