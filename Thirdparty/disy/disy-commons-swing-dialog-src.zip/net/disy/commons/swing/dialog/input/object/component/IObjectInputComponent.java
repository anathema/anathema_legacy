/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.component;

import javax.swing.JComponent;
import javax.swing.event.ChangeListener;

public interface IObjectInputComponent<O, C extends JComponent> {

  public void addChangeListener(final ChangeListener changeListener);

  public void setValue(final O value);

  public O getValue();

  public C getComponent();

  public void setEditable(final boolean editable);

  public boolean isEditable();

  public void selectAll();

  public void requestFocus();

  public void setEnabled(final boolean enabled);

  public void update();
}