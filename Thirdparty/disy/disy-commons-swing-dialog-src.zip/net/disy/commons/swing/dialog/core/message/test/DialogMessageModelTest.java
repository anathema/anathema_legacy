/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core.message.test;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.swing.dialog.core.message.DialogMessageModel;

public class DialogMessageModelTest extends CoreTestCase {

  private DialogMessageModel model;

  @Override
  protected void setUp() throws Exception {
    model = new DialogMessageModel();
    super.setUp();
  }

  public void testCreate() {
    assertFalse(model.isOverlaidMessageActive());
    assertNull(model.getBaseMessage());
    assertNull(model.getOverlaidMessage());
    assertNull(model.getMessage());
  }

  public void testSetNormalMessage() {
    final BasicMessage normalMessage = new BasicMessage("bla"); //$NON-NLS-1$
    model.setMessage(normalMessage);
    assertFalse(model.isOverlaidMessageActive());
    assertSame(normalMessage, model.getBaseMessage());
    assertNull(model.getOverlaidMessage());
    assertSame(normalMessage, model.getMessage());
  }

  public void testSetErrorMessage() {
    final BasicMessage errorMessage = new BasicMessage("bla", MessageType.ERROR); //$NON-NLS-1$
    model.setMessage(errorMessage);
    assertTrue(model.isOverlaidMessageActive());
    assertSame(errorMessage, model.getOverlaidMessage());
    assertNull(model.getBaseMessage());
    assertSame(errorMessage, model.getMessage());
  }

  public void testSetNormalAndErrorMessage() {
    final BasicMessage normalMessage = new BasicMessage("bla"); //$NON-NLS-1$
    final BasicMessage errorMessage = new BasicMessage("bla", MessageType.ERROR); //$NON-NLS-1$
    model.setMessage(normalMessage);
    model.setMessage(errorMessage);
    assertTrue(model.isOverlaidMessageActive());
    assertSame(errorMessage, model.getOverlaidMessage());
    assertSame(normalMessage, model.getBaseMessage());
    assertSame(errorMessage, model.getMessage());
  }

  public void testSetNormalAndErrorAndNormalMessage() {
    final BasicMessage normalMessage1 = new BasicMessage("bla1"); //$NON-NLS-1$
    final BasicMessage errorMessage = new BasicMessage("bla", MessageType.ERROR); //$NON-NLS-1$
    final BasicMessage normalMessage2 = new BasicMessage("bla2"); //$NON-NLS-1$
    model.setMessage(normalMessage1);
    model.setMessage(errorMessage);
    model.setMessage(normalMessage2);
    assertFalse(model.isOverlaidMessageActive());
    assertSame(errorMessage, model.getOverlaidMessage());
    assertSame(normalMessage2, model.getBaseMessage());
    assertSame(normalMessage2, model.getMessage());
  }
}