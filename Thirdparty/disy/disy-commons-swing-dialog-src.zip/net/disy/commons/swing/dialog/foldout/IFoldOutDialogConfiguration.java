//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;

// NOT_PUBLISHED
public interface IFoldOutDialogConfiguration extends IDialogConfiguration {
  public IFoldOutPage getFoldOutPage();
  
  public String getFoldOutButtonText();

  public String getFoldInButtonText();

  public boolean isInitiallyFoldedOut();
}