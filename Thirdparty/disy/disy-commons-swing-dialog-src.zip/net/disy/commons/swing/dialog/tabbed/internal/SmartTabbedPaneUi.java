/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed.internal;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.KeyboardFocusManager;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.SystemColor;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.JComponent;
import javax.swing.plaf.basic.BasicTabbedPaneUI;

import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.dialog.tabbed.TabPlacement;
import net.disy.commons.swing.util.GuiUtilities;

public class SmartTabbedPaneUi extends BasicTabbedPaneUI {

  private static final String PROPERTY_ACTIVE_WINDOW = "activeWindow"; //$NON-NLS-1$
  private static final String PROPERTY_FOCUS_OWNER = "focusOwner"; //$NON-NLS-1$

  private static final Color TRANSPARENT_COLOR = new Color(0, 0, 0, 0);

  private static Color createWeightedAverageColor(
      final Color color1,
      final int weight1,
      final Color color2,
      final int weight2) {
    final int red = createWeightedAverage(color1.getRed(), weight1, color2.getRed(), weight2);
    final int green = createWeightedAverage(color1.getGreen(), weight1, color2.getGreen(), weight2);
    final int blue = createWeightedAverage(color1.getBlue(), weight1, color2.getBlue(), weight2);
    final int alpha = createWeightedAverage(color1.getAlpha(), weight1, color2.getAlpha(), weight2);
    return new Color(red, green, blue, alpha);
  }

  private static int createWeightedAverage(
      final int value1,
      final int weight1,
      final int value2,
      final int weight2) {
    return (value1 * weight1 + value2 * weight2) / (weight1 + weight2);
  }

  private final HierarchyListener hierarchyListener = new HierarchyListener() {
    @Override
    public void hierarchyChanged(final HierarchyEvent e) {
      updateFocusListenerAttached();
    }
  };

  private final Color darkActiveColor = createWeightedAverageColor(
      SystemColor.activeCaption,
      1,
      SwingColors.getControlColor(),
      2);
  private final Color lightActiveColor = createWeightedAverageColor(
      SystemColor.activeCaption,
      1,
      SwingColors.getControlLtHighlightColor(),
      5);

  private final Color darkInactiveColor = createWeightedAverageColor(
      SystemColor.inactiveCaption,
      2,
      SwingColors.getControlColor(),
      1);
  private final Color lightInactiveColor = createWeightedAverageColor(
      SystemColor.inactiveCaption,
      1,
      SwingColors.getControlColor(),
      3);

  private PropertyChangeListener focusManagerListener;

  @Override
  public void installUI(final JComponent c) {
    super.installUI(c);
    //Use a hierarchy listener to attach/detach the focus listener, in order to avoid memory leaks
    //where this classes are still references by the static KeyboardFocusManager
    c.addHierarchyListener(hierarchyListener);
  }

  @Override
  public void uninstallUI(final JComponent c) {
    c.removeHierarchyListener(hierarchyListener);
    super.uninstallUI(c);
    assureFocusListenerDetached();
  }

  private void updateFocusListenerAttached() {
    if (tabPane != null && tabPane.isDisplayable()) {
      assureFocusListenerAttached();
    }
    else {
      assureFocusListenerDetached();
    }
  }

  private void assureFocusListenerDetached() {
    if (focusManagerListener == null) {
      return;
    }
    final KeyboardFocusManager focusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    focusManager.removePropertyChangeListener(focusManagerListener);
    focusManagerListener = null;
  }

  private void assureFocusListenerAttached() {
    if (focusManagerListener != null) {
      return;//Already/still attached
    }
    focusManagerListener = new PropertyChangeListener() {
      @Override
      public void propertyChange(final PropertyChangeEvent evt) {
        if (PROPERTY_FOCUS_OWNER.equals(evt.getPropertyName())) {
          tabPane.repaint();
          return;
        }
        if (PROPERTY_ACTIVE_WINDOW.equals(evt.getPropertyName())) {
          tabPane.repaint();
          return;
        }
      }
    };
    final KeyboardFocusManager focusManager = KeyboardFocusManager.getCurrentKeyboardFocusManager();
    focusManager.addPropertyChangeListener(focusManagerListener);
  }

  @Override
  protected void paintFocusIndicator(
      final Graphics g,
      final int tabPlacement,
      final Rectangle[] rectangles,
      final int tabIndex,
      final Rectangle iconRect,
      final Rectangle textRect,
      final boolean isSelected) {
    //no focus here
  }

  @Override
  protected int calculateTabHeight(final int tabPlacement, final int tabIndex, final int fontHeight) {
    return super.calculateTabHeight(tabPlacement, tabIndex, fontHeight) + 5;
  }

  @Override
  protected void paintTabBackground(
      final Graphics g,
      final int tabPlacement,
      final int tabIndex,
      final int x,
      final int y,
      final int w,
      final int h,
      final boolean isSelected) {
    if (!isSelected) {
      return;
    }
    final Graphics2D graphics = (Graphics2D) g;
    final TabActiveState state = getTabActiveState((ExtendedJTabbedPane) tabPane, tabIndex);
    switch (state) {
      case ACTIVE:
        paintTabBackground(graphics, x, y, w, h, darkActiveColor, lightActiveColor);
        break;
      case DISABLED:
        paintTabBackground(graphics, x, y, w, h, lightActiveColor, TRANSPARENT_COLOR);
        break;
      case FOCUS_OUTSIDE:
        final Color controlColor = SwingColors.getControlColor();
        paintTabBackground(graphics, x, y, w, h, controlColor, controlColor);
        break;
      case INACTIVE:
        paintTabBackground(graphics, x, y, w, h, darkInactiveColor, lightInactiveColor);
        break;
    }
  }

  private static TabActiveState getTabActiveState(
      final ExtendedJTabbedPane tabPane,
      final int tabIndex) {
    if (!GuiUtilities.isContainedInActiveWindow(tabPane)) {
      return TabActiveState.INACTIVE;
    }
    if (!GuiUtilities.containsFocusOwner(tabPane) && !tabPane.isPopupMenuVisible()) {
      return TabActiveState.FOCUS_OUTSIDE;
    }
    if (tabIndex != -1 && tabPane.isEnabledAt(tabIndex)) {
      return TabActiveState.ACTIVE;
    }
    return TabActiveState.DISABLED;
  }

  private void paintTabBackground(
      final Graphics2D graphics,
      final int x,
      final int y,
      final int w,
      final int h,
      final Color startColor,
      final Color endColor) {
    final TabPlacement placement = ((ExtendedJTabbedPane) tabPane).getTabTitlePlacement();
    final Point startPoint;
    final Point endPoint;
    switch (placement) {
      case BOTTOM:
        endPoint = new Point(x, y + h - 2);
        startPoint = new Point(x, y + 2);
        break;
      case LEFT:
        startPoint = new Point(x + w, y);
        endPoint = new Point(x, y);
        break;
      case RIGHT:
        startPoint = new Point(x, y);
        endPoint = new Point(x + w, y);
        break;
      case TOP:
        startPoint = new Point(x, y + h - 2);
        endPoint = new Point(x, y + 2);
        break;
      default:
        throw new RuntimeException("Unsupported tab placement " + placement); //$NON-NLS-1$
    }
    final GradientPaint gradient = new GradientPaint(startPoint, startColor, endPoint, endColor);
    graphics.setPaint(gradient);
    graphics.fillRect(x, y, w, h);
  }

  @Override
  protected void paintContentBorderTopEdge(
      final Graphics g,
      final int tabPlacement,
      final int selectedIndex,
      final int x,
      final int y,
      final int w,
      final int h) {
    final TabActiveState state = getTabActiveState((ExtendedJTabbedPane) tabPane, tabPane
        .getSelectedIndex());
    Color lightColor = lightHighlight;
    Color color = TRANSPARENT_COLOR;
    switch (state) {
      case ACTIVE:
        color = darkActiveColor;
        lightColor = darkActiveColor.brighter();
        break;
      case DISABLED:
        break;
      case FOCUS_OUTSIDE:
        break;
      case INACTIVE:
        color = darkInactiveColor;
        lightColor = darkInactiveColor.brighter();
        break;
    }
    final Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, calcRect);
    g.setColor(lightColor);

    // Draw unbroken line if tabs are not on TOP, OR
    // selected tab is not in run adjacent to content, OR
    // selected tab is not visible (SCROLL_TAB_LAYOUT)
    //
    if (tabPlacement != TOP
        || selectedIndex < 0
        || (selRect.y + selRect.height + 1 < y)
        || (selRect.x < x || selRect.x > x + w)) {
      g.drawLine(x, y, x + w - 2, y);
    }
    else {
      // Break line to show visual connection to selected tab
      g.drawLine(x, y, selRect.x - 1, y);
      if (selRect.x + selRect.width < x + w - 2) {
        g.drawLine(selRect.x + selRect.width, y, x + w - 2, y);
      }
      else {
        g.setColor(color);
        g.drawLine(x + w - 2, y, x + w - 2, y);
      }
      g.setColor(color);
      g.drawLine(selRect.x, y, selRect.x + selRect.width, y);
    }
    if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
      g.setColor(color);
      g.drawLine(x, y + 1, x + w - 2, y + 1);
      g.drawLine(x, y + 2, x + w - 2, y + 2);
    }
  }

  @Override
  protected void paintContentBorderLeftEdge(
      final Graphics g,
      final int tabPlacement,
      final int selectedIndex,
      final int x,
      final int y,
      final int w,
      final int h) {
    final TabActiveState state = getTabActiveState((ExtendedJTabbedPane) tabPane, tabPane
        .getSelectedIndex());
    Color lightColor = lightHighlight;
    Color color = TRANSPARENT_COLOR;
    switch (state) {
      case ACTIVE:
        lightColor = darkActiveColor.brighter();
        color = darkActiveColor;
        break;
      case DISABLED:
        break;
      case FOCUS_OUTSIDE:
        break;
      case INACTIVE:
        lightColor = darkInactiveColor.brighter();
        color = darkInactiveColor;
        break;
    }
    final Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, calcRect);

    g.setColor(lightColor);

    // Draw unbroken line if tabs are not on LEFT, OR
    // selected tab is not in run adjacent to content, OR
    // selected tab is not visible (SCROLL_TAB_LAYOUT)
    //
    if (tabPlacement != LEFT
        || selectedIndex < 0
        || (selRect.x + selRect.width + 1 < x)
        || (selRect.y < y || selRect.y > y + h)) {
      g.drawLine(x, y, x, y + h - 2);
    }
    else {
      // Break line to show visual connection to selected tab
      g.drawLine(x, y, x, selRect.y - 1);
      if (selRect.y + selRect.height < y + h - 2) {
        g.drawLine(x, selRect.y + selRect.height, x, y + h - 2);
      }
      if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
        g.setColor(color);
        g.drawLine(x, selRect.y + 1, x, selRect.y + selRect.height - 1);
        g.drawLine(x + 1, selRect.y, x + 1, selRect.y + selRect.height);
      }
    }
    if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
      g.setColor(color);
      g.drawLine(x + 1, y + 1, x + 1, y + h - 2);
    }
  }

  @Override
  protected void paintContentBorderBottomEdge(
      final Graphics g,
      final int tabPlacement,
      final int selectedIndex,
      final int x,
      final int y,
      final int w,
      final int h) {
    final TabActiveState state = getTabActiveState((ExtendedJTabbedPane) tabPane, tabPane
        .getSelectedIndex());
    Color color = shadow;
    Color darkerColor = darkShadow;
    switch (state) {
      case ACTIVE:
        darkerColor = darkActiveColor.darker();
        color = darkActiveColor;
        break;
      case DISABLED:
        break;
      case FOCUS_OUTSIDE:
        break;
      case INACTIVE:
        darkerColor = darkInactiveColor.darker();
        color = darkInactiveColor;
        break;
    }

    final Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, calcRect);

    g.setColor(color);
    // Draw unbroken line if tabs are not on BOTTOM, OR
    // selected tab is not in run adjacent to content, OR
    // selected tab is not visible (SCROLL_TAB_LAYOUT)
    //
    if (tabPlacement != BOTTOM
        || selectedIndex < 0
        || (selRect.y - 1 > h)
        || (selRect.x < x || selRect.x > x + w)) {
      if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
        g.drawLine(x + 1, y + h - 3, x + w - 2, y + h - 3);
      }
      g.drawLine(x + 1, y + h - 2, x + w - 2, y + h - 2);
      g.setColor(darkerColor);
      g.drawLine(x, y + h - 1, x + w - 1, y + h - 1);
    }
    else {
      // Break line to show visual connection to selected tab
      g.drawLine(x + 1, y + h - 2, selRect.x - 1, y + h - 2);
      g.setColor(darkerColor);
      g.drawLine(x, y + h - 1, selRect.x - 1, y + h - 1);
      if (selRect.x + selRect.width < x + w - 2) {
        g.setColor(color);
        g.drawLine(selRect.x + selRect.width, y + h - 2, x + w - 2, y + h - 2);
        g.setColor(darkerColor);
        g.drawLine(selRect.x + selRect.width, y + h - 1, x + w - 1, y + h - 1);
      }
      if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
        g.setColor(color);
        g.drawLine(selRect.x, y + h - 1, selRect.x + selRect.width, y + h - 1);
        g.drawLine(selRect.x, y + h - 2, selRect.x + selRect.width, y + h - 2);
      }
    }
  }

  @Override
  protected void paintContentBorderRightEdge(
      final Graphics g,
      final int tabPlacement,
      final int selectedIndex,
      final int x,
      final int y,
      final int w,
      final int h) {
    final TabActiveState state = getTabActiveState((ExtendedJTabbedPane) tabPane, tabPane
        .getSelectedIndex());
    Color color = shadow;
    Color darkerColor = darkShadow;
    switch (state) {
      case ACTIVE:
        darkerColor = darkActiveColor.darker();
        color = darkActiveColor;
        break;
      case DISABLED:
        break;
      case FOCUS_OUTSIDE:
        break;
      case INACTIVE:
        darkerColor = darkInactiveColor.darker();
        color = darkInactiveColor;
        break;
    }

    final Rectangle selRect = selectedIndex < 0 ? null : getTabBounds(selectedIndex, calcRect);

    g.setColor(color);

    // Draw unbroken line if tabs are not on RIGHT, OR
    // selected tab is not in run adjacent to content, OR
    // selected tab is not visible (SCROLL_TAB_LAYOUT)
    //
    if (tabPlacement != RIGHT
        || selectedIndex < 0
        || (selRect.x - 1 > w)
        || (selRect.y < y || selRect.y > y + h)) {
      if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
        g.drawLine(x + w - 3, y + 1, x + w - 3, y + h - 3);
      }
      g.drawLine(x + w - 2, y + 1, x + w - 2, y + h - 3);
      g.setColor(darkerColor);
      g.drawLine(x + w - 1, y, x + w - 1, y + h - 1);
    }
    else {
      // Break line to show visual connection to selected tab
      g.drawLine(x + w - 2, y + 1, x + w - 2, selRect.y - 1);
      g.setColor(darkerColor);
      g.drawLine(x + w - 1, y, x + w - 1, selRect.y - 1);

      if (selRect.y + selRect.height < y + h - 2) {
        g.setColor(color);
        g.drawLine(x + w - 2, selRect.y + selRect.height, x + w - 2, y + h - 2);
        g.setColor(darkerColor);
        g.drawLine(x + w - 1, selRect.y + selRect.height, x + w - 1, y + h - 2);
      }
      if (state == TabActiveState.ACTIVE || state == TabActiveState.INACTIVE) {
        g.setColor(color);
        g.drawLine(x + w - 1, selRect.y, x + w - 1, selRect.y + selRect.height - 1);
        g.drawLine(x + w - 2, selRect.y, x + w - 2, selRect.y + selRect.height);
      }
    }
  }
}