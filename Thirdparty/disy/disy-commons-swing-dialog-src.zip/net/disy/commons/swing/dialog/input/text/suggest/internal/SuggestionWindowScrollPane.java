/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JComponent;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import net.disy.commons.swing.layout.util.LayoutUtilities;

public final class SuggestionWindowScrollPane extends JScrollPane {

  private static final int ASSUMED_SCROLLBAR_SIZE = 18;

  public SuggestionWindowScrollPane(final JComponent content) {
    super(
        content,
        ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
        ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
  }

  @Override
  public final Dimension getMaximumSize() {
    final Dimension screenSize = getToolkit().getScreenSize();
    return new Dimension(screenSize.width / 3, screenSize.height / 3);
  }

  @Override
  public final Dimension getMinimumSize() {
    return new Dimension(LayoutUtilities.getDpiAdjusted(130), LayoutUtilities.getDpiAdjusted(100));
  }

  @Override
  public final Dimension getPreferredSize() {
    final Dimension contentSize = getPreferredContentSizeRespectingDefaultBorder();
    final Dimension maxSize = getMaximumSize();
    if (contentSize.width <= maxSize.width && contentSize.height <= maxSize.height) {
      return adjustToMinimumSize(contentSize);
    }
    if (contentSize.width > maxSize.width && contentSize.height > maxSize.height) {
      return maxSize;
    }
    if (contentSize.width > maxSize.width) {
      final int height = Math.min(maxSize.height, contentSize.height + ASSUMED_SCROLLBAR_SIZE);
      return adjustToMinimumSize(new Dimension(maxSize.width, height));
    }
    final int width = Math.min(maxSize.width, contentSize.width + ASSUMED_SCROLLBAR_SIZE);
    return adjustToMinimumSize(new Dimension(width, maxSize.height));
  }

  private Dimension adjustToMinimumSize(final Dimension size) {
    final Dimension minimumSize = getMinimumSize();
    final int width = Math.max(size.width, minimumSize.width);
    final int height = Math.max(size.height, minimumSize.height);
    return new Dimension(width, height);
  }

  private Dimension getPreferredContentSizeRespectingDefaultBorder() {
    final Component content = getViewport().getView();
    final Dimension preferredSize = content.getPreferredSize();
    return new Dimension(preferredSize.width + 6, preferredSize.height + 6);
  }
}