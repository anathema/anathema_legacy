/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.combo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.list.ImmutableListModel;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.ISelectableItemsPanelConfiguration;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public class ComboSelectionDialogPanel<T> extends AbstractLabeledSmartDialogPanel {

  private final IObjectModel<T> model;
  private final JComboBox comboBox;
  private final IListModel<T> itemsModel;

  public ComboSelectionDialogPanel(
      final String label,
      final IObjectModel<T> model,
      final ISelectableItemsPanelConfiguration<T> configuration,
      final IMessageProducingValidator validator) {
    this(label, null, model, new ImmutableListModel<T>(configuration.getItems()), configuration
        .getObjectUi(), validator);
  }

  public ComboSelectionDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<T> model,
      final ISelectableItemsPanelConfiguration<T> configuration,
      final IMessageProducingValidator validator) {
    this(
        label,
        toolTipText,
        model,
        new ImmutableListModel<T>(configuration.getItems()),
        configuration.getObjectUi(),
        validator);
  }

  public ComboSelectionDialogPanel(
      final String label,
      String tooltipText,
      final IObjectModel<T> model,
      final IListModel<T> itemsModel,
      final IObjectUi<T> objectUi,
      final IMessageProducingValidator validator) {
    super(label, tooltipText, validator);
    this.model = model;
    this.itemsModel = itemsModel;
    comboBox = new JComboBox();
    itemsModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateComboItems();
        model.setValue(null);
      }
    });
    updateComboItems();
    comboBox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateCombo();
      }
    });
    updateCombo();
    comboBox.addActionListener(new ActionListener() {
      @Override
      @SuppressWarnings("unchecked")
      public void actionPerformed(final ActionEvent e) {
        model.setValue((T) comboBox.getSelectedItem());
      }
    });
  }

  public ComboSelectionDialogPanel(
      final String label,
      final IObjectModel<T> model,
      final IListModel<T> itemsModel,
      final IObjectUi<T> objectUi,
      final IMessageProducingValidator validator) {
    this(label, null, model, itemsModel, objectUi, validator);
  }

  private void updateComboItems() {
    comboBox.removeAllItems();
    for (final T item : itemsModel.getItemList()) {
      comboBox.addItem(item);
    }
  }

  private void updateCombo() {
    comboBox.setSelectedItem(model.getValue());
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  protected JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    panel.add(comboBox, GridDialogLayoutDataFactory.createHorizontalFillNoGrab());
    return comboBox;
  }

  @Override
  public final void requestFocus() {
    comboBox.requestFocus();
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    comboBox.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ comboBox };
  }
}