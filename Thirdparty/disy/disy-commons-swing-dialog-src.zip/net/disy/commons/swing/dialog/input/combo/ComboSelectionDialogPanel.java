// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.combo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.IMessageProducingValidator;
import net.disy.commons.swing.dialog.input.ISelectionDialogPanelConfiguration;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

//NOT_PUBLISHED
public class ComboSelectionDialogPanel<T> extends AbstractLabeledSmartDialogPanel {

  private final ObjectModel<T> model;
  private JComboBox comboBox;

  public ComboSelectionDialogPanel(
      final ObjectModel<T> model,
      final ISelectionDialogPanelConfiguration<T> configuration) {
    super(configuration.getDescription(), new IMessageProducingValidator() {
      public IBasicMessage validate() {
        if (model.getValue() == null) {
          return new BasicMessage(
              configuration.getNoItemSelectedErrorMessageText(),
              MessageType.ERROR);
        }
        return null;
      }
    });
    this.model = model;
    comboBox = new JComboBox(configuration.getItems());
    comboBox.setRenderer(new ObjectUiListCellRenderer(configuration.getObjectUi()));
    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateCombo();
      }
    });
    updateCombo();
    comboBox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        model.setValue((T) comboBox.getSelectedItem());
      }
    });
  }

  private void updateCombo() {
    comboBox.setSelectedItem(model.getValue());
  }

  public void addChangeListener(ChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  protected void fillMainComponentInto(JPanel panel, int columnCount) {
    panel.add(comboBox);
  }
}