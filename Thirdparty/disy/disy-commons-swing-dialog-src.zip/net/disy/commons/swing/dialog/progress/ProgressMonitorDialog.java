// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.progress;

import java.awt.Component;
import java.lang.reflect.InvocationTargetException;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.progress.DefaultRunnableExecuter;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.progress.IRunnableContext;
import net.disy.commons.core.progress.IRunnableExecuter;
import net.disy.commons.core.progress.IRunnableWithProgress;
import net.disy.commons.core.util.Ensure;

/**
 * A modal dialog that displays progress during a long running operation.
 * 
 * @see net.disy.commons.core.progress.IRunnableWithProgress
 * @author gebhard
 */
public class ProgressMonitorDialog implements IRunnableContext {

  private boolean first = true;
  private final InternalProgressDialog progressDialog;
  private final InternalProgressDialogModel model;
  private int millisecondsUntilDialogPopup = 500;
  private static IRunnableExecuter defaultExecuter = new DefaultRunnableExecuter("runWithProgress"); //$NON-NLS-1$

  public static void setDeaultExecuter(IRunnableExecuter defaultExecuter) {
    Ensure.ensureArgumentNotNull(defaultExecuter);
    ProgressMonitorDialog.defaultExecuter = defaultExecuter;
  }

  public ProgressMonitorDialog(Component parentComponent, String title) {
    model = new InternalProgressDialogModel();
    progressDialog = new InternalProgressDialog(parentComponent, title, model);
  }

  public void setMillisecondsUntilDialogPopup(int millisecondsUntilDialogPopup) {
    this.millisecondsUntilDialogPopup = millisecondsUntilDialogPopup;
  }

  public void run(boolean cancelable, final IRunnableWithProgress runnable)
      throws InterruptedException,
      InvocationTargetException {
    Ensure.ensureArgumentNotNull(runnable);
    synchronized (this) {
      if (!first) {
        throw new IllegalStateException("Progress monitor dialog can only be run once."); //$NON-NLS-1$
      }
      first = false;
    }
    progressDialog.setCancelable(cancelable);

    final Runnable actualRunnable = new Runnable() {
      public void run() {
        try {
          runnable.run(progressDialog);
        }
        catch (InterruptedException e) {
          model.interrupted(e);
        }
        catch (InvocationTargetException e) {
          model.crashed(e);
        }
        catch (RuntimeException e) {
          model.crashed(e);
        }
        catch (Error e) {
          model.crashed(e);
        }
        catch (Throwable e) {
          model.crashed(new InvocationTargetException(e));
        }
        finally {
          synchronized (model) {
            model.finished();
            model.notifyAll();
          }
          progressDialog.dispose();
        }
      }
    };
    defaultExecuter.execute(actualRunnable);

    synchronized (model) {
      if (!model.isFinished()) {
        model.wait(millisecondsUntilDialogPopup);
      }
    }
    if (!model.isFinished()) {
      progressDialog.show();
    }
    
    model.throwThrowableIfAny();
  }

  /** Convenience method for showing a progress monitor dialog while executing a runnable
   * without reporting detailed progress information.
   * This method should only be called on the event dispatch thread.
   * @see #run(boolean, IRunnableWithProgress)
   * @deprecated As of 10.06.2005 (gebhard) Exceptions shall not be reported as Dialog inside the
   * Runnable. They also can not be thrown through the Runnable - so use the non cenvenience way of
   * instantiating the progress monitor.
   */
  public static void runNonInterruptableWithUnknownProgress(
      Component parentComponent,
      String title,
      final String taskName,
      final Runnable runnable) {
    Ensure.ensureArgumentNotNull(runnable);
    ProgressMonitorDialog progressMonitorDialog = new ProgressMonitorDialog(parentComponent, title);
    try {
      progressMonitorDialog.run(false, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) {
          monitor.beginTask(taskName, IProgressMonitor.UNKNOWN);
          runnable.run();
        }
      });
    }
    catch (InterruptedException e1) {
      throw new UnreachableCodeReachedException(e1);
    }
    catch (InvocationTargetException e1) {
      throw new RuntimeException(e1);
    }
  }
}