/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import java.util.List;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

//TODO 14.06.2011 (gebhard): Duplicated in SmartListSelectionDialogPage
public class ListSelectionDialogPage<T> extends SmartDialogPage {
  private final IListSelectionDialogConfiguration<T> configuration;
  private final ListSelectionDialogPanel<T> selectionPanel;

  public ListSelectionDialogPage(final IListSelectionDialogConfiguration<T> configuration) {
    super(configuration.getDefaultMessageText());
    this.configuration = configuration;
    final T[] items = configuration.getItems();
    final FixedOptionsObjectSelectionModel<T> selectionModel = new FixedOptionsObjectSelectionModel<T>(
        items);
    final T selectedItem = configuration.getInitiallySelectedItem();
    if (selectedItem != null) {
      selectionModel.setSelectedValue(selectedItem);
    }
    selectionPanel = new ListSelectionDialogPanel<T>(selectionModel, configuration);
  }

  public List<T> getSelectedItems() {
    return selectionPanel.getSelectedItems();
  }

  @Override
  public String getTitle() {
    return configuration.getTitle();
  }

  @Override
  public String getDescription() {
    return configuration.getDescription();
  }

  @Override
  protected void addPanels(final ISmartDialogPanelsBuilder builder) {
    builder.add(selectionPanel);
    final ISmartDialogPanel[] additionalPanels = configuration
        .createAdditionalPanels(selectionPanel.getSelectedItemModel());
    if (additionalPanels != null) {
      builder.add(additionalPanels);
    }
  }

  @Override
  public void requestFocus() {
    selectionPanel.requestFocus();
  }
}