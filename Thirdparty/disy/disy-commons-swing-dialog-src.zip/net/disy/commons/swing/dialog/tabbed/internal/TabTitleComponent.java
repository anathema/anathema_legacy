/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed.internal;

import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.SystemColor;
import java.awt.event.MouseListener;

import javax.swing.Icon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.SimpleBlock;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogMessages;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.util.GuiUtilities;

public final class TabTitleComponent extends JPanel {

  private final BooleanModel isActiveTabModel = new BooleanModel();
  private final JLabel label;

  public TabTitleComponent(
      final String title,
      final Icon icon,
      final ITabCloseRequestHandler optionalCloseHandler) {
    super(new BorderLayout(LayoutUtilities.getDpiAdjusted(3), 0));
    Ensure.ensureArgumentNotNull(isActiveTabModel);

    label = new JLabel(icon, SwingConstants.LEFT) {
      @Override
      protected void paintComponent(final Graphics g) {
        if (GuiUtilities.isContainedInActiveWindow(this) || !isActiveTabModel.getValue()) {
          setForeground(SwingColors.getLabelForegroundColor());
        }
        else {
          setForeground(SystemColor.inactiveCaptionText);
        }
        super.paintComponent(g);
      }
    };
    setText(title);
    add(label, BorderLayout.CENTER);
    if (optionalCloseHandler != null) {
      final TabCloseButtonComponent closeButton = new TabCloseButtonComponent(
          this,
          isActiveTabModel,
          new SimpleBlock() {
            @Override
            public void execute() throws RuntimeException {
              optionalCloseHandler.handleCloseRequested(TabTitleComponent.this);
            }
          });
      closeButton.setToolTipText(DisyCommonsSwingDialogMessages.CLOSE);
      add(closeButton, BorderLayout.EAST);
    }
    setOpaque(false);
  }

  public void setIsActiveTab(final boolean active) {
    isActiveTabModel.setValue(active);
  }

  public void setIcon(final Icon icon) {
    label.setIcon(icon);
  }

  public void setText(final String text) {
    label.setText(text);
    label.setToolTipText(StringUtilities.isNullOrTrimmedEmpty(text) ? null : text);
  }

  @Override
  public synchronized void addMouseListener(final MouseListener l) {
    super.addMouseListener(l);
    label.addMouseListener(l);
  }

  @Override
  public synchronized void removeMouseListener(final MouseListener l) {
    super.removeMouseListener(l);
    label.removeMouseListener(l);
  }
}