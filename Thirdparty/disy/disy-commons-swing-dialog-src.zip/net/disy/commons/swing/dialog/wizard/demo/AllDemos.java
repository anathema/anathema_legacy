//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for de.disy.lib.gui.wizard.wizard.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(WizardDemo.class));
    //$JDemo-END$
    return suite;
  }
}
