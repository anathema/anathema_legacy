/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed.demo;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTabbedPane;

import net.disy.commons.swing.dialog.tabbed.ISmartTabbedPaneCloseHandler;
import net.disy.commons.swing.dialog.tabbed.ISmartTabbedPanePopupMenuFactory;
import net.disy.commons.swing.dialog.tabbed.SimpleTabbedPaneCloseHandler;
import net.disy.commons.swing.dialog.tabbed.SmartTabbedPane;
import net.disy.commons.swing.dialog.tabbed.TabPlacement;
import net.disy.commons.swing.message.MessageTypeUi;

import org.junit.runner.RunWith;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class SmartTabbedPaneDemo extends SwingDemoCase {

  public void demoSmartTabbedPane() {
    final SmartTabbedPane tabbedPane = createTabPane();
    show(tabbedPane.getContent());
  }

  public void demoSmartTabbedPaneWithoutClose() {
    final SmartTabbedPane tabbedPane = createTabPane(TabPlacement.TOP, null);
    show(tabbedPane.getContent());
  }

  public void demoSmartTabbedPaneWithoutCloseAndIcons() {
    final SmartTabbedPane tabbedPane = createTabPane(TabPlacement.TOP, null, false);
    show(tabbedPane.getContent());
  }

  public void demoTwoSmartTabbedPanes() {
    final SmartTabbedPane tabbedPane1 = createTabPane();
    final SmartTabbedPane tabbedPane2 = createTabPane();
    final JPanel panel = new JPanel(new GridLayout(0, 1));
    panel.add(tabbedPane1.getContent());
    panel.add(tabbedPane2.getContent());
    show(panel);
  }

  public void demoSmartTabbedPanesWithDifferentTabPlacement() {
    final SmartTabbedPane tabbedPane1 = createTabPane(TabPlacement.TOP);
    final SmartTabbedPane tabbedPane2 = createTabPane(TabPlacement.LEFT);
    final SmartTabbedPane tabbedPane3 = createTabPane(TabPlacement.BOTTOM);
    final SmartTabbedPane tabbedPane4 = createTabPane(TabPlacement.RIGHT);
    final JPanel panel = new JPanel(new GridLayout(0, 1, 4, 4));
    panel.add(tabbedPane1.getContent());
    panel.add(tabbedPane2.getContent());
    panel.add(tabbedPane3.getContent());
    panel.add(tabbedPane4.getContent());
    show(panel);
  }

  private SmartTabbedPane createTabPane() {
    return createTabPane(TabPlacement.TOP);
  }

  private SmartTabbedPane createTabPane(final TabPlacement placement) {
    return createTabPane(placement, new SimpleTabbedPaneCloseHandler());
  }

  private SmartTabbedPane createTabPane(
      final TabPlacement placement,
      final ISmartTabbedPaneCloseHandler closeHandler) {
    return createTabPane(placement, closeHandler, true);
  }

  private SmartTabbedPane createTabPane(
      final TabPlacement placement,
      final ISmartTabbedPaneCloseHandler closeHandler,
      boolean showIcons) {
    final SmartTabbedPane tabbedPane = new SmartTabbedPane(placement, closeHandler);
    if (showIcons) {
      addTabContents(tabbedPane);
    }
    else {
      addTabContentsNoIcons(tabbedPane);
    }

    tabbedPane.setPopupMenuFactory(new ISmartTabbedPanePopupMenuFactory() {
      @Override
      public JPopupMenu createPopupMenu(final int tabIndex) {
        final JPopupMenu popupMenu = new JPopupMenu();
        final JMenuItem removeItem = new JMenuItem("Remove this tab"); //$NON-NLS-1$
        removeItem.addActionListener(new ActionListener() {
          @Override
          public void actionPerformed(final ActionEvent e) {
            tabbedPane.removeTab(tabIndex);
          }
        });
        popupMenu.add(removeItem);
        return popupMenu;
      }
    });
    return tabbedPane;
  }

  private void addTabContents(final SmartTabbedPane tabbedPane) {
    tabbedPane.addTab("Tab 1", MessageTypeUi.warningIcon, createDemoContent(1)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 2", MessageTypeUi.infoIcon, createDemoContent(2)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 3", MessageTypeUi.errorIcon, createDemoContent(3)); //$NON-NLS-1$
  }

  private void addTabContentsNoIcons(final SmartTabbedPane tabbedPane) {
    tabbedPane.addTab("Tab 1", null, createDemoContent(1)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 2", null, createDemoContent(2)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 3", null, createDemoContent(3)); //$NON-NLS-1$
  }

  public void demoOrdinaryTabbedPane() {
    final JTabbedPane tabbedPane = new JTabbedPane();
    tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
    addTabContents(tabbedPane);
    show(tabbedPane);
  }

  public void demoEmptyTabbedPane() {
    final JTabbedPane tabbedPane = new JTabbedPane();
    tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
    show(tabbedPane);
  }

  private void addTabContents(final JTabbedPane tabbedPane) {
    tabbedPane.addTab("Tab 1", MessageTypeUi.warningIcon, createDemoContent(1)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 2", MessageTypeUi.infoIcon, createDemoContent(2)); //$NON-NLS-1$
    tabbedPane.addTab("Tab 3", MessageTypeUi.errorIcon, createDemoContent(3)); //$NON-NLS-1$
  }

  private JPanel createDemoContent(final int value) {
    final JButton button = new JButton("This is Tab " + value); //$NON-NLS-1$
    final JPanel panel = new JPanel();
    panel.add(button);
    return panel;
  }
}