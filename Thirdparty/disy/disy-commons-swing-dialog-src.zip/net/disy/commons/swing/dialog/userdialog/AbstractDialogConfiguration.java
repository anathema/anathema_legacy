package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.Icon;
import javax.swing.JComponent;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

/**
 * @author gebhard
 */
public abstract class AbstractDialogConfiguration implements IDialogConfiguration {
  private IUserDialogContainer dialogContainer;
  private boolean modal = true;
  private final IDialogPage dialogPage;
  private final IDialogButtonConfiguration buttonConfiguration;

  public AbstractDialogConfiguration(IDialogPage dialogPage) {
    this(dialogPage, DialogButtonConfigurationFactory.createBoth());
  }

  public AbstractDialogConfiguration(
      IDialogPage dialogPage,
      IDialogButtonConfiguration buttonConfiguration) {
    Ensure.ensureArgumentNotNull(dialogPage);
    Ensure.ensureArgumentNotNull(buttonConfiguration);
    this.dialogPage = dialogPage;
    this.buttonConfiguration = buttonConfiguration;
  }

  //@Overrides
  public IDialogPage getDialogPage() {
    return dialogPage;
  }

  //@Overrides
  public void setUserDialogContainer(IUserDialogContainer dialogContainer) {
    this.dialogContainer = dialogContainer;
    dialogPage.setContainer(dialogContainer);
  }

  protected IUserDialogContainer getDialogContainer() {
    return dialogContainer;
  }

  //@Overrides
  public JComponent[] createAdditionalButtons() {
    return new JComponent[0];
  }

  protected void setModal(boolean modal) {
    this.modal = modal;
  }

  //@Overrides
  public boolean isModal() {
    return modal;
  }

  //@Overrides
  public boolean performOk(Component parentComponent) {
    return true;
  }

  //@Overrides
  public boolean performCancel(Component parentComponent) {
    return true;
  }

  //@Overrides
  public boolean isHeaderPanelVisible() {
    return true;
  }

  //@Overrides
  public IDialogButtonConfiguration getButtonConfiguration() {
    return buttonConfiguration;
  }

  //@Overrides
  public final Dimension getDialogSize() {
    throw new UnsupportedOperationException();
  }

  //@Overrides
  public void performAfterDispose(boolean canceled) {
    //nothing to do
  }
  
  public Icon getLargeDialogIcon() {
    return null;
  }
}