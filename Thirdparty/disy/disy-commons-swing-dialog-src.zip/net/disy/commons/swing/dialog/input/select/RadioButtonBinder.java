/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import java.awt.Component;

import javax.swing.ButtonGroup;
import javax.swing.JRadioButton;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.ui.IObjectUi;

public class RadioButtonBinder<T> {

  private final JRadioButton[] radioButtons;

  public RadioButtonBinder(final T[] values, final ObjectModel<T> model, final IObjectUi<T> objectUi) {
    Ensure.ensureArgumentNotNull(values);
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(objectUi);

    final ButtonGroup group = new ButtonGroup();
    radioButtons = new JRadioButton[values.length];
    for (int i = 0; i < radioButtons.length; ++i) {
      final T currentValue = values[i];
      final String label = objectUi.getLabel(currentValue);
      radioButtons[i] = new JRadioButton(new SmartAction(label) {
        @Override
        protected void execute(final Component parentComponent) {
          model.setValue(currentValue);
        }
      });
      radioButtons[i].setSelected(currentValue == model.getValue());
      group.add(radioButtons[i]);
    }
    model.addChangeListener(new IChangeListener() {

      @Override
      public void stateChanged() {
        for (int i = 0; i < values.length; ++i) {
          if (values[i].equals(model.getValue())) {
            radioButtons[i].setSelected(true);
            return;
          }
        }
      }
    });
  }

  public JRadioButton[] getRadioButtons() {
    return radioButtons;
  }

}
