/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.swing.list.ListSelectionMode;

public abstract class AbstractListSelectionDialogPanelConfiguration<T>
    implements
    IListSelectionDialogPanelConfiguration<T> {

  @Override
  public T getInitiallySelectedItem() {
    final T[] items = getItems();
    if (items.length > 0) {
      return items[0];
    }
    return null;
  }

  @Override
  public ListSelectionMode getListSelectionMode() {
    return ListSelectionMode.SINGLE_SELECTION;
  }
}