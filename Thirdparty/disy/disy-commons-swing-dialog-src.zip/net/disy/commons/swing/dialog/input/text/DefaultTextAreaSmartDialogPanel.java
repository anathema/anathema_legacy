/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import javax.swing.JScrollPane;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.swing.dialog.input.text.component.GeneralTextAreaAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.IStringAttributeInputComponentFactory;

public class DefaultTextAreaSmartDialogPanel extends AbstractTextSmartDialogPanel {

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      int rows) {
    this(label, null, stringModel, validator, true, rows);
  }

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      boolean grabSpace,
      int rows) {
    this(label, null, stringModel, validator, grabSpace, rows);
  }

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      boolean grabSpace,
      int rows) {
    this(
        label,
        toolTipText,
        stringModel,
        new GeneralTextAreaAttributeInputComponentFactory(rows),
        validator,
        grabSpace);
  }

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory<JScrollPane> factory,
      final IMessageProducingValidator validator) {
    this(label, null, stringModel, factory, validator);
  }

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory<JScrollPane> factory,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, stringModel, factory, validator, true);
  }

  public DefaultTextAreaSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory<JScrollPane> factory,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    super(label, toolTipText, stringModel, factory, validator, grabSpace);
  }

}