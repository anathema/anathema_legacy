/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;

public class IntegerModelSmartDialogPanel extends IntegralNumberSmartDialogPanel<Integer> {

  public IntegerModelSmartDialogPanel(
      final String label,
      final String toolTipText,
      final ObjectModel<Integer> model,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, model, validator, new Integer(0), Integer.MIN_VALUE, Integer.MAX_VALUE);
  }

  public IntegerModelSmartDialogPanel(
      final String label,
      final ObjectModel<Integer> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public IntegerModelSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<Integer> model,
      final IMessageProducingValidator validator,
      final int nullValue,
      final int minValue,
      final int maxValue) {
    super(label, toolTipText, model, validator, nullValue, Integer.valueOf(minValue), Integer
        .valueOf(maxValue));
  }

  @Override
  protected Integer convertToNumber(final Long value) {
    return Integer.valueOf(value.intValue());
  }
}