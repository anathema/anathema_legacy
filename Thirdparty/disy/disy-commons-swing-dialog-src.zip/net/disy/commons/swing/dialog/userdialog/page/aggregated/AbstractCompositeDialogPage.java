/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import net.disy.commons.core.message.HighestPriorityMessageBuilder;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.userdialog.page.IBasicDialogPage;

public abstract class AbstractCompositeDialogPage extends AbstractAggregationDialogPage {

  public AbstractCompositeDialogPage(final String title) {
    super(title);
  }

  @Override
  public final IBasicMessage createCurrentMessage() {
    class CurrentMessageClosure implements IPageClosure {
      HighestPriorityMessageBuilder messageBuilder = new HighestPriorityMessageBuilder();

      public CurrentMessageClosure() {
        messageBuilder.addMessage(getDefaultCurrentMessage());
      }

      @Override
      public void execute(final IBasicDialogPage page) {
        messageBuilder.addMessage(page.createCurrentMessage());
      }
    }
    final CurrentMessageClosure closure = new CurrentMessageClosure();
    forAllPages(closure);
    return closure.messageBuilder.getHighestPriorityMessage();
  }

  protected abstract IBasicMessage getDefaultCurrentMessage();
}