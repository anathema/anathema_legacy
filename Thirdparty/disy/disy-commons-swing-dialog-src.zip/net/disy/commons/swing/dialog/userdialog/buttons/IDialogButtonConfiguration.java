// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.05.2005
package net.disy.commons.swing.dialog.userdialog.buttons;

import net.disy.commons.swing.action.IActionConfiguration;

// NOT_PUBLISHED
public interface IDialogButtonConfiguration {

  /** @deprecated As of 20.01.2006 (gebhard), replaced by {@link #getOkActionConfiguration()} */
  @Deprecated
  public boolean isOkayButtonAvailable();

  /** @deprecated As of 20.01.2006 (gebhard), replaced by {@link #getCancelActionConfiguration()} */
  @Deprecated
  public boolean isCancelButtonAvailable();

  /** @deprecated As of 20.01.2006 (gebhard), replaced by {@link #getOkActionConfiguration()} */
  @Deprecated
  public String getOkayButtonText();

  /** @deprecated As of 20.01.2006 (gebhard), replaced by {@link #getCancelActionConfiguration()} */
  @Deprecated
  public String getCancelButtonText();

  /** @return Action configuration object for the ok button or <code>null</code> if there shall not be an 
   * ok button available. */
  public IActionConfiguration getOkActionConfiguration();

  /** @return Action configuration object for the cancel button or <code>null</code> if there shall not be an 
   * ok button available. */
  public IActionConfiguration getCancelActionConfiguration();
}