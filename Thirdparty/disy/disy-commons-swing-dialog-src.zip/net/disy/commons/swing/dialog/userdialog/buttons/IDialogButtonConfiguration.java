// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.05.2005
package net.disy.commons.swing.dialog.userdialog.buttons;

// NOT_PUBLISHED
public interface IDialogButtonConfiguration {

  public boolean isOkayButtonAvailable();

  public boolean isCancelButtonAvailable();

  public String getOkayButtonText();

  public String getCancelButtonText();
}