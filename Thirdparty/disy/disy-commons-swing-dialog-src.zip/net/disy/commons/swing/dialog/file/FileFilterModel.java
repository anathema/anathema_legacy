//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import javax.swing.filechooser.FileFilter;

import net.disy.commons.core.model.AbstractChangeableModel;
import net.disy.commons.core.util.ObjectUtilities;

// NOT_PUBLISHED
public class FileFilterModel extends AbstractChangeableModel {
  private FileFilter fileFilter;

  public FileFilter getFileFilter() {
    return fileFilter;
  }

  public void setFileFilter(FileFilter fileFilter) {
    if (ObjectUtilities.equals(fileFilter, this.fileFilter)) {
      return;
    }
    this.fileFilter = fileFilter;
    fireChangeEvent();
  }
}
