/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.combo.demo;

import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.SmartDialogPage;
import net.disy.commons.swing.dialog.userdialog.demo.DialogPageDemoCase;

public abstract class DialogDemoCase extends DialogPageDemoCase {

  protected void show(final ISmartDialogPanel... dialogPanels) {
    final SmartDialogPage dialogPage = new SmartDialogPage("Demo") { //$NON-NLS-1$
      @Override
      public String getTitle() {
        return "Demo"; //$NON-NLS-1$
      }

      @Override
      protected void addPanels(final ISmartDialogPanelsBuilder builder) {
        for (final ISmartDialogPanel dialogPanel : dialogPanels) {
          builder.add(dialogPanel);
        }
      }
    };
    show(dialogPage);
  }
}