// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.combo.demo;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.SmartDialogPage;
import net.disy.commons.swing.dialog.userdialog.demo.AbstractDialogDemo;

//NOT_PUBLISHED
public abstract class DialogDemoCase extends AbstractDialogDemo {

  protected void show(final ISmartDialogPanel dialogPanel) {
    SmartDialogPage dialogPage = new SmartDialogPage(new BasicMessage("Demo")) { //$NON-NLS-1$
      public String getTitle() {
        return "Demo"; //$NON-NLS-1$
      }

      @Override
      protected ISmartDialogPanel[] createPanels() {
        return new ISmartDialogPanel[]{ dialogPanel };
      }
    };

    show(dialogPage);
  }
}
