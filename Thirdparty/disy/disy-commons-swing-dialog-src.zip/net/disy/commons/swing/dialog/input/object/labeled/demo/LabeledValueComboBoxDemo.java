/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.labeled.demo;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.exception.ConfigurationException;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.object.labeled.ILabeledValue;
import net.disy.commons.swing.dialog.input.object.labeled.LabeledValue;
import net.disy.commons.swing.dialog.input.object.labeled.LabeledValueComboBox;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.util.GuiUtilities;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class LabeledValueComboBoxDemo extends SwingDemoCase {

  @Demo
  public void demo() {
    final LabeledValueComboBox<String> comboBox = new LabeledValueComboBox<String>(
        new IAttributeValueListFactory<ILabeledValue>() {

          @Override
          public List<ILabeledValue> createList(final IAttributeContext attributeContext)
              throws ConfigurationException {
            return createValues();
          }

          private List<ILabeledValue> createValues() {
            return Arrays.asList(new ILabeledValue[]{ new LabeledValue("Label1", "VALUE1"), //$NON-NLS-1$//$NON-NLS-2$
                new LabeledValue("Label2", "VALUE2"), //$NON-NLS-1$ //$NON-NLS-2$
                new LabeledValue("Label3", "VALUE3") }); //$NON-NLS-1$//$NON-NLS-2$
          }

        },
        new IAttributeContext() {

          @Override
          public Object getCurrentValueOf(final String attributeName) {
            return null;
          }

          @Override
          public Collection<String> getAttributeNames() {
            return null;
          }
        });
    show(comboBox);
  }

  private void show(final LabeledValueComboBox comboBox) {
    final JLabel valueLabel = new JLabel(getValueAsString(comboBox.getValue()));
    final JComboBox component = comboBox.getComponent();
    component.addActionListener(new ActionListener() {

      @Override
      public void actionPerformed(final ActionEvent e) {
        GuiUtilities.invokeLaterIfNecessary(new Runnable() {

          @Override
          public void run() {
            valueLabel.setText(getValueAsString(comboBox.getValue()));
          }
        });
      }
    });
    final JPanel panel = new JPanel(new GridLayout(2, 1));
    panel.add(component);
    panel.add(valueLabel);
    show(panel);
  }

  private String getValueAsString(final Object object) {
    return object == null ? "NULL" : object.toString(); //$NON-NLS-1$
  }
}
