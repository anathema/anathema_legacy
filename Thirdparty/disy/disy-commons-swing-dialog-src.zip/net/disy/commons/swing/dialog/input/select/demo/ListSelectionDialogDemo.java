/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select.demo;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.select.ListSelectionDialogPage;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.list.ListSelectionMode;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class ListSelectionDialogDemo extends AbstractSelectionDialogDemo {

  @Demo
  public void demoSimpleSmartOneOutOfManySelectionDialog() {
    final DemoListSelectionDialogConfiguration configuration = new DemoListSelectionDialogConfiguration();
    showDialogFor(configuration);
  }

  @Demo
  public void demoSmartOneOutOfManySelectionDialogWithAdditionalPanels() {
    final DemoListSelectionDialogConfiguration configuration = new DemoListSelectionDialogConfiguration() {
      @Override
      public ISmartDialogPanel[] createAdditionalPanels(
          final FixedOptionsObjectSelectionModel<DemoColorItem> selectionModel) {
        return createAdditionalDemoPanels(selectionModel);
      }
    };
    showDialogFor(configuration);
  }

  @Demo
  public void demoSimpleSmartSomeOutOfManySelectionDialog() {
    final DemoListSelectionDialogConfiguration configuration = new DemoListSelectionDialogConfiguration() {
      @Override
      public ListSelectionMode getListSelectionMode() {
        return ListSelectionMode.MULTIPLE_INTERVAL_SELECTION;
      }
    };
    showDialogFor(configuration);
  }

  @Demo
  public void demoSmartSomeOutOfManySelectionDialogWithAdditionalPanels() {
    final DemoListSelectionDialogConfiguration configuration = new DemoListSelectionDialogConfiguration() {
      @Override
      public ISmartDialogPanel[] createAdditionalPanels(
          final FixedOptionsObjectSelectionModel<DemoColorItem> selectionModel) {
        return createAdditionalDemoPanels(selectionModel);
      }

      @Override
      public ListSelectionMode getListSelectionMode() {
        return ListSelectionMode.MULTIPLE_INTERVAL_SELECTION;
      }
    };
    showDialogFor(configuration);
  }

  private void showDialogFor(final DemoListSelectionDialogConfiguration configuration) {
    final ListSelectionDialogPage<DemoColorItem> page = new ListSelectionDialogPage<DemoColorItem>(
        configuration);
    show(page);
  }
}