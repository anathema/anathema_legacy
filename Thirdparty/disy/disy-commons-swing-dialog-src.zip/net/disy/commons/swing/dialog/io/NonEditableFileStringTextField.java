/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.io;

import java.awt.Font;
import java.awt.Insets;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;

import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import net.disy.commons.core.io.FileDisplayNameUtilities;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;

public class NonEditableFileStringTextField {

  private final ObjectModel<String> fileNameModel;
  private final JTextField textField;

  public NonEditableFileStringTextField(final ObjectModel<String> fileNameModel) {
    Ensure.ensureArgumentNotNull(fileNameModel);
    textField = new JTextField(20);
    textField.setEditable(false);
    this.fileNameModel = fileNameModel;
    fileNameModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateFileName();
      }
    });
    //Provide more or fewer file name characters if text field is resized 
    textField.addComponentListener(new ComponentAdapter() {
      @Override
      public void componentResized(final ComponentEvent e) {
        updateFileName();
      }
    });
    updateFileName();
  }

  private void updateFileName() {
    final String fileName = fileNameModel.getValue();
    SwingUtilities.invokeLater(new Runnable() {
      @Override
      public void run() {
        if (fileName == null) {
          textField.setText(""); //$NON-NLS-1$
          textField.setToolTipText(null);
          return;
        }
        textField.setToolTipText(fileName);
        int length = 10;
        while (length + 1 <= fileName.length()
            && fitsLengthInTextField(textField, FileDisplayNameUtilities.createShortenedFileName(
                fileName,
                length + 1))) {
          ++length;
        }
        final String shortenedFileName = FileDisplayNameUtilities.createShortenedFileName(
            fileName,
            length);
        textField.setText(shortenedFileName);
      }
    });
  }

  private static boolean fitsLengthInTextField(final JTextField textField, final String text) {
    int availableWidth = textField.getBounds().width;
    final Insets borderInsets = textField.getBorder().getBorderInsets(textField);
    availableWidth -= borderInsets.left;
    availableWidth -= borderInsets.right;

    final Font font = textField.getFont();
    final int stringWidth = textField.getFontMetrics(font).stringWidth(text);
    return stringWidth <= availableWidth;
  }

  public JComponent getContent() {
    return textField;
  }

  public void setEnabled(final boolean enabled) {
    textField.setEnabled(enabled);
  }
}