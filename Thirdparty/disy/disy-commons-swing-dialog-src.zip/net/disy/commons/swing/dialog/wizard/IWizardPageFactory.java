// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;


//NOT_PUBLISHED
public interface IWizardPageFactory {

  IWizardPage createPage(IWizardConfiguration configuration);

}
