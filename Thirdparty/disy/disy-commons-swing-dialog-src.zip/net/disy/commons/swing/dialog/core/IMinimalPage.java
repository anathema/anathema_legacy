//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import javax.swing.JComponent;

// NOT_PUBLISHED
public interface IMinimalPage {
  /**
   * Returns the top level control for this dialog page.
   * 
   * @return the dialog content */
  public JComponent getContent();

  /** Set the focus to the first input control. Called by the dialog before showing this page the
   * first time. Usually the page calls the <code>requestFocus()</code> on its first input widget.*/
  public void requestFocus();

}