/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.labeled;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.exception.ConfigurationException;
import net.disy.commons.core.message.Message;
import net.disy.commons.core.util.SimpleEqualOperator;
import net.disy.commons.core.util.StringUtilities;
import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.object.component.IObjectInputComponent;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

public class LabeledValueComboBox<O> implements IObjectInputComponent<O, JComboBox> {

  private final IObjectUi<ILabeledValue> objectUi;
  private final JComboBox comboBox;
  private final List<ILabeledValue> labelByValueMap;

  public LabeledValueComboBox(
      final IAttributeValueListFactory<ILabeledValue> valuesFactory,
      final IAttributeContext attributeContext) {
    this.objectUi = new LabeledValueUi();
    final List<ILabeledValue> values = createValues(valuesFactory, attributeContext);
    this.labelByValueMap = initLabelByValueMap(values);
    this.comboBox = createComboBox(values);
  }

  @SuppressWarnings("unchecked")
  private List<ILabeledValue> initLabelByValueMap(final List<ILabeledValue> values) {
    final List<ILabeledValue> map = new ArrayList<ILabeledValue>();
    for (final ILabeledValue value : values) {
      map.add(value);
    }
    return map;
  }

  private DefaultComboBoxModel createComboBoxModel(final List<ILabeledValue> values) {
    if (values == null) {
      return new DefaultComboBoxModel();
    }
    return new DefaultComboBoxModel(values.toArray());
  }

  private List<ILabeledValue> createValues(
      final IAttributeValueListFactory<ILabeledValue> valuesFactory,
      final IAttributeContext attributeContext) {
    List<ILabeledValue> values = new ArrayList<ILabeledValue>();
    try {
      values = valuesFactory.createList(attributeContext);
      return values == null ? new ArrayList<ILabeledValue>() : values;
    }
    catch (final ConfigurationException e) {
      MessageDialogFactory.createMessageDialog(null, new Message(e.getMessage(), e)).show();
      return new ArrayList<ILabeledValue>();
    }
  }

  private JComboBox createComboBox(final List<ILabeledValue> values) {
    final DefaultComboBoxModel comboBoxModel = createComboBoxModel(values);
    final JComboBox combobox = new JComboBox(comboBoxModel);
    combobox.setPrototypeDisplayValue(createPrototypeDisplayValue(values));
    combobox.setRenderer(new ObjectUiListCellRenderer(objectUi));
    return combobox;
  }

  private ILabeledValue createPrototypeDisplayValue(final List<ILabeledValue> values) {
    ILabeledValue maxLengthValue = new LabeledValue(objectUi.getLabel(null), null);
    for (final ILabeledValue value : values) {
      maxLengthValue = max(maxLengthValue, value);
    }
    return maxLengthValue;
  }

  private ILabeledValue max(final ILabeledValue maxLengthValue, final ILabeledValue value) {
    return StringUtilities.length(maxLengthValue.getLabel()) > StringUtilities.length(value
        .getLabel()) ? maxLengthValue : value;
  }

  @Override
  public void addChangeListener(final ChangeListener changeListener) {
    comboBox.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        changeListener.stateChanged(new ChangeEvent(comboBox));
      }
    });
  }

  @Override
  public void setValue(final O value) {
    final ILabeledValue labeledValue = getLabeledValue(value);
    comboBox.setSelectedItem(labeledValue);
  }

  private ILabeledValue getLabeledValue(final Object value) {
    for (ILabeledValue result : labelByValueMap) {
      if (SimpleEqualOperator.areEquals(value, result.getValue())) {
        return result;
      }
    }
    return new LabeledValue("" + value, value);
  }

  @SuppressWarnings("unchecked")
  @Override
  public O getValue() {
    final ILabeledValue selectedItem = (ILabeledValue) comboBox.getSelectedItem();
    return (O) (selectedItem == null ? null : selectedItem.getValue());
  }

  @Override
  public JComboBox getComponent() {
    return comboBox;
  }

  @Override
  public boolean isEditable() {
    return comboBox.isEditable();
  }

  @Override
  public void setEditable(final boolean editable) {
    comboBox.setEditable(editable);
  }

  @Override
  public void selectAll() {
    // nothing to do
  }

  @Override
  public void requestFocus() {
    comboBox.requestFocus();
  }

  @Override
  public final void setEnabled(final boolean enabled) {
    comboBox.setEnabled(enabled);
  }

  @Override
  public void update() {
    //nothing to do
  }
}