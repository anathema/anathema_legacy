/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.message;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.IRequestFinishListener;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;

public class MessageDialogPanel implements ISmartDialogPanel {
  private final IMessage message;

  public MessageDialogPanel(final IMessage message) {
    this.message = message;
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    //nothing to do
  }

  @Override
  public void addRequestFinishListener(final IRequestFinishListener requestFinishListener) {
    //nothing to do
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return message;
  }

  @Override
  public void requestFocus() {
    //nothing to do
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final JComponent content = new MessageDialogPage(message).createContent();
    panel.add(content, GridDialogLayoutDataFactory.createHorizontalSpanData(columnCount));
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

}