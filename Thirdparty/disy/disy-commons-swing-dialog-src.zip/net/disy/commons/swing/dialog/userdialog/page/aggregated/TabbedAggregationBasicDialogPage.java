/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated;

import javax.swing.JComponent;
import javax.swing.JTabbedPane;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.userdialog.page.IBasicDialogPage;
import net.disy.commons.swing.message.MessageTypeUi;

public class TabbedAggregationBasicDialogPage extends AbstractCompositeDialogPage {

  private final IBasicDialogPage[] pages;
  private JTabbedPane tabbedPane;

  public TabbedAggregationBasicDialogPage(final String title, final IBasicDialogPage... pages) {
    super(title);
    this.pages = pages;
    createTabbedPane();
  }

  @Override
  public final IBasicDialogPage[] getPages() {
    return pages;
  }

  @Override
  public void updateInputValid() {
    super.updateInputValid();
    for (int i = 0; i < pages.length; i++) {
      final IBasicMessage currentMessage = pages[i].createCurrentMessage();
      final MessageType messageType = currentMessage == null ? MessageType.NORMAL : currentMessage
          .getType();
      tabbedPane.setIconAt(i, messageType == MessageType.NORMAL ? null : MessageTypeUi
          .getInstance()
          .getIcon(messageType));
    }
  }

  @Override
  protected IBasicMessage getDefaultCurrentMessage() {
    return currentPage().createCurrentMessage();
  }

  @Override
  public void requestFocus() {
    currentPage().requestFocus();
  }

  private IBasicDialogPage currentPage() {
    return pages[tabbedPane.getSelectedIndex()];
  }

  @Override
  public JComponent createContent() {
    return tabbedPane;
  }

  private void createTabbedPane() {
    tabbedPane = new JTabbedPane();
    forAllPages(new IPageClosure() {
      @Override
      public void execute(final IBasicDialogPage dialogPage) {
        tabbedPane.addTab(dialogPage.getTitle(), dialogPage.createContent());
      }
    });
    tabbedPane.addChangeListener(getCheckInputValidListener());
  }

  public void setEnabledAt(final int index, final boolean enabled) {
    tabbedPane.setEnabledAt(index, enabled);
  }
}