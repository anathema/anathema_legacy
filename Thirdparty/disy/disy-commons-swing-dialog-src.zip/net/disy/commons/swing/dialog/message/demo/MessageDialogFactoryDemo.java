package net.disy.commons.swing.dialog.message.demo;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.message.MessageDialogFactory;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

import de.jdemo.extensions.SwingDemoCase;

public class MessageDialogFactoryDemo extends SwingDemoCase {

  private static final String MESSAGE = "Error loading configuration from file:\n" //$NON-NLS-1$
      + "\t'" //$NON-NLS-1$
      + "f:/sdkjflaksjdf/sdcmnasdc.txt" //$NON-NLS-1$
      + "'\n" //$NON-NLS-1$
      + "The file does not exist.\n\n" //$NON-NLS-1$
      + " Using default configuration instead."; //$NON-NLS-1$

  private void show(IMessage message) {
    UserDialog d = MessageDialogFactory.createMessageDialog(createParentComponent(), message);
    show(d.getDialog().getWindow());
  }

  public void demoErrorWithoutException() {
    show(new Message("Title", //$NON-NLS-1$
        MESSAGE, MessageType.ERROR));
  }

  public void demoErrorWithException() {
    show(new Message("Title", //$NON-NLS-1$
        MESSAGE, new ArrayIndexOutOfBoundsException()));
  }

  public void demoInformationMessage() {
    show(new Message("Title", //$NON-NLS-1$
        "This message is an information message.", //$NON-NLS-1$
        MessageType.INFORMATION));
  }

  public void demoWarningMessageWithoutTitle() {
    show(new Message("This message is a warning message.", //$NON-NLS-1$
        MessageType.WARNING));
  }

  public void demoErrorMessageWithoutTitle() {
    show(new Message("This message is an error message.", //$NON-NLS-1$
        MessageType.ERROR));
  }
}