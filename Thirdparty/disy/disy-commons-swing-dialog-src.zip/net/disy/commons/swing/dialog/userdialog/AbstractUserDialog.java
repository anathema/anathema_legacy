package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;
import java.awt.Dimension;

import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

/**
 * @author gebhard
 */
public abstract class AbstractUserDialog implements IUserDialog {
  private IUserDialogContainer dialogContainer;
  private boolean modal = true;
  private final IDialogPage dialogPage;
  private final IDialogButtonConfiguration buttonConfiguration;

  public AbstractUserDialog(IDialogPage dialogPage) {
    this(dialogPage, DialogButtonConfiguration.createBoth());
  }

  public AbstractUserDialog(IDialogPage dialogPage, IDialogButtonConfiguration buttonConfiguration) {
    this.dialogPage = dialogPage;
    this.buttonConfiguration = buttonConfiguration;
  }

  //@Overrides
  public IDialogPage getDialogPage() {
    return dialogPage;
  }

  //@Overrides
  public void setUserDialogContainer(IUserDialogContainer dialogContainer) {
    this.dialogContainer = dialogContainer;
    dialogPage.setContainer(dialogContainer);
  }

  protected IUserDialogContainer getDialogContainer() {
    return dialogContainer;
  }

  //@Overrides
  public String getOkButtonText() {
    return buttonConfiguration.getOkayButtonText();
  }

  //@Overrides
  public String getCancelButtonText() {
    return buttonConfiguration.getCancelButtonText();
  }

  //@Overrides
  public Component[] createAdditionalButtons() {
    return new Component[0];
  }

  protected void setModal(boolean modal) {
    this.modal = modal;
  }

  //@Overrides
  public boolean isModal() {
    return modal;
  }

  //@Overrides
  public boolean performOk() {
    return true;
  }

  //@Overrides
  public boolean performCancel() {
    return true;
  }

  //@Overrides
  public boolean isHeaderPanelVisible() {
    return true;
  }

  //@Overrides
  public boolean isCancelAvailable() {
    return buttonConfiguration.isCancelButtonAvailable();
  }

  //@Overrides
  public boolean isOkButtonAvailable() {
    return buttonConfiguration.isOkayButtonAvailable();
  }

  //@Overrides
  public final Dimension getDialogSize() {
    throw new UnsupportedOperationException();
  }

  //@Overrides
  public void performAfterDispose(boolean canceled) {
    //nothing to do
  }
}