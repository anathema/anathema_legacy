/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.builder;

import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.userdialog.DefaultDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class DialogConfigurationBuilder implements IDialogConfigurationBuilder {

  private boolean headerPanelVisible = true;

  @Override
  public <P extends IDialogPage> IDialogConfiguration<P> create(final P page) {
    return configure(new DefaultDialogConfiguration<P>(page) {
      @Override
      public IDialogHeaderPanelConfiguration getHeaderPanelConfiguration() {
        return headerPanelVisible
            ? DialogHeaderPanelConfiguration.createVisibleWithoutIcon()
            : DialogHeaderPanelConfiguration.createInvisible();
      }
    });
  }

  private <P extends IDialogPage> DefaultDialogConfiguration<P> configure(
      final DefaultDialogConfiguration<P> dialogConfiguration) {
    return dialogConfiguration;
  }

  @Override
  public <P extends IDialogPage> IDialogConfiguration<P> create(
      final P page,
      final IDialogButtonConfiguration buttonConfiguration) {
    return configure(new DefaultDialogConfiguration<P>(page, buttonConfiguration) {
      @Override
      public IDialogHeaderPanelConfiguration getHeaderPanelConfiguration() {
        return headerPanelVisible
            ? DialogHeaderPanelConfiguration.createVisibleWithoutIcon()
            : DialogHeaderPanelConfiguration.createInvisible();
      }
    });
  }

  @Override
  public IDialogConfigurationBuilder invisibleHeaderPanel() {
    headerPanelVisible = false;
    return this;
  }

}