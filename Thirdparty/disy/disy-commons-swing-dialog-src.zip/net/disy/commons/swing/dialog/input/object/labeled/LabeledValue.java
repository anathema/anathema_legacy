/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.object.labeled;

import net.disy.commons.core.util.ObjectUtilities;

public class LabeledValue implements ILabeledValue {

  private final Object value;
  private final String label;

  public LabeledValue(final String label, final Object value) {
    this.label = label;
    this.value = value;
  }

  @Override
  public String getLabel() {
    return label;
  }

  @Override
  public Object getValue() {
    return value;
  }

  @Override
  public boolean equals(final Object obj) {
    if (!(obj instanceof ILabeledValue)) {
      return false;
    }
    return ObjectUtilities.equals(value, ((ILabeledValue) obj).getValue());
  }

  @Override
  public int hashCode() {
    if (value == null) {
      return ILabeledValue.class.hashCode();
    }
    return value.hashCode();
  }
}