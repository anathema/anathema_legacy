/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.Cursor;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.SwingColors;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.layout.grid.GridDialogLayout;

public abstract class AbstractSuggestionWindowLabelComponent implements IComponentContainer {

  private final JComponent content;

  public AbstractSuggestionWindowLabelComponent(final String labelText, final Icon optionalIcon) {
    Ensure.ensureArgumentNotNull(labelText);
    final JPanel panel = new JPanel(new GridDialogLayout(1, false));
    panel.setBackground(SwingColors.getTextAreaBackgroundColor());
    final JLabel label = new JLabel(labelText);
    label.setIcon(optionalIcon);
    panel.add(label);
    content = new JScrollPane(panel);
    content.setCursor(getCursor());
  }

  protected abstract Cursor getCursor();

  @Override
  public final JComponent getContent() {
    return content;
  }
}