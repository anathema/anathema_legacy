// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.layout.grid.GridAlignment;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.IMessage;
import net.disy.commons.swing.message.gui.MessageTypeUi;
import net.disy.commons.swing.widgets.AutoWrappingLabel;

// NOT_PUBLISHED
public class MessageDialogPage extends AbstractDialogPage {

  private IMessage message;

  public MessageDialogPage(final IMessage message) {
    super(new BasicMessage());
    Ensure.ensureArgumentNotNull(message);
    this.message = message;
  }

  public JComponent createContent() {
    GridDialogLayoutData iconData = new GridDialogLayoutData();
    iconData.setGrabExcessVerticalSpace(true);
    iconData.setVerticalAlignment(GridAlignment.FILL);

    GridDialogLayoutData textData = new GridDialogLayoutData();
    textData.setGrabExcessHorizontalSpace(true);
    textData.setHorizontalAlignment(GridAlignment.FILL);

    Icon icon = MessageTypeUi.getIcon(message.getType());
    AutoWrappingLabel label = new AutoWrappingLabel(message.getText(), 294);
    JPanel panel = new JPanel(new GridDialogLayout(2, false, 13, 0));
    label.setBackground(panel.getBackground());
    panel.add(new JLabel(icon), iconData);
    panel.add(label.getContent(), textData);
    return panel;
  }

  public IBasicMessage createCurrentMessage() {
    return getDefaultMessage();
  }

  public String getDescription() {
    return null;
  }

  public String getTitle() {
    return message.getTitle() == null ? MessageTypeUi.getLabel(message.getType()) : message
        .getTitle();
  }
}