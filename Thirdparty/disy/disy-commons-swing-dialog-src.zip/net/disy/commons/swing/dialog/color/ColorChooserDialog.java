/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Color;
import java.awt.Component;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.userdialog.DefaultDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

/**
 * adds to standard swing colorChooser a possibility to enter transparency
 */
public class ColorChooserDialog {

  public static Color showDialog(
      final Component parent,
      final IColorChooserConfiguration configuration,
      final Color color) {
    final ColorModel colorModel = new ColorModel(color);
    final ColorChooserPanel colorChooserPanel = new ColorChooserPanel(colorModel, configuration
        .isTransparencyEnabled());

    final AbstractDialogPage page = new AbstractDialogPage("") { //$NON-NLS-1$
      @Override
      public String getTitle() {
        return configuration.getColorChooserDialogTitle();
      }

      @Override
      public JComponent createContent() {
        return colorChooserPanel.getContent();
      }

      @Override
      public IBasicMessage createCurrentMessage() {
        return getDefaultMessage();
      }
    };
    final IDialogConfiguration<AbstractDialogPage> dialogConfiguration = new DefaultDialogConfiguration<AbstractDialogPage>(
        page) {
      @Override
      public IDialogHeaderPanelConfiguration getHeaderPanelConfiguration() {
        return DialogHeaderPanelConfiguration.createInvisible();
      }

      @Override
      public JComponent[] createAdditionalButtons() {
        final Action resetAction = new SmartAction(DisyCommonsSwingMessages
            .getString("ColorChooserDialog.Reset")) { //$NON-NLS-1$
          @Override
          protected void execute(final Component parentComponent) {
            colorChooserPanel.resetColor();
          }
        };
        return new JComponent[]{ new JButton(resetAction) };
      }
    };
    final UserDialog userDialog = new UserDialog(parent, dialogConfiguration);
    final IDialogResult result = userDialog.show();
    if (result.isCanceled()) {
      return color;
    }
    return colorModel.getColor();
  }
}