// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard.demo;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.dialog.wizard.AbstractWizardPage;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.MessageType;

public class DemoWizardPage extends AbstractWizardPage {
  private int pageNumber;
  private int pageCount;
  private JTextField textField;

  public DemoWizardPage(int pageNumber, int pageCount) {
    super("DemoWizardPage.description" + pageNumber, "DemoWizardPage.title", new BasicMessage( //$NON-NLS-1$ //$NON-NLS-2$
        "DemoWizardPage.message", //$NON-NLS-1$
        MessageType.NORMAL));
    this.pageCount = pageCount;
    this.pageNumber = pageNumber;
  }

  public boolean canFlipToNextPage() {
    return !hasErrorMessage() && !isLastPage();
  }

  private boolean hasErrorMessage() {
    return getMessage().isErrorMessage();
  }

  private boolean isLastPage() {
    return pageNumber == pageCount;
  }

  public boolean canFinish() {
    return false;
  }

  //TODO 10.11.2003 (gebhard): Demo mit messageds umstellen auf Radio-Buttons und CheckInputValidListener
  protected JComponent createContent() {
    JButton errorButton = new JButton("Error message");
    errorButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setMessage(new BasicMessage("Hitting this Button is an error", MessageType.ERROR));
      }
    });
    JButton warningButton = new JButton("Warning message");
    warningButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setMessage(new BasicMessage("Hitting this Button is produces warning", MessageType.WARNING));
      }
    });
    JButton infoButton = new JButton("Information message");
    infoButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setMessage(new BasicMessage(
            "Hitting this Button is produces an information",
            MessageType.INFORMATION));
      }
    });
    JButton longInfoButton = new JButton("Long Information message");
    longInfoButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setMessage(new BasicMessage(
            "Hitting this Button is produces a very long information message that will span more than one line.",
            MessageType.INFORMATION));
      }
    });

    JButton clearButton = new JButton("Normal message");
    clearButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        setMessage(getDefaultMessage());
      }
    });

    textField = new JTextField("textfield...");

    JPanel panel = new JPanel();
    panel.setLayout(new GridDialogLayout(1, false));
    panel.add(errorButton);
    panel.add(warningButton);
    panel.add(infoButton);
    panel.add(longInfoButton);
    panel.add(clearButton);
    panel.add(textField);
    panel.setBorder(BorderFactory.createLineBorder(Color.cyan));
    return panel;
  }

  public boolean isHelpAvailable() {
    return false;
  }

  public void performHelp() {
  }

  public void pageActivated() {
  }

  public void pageDeactivated() {
  }

  public void requestFocus() {
    textField.requestFocus();
  }

  protected IBasicMessage createCurrentMessage() {
    //TODO 10.11.2003 (gebhard): An Selektion der Buttons anpassen
    return getDefaultMessage();
  }
}