/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.demo;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.core.IDialogHelpHandler;
import net.disy.commons.swing.dialog.wizard.AbstractWizardPage;
import net.disy.commons.swing.layout.grid.GridDialogLayout;

public class DemoWizardPage extends AbstractWizardPage {
  private JTextField textField;
  private final int pageNumber;

  public DemoWizardPage(final int pageNumber) {
    super(
        "DemoWizardPage.description" + pageNumber, "DemoWizardPage.title", "DemoWizardPage.message"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    this.pageNumber = pageNumber;
  }

  @Override
  public boolean canFinish() {
    return false;
  }

  @Override
  protected JComponent createContent() {
    final JButton errorButton = new JButton("Error message"); //$NON-NLS-1$
    errorButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        setMessage(new BasicMessage("Hitting this Button is an error", MessageType.ERROR)); //$NON-NLS-1$
      }
    });
    final JButton warningButton = new JButton("Warning message"); //$NON-NLS-1$
    warningButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        setMessage(new BasicMessage("Hitting this Button is produces warning", MessageType.WARNING)); //$NON-NLS-1$
      }
    });
    final JButton infoButton = new JButton("Information message"); //$NON-NLS-1$
    infoButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        setMessage(new BasicMessage("Hitting this Button is produces an information", //$NON-NLS-1$
            MessageType.INFORMATION));
      }
    });
    final JButton longInfoButton = new JButton("Long Information message"); //$NON-NLS-1$
    longInfoButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        setMessage(new BasicMessage(
            "Hitting this Button is produces a very long information message that will span more than one line.", //$NON-NLS-1$
            MessageType.INFORMATION));
      }
    });

    final JButton clearButton = new JButton("Normal message"); //$NON-NLS-1$
    clearButton.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(final ActionEvent e) {
        setMessage(getDefaultMessage());
      }
    });

    textField = new JTextField("textfield..."); //$NON-NLS-1$

    final JPanel panel = new JPanel();
    panel.setLayout(new GridDialogLayout(1, false));
    panel.add(errorButton);
    panel.add(warningButton);
    panel.add(infoButton);
    panel.add(longInfoButton);
    panel.add(clearButton);
    panel.add(textField);
    panel.setBorder(BorderFactory.createLineBorder(Color.cyan));
    return panel;
  }

  @Override
  public IDialogHelpHandler getHelpHandler() {
    return pageNumber % 2 == 0 ? new IDialogHelpHandler() {
      @Override
      public void execute(final Component parentComponent) {
        System.out.println("Help"); //$NON-NLS-1$
      }
    } : null;
  }

  @Override
  public void requestFocus() {
    textField.requestFocus();
  }

  @Override
  protected IBasicMessage createCurrentMessage() {
    return getDefaultMessage();
  }
}