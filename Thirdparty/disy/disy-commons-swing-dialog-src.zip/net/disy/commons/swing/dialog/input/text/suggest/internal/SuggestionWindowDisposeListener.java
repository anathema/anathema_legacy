/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.suggest.internal;

import java.awt.Window;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.JComponent;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dispose.IDisposable;
import net.disy.commons.swing.util.GuiUtilities;

public class SuggestionWindowDisposeListener {

  private final IDisposable window;

  private final WindowListener parentWindowListener = new WindowAdapter() {
    @Override
    public void windowDeactivated(final WindowEvent e) {
      window.dispose();
    }
  };

  private final ComponentAdapter componentListener = new ComponentAdapter() {
    @Override
    public void componentResized(final ComponentEvent e) {
      window.dispose();
    }

    @Override
    public void componentMoved(final ComponentEvent e) {
      window.dispose();
    }

    @Override
    public void componentHidden(final ComponentEvent e) {
      window.dispose();
    }
  };

  public SuggestionWindowDisposeListener(final IDisposable window) {
    Ensure.ensureArgumentNotNull(window);
    this.window = window;
  }

  public void attachTo(final JComponent hookComponent) {
    final Window parentWindow = GuiUtilities.getWindowFor(hookComponent);
    parentWindow.addWindowListener(parentWindowListener);
    parentWindow.addComponentListener(componentListener);
    hookComponent.addComponentListener(componentListener);
  }

  public void detachFrom(final JComponent hookComponent) {
    final Window parentWindow = GuiUtilities.getWindowFor(hookComponent);
    parentWindow.removeWindowListener(parentWindowListener);
    parentWindow.removeComponentListener(componentListener);
    hookComponent.removeComponentListener(componentListener);
  }
}