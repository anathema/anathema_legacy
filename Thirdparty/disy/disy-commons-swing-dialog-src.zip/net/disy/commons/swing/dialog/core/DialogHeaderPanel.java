//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import net.disy.commons.swing.layout.VFlowLayout;
import net.disy.commons.swing.message.IBasicMessage;
import net.disy.commons.swing.message.gui.MessageTypeUi;
import net.disy.commons.swing.widgets.AutoWrappingLabel;
import net.disy.commons.swing.widgets.HorizontalLine;

// NOT_PUBLISHED
public class DialogHeaderPanel implements IDialogConstants {
  private AutoWrappingLabel messageLabel;
  private final JLabel descriptionLabel;
  private final JLabel messageTypeIconLabel;
  private JComponent content;

  public DialogHeaderPanel() {
    descriptionLabel = new JLabel("!Dialog.description!", SwingConstants.LEFT); //$NON-NLS-1$
    messageTypeIconLabel = new JLabel();
    messageLabel = new AutoWrappingLabel("!Dialog.message!", 330); //$NON-NLS-1$
    messageLabel.setBackground(Color.WHITE);
  }

  public JComponent getContent() {
    if (content == null) {
      messageLabel.setBackground(SystemColor.text);
      messageLabel.setFont(MESSAGE_LABEL_FONT);

      descriptionLabel.setFont(descriptionLabel.getFont().deriveFont(Font.BOLD));

      JPanel iconPanel = new JPanel(new VFlowLayout(VFlowLayout.TOP, 3, 0));
      iconPanel.add(messageTypeIconLabel);
      iconPanel.setBackground(SystemColor.text);

      JPanel p = new JPanel(new BorderLayout());
      p.add(iconPanel, BorderLayout.WEST);
      p.add(Box.createRigidArea(new Dimension(1, 22)), BorderLayout.EAST); /* Platzhalter um Dialog in der H�he zu entzerren*/
      p.add(messageLabel.getContent(), BorderLayout.CENTER);
      p.add(descriptionLabel, BorderLayout.NORTH);
      p.setBorder(new EmptyBorder(2, 4, 2, 2));
      p.setBackground(SystemColor.text);

      JPanel topPanel = new JPanel(new BorderLayout());
      topPanel.add(p, BorderLayout.CENTER);
      topPanel.add(new HorizontalLine(), BorderLayout.SOUTH);

      //TODO 08.04.2003 (gebhard): Icon in einem Label rechts, vorr�bergehend einfach Freiraum:
      //topPanel.add(new JLabel(icon), BorderLayout.EAST);    
      topPanel.add(Box.createRigidArea(new Dimension(1, 52)), BorderLayout.EAST);

      content = topPanel;
    }
    return content;
  }

  public void setMessage(IBasicMessage message) {
    messageTypeIconLabel.setIcon(MessageTypeUi.getSmallIcon(message.getType()));
    messageLabel.setForeground(MessageTypeUi.getColor(message.getType()));
    messageLabel.setText(message.getText());
  }

  public void setDescription(String description) {
    descriptionLabel.setText(description);
  }
}