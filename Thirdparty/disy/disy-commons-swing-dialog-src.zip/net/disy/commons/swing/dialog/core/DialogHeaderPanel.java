//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.core;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.Box;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.model.StringModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.core.message.DialogMessageModel;
import net.disy.commons.swing.dialog.core.message.DialogMessagePanel;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.widgets.HorizontalLine;

// NOT_PUBLISHED
public class DialogHeaderPanel {

  private final DialogMessagePanel messagePanel;
  private final JLabel descriptionLabel;
  private final StringModel descriptionModel;
  private JComponent content;

  public DialogHeaderPanel(DialogMessageModel messageModel, StringModel descriptionModel) {
    Ensure.ensureArgumentNotNull(descriptionModel);
    this.descriptionModel = descriptionModel;

    messagePanel = new DialogMessagePanel(messageModel);

    descriptionLabel = new JLabel("!Dialog.description!", SwingConstants.LEFT); //$NON-NLS-1$
    descriptionLabel.setForeground(IDialogConstants.HEADER_TEXT_COLOR);

    descriptionModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateDescription();
      }
    });
    updateDescription();
  }

  public JComponent getContent() {
    if (content == null) {
      descriptionLabel.setFont(descriptionLabel.getFont().deriveFont(Font.BOLD));

      JPanel innerPanel = new JPanel(new BorderLayout(LayoutUtilities.getDpiAdjusted(2), LayoutUtilities
          .getDpiAdjusted(2)));
      //Platzhalter um Dialog in der H�he zu entzerren
      innerPanel.add(Box.createRigidArea(new Dimension(1, 22)), BorderLayout.EAST);
      innerPanel.add(messagePanel.getContent(), BorderLayout.CENTER);
      innerPanel.add(descriptionLabel, BorderLayout.NORTH);
      innerPanel.setBorder(new EmptyBorder(
          LayoutUtilities.getDpiAdjusted(2),
          LayoutUtilities.getDpiAdjusted(4),
          0,
          LayoutUtilities.getDpiAdjusted(2)));
      innerPanel.setBackground(IDialogConstants.HEADER_BACKGROUND_COLOR);

      JPanel panel = new JPanel(new BorderLayout());
      panel.add(innerPanel, BorderLayout.CENTER);
      panel.add(new HorizontalLine(), BorderLayout.SOUTH);

      //TODO 08.04.2003 (gebhard): Icon in einem Label rechts, vorr�bergehend einfach Freiraum:
      //topPanel.add(new JLabel(icon), BorderLayout.EAST);    
      panel.add(Box.createRigidArea(new Dimension(1, 52)), BorderLayout.EAST);

      content = panel;
    }
    return content;
  }

  private void updateDescription() {
    final String description = descriptionModel.getValue();
    descriptionLabel.setText(description);
  }
}