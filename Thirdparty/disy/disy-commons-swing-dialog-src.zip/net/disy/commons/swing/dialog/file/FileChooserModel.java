// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import net.disy.commons.core.io.FileModel;
import net.disy.commons.core.model.AbstractChangeableModel;

//NOT_PUBLISHED
public class FileChooserModel extends AbstractChangeableModel {
  private final FileModel folderModel = new FileModel();
  private final FileModel fileModel = new FileModel();
  private final FileFilterModel fileFilterModel = new FileFilterModel();
  private final ChoosableFileFilterModel choosableFileFilterModel = new ChoosableFileFilterModel();

  public FileChooserModel() {
    choosableFileFilterModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        if (choosableFileFilterModel.isEmpty()) {
          fileFilterModel.setFileFilter(null);
        }
        else {
          FileFilter[] fileFilters = choosableFileFilterModel.getFileFilters();
          fileFilterModel.setFileFilter(fileFilters[fileFilters.length - 1]);
        }
      }
    });
  }
  
  public FileModel getFileModel() {
    return fileModel;
  }

  public FileModel getFolderModel() {
    return folderModel;
  }

  public void refresh() {
    fireChangeEvent();
  }

  public FileFilterModel getFileFilterModel() {
    return fileFilterModel;
  }

  public ChoosableFileFilterModel getChoosableFileFilterModel() {
    return choosableFileFilterModel;
  }
}
