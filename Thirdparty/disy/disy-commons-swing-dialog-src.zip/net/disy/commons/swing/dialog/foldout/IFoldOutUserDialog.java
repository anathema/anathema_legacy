//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import net.disy.commons.swing.dialog.userdialog.IUserDialog;

// NOT_PUBLISHED
public interface IFoldOutUserDialog extends IUserDialog {
  public IFoldOutPage getFoldOutPage();
  
  public String getFoldOutButtonText();

  public String getFoldInButtonText();

  public boolean isInitiallyFoldedOut();
}