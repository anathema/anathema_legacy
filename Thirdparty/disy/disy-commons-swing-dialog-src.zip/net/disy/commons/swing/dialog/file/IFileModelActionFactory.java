// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import javax.swing.Action;

import net.disy.commons.core.io.FileModel;

//NOT_PUBLISHED
public interface IFileModelActionFactory {

  public Action createAction(FileModel fileModel);

}
