// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.wizard;

import java.awt.Component;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.BasicDialogUi;
import net.disy.commons.swing.dialog.core.AbstractDialog;
import net.disy.commons.swing.dialog.core.IDialogConstants;
import net.disy.commons.swing.dialog.core.ISwingFrameOrDialog;
import net.disy.commons.swing.layout.util.ButtonPanelBuilder;
import net.disy.commons.swing.util.GuiUtilities;

/**
 * A dialog to show a wizard to the end user. In typical usage, the client instantiates this class
 * with a particular wizard. The dialog serves as the wizard container and orchestrates the
 * presentation of its pages.
 * 
 * The standard layout is roughly as follows: it has an area at the top containing both the
 * wizard's title, description, and image; the actual wizard page appears in the middle; below that
 * is a progress indicator (which is made visible if needed); and at the bottom of the page is
 * message line and a button bar containing Help, Next, Back, Finish, and Cancel buttons (or some
 * subset).
 * 
 * Clients may subclass WizardDialog, although this is rarely required.
 */
public class WizardDialog extends AbstractDialog implements IWizardContainer, IDialogConstants {

  public static final String FINISH_BUTTON_NAME = "WizardDialog.FinishButton.ComponentName"; //$NON-NLS-1$
  private JButton finishButton;
  private JButton backButton;
  private JButton nextButton;
  private JButton helpButton;
  private IWizardPage currentPage;
  private IWizard wizard;

  /**
   * Creates a new wizard dialog for the given wizard.
   * 
   * @param parent a parent component
   * @param wizard the wizard this dialog is working on
   */
  public WizardDialog(Component parent, IWizard wizard) {
    super(parent, wizard);
    this.wizard = wizard;
    wizard.setContainer(this);
    wizard.addPages();
    initialize();
  }

  protected Component createButtonBar() {
    //SmartAction wegen Mnemonic!
    SmartAction backAction = new SmartAction(BasicDialogUi.WIZARD_BACK_SMART) {
      protected void execute(Component parentComponent) {
        backPressed();
      }
    };

    backButton = new JButton(backAction); //$NON-NLS-1$

    SmartAction nextAction = new SmartAction(BasicDialogUi.WIZARD_NEXT_SMART) {
      protected void execute(Component parentComponent) {
        nextPressed();
      }
    };

    nextButton = new JButton(nextAction);

    JPanel compactedButtons = new JPanel(new GridLayout(1, 0, 0, 0));
    compactedButtons.add(backButton);
    compactedButtons.add(nextButton);

    final SmartAction finishAction = new SmartAction(getWizard().getOkButtonText()) {
      protected void execute(Component parentComponent) {
        performFinish();
      }
    };

    finishButton = new JButton(finishAction);
    finishButton.setName(FINISH_BUTTON_NAME);

    final SmartAction cancelAction = new SmartAction(getWizard().getCancelButtonText()) {
      protected void execute(Component parentComponent) {
        performCancel();
      }
    };

    JButton cancelButton = new JButton(cancelAction);

    final SmartAction helpAction = new SmartAction(BasicDialogUi.HELP_TEXT_SMART) {
      protected void execute(Component parentComponent) {
        helpPressed();
      }
    };

    helpButton = new JButton(helpAction);

    List buttonList = new ArrayList();
    buttonList.add(compactedButtons);
    //ggf. hier auch zus�tzliche Buttons zulassen

    JButton[] additionalButtons = createAdditionalButtons();
    buttonList.addAll(Arrays.asList(additionalButtons));
    if (getWizard().isOkButtonAvailable()) {
      buttonList.add(finishButton);
    }
    if (getWizard().isCancelAvailable()) {
      buttonList.add(cancelButton);
    }
    if (getWizard().isHelpAvailable()) {
      buttonList.add(helpButton);
    }
    ButtonPanelBuilder buttonPanelBuilder = new ButtonPanelBuilder();
    for (int i = 0; i < buttonList.size(); i++) {
      Component button = (Component) buttonList.get(i);
      buttonPanelBuilder.add(button);
    }
    return buttonPanelBuilder.createPanel();
  }

  private JButton[] createAdditionalButtons() {
    return new JButton[0];
  }

  /** Notifies that the back button of this dialog has been pressed. */
  protected void backPressed() {
    showPage(getCurrentPage().getPreviousPage());
  }

  /** Notifies that the cancel button of this dialog has been pressed. */
  protected boolean cancelPressed() {
    return getWizard().performCancel();
  }

  /** The Finish button has been pressed. */
  protected boolean finishPressed() {
    /*
     * Zur Sicherheit nochmal getNextPage auf der aktuellen Seite aufrufen, um
     */
    //TODO NOW (sieroux) 30.10.2003: Diskussion ob nextPage oder pageDeactivated (mg): Wenn �berhaupt dann sollte pageDeactivated aufgerufen werden. Die getNextPage() hat semantisch nichts mit finish zu tun, oder? 
    getCurrentPage().getNextPage();
    getCurrentPage().pageDeactivated();

    return getWizard().performFinish();
  }

  /** The Help button has been pressed. */
  protected void helpPressed() {
    getCurrentPage().performHelp();
  }

  /** The Next button has been pressed */
  protected void nextPressed() {
    showPage(getCurrentPage().getNextPage());
  }

  //  /** Sets the minimum page size used for the pages.*/
  //  protected void setMinimumPageSize(Dimension size) {
  //    this.minimumPageSize = size;
  //    updateSize();
  //  }

  public void showPage(IWizardPage page) {
    Ensure.ensureArgumentNotNull(page);
    if (currentPage != null) {
      currentPage.pageDeactivated();
    }
    currentPage = page;
    updateContent();
    updateMessage();
    updateDescription();
    updateButtons();
    updateTitle();
    updateSize();
    currentPage.pageActivated();
    currentPage.requestFocus();
  }

  protected void updateContent() {
    setContent(getCurrentPage().getContent());
  }

  public IWizardPage getCurrentPage() {
    return currentPage;
  }

  public void updateButtons() {
    IWizardPage page = getCurrentPage();
    nextButton.setEnabled(page.canFlipToNextPage());
    backButton.setEnabled(page.getPreviousPage() != null);
    finishButton.setEnabled(getWizard().canFinish());
    helpButton.setVisible(getWizard().isHelpAvailable());
    helpButton.setEnabled(page.isHelpAvailable());
    if (finishButton.isEnabled()) {
      setDefaultButton(finishButton);
    }
    else {
      setDefaultButton(nextButton);
    }
  }

  public void updateMessage() {
    setMessage(getCurrentPage().getMessage());
  }

  public void updateDescription() {
    setDescription(getCurrentPage().getDescription());
  }

  public void updateTitle() {
    setTitle(getCurrentPage().getTitle());
  }

  public void show() {
    ISwingFrameOrDialog configuredDialog = getConfiguredDialog();
    GuiUtilities.centerToParent(configuredDialog.getWindow());
    configuredDialog.show();
  }

  /** For internal use only (demos) */
  public ISwingFrameOrDialog getConfiguredDialog() {
    IWizardPage startingPage = getWizard().getStartingPage();
    if (startingPage == null) {
      throw new RuntimeException("Starting page may not be null in IWizard.getStartingPage()"); //$NON-NLS-1$
    }
    showPage(startingPage);
    ISwingFrameOrDialog configuredDialog = getDialog();
    if (configuredDialog == null) {
      throw new IllegalStateException(
          "WizardDialog is already disposed and may not be shown more often than once"); //$NON-NLS-1$
    }
    if (configuredDialog.isVisible()) {
      throw new IllegalStateException("WizardDialog is already visible"); //$NON-NLS-1$
    }
    return configuredDialog;
  }

  protected IWizard getWizard() {
    return wizard;
  }

  private void performFinish() {
    if (finishPressed()) {
      closeDialog();
      getGenericDialog().performAfterDispose(false);
    }
  }

  //@Overrides
  public final void requestFinish() {
    performFinish();
  }
  
  //@Overrides
  public final void requestNext() {
    if (!getCurrentPage().canFlipToNextPage()) {
      return;
    }
    nextPressed();
  } 
}