//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import java.awt.Component;

import net.disy.commons.swing.dialog.userdialog.UserDialog;

// NOT_PUBLISHED
public class SmartOneOutOfManySelectionDialog {

  private SmartOneOutOfManySelectionDialog() {
    //no instance available
  }

  public static IOneOutOfManyDialogResult showSelectOneOutOfManeDialog(
      Component parentComponent,
      final IOneOutOfManyDialogConfiguration configuration) {
    SelectOneOutOfManyDialogPage page = new SelectOneOutOfManyDialogPage(configuration);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    dialog.show();
    final Object selectedItem = page.getSelectedItem();
    return new IOneOutOfManyDialogResult() {
      public boolean isCanceled() {
        return dialog.isCanceled();
      }

      public Object getSelectedItem() {
        return selectedItem;
      }
    };
  }

  public static UserDialog createDemoDialog(
      Component parentComponent,
      IOneOutOfManyDialogConfiguration configuration) {
    SelectOneOutOfManyDialogPage page = new SelectOneOutOfManyDialogPage(configuration);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    return dialog;
  }
}