/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.ArrayList;

import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.input.text.component.GeneralStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.IStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.PresetValuesStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.StringComboBox;
import net.disy.commons.swing.dialog.input.text.component.StringInputComponentFactoryFactory;

import org.junit.Test;

public class StringInputComponentFactoryFactoryTest {

  @SuppressWarnings("unchecked")
  @Test
  public void createsComponentFacotryWithGivenValueListFactory() throws Exception {
    final IAttributeValueListFactory<String> presetValueListFactory = createMock(IAttributeValueListFactory.class);
    final IAttributeContext attributeContext = createNiceMock(IAttributeContext.class);
    expect(presetValueListFactory.createList(attributeContext)).andReturn(new ArrayList<String>());
    replay(presetValueListFactory, attributeContext);
    final IStringAttributeInputComponentFactory<?> componentFactory = new StringInputComponentFactoryFactory()
        .createFactory(presetValueListFactory, attributeContext);
    assertThat(
        componentFactory,
        is(instanceOf(PresetValuesStringAttributeInputComponentFactory.class)));
    assertThat(componentFactory.createComponent(), is(instanceOf(StringComboBox.class)));
    verify(presetValueListFactory, attributeContext);
  }

  @Test
  public void createsGeneralComponentFacotryIfValueListFactoryIsNull() throws Exception {
    assertThat(
        new StringInputComponentFactoryFactory().createFactory(null, null),
        is(instanceOf(GeneralStringAttributeInputComponentFactory.class)));
  }
}
