/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.optional.OptionalSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;
import net.disy.commons.swing.testing.ComponentFinder;

import org.junit.Test;

public class OptionalSmartDialogPanel_MandatoryTest {
  private class MandatoryOptionalSmartDialogPanel<T extends Object>
      extends
      OptionalSmartDialogPanel<T> {

    public MandatoryOptionalSmartDialogPanel(
        final ObjectModel<T> model,
        final String checkBoxLabel,
        final IUpdatableSmartDialogPanel delegate,
        final ObjectModel<T> fieldModel) {
      super(model, checkBoxLabel, delegate, fieldModel, true);
    }

    @Override
    public void updateModel() {
      super.updateModel();
    }

    @Override
    public void updateView() {
      super.updateView();
    }

    @Override
    public JCheckBox getCheckbox() {
      return super.getCheckbox();
    }
  }

  @Test
  public void fillIntoAddsNoCheckbox() throws Exception {
    final JPanel container = new JPanel();
    final IUpdatableSmartDialogPanel delegate = createNiceMock(IUpdatableSmartDialogPanel.class);
    expect(delegate.getComponents()).andReturn(new JComponent[0]);
    replay(delegate);
    new MandatoryOptionalSmartDialogPanel<Integer>(new ObjectModel<Integer>(), "checkboxLabel", //$NON-NLS-1$
        delegate,
        new ObjectModel<Integer>()).fillInto(container, 3);
    assertThat(
        ComponentFinder.find(container, new CheckBoxPredicate()),
        is(nullValue()));
  }
}