// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;

import javax.swing.Icon;
import javax.swing.filechooser.FileSystemView;

import net.disy.commons.swing.ui.IObjectUi;

//NOT_PUBLISHED
public class FileObjectUi implements IObjectUi {

  private final FileSystemView fileSystemView;

  public FileObjectUi(FileSystemView fileSystemView) {
    this.fileSystemView = fileSystemView;
  }

  public Icon getIcon(Object value) {
    return fileSystemView.getSystemIcon((File) value);
  }

  public String getLabel(Object value) {
    return fileSystemView.getSystemDisplayName((File) value);
  }

}
