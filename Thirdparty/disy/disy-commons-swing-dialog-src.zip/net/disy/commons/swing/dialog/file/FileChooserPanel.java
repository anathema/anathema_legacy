// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextField;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

import net.disy.commons.core.string.StringFilter;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.component.AbstractActionComponent;
import net.disy.commons.swing.events.AbstractDocumentChangeListener;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.list.JListUtilities;
import net.disy.commons.swing.textfield.FilteredTextField;
import net.disy.commons.swing.ui.IObjectUi;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

//NOT_PUBLISHED
public class FileChooserPanel extends AbstractActionComponent {
  private JComponent content;
  private FileSelectionPanel fileSelectionPanel;
  private JTextField textField;
  private final FileChooserDialogConfiguration configuration;
  private final FileChooserModel model;
  private FolderSelectionPanel folderSelectionPanel;
  private JComboBox filterCombo;

  public FileChooserPanel(final FileChooserModel model, FileChooserDialogConfiguration configuration) {
    Ensure.ensureArgumentNotNull(model);
    Ensure.ensureArgumentNotNull(configuration);
    this.model = model;
    this.configuration = configuration;
    content = createContent();

    updateTextField();

    if (configuration.isFileFilterEnabled()) {
      updateComboItems();
      updateComboSelection();
    }

    initListeners();
  }

  private void initListeners() {
    ActionListener actionListener = new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        File selectedFile = model.getFileModel().getFile();
        if (selectedFile.isDirectory()) {
          model.getFolderModel().setFile(selectedFile);
        }
        else {
          fireActionEvent();
        }
      }
    };
    fileSelectionPanel.addActionListener(actionListener);

    model.getFileModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateTextField();
      }
    });

    textField.getDocument().addDocumentListener(new AbstractDocumentChangeListener() {
      protected void documentChanged() {
        String text = textField.getText();
        if (text == null || text.equals("")) { //$NON-NLS-1$
          return;
        }
        model.getFileModel().setFile(new File(model.getFolderModel().getFile(), text));
      }
    });
    textField.addActionListener(actionListener);

    model.getFolderModel().addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        model.getFileModel().setFile(null);
      }
    });

    model.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        folderSelectionPanel.refresh();
        fileSelectionPanel.refresh();
      }
    });

    if (configuration.isFileFilterEnabled()) {
      model.getChoosableFileFilterModel().addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          updateComboItems();
          updateComboSelection();
        }
      });

      model.getFileFilterModel().addChangeListener(new ChangeListener() {
        public void stateChanged(ChangeEvent e) {
          updateComboSelection();
        }
      });

      filterCombo.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          FileFilter selectedFileFilter = (FileFilter) filterCombo.getSelectedItem();
          model.getFileFilterModel().setFileFilter(selectedFileFilter);
        }
      });
    }
  }

  private void updateComboSelection() {
    filterCombo.setSelectedItem(model.getFileFilterModel().getFileFilter());
  }

  private void updateComboItems() {
    JListUtilities.setComboItems(filterCombo, model.getChoosableFileFilterModel().getFileFilters());
  }

  private void updateTextField() {
    File file = model.getFileModel().getFile();
    if (file == null) {
      textField.setText(""); //$NON-NLS-1$
    }
    else {
      String displayName = configuration.getFileSystemView().getSystemDisplayName(file);
      if (!displayName.equals(textField.getText())) {
        textField.setText(displayName);
      }
    }
  }

  private JComponent createContent() {
    folderSelectionPanel = new FolderSelectionPanel(model.getFolderModel(), configuration
        .getFileSystemView(), configuration.getRoots());
    fileSelectionPanel = new FileSelectionPanel(model, configuration.getFileSystemView());
    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, folderSelectionPanel
        .getContent(), fileSelectionPanel.getContent());
    JPanel textFieldPanel = new JPanel(new GridDialogLayout(2, false));
    textFieldPanel.add(new JLabel("Dateiname:"), new GridDialogLayoutData()); //$NON-NLS-1$
    StringFilter filter = new StringFilter() {
      public boolean acceptFilterText(String s) {
        if (s.equals("")) { //$NON-NLS-1$
          return true;
        }
        if (s.endsWith(File.separator)) {
          return false;
        }
        File file = new File(model.getFolderModel().getFile(), s);
        return model.getFolderModel().getFile().equals(file.getParentFile());
      }
    };
    textField = new FilteredTextField(filter);
    textFieldPanel.add(textField, GridDialogLayoutData.FILL_HORIZONTAL);
    if (configuration.isFileFilterEnabled()) {
      addFilterCombo(textFieldPanel);
    }
    JPanel panel = new JPanel(new BorderLayout(
        LayoutUtilities.getComponentSpacing(),
        LayoutUtilities.getComponentSpacing()));
    panel.add(splitPane, BorderLayout.CENTER);
    panel.add(textFieldPanel, BorderLayout.SOUTH);
    return panel;
  }

  private void addFilterCombo(JPanel textFieldPanel) {
    textFieldPanel.add(new JLabel("Dateityp:"), new GridDialogLayoutData()); //$NON-NLS-1$
    filterCombo = new JComboBox();
    filterCombo.setRenderer(new ObjectUiListCellRenderer(new IObjectUi() {
      public String getLabel(Object value) {
        if (value == null) {
          return ""; //$NON-NLS-1$
        }
        FileFilter fileFilter = (FileFilter) value;
        return fileFilter.getDescription();
      }

      public Icon getIcon(Object value) {
        return null;
      }
    }));
    textFieldPanel.add(filterCombo, GridDialogLayoutData.FILL_HORIZONTAL);
  }

  public JComponent getContent() {
    return content;
  }
}
