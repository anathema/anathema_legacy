/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select.demo;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.NullMessageProducingValidator;
import net.disy.commons.swing.dialog.input.text.DefaultTextSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.combobox.demo.DemoColorItem;
import net.disy.commons.swing.dialog.userdialog.demo.DialogPageDemoCase;

public abstract class AbstractSelectionDialogDemo extends DialogPageDemoCase {

  protected final ISmartDialogPanel[] createAdditionalDemoPanels(
      final FixedOptionsObjectSelectionModel<DemoColorItem> selectionModel) {
    final ObjectModel<String> nameModel = new ObjectModel<String>();

    final IMessageProducingValidator nameValidator = new IMessageProducingValidator() {
      @Override
      public IBasicMessage createOptionalCurrentMessage() {
        if (nameModel.getValue() == null || nameModel.getValue().length() == 0) {
          return new BasicMessage("The name field is empty. Please enter a name for the color.", //$NON-NLS-1$
              MessageType.ERROR);
        }
        if (nameModel.getValue().length() > 10) {
          return new BasicMessage(
              "The specified name for the color is discouraged: Names should not be longer than 30 characters.", //$NON-NLS-1$
              MessageType.WARNING);
        }
        return null;
      }
    };

    final ObjectModel<String> colorNameModel = new ObjectModel<String>();
    selectionModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateNameModel(selectionModel, colorNameModel);
      }
    });
    updateNameModel(selectionModel, colorNameModel);

    final DefaultTextSmartDialogPanel selectedColorNamePanel = new DefaultTextSmartDialogPanel(
        "Selected Color:", //$NON-NLS-1$
        colorNameModel,
        new NullMessageProducingValidator());
    selectedColorNamePanel.setEditable(false);
    final DefaultTextSmartDialogPanel colorNamePanel = new DefaultTextSmartDialogPanel("&Name:", //$NON-NLS-1$
        nameModel,
        nameValidator);
    return new ISmartDialogPanel[]{ selectedColorNamePanel, colorNamePanel, };
  }

  private void updateNameModel(
      final FixedOptionsObjectSelectionModel<DemoColorItem> selectionModel,
      final ObjectModel<String> colorNameModel) {
    final DemoColorItem selectedColor = selectionModel.getFirstSelectedValue();
    colorNameModel.setValue(selectedColor == null ? "" : selectedColor.getName()); //$NON-NLS-1$
  }
}