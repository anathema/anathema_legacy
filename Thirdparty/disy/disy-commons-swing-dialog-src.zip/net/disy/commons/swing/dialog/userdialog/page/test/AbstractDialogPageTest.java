/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.test;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.MessageType;

import org.junit.Before;
import org.junit.Test;

public class AbstractDialogPageTest {

  private TestDialogPage dialogPage;

  @Before
  public void createDialogPage() throws Exception {
    dialogPage = new TestDialogPage();
  }

  @Test
  public void canNotFinishWithErrorMessage() throws Exception {
    dialogPage.currentMessage = new BasicMessage("Hallo", MessageType.ERROR); //$NON-NLS-1$
    assertThat(dialogPage.canFinish(), is(false));
  }

  @Test
  public void canFinishWithMessageTypeLessSevereThanError() throws Exception {
    dialogPage.currentMessage = new BasicMessage("Hallo", MessageType.WARNING); //$NON-NLS-1$
    assertThat(dialogPage.canFinish(), is(true));
  }
}