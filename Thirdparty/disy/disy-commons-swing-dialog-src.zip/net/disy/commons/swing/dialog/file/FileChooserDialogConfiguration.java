//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file;

import java.io.File;

import javax.swing.filechooser.FileSystemView;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.Ensure;

// NOT_PUBLISHED
public class FileChooserDialogConfiguration implements Cloneable {

  private FileSystemView fileSystemView;
  private File[] roots;
  private final IFileModelActionFactory[] actionFactories;
  private boolean fileFilterEnabled = true;

  public FileChooserDialogConfiguration() {
    this(FileSystemView.getFileSystemView(), FileSystemView.getFileSystemView().getRoots());
  }

  public FileChooserDialogConfiguration(File[] roots) {
    this(FileSystemView.getFileSystemView(), roots);
  }

  public FileChooserDialogConfiguration(FileSystemView fileSystemView, File[] roots) {
    this(fileSystemView, roots, new IFileModelActionFactory[0]);
  }

  public FileChooserDialogConfiguration(File[] roots, IFileModelActionFactory[] actionFactories) {
    this(FileSystemView.getFileSystemView(), roots, actionFactories);
  }

  public FileChooserDialogConfiguration(
      FileSystemView fileSystemView,
      File[] roots,
      IFileModelActionFactory[] actionFactories) {
    Ensure.ensureArgumentNotNull(fileSystemView);
    Ensure.ensureArgumentNotNull(roots);
    Ensure.ensureArgumentNotNull(actionFactories);
    this.fileSystemView = fileSystemView;
    this.roots = roots;
    this.actionFactories = actionFactories;
  }

  public FileSystemView getFileSystemView() {
    return fileSystemView;
  }

  public File[] getRoots() {
    return roots;
  }

  public IFileModelActionFactory[] getActionFactories() {
    return actionFactories;
  }

  public boolean isFileFilterEnabled() {
    return fileFilterEnabled;
  }

  public void setFileFilterEnabled(boolean fileFilterEnabled) {
    this.fileFilterEnabled = fileFilterEnabled;
  }
  
  public FileChooserDialogConfiguration getClone() {
    try {
      return (FileChooserDialogConfiguration) clone();
    }
    catch (CloneNotSupportedException e) {
      throw new UnreachableCodeReachedException();
    }
  }
}