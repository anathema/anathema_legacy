/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog;

import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JComponent;

import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.core.IVetoDialogCloseHandler;
import net.disy.commons.swing.dialog.core.internal.AbstractGenericDialogConfiguration;
import net.disy.commons.swing.dialog.core.preferences.IDialogPreferences;
import net.disy.commons.swing.dialog.input.IRequestFinishListener;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

public class DefaultDialogConfiguration<P extends IDialogPage>
    extends
    AbstractGenericDialogConfiguration implements IDialogConfiguration<P> {
  private IUserDialogContainer dialogContainer;
  private final P dialogPage;
  private final Dimension customizedPreferedSize;

  /**
   * @deprecated as of 21.12.2010 (beck), use {@link DefaultDialogConfigurationBuilder} instead
   */
  @Deprecated
  public DefaultDialogConfiguration(final P dialogPage) {
    this(dialogPage, DialogButtonConfigurationFactory.createOkCancel());
  }

  /**
   * @deprecated as of 21.12.2010 (beck), use {@link DefaultDialogConfigurationBuilder} instead
   */
  @Deprecated
  public DefaultDialogConfiguration(
      final P dialogPage,
      final IDialogButtonConfiguration buttonConfiguration) {
    this(dialogPage, buttonConfiguration, null);
  }

  /**
   * @deprecated as of 21.12.2010 (beck), use {@link DefaultDialogConfigurationBuilder} instead
   */
  @Deprecated
  public DefaultDialogConfiguration(
      final P dialogPage,
      final IDialogButtonConfiguration buttonConfiguration,
      final Dimension customizedPreferedSize) {
    this(dialogPage, buttonConfiguration, customizedPreferedSize, null);
  }

  /**
   * @deprecated as of 21.12.2010 (beck), use {@link DefaultDialogConfigurationBuilder} instead
   */
  @Deprecated
  public DefaultDialogConfiguration(
      final P dialogPage,
      final IDialogButtonConfiguration buttonConfiguration,
      final Dimension customizedPreferedSize,
      final IDialogPreferences preferences) {
    this(
        dialogPage,
        buttonConfiguration,
        DialogHeaderPanelConfiguration.createVisibleWithoutIcon(),
        customizedPreferedSize,
        preferences);
  }

  /**
   * @deprecated as of 21.12.2010 (beck), use {@link DefaultDialogConfigurationBuilder} instead
   */
  @Deprecated
  public DefaultDialogConfiguration(final P dialogPage, final IDialogPreferences preferences) {
    this(dialogPage, DialogButtonConfigurationFactory.createOkCancel(), null, preferences);
  }

  public DefaultDialogConfiguration(
      final P dialogPage,
      final IDialogButtonConfiguration buttonConfiguration,
      IDialogHeaderPanelConfiguration headerPanelConfiguration,
      final Dimension customizedPreferedSize,
      final IDialogPreferences preferences) {
    super(buttonConfiguration, headerPanelConfiguration, preferences);
    this.dialogPage = dialogPage;
    this.customizedPreferedSize = customizedPreferedSize;
  }

  @Override
  public P getDialogPage() {
    return dialogPage;
  }

  @Override
  public void setUserDialogContainer(final IUserDialogContainer dialogContainer) {
    this.dialogContainer = dialogContainer;
    dialogPage.addRequestFinishListener(new IRequestFinishListener() {
      @Override
      public void requestFinish() {
        dialogContainer.requestFinish();
      }
    });
  }

  protected final IUserDialogContainer getDialogContainer() {
    return dialogContainer;
  }

  @Override
  public JComponent[] createAdditionalButtons() {
    return new JComponent[0];
  }

  @Override
  public JComponent createOptionalButtonPanelLeftComponent() {
    return null;
  }

  @Override
  public IVetoDialogCloseHandler getVetoCloseHandler() {
    return new IVetoDialogCloseHandler() {
      @Override
      public boolean handleDialogAboutToClose(
          final IDialogResult result,
          final Component parentComponent) {
        if (result.isCanceled()) {
          return performCancel(parentComponent);
        }
        return performOk(parentComponent);
      }
    };
  }

  @Deprecated
  @Override
  public boolean performOk(final Component parentComponent) {
    return true;
  }

  @Deprecated
  @Override
  public boolean performCancel(final Component parentComponent) {
    return true;
  }

  @Override
  public Dimension getCustomizedPreferedSize() {
    return customizedPreferedSize;
  }
}