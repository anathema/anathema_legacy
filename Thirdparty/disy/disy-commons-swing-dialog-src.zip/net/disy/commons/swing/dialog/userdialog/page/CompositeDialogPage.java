/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.input.select.RadioButtonBinder;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.ui.AbstractObjectUi;
import net.disy.commons.swing.util.ToggleComponentEnabler;

public class CompositeDialogPage<R> extends AbstractDialogPage {

  private final String title;
  private final DialogPageClosureAssociation<R>[] associations;
  private final JRadioButton[] radioButtons;
  private final ObjectModel<DialogPageClosureAssociation<R>> radioGroupSelectionModel;

  public CompositeDialogPage(
      String title,
      String defaultMessageText,
      DialogPageClosureAssociation<R>... associations) {
    super(defaultMessageText);
    Ensure.ensureNotNull(associations);
    Ensure.ensureTrue("At least one dialog page must be defined.", associations.length > 0); //$NON-NLS-1$
    this.title = title;
    this.associations = associations;
    radioGroupSelectionModel = new ObjectModel<DialogPageClosureAssociation<R>>();
    radioGroupSelectionModel.setValue(associations[0]);
    RadioButtonBinder<DialogPageClosureAssociation<R>> radioButtonBinder = new RadioButtonBinder<DialogPageClosureAssociation<R>>(
        associations,
        radioGroupSelectionModel,
        new AbstractObjectUi<DialogPageClosureAssociation<R>>() {

          @Override
          public String getLabel(DialogPageClosureAssociation<R> value) {
            return value.getDescription();
          }
        });
    radioButtons = radioButtonBinder.getRadioButtons();
  }

  @Override
  public JComponent createContent() {
    JPanel panel = new JPanel(new GridDialogLayout(1, false));
    for (int i = 0; i < associations.length; i++) {
      final JRadioButton radioButton = radioButtons[i];
      IDialogPage dialogPage = associations[i].getDialogPage();
      dialogPage.setInputValidListener(getCheckInputValidListener());
      final JComponent dialogPageContent = dialogPage.createContent();
      final Action originalAction = radioButton.getAction();
      radioButton.setAction(new AbstractAction((String) originalAction.getValue(Action.NAME)) {

        @Override
        public void actionPerformed(ActionEvent e) {
          originalAction.actionPerformed(e);
          dialogPageContent.setEnabled(radioButton.isSelected());
          getCheckInputValidListener().checkInputValid();
        }
      });
      if (associations.length > 1) {
        panel.add(radioButton, GridDialogLayoutData.FILL_HORIZONTAL);
      }
      panel.add(dialogPageContent, GridDialogLayoutData.FILL_HORIZONTAL);
      ToggleComponentEnabler.connect(radioButton, dialogPageContent);
    }
    return panel;
  }

  @Override
  public String getTitle() {
    return title;
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    return radioGroupSelectionModel.getValue().getDialogPage().createCurrentMessage();
  }

  public R doPostProcessing() {
    return radioGroupSelectionModel.getValue().getClosure().execute();
  }

}
