/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.check;

import javax.swing.JCheckBox;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.action.ActionWidgetFactory;
import net.disy.commons.swing.action.SmartToggleAction;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.GridDialogLayoutDataFactory;

public class CheckBoxSmartDialogPanel extends AbstractSmartDialogPanel {

  private final JCheckBox checkBox;
  private final BooleanModel model;

  public CheckBoxSmartDialogPanel(final BooleanModel model, final String label) {
    this.model = model;
    Ensure.ensureArgumentNotNull(model);
    checkBox = ActionWidgetFactory.createCheckBox(new SmartToggleAction(model, label));
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return null;
  }

  @Override
  public void requestFocus() {
    checkBox.requestFocus();
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final GridDialogLayoutData layoutData = GridDialogLayoutDataFactory
        .createHorizontalSpanData(columnCount);
    panel.add(checkBox, layoutData);
  }

  @Override
  public int getColumnCount() {
    return 1;
  }

  public void setEnabled(final boolean value) {
    checkBox.setEnabled(value);
  }

  public void setToolTip(final String toolTip) {
    checkBox.setToolTipText(toolTip);
  }
}