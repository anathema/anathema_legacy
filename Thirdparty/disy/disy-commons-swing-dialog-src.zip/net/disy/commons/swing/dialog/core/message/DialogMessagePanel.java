package net.disy.commons.swing.dialog.core.message;

import javax.swing.JComponent;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.dialog.animation.AnimatedCompositeComponent;
import net.disy.commons.swing.dialog.animation.OverlaidComponentBorder;

public class DialogMessagePanel {

  private final DialogMessageModel messageModel;
  private final DialogMessageComponent baseMessageComponent;
  private final DialogMessageComponent overlaidMessageComponent;
  private final AnimatedCompositeComponent content;

  public DialogMessagePanel(DialogMessageModel messageModel) {
    Ensure.ensureArgumentNotNull(messageModel);
    this.messageModel = messageModel;
    baseMessageComponent = new DialogMessageComponent(false);
    overlaidMessageComponent = new DialogMessageComponent(true);
    overlaidMessageComponent.setBorder(new OverlaidComponentBorder());

    this.content = new AnimatedCompositeComponent(baseMessageComponent, overlaidMessageComponent);

    messageModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateMessage();
      }
    });
    updateMessage();
  }

  private void updateMessage() {
    baseMessageComponent.setMessage(messageModel.getBaseMessage());
    overlaidMessageComponent.setMessage(messageModel.getOverlaidMessage());
    content.setOverlaidComponentVisible(messageModel.isOverlaidMessageActive());
  }

  public JComponent getContent() {
    return content;
  }
}