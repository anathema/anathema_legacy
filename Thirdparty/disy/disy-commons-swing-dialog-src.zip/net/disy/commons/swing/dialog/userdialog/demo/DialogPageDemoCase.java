/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.demo;

import net.disy.commons.swing.dialog.core.AbstractDialog;
import net.disy.commons.swing.dialog.core.DialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.IDialogHeaderPanelConfiguration;
import net.disy.commons.swing.dialog.core.ISwingFrameOrDialog;
import net.disy.commons.swing.dialog.userdialog.DefaultDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.IDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;
import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import de.jdemo.extensions.SwingDemoCase;

public abstract class DialogPageDemoCase extends SwingDemoCase {

  protected final void show(final IDialogConfiguration<?> configuration) {
    final UserDialog dialog = new UserDialog(createParentComponent(), configuration);
    show(dialog);
  }

  protected final void show(final AbstractDialog dialog) {
    show(dialog.getDialog().getWindow());
  }

  protected final void show(final IDialogPage dialogPage, final boolean headerPanelVisible) {
    final IDialogConfiguration<IDialogPage> dialogConfiguration = new DefaultDialogConfiguration<IDialogPage>(
        dialogPage) {
      @Override
      public IDialogHeaderPanelConfiguration getHeaderPanelConfiguration() {
        return headerPanelVisible
            ? DialogHeaderPanelConfiguration.createVisibleWithoutIcon()
            : DialogHeaderPanelConfiguration.createInvisible();
      }
    };

    final ISwingFrameOrDialog dialog = new UserDialog(createJFrame(), dialogConfiguration).getDialog();
    dialog.setModal(false);
    show(dialog.getWindow());
  }

  protected final void show(final IDialogPage dialogPage) {
    show(dialogPage, true);
  }

  protected final void show(final IDialogComponent component) {
    final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
    builder.add(component);
    show(builder.createPanel());
  }

}