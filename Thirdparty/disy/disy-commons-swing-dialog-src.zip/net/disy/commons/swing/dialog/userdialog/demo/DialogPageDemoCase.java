//Copyright (c) 2004 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog.demo;

import net.disy.commons.swing.dialog.userdialog.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public abstract class DialogPageDemoCase extends SwingDemoCase {

  protected void show(IDialogPage page) {
    UserDialog dialog = new UserDialog(createParentComponent(), page);
    show(dialog.getDialog().getWindow());
  }
}