/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.message;

import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JComponent;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.BooleanModel;
import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogMessages;
import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.userdialog.UserDialog;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

public class MessageDialogUtilities {

  public static boolean showDialog(
      final Component parent,
      final IMessage message,
      final IDialogButtonConfiguration buttonConfiguration) {
    final MessageUserDialogConfiguration configuration = new MessageUserDialogConfiguration(
        message,
        buttonConfiguration);
    final UserDialog userDialog = new UserDialog(parent, configuration);
    final IDialogResult result = userDialog.show();
    return !result.isCanceled();
  }

  public static YesNoCancel showYesNoCancelDialog(final Component parent, final IMessage message) {
    final BooleanModel noPressedModel = new BooleanModel(false);
    final IDialogButtonConfiguration buttonConfiguration = DialogButtonConfigurationFactory
        .createYesCancel();
    final MessageUserDialogConfiguration configuration = new MessageUserDialogConfiguration(
        message,
        buttonConfiguration) {
      @Override
      public JComponent[] createAdditionalButtons() {
        return new JComponent[]{ new JButton(new SmartAction(DisyCommonsSwingDialogMessages.NO) {
          @Override
          protected void execute(final Component parentComponent) {
            noPressedModel.setValue(true);
            getDialogContainer().requestFinish();
          }
        }) };
      }
    };
    final UserDialog userDialog = new UserDialog(parent, configuration);
    final IDialogResult result = userDialog.show();
    if (result.isCanceled()) {
      return YesNoCancel.CANCEL;
    }
    if (noPressedModel.getValue()) {
      return YesNoCancel.NO;
    }
    return YesNoCancel.YES;
  }

  public static boolean confirmUserOperation(
      final Component parent,
      final String message,
      final String title) {
    return showYesNoDialog(parent, new Message(title, message, MessageType.QUESTION));
  }

  public static boolean confirmUserOperation(final Component parent, final String message) {
    return showYesNoDialog(parent, new Message(message, MessageType.QUESTION));
  }

  public static boolean showYesNoDialog(final Component parent, final IMessage message) {
    return showDialog(parent, message, DialogButtonConfigurationFactory.createYesNo());
  }

  public static boolean showOkCancelDialog(final Component parent, final Message message) {
    return showDialog(parent, message, DialogButtonConfigurationFactory.createOkCancel());
  }
}