/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.test;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;

public class TestDialogPage extends AbstractDialogPage {

  public IBasicMessage currentMessage;

  public TestDialogPage() {
    super("Hallo"); //$NON-NLS-1$
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    if (currentMessage == null) {
      return getDefaultMessage();
    }
    return currentMessage;
  }

  @Override
  public JComponent createContent() {
    return new JPanel();
  }

  @Override
  public String getTitle() {
    return "Title"; //$NON-NLS-1$
  }
}