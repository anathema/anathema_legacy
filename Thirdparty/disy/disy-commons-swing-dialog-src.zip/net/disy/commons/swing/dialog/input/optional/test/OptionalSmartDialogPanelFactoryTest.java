/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional.test;

import static net.disy.commons.testing.Assert.assertNotEquals;
import static org.easymock.EasyMock.createMock;
import static org.easymock.EasyMock.expect;
import static org.easymock.EasyMock.replay;
import static org.easymock.EasyMock.verify;
import static org.hamcrest.Matchers.instanceOf;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThat;

import java.util.Calendar;
import java.util.Date;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.combo.BooleanModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.date.DateSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.ByteModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.DoubleModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.IntegerModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.LongModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.number.ShortModelSmartDialogPanel;
import net.disy.commons.swing.dialog.input.optional.IOptionalSmartDialogPanel;
import net.disy.commons.swing.dialog.input.optional.OptionalSmartDialogPanelFactory;
import net.disy.commons.swing.dialog.input.text.DefaultTextSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;

import org.junit.Before;
import org.junit.Test;

public class OptionalSmartDialogPanelFactoryTest {

  private final String printName = "printName"; //$NON-NLS-1$
  private IMessageProducingValidator validator;
  private IOptionalSmartDialogPanel optionalPanel;

  @Before
  public void init() throws Exception {
    validator = createMock(IMessageProducingValidator.class);
  }

  @Test
  public void createBooleanPanel() throws Exception {
    final ObjectModel<Boolean> expectedModel = new ObjectModel<Boolean>(Boolean.TRUE);
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        BooleanModelSmartDialogPanel.class).createBooleanPanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createBytePanel() throws Exception {
    final ObjectModel<Byte> expectedModel = new ObjectModel<Byte>(new Byte((byte) 42));
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        ByteModelSmartDialogPanel.class).createBytePanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createDatePanel() throws Exception {
    final ObjectModel<Date> expectedModel = new ObjectModel<Date>(Calendar.getInstance().getTime());
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        DateSmartDialogPanel.class).createDatePanel(expectedModel, false, "yyyy"); //$NON-NLS-1$
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createDoublePanel() throws Exception {
    final ObjectModel<Double> expectedModel = new ObjectModel<Double>(new Double(42.0));
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        DoubleModelSmartDialogPanel.class).createDoublePanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createIntegerPanel() throws Exception {
    final ObjectModel<Integer> expectedModel = new ObjectModel<Integer>(new Integer(42));
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        IntegerModelSmartDialogPanel.class).createIntegerPanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createLongPanel() throws Exception {
    final ObjectModel<Long> expectedModel = new ObjectModel<Long>(new Long(42));
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        LongModelSmartDialogPanel.class).createLongPanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createShortPanel() throws Exception {
    final ObjectModel<Short> expectedModel = new ObjectModel<Short>(new Short((short) 42));
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        ShortModelSmartDialogPanel.class).createShortPanel(expectedModel, false);
    assertSame(optionalPanel, panel);
  }

  @Test
  public void createStringPanel() throws Exception {
    final ObjectModel<String> expectedModel = new ObjectModel<String>("text"); //$NON-NLS-1$
    final IOptionalSmartDialogPanel panel = new TestOptionalSmartDialogPanelFactory(
        expectedModel,
        DefaultTextSmartDialogPanel.class).createStringPanel(expectedModel, false, null, null);
    assertSame(optionalPanel, panel);
  }

  private class TestOptionalSmartDialogPanelFactory extends OptionalSmartDialogPanelFactory {

    private final ObjectModel<?> expectedModel;
    private final Class<? extends AbstractLabeledSmartDialogPanel> expectedPanelClass;

    public <T> TestOptionalSmartDialogPanelFactory(
        final ObjectModel<T> expectedModel,
        final Class<? extends AbstractLabeledSmartDialogPanel> expectedPanelClass) {
      super(printName, validator);
      this.expectedModel = expectedModel;
      this.expectedPanelClass = expectedPanelClass;
    }

    @Override
    protected <T> IOptionalSmartDialogPanel createOptionalPanel(
        final ObjectModel<T> model,
        final boolean mandatory,
        final IUpdatableSmartDialogPanel dialogPanel,
        final ObjectModel<T> fieldModel) {
      assertSame(expectedModel, model);
      assertNotEquals(expectedModel, fieldModel);
      assertEquals(expectedModel.getValue(), fieldModel.getValue());
      assertThat(dialogPanel, is(instanceOf(expectedPanelClass)));
      final IBasicMessage message = createMock(IBasicMessage.class);
      expect(validator.createOptionalCurrentMessage()).andReturn(message);
      replay(validator);
      assertSame(message, dialogPanel.createOptionalCurrentMessage());
      verify(validator);
      return optionalPanel;
    }
  }
}
