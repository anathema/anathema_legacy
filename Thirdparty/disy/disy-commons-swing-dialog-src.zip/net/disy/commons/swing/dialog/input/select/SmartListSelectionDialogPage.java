/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import net.disy.commons.core.model.FixedOptionsObjectSelectionModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

//TODO 14.06.2011 (gebhard): Duplicated in ListSelectionDialogPage
public class SmartListSelectionDialogPage<T> extends SmartDialogPage {

  private final IListSelectionDialogConfiguration<T> configuration;
  private final ObjectModel<T> model;
  private ListSelectionDialogPanel<T> outputTargetPanel;

  public SmartListSelectionDialogPage(
      final IListSelectionDialogConfiguration<T> configuration,
      final ObjectModel<T> model) {
    super(configuration.getDefaultMessageText());
    this.model = model;
    this.configuration = configuration;
  }

  @Override
  public final String getTitle() {
    return configuration.getTitle();
  }

  @Override
  public String getDescription() {
    return configuration.getDescription();
  }

  @Override
  public void requestFocus() {
    outputTargetPanel.requestFocus();
  }

  @Override
  protected void addPanels(final ISmartDialogPanelsBuilder builder) {
    final FixedOptionsObjectSelectionModel<T> outputTargetSelectionModel = new FixedOptionsObjectSelectionModel<T>(
        configuration.getItems());
    outputTargetSelectionModel.setSelectedValue(model.getValue());
    outputTargetSelectionModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        model.setValue(outputTargetSelectionModel.getFirstSelectedValue());
      }
    });
    this.outputTargetPanel = new ListSelectionDialogPanel<T>(
        outputTargetSelectionModel,
        configuration);
    builder.add(outputTargetPanel);
  }
}