/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import javax.swing.JPanel;

import net.disy.commons.core.util.Ensure;

public class SmartDialogPanelsBuildResult {

  private final ISmartDialogPanel[] panels;
  private final JPanel panel;

  public SmartDialogPanelsBuildResult(final ISmartDialogPanel[] panels, final JPanel panel) {
    Ensure.ensureArgumentNotNull(panels);
    Ensure.ensureArgumentArrayContentsNotNull(panels);
    Ensure.ensureArgumentNotNull(panel);
    this.panels = panels;
    this.panel = panel;
  }

  public ISmartDialogPanel[] getPanels() {
    return panels;
  }

  public JPanel getCompletePanel() {
    return panel;
  }
}