/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import javax.swing.JPasswordField;
import javax.swing.JTextField;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.swing.dialog.input.text.component.IStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.IStringInputComponent;
import net.disy.commons.swing.dialog.input.text.component.StringTextField;

public class PasswordSmartDialogPanel extends AbstractTextSmartDialogPanel {

  public PasswordSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator) {
    this(label, null, stringModel, validator);
  }

  public PasswordSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, stringModel, validator, true);
  }

  public PasswordSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    super(label, toolTipText, stringModel, new IStringAttributeInputComponentFactory<JTextField>() {
      @Override
      public IStringInputComponent<JTextField> createComponent() {
        return new StringTextField<JTextField>(new JPasswordField());
      }
    }, validator, grabSpace);
  }
}