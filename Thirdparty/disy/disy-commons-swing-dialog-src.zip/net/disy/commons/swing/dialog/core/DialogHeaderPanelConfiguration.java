/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.core;

import javax.swing.Icon;

import net.disy.commons.core.util.Ensure;

public class DialogHeaderPanelConfiguration implements IDialogHeaderPanelConfiguration {

  public static IDialogHeaderPanelConfiguration createVisibleWithoutIcon() {
    return new DialogHeaderPanelConfiguration(null, true);
  }

  public static IDialogHeaderPanelConfiguration createVisibleWithIcon(final Icon icon) {
    Ensure.ensureArgumentNotNull(icon);
    return new DialogHeaderPanelConfiguration(icon, true);
  }

  public static IDialogHeaderPanelConfiguration createInvisible() {
    return new DialogHeaderPanelConfiguration(null, false);
  }

  private final Icon icon;
  private final boolean visible;

  private DialogHeaderPanelConfiguration(final Icon icon, final boolean visible) {
    this.icon = icon;
    this.visible = visible;
  }

  @Override
  public Icon getLargeDialogIcon() {
    return icon;
  }

  @Override
  public boolean isHeaderPanelVisible() {
    return visible;
  }
}