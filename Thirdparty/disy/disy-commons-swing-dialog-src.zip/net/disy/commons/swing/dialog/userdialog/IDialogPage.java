// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 24.02.2005
package net.disy.commons.swing.dialog.userdialog;

import javax.swing.JComponent;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.core.IDialogContainer;
import net.disy.commons.swing.events.CheckInputValidListener;

// NOT_PUBLISHED
public interface IDialogPage {

  /** Gibt die zum aktuellen Dialogzustand passende Meldung zur�ck. Der Typ der Message entscheidet,
   * ob im Dialog der Ok-Button enabled ist (disabled bei <code>MessageType.ERROR</code>).
   * Die Meldung wird auch zur Anzeige des Dialogzustands f�r den Benutzer verwendet.
   * Bei der Implementierung der Methode sollte darauf geachtet werden, dass der Zustand der
   * Eingabeelemente von oben nach unten �berpr�ft wird, ausserdem m�ssen Fehler vor Warnungen und
   * Informationsmeldungen �berpr�ft werden.
   * Wird keine Fehler oder aehnliches gefunden, so sollte die Methode {@link #getDefaultMessage()}
   * zur�ckgeben. */
  public IBasicMessage createCurrentMessage();

  public IBasicMessage getDefaultMessage();

  public String getDescription();

  public String getTitle();

  public void requestFocus();

  public JComponent createContent();

  public void setInputValidListener(CheckInputValidListener inputValidListener);

  public boolean isHelpAvailable();

  public void performHelp();

  /**
   * @deprecated
   */
  public boolean performCancel();

  /**
   * @deprecated
   */
  public boolean performOk();

  public void setContainer(IDialogContainer container);

  public void updateInputValid();
  
  public void dispose();

  public boolean canFinish();
}