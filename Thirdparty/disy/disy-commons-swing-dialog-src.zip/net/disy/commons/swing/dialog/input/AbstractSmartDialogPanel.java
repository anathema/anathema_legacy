// Copyright (c) 2006 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input;

import net.disy.commons.core.model.listener.IListenerClosure;
import net.disy.commons.core.model.listener.ListenerList;

//NOT_PUBLISHED
public abstract class AbstractSmartDialogPanel implements ISmartDialogPanel {
  private transient ListenerList<IRequestFinishListener> listeners = new ListenerList<IRequestFinishListener>();

  public void addRequestFinishListener(IRequestFinishListener listener) {
    listeners.add(listener);
  }

  public void removeRequestFinishListener(IRequestFinishListener listener) {
    listeners.remove(listener);
  }

  protected void fireRequestFinish() {
    listeners.forAllDo(new IListenerClosure<IRequestFinishListener>() {
      public void execute(IRequestFinishListener listener) {
        listener.requestFinish();
      }
    });
  }
}