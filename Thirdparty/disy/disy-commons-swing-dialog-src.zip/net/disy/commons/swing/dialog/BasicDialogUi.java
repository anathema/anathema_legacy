// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 17.01.2005
package net.disy.commons.swing.dialog;

import net.disy.commons.core.exception.UnreachableCodeReachedException;

/** @deprecated As of 10.01.2006 (gebhard), replaced by {@link BasicDialogResources}*/
public class BasicDialogUi extends BasicDialogResources {

  private BasicDialogUi() {
    throw new UnreachableCodeReachedException();
  }
}