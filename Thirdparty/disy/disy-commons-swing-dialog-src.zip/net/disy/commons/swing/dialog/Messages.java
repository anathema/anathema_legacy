// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 14.01.2005
package net.disy.commons.swing.dialog;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

// NOT_PUBLISHED
public class Messages {
  private static final String BUNDLE_NAME = "net.disy.commons.swing.dialog.messages";//$NON-NLS-1$

  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(
      BUNDLE_NAME,
      Locale.getDefault());

  public static String getString(String key) {
    return RESOURCE_BUNDLE.getString(key);
  }

  public String getString(String key, Object[] arguments) {
    String value = getString(key);
    if (value == null) {
      return null;
    }
    return MessageFormat.format(value, arguments);
  }
}
