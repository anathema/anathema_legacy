/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color.demo;

import java.awt.Color;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.IconedColorChooserButton;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class IconedColorChooserButtonDemo extends SwingDemoCase {

  public void demoTextColorChooserButton() {
    show(IconedColorChooserButton.createTextColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }

  public void demoTextColorChooserDropDownButton() {
    show(IconedColorChooserButton.createTextColorChooserButton(
        new ColorModel(Color.RED),
        new IconedColorChooserButton.DropDownStrategy(false)).getContent());
  }

  public void demoTextColorChooserDropDownButtonWithTransparency() {
    show(IconedColorChooserButton.createTextColorChooserButton(
        new ColorModel(Color.RED),
        new IconedColorChooserButton.DropDownStrategy(true)).getContent());
  }

  public void demoMarkerColorChooserButton() {
    show(IconedColorChooserButton.createMarkerColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }

  public void demoBackgroundColorChooserButton() {
    show(IconedColorChooserButton.createBackgroundColorChooserButton(
        new ColorModel(Color.RED),
        IconedColorChooserButton.DIRECT).getContent());
  }
}