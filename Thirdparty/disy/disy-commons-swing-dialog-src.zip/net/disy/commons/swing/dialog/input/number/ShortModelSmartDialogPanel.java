/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.number;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;

public class ShortModelSmartDialogPanel extends IntegralNumberSmartDialogPanel<Short> {

  public ShortModelSmartDialogPanel(
      final String label,
      final ObjectModel<Short> model,
      final IMessageProducingValidator validator) {
    this(label, null, model, validator);
  }

  public ShortModelSmartDialogPanel(
      final String label,
      String toolTipText,
      final ObjectModel<Short> model,
      final IMessageProducingValidator validator) {
    super(label, toolTipText, model, validator, new Short((short) 0), Short
        .valueOf(Short.MIN_VALUE), Short.valueOf(Short.MAX_VALUE));
  }

  @Override
  protected Short convertToNumber(final Long value) {
    return Short.valueOf(value.shortValue());
  }
}