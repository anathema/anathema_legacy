//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import java.awt.Component;

import net.disy.commons.swing.dialog.userdialog.UserDialog;

// NOT_PUBLISHED
public class SmartTextInputDialog {

  private SmartTextInputDialog() {
    //no instance available
  }

  public static ITextInputDialogResult showTextInputDialog(
      Component parentComponent,
      final ITextInputDialogConfiguration configuration,
      String initialText) {
    TextInputDialogPage page = new TextInputDialogPage(configuration, initialText);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    dialog.show();
    final String selectedText = page.getSelectedText();
    return new ITextInputDialogResult() {
      public boolean isCanceled() {
        return dialog.isCanceled();
      }

      public String getText() {
        return selectedText;
      }
    };
  }

  public static UserDialog createDemoDialog(
      Component parentComponent,
      ITextInputDialogConfiguration configuration,
      String initialText) {
    TextInputDialogPage page = new TextInputDialogPage(configuration, initialText);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    return dialog;
  }
}