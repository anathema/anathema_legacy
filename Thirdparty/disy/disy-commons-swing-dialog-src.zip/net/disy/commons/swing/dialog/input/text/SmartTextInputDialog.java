/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import java.awt.Component;

import net.disy.commons.swing.dialog.core.IDialogResult;
import net.disy.commons.swing.dialog.userdialog.UserDialog;

public class SmartTextInputDialog {

  private SmartTextInputDialog() {
    //no instance available
  }

  public static ITextInputDialogResult showTextInputDialog(
      final Component parentComponent,
      final ITextInputDialogConfiguration configuration,
      final String initialText) {
    final TextInputDialogPage page = new TextInputDialogPage(configuration, initialText);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    final IDialogResult result = dialog.show();
    final String selectedText = page.getSelectedText();
    return new ITextInputDialogResult() {
      @Override
      public boolean isCanceled() {
        return result.isCanceled();
      }

      @Override
      public String getText() {
        return selectedText;
      }
    };
  }

  public static UserDialog createDemoDialog(
      final Component parentComponent,
      final ITextInputDialogConfiguration configuration,
      final String initialText) {
    final TextInputDialogPage page = new TextInputDialogPage(configuration, initialText);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    return dialog;
  }
}