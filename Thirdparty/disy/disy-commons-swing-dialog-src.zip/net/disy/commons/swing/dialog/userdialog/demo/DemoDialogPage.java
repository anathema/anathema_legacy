/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.demo;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;

public class DemoDialogPage extends AbstractDialogPage {

  private static final BasicMessage WARNING_MESSAGE_TOO_SHORT = new BasicMessage(
      "The name is discouraged, names should be at least 4 characters long.", //$NON-NLS-1$
      MessageType.WARNING);
  private static final BasicMessage ERROR_MESSAGE_EMPTY = new BasicMessage(
      "The name may not be empty. Please enter a valid name.", MessageType.ERROR); //$NON-NLS-1$
  private static final String DEFAULT_MESSAGE_TEXT = "Default message describing some details about this dialog and what to do."; //$NON-NLS-1$

  private JTextField textField;

  public DemoDialogPage() {
    super(DEFAULT_MESSAGE_TEXT);
  }

  @Override
  public JComponent createContent() {
    final JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JLabel("Name:")); //$NON-NLS-1$
    textField = new JTextField(20);
    textField.getDocument().addDocumentListener(getCheckInputValidListener());
    panel.add(textField, GridDialogLayoutData.FILL_HORIZONTAL);
    return panel;
  }

  @Override
  public String getDescription() {
    return "Description Label"; //$NON-NLS-1$
  }

  @Override
  public String getTitle() {
    return "Dialog Title"; //$NON-NLS-1$
  }

  @Override
  public void requestFocus() {
    textField.requestFocus();
  }

  @Override
  public IBasicMessage createCurrentMessage() {
    if (textField.getText().length() == 0) {
      return ERROR_MESSAGE_EMPTY;
    }
    else if (textField.getText().length() < 4) {
      return WARNING_MESSAGE_TOO_SHORT;
    }
    else {
      return getDefaultMessage();
    }
  }
}