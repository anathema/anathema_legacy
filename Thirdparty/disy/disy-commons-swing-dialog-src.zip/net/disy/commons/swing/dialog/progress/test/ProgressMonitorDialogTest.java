/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress.test;

import static org.junit.Assert.*;

import java.lang.reflect.InvocationTargetException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

import net.disy.commons.core.progress.IInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.INonInterruptableRunnableWithProgress;
import net.disy.commons.core.progress.IObservableCancelable;
import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.util.IExceptionThrowingBlock;
import net.disy.commons.swing.dialog.progress.InternalProgressDialog;
import net.disy.commons.swing.dialog.progress.ProgressMonitorDialog;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class ProgressMonitorDialogTest {

  private JFrame frame;

  @Before
  public void setUp() throws Exception {
    frame = new JFrame();
    frame.setVisible(true);
  }

  @After
  public void tearDown() throws Exception {
    frame.dispose();
  }

  @Test(expected = IllegalArgumentException.class)
  public void testIllegalRun() {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    try {
      dialog.run((IInterruptableRunnableWithProgress) null);
    }
    catch (final InterruptedException e) {
      fail();
    }
    catch (final InvocationTargetException e) {
      fail();
    }
  }

  @Test
  public void testRunsWithInternalProgressDialog() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.run(new INonInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor) {
        assertNotNull(monitor);
        assertTrue(monitor instanceof InternalProgressDialog);
        assertFalse(((InternalProgressDialog) monitor).isCanceled());
        final InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertFalse(internalDialog.getTestIsCancelable());
      }
    });
  }

  @Test
  public void testRunsWithInternalProgressDialogCancelable()
      throws InterruptedException,
      InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.run(new IInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable) {
        final InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertTrue(internalDialog.getTestIsCancelable());
      }
    });
  }

  @Test
  @Ignore("Test ist unzuverlässig")
  public void _testInternalProgressDialogBecomesVisibleAfterDelay()
      throws InterruptedException,
      InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    dialog.run(new IInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
          throws InterruptedException {
        final InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertFalse(internalDialog.getTestIsDialogVisible());
        Thread.sleep(2000);
        assertTrue(internalDialog.getTestIsDialogVisible());
      }
    });
  }

  @Test
  public void testInterruptionPropagated() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final InterruptedException interruptedException = new InterruptedException();
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InterruptedException {
          throw interruptedException;
        }
      });
      fail("InterruptedException expected"); //$NON-NLS-1$
    }
    catch (final InterruptedException e) {
      assertSame(interruptedException, e);
    }
  }

  @Test
  public void testInvocationTargetExceptionPropagated() throws InterruptedException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final InvocationTargetException invocationTargetException = new InvocationTargetException(
        new RuntimeException());
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
            throws InvocationTargetException {
          throw invocationTargetException;
        }
      });
      fail("InvocationTargetException expected"); //$NON-NLS-1$
    }
    catch (final InvocationTargetException e) {
      assertSame(invocationTargetException, e);
    }
  }

  @Test
  public void testRuntimeExeptionPropagatedAsRuntimeException()
      throws InterruptedException,
      InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final RuntimeException runtimeException = new RuntimeException();
    try {
      dialog.run(new IInterruptableRunnableWithProgress() {
        @Override
        public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable) {
          runtimeException.fillInStackTrace();
          throw runtimeException;
        }
      });
      fail("RuntimeException expected"); //$NON-NLS-1$
    }
    catch (final RuntimeException e) {
      assertSame(runtimeException, e);
    }
  }

  @Test
  public void testRunsSynchrounously() throws InterruptedException, InvocationTargetException {
    final boolean[] finished = new boolean[]{ false };
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    dialog.run(new IInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor, final IObservableCancelable cancelable)
          throws InterruptedException {
        Thread.sleep(1000);
        finished[0] = true;
      }
    });
    assertTrue(finished[0]);
  }

  @Test(expected = IllegalStateException.class)
  public void testIllegalStateWhenMultipleCallsToRun() throws InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    final INonInterruptableRunnableWithProgress nullRunnable = new INonInterruptableRunnableWithProgress() {
      @Override
      public void run(final IProgressMonitor monitor) {
        //nothing to do
      }
    };
    dialog.run(nullRunnable);
    try {
      dialog.run(nullRunnable);
    }
    catch (final InvocationTargetException e) {
      fail();
    }
  }

  @Test
  public void testStressTest() {
    for (int i = 0; i < 100; ++i) {
      final IExceptionThrowingBlock block = new IExceptionThrowingBlock() {
        @Override
        public void execute() {
          final InternalProgressDialog[] internalDialog = new InternalProgressDialog[1];
          final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
          dialog.setMillisecondsUntilDialogPopup(getRandomInt(50));
          try {
            dialog.run(new INonInterruptableRunnableWithProgress() {
              @Override
              public void run(final IProgressMonitor monitor) {
                internalDialog[0] = (InternalProgressDialog) monitor;
                try {
                  Thread.sleep(getRandomInt(50));
                }
                catch (final InterruptedException e) {
                  throw new RuntimeException(e);
                }
              }
            });
          }
          catch (final InvocationTargetException e) {
            fail();
          }
          assertFalse(internalDialog[0].getTestIsDialogVisible());
        }
      };
      assertFinishedWithin(block, 1000);
    }
  }

  private void assertFinishedWithin(
      final IExceptionThrowingBlock<RuntimeException> block,
      final int timeOut) {
    final Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      @Override
      public void run() {
        fail("Expected to finish within " + timeOut + "ms, but did not."); //$NON-NLS-1$ //$NON-NLS-2$
      }
    }, timeOut);
    block.execute();
    timer.cancel();
  }

  private static int getRandomInt(final int median) {
    return (int) (median / 3.0 * (Math.random() - 0.5)) + median;
  }
}