package net.disy.commons.swing.dialog.progress.test;

import java.lang.reflect.InvocationTargetException;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JFrame;

import net.disy.commons.core.progress.IProgressMonitor;
import net.disy.commons.core.progress.IRunnableWithProgress;
import net.disy.commons.core.testing.CoreTestCase;
import net.disy.commons.core.util.ISimpleBlock;
import net.disy.commons.swing.dialog.progress.InternalProgressDialog;
import net.disy.commons.swing.dialog.progress.ProgressMonitorDialog;

public class ProgressMonitorDialogTest extends CoreTestCase {

  private JFrame frame;

  protected void setUp() throws Exception {
    super.setUp();
    frame = new JFrame();
    frame.setVisible(true);
  }

  protected void tearDown() throws Exception {
    super.tearDown();
    frame.dispose();
  }

  public void testIllegalRun() {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    assertThrowsException(IllegalArgumentException.class, new ISimpleBlock() {
      public void execute() {
        try {
          dialog.run(true, null);
        }
        catch (InterruptedException e) {
          fail();
        }
        catch (InvocationTargetException e) {
          fail();
        }
      }
    });
  }

  public void testRunsWithInternalProgressDialog() throws InterruptedException, InvocationTargetException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.run(false, new IRunnableWithProgress() {
      public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
        assertNotNull(monitor);
        assertFalse(monitor.isCanceled());
        assertTrue(monitor instanceof InternalProgressDialog);
        InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertFalse(internalDialog.getTestIsCancelable());
      }
    });
  }

  public void testRunsWithInternalProgressDialogCancelable()
      throws InterruptedException,
      InvocationTargetException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.run(true, new IRunnableWithProgress() {
      public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
        InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertTrue(internalDialog.getTestIsCancelable());
      }
    });
  }

  public void testInternalProgressDialogBecomesVisibleAfterDelay()
      throws InterruptedException,
      InvocationTargetException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    dialog.run(true, new IRunnableWithProgress() {
      public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
        InternalProgressDialog internalDialog = (InternalProgressDialog) monitor;
        assertFalse(internalDialog.getTestIsDialogVisible());
        Thread.sleep(1000);
        assertTrue(internalDialog.getTestIsDialogVisible());
      }
    });
  }

  public void testInterruptionPropagated() throws InvocationTargetException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final InterruptedException interruptedException = new InterruptedException();
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
          throw interruptedException;
        }
      });
      fail("InterruptedException expected"); //$NON-NLS-1$
    }
    catch (InterruptedException e) {
      assertSame(interruptedException, e);
    }
  }

  public void testInvocationTargetExceptionPropagated() throws InterruptedException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final InvocationTargetException invocationTargetException = new InvocationTargetException(
        new RuntimeException());
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
          throw invocationTargetException;
        }
      });
      fail("InvocationTargetException expected"); //$NON-NLS-1$
    }
    catch (InvocationTargetException e) {
      assertSame(invocationTargetException, e);
    }
  }

  public void testRuntimeExptionPropagatedAsInvocationTargetException() throws InterruptedException {
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    final RuntimeException runtimeException = new RuntimeException();
    try {
      dialog.run(true, new IRunnableWithProgress() {
        public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
          throw runtimeException;
        }
      });
      fail("InvocationTargetException expected"); //$NON-NLS-1$
    }
    catch (InvocationTargetException e) {
      assertSame(runtimeException, e.getCause());
    }
  }

  public void testRunsSynchrounously() throws InterruptedException, InvocationTargetException {
    final boolean[] finished = new boolean[]{ false };
    ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    dialog.setMillisecondsUntilDialogPopup(500);
    dialog.run(true, new IRunnableWithProgress() {
      public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
        Thread.sleep(1000);
        finished[0] = true;
      }
    });
    assertTrue(finished[0]);
  }

  public void testIllegalStateWhenMultipleCallsToRun() throws InterruptedException, InvocationTargetException {
    final ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
    final IRunnableWithProgress nullRunnable = new IRunnableWithProgress() {
      public void run(IProgressMonitor monitor) {
        //nothing to do
      }
    };
    dialog.run(false, nullRunnable);
    assertThrowsException(IllegalStateException.class, new ISimpleBlock() {
      public void execute() {
        try {
          dialog.run(false, nullRunnable);
        }
        catch (InterruptedException e) {
          fail();
        }
        catch (InvocationTargetException e) {
          fail();
        }
      }
    });
  }

  public void testStressTest() {
    for (int i = 0; i < 100; ++i) {
      ISimpleBlock block = new ISimpleBlock() {
        public void execute() {
          final InternalProgressDialog[] internalDialog = new InternalProgressDialog[1];
          ProgressMonitorDialog dialog = new ProgressMonitorDialog(frame, "progress"); //$NON-NLS-1$
          dialog.setMillisecondsUntilDialogPopup(getRandomInt(50));
          try {
            dialog.run(true, new IRunnableWithProgress() {
              public void run(IProgressMonitor monitor) throws InterruptedException, InvocationTargetException {
                internalDialog[0] = (InternalProgressDialog) monitor;
                Thread.sleep(getRandomInt(50));
              }
            });
          }
          catch (InterruptedException e) {
            fail();
          }
          catch (InvocationTargetException e) {
            fail();
          }
          assertFalse(internalDialog[0].getTestIsDialogVisible());
        }
      };
      assertFinishedWithin(block, 1000);
    }
  }

  private void assertFinishedWithin(ISimpleBlock block, final int timeOut) {
    Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      public void run() {
        fail("Expected to finish within " + timeOut + "ms, but did not."); //$NON-NLS-1$ //$NON-NLS-2$
      }
    }, timeOut);
    block.execute();
    timer.cancel();
  }

  private static int getRandomInt(final int median) {
    return (int) (median / 3.0 * (Math.random() - 0.5)) + median;
  }
}