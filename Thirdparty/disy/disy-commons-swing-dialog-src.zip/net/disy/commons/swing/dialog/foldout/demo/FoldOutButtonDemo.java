// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout.demo;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutPage;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutDialogConfiguration;
import net.disy.commons.swing.dialog.foldout.FoldOutDialog;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.foldout.IFoldOutDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.dialog.userdialog.IDialogPage;

import de.jdemo.extensions.SwingDemoCase;

// NOT_PUBLISHED
public class FoldOutButtonDemo extends SwingDemoCase {

  public void demo() {
    IDialogPage dialogPage = new AbstractDialogPage(new BasicMessage("Default message...")) { //$NON-NLS-1$
      public JComponent createContent() {
        return new JLabel("Ich bin der Inhalt"); //$NON-NLS-1$
      }

      public IBasicMessage createCurrentMessage() {
        return getDefaultMessage();
      }

      public String getDescription() {
        return "Description"; //$NON-NLS-1$
      }

      public String getTitle() {
        return "Title"; //$NON-NLS-1$
      }

    };
    IFoldOutPage foldOutPage = new AbstractFoldOutPage() {
      private JTextArea textArea;

      protected JComponent createContent() {
        textArea = new JTextArea(5, 40);
        return new JScrollPane(textArea);
      }

      public void requestFocus() {
        textArea.requestFocus();
      }
    };

    IFoldOutDialogConfiguration userDialog = new AbstractFoldOutDialogConfiguration(dialogPage, foldOutPage) {
      //nothing to do
    };

    show(new FoldOutDialog(createJFrame(), userDialog).getDialog().getWindow());
  }
}