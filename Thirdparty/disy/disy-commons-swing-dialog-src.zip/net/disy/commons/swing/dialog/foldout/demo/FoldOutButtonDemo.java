/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.foldout.demo;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutDialogConfiguration;
import net.disy.commons.swing.dialog.foldout.AbstractFoldOutPage;
import net.disy.commons.swing.dialog.foldout.FoldOutDialog;
import net.disy.commons.swing.dialog.foldout.IFoldOutDialogConfiguration;
import net.disy.commons.swing.dialog.foldout.IFoldOutPage;
import net.disy.commons.swing.dialog.userdialog.page.AbstractDialogPage;

import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class FoldOutButtonDemo extends SwingDemoCase {

  public void demo() {
    final AbstractDialogPage dialogPage = new AbstractDialogPage("Default message...") { //$NON-NLS-1$
      @Override
      public JComponent createContent() {
        return new JLabel("I am the main content"); //$NON-NLS-1$
      }

      @Override
      public IBasicMessage createCurrentMessage() {
        return getDefaultMessage();
      }

      @Override
      public String getDescription() {
        return "Description"; //$NON-NLS-1$
      }

      @Override
      public String getTitle() {
        return "Title"; //$NON-NLS-1$
      }

    };
    final IFoldOutPage foldOutPage = new AbstractFoldOutPage() {
      private JTextArea textArea;

      @Override
      protected JComponent createContent() {
        textArea = new JTextArea(5, 40);
        return new JScrollPane(textArea);
      }

      @Override
      public void requestFocus() {
        textArea.requestFocus();
      }
    };

    final IFoldOutDialogConfiguration<AbstractDialogPage> userDialog = new AbstractFoldOutDialogConfiguration<AbstractDialogPage>(
        dialogPage,
        foldOutPage) {
      //nothing to do
    };

    show(new FoldOutDialog(createJFrame(), userDialog).getDialog().getWindow());
  }
}