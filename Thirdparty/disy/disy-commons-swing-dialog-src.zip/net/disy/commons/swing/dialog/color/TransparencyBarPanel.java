/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeEvent;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class TransparencyBarPanel implements IDialogComponent {

  private final JSlider alphaSlider;
  private final SpinnerNumberModel spinnerModel;
  private final boolean showLabel;

  public TransparencyBarPanel(final ColorModel colorModel) {
    this(colorModel, true);
  }

  public TransparencyBarPanel(final ColorModel colorModel, final boolean showLabel) {
    this.showLabel = showLabel;
    alphaSlider = new JSlider();
    alphaSlider.addChangeListener(new javax.swing.event.ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent changeEvent) {
        final int percentage = alphaSlider.getValue();
        updateModel(colorModel, percentage);
      }
    });

    spinnerModel = new SpinnerNumberModel(0, 0, 100, 1);
    spinnerModel.addChangeListener(new javax.swing.event.ChangeListener() {
      @Override
      public void stateChanged(final ChangeEvent changeEvent) {
        updateModel(colorModel, spinnerModel.getNumber().intValue());
      }
    });

    colorModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateView(colorModel);
      }
    });
    updateView(colorModel);
  }

  private void updateModel(final ColorModel colorModel, final int percentage) {
    final int alpha = 255 - (int) (percentage * 2.55);
    final Color color = colorModel.getColor();
    final Color alphaColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    colorModel.setColor(alphaColor);
  }

  private void updateView(final ColorModel colorModel) {
    final int alpha = colorModel.getColor().getAlpha();
    final int percentage = 100 - (int) Math.round(alpha / 2.55);
    alphaSlider.setValue(percentage);
    spinnerModel.setValue(new Integer(percentage));
  }

  @Override
  public int getColumnCount() {
    return showLabel ? 4 : 3;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    if (showLabel) {
      panel
          .add(
              new JLabel(DisyCommonsSwingMessages.getString("TransparencyBarPanel.Transparency")), GridDialogLayoutData.RIGHT); //$NON-NLS-1$
    }
    panel.add(alphaSlider, GridDialogLayoutData.FILL_HORIZONTAL);
    panel.add(new JSpinner(spinnerModel));
    panel.add(new JLabel("%")); //$NON-NLS-1$
  }
}