/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.core.model.ObjectModel;

public class RangeCheckingValidator implements IMessageProducingValidator {
  private final ObjectModel<Integer> minResultCountModel;
  private final ObjectModel<Integer> maxResultCountModel;
  private final String messageText;

  public RangeCheckingValidator(
      final ObjectModel<Integer> minResultCountModel,
      final ObjectModel<Integer> maxResultCountModel,
      final String messageText) {
    this.minResultCountModel = minResultCountModel;
    this.maxResultCountModel = maxResultCountModel;
    this.messageText = messageText;
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    if (minResultCountModel.getValue() == null) {
      return null;
    }
    if (maxResultCountModel.getValue() == null) {
      return null;
    }
    if (maxResultCountModel.getValue() < minResultCountModel.getValue()) {
      return new BasicMessage(messageText, MessageType.ERROR);
    }
    return null;
  }
}