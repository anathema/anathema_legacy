package net.disy.commons.swing.dialog.core;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;

/**
 * @author gebhard
 */
public interface IDialogConstants {
  public static final Dimension MINIMUM_CONTENT_SIZE = new Dimension(310, 50);
  public static final Font MESSAGE_LABEL_FONT = new Font("Dialog", Font.PLAIN, 11); //$NON-NLS-1$

  //Always use black on white color for header panel. There are no L&F colors defined for dialog headers 
  public static final Color HEADER_TEXT_COLOR = Color.BLACK;

  //Always use a bright grey color for header panel background, since there are no L&F colors defined for dialog headers 
  public static final Color HEADER_BACKGROUND_COLOR = new Color(240, 240, 240);

  public static final Color HEADER_OVERLAID_BORDER_COLOR = Color.DARK_GRAY;
}