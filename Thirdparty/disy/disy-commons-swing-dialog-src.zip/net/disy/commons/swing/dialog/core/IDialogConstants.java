package net.disy.commons.swing.dialog.core;

import java.awt.Dimension;
import java.awt.Font;

/**
 * @author gebhard
 */
public interface IDialogConstants {
  public static final Dimension MINIMUM_CONTENT_SIZE = new Dimension(310, 50);
  public static final Font MESSAGE_LABEL_FONT = new Font("Dialog", Font.PLAIN, 11); //$NON-NLS-1$
}