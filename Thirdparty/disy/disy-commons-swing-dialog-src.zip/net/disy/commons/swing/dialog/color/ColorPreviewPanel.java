/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.layout.grid.EndOfLineMarkerComponent;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IDialogComponent;
import net.disy.commons.swing.resources.DisyCommonsSwingMessages;

public class ColorPreviewPanel implements IDialogComponent {

  private final ColorIndicator oldColorIndicator;
  private final ColorIndicator currentColorIndicator;

  public ColorPreviewPanel(final ColorModel colorModel) {
    oldColorIndicator = new ColorIndicator(new ColorModel(colorModel.getColor()));
    currentColorIndicator = new ColorIndicator(colorModel);
  }

  @Override
  public int getColumnCount() {
    return 2;
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    final JLabel oldColorLabel = new JLabel(DisyCommonsSwingMessages.getString("ColorPreviewPanel.OriginalColor")); //$NON-NLS-1$
    final JLabel currentColorLabel = new JLabel(DisyCommonsSwingMessages
        .getString("ColorPreviewPanel.SelectedColor")); //$NON-NLS-1$

    panel.add(oldColorLabel, GridDialogLayoutData.RIGHT);
    panel.add(oldColorIndicator.getContent());
    panel.add(new EndOfLineMarkerComponent());

    panel.add(currentColorLabel, GridDialogLayoutData.RIGHT);
    panel.add(currentColorIndicator.getContent());
    panel.add(new EndOfLineMarkerComponent());
  }
}