/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.smarttree;

import java.awt.Component;

import net.disy.commons.swing.dialog.message.MessageDialogUtilities;
import net.disy.commons.swing.tree.ISmartTreeDeleteStrategy;

public abstract class AbstractConfirmSmartTreeDeleteStrategy<T>
    implements
    ISmartTreeDeleteStrategy<T> {

  @Override
  public final boolean deleteNode(
      final Component parentComponent,
      final T parentNode,
      final int index,
      final T node) {
    if (MessageDialogUtilities.confirmUserOperation(parentComponent, getConfirmText())) {
      return doDelete(parentNode, index, node);
    }

    return false;
  }

  protected abstract String getConfirmText();

  protected abstract boolean doDelete(T parentNode, int index, T node);

}