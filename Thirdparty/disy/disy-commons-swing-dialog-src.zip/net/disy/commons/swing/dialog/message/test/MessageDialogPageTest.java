/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.message.test;

import junit.framework.TestCase;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.message.MessageDialogPage;
import net.disy.commons.swing.message.MessageTypeUi;

public class MessageDialogPageTest extends TestCase {

  public void testGetTitleFromMessage() {
    final MessageDialogPage page = new MessageDialogPage(new Message(
        "title", "text", MessageType.NORMAL)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("title", page.getTitle()); //$NON-NLS-1$
  }

  public void testGetTitleWithMessageNotHavingTitle() {
    final MessageType[] allTypes = MessageType.getAll();
    for (int i = 0; i < allTypes.length; i++) {
      final MessageDialogPage page = new MessageDialogPage(new Message("text", allTypes[i])); //$NON-NLS-1$ 
      assertEquals(MessageTypeUi.getInstance().getLabel(allTypes[i]), page.getTitle());
    }
  }
}