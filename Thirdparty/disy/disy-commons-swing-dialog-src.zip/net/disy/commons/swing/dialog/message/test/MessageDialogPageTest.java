//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message.test;

import junit.framework.TestCase;

import net.disy.commons.core.message.Message;
import net.disy.commons.core.message.MessageType;
import net.disy.commons.swing.dialog.message.MessageDialogPage;
import net.disy.commons.swing.message.MessageTypeUi;

// NOT_PUBLISHED
public class MessageDialogPageTest extends TestCase {

  public void testGetTitleFromMessage() {
    MessageDialogPage page = new MessageDialogPage(new Message("title", "text", MessageType.NORMAL)); //$NON-NLS-1$ //$NON-NLS-2$
    assertEquals("title", page.getTitle()); //$NON-NLS-1$
  }

  public void testGetTitleWithMessageNotHavingTitle() {
    MessageType[] allTypes = MessageType.getAll();
    for (int i = 0; i < allTypes.length; i++) {
      MessageDialogPage page = new MessageDialogPage(new Message("text", allTypes[i])); //$NON-NLS-1$ 
      assertEquals(MessageTypeUi.getLabel(allTypes[i]), page.getTitle());
    }
  }
}