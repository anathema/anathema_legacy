/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.progress;

import java.awt.Component;

public class DefaultProgressMonitorStrategieFactory implements IProgressMonitorStrategieFactory {

  private final Component parentComponent;

  public DefaultProgressMonitorStrategieFactory(final Component parentComponent) {
    this.parentComponent = parentComponent;
  }

  @Override
  public IProgressMonitorStrategie createProgressMonitorStrategie(String title) {
    return new ProgressMonitorDialog(parentComponent, title);
  }

}
