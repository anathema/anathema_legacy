/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.tabbed;

import javax.swing.SwingConstants;

public enum TabPlacement {

  TOP(SwingConstants.TOP), BOTTOM(SwingConstants.BOTTOM), LEFT(SwingConstants.LEFT), RIGHT(
      SwingConstants.RIGHT);

  private final int swingValue;

  private TabPlacement(final int swingValue) {
    this.swingValue = swingValue;
  }

  public int getSwingValue() {
    return swingValue;
  }
}