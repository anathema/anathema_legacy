//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox;

import java.awt.Component;
import java.awt.Insets;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.predicate.AcceptNothingPredicate;
import net.disy.commons.core.predicate.IPredicate;
import net.disy.commons.core.predicate.IPredicateFactory;
import net.disy.commons.core.predicate.Or;
import net.disy.commons.core.predicate.StaticPredicateFactory;
import net.disy.commons.core.progress.ICancelable;
import net.disy.commons.core.text.ISuggestionsForStringProvider;
import net.disy.commons.core.text.SuggestionResult;
import net.disy.commons.core.util.CollectionUtilities;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.IBlock;
import net.disy.commons.swing.component.IComponentContainer;
import net.disy.commons.swing.dialog.DisyCommonsSwingDialogIconResources;
import net.disy.commons.swing.dialog.input.text.combobox.internal.TextualMatchRankerComparator;
import net.disy.commons.swing.dialog.input.text.suggest.AbstractSuggestionTextFieldConfiguration;
import net.disy.commons.swing.dialog.input.text.suggest.ISuggestionActionHandler;
import net.disy.commons.swing.dialog.input.text.suggest.ISuggestionTextFieldConfiguration;
import net.disy.commons.swing.dialog.input.text.suggest.ISwingIOExceptionHandler;
import net.disy.commons.swing.dialog.input.text.suggest.SuggestionTextField;
import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public class FilterComboBox<T> implements IComponentContainer {

  private SuggestionTextField<T> suggestionTextField;
  private final IObjectModel<T> selectionModel;
  private final IFilterComboBoxConfiguration<T> configuration;
  private final IListModel<T> itemsModel;
  private boolean allItemsPopupVisible = false;

  public FilterComboBox(
      final IListModel<T> itemsModel,
      final IObjectModel<T> selectionModel,
      final IFilterComboBoxConfiguration<T> configuration) {
    this(itemsModel, selectionModel, configuration, new StaticPredicateFactory<String, T>(
        new AcceptNothingPredicate<T>()));
  }

  public FilterComboBox(
      final IListModel<T> itemsModel,
      final IObjectModel<T> selectionModel,
      final IFilterComboBoxConfiguration<T> configuration,
      final IPredicateFactory<String, T> alternativeMatcher

  ) {
    Ensure.ensureArgumentNotNull(itemsModel);
    Ensure.ensureArgumentNotNull(selectionModel);
    Ensure.ensureArgumentNotNull(configuration);
    this.itemsModel = itemsModel;
    this.selectionModel = selectionModel;
    this.configuration = configuration;
    final ISuggestionTextFieldConfiguration<T> textFieldConfiguration = new AbstractSuggestionTextFieldConfiguration<T>() {
      @Override
      public boolean isClearButtonVisible() {
        return FilterComboBox.this.configuration.isClearButtonVisible();
      }

      @Override
      public JComponent createOptionalRightInsideTextFieldComponent() {
        final Icon icon = DisyCommonsSwingDialogIconResources.COMBOBOX_DROPDOWN_BUTTON;
        final JButton button = new JButton(icon);
        button.setFocusPainted(false);
        button.setMargin(new Insets(1, 1, 1, 1));
        button.addMouseListener(new MouseAdapter() {
          @Override
          public void mousePressed(final MouseEvent e) {
            button.getParent().requestFocus();
            if (allItemsPopupVisible) {
              suggestionTextField.getWindow().dispose();
              return;
            }
            showAllItemsPopup();
          }
        });
        button.setFocusable(false);
        return button;
      }

      @Override
      public String getToolTipText() {
        return configuration.getToolTipText();
      }

      @Override
      public String getBusyLabelText() {
        return null;
      }

      @Override
      public String getNoResultLabelText() {
        return configuration.getNoResultLabelText();
      }

      @Override
      public IObjectUi<T> getObjectUi() {
        return configuration.getObjectUi();
      }

      @Override
      public ISuggestionActionHandler<T> getActionHandler() {
        return new ISuggestionActionHandler<T>() {
          @Override
          public void handle(final Component parentComponent, final T selection) {
            FilterComboBox.this.selectionModel.setValue(selection);
            updateTextFromModel();//Required if model itself does not change!
          }
        };
      }

      @Override
      public ISuggestionsForStringProvider<T> getSuggestionsForStringProvider() {
        final IObjectUi<T> objectUi = configuration.getObjectUi();
        return new ISuggestionsForStringProvider<T>() {
          @Override
          public SuggestionResult<T> querySuggestions(
              final String text,
              final ICancelable cancelable) {
            final List<T> items = itemsModel.getItemList();
            final IPredicate<T> predicate = new Or<T>(new IPredicate<T>() {

              @Override
              public boolean evaluate(T value) {
                return objectUi.getLabel(value).toLowerCase().contains(text.toLowerCase());
              }
            }, alternativeMatcher.createPredicate(text));
            final List<T> filteredItems = CollectionUtilities.filter(items, predicate);
            Collections.sort(filteredItems, new TextualMatchRankerComparator<T>(objectUi, text));
            return new SuggestionResult<T>(filteredItems);
          }
        };
      }

      @Override
      public ISwingIOExceptionHandler getErrorHandler() {
        return new ISwingIOExceptionHandler() {
          @Override
          public void handleError(final Component parentComponent, final IOException exception) {
            //There is no IO in this scenario -> Throw as Runtime Exception
            throw new UnreachableCodeReachedException(exception);
          }
        };
      }

    };
    this.suggestionTextField = new SuggestionTextField<T>(textFieldConfiguration);
    /* Workaround (gebhard) 27.06.2011: in JGoodies Looks L&F this textfield will receive a
     * selectAll() as it gains focus. This leeds to strange bahavior when using the
     * the textfiels in a FilterComboBox:
     * When first displayed, subsequently entering characters will result in only one character
     * being shown in the end. This bahavior disappears, as soon as using mouse interaction.
     * It is very strange and seems to have to do with ugly event handling in Swing Document classes...
     * 
     * As I cannot fix the problem now, I just work around it :-( 
     */
    suggestionTextField._disableTextFieldSelectAllInJGoodiesLooks();

    this.selectionModel.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateTextFromModel();
      }
    });
    updateTextFromModel();
    suggestionTextField.addKeyListener(new KeyAdapter() {
      @Override
      public void keyPressed(final KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
          updateTextFromModel();
          return;
        }
        if (e.getKeyCode() == KeyEvent.VK_DOWN) {
          if (suggestionTextField.getWindow().isVisible()) {
            return;
          }
          showAllItemsPopup();
        }
      }
    });
    suggestionTextField.addFocusListener(new FocusAdapter() {
      @Override
      public void focusLost(final FocusEvent e) {
        if (!e.isTemporary()) {
          updateTextFromModel();
        }
      }
    });
  }

  private void updateTextFromModel() {
    final Runnable runnable = new Runnable() {
      @Override
      public void run() {
        final T value = FilterComboBox.this.selectionModel.getValue();
        final String text = value == null ? "" : configuration.getObjectUi().getLabel(value); //$NON-NLS-1$
        suggestionTextField.setText(text);
      }
    };
    if (SwingUtilities.isEventDispatchThread()) {
      runnable.run();
    }
    else {
      SwingUtilities.invokeLater(runnable);
    }
  }

  @Override
  public JComponent getContent() {
    return suggestionTextField.getContent();
  }

  private void showAllItemsPopup() {
    updateTextFromModel(); //resets any typed text
    suggestionTextField.getWindow().showWithQueryStarted();
    final List<T> items = itemsModel.getItemList();
    suggestionTextField.getWindow().showLoadedSuggestions(new SuggestionResult<T>(items));
    suggestionTextField.requestFocus();
    allItemsPopupVisible = true;
    suggestionTextField.getWindow().addWindowDisposeListener(new IBlock() {
      @Override
      public void execute() {
        allItemsPopupVisible = false;
        suggestionTextField.getWindow().removeWindowDisposeListener(this);
      }
    });
  }
}