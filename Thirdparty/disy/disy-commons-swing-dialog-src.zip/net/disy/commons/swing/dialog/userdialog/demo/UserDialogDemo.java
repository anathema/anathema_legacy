package net.disy.commons.swing.dialog.userdialog.demo;

import net.disy.commons.swing.dialog.userdialog.IDialogPage;

/**
 * @author gebhard
 */
public class UserDialogDemo extends AbstractDialogDemo {
  public void demoUserDialogWithHeaderPanel() {
    IDialogPage dialogPage = createDemoDialogPage();
    showDemoUserDialog(dialogPage, true);
  }

  public void demoUserDialogWithoutHeaderPanel() {
    IDialogPage dialogPage = createDemoDialogPage();
    showDemoUserDialog(dialogPage, false);
  }
}