/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.demo;

import java.awt.Component;

import net.disy.commons.swing.dialog.core.IDialogHelpHandler;
import net.disy.commons.swing.dialog.userdialog.page.IDialogPage;

import org.junit.runner.RunWith;

import de.jdemo.junit.DemoAsTestRunner;

@RunWith(DemoAsTestRunner.class)
public class UserDialogDemo extends AbstractDialogDemo {

  public void demoUserDialogWithHeaderPanel() {
    final IDialogPage dialogPage = new DemoDialogPage();
    show(dialogPage, true);
  }

  public void demoUserDialogWithoutHeaderPanel() {
    final IDialogPage dialogPage = new DemoDialogPage();
    show(dialogPage, false);
  }

  public void demoUserDialogWithHelp() {
    final IDialogPage dialogPage = new DemoDialogPage() {
      @Override
      public IDialogHelpHandler getHelpHandler() {
        return new IDialogHelpHandler() {
          @Override
          public void execute(final Component parentComponent) {
            System.out.println("help"); //$NON-NLS-1$
          }
        };
      }
    };
    show(dialogPage);
  }
}