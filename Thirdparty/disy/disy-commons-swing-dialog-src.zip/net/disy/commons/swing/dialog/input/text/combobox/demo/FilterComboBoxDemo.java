//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox.demo;

import java.util.List;
import java.util.Vector;

import javax.swing.JComboBox;

import net.disy.commons.core.list.DefaultListModel;
import net.disy.commons.core.list.IListModel;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.text.combobox.FilterComboBox;
import net.disy.commons.swing.dialog.input.text.combobox.IFilterComboBoxConfiguration;
import net.disy.commons.swing.ui.ObjectUiListCellRenderer;

import org.junit.runner.RunWith;

import de.jdemo.annotation.Demo;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.junit.DemoAsTestRunner;

// NOT_PUBLISHED
@RunWith(DemoAsTestRunner.class)
public class FilterComboBoxDemo extends SwingDemoCase {

  @Demo
  public void demoOrdinaryComboBoxForComparisonOnly() {
    final JComboBox comboBox = new JComboBox(new Vector<DemoColorItem>(
        DemoColorItem.createDemoItems()));
    comboBox.setRenderer(new ObjectUiListCellRenderer(new DemoColorItemUi()));
    comboBox.setEditable(true);
    show(comboBox);
  }

  @Demo
  public void demo() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    final IListModel<DemoColorItem> itemsModel = new DefaultListModel<DemoColorItem>(items);
    final ObjectModel<DemoColorItem> selectionModel = new ObjectModel<DemoColorItem>(items.get(2));
    final IFilterComboBoxConfiguration<DemoColorItem> configuration = new DemoFilterComboBoxConfiguration();
    final FilterComboBox<DemoColorItem> comboBox = new FilterComboBox<DemoColorItem>(
        itemsModel,
        selectionModel,
        configuration);
    show(comboBox.getContent());
  }

  @Demo
  public void demoClearable() {
    final List<DemoColorItem> items = DemoColorItem.createDemoItems();
    final IListModel<DemoColorItem> itemsModel = new DefaultListModel<DemoColorItem>(items);
    final ObjectModel<DemoColorItem> selectionModel = new ObjectModel<DemoColorItem>(items.get(2));
    final IFilterComboBoxConfiguration<DemoColorItem> configuration = new DemoFilterComboBoxConfiguration() {

      @Override
      public boolean isClearButtonVisible() {
        return true;
      }

    };
    final FilterComboBox<DemoColorItem> comboBox = new FilterComboBox<DemoColorItem>(
        itemsModel,
        selectionModel,
        configuration);
    show(comboBox.getContent());
  }
}