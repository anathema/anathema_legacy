/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.color.demo;

import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.JComponent;

import org.junit.runner.RunWith;

import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.ColorChooserButton;
import net.disy.commons.swing.dialog.color.ColorChooserLabel;
import net.disy.commons.swing.dialog.color.ColorIndicator;
import net.disy.commons.swing.dialog.color.DefaultColorChooserConfiguration;

import de.jdemo.junit.DemoAsTestRunner;

import de.jdemo.extensions.SwingDemoCase;

@RunWith(DemoAsTestRunner.class)
public class ColorChooserButtonDemo extends SwingDemoCase {

  public void demoShowColorChooseButton() {
    final ColorChooserButton button1 = new ColorChooserButton();
    button1.setEnabled(false);
    final ColorChooserButton button2 = new ColorChooserButton(new ColorModel(new Color(
        255,
        255,
        0,
        128)), new DefaultColorChooserConfiguration(true));

    show(new JComponent[]{
        new ColorChooserButton(new ColorModel(Color.red)).getContent(),
        button1.getContent(),
        button2.getContent() }, new FlowLayout());
  }

  public void demoColorIndicator() {
    show(new ColorIndicator(new ColorModel(Color.red)).getContent());
  }

  public void demoColorChooseLabel() {
    final ColorChooserLabel colorLabel = new ColorChooserLabel(new ColorModel(Color.red));
    show(colorLabel.getContent());
  }

  public void demoColorChooseLabelWithTransparency() {
    final ColorChooserLabel colorLabel = new ColorChooserLabel(
        new ColorModel(Color.red),
        new DefaultColorChooserConfiguration(true));
    show(colorLabel.getContent());
  }
}