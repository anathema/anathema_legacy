/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.ResourceBundle;

public class DisyCommonsSwingDialogMessages {

  private static final String BUNDLE_NAME = "net.disy.commons.swing.dialog.messages";//$NON-NLS-1$

  private static final ResourceBundle RESOURCE_BUNDLE = ResourceBundle.getBundle(
      BUNDLE_NAME,
      Locale.getDefault());

  public static final String LESS = getString("Dialog.LessButtonText"); //$NON-NLS-1$
  public static final String MORE = getString("Dialog.MoreButtonText"); //$NON-NLS-1$

  public static final String APPLY = getString("SmartAction.apply"); //$NON-NLS-1$
  public static final String CANCEL = getString("SmartAction.cancel"); //$NON-NLS-1$
  public static final String CLOSE = getString("SmartAction.close"); //$NON-NLS-1$
  public static final String HELP = getString("SmartAction.help"); //$NON-NLS-1$
  public static final String OK = getString("SmartAction.okay"); //$NON-NLS-1$
  public static final String YES = getString("SmartAction.Yes"); //$NON-NLS-1$
  public static final String NO = getString("SmartAction.No"); //$NON-NLS-1$

  public static final String SELECT_ALL = getString("SmartAction.selectAll"); //$NON-NLS-1$
  public static final String COPY = getString("SmartAction.copy"); //$NON-NLS-1$
  public static final String CUT = getString("SmartAction.cut"); //$NON-NLS-1$
  public static final String PASTE = getString("SmartAction.paste"); //$NON-NLS-1$

  public static final String WIZARD_NEXT = getString("Wizard.SmartNext"); //$NON-NLS-1$
  public static final String WIZARD_BACK = getString("Wizard.SmartBack"); //$NON-NLS-1$
  public static final String WIZARD_FINISH = getString("Wizard.SmartFinish"); //$NON-NLS-1$

  public static String getString(final String key) {
    return RESOURCE_BUNDLE.getString(key);
  }

  public String getString(final String key, final Object[] arguments) {
    final String value = getString(key);
    if (value == null) {
      return null;
    }
    return MessageFormat.format(value, arguments);
  }
}