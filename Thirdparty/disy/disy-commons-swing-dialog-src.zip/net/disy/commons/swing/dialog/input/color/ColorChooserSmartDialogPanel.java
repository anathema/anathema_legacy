/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.color;

import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.swing.color.widgets.ColorModel;
import net.disy.commons.swing.dialog.color.ColorChooserButton;
import net.disy.commons.swing.dialog.color.IColorChooserConfiguration;
import net.disy.commons.swing.dialog.input.AbstractLabeledSmartDialogPanel;
import net.disy.commons.swing.dialog.input.NullMessageProducingValidator;

public class ColorChooserSmartDialogPanel extends AbstractLabeledSmartDialogPanel {

  private final ColorModel model;
  private final ColorChooserButton button;

  public ColorChooserSmartDialogPanel(
      final String label,
      final ColorModel model,
      final IColorChooserConfiguration configuration) {
    this(label, null, model, configuration);
  }

  public ColorChooserSmartDialogPanel(
      final String label,
      final String toolTipText,
      final ColorModel model,
      final IColorChooserConfiguration configuration) {
    super(label, toolTipText, new NullMessageProducingValidator());
    Ensure.ensureArgumentNotNull(model);
    this.model = model;
    button = new ColorChooserButton(model, configuration);
  }

  @Override
  protected JComponent fillMainComponentInto(final JPanel panel, final int columnCount) {
    panel.add(button.getContent());
    return button.getContent();
  }

  @Override
  protected int getMainComponentColumnCount() {
    return 1;
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    model.addChangeListener(listener);
  }

  @Override
  public void requestFocus() {
    button.getContent().requestFocus();
  }

  @Override
  protected void setMainComponentEnabled(final boolean enabled) {
    button.setEnabled(enabled);
  }

  @Override
  protected JComponent[] getOtherComponents() {
    return new JComponent[]{ button.getContent() };
  }
}
