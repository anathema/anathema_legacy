/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input;

import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

import net.disy.commons.swing.layout.grid.GridDialogPanelBuilder;
import net.disy.commons.swing.layout.util.LayoutUtilities;

public class SmartDialogPanelsBuilder implements ISmartDialogPanelsBuilder {

  private final GridDialogPanelBuilder builder = new GridDialogPanelBuilder();
  private final List<ISmartDialogPanel> allPanels = new ArrayList<ISmartDialogPanel>();
  private final boolean withBorder;

  public SmartDialogPanelsBuilder() {
    this(false);
  }

  public SmartDialogPanelsBuilder(final boolean withBorder) {
    this.withBorder = withBorder;
  }

  @Override
  public void add(final ISmartDialogPanel... panels) {
    for (final ISmartDialogPanel panel : panels) {
      addPanel(panel);
    }
  }

  @Override
  @Deprecated
  public void add(final Iterable<ISmartDialogPanel> panels) {
    for (final ISmartDialogPanel panel : panels) {
      addPanel(panel);
    }
  }

  private void addPanel(final ISmartDialogPanel panel) {
    builder.add(panel);
    allPanels.add(panel);
  }

  @Override
  public void addVerticalComponentSpacing() {
    addVerticalSpacing(LayoutUtilities.getComponentSpacing());
  }

  private void addVerticalSpacing(final int height) {
    builder.addVerticalSpacing(height);
  }

  public SmartDialogPanelsBuildResult createResult() {
    final JPanel builtPanel = builder.createPanel();
    if (withBorder) {
      builtPanel.setBorder(LayoutUtilities.getDefaultEmptyBorder());
    }
    return new SmartDialogPanelsBuildResult(allPanels.toArray(new ISmartDialogPanel[allPanels
        .size()]), builtPanel);
  }
}