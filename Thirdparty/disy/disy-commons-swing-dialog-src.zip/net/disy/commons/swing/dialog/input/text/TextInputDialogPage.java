//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.core.message.BasicMessage;
import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.StringModel;
import net.disy.commons.swing.dialog.input.IMessageProducingValidator;
import net.disy.commons.swing.dialog.input.ISmartDialogPanel;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

// NOT_PUBLISHED
public class TextInputDialogPage extends SmartDialogPage {

  private final ITextInputDialogConfiguration configuration;
  private StringModelSmartDialogPanel textPanel;
  private StringModel stringModel;

  public TextInputDialogPage(final ITextInputDialogConfiguration configuration, String initialText) {
    super(new BasicMessage(configuration.getDefaultMessageText()));
    this.configuration = configuration;
    stringModel = new StringModel(initialText);
    textPanel = new StringModelSmartDialogPanel(
        configuration.getLabelText(),
        stringModel,
        new IMessageProducingValidator() {
          public IBasicMessage validate() {
            return configuration.createCurrentMessage(stringModel.getValue());
          }
        });
    textPanel.selectAll();
  }

  public String getTitle() {
    return configuration.getTitle();
  }

  protected ISmartDialogPanel[] createPanels() {
    return new ISmartDialogPanel[]{ textPanel };
  }

  public void requestFocus() {
    textPanel.requestFocus();
  }

  public String getSelectedText() {
    return stringModel.getValue();
  }
}