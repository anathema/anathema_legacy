//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import net.disy.commons.swing.dialog.userdialog.AbstractDialogPage;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.message.BasicMessage;
import net.disy.commons.swing.message.IBasicMessage;

// NOT_PUBLISHED
public class TextInputDialogPage extends AbstractDialogPage {

  private final ITextInputDialogConfiguration configuration;
  private JTextField textField;

  public TextInputDialogPage(ITextInputDialogConfiguration configuration, String initialText) {
    super(new BasicMessage(configuration.getDefaultMessageText()));
    this.configuration = configuration;
    textField = new JTextField(initialText);
  }

  public String getTitle() {
    return configuration.getTitle();
  }

  public IBasicMessage createCurrentMessage() {
    IBasicMessage currentMessage = configuration.createCurrentMessage(getSelectedText());
    if (currentMessage != null) {
      return currentMessage;
    }
    return getDefaultMessage();
  }

  public JComponent createContent() {
    JPanel panel = new JPanel(new GridDialogLayout(2, false));
    panel.add(new JLabel(configuration.getLabelText()));
    panel.add(textField, GridDialogLayoutData.FILL_HORIZONTAL);
    textField.selectAll();
    textField.getDocument().addDocumentListener(getCheckInputValidListener());
    return panel;
  }

  public void requestFocus() {
    textField.requestFocus();
  }

  public String getSelectedText() {
    return textField.getText();
  }
}