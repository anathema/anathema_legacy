/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.dialog.input.ISmartDialogPanelsBuilder;
import net.disy.commons.swing.dialog.input.SmartDialogPage;

public class TextInputDialogPage extends SmartDialogPage {

  private final ITextInputDialogConfiguration configuration;
  private final DefaultTextSmartDialogPanel textPanel;
  private final ObjectModel<String> stringModel;

  public TextInputDialogPage(
      final ITextInputDialogConfiguration configuration,
      final String initialText) {
    super(configuration.getDefaultMessageText());
    this.configuration = configuration;
    stringModel = new ObjectModel<String>(initialText);
    textPanel = new DefaultTextSmartDialogPanel(
        configuration.getLabelText(),
        stringModel,
        new IMessageProducingValidator() {
          @Override
          public IBasicMessage createOptionalCurrentMessage() {
            return configuration.createCurrentMessage(stringModel.getValue());
          }
        });
    textPanel.selectAll();
  }

  @Override
  public String getTitle() {
    return configuration.getTitle();
  }

  @Override
  protected void addPanels(final ISmartDialogPanelsBuilder builder) {
    builder.add(textPanel);
  }

  @Override
  public void requestFocus() {
    textPanel.requestFocus();
  }

  public String getSelectedText() {
    return stringModel.getValue();
  }
}