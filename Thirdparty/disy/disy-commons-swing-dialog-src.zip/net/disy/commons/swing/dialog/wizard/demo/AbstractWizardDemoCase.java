/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.wizard.demo;

import java.awt.Window;

import net.disy.commons.swing.dialog.wizard.IWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.IWizardPageFactory;
import net.disy.commons.swing.dialog.wizard.SinglePageWizardConfiguration;
import net.disy.commons.swing.dialog.wizard.WizardDialog;
import de.jdemo.extensions.SwingDemoCase;

public abstract class AbstractWizardDemoCase extends SwingDemoCase {

  protected void show(final IWizardPageFactory pageFactory) {
    show(new SinglePageWizardConfiguration(pageFactory));
  }

  protected void show(final IWizardConfiguration configuration) {
    final WizardDialog dialog = new WizardDialog(getRegisteredDemoWindow(), configuration);
    final Window window = dialog.getConfiguredDialog().getWindow();
    show(window);
  }
}