/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.optional;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.core.model.listener.IChangeListener;
import net.disy.commons.swing.component.Gap;
import net.disy.commons.swing.dialog.input.AbstractSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;
import net.disy.commons.swing.layout.grid.GridDialogLayoutData;
import net.disy.commons.swing.layout.grid.IGridDialogLayoutData;
import net.disy.commons.swing.layout.util.LayoutUtilities;
import net.disy.commons.swing.util.ToggleComponentEnabler;

public class OptionalSmartDialogPanel<T extends Object> extends AbstractSmartDialogPanel
    implements
    IOptionalSmartDialogPanel {

  private final JCheckBox enabledCheckBox;
  private final IUpdatableSmartDialogPanel delegate;
  private final IObjectModel<T> model;
  private final IObjectModel<T> fieldModel;
  private final boolean mandatory;

  public OptionalSmartDialogPanel(
      final IObjectModel<T> model,
      final IUpdatableSmartDialogPanel field,
      final IObjectModel<T> fieldModel,
      final boolean mandatory) {
    this(model, null, field, fieldModel, mandatory);
  }

  // für Testzwecke
  protected OptionalSmartDialogPanel(
      final IObjectModel<T> model,
      final String checkBoxLabel,
      final IUpdatableSmartDialogPanel delegate,
      final IObjectModel<T> fieldModel,
      final boolean mandatory) {
    this.model = model;
    this.delegate = delegate;
    this.fieldModel = fieldModel;
    this.mandatory = mandatory;
    enabledCheckBox = new JCheckBox(checkBoxLabel);
    enabledCheckBox.setSelected(mandatory || model.getValue() != null);
    if (!mandatory) {
      enabledCheckBox.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(final ActionEvent e) {
          updateModel();
        }
      });
    }

    updateView();
    model.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateView();
      }
    });
    delegate.addChangeListener(new IChangeListener() {
      @Override
      public void stateChanged() {
        updateModel();
      }
    });
  }

  protected void updateModel() {
    model.setValue(enabledCheckBox.isSelected() ? fieldModel.getValue() : null);
  }

  protected void updateView() {
    if (model.getValue() != null) {
      fieldModel.setValue(model.getValue());
    }
  }

  @Override
  public void addChangeListener(final IChangeListener listener) {
    delegate.addChangeListener(listener);
  }

  @Override
  public void requestFocus() {
    delegate.requestFocus();
  }

  @Override
  public void fillInto(final JPanel panel, final int columnCount) {
    if (mandatory) {
      fillMandatory(panel, columnCount);
    }
    else {
      fillOptional(panel, columnCount);
    }
  }

  private void fillOptional(final JPanel panel, final int columnCount) {
    if (isCheckboxWithoutLabel()) {
      panel.add(enabledCheckBox);
    }
    else {
      final GridDialogLayoutData allColumnsData = new GridDialogLayoutData();
      allColumnsData.setHorizontalSpan(columnCount);
      panel.add(enabledCheckBox, allColumnsData);
      panel.add(
          Box.createHorizontalStrut(LayoutUtilities.getDpiAdjusted(20)),
          IGridDialogLayoutData.DEFAULT);
    }
    delegate.fillInto(panel, columnCount - 2);
    ToggleComponentEnabler.connect(enabledCheckBox, delegate);
  }

  private void fillMandatory(final JPanel panel, final int columnCount) {
    if (isCheckboxWithoutLabel()) {
      panel.add(new Gap());
    }
    else {
      final GridDialogLayoutData allColumnsData = new GridDialogLayoutData();
      allColumnsData.setHorizontalSpan(columnCount);
      panel.add(new Gap(), allColumnsData);
      panel.add(
          Box.createHorizontalStrut(LayoutUtilities.getDpiAdjusted(20)),
          IGridDialogLayoutData.DEFAULT);
    }
    delegate.fillInto(panel, columnCount - 2);
  }

  private boolean isCheckboxWithoutLabel() {
    return enabledCheckBox.getText() == null || enabledCheckBox.getText().isEmpty();
  }

  @Override
  public int getColumnCount() {
    return delegate.getColumnCount() + 2;
  }

  @Override
  public IBasicMessage createOptionalCurrentMessage() {
    return delegate.createOptionalCurrentMessage();
  }

  protected JCheckBox getCheckbox() {
    return enabledCheckBox;
  }

  @Override
  public void update() {
    delegate.update();
  }

  @Override
  public JComponent[] getComponents() {
    return delegate.getComponents();
  }

  @Override
  public void setEnabled(final boolean enabled) {
    delegate.setEnabled(enabled);
  }
}