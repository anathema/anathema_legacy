// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 04.05.2005
package net.disy.commons.swing.dialog.userdialog.buttons;

import net.disy.commons.swing.dialog.BasicDialogUi;

// NOT_PUBLISHED
public class DialogButtonConfiguration implements IDialogButtonConfiguration {

  private final String okayText;
  private final boolean okayAvailable;
  private final boolean cancelAvailable;
  private final String cancelText;

  public static IDialogButtonConfiguration createBoth() {
    return new DialogButtonConfiguration(
        BasicDialogUi.OK_TEXT_SMART,
        true,
        BasicDialogUi.CANCEL_TEXT_SMART,
        true);
  }

  public static IDialogButtonConfiguration createOnlyOkay() {
    return createOnlyOkay(BasicDialogUi.OK_TEXT_SMART);
  }

  public static IDialogButtonConfiguration createOnlyOkay(String okayText) {
    return new DialogButtonConfiguration(okayText, true, BasicDialogUi.CANCEL_TEXT_SMART, false);
  }

  public static IDialogButtonConfiguration createBothWithCancelText(String cancelText) {
    return createBoth(BasicDialogUi.OK_TEXT_SMART, cancelText);
  }

  public static IDialogButtonConfiguration createBothWithOkayText(String okayText) {
    return createBoth(okayText, BasicDialogUi.CANCEL_TEXT_SMART);
  }

  public static IDialogButtonConfiguration createBoth(String okayText, String cancelText) {
    return new DialogButtonConfiguration(okayText, true, cancelText, true);
  }

  private DialogButtonConfiguration(
      String okayText,
      boolean okayAvailable,
      String cancelText,
      boolean cancelAvailable) {
    this.okayText = okayText;
    this.okayAvailable = okayAvailable;
    this.cancelText = cancelText;
    this.cancelAvailable = cancelAvailable;
  }

  public boolean isOkayButtonAvailable() {
    return okayAvailable;
  }

  public boolean isCancelButtonAvailable() {
    return cancelAvailable;
  }

  public String getOkayButtonText() {
    return okayText;
  }

  public String getCancelButtonText() {
    return cancelText;
  }
}