// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.message;

import net.disy.commons.core.message.IMessage;
import net.disy.commons.swing.dialog.userdialog.AbstractDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public class MessageUserDialogConfiguration extends AbstractDialogConfiguration {

  public MessageUserDialogConfiguration(IMessage message) {
    this(message, DialogButtonConfigurationFactory.createOnlyOkay());
  }

  public MessageUserDialogConfiguration(IMessage message, IDialogButtonConfiguration buttonConfiguration) {
    super(new MessageDialogPage(message), buttonConfiguration);
  }

  @Override
  public boolean isHeaderPanelVisible() {
    return false;
  }
}