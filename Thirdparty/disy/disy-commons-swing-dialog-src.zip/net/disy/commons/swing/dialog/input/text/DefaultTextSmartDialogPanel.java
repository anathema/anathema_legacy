/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text;

import net.disy.commons.core.message.IMessageProducingValidator;
import net.disy.commons.core.model.IObjectModel;
import net.disy.commons.swing.dialog.input.text.component.GeneralStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.IStringAttributeInputComponentFactory;

public class DefaultTextSmartDialogPanel extends AbstractTextSmartDialogPanel {

  public DefaultTextSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator) {
    this(label, null, stringModel, validator, true);
  }

  public DefaultTextSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    this(label, null, stringModel, validator, grabSpace);
  }

  public DefaultTextSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    this(
        label,
        toolTipText,
        stringModel,
        new GeneralStringAttributeInputComponentFactory(),
        validator,
        grabSpace);
  }

  public DefaultTextSmartDialogPanel(
      final String label,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory factory,
      final IMessageProducingValidator validator) {
    this(label, null, stringModel, factory, validator);
  }

  public DefaultTextSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory factory,
      final IMessageProducingValidator validator) {
    this(label, toolTipText, stringModel, factory, validator, true);
  }

  public DefaultTextSmartDialogPanel(
      final String label,
      String toolTipText,
      final IObjectModel<String> stringModel,
      final IStringAttributeInputComponentFactory factory,
      final IMessageProducingValidator validator,
      boolean grabSpace) {
    super(label, toolTipText, stringModel, factory, validator, grabSpace);
  }
}