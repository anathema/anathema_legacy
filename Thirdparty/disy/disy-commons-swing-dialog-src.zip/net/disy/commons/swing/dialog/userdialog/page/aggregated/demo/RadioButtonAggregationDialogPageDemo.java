/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.userdialog.page.aggregated.demo;

import net.disy.commons.swing.dialog.userdialog.demo.AbstractDialogDemo;
import net.disy.commons.swing.dialog.userdialog.demo.DemoDialogPage;
import net.disy.commons.swing.dialog.userdialog.page.aggregated.RadioButtonAggregationDialogPage;

import de.jdemo.junit.DemoAsTestRunner;

import org.junit.runner.RunWith;

@RunWith(DemoAsTestRunner.class)
public class RadioButtonAggregationDialogPageDemo extends AbstractDialogDemo {

  @SuppressWarnings("unchecked")
  public void demo() {
    show(new RadioButtonAggregationDialogPage<Void>("DialogTitle", //$NON-NLS-1$
        "message", //$NON-NLS-1$
        new DummyDialogPageWithModel(new DemoDialogPage()),
        new DummyDialogPageWithModel(new DemoDialogPage())));
  }
}
