//Copyright (c) 2011 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.text.combobox;

import net.disy.commons.swing.ui.IObjectUi;

// NOT_PUBLISHED
public interface IFilterComboBoxConfiguration<T> {

  /** @return the tooltip text for the combo box or <code>null</code> if none. */
  public String getToolTipText();

  public IObjectUi<T> getObjectUi();

  public String getNoResultLabelText();

  public boolean isClearButtonVisible();

}