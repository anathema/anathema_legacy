// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.demo;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import net.disy.commons.swing.dialog.file.ChoosableFileFilterModel;
import net.disy.commons.swing.dialog.file.FileChooserModel;

import de.jdemo.extensions.SwingDemoCase;

//NOT_PUBLISHED
public abstract class AbstractFileChooserDemo extends SwingDemoCase {

  protected void addFileFilters(FileChooserModel model) {
    model.getChoosableFileFilterModel().addFileFilter(
        ChoosableFileFilterModel.ACCEPT_ALL_FILE_FILTER); //$NON-NLS-1$
    model.getChoosableFileFilterModel().addFileFilter(createFileFilter("txt")); //$NON-NLS-1$
    model.getChoosableFileFilterModel().addFileFilter(createFileFilter("pdf")); //$NON-NLS-1$
  }

  private FileFilter createFileFilter(final String extension) {
    return new FileFilter() {
      public String getDescription() {
        return extension;
      }
    
      public boolean accept(File f) {
        return f.getName().endsWith("." + extension); //$NON-NLS-1$
      }
    };
  }

}
