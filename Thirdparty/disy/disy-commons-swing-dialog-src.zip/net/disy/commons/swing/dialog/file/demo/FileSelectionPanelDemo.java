// Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.demo;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.filechooser.FileFilter;

import net.disy.commons.swing.action.SmartAction;
import net.disy.commons.swing.dialog.file.FileChooserModel;
import net.disy.commons.swing.dialog.file.FileSelectionPanel;

import de.jdemo.extensions.SwingDemoCase;

//NOT_PUBLISHED
public class FileSelectionPanelDemo extends SwingDemoCase {
  private FileChooserModel fileChooserModel;
  private FileSelectionPanel fileSelectionPanel;

  protected void setUp() throws Exception {
    super.setUp();
    fileChooserModel = new FileChooserModel();
    fileChooserModel.getFolderModel().setFile(new File(System.getProperty("user.home"))); //$NON-NLS-1$
    fileSelectionPanel = new FileSelectionPanel(fileChooserModel);
  }
  
  public void demoFileSelectionOnly() throws Exception {
    show(fileSelectionPanel.getContent());
  }
  
  public void demoFileFilter() throws Exception {
    JPanel panel = new JPanel(new BorderLayout());
    panel.add(fileSelectionPanel.getContent(), BorderLayout.CENTER);
    JPanel filterPanel = new JPanel(new FlowLayout());
    final JTextField textField = new JTextField(10);
    filterPanel.add(textField);
    JButton filterButton = new JButton(new SmartAction("Filtern") { //$NON-NLS-1$
      protected void execute(Component parentComponent) {
        fileChooserModel.getFileFilterModel().setFileFilter(createExtensionFileFilter(textField));
      }
    });
    filterPanel.add(filterButton);
    panel.add(filterPanel, BorderLayout.SOUTH);
    show(panel);
  }

  private FileFilter createExtensionFileFilter(final JTextField textField) {
    return new FileFilter() {
      public String getDescription() {
        return null;
      }
      public boolean accept(File f) {
        return f.getName().endsWith("." + textField.getText()); //$NON-NLS-1$
      }
    };
  }
}
