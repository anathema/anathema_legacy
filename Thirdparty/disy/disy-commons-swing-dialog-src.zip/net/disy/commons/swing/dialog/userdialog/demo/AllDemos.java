//Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.userdialog.demo;

import de.jdemo.framework.DemoSuite;
import de.jdemo.framework.IDemo;

// NOT_PUBLISHED
public class AllDemos {

  public static IDemo suite() {
    DemoSuite suite = new DemoSuite("Demo for de.disy.lib.gui.wizard.dialog.demo"); //$NON-NLS-1$
    //$JDemo-BEGIN$
    suite.addDemo(new DemoSuite(UserDialogDemo.class));
    suite.addDemo(new DemoSuite(TabbedAggregationDialogPageDemo.class));
    //$JDemo-END$
    return suite;
  }
}
