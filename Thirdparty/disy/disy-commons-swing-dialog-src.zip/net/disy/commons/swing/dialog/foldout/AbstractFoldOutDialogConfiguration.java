// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import net.disy.commons.swing.dialog.userdialog.AbstractDialogConfiguration;
import net.disy.commons.swing.dialog.userdialog.IDialogPage;
import net.disy.commons.swing.dialog.userdialog.buttons.DialogButtonConfigurationFactory;
import net.disy.commons.swing.dialog.userdialog.buttons.IDialogButtonConfiguration;

// NOT_PUBLISHED
public abstract class AbstractFoldOutDialogConfiguration extends AbstractDialogConfiguration
    implements
    IFoldOutDialogConfiguration {

  private IFoldOutPage foldOutPage;

  public AbstractFoldOutDialogConfiguration(IDialogPage dialogPage, IFoldOutPage foldOutPage) {
    this(dialogPage, foldOutPage, DialogButtonConfigurationFactory.createBoth());
  }

  public AbstractFoldOutDialogConfiguration(
      IDialogPage dialogPage,
      IFoldOutPage foldOutPage,
      IDialogButtonConfiguration buttonConfiguration) {
    super(dialogPage, buttonConfiguration);
    this.foldOutPage = foldOutPage;
  }

  public String getFoldOutButtonText() {
    return "Details >>>";
  }

  public String getFoldInButtonText() {
    return "Details <<<";
  }

  public IFoldOutPage getFoldOutPage() {
    return foldOutPage;
  }

  public boolean isInitiallyFoldedOut() {
    return false;
  }
}