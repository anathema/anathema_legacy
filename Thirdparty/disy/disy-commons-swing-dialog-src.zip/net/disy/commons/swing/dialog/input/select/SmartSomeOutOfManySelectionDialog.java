/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import java.awt.Component;

/** @deprecated As of 14.06.2011 (gebhard), replaced by {@link ListSelectionDialog} */
@Deprecated
public class SmartSomeOutOfManySelectionDialog extends ListSelectionDialog {

  private SmartSomeOutOfManySelectionDialog() {
    //no instance available
  }

  /** @deprecated As of 14.06.2011 (gebhard), replaced by {@link #showDialog(Component, ISomeOutOfManyDialogConfiguration)}*/
  @Deprecated
  public static <T> ISomeOutOfManyDialogResult<T> showSelectOneOutOfManyDialog(
      final Component parentComponent,
      final ISomeOutOfManyDialogConfiguration<T> configuration) {
    final ISelectionDialogResult<T> result = showDialog(parentComponent, configuration);
    return new SelectionDialogResult<T>(result, result.getSelectedItems());
  }
}