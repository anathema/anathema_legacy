//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.input.select;

import java.awt.Component;

import net.disy.commons.swing.dialog.userdialog.UserDialog;

// NOT_PUBLISHED
public class SmartSomeOutOfManySelectionDialog {

  private SmartSomeOutOfManySelectionDialog() {
    //no instance available
  }

  public static ISomeOutOfManyDialogResult showSelectOneOutOfManyDialog(
      Component parentComponent,
      final ISomeOutOfManyDialogConfiguration configuration) {
    SelectSomeOutOfManyDialogPage page = new SelectSomeOutOfManyDialogPage(configuration);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    dialog.show();
    final Object[] selectedItems = page.getSelectedItems();
    return new ISomeOutOfManyDialogResult() {
      public boolean isCanceled() {
        return dialog.isCanceled();
      }

      public Object[] getSelectedItems() {
        return selectedItems;
      }

      public Object getSelectedItem() {
        return selectedItems.length == 0? null: selectedItems[0];
      }
    };
  }

  public static UserDialog createDemoDialog(
      Component parentComponent,
      ISomeOutOfManyDialogConfiguration configuration) {
    SelectSomeOutOfManyDialogPage page = new SelectSomeOutOfManyDialogPage(configuration);
    final UserDialog dialog = new UserDialog(parentComponent, page);
    return dialog;
  }
}