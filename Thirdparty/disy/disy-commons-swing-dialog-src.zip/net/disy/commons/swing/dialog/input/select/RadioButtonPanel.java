/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.select;

import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import net.disy.commons.core.model.ObjectModel;
import net.disy.commons.swing.layout.grid.GridDialogLayout;
import net.disy.commons.swing.ui.IObjectUi;

public class RadioButtonPanel<T> {

  private final JComponent content;
  private final JRadioButton[] radioButtons;

  private final GridDialogLayout layout;

  public RadioButtonPanel(final T[] values, final ObjectModel<T> model, final IObjectUi<T> objectUi) {
    RadioButtonBinder<T> radioButtonBinder = new RadioButtonBinder<T>(values, model, objectUi);
    radioButtons = radioButtonBinder.getRadioButtons();

    layout = new GridDialogLayout(1, false, 0, 0);
    final JPanel panel = new JPanel(layout);
    for (int i = 0; i < radioButtons.length; ++i) {
      panel.add(radioButtons[i]);
    }
    this.content = panel;
    panel.setEnabled(false);
  }

  public JComponent getContent() {
    return content;
  }

  public void setHorizontalSpacing(int horizontalSpacing) {
    layout.setHorizontalSpacing(horizontalSpacing);
  }

  public void setVerticalSpacing(int verticalSpacing) {
    layout.setVerticalSpacing(verticalSpacing);
  }

  public void setEnabled(final boolean isEnabled) {
    for (final JRadioButton radioButton : radioButtons) {
      radioButton.setEnabled(isEnabled);
    }
  }

  protected JRadioButton[] getRadioButtons() {
    return radioButtons;
  }
}