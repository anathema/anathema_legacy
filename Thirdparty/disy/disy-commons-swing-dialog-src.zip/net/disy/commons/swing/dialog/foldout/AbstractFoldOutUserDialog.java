// Copyright (c) 2003 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.foldout;

import net.disy.commons.swing.dialog.userdialog.AbstractUserDialog;
import net.disy.commons.swing.dialog.userdialog.IDialogPage;

// NOT_PUBLISHED
public abstract class AbstractFoldOutUserDialog
  extends AbstractUserDialog
  implements IFoldOutUserDialog {

  private IFoldOutPage foldOutPage;

  public AbstractFoldOutUserDialog(IDialogPage dialogPage, IFoldOutPage foldOutPage) {
    super(dialogPage);
    this.foldOutPage = foldOutPage;
  }

  public String getFoldOutButtonText() {
    return "Details >>>";
  }

  public String getFoldInButtonText() {
    return "Details <<<";
  }

  public IFoldOutPage getFoldOutPage() {
    return foldOutPage;
  }

  public boolean isInitiallyFoldedOut() {
    return false;
  }
}