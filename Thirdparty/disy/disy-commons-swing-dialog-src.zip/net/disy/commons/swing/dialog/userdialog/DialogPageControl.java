package net.disy.commons.swing.dialog.userdialog;

import javax.swing.JComponent;

import net.disy.commons.core.message.IBasicMessage;
import net.disy.commons.core.util.Ensure;
import net.disy.commons.core.util.ObjectUtilities;
import net.disy.commons.swing.events.CheckInputValidListener;
import net.disy.commons.swing.events.IInputValidCheckable;

public class DialogPageControl implements IInputValidCheckable {
  private IUserDialogContainer userDialog;
  private JComponent content;
  private boolean canFinish;
  private final IDialogPage dialogPage;
  private IBasicMessage message;

  public DialogPageControl(IDialogPage dialogPage) {
    this.dialogPage = dialogPage;
    setMessage(dialogPage.getDefaultMessage());
    dialogPage.setInputValidListener(new CheckInputValidListener(this));
  }

  public boolean canFinish() {
    return canFinish && dialogPage.canFinish();
  }

  private final void setMessage(IBasicMessage message) {
    Ensure.ensureArgumentNotNull(message);
    if (ObjectUtilities.equals(this.message, message)) {
      updateCanFinish();
      return;
    }
    this.message = message;
    updateCanFinish();
    IUserDialogContainer dialog = userDialog;
    if (dialog != null) {
      dialog.updateMessage();
    }
  }

  private void updateCanFinish() {
    IUserDialogContainer dialog = userDialog;
    if (dialog != null) {
      canFinish = !message.isErrorMessage();
      updateButtons();
    }
  }

  public final IBasicMessage getMessage() {
    return message;
  }

  public final void setUserDialogContainer(IUserDialogContainer userDialog) {
    this.userDialog = userDialog;
  }

  public final JComponent getContent() {
    if (content == null) {
      content = dialogPage.createContent();
      canFinish = !dialogPage.createCurrentMessage().isErrorMessage();
      updateButtons();
    }
    return content;
  }

  protected void updateButtons() {
    if (userDialog != null) {
      userDialog.updateButtons();
    }
  }

  /**
   * @deprecated
   */
  @Deprecated
  public boolean performOk() {
    return dialogPage.performOk();
  }

  /**
   * @deprecated
   */
  @Deprecated
  public boolean performCancel() {
    return dialogPage.performCancel();
  }

  public String getDescription() {
    return dialogPage.getDescription();
  }

  public void checkInputValid() {
    setMessage(dialogPage.createCurrentMessage());
    dialogPage.updateInputValid();
  }

  public String getTitle() {
    return dialogPage.getTitle();
  }

  public void requestFocus() {
    dialogPage.requestFocus();
  }

  public boolean isHelpAvailable() {
    return dialogPage.isHelpAvailable();
  }

  public void performHelp() {
    dialogPage.performHelp();
  }
}