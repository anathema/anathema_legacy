//Copyright (c) 2005 by disy Informationssysteme GmbH
package net.disy.commons.swing.dialog.file.test;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import junit.framework.TestCase;

// NOT_PUBLISHED
public abstract class AbstractFileFilterTest extends TestCase {

  protected FileFilter createDummyFileFilter() {
    return new FileFilter() {
      public String getDescription() {
        return null;
      }
      public boolean accept(File f) {
        return false;
      }
    };
  }

}
