package net.disy.commons.swing.dialog.animation;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Insets;
import java.awt.LayoutManager2;

import javax.swing.JComponent;

import net.disy.commons.core.util.Ensure;

public class AnimatedCompositeLayout implements LayoutManager2 {

  private final JComponent overlaidComponent;
  private final JComponent baseComponent;

  public AnimatedCompositeLayout(JComponent baseComponent, JComponent overlaidComponent) {
    Ensure.ensureArgumentNotNull(baseComponent);
    Ensure.ensureArgumentNotNull(overlaidComponent);
    this.baseComponent = baseComponent;
    this.overlaidComponent = overlaidComponent;
  }

  public void addLayoutComponent(String name, Component comp) {
    if (comp != baseComponent && comp != overlaidComponent) {
      throw new IllegalArgumentException(
          "No other components may be added to an animated composite panel, tried to add " + comp); //$NON-NLS-1$
    }
  }

  public void addLayoutComponent(Component comp, Object constraints) {
    if (comp != baseComponent && comp != overlaidComponent) {
      throw new IllegalArgumentException(
          "No other components may be added to an animated composite panel, tried to add " + comp); //$NON-NLS-1$
    }
  }

  public void layoutContainer(Container parent) {
    synchronized (parent.getTreeLock()) {
      AnimatedCompositeComponent component = (AnimatedCompositeComponent) parent;
      Insets insets = parent.getInsets();
      final Dimension size = parent.getSize();
      baseComponent.setBounds(
          insets.left,
          insets.top,
          size.width - (insets.left + insets.right),
          size.height - (insets.top + insets.bottom));
      overlaidComponent.setBounds(
          insets.left,
          insets.top + size.height - component.getOverlayPositionFromBottom(),
          size.width - (insets.left + insets.right),
          size.height - (insets.top + insets.bottom));
      //baseComponent.setVisible(!component.isOverlayVisible());
      overlaidComponent.setVisible(component.getOverlayPositionFromBottom() > 0);
      baseComponent.setVisible(component.getOverlayPositionFromBottom() < size.height);
    }
  }

  public Dimension minimumLayoutSize(Container parent) {
    synchronized (parent.getTreeLock()) {
      Insets insets = parent.getInsets();
      Dimension size1 = baseComponent.getMinimumSize();
      Dimension size2 = overlaidComponent.getMinimumSize();
      return new Dimension(
          insets.left + insets.right + Math.max(size1.width, size2.width),
          insets.top + insets.bottom + Math.max(size1.height, size2.height));
    }
  }

  public Dimension preferredLayoutSize(Container parent) {
    synchronized (parent.getTreeLock()) {
      Insets insets = parent.getInsets();
      Dimension size1 = baseComponent.getPreferredSize();
      Dimension size2 = overlaidComponent.getPreferredSize();
      return new Dimension(
          insets.left + insets.right + Math.max(size1.width, size2.width),
          insets.top + insets.bottom + Math.max(size1.height, size2.height));
    }
  }

  public Dimension maximumLayoutSize(Container target) {
    return new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE);
  }

  public float getLayoutAlignmentX(Container parent) {
    return 0.5f;
  }

  /**
   * Returns the alignment along the y axis.  This specifies how
   * the component would like to be aligned relative to other
   * components.  The value should be a number between 0 and 1
   * where 0 represents alignment along the origin, 1 is aligned
   * the furthest away from the origin, 0.5 is centered, etc.
   */
  public float getLayoutAlignmentY(Container parent) {
    return 0.5f;
  }

  public void invalidateLayout(Container target) {
    //nothing to do
  }

  public void removeLayoutComponent(Component comp) {
    //nothing to do
  }
}