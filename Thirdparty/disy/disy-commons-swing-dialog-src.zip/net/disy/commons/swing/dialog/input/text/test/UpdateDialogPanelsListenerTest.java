/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.test;

import static org.easymock.EasyMock.*;

import net.disy.commons.swing.dialog.input.text.IUpdatableSmartDialogPanel;
import net.disy.commons.swing.dialog.input.text.UpdateDialogPanelsListener;

import org.junit.Test;

public class UpdateDialogPanelsListenerTest {

  @Test
  public void updateIsCalledOnPanels() throws Exception {
    final IUpdatableSmartDialogPanel firstPanel = createMock(IUpdatableSmartDialogPanel.class);
    final IUpdatableSmartDialogPanel secondPanel = createMock(IUpdatableSmartDialogPanel.class);
    firstPanel.update();
    secondPanel.update();
    replay(firstPanel, secondPanel);
    final UpdateDialogPanelsListener listener = new UpdateDialogPanelsListener();
    listener.setPanels(firstPanel, secondPanel);
    listener.stateChanged();
    verify(firstPanel, secondPanel);
  }

  @Test
  public void nothingHappensIfNoPanelsAreSet() throws Exception {
    new UpdateDialogPanelsListener().stateChanged();
  }

}
