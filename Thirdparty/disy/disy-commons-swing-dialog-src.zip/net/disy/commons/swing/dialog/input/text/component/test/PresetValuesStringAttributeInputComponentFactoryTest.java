/**
 * Copyright (C) 2005, 2011 disy Informationssysteme GmbH and others
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Common Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/cpl-v10.html
 */
package net.disy.commons.swing.dialog.input.text.component.test;

import static org.easymock.EasyMock.*;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.*;

import java.util.ArrayList;

import javax.swing.JComboBox;

import net.disy.commons.swing.dialog.input.object.IAttributeValueListFactory;
import net.disy.commons.swing.dialog.input.text.IAttributeContext;
import net.disy.commons.swing.dialog.input.text.component.IStringInputComponent;
import net.disy.commons.swing.dialog.input.text.component.PresetValuesStringAttributeInputComponentFactory;
import net.disy.commons.swing.dialog.input.text.component.StringComboBox;

import org.junit.Test;

public class PresetValuesStringAttributeInputComponentFactoryTest {

  @SuppressWarnings("unchecked")
  @Test
  public void createsStringComboBoxWithValuesOfGivenValueListFactory() throws Exception {
    final IAttributeValueListFactory<String> presetValueListFactory = createMock(IAttributeValueListFactory.class);
    final IAttributeContext attributeContext = createNiceMock(IAttributeContext.class);
    final ArrayList<String> valueList = new ArrayList<String>();
    valueList.add("eins"); //$NON-NLS-1$
    valueList.add("zwei"); //$NON-NLS-1$
    expect(presetValueListFactory.createList(attributeContext)).andReturn(valueList);
    replay(presetValueListFactory, attributeContext);
    final IStringInputComponent<JComboBox> component = new PresetValuesStringAttributeInputComponentFactory(
        presetValueListFactory,
        attributeContext).createComponent();
    assertThat(component, is(instanceOf(StringComboBox.class)));
    final JComboBox jComboBox = component.getComponent();
    assertThat(jComboBox.getItemCount(), is(2));
    assertThat(jComboBox.getItemAt(0), is((Object) "eins")); //$NON-NLS-1$
    assertThat(jComboBox.getItemAt(1), is((Object) "zwei")); //$NON-NLS-1$
    verify(presetValueListFactory);
  }
}
