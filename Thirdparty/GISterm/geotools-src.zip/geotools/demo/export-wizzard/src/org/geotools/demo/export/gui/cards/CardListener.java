/*
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 */
package org.geotools.demo.export.gui.cards;

/**
 * DOCUMENT ME!
 *
 * @author Gabriel Roldan, Axios Engineering
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/demo/export/src/org/geotools/demo/export/gui/cards/CardListener.java $
 * @version $Id: CardListener.java 17699 2006-01-22 22:42:41Z desruisseaux $
 */
public interface CardListener {
    /**
     * DOCUMENT ME!
     *
     * @param enable DOCUMENT ME!
     */
    void setNextEnabled(boolean enable);

    /**
     * DOCUMENT ME!
     *
     * @param enable DOCUMENT ME!
     */
    void setPreviousEnabled(boolean enable);

    /**
     * DOCUMENT ME!
     *
     * @param enable DOCUMENT ME!
     */
    void setFinishEnabled(boolean enable);
}
