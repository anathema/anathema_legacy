/*
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */
package org.geotools.brewer.color;

import java.io.IOException;

import org.geotools.data.DataTestCase;
import org.geotools.data.DataUtilities;
import org.geotools.data.FeatureSource;
import org.geotools.feature.Feature;
import org.geotools.feature.FeatureCollection;
import org.geotools.feature.FeatureIterator;
import org.geotools.feature.FeatureType;
import org.geotools.filter.Filter;
import org.geotools.filter.FilterFactory;
import org.geotools.filter.FilterFactoryFinder;
import org.geotools.filter.IllegalFilterException;
import org.geotools.filter.MathExpression;
import org.geotools.filter.function.ClassificationFunction;
import org.geotools.filter.function.EqualIntervalFunction;
import org.geotools.styling.FeatureTypeStyle;
import org.geotools.styling.Rule;


/**
 *
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/brewer/test/org/geotools/brewer/color/StyleGeneratorTest.java $
 */
public class StyleGeneratorTest extends DataTestCase {
    public StyleGeneratorTest(String arg0) {
        super(arg0);
    }
    
    public void checkFilteredResultNotEmpty(Rule[] rule, FeatureSource fs, String attribName) throws IOException {
        for (int i = 0; i < rule.length; i++) {
        	Filter filter = rule[i].getFilter();
        	FeatureCollection filteredCollection = fs.getFeatures(filter).collection();
        	assertTrue(filteredCollection.size() > 0); 
        	String filterInfo = "Filter \""+filter.toString()+"\" contains "+filteredCollection.size()+" element(s) (";
        	FeatureIterator it = filteredCollection.features();
        	while (it.hasNext()) {
        		Feature feature = it.next();
        		filterInfo+="'"+feature.getAttribute(attribName)+"'";
        		if (it.hasNext()) filterInfo+=", ";
        	}
        	System.out.println(filterInfo+")");
        }
    }
    
    public void testComplexExpression() throws Exception {
        System.out.println("Complex Expression (using Sequential)");
        ColorBrewer brewer = new ColorBrewer();
        brewer.loadPalettes();

        FilterFactory ff = FilterFactoryFinder.createFilterFactory();
        MathExpression expr = null;
        MathExpression expr2 = null;
        FeatureType type = roadType;
        String attribName = type.getAttributeType(0).getName();
        FeatureCollection fc = DataUtilities.collection(roadFeatures);
        FeatureSource fs = DataUtilities.source(fc);

        try {
            expr = ff.createMathExpression(MathExpression.MATH_MULTIPLY);
            expr.addLeftValue(ff.createAttributeExpression(type, attribName));
            expr.addRightValue(ff.createAttributeExpression(type, attribName));
            expr2 = ff.createMathExpression(MathExpression.MATH_ADD);
            expr2.addLeftValue(expr);
            expr2.addRightValue(ff.createLiteralExpression(3));
        } catch (IllegalFilterException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        String paletteName = "YlGn"; //type = Sequential

        //create the classification function
        ClassificationFunction classifier = new EqualIntervalFunction();
        classifier.setNumberOfClasses(2);
        classifier.setCollection(fc);
        classifier.setExpression(expr2);
        classifier.getValue(0); //recalc classes? (only useful for UniqueInterval) 

        //get the fts
        StyleGenerator sg = new StyleGenerator(brewer.getPalette(paletteName).getColors(2), classifier, "myfts");
        FeatureTypeStyle fts = sg.createFeatureTypeStyle();
        assertNotNull(fts);
        
        //test each filter
        Rule[] rule = fts.getRules();
        //do a preliminary test to make sure each rule's filter returns some results
        checkFilteredResultNotEmpty(rule, fs, attribName);
    }
}
