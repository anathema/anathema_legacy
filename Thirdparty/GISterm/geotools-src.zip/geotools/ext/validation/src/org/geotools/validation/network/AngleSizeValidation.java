/*
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 */
/*
 * Created on Jan 24, 2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.geotools.validation.network;

import java.util.Map;

import org.geotools.validation.DefaultIntegrityValidation;
import org.geotools.validation.ValidationResults;

import com.vividsolutions.jts.geom.Envelope;


/**
 * StarNodeValidation purpose.
 * 
 * <p>
 * TODO fill this in.
 * </p>
 *
 * @author dzwiers, Refractions Research, Inc.
 * @author $Author: dmzwiers $ (last modification)
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/validation/src/org/geotools/validation/network/AngleSizeValidation.java $
 * @version $Id: AngleSizeValidation.java 17704 2006-01-23 00:26:16Z desruisseaux $
 */
public class AngleSizeValidation extends DefaultIntegrityValidation {
	
	private int angle;
	
    /**
     * StarNodeValidation constructor.
     * 
     * <p>
     * Description
     * </p>
     */
    public AngleSizeValidation() {
        super();
        // TODO Auto-generated constructor stub
    }

    /**
     * Check FeatureType for ...
     * 
     * <p>
     * Detailed description...
     * </p>
     *
     * @param layers Map of FeatureSource by "dataStoreID:typeName"
     * @param envelope The bounding box that encloses the unvalidated data
     * @param results Used to coallate results information
     *
     * @return <code>true</code> if all the features pass this test.
     *
     * @throws Exception DOCUMENT ME!
     */
    public boolean validate(Map layers, Envelope envelope,
    		ValidationResults results) throws Exception {
    	results.warning(null, "Validation not yet implemented");
    	// TODO fill me in!
    	return false;
    }
	/**
	 * Access angle property.
	 * 
	 * @return Returns the angle.
	 */
	public int getAngle() {
		return angle;
	}
	/**
	 * Set angle to angle.
	 *
	 * @param angle The angle to set.
	 */
	public void setAngle(int angle) {
		this.angle = angle;
	}
}
