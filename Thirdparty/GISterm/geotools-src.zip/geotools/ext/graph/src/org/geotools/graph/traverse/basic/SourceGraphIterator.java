/*
 *    $Id: SourceGraphIterator.java 17704 2006-01-23 00:26:16Z desruisseaux $
 *   
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */

package org.geotools.graph.traverse.basic;

import org.geotools.graph.structure.Graphable;

/**
 * A GraphIterator that starts iteration from a specefied point.
 * 
 * @author Justin Deoliveira, Refractions Research Inc, jdeolive@refractions.net
 *
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/graph/src/org/geotools/graph/traverse/basic/SourceGraphIterator.java $
 */
public abstract class SourceGraphIterator extends AbstractGraphIterator {
  
  /** source of the iteration **/
  private Graphable m_source;
  
  /**
   * Sets the source for the iteration.
   * 
   * @param source The source of the iteration.
   */
  public void setSource(Graphable source) {
    m_source = source;  
  }
  
  /**
   * Returns the source of the iteration.
   *  
   * @return The source of the iteration.
   */
  public Graphable getSource() {
    return(m_source);  
  }
   
}
