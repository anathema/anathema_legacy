/*
 *    $Id: DirectedCycleDetector.java 17704 2006-01-23 00:26:16Z desruisseaux $
 * 
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 */

package org.geotools.graph.util.graph;

import org.geotools.graph.structure.Graph;
import org.geotools.graph.traverse.GraphIterator;
import org.geotools.graph.traverse.standard.DirectedBreadthFirstTopologicalIterator;

/**
 * Detects cycles in a directed graph. A directed topological iteration 
 * of the nodes of the graph is performed. If the iteration includes all nodes 
 * in the graph then the graph is cycle free, otherwise a cycle exists. 
 * 
 * @see org.geotools.graph.traverse.standard.DirectedBreadthFirstTopologicalIterator
 * @author Justin Deoliveira, Refractions Research Inc, jdeolive@refractions.net
 *
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/graph/src/org/geotools/graph/util/graph/DirectedCycleDetector.java $
 */

public class DirectedCycleDetector extends CycleDetector {

	public DirectedCycleDetector(Graph graph) {
		super(graph);
	}

	protected GraphIterator createIterator() {
		return(new DirectedBreadthFirstTopologicalIterator());
	}

	
}
