/*
 * Created on 15-feb-2004
 */
package org.geotools.gui.swing.sldeditor.property;

import javax.swing.JComponent;

import org.geotools.gui.swing.sldeditor.SLDEditor;
import org.geotools.styling.Mark;

/**
 * @author wolf
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/legend/src/org/geotools/gui/swing/sldeditor/property/MarkEditor.java $
 */
public abstract class MarkEditor extends JComponent implements SLDEditor {
    public abstract void setMark(Mark mark);
    public abstract Mark getMark();
}
