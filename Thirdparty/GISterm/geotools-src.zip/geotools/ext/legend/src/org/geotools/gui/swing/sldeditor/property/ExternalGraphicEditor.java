/*
 * Created on 15-feb-2004
 */
package org.geotools.gui.swing.sldeditor.property;

import javax.swing.JComponent;

import org.geotools.gui.swing.sldeditor.SLDEditor;
import org.geotools.styling.ExternalGraphic;

/**
 * @author wolf
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/legend/src/org/geotools/gui/swing/sldeditor/property/ExternalGraphicEditor.java $
 */
public abstract class ExternalGraphicEditor extends JComponent implements SLDEditor {
    public abstract void setExternalGraphic(ExternalGraphic externalGraphic);
    public abstract ExternalGraphic getExternalGraphic();
}
