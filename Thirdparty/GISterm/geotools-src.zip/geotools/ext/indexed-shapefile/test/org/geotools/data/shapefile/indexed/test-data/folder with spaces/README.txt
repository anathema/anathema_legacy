The content of this directory is not shared in module/sample-data
because some tests check for file existence. If the files were in
module/sample-data, they would be reacheable only through an URL,
not as a File.
