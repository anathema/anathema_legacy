/*
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 */
/*
 *    Geotools - OpenSource mapping toolkit
 *    (C) 2002, Centre for Computational Geography
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package org.geotools.index;

import java.nio.charset.Charset;
import java.util.ArrayList;


/**
 * DOCUMENT ME!
 *
 * @author Tommaso Nolli
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/shape/src/org/geotools/index/DataDefinition.java $
 */
public class DataDefinition {
    private Charset charset;
    private ArrayList fields;

    public DataDefinition(String charset) {
        fields = new ArrayList();
        this.charset = Charset.forName(charset);
    }

    public final boolean isValid() {
        return (this.charset != null) && !this.charset.equals("")
        && (this.fields.size() > 0);
    }

    public int getFieldsCount() {
        return this.fields.size();
    }

    public Field getField(int i) {
        return (Field) this.fields.get(i);
    }

    /**
     * Well known classes
     * 
     * <ul>
     * <li>
     * Short
     * </li>
     * <li>
     * Integer
     * </li>
     * <li>
     * Long
     * </li>
     * <li>
     * Float
     * </li>
     * <li>
     * Double
     * </li>
     * <li>
     * Date
     * </li>
     * </ul>
     * 
     *
     * @param clazz
     *
     * @throws TreeException DOCUMENT ME!
     */
    public void addField(Class clazz) {
        if (clazz.isAssignableFrom(Short.class)) {
            this.fields.add(new Field(clazz, 2));
        } else if (clazz.isAssignableFrom(Integer.class)) {
            this.fields.add(new Field(clazz, 4));
        } else if (clazz.isAssignableFrom(Long.class)) {
            this.fields.add(new Field(clazz, 8));
        } else if (clazz.isAssignableFrom(Float.class)) {
            // TODO: Are you sure of 4 bytes?
            this.fields.add(new Field(clazz, 4));
        } else if (clazz.isAssignableFrom(Double.class)) {
            this.fields.add(new Field(clazz, 8));
        } else {
            throw new IllegalArgumentException("Unknow len of class " + clazz
                + "use addField(int)");
        }
    }

    /**
     * For classes with unknown length; this values will be threated as
     * <code>String</code>s and truncated at the specified len
     *
     * @param len
     */
    public void addField(int len) {
        this.fields.add(new Field(String.class, len));
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public Charset getCharset() {
        return charset;
    }

    /**
     * Gets the max len of the data
     *
     * @return
     */
    public int getLen() {
        int len = 0;

        Field field = null;

        for (int i = 0; i < this.fields.size(); i++) {
            field = (Field) this.fields.get(i);
            len += field.getLen();
        }

        return len;
    }

    /**
     * Gets the len of this field after the encoding, this method may be
     * different from getLen() only if exists strings in the definition
     *
     * @return
     */
    public int getEncodedLen() {
        int len = 0;

        Field field = null;

        for (int i = 0; i < this.fields.size(); i++) {
            field = (Field) this.fields.get(i);
            len += field.getEncodedLen();
        }

        return len;
    }

    /**
     * Inner class for Data fields
     *
     * @author Tommaso Nolli
     */
    public class Field {
        private Class clazz;
        private int len;

        public Field(Class clazz, int len) {
            this.clazz = clazz;
            this.len = len;
        }

        /**
         * DOCUMENT ME!
         *
         * @return
         */
        public Class getFieldClass() {
            return clazz;
        }

        /**
         * DOCUMENT ME!
         *
         * @return
         */
        public int getLen() {
            return len;
        }

        /**
         * DOCUMENT ME!
         *
         * @return
         */
        public int getEncodedLen() {
            int ret = this.len;

            if (this.clazz.equals(String.class)) {
                ret = (int) charset.newEncoder().maxBytesPerChar() * this.len;
            }

            return ret;
        }
    }
}
