/*
 *    Geotools2 - OpenSource mapping toolkit
 *    http://geotools.org
 *    (C) 2002, Geotools Project Managment Committee (PMC)
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 */
/*
 *    Geotools - OpenSource mapping toolkit
 *    (C) 2002, Centre for Computational Geography
 *
 *    This library is free software; you can redistribute it and/or
 *    modify it under the terms of the GNU Lesser General Public
 *    License as published by the Free Software Foundation;
 *    version 2.1 of the License.
 *
 *    This library is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    Lesser General Public License for more details.
 *
 *    You should have received a copy of the GNU Lesser General Public
 *    License along with this library; if not, write to the Free Software
 *    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 */
package org.geotools.index.rtree.fs;

import org.geotools.index.DataDefinition;
import java.nio.channels.FileChannel;
import java.util.Stack;


/**
 * DOCUMENT ME!
 *
 * @author Tommaso Nolli
 * @source $URL: http://svn.geotools.org/geotools/tags/2.2.RC1/ext/shape/src/org/geotools/index/rtree/fs/Parameters.java $
 */
public class Parameters {
    private int maxNodeEntries;
    private int minNodeEntries;
    private short splitAlg;
    private DataDefinition dataDef;
    private FileChannel channel;
    private Stack freePages;
    private boolean forceChannel;

    public Parameters() {
        this.freePages = new Stack();
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public FileChannel getChannel() {
        return channel;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public DataDefinition getDataDef() {
        return dataDef;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public int getMaxNodeEntries() {
        return maxNodeEntries;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public int getMinNodeEntries() {
        return minNodeEntries;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public short getSplitAlg() {
        return splitAlg;
    }

    /**
     * DOCUMENT ME!
     *
     * @param channel
     */
    public void setChannel(FileChannel channel) {
        this.channel = channel;
    }

    /**
     * DOCUMENT ME!
     *
     * @param definition
     */
    public void setDataDef(DataDefinition definition) {
        dataDef = definition;
    }

    /**
     * DOCUMENT ME!
     *
     * @param i
     */
    public void setMaxNodeEntries(int i) {
        maxNodeEntries = i;
    }

    /**
     * DOCUMENT ME!
     *
     * @param i
     */
    public void setMinNodeEntries(int i) {
        minNodeEntries = i;
    }

    /**
     * DOCUMENT ME!
     *
     * @param s
     */
    public void setSplitAlg(short s) {
        splitAlg = s;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public boolean getForceChannel() {
        return forceChannel;
    }

    /**
     * DOCUMENT ME!
     *
     * @param b
     */
    public void setForceChannel(boolean b) {
        forceChannel = b;
    }

    /**
     * DOCUMENT ME!
     *
     * @return
     */
    public Stack getFreePages() {
        return freePages;
    }

    /**
     * DOCUMENT ME!
     *
     * @param stack
     */
    public void setFreePages(Stack stack) {
        freePages = stack;
    }
}
