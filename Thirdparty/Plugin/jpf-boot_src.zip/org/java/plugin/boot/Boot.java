/*****************************************************************************
 * Java Plug-in Framework (JPF)
 * Copyright (C) 2004-2005 Dmitry Olshansky
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *****************************************************************************/
package org.java.plugin.boot;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.InetAddress;
import java.util.Locale;

import org.apache.commons.logging.LogFactory;
import org.java.plugin.PluginManager;
import org.java.plugin.util.ExtendedProperties;
import org.java.plugin.util.IoUtil;
import org.java.plugin.util.ResourceManager;

/**
 * Main class to get JPF based application running in different modes.
 * Application mode may be specified as <code>jpf.boot.mode</code> System
 * property (via <code>-Djpf.boot.mode=</code> command line argument). Supported
 * values are:
 * <dl>
 *   <dt>start</dt>
 *   <dd>Runs application in "background" ("service") mode.</dd>
 *   <dt>stop</dt>
 *   <dd>Stops application, running in "background" mode.</dd>
 *   <dt>restart</dt>
 *   <dd>Restarts application, running in "background" mode. If it is not
 *     started, the action is the same as just starting application.</dd>
 *   <dt>shell</dt>
 *   <dd>Runs application in "shell" (or "interactive") mode. It is possible to
 *     control "service" style application from command line. Note, that
 *     currently running application will be stopped first.</dd>
 * </dl>
 * The "shell" mode is default. Application will be started in this mode if no
 * <code>jpf.boot.mode</code> System property can be found.
 * <p>
 * Application configuration is expected to be in <code>boot.properties</code>
 * file located in the current directory. Note that properties will be loaded
 * using {@link org.java.plugin.util.ExtendedProperties specially extended}
 * version of {@link java.util.Properties} class, which supports parameters
 * substitution. If there is no <code>applicationRoot</code> property available
 * in the given configuration, the current folder will be published as default
 * value.
 * </p>
 * <p>
 * Standard configuration parameters are (all are optional when application is
 * running in "shell" mode):
 * <dl>
 *   <dt>org.java.plugin.boot.appInitializer</dt>
 *   <dd>Application initializer class, for details see
 *   {@link org.java.plugin.boot.ApplicationInitializer}. Default is
 *   {@link org.java.plugin.boot.DefaultApplicationInitializer}.</dd>
 *   <dt>org.java.plugin.boot.errorHandler</dt>
 *   <dd>Error handler class, for details see
 *     {@link org.java.plugin.boot.BootErrorHandler}. Default is
 *     {@link org.java.plugin.boot.BootErrorHandlerConsole} for "service" style
 *     applications and {@link org.java.plugin.boot.BootErrorHandlerGui} for
 *     "interactive" applications.</dd>
 *   <dt>org.java.plugin.boot.controlHost</dt>
 *   <dd>Host to be used by background control service, no default values.</dd>
 *   <dt>org.java.plugin.boot.controlPort</dt>
 *   <dd>Port number to be used by background control service, no default
 *     values.</dd>
 *   <dt>org.java.plugin.boot.splashImage</dt>
 *   <dd>Path to an image file to be shown as splash screen. If no file given,
 *     the splash screen will not be shown.</dd>
 * </dl>
 *
 * @version $Id: Boot.java,v 1.9 2006/03/15 19:24:41 ddimon Exp $
 */
public final class Boot {
    /**
     * Name of the file, where to put boot error details.
     */
    public static final String BOOT_ERROR_FILE_NAME = "jpf-boot-error.txt"; //$NON-NLS-1$
    
    /**
     * Boot mode System property name.
     */
    public static final String BOOT_MODE_COMMAND_NAME = "jpf.boot.mode"; //$NON-NLS-1$
    
    /**
     * "shell" mode boot command value.
     */
    public static final String BOOT_MODE_SHELL = "shell"; //$NON-NLS-1$
    
    /**
     * "start" mode boot command value.
     */
    public static final String BOOT_MODE_START = "start"; //$NON-NLS-1$
    
    /**
     * "stop" mode boot command value.
     */
    public static final String BOOT_MODE_STOP = "stop"; //$NON-NLS-1$
    
    /**
     * "restart" mode boot command value.
     */
    public static final String BOOT_MODE_RESTART = "restart"; //$NON-NLS-1$
    
    // This is for ResourceManager to look up resources.
    static final String PACKAGE_NAME = "org.java.plugin.boot"; //$NON-NLS-1$
    
    // Application bootstrap configuration parameter names goes here
    private static final String PARAM_CONTROL_HOST =
        "org.java.plugin.boot.controlHost"; //$NON-NLS-1$
    private static final String PARAM_CONTROL_PORT =
        "org.java.plugin.boot.controlPort"; //$NON-NLS-1$
    private static final String PARAM_ERROR_HANDLER =
        "org.java.plugin.boot.errorHandler"; //$NON-NLS-1$
    private static final String PARAM_APP_INITIALIZER =
        "org.java.plugin.boot.appInitializer"; //$NON-NLS-1$
    private static final String PARAM_SPLASH_IMAGE =
        "org.java.plugin.boot.splashImage"; //$NON-NLS-1$
    
    /**
     * Call this method to start/stop application.
     * @param args command line arguments, not interpreted by this method but
     *             passed to
     *             {@link ApplicationPlugin#initApplication(ExtendedProperties, String[])}
     *             method
     */
    public static void main(final String[] args) {
        clearBootLog();
        // Load start-up configuration
        ExtendedProperties props = new ExtendedProperties(
                System.getProperties());
        try {
            InputStream strm = new FileInputStream("boot.properties"); //$NON-NLS-1$
            try {
                props.load(strm);
            } finally {
                strm.close();
            }
        } catch (IOException e) {
            // ignore
        }
        boolean useControlService = props.containsKey(PARAM_CONTROL_HOST)
            && props.containsKey(PARAM_CONTROL_PORT);
        BootErrorHandler errorHandler = getErrorHandlerInstance(
                props.getProperty(PARAM_ERROR_HANDLER), useControlService);
        try {
            if (props.getProperty("applicationRoot") == null) { //$NON-NLS-1$
                // Publish current folder as configuration parameter
                // to get it available as ${applicationRoot} variable
                // in extended properties syntax.
                String applicationRoot = new File(".").getCanonicalPath(); //$NON-NLS-1$
                props.put("applicationRoot", applicationRoot);  //$NON-NLS-1$
            }
            InetAddress controlHost = useControlService ? InetAddress.getByName(
                    props.getProperty(PARAM_CONTROL_HOST)) : null;
            int controlPort = useControlService ? Integer.parseInt(
                    props.getProperty(PARAM_CONTROL_PORT), 10) : 0;
            String command = System.getProperty(BOOT_MODE_COMMAND_NAME);
            if (command != null) {
                command = command.trim().toLowerCase(Locale.ENGLISH);
            } else {
                command = BOOT_MODE_SHELL;
                System.setProperty(BOOT_MODE_COMMAND_NAME, command);
            }
            // handle given command
            if (useControlService && BOOT_MODE_STOP.equals(command)) {
                if (!ControlThread.stopRunningApplication(controlHost,
                        controlPort)) {
                    System.out.println("application not running"); //$NON-NLS-1$
                } else {
                    System.out.println("application stopped"); //$NON-NLS-1$
                }
                return;
            }
            if (useControlService && BOOT_MODE_START.equals(command)) {
                if (ControlThread.isApplicationRunning(controlHost,
                        controlPort)) {
                    errorHandler.handleFatalError(
                            "Application already running."); //$NON-NLS-1$
                    return;
                }
                Application application =
                    initApplication(errorHandler, props, args);
                if (!(application instanceof ServiceApplication)) {
                    errorHandler.handleFatalError(
                            "Application is not a service."); //$NON-NLS-1$
                    return;
                }
                ControlThread controlThread = new ControlThread(controlHost,
                        controlPort, (ServiceApplication) application);
                application.startApplication();
                controlThread.start();
                System.out.println(
                        "application started in BACKGROUND mode"); //$NON-NLS-1$
                return;
            }
            if (useControlService && BOOT_MODE_RESTART.equals(command)) {
                if (ControlThread.stopRunningApplication(controlHost,
                        controlPort)) {
                    System.out.println("another instance of application stopped"); //$NON-NLS-1$
                }
                Application application =
                    initApplication(errorHandler, props, args);
                if (!(application instanceof ServiceApplication)) {
                    errorHandler.handleFatalError(
                            "Application is not a service."); //$NON-NLS-1$
                    return;
                }
                ControlThread controlThread = new ControlThread(controlHost,
                        controlPort, (ServiceApplication) application);
                application.startApplication();
                controlThread.start();
                System.out.println(
                        "application started in BACKGROUND mode"); //$NON-NLS-1$
                return;
            }
            // SHELL mode by default
            if (useControlService
                    && ControlThread.stopRunningApplication(controlHost,
                            controlPort)) {
                System.out.println("another instance of application stopped"); //$NON-NLS-1$
            }
            String splashImage = props.getProperty(PARAM_SPLASH_IMAGE, null);
            if ((splashImage != null) && (splashImage.length() > 0)) {
                File splashFile = new File(splashImage);
                if (splashFile.isFile()) {
                    SplashWindow.splash(IoUtil.file2url(splashFile));
                } else {
                    System.out.println("splash image file " //$NON-NLS-1$
                            + splashFile + " not found"); //$NON-NLS-1$
                }
            }
            Application application =
                initApplication(errorHandler, props, args);
            if (application instanceof ServiceApplication) {
                application.startApplication();
                SplashWindow.disposeSplash();
                System.out.println("application started in SHELL mode"); //$NON-NLS-1$
                runShell();
                stopApplication(application);
            } else {
                application.startApplication();
                SplashWindow.disposeSplash();
            }
        } catch (Throwable t) {
            SplashWindow.disposeSplash();
            bootLog(t);
            errorHandler.handleFatalError(ResourceManager.getMessage(
                    Boot.PACKAGE_NAME, "bootFailed"), t); //$NON-NLS-1$
            System.exit(1);
        }
    }
    
    /**
     * Stops the application, shuts down plug-in manager and disposes log
     * service. Call this method before exiting interactive application. For
     * service applications this method will be called automatically by control
     * service or from shell.
     * @param application application instance being stopped
     * @throws Exception if any error has occurred during application stopping
     */
    public static void stopApplication(final Application application)
            throws Exception {
        if (application instanceof ServiceApplication) {
            ((ServiceApplication) application).stopApplication();
        }
        PluginManager pluginManager = PluginManager.lookup(application);
        if (pluginManager != null) {
            pluginManager.shutdown();
        }
        LogFactory.getLog(Boot.class).info("logging system finalized"); //$NON-NLS-1$
        LogFactory.getLog(Boot.class).info("---------------------------------"); //$NON-NLS-1$
        LogFactory.releaseAll();
    }
    
    private static BootErrorHandler getErrorHandlerInstance(
            final String handler, final boolean isServiceApp) {
        if (handler != null) {
            try {
                return (BootErrorHandler) Class.forName(handler).newInstance();
            } catch (InstantiationException ie) {
                // ignore
            } catch (IllegalAccessException iae) {
                // ignore
            } catch (ClassNotFoundException cnfe) {
                // ignore
            }
        }
        return isServiceApp ? new BootErrorHandlerConsole()
                : (BootErrorHandler) new BootErrorHandlerGui();
    }
    
    private static Application initApplication(
            final BootErrorHandler errorHandler,
            final ExtendedProperties props, final String[] args)
            throws Exception {
        ApplicationInitializer appInitializer = null;
        String className = props.getProperty(PARAM_APP_INITIALIZER);
        if (className != null) {
            try {
                appInitializer = (ApplicationInitializer) Class.forName(
                        className).newInstance();
            } catch (InstantiationException ie) {
                // ignore
            } catch (IllegalAccessException iae) {
                // ignore
            } catch (ClassNotFoundException cnfe) {
                // ignore
            }
        }
        if (appInitializer == null) {
            appInitializer = new DefaultApplicationInitializer();
        }
        appInitializer.configure(props);
        Application result = appInitializer.initApplication(errorHandler, args);
        if (result == null) {
            throw new Exception(ResourceManager.getMessage(
                    Boot.PACKAGE_NAME, "bootAppInitFailed")); //$NON-NLS-1$
        }
        return result;
    }
    
    private static void runShell() {
        System.out.println("Press 'q' key to exit."); //$NON-NLS-1$
        do {
            int c;
            try {
                c = System.in.read();
            } catch (IOException ioe) {
                break;
            }
            if (('q' == (char) c) || ('Q' == (char) c)) {
                break;
            }
        } while (true);
    }
    
    private static void clearBootLog() {
        File file = new File(BOOT_ERROR_FILE_NAME);
        if (file.isFile()) {
            file.delete();
        }
    }
    
    private static void bootLog(final Throwable t) {
        try {
            Writer writer = new OutputStreamWriter(
                    new FileOutputStream(BOOT_ERROR_FILE_NAME, false),
                    "UTF-8"); //$NON-NLS-1$
            try {
                writer.write("JPF Application boot failed."); //$NON-NLS-1$
                writer.write(System.getProperty("line.separator")); //$NON-NLS-1$
                writer.write(ErrorDialog.getErrorDetails(t));
            } finally {
                writer.close();
            }
        } catch (Throwable t2) {
            throw new Error("boot failed", t); //$NON-NLS-1$
        }
    }
    
    private Boot() {
        // no-op
    }
}
