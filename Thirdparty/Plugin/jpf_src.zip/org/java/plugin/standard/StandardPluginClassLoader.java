/*****************************************************************************
 * Java Plug-in Framework (JPF)
 * Copyright (C) 2004-2006 Dmitry Olshansky
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *****************************************************************************/
package org.java.plugin.standard;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.security.CodeSource;
import java.security.ProtectionDomain;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.java.plugin.PathResolver;
import org.java.plugin.PluginClassLoader;
import org.java.plugin.PluginManager;
import org.java.plugin.registry.Library;
import org.java.plugin.registry.PluginDescriptor;
import org.java.plugin.registry.PluginPrerequisite;
import org.java.plugin.registry.PluginRegistry;
import org.java.plugin.util.IoUtil;

/**
 * Standard implementation of plug-in class loader.
 * @version $Id: StandardPluginClassLoader.java,v 1.6 2006/04/30 09:22:46 ddimon Exp $
 */
public class StandardPluginClassLoader extends PluginClassLoader {
    static Log log = LogFactory.getLog(StandardPluginClassLoader.class);
    
    private static File libCacheFolder;
    private static boolean libCacheFolderInitialized = false;
    
    private static URL getClassBaseUrl(final Class cls) {
        ProtectionDomain pd = cls.getProtectionDomain();
        if (pd != null) {
            CodeSource cs = pd.getCodeSource();
            if (cs != null) {
                return cs.getLocation();
            }
        }
        return null;
    }

    private static URL[] getUrls(final PluginManager manager,
            final PluginDescriptor descr) {
        List result = new LinkedList();
        for (Iterator it = descr.getLibraries().iterator(); it.hasNext();) {
            Library lib = (Library) it.next();
            if (!lib.isCodeLibrary()) {
                continue;
            }
            result.add(manager.getPathResolver().resolvePath(lib,
                    lib.getPath()));
        }
        if (log.isDebugEnabled()) {
            StringBuffer buf = new StringBuffer();
            buf.append("Code URL's populated for plug-in " //$NON-NLS-1$
                    + descr + ":\r\n"); //$NON-NLS-1$
            for (Iterator it = result.iterator(); it.hasNext();) {
                buf.append("\t"); //$NON-NLS-1$
                buf.append(it.next());
                buf.append("\r\n"); //$NON-NLS-1$
            }
            log.trace(buf.toString());
        }
        return (URL[]) result.toArray(new URL[result.size()]);
    }
    
    private static URL[] getUrls(final PluginManager manager,
            final PluginDescriptor descr, final URL[] existingUrls) {
        List urls = Arrays.asList(existingUrls);
        List result = new LinkedList();
        for (Iterator it = descr.getLibraries().iterator(); it.hasNext();) {
            Library lib = (Library) it.next();
            if (!lib.isCodeLibrary()) {
                continue;
            }
            URL url = manager.getPathResolver().resolvePath(lib, lib.getPath());
            if (!urls.contains(url)) {
                result.add(url);
            }
        }
        return (URL[]) result.toArray(new URL[result.size()]);
    }
    
    private static File getLibCacheFolder() {
        if (libCacheFolder != null) {
            return libCacheFolderInitialized ? libCacheFolder : null;
        }
        synchronized (StandardPluginClassLoader.class) {
            libCacheFolder = new File(System.getProperty("java.io.tmpdir"), //$NON-NLS-1$
                    System.currentTimeMillis() + ".jpf-lib-cache"); //$NON-NLS-1$
            log.debug("libraries cache folder is " + libCacheFolder); //$NON-NLS-1$
            File lockFile = new File(libCacheFolder, "lock"); //$NON-NLS-1$
            if (lockFile.exists()) {
                log.error("can't initialize libraries cache folder " //$NON-NLS-1$
                        + libCacheFolder + " as lock file indicates that it" //$NON-NLS-1$
                        + " is owned by another JPF instance"); //$NON-NLS-1$
                return null;
            }
            if (libCacheFolder.exists()) {
                // clean up folder
                IoUtil.emptyFolder(libCacheFolder);
            } else {
                libCacheFolder.mkdirs();
            }
            try {
                if (!lockFile.createNewFile()) {
                    log.error("can\'t create lock file in JPF libraries cache" //$NON-NLS-1$
                            + " folder " + libCacheFolder); //$NON-NLS-1$
                    return null;
                }
            } catch (IOException ioe) {
                log.error("can\'t create lock file in JPF libraries cache" //$NON-NLS-1$
                        + " folder " + libCacheFolder, ioe); //$NON-NLS-1$
                return null;
            }
            lockFile.deleteOnExit();
            libCacheFolder.deleteOnExit();
            libCacheFolderInitialized = true;
        }
        return libCacheFolder;
    }
    
    private PluginDescriptor[] publicImports;
    private PluginDescriptor[] privateImports;
    private PluginResourceLoader resourceLoader;
    private Map resourceFilters; // <lib URL, ResourceFilter>
    private Map libraryCache; // <libname, File>
    private boolean probeParentLoaderLast;

    /**
     * Creates class instance configured to load classes and resources for
     * given plug-in.
     * @param aManager plug-in manager instance
     * @param descr plug-in descriptor
     * @param parent parent class loader, usually this is JPF "host"
     *        application class loader
     */
    public StandardPluginClassLoader(final PluginManager aManager,
            final PluginDescriptor descr, final ClassLoader parent) {
        super(aManager, descr, getUrls(aManager, descr), parent);
        collectImports();
        resourceLoader = PluginResourceLoader.get(aManager, descr);
        collectFilters();
        libraryCache = new HashMap();
    }
    
    private void collectImports() {
        // collect imported plug-ins (exclude duplicates)
        Map publicImportsMap = new HashMap(); //<plug-in ID, PluginDescriptor>
        Map privateImportsMap = new HashMap(); //<plug-in ID, PluginDescriptor>
        PluginRegistry registry = getPluginDescriptor().getRegistry();
        for (Iterator it = getPluginDescriptor().getPrerequisites().iterator();
                it.hasNext();) {
            PluginPrerequisite pre = (PluginPrerequisite) it.next();
            if (!pre.matches()) {
                continue;
            }
            PluginDescriptor preDescr =
                registry.getPluginDescriptor(pre.getPluginId());
            if (pre.isExported()) {
                publicImportsMap.put(preDescr.getId(), preDescr);
            } else {
                privateImportsMap.put(preDescr.getId(), preDescr);
            }
        }
        publicImports = (PluginDescriptor[]) publicImportsMap.values().toArray(
                new PluginDescriptor[publicImportsMap.size()]);
        privateImports =
            (PluginDescriptor[]) privateImportsMap.values().toArray(
                new PluginDescriptor[privateImportsMap.size()]);
    }
    
    private void collectFilters() {
        if (resourceFilters == null) {
            resourceFilters = new HashMap();
        } else {
            resourceFilters.clear();
        }
        for (Iterator it = getPluginDescriptor().getLibraries().iterator();
                it.hasNext();) {
            Library lib = (Library) it.next();
            resourceFilters.put(
                    getPluginManager().getPathResolver().resolvePath(lib,
                            lib.getPath()), new ResourceFilter(lib));
        }
    }
    
    /**
     * @see org.java.plugin.PluginClassLoader#pluginsSetChanged()
     */
    protected void pluginsSetChanged() {
        URL[] newUrls = getUrls(getPluginManager(), getPluginDescriptor(),
                getURLs());
        for (int i = 0; i < newUrls.length; i++) {
            addURL(newUrls[i]);
        }
        if (log.isDebugEnabled()) {
            StringBuffer buf = new StringBuffer();
            buf.append("New code URL's populated for plug-in " //$NON-NLS-1$
                    + getPluginDescriptor() + ":\r\n"); //$NON-NLS-1$
            for (int i = 0; i < newUrls.length; i++) {
                buf.append("\t"); //$NON-NLS-1$
                buf.append(newUrls[i]);
                buf.append("\r\n"); //$NON-NLS-1$
            }
            log.trace(buf.toString());
        }
        collectImports();
        // repopulate resource URLs
        resourceLoader =
            PluginResourceLoader.get(getPluginManager(), getPluginDescriptor());
        collectFilters();
        for (Iterator it = libraryCache.entrySet().iterator(); it.hasNext();) {
            if (((Map.Entry) it.next()).getValue() == null) {
                it.remove();
            }
        }
    }
    
    /**
     * @see org.java.plugin.PluginClassLoader#dispose()
     */
    protected void dispose() {
        for (Iterator it = libraryCache.values().iterator(); it.hasNext();) {
            ((File) it.next()).delete();
        }
        libraryCache.clear();
        resourceFilters.clear();
        privateImports = null;
        publicImports = null;
        resourceLoader = null;
    }
    
    void setProbeParentLoaderLast(final boolean value) {
        probeParentLoaderLast = value;
    }
    
    /**
     * @see java.lang.ClassLoader#loadClass(java.lang.String, boolean)
     */
    protected Class loadClass(final String name, final boolean resolve)
            throws ClassNotFoundException {
        /*log.debug("loadClass(String, boolean): name=" + name + ", this="
                + this);*/
        Class result;
        if (probeParentLoaderLast) {
            try {
                result = loadClass(name, resolve, this, null);
            } catch (ClassNotFoundException cnfe) {
                result = getParent().loadClass(name);
            }
            if (result == null) {
                result = getParent().loadClass(name);
            }
        } else {
            try {
                result = getParent().loadClass(name);
            } catch (ClassNotFoundException cnfe) {
                result = loadClass(name, resolve, this, null);
            }
        }
        if (result != null) {
            return result;
        }
        throw new ClassNotFoundException(name);
    }
    
    private Class loadClass(final String name, final boolean resolve,
            final StandardPluginClassLoader requestor, Set seen)
            throws ClassNotFoundException {
        /*log.debug("loadClass(String, boolean, ...): name=" + name + ", this="
                + this);*/
        if ((seen != null) && seen.contains(getPluginDescriptor().getId())) {
            return null;
        }
        if ((this != requestor)
                && !getPluginManager().isPluginActivated(getPluginDescriptor())
                && !getPluginManager().isPluginActivating(
                        getPluginDescriptor())) {
            String msg = "can't load class " + name + ", plug-in " //$NON-NLS-1$ //$NON-NLS-2$
                + getPluginDescriptor() + " is not activated yet"; //$NON-NLS-1$
            log.warn(msg);
            throw new ClassNotFoundException(msg);
        }
        Class result = null;
        synchronized (this) {
            result = findLoadedClass(name);
            if (result != null) {
                if (log.isDebugEnabled()) {
                    log.debug("loadClass(...): found loaded class, class=" //$NON-NLS-1$
                            + result + ", this=" //$NON-NLS-1$
                            + this + ", requestor=" + requestor); //$NON-NLS-1$
                }
                checkClassVisibility(result, requestor);
                if (resolve) {
                    resolveClass(result);
                }
                return result; // found already loaded class in this plug-in
            }
            try {
                result = findClass(name);
            } catch (ClassNotFoundException cnfe) {
                // ignore
            }
            if (result != null) {
                if (log.isDebugEnabled()) {
                    log.debug("loadClass(...): found class, class=" //$NON-NLS-1$
                            + result + ", this=" //$NON-NLS-1$
                            + this + ", requestor=" + requestor); //$NON-NLS-1$
                }
                checkClassVisibility(result, requestor);
                if (resolve) {
                    resolveClass(result);
                }
                return result; // found class in this plug-in
            }
            if (seen == null) {
                seen = new HashSet();
            }
            if (log.isDebugEnabled()) {
                log.debug("loadClass(...): class not found, name=" //$NON-NLS-1$
                        + name + ", this=" //$NON-NLS-1$
                        + this + ", requestor=" + requestor); //$NON-NLS-1$
            }
            seen.add(getPluginDescriptor().getId());
            for (int i = 0; i < publicImports.length; i++) {
                if (seen.contains(publicImports[i].getId())) {
                    continue;
                }
                result = ((StandardPluginClassLoader) getPluginManager()
                        .getPluginClassLoader(publicImports[i])).loadClass(
                                name, resolve, requestor, seen);
                if (result != null) {
                    if (resolve) {
                        resolveClass(result);
                    }
                    break; // found class in publicly imported plug-in
                }
            }
            if ((this == requestor) && (result == null)) {
                for (int i = 0; i < privateImports.length; i++) {
                    if (seen.contains(privateImports[i].getId())) {
                        continue;
                    }
                    result = ((StandardPluginClassLoader) getPluginManager()
                            .getPluginClassLoader(privateImports[i])).loadClass(
                                    name, resolve, requestor, seen);
                    if (result != null) {
                        if (resolve) {
                            resolveClass(result);
                        }
                        break; // found class in privately imported plug-in
                    }
                }
            }
        }
        return result;
    }
    
    private void checkClassVisibility(final Class cls,
            final StandardPluginClassLoader requestor) throws ClassNotFoundException {
        /*log.debug("checkClassVisibility(Class, PluginClassLoader): class=" //$NON-NLS-1$
                + cls.getName() + ", requestor=" + requestor //$NON-NLS-1$
                + ", this=" + this); //$NON-NLS-1$*/
        if (this == requestor) {
            return;
        }
        URL lib = getClassBaseUrl(cls);
        if (lib == null) {
            return; // cls is a system class
        }
        ClassLoader loader = cls.getClassLoader();
        if (!(loader instanceof StandardPluginClassLoader)) {
            return;
        }
        if (loader != this) {
            ((StandardPluginClassLoader) loader).checkClassVisibility(cls, requestor);
        } else {
            ResourceFilter filter = (ResourceFilter) resourceFilters.get(lib);
            if ((filter == null) || !filter.isClassVisible(cls.getName())) {
                log.warn("class not visible, class=" + cls //$NON-NLS-1$
                        + ", this=" + this //$NON-NLS-1$
                        + ", requestor=" + requestor); //$NON-NLS-1$
                throw new ClassNotFoundException("class " //$NON-NLS-1$
                        + cls.getName() + " is not visible for plug-in " //$NON-NLS-1$
                        + requestor.getPluginDescriptor().getId());
            }
        }
    }

    /**
     * @see java.lang.ClassLoader#findLibrary(java.lang.String)
     */
    protected String findLibrary(String libname) {
        if ((libname == null) || "".equals(libname.trim())) { //$NON-NLS-1$
            return null;
        }
        log.debug("findLibrary(String): name=" + libname //$NON-NLS-1$
                + ", this=" + this); //$NON-NLS-1$
        libname = System.mapLibraryName(libname);
        String result = null;
        PathResolver pathResolver = getPluginManager().getPathResolver();
        for (Iterator it = getPluginDescriptor().getLibraries().iterator();
                it.hasNext();) {
            Library lib = (Library) it.next();
            if (lib.isCodeLibrary()) {
                continue;
            }
            URL libUrl = pathResolver.resolvePath(lib, lib.getPath() + libname);
            log.debug("findLibrary(String): trying URL " + libUrl); //$NON-NLS-1$
            File libFile = IoUtil.url2file(libUrl);
            if (libFile != null) {
                log.debug("findLibrary(String): URL " + libUrl //$NON-NLS-1$
                        + " resolved as local file " + libFile); //$NON-NLS-1$
                if (libFile.isFile()) {
                    result = libFile.getAbsolutePath();
                    break;
                }
                continue;
            }
            // we have some kind of non-local URL
            // try to copy it to local temporary file
            libFile = (File) libraryCache.get(libname);
            if (libFile != null) {
                if (libFile.isFile()) {
                    result = libFile.getAbsolutePath();
                    break;
                }
                libraryCache.remove(libname);
            }
            if (libraryCache.containsKey(libname)) {
                // already tried to cache this library
                break;
            }
            libFile = cacheLibrary(libUrl, libname);
            if (libFile != null) {
                result = libFile.getAbsolutePath();
                break;
            }
        }
        log.debug("findLibrary(String): name=" + libname //$NON-NLS-1$
                + ", result=" + result //$NON-NLS-1$
                + ", this=" + this); //$NON-NLS-1$
        return result;
    }

    private synchronized File cacheLibrary(final URL libUrl,
            final String libname) {
        File cacheFolder = getLibCacheFolder();
        if (libraryCache.containsKey(libname)) {
            return (File) libraryCache.get(libname);
        }
        File result = null;
        try {
            if (cacheFolder == null) {
                throw new IOException(
                        "can't initialize libraries cache folder"); //$NON-NLS-1$
            }
            File libCachePluginFolder = new File(cacheFolder,
                    getPluginDescriptor().getUniqueId());
            if (!libCachePluginFolder.exists()
                    && !libCachePluginFolder.mkdirs()) {
                throw new IOException("can't create cache folder " //$NON-NLS-1$
                        + libCachePluginFolder);
            }
            result = new File(libCachePluginFolder, libname);
            InputStream in = libUrl.openStream();
            try {
                OutputStream out = new BufferedOutputStream(
                        new FileOutputStream(result));
                try {
                    byte[] buf = new byte[512];
                    int read;
                    while ((read = in.read(buf)) != -1) {
                        out.write(buf, 0, read);
                    }
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
            libraryCache.put(libname, result);
            log.debug("library " + libname //$NON-NLS-1$
                    + " successfully cached from URL " + libUrl //$NON-NLS-1$
                    + " and saved to local file " + result); //$NON-NLS-1$
        } catch (IOException ioe) {
            log.error("can't cache library " + libname //$NON-NLS-1$
                    + " from URL " + libUrl, ioe); //$NON-NLS-1$
            libraryCache.put(libname, null);
            result = null;
        }
        return result;
    }

    /**
     * @see java.lang.ClassLoader#findResource(java.lang.String)
     */
    public URL findResource(final String name) {
        //log.debug("findResource(String): name=" + name); //$NON-NLS-1$
        URL result = findResource(name, this, null);
        //log.debug("findResource(String): result=" + result); //$NON-NLS-1$
        return result;
    }

    /**
     * @see java.lang.ClassLoader#findResources(java.lang.String)
     */
    public Enumeration findResources(final String name) throws IOException {
        List result = new LinkedList();
        findResources(result, name, this, null);
        return Collections.enumeration(result);
    }

    private URL findResource(final String name,
            final StandardPluginClassLoader requestor, Set seen) {
        /*log.debug("findResource(String,...): name=" + name //$NON-NLS-1$
                + ", this=" + this); //$NON-NLS-1$*/
        if ((seen != null) && seen.contains(getPluginDescriptor().getId())) {
            return null;
        }
        URL result = super.findResource(name);
        if (result != null) { // found resource in this plug-in class path
            if (log.isDebugEnabled()) {
                log.debug("findResource(...): resource found in classpath, name=" //$NON-NLS-1$
                        + name + " URL=" + result + ", this=" //$NON-NLS-1$ //$NON-NLS-2$
                        + this + ", requestor=" + requestor); //$NON-NLS-1$
            }
            if (isResourceVisible(name, result, requestor)) {
                return result;
            }
            return null;
        }
        if (resourceLoader != null) {
            result = resourceLoader.findResource(name);
            if (result != null) { // found resource in this plug-in resource libraries
                if (log.isDebugEnabled()) {
                    log.debug("findResource(...): resource found in libraries, name=" //$NON-NLS-1$
                            + name + ", URL=" + result + ", this=" //$NON-NLS-1$ //$NON-NLS-2$
                            + this + ", requestor=" + requestor); //$NON-NLS-1$
                }
                if (isResourceVisible(name, result, requestor)) {
                    return result;
                }
                return null;
            }
        }
        if (seen == null) {
            seen = new HashSet();
        }
        if (log.isDebugEnabled()) {
            log.debug("findResource(...): resource not found, name=" //$NON-NLS-1$
                    + name + ", this=" //$NON-NLS-1$
                    + this + ", requestor=" + requestor); //$NON-NLS-1$
        }
        seen.add(getPluginDescriptor().getId());
        for (int i = 0; i < publicImports.length; i++) {
            if (seen.contains(publicImports[i].getId())) {
                continue;
            }
            result = ((StandardPluginClassLoader) getPluginManager()
                    .getPluginClassLoader(publicImports[i])).findResource(
                            name, requestor, seen);
            if (result != null) {
                break; // found resource in publicly imported plug-in
            }
        }
        if ((this == requestor) && (result == null)) {
            for (int i = 0; i < privateImports.length; i++) {
                if (seen.contains(privateImports[i].getId())) {
                    continue;
                }
                result = ((StandardPluginClassLoader) getPluginManager()
                        .getPluginClassLoader(privateImports[i])).findResource(
                                name, requestor, seen);
                if (result != null) {
                    break; // found resource in privately imported plug-in
                }
            }
        }
        return result;
    }

    private void findResources(final List result, final String name,
            final StandardPluginClassLoader requestor, Set seen) throws IOException {
        if ((seen != null) && seen.contains(getPluginDescriptor().getId())) {
            return;
        }
        for (Enumeration enm = super.findResources(name);
                enm.hasMoreElements();) {
            URL url = (URL) enm.nextElement();
            if (isResourceVisible(name, url, requestor)) {
                result.add(url);
            }
        }
        if (resourceLoader != null) {
            for (Enumeration enm = resourceLoader.findResources(name);
                    enm.hasMoreElements();) {
                URL url = (URL) enm.nextElement();
                if (isResourceVisible(name, url, requestor)) {
                    result.add(url);
                }
            }
        }
        if (seen == null) {
            seen = new HashSet();
        }
        seen.add(getPluginDescriptor().getId());
        for (int i = 0; i < publicImports.length; i++) {
            if (seen.contains(publicImports[i].getId())) {
                continue;
            }
            ((StandardPluginClassLoader) getPluginManager().getPluginClassLoader(
                    publicImports[i])).findResources(result, name,
                            requestor, seen);
        }
        if (this == requestor) {
            for (int i = 0; i < privateImports.length; i++) {
                if (seen.contains(privateImports[i].getId())) {
                    continue;
                }
                ((StandardPluginClassLoader) getPluginManager().getPluginClassLoader(
                        privateImports[i])).findResources(result, name,
                                requestor, seen);
            }
        }
    }
    
    private boolean isResourceVisible(final String name, final URL url,
            final StandardPluginClassLoader requestor) {
        /*log.debug("isResourceVisible(URL, PluginClassLoader): URL=" + url //$NON-NLS-1$
                + ", requestor=" + requestor); //$NON-NLS-1$*/
        if (this == requestor) {
            return true;
        }
        URL lib = null;
        String file = url.getFile();
        try {
            String libFile = file.substring(0, file.length() - name.length());
            String prot = url.getProtocol();
            if ("jar".equals(prot)) { //$NON-NLS-1$
                if (libFile.endsWith("!/")) { //$NON-NLS-1$
                    libFile = libFile.substring(0, libFile.length() - 2);
                } else if (libFile.endsWith("!")) { //$NON-NLS-1$
                    libFile = libFile.substring(0, libFile.length() - 1);
                }
            }
            lib = new URL(prot, url.getHost(), libFile);
        } catch (MalformedURLException mue) {
            log.error("can't get resource library URL", mue); //$NON-NLS-1$
            return false;
        }
        ResourceFilter filter = (ResourceFilter) resourceFilters.get(lib);
        if ((filter == null) || !filter.isResourceVisible(name)) {
            log.warn("resource not visible, name=" + name //$NON-NLS-1$
                    + ", URL=" + url + ", this=" + this //$NON-NLS-1$ //$NON-NLS-2$
                    + ", requestor=" + requestor); //$NON-NLS-1$
            return false;
        }
        return true;
    }
    
    private static final class ResourceFilter {
        private boolean isPublic;
        private Set entries;

        protected ResourceFilter(final Library lib) {
            entries = new HashSet();
            for (Iterator it = lib.getExports().iterator(); it.hasNext();) {
                String exportPrefix = (String) it.next();
                if ("*".equals(exportPrefix)) { //$NON-NLS-1$
                    isPublic = true;
                    entries.clear();
                    break;
                }
                if (!lib.isCodeLibrary()) {
                    exportPrefix = exportPrefix.replace('\\', '.')
                        .replace('/', '.');
                    if (exportPrefix.startsWith(".")) { //$NON-NLS-1$
                        exportPrefix = exportPrefix.substring(1);
                    }
                }
                entries.add(exportPrefix);
            }
        }
        
        protected boolean isClassVisible(final String className) {
            if (isPublic) {
                return true;
            }
            if (entries.isEmpty()) {
                return false;
            }
            if (entries.contains(className)) {
                return true;
            }
            int p = className.lastIndexOf('.');
            if (p == -1) {
                return false;
            }
            return entries.contains(className.substring(0, p) + ".*"); //$NON-NLS-1$
        }

        protected boolean isResourceVisible(String resPath) {
            // quick check
            if (isPublic) {
                return true;
            }
            if (entries.isEmpty()) {
                return false;
            }
            // translate "path spec" -> "full class name"
            resPath = resPath.replace('\\', '.').replace('/', '.');
            if (resPath.startsWith(".")) { //$NON-NLS-1$
                resPath = resPath.substring(1);
            }
            if (resPath.endsWith(".")) { //$NON-NLS-1$
                resPath = resPath.substring(0, resPath.length() - 1);
            }
            return isClassVisible(resPath);
        }
    }

    private static class PluginResourceLoader extends URLClassLoader {
        private static Log logger =
            LogFactory.getLog(PluginResourceLoader.class);

        static PluginResourceLoader get(final PluginManager manager,
                final PluginDescriptor descr) {
            List urls = new LinkedList();
            for (Iterator it = descr.getLibraries().iterator(); it.hasNext();) {
                Library lib = (Library) it.next();
                if (lib.isCodeLibrary()) {
                    continue;
                }
                urls.add(manager.getPathResolver().resolvePath(lib,
                        lib.getPath()));
            }
            if (logger.isDebugEnabled()) {
                StringBuffer buf = new StringBuffer();
                buf.append("Resource URL's populated for plug-in " + descr //$NON-NLS-1$
                        + ":\r\n"); //$NON-NLS-1$
                for (Iterator it = urls.iterator(); it.hasNext();) {
                    buf.append("\t"); //$NON-NLS-1$
                    buf.append(it.next());
                    buf.append("\r\n"); //$NON-NLS-1$
                }
                logger.trace(buf.toString());
            }
            if (urls.isEmpty()) {
                return null;
            }
            return new PluginResourceLoader((URL[]) urls.toArray(
                    new URL[urls.size()]));
        }

        /**
         * Creates loader instance configured to load resources only from given
         * URLs.
         * @param urls array of resource URLs
         */
        private PluginResourceLoader(final URL[] urls) {
            super(urls);
        }

        /**
         * @see java.lang.ClassLoader#findClass(java.lang.String)
         */
        protected Class findClass(final String name)
                throws ClassNotFoundException {
            throw new ClassNotFoundException(name);
        }

        /**
         * @see java.lang.ClassLoader#loadClass(java.lang.String, boolean)
         */
        protected Class loadClass(final String name, final boolean resolve)
                throws ClassNotFoundException {
            throw new ClassNotFoundException(name);
        }
    }
}
