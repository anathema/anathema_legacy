/*****************************************************************************
 * Java Plug-in Framework (JPF)
 * Copyright (C) 2004-2006 Dmitry Olshansky
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *****************************************************************************/
package org.java.plugin.registry.xml;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import org.java.plugin.PathResolver;
import org.java.plugin.registry.Extension;
import org.java.plugin.registry.ExtensionPoint;
import org.java.plugin.registry.Identity;
import org.java.plugin.registry.ManifestProcessingException;
import org.java.plugin.registry.PluginDescriptor;
import org.java.plugin.registry.PluginFragment;
import org.java.plugin.registry.PluginRegistry;
import org.java.plugin.registry.ExtensionPoint.ParameterDefinition;
import org.java.plugin.registry.IntegrityCheckReport.ReportItem;

/**
 * @version $Id: ExtensionImpl.java,v 1.7 2006/06/05 18:16:43 ddimon Exp $
 */
final class ExtensionImpl extends PluginElementImpl implements Extension {
    private final ModelExtension model;
    private List parameters;
    private Boolean isValid;
    
    ExtensionImpl(final PluginDescriptorImpl descr,
            final PluginFragmentImpl aFragment, final ModelExtension aModel)
            throws ManifestProcessingException {
        super(descr, aFragment, aModel.getId(), aModel.getDocumentation());
        model = aModel;
        if ((model.getPluginId() == null)
                || (model.getPluginId().trim().length() == 0)) {
            throw new ManifestProcessingException(
                    PluginRegistryImpl.PACKAGE_NAME,
                    "extensionIdIsBlank", descr.getId()); //$NON-NLS-1$
        }
        if ((model.getPointId() == null)
                || (model.getPointId().trim().length() == 0)) {
            throw new ManifestProcessingException(
                    PluginRegistryImpl.PACKAGE_NAME,
                    "extendedPointIdIsBlank", descr.getId()); //$NON-NLS-1$
        }
        parameters = new ArrayList(model.getParams().size());
        for (Iterator it = model.getParams().iterator(); it.hasNext();) {
            parameters.add(new ParameterImpl(null, (ModelParameter) it.next()));
        }
        parameters = Collections.unmodifiableList(parameters);
        if (log.isDebugEnabled()) {
            log.debug("object instantiated: " + this); //$NON-NLS-1$
        }
    }

    /**
     * @see org.java.plugin.registry.UniqueIdentity#getUniqueId()
     */
    public String getUniqueId() {
        return getDeclaringPluginDescriptor().getRegistry().makeUniqueId(
                getDeclaringPluginDescriptor().getId(), getId());
    }

    /**
     * @see org.java.plugin.registry.Extension#getParameters()
     */
    public Collection getParameters() {
        return parameters;
    }

    /**
     * @see org.java.plugin.registry.Extension#getParameter(java.lang.String)
     */
    public Parameter getParameter(final String id) {
        ParameterImpl result = null;
        for (Iterator it = parameters.iterator(); it.hasNext();) {
            ParameterImpl param = (ParameterImpl) it.next();
            if (param.getId().equals(id)) {
                if (result == null) {
                    result = param;
                } else {
                    throw new IllegalArgumentException(
                        "more than one parameter with ID " + id //$NON-NLS-1$
                        + " defined in extension " + getUniqueId()); //$NON-NLS-1$
                }
            }
        }
        return result;
    }

    /**
     * @see org.java.plugin.registry.Extension#getParameters(java.lang.String)
     */
    public Collection getParameters(final String id) {
        List result = new LinkedList();
        for (Iterator it = parameters.iterator(); it.hasNext();) {
            ParameterImpl param = (ParameterImpl) it.next();
            if (param.getId().equals(id)) {
                result.add(param);
            }
        }
        return Collections.unmodifiableList(result);
    }

    /**
     * @see org.java.plugin.registry.Extension#getExtendedPluginId()
     */
    public String getExtendedPluginId() {
        return model.getPluginId();
    }

    /**
     * @see org.java.plugin.registry.Extension#getExtendedPointId()
     */
    public String getExtendedPointId() {
        return model.getPointId();
    }

    /**
     * @see org.java.plugin.registry.Extension#isValid()
     */
    public boolean isValid() {
        if (isValid == null) {
            validate();
        }
        return isValid.booleanValue();
    }
    
    Collection validate() {
        ExtensionPoint point =
            getExtensionPoint(getExtendedPluginId(), getExtendedPointId());
        if (point == null) {
            isValid = Boolean.FALSE;
            return Collections.singletonList(
                    new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "extPointNotAvailable", new Object[] { //$NON-NLS-1$
                        getDeclaringPluginDescriptor().getRegistry()
                            .makeUniqueId(getExtendedPluginId(),
                                    getExtendedPointId()), getUniqueId()}));
        }
        Collection result =
            validateParameters(point.getParameterDefinitions(), parameters);
        isValid = result.isEmpty() ? Boolean.TRUE : Boolean.FALSE;
        return result;
    }
    
    ExtensionPoint getExtensionPoint(final String uniqueId) {
        PluginRegistry registry = getDeclaringPluginDescriptor().getRegistry();
        return getExtensionPoint(registry.extractPluginId(uniqueId),
                registry.extractId(uniqueId));
    }

    ExtensionPoint getExtensionPoint(final String pluginId,
            final String pointId) {
        PluginRegistry registry = getDeclaringPluginDescriptor().getRegistry();
        if (!registry.isPluginDescriptorAvailable(pluginId)) {
            return null;
        }
        for (Iterator it = registry.getPluginDescriptor(pluginId)
                .getExtensionPoints().iterator(); it.hasNext();) {
            ExtensionPoint point = (ExtensionPoint) it.next();
            if (point.getId().equals(pointId)) {
                return point;
            }
        }
        return null;
    }
    
    private Collection validateParameters(final Collection allDefinitions,
            final Collection allParams) {
        List result = new LinkedList();
        Map groups = new HashMap();
        for (Iterator it = allParams.iterator(); it.hasNext();) {
            Parameter param = (Parameter) it.next();
            ParameterDefinition def = param.getDefinition();
            if (def == null) {
                result.add(new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "cantDetectParameterDef", new Object[] { //$NON-NLS-1$
                        param.getId(), getUniqueId()}));
                continue;
            }
            if (groups.containsKey(param.getId())) {
                ((Collection) groups.get(param.getId())).add(param);
            } else {
                Collection paramGroup = new LinkedList();
                paramGroup.add(param);
                groups.put(param.getId(), paramGroup);
            }
        }
        if (!result.isEmpty()) {
            return result;
        }
        for (Iterator it = allDefinitions.iterator(); it.hasNext();) {
            ParameterDefinition def = (ParameterDefinition) it.next();
            Collection paramGroup = (Collection) groups.get(def.getId());
            result.addAll(validateParameters(def,
                    (paramGroup != null) ? paramGroup
                            : Collections.EMPTY_LIST));
        }
        return result;
    }
    
    private Collection validateParameters(final ParameterDefinition def,
            final Collection params) {
        if (log.isDebugEnabled()) {
            log.debug("validating parameters for definition " + def); //$NON-NLS-1$
        }
        if (ParameterDefinition.MULT_ONE.equals(def.getMultiplicity())
                && (params.size() != 1)) {
            return Collections.singletonList(
                    new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "tooManyOrFewParams", new Object[] { //$NON-NLS-1$
                        def.getId(), getUniqueId()}));
        } else if (ParameterDefinition.MULT_NONE_OR_ONE.equals(
                def.getMultiplicity()) && (params.size() > 1)) {
            return Collections.singletonList(
                    new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "tooManyParams", new Object[] { //$NON-NLS-1$
                                def.getId(), getUniqueId()}));
        } else if (ParameterDefinition.MULT_ONE_OR_MORE.equals(
                def.getMultiplicity()) && params.isEmpty()) {
            return Collections.singletonList(
                    new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "tooFewParams", new Object[] { //$NON-NLS-1$
                                def.getId(), getUniqueId()}));
        }
        if (params.isEmpty()) {
            return Collections.EMPTY_LIST;
        }
        List result = new LinkedList();
        int count = 1;
        for (Iterator it = params.iterator(); it.hasNext(); count++) {
            ParameterImpl param = (ParameterImpl) it.next();
            if (!param.isValid()) {
                result.add(new IntegrityChecker.ReportItemImpl(
                        ReportItem.SEVERITY_ERROR, this,
                        ReportItem.ERROR_INVALID_EXTENSION,
                        "invalidParameterValue", new Object[] { //$NON-NLS-1$
                        def.getId(), new Integer(count), getUniqueId()}));
            }
            if (!ParameterDefinition.TYPE_ANY.equals(def.getType())
                    && result.isEmpty()) {
                result.addAll(validateParameters(
                        param.getDefinition().getSubDefinitions(),
                        param.getSubParameters()));
            }
        }
        return result;
    }
    
    /**
     * @see java.lang.Object#toString()
     */
    public String toString() {
        return "{PluginExtension: uid=" + getUniqueId() + "}"; //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    void registryChanged() {
        isValid = null;
    }

    private class ParameterImpl extends PluginElementImpl implements Parameter {
        private final ModelParameter modelParam;
        private Boolean isParamValid;
        private Object valueObj;
        private List subParameters;
        private ParameterDefinition definition = null;
        private boolean definitionDetected = false;
        private final ParameterImpl superParameter;

        ParameterImpl(final ParameterImpl aSuperParameter,
                final ModelParameter aModel)
                throws ManifestProcessingException {
            super(ExtensionImpl.this.getDeclaringPluginDescriptor(),
                    ExtensionImpl.this.getDeclaringPluginFragment(),
                    aModel.getId(), aModel.getDocumentation());
            this.superParameter = aSuperParameter;
            modelParam = aModel;
            subParameters = new ArrayList(modelParam.getParams().size());
            for (Iterator it = modelParam.getParams().iterator();
                    it.hasNext();) {
                subParameters.add(new ParameterImpl(this,
                        (ModelParameter) it.next()));
            }
            subParameters = Collections.unmodifiableList(subParameters);
            if (log.isDebugEnabled()) {
                log.debug("object instantiated: " + this); //$NON-NLS-1$
            }
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#getDeclaringExtension()
         */
        public Extension getDeclaringExtension() {
            return ExtensionImpl.this;
        }

        /**
         * @see org.java.plugin.registry.PluginElement#getDeclaringPluginDescriptor()
         */
        public PluginDescriptor getDeclaringPluginDescriptor() {
            return ExtensionImpl.this.getDeclaringPluginDescriptor();
        }
        
        /**
         * @see org.java.plugin.registry.PluginElement#getDeclaringPluginFragment()
         */
        public PluginFragment getDeclaringPluginFragment() {
            return ExtensionImpl.this.getDeclaringPluginFragment();
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#getDefinition()
         */
        public ParameterDefinition getDefinition() {
            if (definitionDetected) {
                return definition;
            }
            definitionDetected = true;
            if (log.isDebugEnabled()) {
                log.debug("detecting definition for parameter " + this); //$NON-NLS-1$
            }
            Collection definitions;
            if (superParameter != null) {
                if (superParameter.getDefinition() == null) {
                    return null;
                }
                if (ParameterDefinition.TYPE_ANY.equals(
                            superParameter.getDefinition().getType())) {
                    definition = superParameter.getDefinition();
                    if (log.isDebugEnabled()) {
                        log.debug("definition detected - " + definition); //$NON-NLS-1$
                    }
                    return definition;
                }
                definitions =
                    superParameter.getDefinition().getSubDefinitions();
            } else {
                definitions = getExtensionPoint(
                            getDeclaringExtension().getExtendedPluginId(),
                            getDeclaringExtension().getExtendedPointId()).
                                getParameterDefinitions();
            }
            for (Iterator it = definitions.iterator(); it.hasNext();) {
                ParameterDefinition def = (ParameterDefinition) it.next();
                if (def.getId().equals(getId())) {
                    definition = def;
                    break;
                }
            }
            if (log.isDebugEnabled()) {
                log.debug("definition detected - " + definition); //$NON-NLS-1$
            }
            return definition;
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#getSuperParameter()
         */
        public Parameter getSuperParameter() {
            return superParameter;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#getSubParameters()
         */
        public Collection getSubParameters() {
            return subParameters;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#getSubParameter(
         *      java.lang.String)
         */
        public Parameter getSubParameter(final String id) {
            ParameterImpl result = null;
            for (Iterator it = subParameters.iterator(); it.hasNext();) {
                ParameterImpl param = (ParameterImpl) it.next();
                if (param.getId().equals(id)) {
                    if (result == null) {
                        result = param;
                    } else {
                        throw new IllegalArgumentException(
                            "more than one parameter with ID " + id //$NON-NLS-1$
                            + " defined in extension " + getUniqueId()); //$NON-NLS-1$
                    }
                }
            }
            return result;
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#getSubParameters(
         *      java.lang.String)
         */
        public Collection getSubParameters(final String id) {
            List result = new LinkedList();
            for (Iterator it = subParameters.iterator(); it.hasNext();) {
                ParameterImpl param = (ParameterImpl) it.next();
                if (param.getId().equals(id)) {
                    result.add(param);
                }
            }
            return Collections.unmodifiableList(result);
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#rawValue()
         */
        public String rawValue() {
            return (modelParam.getValue() != null) ? modelParam.getValue() : ""; //$NON-NLS-1$
        }
        
        boolean isValid() {
            if (isParamValid != null) {
                return isParamValid.booleanValue();
            }
            if (log.isDebugEnabled()) {
                log.debug("validating parameter " + this); //$NON-NLS-1$
            }
            isParamValid = Boolean.FALSE;
            if (getDefinition() == null) {
                isParamValid = Boolean.FALSE;
                log.warn("can't detect definition for parameter " + this); //$NON-NLS-1$
            } else {
                isParamValid = (modelParam.getValue() != null) ? parseValue()
                        : Boolean.TRUE;
            }
            return isParamValid.booleanValue();
        }
        
        private Boolean parseValue() {
            // note that definition already detected and is not NULL
            if (log.isDebugEnabled()) {
                log.debug("parsing value for parameter " + this); //$NON-NLS-1$
            }
            if (ParameterDefinition.TYPE_ANY.equals(definition.getType())
                    || ParameterDefinition.TYPE_NULL.equals(
                            definition.getType())) {
                return Boolean.TRUE;
            } else if (ParameterDefinition.TYPE_STRING.equals(
                    definition.getType())) {
                valueObj = modelParam.getValue();
                return Boolean.TRUE;
            }
            String val = modelParam.getValue().trim();
            if (val.length() == 0) {
                return Boolean.TRUE;
            }
            if (ParameterDefinition.TYPE_BOOLEAN.equals(definition.getType())) {
                if ("true".equals(val)) { //$NON-NLS-1$
                    valueObj = Boolean.TRUE;
                } else if ("false".equals(val)) { //$NON-NLS-1$
                    valueObj = Boolean.FALSE;
                } else {
                    log.error("can't parse value " + val //$NON-NLS-1$
                            + " of parameter " + this); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_NUMBER.equals(
                    definition.getType())) {
                try {
                    valueObj =
                        NumberFormat.getInstance(Locale.ENGLISH).parse(val);
                } catch (ParseException nfe) {
                    log.error("can't parse value " + val //$NON-NLS-1$
                            + " of parameter " + this, nfe); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_DATE.equals(
                    definition.getType())) {
                DateFormat fmt =
                    new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH); //$NON-NLS-1$
                try {
                    valueObj = fmt.parse(val);
                } catch (ParseException pe) {
                    log.error("can't parse value " + val //$NON-NLS-1$
                            + " of parameter " + this, pe); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_TIME.equals(
                    definition.getType())) {
                DateFormat fmt =
                    new SimpleDateFormat("HH:mm:ss", Locale.ENGLISH); //$NON-NLS-1$
                try {
                    valueObj = fmt.parse(val);
                } catch (ParseException pe) {
                    log.error("can't parse value " + val //$NON-NLS-1$
                            + " of parameter " + this, pe); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_DATETIME.equals(
                    definition.getType())) {
                DateFormat fmt =
                    new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH); //$NON-NLS-1$
                try {
                    valueObj = fmt.parse(val);
                } catch (ParseException pe) {
                    log.error("can't parse value " + val //$NON-NLS-1$
                            + " of parameter " + this, pe); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_PLUGIN_ID.equals(
                    definition.getType())) {
                try {
                    valueObj = getDeclaringPluginDescriptor().getRegistry()
                        .getPluginDescriptor(val);
                } catch (IllegalArgumentException iae) {
                    log.error("unknown plug-in ID " + val //$NON-NLS-1$
                            + " provided in parameter " + this, iae); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
            } else if (ParameterDefinition.TYPE_EXTENSION_POINT_ID.equals(
                    definition.getType())) {
                valueObj = getExtensionPoint(val);
                if (valueObj == null) {
                    log.error("unknown extension point UID " + val //$NON-NLS-1$
                            + " provided in parameter " + this); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
                if (definition.getCustomData() != null) {
                    ExtensionPoint customExtPoint = getExtensionPoint(
                            definition.getCustomData());
                    if (customExtPoint == null) {
                        log.error("unknown extension point UID " //$NON-NLS-1$
                                + definition.getCustomData() //$NON-NLS-1$
                                + " provided as custom data in parameter " //$NON-NLS-1$
                                + this);
                        return Boolean.FALSE;
                    }
                    if (!((ExtensionPoint) valueObj).isSuccessorOf(
                            customExtPoint)) {
                        log.error("extension point with UID " + val //$NON-NLS-1$
                                + " provided in parameter " + this //$NON-NLS-1$
                                + " doesn't \"inherit\" point that is defined" //$NON-NLS-1$
                                + " according to custom data in parameter" //$NON-NLS-1$
                                + " definition - " //$NON-NLS-1$
                                + definition.getCustomData());
                        return Boolean.FALSE;
                    }
                }
            } else if (ParameterDefinition.TYPE_EXTENSION_ID.equals(
                    definition.getType())) {
                String extId =
                    getDeclaringPluginDescriptor().getRegistry().extractId(val);
                for (Iterator it = getDeclaringPluginDescriptor()
                        .getRegistry().getPluginDescriptor(
                                getDeclaringPluginDescriptor().getRegistry()
                                .extractPluginId(val)).getExtensions()
                                .iterator(); it.hasNext();) {
                    Extension ext = (Extension) it.next();
                    if (ext.getId().equals(extId)) {
                        valueObj = ext;
                        break;
                    }
                }
                if (valueObj == null) {
                    log.error("unknown extension UID " + val //$NON-NLS-1$
                            + " provided in parameter " + this); //$NON-NLS-1$
                    return Boolean.FALSE;
                }
                if (definition.getCustomData() != null) {
                    ExtensionPoint customExtPoint =
                        getExtensionPoint(definition.getCustomData());
                    if (customExtPoint == null) {
                        log.error("unknown extension point UID " //$NON-NLS-1$
                                + definition.getCustomData() //$NON-NLS-1$
                                + " provided as custom data in parameter " //$NON-NLS-1$
                                + this);
                        return Boolean.FALSE;
                    }
                    String extPointUid =
                        getDeclaringPluginDescriptor().getRegistry()
                        .makeUniqueId(((Extension) valueObj)
                                .getExtendedPluginId(),
                                ((Extension) valueObj).getExtendedPointId());
                    ExtensionPoint extPoint = getExtensionPoint(extPointUid);
                    if (extPoint == null) {
                        log.error("extension point " + extPointUid //$NON-NLS-1$
                                + " is unknown for extension " //$NON-NLS-1$
                                + ((Extension) valueObj).getUniqueId()
                                + ", provided in parameter " + this); //$NON-NLS-1$
                        return Boolean.FALSE;
                    }
                    if (!extPoint.equals(customExtPoint)
                            && !extPoint.isSuccessorOf(customExtPoint)) {
                        log.error("extension with UID " + val //$NON-NLS-1$
                                + " provided in parameter " + this //$NON-NLS-1$
                                + " extends point that not allowed according" //$NON-NLS-1$
                                + " to custom data defined in parameter" //$NON-NLS-1$
                                + " definition - " //$NON-NLS-1$
                                + definition.getCustomData());
                        return Boolean.FALSE;
                    }
                }
            } else if (ParameterDefinition.TYPE_FIXED.equals(
                    definition.getType())) {
                for (StringTokenizer st = new StringTokenizer(
                        definition.getCustomData(), "|", false); //$NON-NLS-1$
                        st.hasMoreTokens();) {
                    if (val.equals(st.nextToken().trim())) {
                        valueObj = val;
                        return Boolean.TRUE;
                    }
                }
                log.error("not allowed value " + val //$NON-NLS-1$
                        + " provided in parameter " + this); //$NON-NLS-1$
                return Boolean.FALSE;
            } else if (ParameterDefinition.TYPE_RESOURCE.equals(
                    definition.getType())) {
                try {
                    valueObj = new URL(val);
                } catch (MalformedURLException mue) {
                    if (log.isDebugEnabled()) {
                        log.debug("can't parse value " + val //$NON-NLS-1$
                                + " of parameter " + this //$NON-NLS-1$
                                + " as an absolute URL, we'll treat it as relative" //$NON-NLS-1$
                                + " URL", mue); //$NON-NLS-1$
                    }
                    //return Boolean.FALSE;
                    valueObj = null;
                }
                return Boolean.TRUE;
            }
            return Boolean.TRUE;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsBoolean()
         */
        public Boolean valueAsBoolean() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_BOOLEAN.equals(
                    definition.getType())) {
                throw new UnsupportedOperationException("parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_BOOLEAN);
            }
            return (Boolean) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsDate()
         */
        public Date valueAsDate() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_DATE.equals(definition.getType())
                    && !ParameterDefinition.TYPE_DATETIME.equals(
                            definition.getType())
                    && !ParameterDefinition.TYPE_TIME.equals(
                            definition.getType())) {
                throw new UnsupportedOperationException("parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_DATE + " nor " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_DATETIME + " nor" //$NON-NLS-1$
                        + ParameterDefinition.TYPE_TIME);
            }
            return (Date) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsNumber()
         */
        public Number valueAsNumber() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_NUMBER.equals(definition.getType())) {
                throw new UnsupportedOperationException("parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_NUMBER);
            }
            return (Number) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsString()
         */
        public String valueAsString() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_STRING.equals(definition.getType())
                    && !ParameterDefinition.TYPE_FIXED.equals(
                            definition.getType())) {
                throw new UnsupportedOperationException("parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_STRING);
            }
            return (String) valueObj;
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsExtension()
         */
        public Extension valueAsExtension() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_EXTENSION_ID.equals(
                    definition.getType())) {
                throw new UnsupportedOperationException(
                        "parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_EXTENSION_ID);
            }
            return (Extension) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsExtensionPoint()
         */
        public ExtensionPoint valueAsExtensionPoint() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_EXTENSION_POINT_ID.equals(
                    definition.getType())) {
                throw new UnsupportedOperationException(
                        "parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_EXTENSION_POINT_ID);
            }
            return (ExtensionPoint) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsPluginDescriptor()
         */
        public PluginDescriptor valueAsPluginDescriptor() {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_PLUGIN_ID.equals(
                    definition.getType())) {
                throw new UnsupportedOperationException("parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_PLUGIN_ID);
            }
            return (PluginDescriptor) valueObj;
        }
        
        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsUrl()
         */
        public URL valueAsUrl() {
            return valueAsUrl(null);
        }

        /**
         * @see org.java.plugin.registry.Extension.Parameter#valueAsUrl(
         *      org.java.plugin.PathResolver)
         */
        public URL valueAsUrl(final PathResolver pathResolver) {
            if (!isValid()) {
                throw new UnsupportedOperationException(
                        "parameter value is invalid"); //$NON-NLS-1$
            }
            if (!ParameterDefinition.TYPE_RESOURCE.equals(
                    definition.getType())) {
                throw new UnsupportedOperationException(
                        "parameter type is not " //$NON-NLS-1$
                        + ParameterDefinition.TYPE_RESOURCE);
            }
            if ((pathResolver == null) || (valueObj != null)) {
                return (URL) valueObj;
            }
            return pathResolver.resolvePath(getDeclaringPluginDescriptor(),
                    rawValue());
        }
        
        /**
         * @see java.lang.Object#toString()
         */
        public String toString() {
            return "{PluginExtension.Parameter: extUid=" //$NON-NLS-1$
                + getDeclaringExtension().getUniqueId() + "; id=" + getId() //$NON-NLS-1$
                + "}"; //$NON-NLS-1$
        }
        
        /**
         * @see org.java.plugin.registry.xml.IdentityImpl#isEqualTo(
         *      org.java.plugin.registry.Identity)
         */
        protected boolean isEqualTo(final Identity idt) {
            if (!super.isEqualTo(idt)) {
                return false;
            }
            ParameterImpl other = (ParameterImpl) idt;
            if ((getSuperParameter() == null)
                    && (other.getSuperParameter() == null)) {
                return true;
            }
            if ((getSuperParameter() == null)
                    || (other.getSuperParameter() == null)) {
                return false;
            }
            return getSuperParameter().equals(other.getSuperParameter());
        }
    }
}
