/*****************************************************************************
 * Java Plug-in Framework (JPF)
 * Copyright (C) 2004 Dmitry Olshansky
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *****************************************************************************/
package org.java.plugin.tools.configuration;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.Properties;

/**
 * Utility class to manage plug-ins set configuration.
 * @version $Id: ConfigurationManager.java,v 1.2 2005/06/09 18:38:21 ddimon Exp $
 */
public final class ConfigurationManager {
    private static final String KEY_PREFIX =
        ConfigurationManager.class.getName() + "."; //$NON-NLS-1$
    
    private Properties props = new Properties();

    /**
     * Loads this class specific properties from given collection.
     * @param config some configuration properties
     */
    public void load(final Properties config) {
        this.props = new Properties();
        for (Enumeration en = config.propertyNames(); en.hasMoreElements();) {
            String name = (String) en.nextElement();
            if (name.startsWith(KEY_PREFIX)) {
                this.props.put(name, config.getProperty(name));
            }
        }
    }

    /**
     * Loads configuration from given file.
     * @param configFile configuration file
     * @throws IOException if an I/O error has occurred
     */
    public void load(final File configFile) throws IOException {
        props = new Properties();
        InputStream strm = new BufferedInputStream(new FileInputStream(
                configFile));
        try {
            props.load(strm);
        } finally {
            strm.close();
        }
    }
    
    /**
     * Loads configuration from given input stream.
     * @param strm stream to configuration data
     * @throws IOException if an I/O error has occurred
     */
    public void load(final InputStream strm) throws IOException {
        props = new Properties();
        props.load(strm);
    }
    
    /**
     * Merges this class specific properties with given collection.
     * @param config some configuration properties
     */
    public void save(final Properties config) {
        for (Enumeration en = this.props.propertyNames();
                en.hasMoreElements();) {
            String name = (String) en.nextElement();
            config.put(name, this.props.getProperty(name));
        }
    }
    
    /**
     * Stores configuration data to given file.
     * @param configFile configuration file
     * @throws IOException if an I/O error has occurred
     */
    public void save(final File configFile) throws IOException {
        OutputStream strm = new BufferedOutputStream(
                new FileOutputStream(configFile, false));
        try {
            props.store(strm, "This is JPF plug-ins configuration file."); //$NON-NLS-1$
        } finally {
            strm.close();
        }
    }
    
    /**
     * Stores configuration data to given output stream.
     * @param strm stream to configuration data
     * @throws IOException if an I/O error has occurred
     */
    public void save(final OutputStream strm) throws IOException {
        props.store(strm, "This is JPF plug-ins configuration file."); //$NON-NLS-1$
    }
}
