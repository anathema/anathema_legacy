/*****************************************************************************
 * Java Plug-in Framework (JPF)
 * Copyright (C) 2004-2005 Dmitry Olshansky
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *****************************************************************************/
package org.java.plugin.tools.ant;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.DirectoryScanner;
import org.apache.tools.ant.Project;
import org.apache.tools.ant.taskdefs.MatchingTask;
import org.java.plugin.ObjectFactory;
import org.java.plugin.PathResolver;
import org.java.plugin.registry.Identity;
import org.java.plugin.registry.PluginRegistry;
import org.java.plugin.util.IoUtil;

/**
 * Base class for some JPF related ant tasks.
 * @version $Id: BaseJpfTask.java,v 1.8 2005/10/24 18:00:27 ddimon Exp $
 */
public abstract class BaseJpfTask extends MatchingTask {
    private File baseDir;
    private boolean verbose;
    private PluginRegistry registry;
    private PathResolver pathResolver;

    /**
     * @param aBaseDir base directory for manifest files
     */
    public final void setBaseDir(final File aBaseDir) {
        this.baseDir = aBaseDir;
    }

    /**
     * @param aVerbose <code>true</code> if detailed integrity check report
     *                required
     */
    public final void setVerbose(final boolean aVerbose) {
        this.verbose = aVerbose;
    }
    
    protected final boolean getVerbose() {
        return verbose;
    }

    protected final PathResolver getPathResolver() {
        return pathResolver;
    }
    
    protected final PluginRegistry getRegistry() {
        return registry;
    }

    protected final void initRegistry(final boolean usePathResolver) {
        if (baseDir == null) {
            throw new BuildException("basedir attribute must be set!", //$NON-NLS-1$
                    getLocation());
        }
        if (!baseDir.isDirectory()) {
            throw new BuildException("basedir " + baseDir //$NON-NLS-1$
                    + " does not exist!", getLocation()); //$NON-NLS-1$
        }
        ObjectFactory objectFactory = ObjectFactory.newInstance();
        log("Collecting manifest files..."); //$NON-NLS-1$
        DirectoryScanner ds = super.getDirectoryScanner(baseDir);
        registry = objectFactory.createRegistry();
        String[] manifestFiles = ds.getIncludedFiles();
        URL[] manifestUrls = new URL[manifestFiles.length];
        Map foldersMap = new HashMap();
        for (int i = 0; i < manifestFiles.length; i++) {
            File manifestFile = new File(baseDir, manifestFiles[i]);
            try {
                manifestUrls[i] = IoUtil.file2url(manifestFile);
                if (verbose) {
                    log("Added URL: " + manifestUrls[i]); //$NON-NLS-1$
                }
                if (usePathResolver) {
                    foldersMap.put(manifestUrls[i],
                            IoUtil.file2url(manifestFile.getParentFile()));
                }
            } catch (MalformedURLException mue) {
                throw new BuildException("can't create URL for file " //$NON-NLS-1$
                        + manifestFile, mue, getLocation());
            }
        }
        Map processedPlugins;
        try {
            processedPlugins = registry.register(manifestUrls);
        } catch (Exception e) {
            throw new BuildException("can't register URLs", e, getLocation()); //$NON-NLS-1$
        }
        log("... successfully registered " + processedPlugins.size() //$NON-NLS-1$
                + " (of " + manifestUrls.length + ") manifest files ", //$NON-NLS-1$ //$NON-NLS-2$
                (processedPlugins.size() != manifestUrls.length)
                    ? Project.MSG_WARN : Project.MSG_INFO);
        if (usePathResolver) {
            pathResolver = objectFactory.createPathResolver();
            for (Iterator it = processedPlugins.entrySet().iterator();
                    it.hasNext();) {
                Map.Entry entry = (Entry) it.next();
                pathResolver.registerContext((Identity) entry.getValue(),
                        (URL) foldersMap.get(entry.getKey()));
            }
            log("PathResolver initialized"); //$NON-NLS-1$
        }
    }
}
