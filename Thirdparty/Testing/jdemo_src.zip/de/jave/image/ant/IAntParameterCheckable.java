package de.jave.image.ant;

/**
 * @author Markus Gebhard
 */
public interface IAntParameterCheckable {
  public void checkParameters();

}