package de.jave.image.test;

import de.jave.image.ImageIoUtilities;
import junit.framework.TestCase;

/**
 * @author Markus Gebhard
 */
public class ImageIoUtilitiesTest extends TestCase {
  public void testGuessImageFormat() {
    assertEquals("png", ImageIoUtilities.guessImageFormat("test.png"));
    assertEquals("gif", ImageIoUtilities.guessImageFormat("test.name.gif"));
    assertNull(ImageIoUtilities.guessImageFormat("testnamegif"));
  }
}