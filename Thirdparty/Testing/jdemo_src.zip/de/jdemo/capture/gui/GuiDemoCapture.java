package de.jdemo.capture.gui;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Window;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.swing.SwingUtilities;

import de.jave.image.ImageIoUtilities;
import de.jdemo.capture.DemoCaptureException;
import de.jdemo.extensions.GuiDemoCase;
import de.jdemo.framework.DemoIdentifier;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.exceptions.DemoClassNotFoundException;
import de.jdemo.framework.state.DemoState;
import de.jdemo.framework.util.DemoUtilities;
import de.jdemo.framework.util.ErrorDemoCase;

/**
 * @author Markus Gebhard
 */
public class GuiDemoCapture {

  private static final long TIMEOUT = 5000;

  public BufferedImage capture(DemoIdentifier demoId, boolean includeFrameTitle)
      throws DemoCaptureException,
      DemoClassNotFoundException {
    GuiDemoCase demo = castToGuiDemoCase(DemoUtilities.createDemo(demoId));
    return capture(demo, includeFrameTitle);
  }

  private static GuiDemoCase castToGuiDemoCase(IDemoCase demo) throws DemoCaptureException {
    if (demo instanceof ErrorDemoCase) {
      ErrorDemoCase errorDemoCase = (ErrorDemoCase) demo;
      throw new DemoCaptureException(
          "Error initializing demo (" + errorDemoCase.getException() + ").",
          errorDemoCase.getException());
    }
    if (!(demo instanceof GuiDemoCase)) {
      throw new DemoCaptureException("Demo '" + demo + "' is not a GuiDemoCase."); //$NON-NLS-1$ //$NON-NLS-2$
    }
    return (GuiDemoCase) demo;
  }

  private BufferedImage capture(GuiDemoCase demo, boolean includeFrameTitle) throws DemoCaptureException {
    IDemoCaseRunnable runner = demo.createRunnable();
    if (SwingUtilities.isEventDispatchThread()) {
      runner.run();
    }
    else {
      try {
        SwingUtilities.invokeAndWait(runner);
      }
      catch (InterruptedException exception) {
        throw new RuntimeException("Demo '" + demo + "' has been interrupted.", exception);
      }
      catch (InvocationTargetException exception) {
        throw new RuntimeException("Error executing Demo '" + demo + "'.", exception);
      }
    }

    if (runner.getState().equals(DemoState.CRASHED)) {
      throw new DemoCaptureException("Demo crashed before being able to take a screen capture.", //$NON-NLS-1$
          runner.getThrowable());
    }

    GuiDemoCase guiDemo = (GuiDemoCase) runner.getDemo();
    Window window = guiDemo.getRegisteredDemoWindow();
    if (window == null) {
      throw new RuntimeException("Demo '" + demo + "' does not have a managed window object to capture."); //$NON-NLS-1$ //$NON-NLS-2$
    }

    long timeStart = System.currentTimeMillis();
    while (true) {
      if (System.currentTimeMillis() - timeStart > TIMEOUT) {
        throw new DemoCaptureException("Timeout when capturing demo window.");
      }
      if (runner.getState().equals(DemoState.RUNNING) && guiDemo.isRegisteredDemoWindowOpened()) {
        try {
          new Robot().waitForIdle();
        }
        catch (AWTException e1) {
          throw new DemoCaptureException("Unable to create Robot for GuiDemoCapture.", //$NON-NLS-1$
              e1);
        }

        BufferedImage image = capture(window, includeFrameTitle);
        runner.cancel();
        return image;
      }
      if (runner.getState().equals(DemoState.CRASHED)) {
        throw new DemoCaptureException("Demo crashed before being able to create screen capture.",
        //$NON-NLS-1$
            runner.getThrowable());
      }
      if (runner.getState().equals(DemoState.FINISHED)) {
        throw new DemoCaptureException("Demo finished before being able to create screen capture.",
        //$NON-NLS-1$
            runner.getThrowable());
      }
      Thread.yield();
    }
  }

  private BufferedImage capture(Window window, boolean includeFrameTitle) {
    try {
      return ScreenCapture.captureFromScreen(window, includeFrameTitle);
    }
    catch (AWTException e1) {
      e1.printStackTrace();
    }
    return null;
  }

  public void capture(DemoIdentifier demoId, boolean includeFrameTitle, String imageFormat, File file)
      throws DemoCaptureException,
      DemoClassNotFoundException,
      IOException {
    BufferedImage image = capture(demoId, includeFrameTitle);
    ImageIoUtilities.write(image, imageFormat, file);
  }

  public void capture(IDemoCase demo, boolean includeFrameTitle, String imageFormat, File outputFile)
      throws IOException,
      DemoCaptureException {
    GuiDemoCase guiDemoCase = castToGuiDemoCase(demo);
    BufferedImage image = capture(guiDemoCase, includeFrameTitle);
    ImageIoUtilities.write(image, imageFormat, outputFile);
  }
}