package de.jdemo.capture.gui.test;

import javax.swing.JLabel;

import de.jdemo.extensions.SwingDemoCase;

/**
 * @author Markus Gebhard
 */
public class SwingTestDemo extends SwingDemoCase {

  public void demo() {
    show(new JLabel("label"));
  }

}