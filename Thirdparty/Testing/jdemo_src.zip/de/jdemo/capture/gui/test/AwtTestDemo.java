package de.jdemo.capture.gui.test;

import java.awt.Label;

import de.jdemo.extensions.AwtDemoCase;

/**
 * @author Markus Gebhard
 */
public class AwtTestDemo extends AwtDemoCase {

  public void demo() {
    show(new Label("label"));
  }
}