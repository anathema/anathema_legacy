package de.jdemo.swingui.test;

import java.io.PrintStream;
import java.io.StringWriter;

import de.jdemo.capture.stream.SystemStreamType;
import de.jdemo.capture.stream.WriterOutputStream;
import de.jdemo.swingui.DemoRunner;
import de.jdemo.swingui.launch.CommandLineOptions;
import junit.framework.TestCase;

/**
 * @author Markus Gebhard
 */
public class DemoRunnerTest extends TestCase {
  private StringWriter outWriter;
  private StringWriter errWriter;
  private CommandLineOptions commandLineOptions;

  protected void setUp() throws Exception {
    outWriter = new StringWriter();
    SystemStreamType.OUT.setPrintStream(new PrintStream(new WriterOutputStream(outWriter)));
    errWriter = new StringWriter();
    SystemStreamType.ERR.setPrintStream(new PrintStream(new WriterOutputStream(errWriter)));
    commandLineOptions = new CommandLineOptions();
  }

  private String getSystemOutString() {
    SystemStreamType.OUT.resetPrintStream();
    return outWriter.toString();
  }
  
  private String getSystemErrString() {
    SystemStreamType.ERR.resetPrintStream();
    return errWriter.toString();
  }
  
  public void testPrintsVersion() {
    commandLineOptions.setShowVersion(true);
    DemoRunner.run(commandLineOptions);
    assertEquals("", getSystemErrString());
    assertTrue(getSystemOutString().startsWith("JDemo version"));
  }

  public void testPrintsUsage() {
    commandLineOptions.setShowHelp(true);
    DemoRunner.run(commandLineOptions);
    assertEquals("", getSystemErrString());
    assertTrue(getSystemOutString().startsWith("Usage:"));
  }
}