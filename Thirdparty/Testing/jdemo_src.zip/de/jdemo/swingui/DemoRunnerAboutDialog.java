package de.jdemo.swingui;

import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import de.jave.lib.gui.layout.grid.GridAlignment;
import de.jave.lib.gui.layout.grid.GridDialogLayout;
import de.jave.lib.gui.layout.grid.GridDialogLayoutData;
import de.jave.lib.gui.layout.grid.util.ButtonPanelBuilder;
import de.jave.lib.gui.layout.grid.util.LayoutDirection;
import de.jdemo.Version;
import de.jdemo.swingui.util.HorizontalLine;
import de.jdemo.swingui.util.SmartAction;
import de.jdemo.swingui.util.WebLinkLabel;
import de.jdemo.util.GuiUtilities;

/**
 * @author Markus Gebhard
 */
public class DemoRunnerAboutDialog {

  private JDialog dialog;

  public DemoRunnerAboutDialog(Component parentComponent) {
    dialog = GuiUtilities.createDialog(parentComponent);
    dialog.setTitle("JDemo");
    dialog.setModal(true);

    //    /*TODO Aug 15, 2004 (Markus Gebhard): Can the hyperlink be made working? Maybe by attaching
    //     a listener and using the FileLauncher?*/
    GridDialogLayoutData totalSpanData = new GridDialogLayoutData();
    totalSpanData.setHorizontalSpan(2);
    GridDialogLayoutData rightAlign = new GridDialogLayoutData();
    rightAlign.setHorizontalAlignment(GridAlignment.END);
    GridDialogLayoutData horizontalLineData = new GridDialogLayoutData(GridDialogLayoutData.FILL_HORIZONTAL);
    horizontalLineData.setHorizontalSpan(2);

    JPanel mainPanel = new JPanel(new GridDialogLayout(2, false));
    mainPanel.add(
        new JLabel("<html><center>" + "<b>JDemo - Java Demonstration Framework</b></html>"),
        totalSpanData);
    mainPanel.add(new HorizontalLine(), horizontalLineData);
    mainPanel.add(new JLabel("Version: "), rightAlign);
    mainPanel.add(new JLabel(Version.getFullVersionNumber()));
    mainPanel.add(new JLabel("Build date: "), rightAlign);
    mainPanel.add(new JLabel(Version.getBuildDate()));
    mainPanel.add(new JLabel("Web site:"), rightAlign);
    mainPanel.add(new WebLinkLabel("http://www.jdemo.de").getContent());
    mainPanel.add(new HorizontalLine(), horizontalLineData);

    mainPanel.setBorder(new EmptyBorder(6, 6, 2, 6));

    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.HORIZONTAL);
    builder.add(new JButton(new SmartAction("OK") {
      protected void execute(Component parentComponent) {
        dialog.dispose();
      }
    }));

    dialog.getContentPane().add(mainPanel, BorderLayout.CENTER);
    dialog.getContentPane().add(builder.createPanel(), BorderLayout.SOUTH);

    dialog.pack();
    GuiUtilities.centerOnScreen(dialog);
  }

  public static void show(Component parentComponent) {
    new DemoRunnerAboutDialog(parentComponent).getDialog().show();
  }

  public JDialog getDialog() {
    return dialog;
  }
}