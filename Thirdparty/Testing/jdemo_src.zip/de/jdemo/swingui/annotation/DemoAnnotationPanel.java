package de.jdemo.swingui.annotation;

import java.awt.BorderLayout;
import java.io.IOException;
import java.io.StringReader;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import de.jave.lib.gui.layout.grid.GridDialogLayout;
import de.jave.lib.gui.layout.grid.GridDialogLayoutData;
import de.jdemo.annotation.DemoAnnotation;
import de.jdemo.annotation.DemoAnnotationReaderFactory;
import de.jdemo.annotation.IDemoAnnotationReader;
import de.jdemo.framework.IDemo;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.IDemoSuite;
import de.jdemo.framework.IDemoVisitor;
import de.jdemo.framework.exceptions.DemoClassNotFoundException;
import de.jdemo.framework.util.DemoUtilities;
import de.jdemo.swingui.DemoSelectionModel;
import de.jdemo.swingui.FramePanel;

/**
 * @author Markus Gebhard
 */
public class DemoAnnotationPanel {

  private final JPanel panel;
  private final JTextPane descriptionTextPane;
  private final JTextField idTextField;
  private final JTextField nameTextField;
  private final JComponent content;

  public DemoAnnotationPanel(final DemoSelectionModel selectionModel) {
    descriptionTextPane = new JTextPane();
    descriptionTextPane.setContentType("text/html"); //$NON-NLS-1$
    descriptionTextPane.setEditable(false);
    idTextField = new JTextField();
    idTextField.setEditable(false);
    nameTextField = new JTextField();
    nameTextField.setEditable(false);

    JPanel topPanel = new JPanel(new GridDialogLayout(2, false));
    GridDialogLayoutData gridDialogLayoutData = new GridDialogLayoutData();
    gridDialogLayoutData.setHorizontalSpan(2);
    //topPanel.add(new JLabel("Selected demo:"), gridDialogLayoutData);
    topPanel.add(new JLabel("Name:"), GridDialogLayoutData.RIGHT);
    topPanel.add(nameTextField, GridDialogLayoutData.FILL_HORIZONTAL);
    topPanel.add(new JLabel("ID:"), GridDialogLayoutData.RIGHT);
    topPanel.add(idTextField, GridDialogLayoutData.FILL_HORIZONTAL);
    topPanel.add(new JLabel("Description:"));

    panel = new JPanel(new BorderLayout());
    panel.add(topPanel, BorderLayout.NORTH);
    panel.add(new JScrollPane(descriptionTextPane), BorderLayout.CENTER);

    selectionModel.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateView(selectionModel.getSelectedDemo());
      }
    });
    
    content = new FramePanel("Selected demo:", panel).getContent();
  }

  public JComponent getContent() {
    return content;
  }

  private void updateView(IDemo demo) {
    if (demo == null) {
      panel.setEnabled(false);
      nameTextField.setText(""); //$NON-NLS-1$
      idTextField.setText(""); //$NON-NLS-1$
      descriptionTextPane.setText(""); //$NON-NLS-1$
      return;
    }
    nameTextField.setText(DemoUtilities.getDisplayName(demo));
    demo.accept(new IDemoVisitor() {
      public void visitDemoCase(IDemoCase demoCase) {
        panel.setEnabled(true);
        idTextField.setText(demoCase.getIdentifier().toString());
        IDemoAnnotationReader reader = DemoAnnotationReaderFactory.getDemoAnnotationReader();
        if (reader == null) {
          descriptionTextPane.setEnabled(false);
          descriptionTextPane
              .setText("Descriptions from annotations are only available in a JRE 1.5 or greater."); //$NON-NLS-1$
        }
        else {
          try {
            DemoAnnotation annotation = reader.getAnnotation(demoCase.getIdentifier());
            setDescription(annotation == null ? null : annotation.getDescription());
          }
          catch (DemoClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
          }
        }
      }

      public void visitDemoSuite(IDemoSuite demoSuite) {
        panel.setEnabled(false);
        descriptionTextPane.setText(""); //$NON-NLS-1$
      }
    });
  }

  public void setDescription(String description) {
    descriptionTextPane.setEnabled(true);
    
    String text=description == null ? "No description available." : description;
    try {
      descriptionTextPane.read(new StringReader(text), null);
    }
    catch (IOException e) {
      e.printStackTrace();
      descriptionTextPane.setText(text);
    }
  }
}