package de.jdemo.swingui.showsource;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.SystemColor;
import java.io.IOException;
import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JDialog;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.Segment;
import javax.swing.text.html.HTMLDocument;

import de.java2html.converter.JavaSource2HTMLConverter;
import de.java2html.javasource.JavaSource;
import de.java2html.javasource.JavaSourceType;
import de.java2html.options.Java2HtmlConversionOptions;
import de.java2html.options.JavaSourceStyleEntry;
import de.java2html.options.JavaSourceStyleTable;
import de.java2html.util.RGB;
import de.jdemo.framework.DemoIdentifier;
import de.jdemo.runner.DemoSourceCodeNotFoundException;
import de.jdemo.runner.IDemoShowSourceCodeHandler;
import de.jdemo.runner.path.EmptySourcePath;
import de.jdemo.runner.path.ISourcePath;
import de.jdemo.util.GuiUtilities;

/**
 * @author Markus Gebhard
 */
public class Java2HtmlShowSourceCodeHandler implements IDemoShowSourceCodeHandler {
  /**
   * Site header for the html page. Improved to look good in Swing JTextPane.
   */
  private final static String HTML_SITE_HEADER =
  //"<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">\n"
  "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n" //$NON-NLS-1$
      + "<html><head>\n" //$NON-NLS-1$
      + "<title></title>\n" //$NON-NLS-1$
      + "  <style type=\"text/css\">\n" //$NON-NLS-1$
      + "    <!--code { font-family: Courier New, Courier; font-size: 11pt; margin: 0px; }-->\n" //$NON-NLS-1$
      + "  </style>\n" //$NON-NLS-1$
      + "</head><body>\n"; //$NON-NLS-1$

  private final static String HTML_SITE_FOOTER = "\n</body></html>"; //$NON-NLS-1$

  private final static Pattern BR_SLASH_PATTERN = Pattern.compile("<br />"); //$NON-NLS-1$

  private Component parentComponent;
  private ISourcePath sourcePath = new EmptySourcePath();

  public Java2HtmlShowSourceCodeHandler(Component parentComponent) {
    this.parentComponent = parentComponent;
  }

  public void showDemoSourceCode(DemoIdentifier id) throws DemoSourceCodeNotFoundException {
    JDialog dialog = createSourceCodeDialog(id);
    dialog.show();
  }

  /** For internal use only */
  public JDialog createSourceCodeDialog(DemoIdentifier id) throws DemoSourceCodeNotFoundException {
    JavaSource sourceCode = loadSourceCode(id);
    if (sourceCode == null) {
      throw new DemoSourceCodeNotFoundException();
    }
    return createSourceCodeDialog(sourceCode, id);
  }

  public JDialog createSourceCodeDialog(JavaSource sourceCode, DemoIdentifier id) {
    if (sourceCode == null) {
      throw new IllegalArgumentException("Source code must not be null."); //$NON-NLS-1$
    }
    JDialog dialog = GuiUtilities.createDialog(parentComponent);
    dialog.setTitle("Source code from " + id.getClassName());

    String html = convertToHtml(sourceCode);
    html = convertToTextPaneCompatibleHtml(html);
    dialog.getContentPane().setLayout(new BorderLayout());
    JTextPane editorPane = new JTextPane();
    editorPane.setBackground(SystemColor.text);
    editorPane.setEditable(false);
    editorPane.setContentType("text/html"); //$NON-NLS-1$
    editorPane.setText(html);

    JScrollPane scrollPane = new JScrollPane(editorPane);
    scrollPane.setPreferredSize(new Dimension(580, 400));
    dialog.getContentPane().add(scrollPane, BorderLayout.CENTER);
    dialog.pack();

    HTMLDocument document = (HTMLDocument) editorPane.getDocument();
    try {
      Segment segment = new Segment();
      document.getText(0, document.getLength(), segment);
      SelectionRange range = getSelectionRange(segment.toString(), id.getMethodName());
      if (range != null) {
        editorPane.setCaretPosition(range.start);
        editorPane.select(range.start, range.end);
      }
    }
    catch (BadLocationException e) {
      //should never happen
      throw new RuntimeException(e);
    }
    return dialog;
  }

  //JTextPane in JRE1.4_03 cannot handle <br /> - so we have to change it to <br> 
  public static String convertToTextPaneCompatibleHtml(String html) {
    Matcher matcher = BR_SLASH_PATTERN.matcher(html);
    return matcher.replaceAll("<br>"); //$NON-NLS-1$
  }

  public JavaSource loadSourceCode(DemoIdentifier id) {
    JavaSource sourceCode = null;
    try {
      sourceCode = sourcePath.load(id.getClassName());
    }
    catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    return sourceCode;
  }

  public static SelectionRange getSelectionRange(String source, String methodName) {
    String whiteSpace = "(\\s|\\xA0)"; //$NON-NLS-1$
    Pattern pattern = Pattern.compile("public" //$NON-NLS-1$
        + whiteSpace + "+" //$NON-NLS-1$
        + "void" //$NON-NLS-1$
        + whiteSpace + "+" //$NON-NLS-1$
        + methodName + whiteSpace + "*" //$NON-NLS-1$
        + "\\x28" //$NON-NLS-1$
        + whiteSpace + "*" //$NON-NLS-1$
        + "\\x29" //$NON-NLS-1$
        + whiteSpace + "*" //$NON-NLS-1$
        + "\\x7B"); //$NON-NLS-1$
    Matcher matcher = pattern.matcher(source);
    if (matcher.find()) {
      return new SelectionRange(matcher.start(), matcher.end());
    }
    return null;
  }

  private String convertToHtml(JavaSource sourceCode) {
    Java2HtmlConversionOptions options = Java2HtmlConversionOptions.getDefault();
    JavaSourceStyleTable styleTable = JavaSourceStyleTable.getDefaultEclipseStyleTable();
    Color backgroundColor = SystemColor.text;
    RGB backgroundRgb = new RGB(backgroundColor.getRed(), backgroundColor.getGreen(), backgroundColor.getBlue());
    styleTable.put(JavaSourceType.BACKGROUND, new JavaSourceStyleEntry(backgroundRgb));
    options.setStyleTable(styleTable);
    options.setShowLineNumbers(false);
    options.setShowTableBorder(false);

    JavaSource2HTMLConverter converter = new JavaSource2HTMLConverter(sourceCode);
    converter.setConversionOptions(options);
    StringWriter writer = new StringWriter();
    try {
      converter.convert(writer);
    }
    catch (IOException e) {
      return null;
    }

    return HTML_SITE_HEADER + writer.toString() + HTML_SITE_FOOTER;
  }

  public void setSourcePath(ISourcePath sourcePath) {
    this.sourcePath = sourcePath;
  }
}