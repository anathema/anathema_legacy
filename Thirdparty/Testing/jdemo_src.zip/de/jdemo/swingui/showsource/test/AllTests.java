package de.jdemo.swingui.showsource.test;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * @author Markus Gebhard
 */
public class AllTests {

  public static Test suite() {
    TestSuite suite = new TestSuite("Test for de.jdemo.swingui.showsource.test");
    //$JUnit-BEGIN$
    suite.addTestSuite(Java2HtmlShowSourceCodeHandlerTest.class);
    //$JUnit-END$
    return suite;
  }
}
