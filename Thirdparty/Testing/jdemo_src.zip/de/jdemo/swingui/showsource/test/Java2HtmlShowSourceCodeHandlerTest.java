package de.jdemo.swingui.showsource.test;

import junit.framework.TestCase;
import de.jdemo.swingui.showsource.Java2HtmlShowSourceCodeHandler;
import de.jdemo.swingui.showsource.SelectionRange;

/**
 * @author Markus Gebhard
 */
public class Java2HtmlShowSourceCodeHandlerTest extends TestCase {

  public void testPatternMatcher() {
    assertRange(0, 22, "public void demoOne(){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(0, 23, "public  void demoOne(){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(0, 24, "public  void  demoOne(){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(1, 23, " public void demoOne(){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(7, 29, "public public void demoOne(){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(0, 29, "public" + (char) 160 + "void demoHelloWorld(){", "demoHelloWorld"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    assertRange(0, 30, "public void" + (char) 160 + (char) 160 + "demoHelloWorld(){", "demoHelloWorld"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
    assertRange(0, 23, "public void demoOne (){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertNoRange("public void demoOne ){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertNoRange("public void demoOne()", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(0, 23, "public void demoOne( ){", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
    assertRange(0, 24, "public void demoOne( ) {", "demoOne"); //$NON-NLS-1$ //$NON-NLS-2$
  }

  private void assertNoRange(String source, String methodName) {
    assertNull(Java2HtmlShowSourceCodeHandler.getSelectionRange(source, methodName));
  }

  private void assertRange(int expectedStart, int expectedEnd, String source, String methodName) {
    SelectionRange range = Java2HtmlShowSourceCodeHandler.getSelectionRange(source, methodName);
    assertEquals(expectedStart, range.start);
    assertEquals(expectedEnd, range.end);
  }

  public void testConvertToTextPaneCompatibleHtml() {
    assertEquals("<br>", Java2HtmlShowSourceCodeHandler //$NON-NLS-1$
        .convertToTextPaneCompatibleHtml("<br />")); //$NON-NLS-1$
    assertEquals("<br>", Java2HtmlShowSourceCodeHandler //$NON-NLS-1$
        .convertToTextPaneCompatibleHtml("<br>")); //$NON-NLS-1$
    assertEquals("/", Java2HtmlShowSourceCodeHandler //$NON-NLS-1$
        .convertToTextPaneCompatibleHtml("/")); //$NON-NLS-1$
    assertEquals("<html><br></html>", Java2HtmlShowSourceCodeHandler //$NON-NLS-1$
        .convertToTextPaneCompatibleHtml("<html><br /></html>")); //$NON-NLS-1$
  }
}