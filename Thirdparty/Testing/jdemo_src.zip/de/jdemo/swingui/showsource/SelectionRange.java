package de.jdemo.swingui.showsource;

public class SelectionRange {
  public int start;
  public int end;

  public SelectionRange(int start, int end) {
    this.start = start;
    this.end = end;
  }
}