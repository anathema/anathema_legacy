package de.jdemo.swingui.list;

import java.awt.Component;

import javax.swing.DefaultListCellRenderer;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.state.DemoState;
import de.jdemo.framework.util.DemoUtilities;
import de.jdemo.swingui.icons.AggregatedIcon;
import de.jdemo.swingui.icons.JDemoIcons;
import de.jdemo.swingui.icons.SwingDemoStateDecoration;
import de.jdemo.swingui.icons.SwingDemoTypeDecoration;

/**
 * @author Markus Gebhard
 */
public class DemoExecutionListCellRenderer extends DefaultListCellRenderer implements ListCellRenderer {

  public Component getListCellRendererComponent(
    JList list,
    Object value,
    int index,
    boolean isSelected,
    boolean cellHasFocus) {

    super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

    IDemoCaseRunnable runner = (IDemoCaseRunnable) value;
    setText(DemoUtilities.getDisplayName(runner.getDemo()));

    DemoState state = runner.getState();

    AggregatedIcon icon = new AggregatedIcon();
    icon.setBaseIcon(JDemoIcons.DEMO_CASE);
    icon.addDecorationIcon(SwingDemoTypeDecoration.getFor(runner.getDemo()).getIcon());
    SwingDemoStateDecoration stateDecoration = SwingDemoStateDecoration.getFor(state);
    icon.addDecorationIcon(stateDecoration.getIcon());
    setIcon(icon);

    if (state.equals(DemoState.CRASHED)) {
      Throwable error = runner.getThrowable();
      setText(getText() + " - " + error); //$NON-NLS-1$
    }
    setToolTipText(createToolTipText(runner));

    if (isSelected) {
      setBackground(list.getSelectionBackground());
      setForeground(list.getSelectionForeground());
    }
    else {
      setForeground(stateDecoration.getColor());
    }
    return this;
  }

  private String createToolTipText(IDemoCaseRunnable runner) {
    StringBuffer sb = new StringBuffer();
    sb.append("<html>"); //$NON-NLS-1$

    sb.append(runner.getDemo().getIdentifier().toString());
    if (runner.getState().equals(DemoState.CRASHED)) {
      sb.append("<br>"); //$NON-NLS-1$
      sb.append(createErrorToolTipTextPart(runner.getThrowable(), "&nbsp;&nbsp;")); //$NON-NLS-1$
    }
    sb.append("</html>"); //$NON-NLS-1$
    return sb.toString();
  }

  private String createErrorToolTipTextPart(Throwable error, String linePrefix) {
    StringBuffer sb = new StringBuffer();
    sb.append(linePrefix);
    sb.append(error);
    sb.append("<br>"); //$NON-NLS-1$
    StackTraceElement[] elements = error.getStackTrace();
    for (int i = 0; i < elements.length; ++i) {
      sb.append(linePrefix);
      sb.append("&nbsp;&nbsp;&nbsp;"); //$NON-NLS-1$
      sb.append(elements[i].toString());
      sb.append("<br>"); //$NON-NLS-1$
    }
    return sb.toString();
  }
}