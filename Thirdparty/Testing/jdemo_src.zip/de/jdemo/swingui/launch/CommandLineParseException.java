package de.jdemo.swingui.launch;

/**
 * @author Markus Gebhard
 */
public class CommandLineParseException extends Exception {

  public CommandLineParseException(String message) {
    super(message);
  }
}
