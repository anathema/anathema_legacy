package de.jdemo.swingui.tree.iterate.test;

import java.util.NoSuchElementException;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import junit.framework.TestCase;

import de.jdemo.framework.DemoIdentifier;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.IDemoVisitor;
import de.jdemo.swingui.tree.iterate.NamedDemoCaseIterator;

/**
 * @author Markus Gebhard
 */
public class NamedDemoCaseIteratorTest extends TestCase {

  public void testNextWithEmptyTree() {
    DefaultTreeModel treeModel = new DefaultTreeModel(null);
    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertHasNoNextElement(iterator);
  }

  public void testPreviousWithEmptyTree() {
    DefaultTreeModel treeModel = new DefaultTreeModel(null);
    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertHasNoPreviousElement(iterator);
  }

  public void testNextWithSingleNodeTreeWithDemoCase() {
    IDemoCase rootDemoCase = createDemoCase("root"); //$NON-NLS-1$
    DefaultTreeModel treeModel = new DefaultTreeModel(new DefaultMutableTreeNode(rootDemoCase));
    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertIsNext(rootDemoCase, iterator);
    assertHasNoNextElement(iterator);
  }

  public void testPreviousWithSingleNodeTree() {
    IDemoCase rootDemoCase = createDemoCase("root"); //$NON-NLS-1$
    DefaultTreeModel treeModel = new DefaultTreeModel(new DefaultMutableTreeNode(rootDemoCase));
    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertIsNext(rootDemoCase, iterator);
    assertHasNoPreviousElement(iterator);
  }

  public void testNextWithSingleNodeTreeWithoutDemoCase() {
    DefaultTreeModel treeModel = new DefaultTreeModel(new DefaultMutableTreeNode("root")); //$NON-NLS-1$
    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertHasNoNextElement(iterator);
  }

  public void testNextWithTreeWithDemoCases() {
    IDemoCase child1DemoCase = createDemoCase("child1"); //$NON-NLS-1$
    IDemoCase child2DemoCase = createDemoCase("child2"); //$NON-NLS-1$
    DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode();
    rootNode.add(new DefaultMutableTreeNode(child1DemoCase));
    rootNode.add(new DefaultMutableTreeNode(child2DemoCase));
    DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);

    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertIsNext(child1DemoCase, iterator);
    assertIsNext(child2DemoCase, iterator);
    assertHasNoNextElement(iterator);
  }

  public void testPreviousWithTreeWithDemoCases() {
    IDemoCase child1DemoCase = createDemoCase("child1"); //$NON-NLS-1$
    IDemoCase child2DemoCase = createDemoCase("child2"); //$NON-NLS-1$
    DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode();
    rootNode.add(new DefaultMutableTreeNode(child1DemoCase));
    rootNode.add(new DefaultMutableTreeNode(child2DemoCase));
    DefaultTreeModel treeModel = new DefaultTreeModel(rootNode);

    NamedDemoCaseIterator iterator = new NamedDemoCaseIterator(treeModel);
    assertIsNext(child1DemoCase, iterator);
    assertHasNoPreviousElement(iterator);
    assertIsNext(child2DemoCase, iterator);
    assertIsPrevious(child1DemoCase, iterator);
    assertHasNoPreviousElement(iterator);
    assertIsNext(child2DemoCase, iterator);
    assertHasNoNextElement(iterator);
  }

  private static void assertIsNext(IDemoCase demoCase, NamedDemoCaseIterator iterator) {
    assertTrue(iterator.hasNext());
    assertSame(demoCase, iterator.getNext());
  }

  private static void assertIsPrevious(IDemoCase demoCase, NamedDemoCaseIterator iterator) {
    assertTrue(iterator.hasPrevious());
    assertSame(demoCase, iterator.getPrevious());
  }

  private static IDemoCase createDemoCase(final String name) {
    return new IDemoCase() {

      public String toString() {
        return name;
      }

      public IDemoCaseRunnable createRunnable() {
        throw new UnsupportedOperationException();
      }

      public DemoIdentifier getIdentifier() {
        throw new UnsupportedOperationException();
      }

      public String getName() {
        throw new UnsupportedOperationException();
      }

      public void setName(String name) {
        throw new UnsupportedOperationException();
      }

      public void accept(IDemoVisitor visitor) {
        throw new UnsupportedOperationException();
      }
    };
  }

  private static void assertHasNoNextElement(NamedDemoCaseIterator iterator) {
    assertFalse(iterator.hasNext());
    try {
      iterator.getNext();
      fail();
    }
    catch (NoSuchElementException expected) {
      //expected
    }
  }

  private static void assertHasNoPreviousElement(NamedDemoCaseIterator iterator) {
    assertFalse(iterator.hasPrevious());
    try {
      iterator.getPrevious();
      fail();
    }
    catch (NoSuchElementException expected) {
      //expected
    }
  }
}