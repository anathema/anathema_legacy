package de.jdemo.swingui.tree.actions;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LookAndFeel;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import de.jave.lib.gui.layout.grid.GridDialogLayout;
import de.jave.lib.gui.layout.grid.GridDialogLayoutData;
import de.jdemo.swingui.lookandfeel.LookAndFeelUtilities;
import de.jdemo.swingui.util.AbstractUserDialogPage;
import de.jdemo.swingui.util.Message;

/**
 * @author Markus Gebhard
 */
public class CustomLookAndFeelChooserDialog extends AbstractUserDialogPage {

  private static final Message DEFAULT_MESSAGE = new Message("Specify the new Look&Feel.");
  private JTextField tfClassName;
  private JTextField tfName;
  private JCheckBox cbRemember;
  private final boolean mustRemember;

  public CustomLookAndFeelChooserDialog(boolean mustRemember) {
    this.mustRemember = mustRemember;
  }

  public JComponent createContent() {
    tfClassName = new JTextField(30);
    tfClassName.setFont(new Font("Courier", Font.PLAIN, 11)); //$NON-NLS-1$
    tfName = new JTextField(20);
    JLabel classNameLabel = new JLabel("Class name:");
    final JLabel nameLabel = new JLabel("Name:");
    cbRemember = new JCheckBox("Remember", true);

    if (mustRemember) {
      cbRemember.setEnabled(false);
    }

    DocumentListener documentListener = new DocumentListener() {
      public void changedUpdate(DocumentEvent e) {
        fireChangeEvent();
      }

      public void insertUpdate(DocumentEvent e) {
        fireChangeEvent();
      }

      public void removeUpdate(DocumentEvent e) {
        fireChangeEvent();
      }
    };
    tfClassName.getDocument().addDocumentListener(documentListener);
    tfName.getDocument().addDocumentListener(documentListener);

    cbRemember.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        tfName.setEnabled(cbRemember.isSelected());
        nameLabel.setEnabled(cbRemember.isSelected());
        fireChangeEvent();
      }
    });

    JPanel mainPanel = new JPanel(new GridDialogLayout(2, false));
    mainPanel.add(classNameLabel);
    mainPanel.add(tfClassName, GridDialogLayoutData.FILL_HORIZONTAL);
    mainPanel.add(nameLabel);
    mainPanel.add(tfName, GridDialogLayoutData.FILL_HORIZONTAL);
    mainPanel.add(cbRemember);
    return mainPanel;
  }

  public CustomLookAndFeelOptions getSelectedOptions() {
    CustomLookAndFeelOptions selectedOptions = new CustomLookAndFeelOptions(getSelectedClassName(), cbRemember
        .isSelected(), getSelectedName());
    return selectedOptions;
  }

  public void performOk() {
    //nothing to do
  }

  public void performCancel() {
    //nothing to do
  }

  public Message createCurrentMessage() {
    String className = getSelectedClassName();
    if (className.length() == 0) {
      return new Message("The specified class name is empty.", true);
      //" Please specify the name of Look&Feel class.", true);
    }
    if (!LookAndFeelUtilities.isClassAvailable(className)) {
      return new Message("The specified class can not be found on the classpath.", true);
    }
    if (!LookAndFeelUtilities.isLookAndFeelClass(className)) {
      return new Message("The specified class does not extend the Look&Feel base class.", true);
    }
    if (cbRemember.isSelected() && getSelectedName().length() == 0) {
      //name may not be empty
      return new Message("You must specify a name in order to remember the Look&Feel.", true);
    }
    return getDefaultMessage();
  }

  private String getSelectedName() {
    return tfName.getText().trim();
  }

  private String getSelectedClassName() {
    return tfClassName.getText().trim();
  }

  public Message getDefaultMessage() {
    return DEFAULT_MESSAGE;
  }

  public String getDescription() {
    return getTitle();
  }

  public String getTitle() {
    return "Custom Look&Feel";
  }

  public void requestFocus() {
    tfClassName.requestFocus();
  }
}