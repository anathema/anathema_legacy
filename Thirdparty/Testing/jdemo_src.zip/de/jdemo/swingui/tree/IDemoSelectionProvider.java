package de.jdemo.swingui.tree;

import de.jdemo.framework.IDemoCase;

/**
 * @author Markus Gebhard
 */
public interface IDemoSelectionProvider {

  public IDemoCase getSelectedDemoCase();

}
