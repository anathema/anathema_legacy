package de.jdemo.swingui.actions;

import java.awt.Component;

import de.jdemo.framework.DemoIdentifier;
import de.jdemo.runner.DemoSourceCodeNotFoundException;
import de.jdemo.runner.IDemoIdentifierSelectionProvider;
import de.jdemo.runner.IDemoShowSourceCodeHandler;
import de.jdemo.swingui.icons.JDemoIcons;
import de.jdemo.swingui.util.MessageUtilities;
import de.jdemo.swingui.util.SmartAction;

/**
 * @author Markus Gebhard
 */
public class ShowSourceCodeAction extends SmartAction {
  private IDemoIdentifierSelectionProvider selectionProvider;
  private IDemoShowSourceCodeHandler handler;

  public ShowSourceCodeAction(
      IDemoShowSourceCodeHandler handler,
      IDemoIdentifierSelectionProvider selectionProvider) {
    super("Show source code", JDemoIcons.getIconResource("goto.gif")); //$NON-NLS-2$
    this.handler = handler;
    this.selectionProvider = selectionProvider;
    setEnabled(handler != null);
  }

  public void setEnabled(boolean enabled) {
    if (handler == null) {
      super.setEnabled(false);
    }
    else {
      super.setEnabled(enabled);
    }
  }

  protected void execute(Component parentComponent) {
    DemoIdentifier identifier = selectionProvider.getSelectedDemoIdentifier();
    if (identifier == null) {
      return;
    }
    try {
      handler.showDemoSourceCode(identifier);
    }
    catch (DemoSourceCodeNotFoundException e) {
      MessageUtilities.showErrorMessageDialog(
          parentComponent,
          "JDemo - Demo source code",
          "The source code of the demo was not found on the source path.");
    }
  }
}