package de.jdemo.swingui.icons;

import java.awt.Component;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.Icon;

/**
 * @author Markus Gebhard
 */
public class AggregatedIcon implements Icon {
  private List decorations;
  private Icon baseIcon;

  public AggregatedIcon(){
    decorations=new ArrayList();
  }

  public void paintIcon(Component c, Graphics g, int x, int y) {
    baseIcon.paintIcon(c, g, x, y);
    for (int i=0;i<decorations.size();++i){
      ((Icon)decorations.get(i)).paintIcon(c, g, x, y);
    }
  }

  public int getIconWidth() {
    int width = baseIcon.getIconWidth();
    for (int i=0;i<decorations.size();++i){
      if (((Icon)decorations.get(i)).getIconWidth()>width){
        width = ((Icon)decorations.get(i)).getIconWidth();
      }
    } 
    return width;
  }

  public int getIconHeight() {
    int height = baseIcon.getIconHeight();
    for (int i=0;i<decorations.size();++i){
      if (((Icon)decorations.get(i)).getIconHeight()>height){
        height = ((Icon)decorations.get(i)).getIconHeight();
      }
    } 
    return height;
  }

  public void setBaseIcon(Icon baseIcon) {
    this.baseIcon = baseIcon;
  }

  public void addDecorationIcon(Icon icon) {
    if (icon==null){
      return;
    }
    decorations.add(icon);
  }
}