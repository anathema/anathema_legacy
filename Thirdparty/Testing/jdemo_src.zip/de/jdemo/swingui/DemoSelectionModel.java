package de.jdemo.swingui;

import de.jdemo.framework.IDemo;
import de.jdemo.swingui.util.AbstractChangeableModel;

/**
 * @author Markus Gebhard
 */
public class DemoSelectionModel extends AbstractChangeableModel {

  private IDemo selectedDemo;

  public IDemo getSelectedDemo() {
    return selectedDemo;
  }

  public void setSelectedDemo(IDemo selectedDemo) {
    this.selectedDemo = selectedDemo;
    fireChangeEvent();
  }

}