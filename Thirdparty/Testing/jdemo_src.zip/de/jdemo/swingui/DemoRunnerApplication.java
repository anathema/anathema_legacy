package de.jdemo.swingui;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.WindowConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import de.jdemo.Version;
import de.jdemo.framework.IDemo;
import de.jdemo.framework.state.IDemoStateChangeEvent;
import de.jdemo.framework.state.IDemoStateChangeListener;
import de.jdemo.runner.IDemoRunnerExitListener;
import de.jdemo.runner.IDemoShowSourceCodeHandler;
import de.jdemo.runner.path.ISourcePath;
import de.jdemo.swingui.actions.DemoRunnerMenuBar;
import de.jdemo.swingui.icons.JDemoIcons;
import de.jdemo.swingui.preferences.JDemoPreferences;
import de.jdemo.swingui.preferences.WindowConfigurationPreferences;
import de.jdemo.swingui.showsource.Java2HtmlShowSourceCodeHandler;

/**
 * @author Markus Gebhard
 */
public class DemoRunnerApplication {
  private final List/*<IDemoRunnerExitListener>*/exitListeners = new ArrayList();

  private final JFrame frame;
  private File currentDirectory;
  private final DemoRunnerPanel panel;
  private boolean systemExitsOnClose = true;

  public DemoRunnerApplication() {
    this((IDemo) null, null);
  }

  public DemoRunnerApplication(IDemo demo) {
    this(demo, null);
  }

  public DemoRunnerApplication(IDemo demo, IDemoShowSourceCodeHandler showSourceCodeHandler) {
    frame = new JFrame("JDemo " + Version.getFullVersionNumber());
    if (showSourceCodeHandler == null) {
      showSourceCodeHandler = new Java2HtmlShowSourceCodeHandler(frame);
    }

    panel = new DemoRunnerPanel(demo, showSourceCodeHandler);

    panel.addDemoStateChangeListener(new IDemoStateChangeListener() {
      public void demoStateChanged(IDemoStateChangeEvent event) {
        if (event.getNewState().isTerminated()) {
          frame.toFront();
        }
      }
    });

    frame.setIconImage(JDemoIcons.getImage(JDemoIcons.JDEMO));
    frame.getContentPane().setLayout(new GridLayout(1,0));
    frame.getContentPane().add(panel.getContent());//, BorderLayout.CENTER);
    frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    frame.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        performExit();
      }
    });
    final WindowConfigurationPreferences preferences = JDemoPreferences
        .getInstance().getWindowConfigurationPreferences();
    frame.setSize(preferences.getWindowSize());
    frame.setLocation(preferences.getWindowLocation());
    panel.setVerticalDividerLocation(preferences.getVerticalDividerLocation());
    panel.setHorizontalDividerLocation(preferences.getHorizontalDividerLocation());
    initMenuBar();

    preferences.addAnnotationPanelVisibilityChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        SwingUtilities.invokeLater(new Runnable() {
          public void run() {
            frame.setSize(preferences.getWindowSize().width, frame.getHeight());
            panel.updateAnnotationPanelVisibility();
            frame.validate();
          }
        });
      }
    });
  }

  private void initMenuBar() {
    frame.setJMenuBar(new DemoRunnerMenuBar(this));
  }

  public void performExit() {
    try {
      WindowConfigurationPreferences preferences = JDemoPreferences
          .getInstance().getWindowConfigurationPreferences();
      preferences.setWindowSize(frame.getSize());
      preferences.setWindowLocation(frame.getLocation());
      preferences.setVerticalDividerLocation(panel.getVerticalDividerLocation());
      preferences.setHorizontalDividerLocation(panel.getHorizontalDividerLocation());
      preferences.flush();
    }
    catch (Exception e) {
      System.err.println("Error writing preferences."); //$NON-NLS-1$
      e.printStackTrace();
    }
    frame.dispose();
    panel.cancelAllDemos();
    fireDemoRunnerExited();
    if (systemExitsOnClose) {
      System.exit(0);
    }
  }

  private void fireDemoRunnerExited() {
    for (int i = 0; i < exitListeners.size(); ++i) {
      ((IDemoRunnerExitListener) exitListeners.get(i)).demoRunnerExited();
    }
  }

  public void show() {
    frame.setVisible(true);
  }

  public void addDemoRunnerExitListener(IDemoRunnerExitListener listener) {
    exitListeners.add(listener);
  }

  public JFrame getFrame() {
    return frame;
  }

  public void setCurrentDirectory(File directory) {
    this.currentDirectory = directory;
  }

  public File getCurrentDirectory() {
    return currentDirectory;
  }

  public void setSourcePath(ISourcePath sourcePath) {
    if (panel.getShowSourceCodeHandler() != null) {
      panel.getShowSourceCodeHandler().setSourcePath(sourcePath);
    }
  }

  public DemoRunnerPanel getDemoRunnerPanel() {
    return panel;
  }

  public void setSystemExitsOnClose(boolean systemExitsOnClose) {
    this.systemExitsOnClose = systemExitsOnClose;
  }

  public void setDividerLocation(int location) {
    panel.setVerticalDividerLocation(location);
  }
}