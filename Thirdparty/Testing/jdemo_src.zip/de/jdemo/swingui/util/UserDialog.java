package de.jdemo.swingui.util;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import de.jave.lib.gui.layout.grid.GridDialogLayout;
import de.jave.lib.gui.layout.grid.GridDialogLayoutData;
import de.jdemo.util.GuiUtilities;

/**
 * @author Markus Gebhard
 */
public class UserDialog {

  private final JDialog dialog;
  private JButton okButton;
  private boolean isCancelled = false;
  private final IUserDialogPage dialogOage;
  private final JTextArea messageLabel;

  public UserDialog(Component parentComponent, IUserDialogPage dialogPage) {
    this.dialogOage = dialogPage;
    dialog = GuiUtilities.createDialog(parentComponent);
    dialog.setModal(true);
    dialog.setTitle(dialogPage.getTitle());
    dialog.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);

    dialog.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        performCancel();
      }
    });

    JLabel descriptionLabel = new JLabel(dialogPage.getDescription());
    descriptionLabel.setFont(new Font("Dialog", Font.BOLD, 11)); //$NON-NLS-1$

    //TODO Oct 30, 2004 (Markus Gebhard): Use AutoWrappingLabel when available
    messageLabel = new JTextArea(" ");
    messageLabel.setEditable(false);
    messageLabel.setFont(new Font("Dialog", Font.PLAIN, 11)); //$NON-NLS-1$
    messageLabel.setOpaque(false);

    JPanel headerPanel = new JPanel(new GridDialogLayout(2, false));
    headerPanel.setBackground(Color.WHITE);
    GridDialogLayoutData descriptionLayoutData = new GridDialogLayoutData();
    descriptionLayoutData.setHorizontalSpan(2);
    headerPanel.add(descriptionLabel, descriptionLayoutData);
    JLabel smallMessageIconLabel = new JLabel();
    smallMessageIconLabel.setPreferredSize(new Dimension(16, 25));
    headerPanel.add(smallMessageIconLabel);
    headerPanel.add(messageLabel);

    JPanel mainPanel = new JPanel(new GridLayout(1, 0));
    mainPanel.add(dialogPage.createContent());
    mainPanel.setBorder(new EmptyBorder(5, 5, 5, 5));

    JPanel buttonPanel = createButtonPanel();

    Container contentPane = dialog.getContentPane();
    GridDialogLayout mainLayout = new GridDialogLayout(1, false);
    mainLayout.setVerticalSpacing(0);
    contentPane.setLayout(mainLayout);
    contentPane.add(headerPanel, GridDialogLayoutData.FILL_HORIZONTAL);
    contentPane.add(new HorizontalLine(), GridDialogLayoutData.FILL_HORIZONTAL);
    contentPane.add(mainPanel, GridDialogLayoutData.FILL_BOTH);
    contentPane.add(new HorizontalLine(), GridDialogLayoutData.FILL_HORIZONTAL);
    contentPane.add(buttonPanel, GridDialogLayoutData.FILL_HORIZONTAL);
    dialog.getRootPane().setDefaultButton(okButton);
    dialog.pack();

    dialogPage.addChangeListener(new ChangeListener() {
      public void stateChanged(ChangeEvent e) {
        updateMessageLabel();
        updateOkButtonEnabled();
      }
    });

    updateOkButtonEnabled();
    setMessage(dialogPage.getDefaultMessage());
    dialogPage.requestFocus();
  }

  private void updateOkButtonEnabled() {
    okButton.setEnabled(!dialogOage.createCurrentMessage().isError());
  }

  private JPanel createButtonPanel() {
    okButton = new JButton(new SmartAction("OK") {
      protected void execute(Component parentComponent) {
        dialogOage.performOk();
        dialog.dispose();
      }
    });
    JButton cancelButton = new JButton(new SmartAction("Cancel") {
      protected void execute(Component parentComponent) {
        performCancel();
      }
    });

    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
    buttonPanel.add(okButton);
    buttonPanel.add(cancelButton);
    buttonPanel.setBorder(new EmptyBorder(8, 4, 4, 4));
    return buttonPanel;
  }

  private void updateMessageLabel() {
    setMessage(dialogOage.createCurrentMessage());
  }

  private void setMessage(Message message) {
    if (message.isError()) {
      messageLabel.setForeground(Color.RED);
    }
    else {
      messageLabel.setForeground(Color.BLACK);
    }
    messageLabel.setText(message.getText());
  }

  public JDialog getDialog() {
    return dialog;
  }

  public void show() {
    GuiUtilities.centerOnScreen(dialog);
    dialog.show();
  }

  public boolean isCancelled() {
    return isCancelled;
  }

  private void performCancel() {
    dialogOage.performCancel();
    isCancelled = true;
    dialog.dispose();
  }
}