package de.jdemo.swingui.util;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.JComponent;
import javax.swing.JLabel;

import de.jdemo.util.FileLauncher;

/**
 * @author Markus Gebhard
 */
public class WebLinkLabel {

  private final JLabel label;
  private final String urlString;

  public WebLinkLabel(String urlString) {
    this.urlString = urlString;
    label = new JLabel(urlString);

    updateColor(false);
    label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

    label.addMouseListener(new MouseAdapter() {
      public void mouseReleased(MouseEvent e) {
        if (!e.isMetaDown()) {
          gotoWebSite();
        }
        updateColor(false);
      }

      public void mousePressed(MouseEvent e) {
        updateColor(true);
      }
    });
  }

  private void updateColor(boolean mousePressed) {
    if (mousePressed) {
      label.setForeground(new Color(64, 64, 224));
    }
    else {
      label.setForeground(new Color(0, 0, 128));
    }
  }

  private void gotoWebSite() {
    try {
      new FileLauncher().launch(urlString);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
  }

  public JComponent getContent() {
    return label;
  }
}