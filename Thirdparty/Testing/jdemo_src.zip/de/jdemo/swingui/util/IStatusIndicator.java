package de.jdemo.swingui.util;

/**
 * @author Markus Gebhard
 */
public interface IStatusIndicator {

  public void setStatus(String statusText);

}
