package de.jdemo.swingui.util;

/**
 * @author Markus Gebhard
 */
public abstract class AbstractUserDialogPage extends AbstractChangeableModel implements IUserDialogPage {
  //nothing to do
}