package de.jdemo.swingui.util;

public enum LayoutDirection {

  HORIZONTAL, VERTICAL
}