package de.jdemo.swingui.lookandfeel;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager.LookAndFeelInfo;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import de.jave.lib.gui.layout.grid.GridDialogLayout;
import de.jave.lib.gui.layout.grid.GridDialogLayoutData;
import de.jave.lib.gui.layout.grid.util.ButtonPanelBuilder;
import de.jave.lib.gui.layout.grid.util.LayoutDirection;
import de.jdemo.swingui.tree.actions.CustomLookAndFeelChooserDialog;
import de.jdemo.swingui.tree.actions.CustomLookAndFeelOptions;
import de.jdemo.swingui.util.AbstractUserDialogPage;
import de.jdemo.swingui.util.Message;
import de.jdemo.swingui.util.SmartAction;
import de.jdemo.swingui.util.UserDialog;

/**
 * @author Markus Gebhard
 */
public class LookAndFeelManagerDialogPage extends AbstractUserDialogPage {

  private static final Message DEFAULT_MESSAGE = new Message("Manage available Look&Feels.");
  private LookAndFeelManagerDialogModel model;

  public static void show(Component parentComponent) {
    UserDialog dialog = new UserDialog(parentComponent, new LookAndFeelManagerDialogPage(LookAndFeelRegistry
        .getInstance()));
    dialog.show();
  }

  public LookAndFeelManagerDialogPage(LookAndFeelRegistry registry) {
    model = new LookAndFeelManagerDialogModel(registry);
  }

  public String getTitle() {
    return "Manage Look&Feels";
  }

  public String getDescription() {
    return getTitle();
  }

  public void performOk() {
    model.saveInRegistry();
  }

  public void performCancel() {
    //nothing to do
  }

  public JComponent createContent() {
    final JTable table = new JTable(new LookAndFeelTableModel(model));
    table.getColumnModel().getColumn(0).setPreferredWidth(100);
    table.getColumnModel().getColumn(1).setPreferredWidth(80);
    table.getColumnModel().getColumn(2).setPreferredWidth(200);
    table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

    final SmartAction removeAction = new SmartAction("Remove") {
      protected void execute(Component parentComponent) {
        model.removeLookAndFeelAt(table.getSelectedRow());
      }
    };
    SmartAction addAction = new SmartAction("Add...") {
      protected void execute(Component parentComponent) {
        CustomLookAndFeelChooserDialog customLookAndFeelChooserDialog = new CustomLookAndFeelChooserDialog(true);
        UserDialog userDialog = new UserDialog(parentComponent, customLookAndFeelChooserDialog);
        userDialog.show();
        if (!userDialog.isCancelled()) {
          CustomLookAndFeelOptions selectedOptions = customLookAndFeelChooserDialog.getSelectedOptions();
          String className = selectedOptions.getLookAndFeelClassName();
          String name = selectedOptions.getName();
          model.addCustomLookAndFeel(new LookAndFeelInfo(name, className));
        }
      }
    };
    table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        updateRemoveActionEnabled(table, removeAction);
      }
    });
    JScrollPane scrollPane = new JScrollPane(table);
    scrollPane.setPreferredSize(new Dimension(300, 140));

    ButtonPanelBuilder builder = new ButtonPanelBuilder(LayoutDirection.VERTICAL);
    builder.add(new JButton(addAction));
    builder.add(new JButton(removeAction));
    JPanel buttonPanel = builder.createPanel();
    buttonPanel.setBorder(null);

    JPanel tablePanel = new JPanel(new GridDialogLayout(2, false));
    GridDialogLayoutData gridLayoutData = new GridDialogLayoutData();
    gridLayoutData.setHorizontalSpan(2);
    tablePanel.add(new JLabel("Installed Look&Feels:"), gridLayoutData);
    tablePanel.add(scrollPane, GridDialogLayoutData.FILL_BOTH);
    tablePanel.add(buttonPanel, GridDialogLayoutData.FILL_VERTICAL);

    updateRemoveActionEnabled(table, removeAction);

    JPanel defaultPanel = new JPanel(new GridDialogLayout(2, false));
    defaultPanel.add(new JLabel("Default:"));
    defaultPanel.add(new DefaultLookAndFeelComboBox(model).getContent());

    JPanel panel = new JPanel(new BorderLayout(6, 6));
    panel.add(tablePanel, BorderLayout.CENTER);
    panel.add(defaultPanel, BorderLayout.SOUTH);
    return panel;
  }

  private void updateRemoveActionEnabled(JTable table, SmartAction removeAction) {
    removeAction.setEnabled(!table.getSelectionModel().isSelectionEmpty()
        && !model.isSystemLookAndFeelIndex(table.getSelectedRow()));
  }

  public Message getDefaultMessage() {
    return DEFAULT_MESSAGE;
  }

  public Message createCurrentMessage() {
    return getDefaultMessage();
  }

  public void requestFocus() {
    //nothing to do
  }
}