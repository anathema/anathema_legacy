package de.jdemo.runner;

/**
 * @author Markus Gebhard
 */
public interface IDemoRunnerExitListener {
  public void demoRunnerExited();
}