package de.jdemo.runner.path;

import de.java2html.javasource.JavaSource;

/**
 * @author Markus Gebhard
 */
public class EmptySourcePathElement implements ISourcePathElement {

  public boolean contains(String className) {
    return false;
  }

  public JavaSource load(String className) {
    return null;
  }
}
