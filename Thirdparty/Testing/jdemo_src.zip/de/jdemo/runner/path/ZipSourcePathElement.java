package de.jdemo.runner.path;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import de.java2html.javasource.JavaSource;
import de.jdemo.util.IOUtilities;

/**
 * @author Markus Gebhard
 */
public class ZipSourcePathElement extends AbstractSourcePathElement {
  private ZipFile zipFile;
  private String fileName;

  public ZipSourcePathElement(File file) throws IOException {
    fileName = file.getName();
    zipFile = new ZipFile(file, ZipFile.OPEN_READ);
  }

  public boolean contains(String className) {
    return createZipEntry(className) != null;
  }

  private ZipEntry createZipEntry(String className) {
    return zipFile.getEntry(createSourceFileName(className));
  }

  public JavaSource load(String className) throws IOException {
    ZipEntry entry = createZipEntry(className);
    if (entry == null) {
      return null;
    }
    InputStream inputStream = null;
    try {
      inputStream = zipFile.getInputStream(entry);
      return loadSourceFile(inputStream);
    }
    finally {
      IOUtilities.close(inputStream);
    }
  }

  public String toString() {
    return fileName;
  }
}