package de.jdemo.runner.path;

import java.io.IOException;

import de.java2html.javasource.JavaSource;

/**
 * @author Markus Gebhard
 */
public interface ISourcePathElement {

  public boolean contains(String className);

  public JavaSource load(String className) throws IOException;

}