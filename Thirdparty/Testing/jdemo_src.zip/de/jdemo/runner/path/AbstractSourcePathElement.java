package de.jdemo.runner.path;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import de.java2html.javasource.JavaSource;
import de.java2html.javasource.JavaSourceParser;

/**
 * @author Markus Gebhard
 */
public abstract class AbstractSourcePathElement implements ISourcePathElement {
  protected String createSourceFileName(String className) {
    return className.replace('.', '/') + ".java"; //$NON-NLS-1$
  }

  protected JavaSource loadSourceFile(InputStream stream) throws IOException {
    JavaSource javaSource = new JavaSourceParser().parse(new InputStreamReader(stream));
    return javaSource;
  }
}