package de.jdemo.runner.path;

import de.java2html.javasource.JavaSource;

/**
 * @author Markus Gebhard
 */
public class EmptySourcePath implements ISourcePath {

  public int getPathElementCount() {
    return 0;
  }

  public ISourcePathElement getPathElement(int index) {
    throw new IllegalArgumentException();
  }

  public boolean contains(String className) {
    return false;
  }

  public JavaSource load(String className) {
    return null;
  }
}
