package de.jdemo.runner.path;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import de.java2html.javasource.JavaSource;
import de.jdemo.util.IOUtilities;

/**
 * @author Markus Gebhard
 */
public class DirectorySourcePathElement extends AbstractSourcePathElement {

  private File directory;

  public DirectorySourcePathElement(File directory) {
    this.directory = directory;
  }

  public boolean contains(String className) {
    return createSourceFile(className).exists();
  }

  private File createSourceFile(String className) {
    return new File(directory, createSourceFileName(className));
  }

  public JavaSource load(String className) throws IOException {
    File file = createSourceFile(className);
    if (!file.exists()) {
      return null;
    }
    FileInputStream inputStream = null;
    try {
      inputStream = new FileInputStream(file);
      return loadSourceFile(inputStream);
    }
    finally {
      IOUtilities.close(inputStream);
    }
  }
  
  public String toString() {
    return directory.getName();
  }
}