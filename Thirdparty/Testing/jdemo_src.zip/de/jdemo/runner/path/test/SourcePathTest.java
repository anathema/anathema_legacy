package de.jdemo.runner.path.test;

import java.io.IOException;

import junit.framework.TestCase;
import de.java2html.javasource.JavaSource;
import de.jdemo.runner.path.ISourcePathElement;
import de.jdemo.runner.path.SourcePath;

/**
 * @author Markus Gebhard
 */
public class SourcePathTest extends TestCase {

  private ISourcePathElement nothingContainingPathElement = new ISourcePathElement() {
    public boolean contains(String className) {
      return false;
    }
    public JavaSource load(String className) {
      throw new IllegalStateException();
    }
  };

  private ISourcePathElement everyThingContainingPathElement = new ISourcePathElement() {
    public boolean contains(String className) {
      return true;
    }
    public JavaSource load(String className) {
      return new JavaSource("42"); //$NON-NLS-1$
    }
  };

  public void testNotExistingPathEntry() throws IOException {
    SourcePath sourcePath = new SourcePath(new ISourcePathElement[] { nothingContainingPathElement });
    assertFalse(sourcePath.contains("test")); //$NON-NLS-1$
    assertEquals(null, sourcePath.load("test")); //$NON-NLS-1$
  }

  public void testLoadsFromSecondElement() throws IOException {
    SourcePath sourcePath =
      new SourcePath(new ISourcePathElement[] { nothingContainingPathElement, everyThingContainingPathElement });
    assertTrue(sourcePath.contains("test")); //$NON-NLS-1$
    assertEquals("42", sourcePath.load("test").getCode()); //$NON-NLS-1$ //$NON-NLS-2$
  }
}