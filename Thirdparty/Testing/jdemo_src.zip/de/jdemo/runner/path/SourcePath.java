package de.jdemo.runner.path;

import java.io.IOException;

import de.java2html.javasource.JavaSource;

/**
 * @author Markus Gebhard
 */
public class SourcePath implements ISourcePath {
  private ISourcePathElement[] pathElements;

  public SourcePath(ISourcePathElement[] pathElements) {
    this.pathElements = pathElements;
  }

  public int getPathElementCount() {
    return pathElements.length;
  }

  public ISourcePathElement getPathElement(int index) {
    return pathElements[index];
  }

  public boolean contains(String className) {
    for (int i = 0; i < getPathElementCount(); i++) {
      if (getPathElement(i).contains(className)) {
        return true;
      }
    }
    return false;
  }

  public JavaSource load(String className) throws IOException {
    for (int i = 0; i < getPathElementCount(); i++) {
      if (getPathElement(i).contains(className)) {
        return getPathElement(i).load(className);
      }
    }
    return null;
  }
}