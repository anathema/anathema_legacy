package de.jdemo.runner;

/**
 * @author Markus Gebhard
 */
public class DemoSourceCodeNotFoundException extends Exception {
  //nothing to do
}