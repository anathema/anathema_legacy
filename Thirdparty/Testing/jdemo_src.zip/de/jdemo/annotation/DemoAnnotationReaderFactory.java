package de.jdemo.annotation;

/**
 * @author Markus Gebhard
 */
public class DemoAnnotationReaderFactory {

  private final static IDemoAnnotationReader readerInstance = createReaderInstance();

  /** @return An annotation reader for this runtime or <code>null</code> if there is none
   * available. */
  public static IDemoAnnotationReader getDemoAnnotationReader() {
    return readerInstance;
  }

  private static IDemoAnnotationReader createReaderInstance() {
    try {
      Class class1 = Class.forName("de.jdemo.annotation.TigerDemoAnnotationReader");
      IDemoAnnotationReader reader = (IDemoAnnotationReader) class1.newInstance();
      return reader;
    }
    catch (UnsupportedClassVersionError e) {
      //So we do not have a 1.5 compatible runtime 
      return null;
    }
    catch (NoClassDefFoundError e) {
      return null;
    }
    catch (ClassNotFoundException e) {
      return null;
    }
    catch (InstantiationException e) {
      throw new RuntimeException(e);
    }
    catch (IllegalAccessException e) {
      throw new RuntimeException(e);
    }
  }
}