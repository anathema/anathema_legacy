package de.jdemo.extensions.test;

import javax.swing.JWindow;

import junit.framework.Assert;
import de.jdemo.extensions.SwingDemoCase;
import de.jdemo.framework.IDemoCase;

public class MockSwingDemoCase extends SwingDemoCase {
  private String title = "title"; //$NON-NLS-1$
  private RuntimeException exception = new RuntimeException();
  private JWindow window;

  private int expectedDemoEmptyCalls = 0;
  private int expectedDemoExitCalls = 0;
  private int expectedDemoCrashCalls = 0;
  private int expectedDemoShowWindowCalls = 0;
  private int expectedSetUpCalls = 0;
  private int expectedTearDownCalls = 0;
  private int demoEmptyCalls = 0;
  private int demoShowWindowCalls = 0;
  private int demoExitCalls = 0;
  private int demoCrashCalls = 0;
  private int setUpCalls = 0;
  private int tearDownCalls = 0;

  public MockSwingDemoCase(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    ++setUpCalls;
    window = new JWindow();
  }

  protected void tearDown() throws Exception {
    ++tearDownCalls;
  }

  public IDemoCase getClone() {
    return this;
  }

  public void demoShowWindow() {
    ++demoShowWindowCalls;
    show(window);
  }

  public void demoShowCreatedFrame() {
    show(createJFrame());
  }

  public void demoShowCreatedFrameWithGivenTitle() {
    setFrameTitle(title);
    show(createJFrame());
  }

  public void demoEmpty() {
    ++demoEmptyCalls;
  }

  public void demoExit() {
    ++demoExitCalls;
    exit();
  }

  public void demoCrash() {
    ++demoCrashCalls;
    exception.fillInStackTrace();
    throw exception;
  }

  public void verify() {
    Assert.assertEquals(expectedDemoCrashCalls, demoCrashCalls);
    Assert.assertEquals(expectedDemoEmptyCalls, demoEmptyCalls);
    Assert.assertEquals(expectedDemoExitCalls, demoExitCalls);
    Assert.assertEquals(expectedDemoShowWindowCalls, demoShowWindowCalls);
    Assert.assertEquals(expectedSetUpCalls, setUpCalls);
    Assert.assertEquals(expectedTearDownCalls, tearDownCalls);
  }

  public void setExpectedDemoCrashCalls(int expectedDemoCrashCalls) {
    this.expectedDemoCrashCalls = expectedDemoCrashCalls;
  }

  public void setExpectedDemoEmptyCalls(int expectedDemoEmptyCalls) {
    this.expectedDemoEmptyCalls = expectedDemoEmptyCalls;
  }

  public void setExpectedDemoExitCalls(int expectedDemoExitCalls) {
    this.expectedDemoExitCalls = expectedDemoExitCalls;
  }

  public void setExpectedDemoShowWindowCalls(int expectedDemoShowWindowCalls) {
    this.expectedDemoShowWindowCalls = expectedDemoShowWindowCalls;
  }

  public void setExpectedSetUpCalls(int expectedSetUpCalls) {
    this.expectedSetUpCalls = expectedSetUpCalls;
  }

  public void setExpectedTearDownCalls(int expectedTearDownCalls) {
    this.expectedTearDownCalls = expectedTearDownCalls;
  }

  public JWindow getWindow() {
    return window;
  }

  public Exception getException() {
    return exception;
  }

  public String getTitle() {
    return title;
  }
}