package de.jdemo.extensions;

/**
 * Marker interface => No need to instantiate the SwtDemoCase class w/o SWT on the classpath. 
 * @author Markus Gebhard
 */
public interface ISwtDemoCase {
  //Empty marker interface
}