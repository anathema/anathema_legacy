package de.jdemo.extensions;

import java.awt.Window;

import de.jdemo.framework.DemoCaseRunnable;
import de.jdemo.framework.IDemoCaseRunnable;

/**
 * @author Markus Gebhard
 */
public class GuiDemoCaseRunnable extends DemoCaseRunnable implements IDemoCaseRunnable {

  public GuiDemoCaseRunnable(GuiDemoCase demoCase) {
    super(demoCase);
  }

  protected void runMainDemo() throws Throwable {
    ((GuiDemoCase)getDemo()).runDemo();
    Window demoWindow = ((GuiDemoCase)getDemo()).getRegisteredDemoWindow();
    if (demoWindow!=null && !demoWindow.isVisible()) {
      exit();
    }
    checkShowWasCalled();
  }

}