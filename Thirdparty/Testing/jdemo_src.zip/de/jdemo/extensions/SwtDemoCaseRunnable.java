package de.jdemo.extensions;

import de.jdemo.framework.DemoCaseRunnable;
import de.jdemo.framework.IDemoCaseRunnable;

/**
 * @author Markus Gebhard
 */
public class SwtDemoCaseRunnable extends DemoCaseRunnable implements IDemoCaseRunnable {

  public SwtDemoCaseRunnable(SwtDemoCase demo) {
    super(demo);
  }

  public SwtDemoCase getSwtDemoCase(){
    return (SwtDemoCase) getDemo();
  }
  
  protected void runMainDemo() throws Throwable {
    getSwtDemoCase().runDemo();
    exit();
    /*TODO Jul 21, 2004 (Markus Gebhard): Ensure that 'show' was called - as soon as it is clear
    what show methods in SWT are...*/
  }
}