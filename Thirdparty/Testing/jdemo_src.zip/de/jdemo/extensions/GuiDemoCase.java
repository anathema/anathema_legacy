package de.jdemo.extensions;

import java.awt.Window;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import de.jdemo.framework.AbstractDemoCase;
import de.jdemo.framework.IDemoCaseRunnable;

/**
 * @author Markus Gebhard
 */
public abstract class GuiDemoCase extends AbstractDemoCase {
  private boolean registeredDemoWindowOpened = false;
  private Window demoWindow;
  private DemoExitWindowListener exitWindowListener = new DemoExitWindowListener(this);

  public GuiDemoCase() {
    super();
  }

  public GuiDemoCase(String name) {
    super(name);
  }

  protected Object clone() {
    GuiDemoCase clone = (GuiDemoCase) super.clone();
    clone.demoWindow = null;
    clone.exitWindowListener=new DemoExitWindowListener(clone);
    return clone;
  }

  //TODO Jul 21, 2004 (Markus Gebhard): Add annotation @Overrides
  public IDemoCaseRunnable createRunnable() {
    return new GuiDemoCaseRunnable((GuiDemoCase) getClone());
  }

  protected void disposeDemoWindow() {
    if (demoWindow != null && demoWindow.isDisplayable()) {
      demoWindow.dispose();
    }
  }

  /** Registers the given window as demo window for this GuiDemoCase. Usually called by any framework method
   * that displays a window object. */
  protected final void registerDemoWindow(Window window) {
    demoWindow = window;
    attachExitDemoWindowListener(window);
  }

  private boolean hasExitDemoWindowListenerAttached(Window window) {
    WindowListener[] listeners = window.getWindowListeners();
    for (int i = 0; i < listeners.length; ++i) {
      if (listeners[i]==exitWindowListener) {
        return true;
      }
    }
    return false;
  }

  private void attachExitDemoWindowListener(Window window) {
    if (!hasExitDemoWindowListenerAttached(window)) {
      window.addWindowListener(exitWindowListener);
    }
  }
  
  private static class DemoExitWindowListener extends WindowAdapter {
    private GuiDemoCase demoCase;

    public DemoExitWindowListener(GuiDemoCase demoCase) {
      this.demoCase = demoCase;
    }
    public void windowClosing(WindowEvent e) {
      //received when user requests close() on the window
      demoCase.exit();
    }

    public void windowOpened(WindowEvent e) {
      demoCase.setRegisteredDemoWindowOpened(true);
    }

    public void windowClosed(WindowEvent e) {
      //received when window.dispose(); called
      demoCase.exit();
    }
  }

  public void cancel() {
    super.cancel();
    disposeDemoWindow();
    exit();
  }
  
  protected void exit() {
    if (demoWindow!=null && hasExitDemoWindowListenerAttached(demoWindow)) {
      demoWindow.removeWindowListener(exitWindowListener);
    }
    super.exit();
  }
  
  /** Returns the demo window registered with this GuiDemoCase or <code>null</code>
   * if there is none registered. 
   * @see #registerDemoWindow(Window)
   */
  public Window getRegisteredDemoWindow() {
    return demoWindow;
  }

  public void executeTearDown() throws Exception {
    super.executeTearDown();
    disposeDemoWindow();
  }

  public boolean isRegisteredDemoWindowOpened() {
    return registeredDemoWindowOpened;
  }

  protected void setRegisteredDemoWindowOpened(boolean opened) {
    this.registeredDemoWindowOpened = opened;
  }
}