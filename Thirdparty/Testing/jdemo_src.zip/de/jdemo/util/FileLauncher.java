package de.jdemo.util;

import java.io.File;
import java.io.IOException;

/**
 * @author Markus Gebhard
 */
public class FileLauncher implements IFileLauncher {

  /**
   * Tries to open the given file by passing it to the operating system.
   * Note that this might not work properly on all systems.
   * (In fact it only works on windows systems at the moment.)
   */
  public void launch(File file) throws Exception {
    launch(file.getAbsolutePath());
  }

  public void launch(String filePath) throws IOException {
    String osVersion = System.getProperty("os.name"); //$NON-NLS-1$
    if (osVersion.equals("Windows 98")) { //$NON-NLS-1$
      Runtime.getRuntime().exec("start \"" + filePath + "\""); //$NON-NLS-1$ //$NON-NLS-2$
    }
    else if (osVersion.equals("Windows 95")) { //$NON-NLS-1$
      Runtime.getRuntime().exec("start \"" + filePath + "\""); //$NON-NLS-1$ //$NON-NLS-2$
    }
    else if (osVersion.startsWith("Windows")) { //$NON-NLS-1$
      Runtime.getRuntime().exec("cmd.exe /c start " + filePath); //$NON-NLS-1$
    }
    else {
      //TODO 15.06.2003 (Markus Gebhard): Try to implement file launching for other platforms, too
      throw new RuntimeException(
          "Launching files not currently supported for your operating system '" + osVersion + "'."); //$NON-NLS-1$ //$NON-NLS-2$
    }
  }
}