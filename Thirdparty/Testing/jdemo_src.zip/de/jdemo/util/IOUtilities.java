package de.jdemo.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;

/**
 * @author Markus Gebhard
 */
public class IOUtilities {
  private IOUtilities() {
    //not instantiable
  }
  
  public static void close(Writer writer) {
    if (writer != null) {
      try {
        writer.close();
      }
      catch (IOException e) {
        //ignore
      }
    }
  }
  public static void close(Reader reader) {
    if (reader != null) {
      try {
        reader.close();
      }
      catch (IOException e) {
        //ignore
      }
    }
  }

  public static void close(InputStream inputStream) {
    if (inputStream != null) {
      try {
        inputStream.close();
      }
      catch (IOException e) {
        //ignore
      }
    }
  }

  public static void close(OutputStream stream) {
    if (stream != null) {
      try {
        stream.close();
      }
      catch (IOException exception) {
        //logger.error("An error occured closing an output stream",
        // exception);
      }
    }
  }

  public static void copy(File sourceFile, File destinationFile) throws IOException {
    if (!ensureFoldersExist(destinationFile.getParentFile())) {
      throw new IOException("Unable to create necessary output directory "
          + destinationFile.getParentFile());
    }
    BufferedInputStream bis = null;
    BufferedOutputStream bos = null;
    try {
      bis = new BufferedInputStream(new FileInputStream(sourceFile));
      bos = new BufferedOutputStream(new FileOutputStream(destinationFile));
      copyStream(bis, bos);
    }
    finally {
      close(bis);
      close(bos);
    }
  }

  public static boolean ensureFoldersExist(File folder) {
    if (folder.exists()) {
      return true;
    }
    return folder.mkdirs();
  }

  public static void copyStream(InputStream in, OutputStream out) throws IOException {
    //TODO 12.12.2003 (gebhard): BufferedStreams zur Performanceverbesserung?
    byte[] buffer = new byte[4096];
    while (true) {
      int bytesRead = in.read(buffer);
      if (bytesRead == -1) {
        break;
      }
      out.write(buffer, 0, bytesRead);
    }
  }
}