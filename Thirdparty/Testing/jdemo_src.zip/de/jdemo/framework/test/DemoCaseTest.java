package de.jdemo.framework.test;

import de.jdemo.framework.DemoCase;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.state.DemoState;

/**
 * @author Markus Gebhard
 */
public class DemoCaseTest extends AbstractDemoCaseTest {

  protected IDemoCase createEmptyDemo() {
    return new DemoCase("demo") {
      //empty
    };
  }

  protected IDemoCase createCrashingDemo(final RuntimeException exception) {
    return new DemoCase("demo") {
      public void demo() {
        throw exception;
      }
    };
  }

  protected IDemoCase createValidSelfExitingDemo() {
    return new DemoCase("demo") {
      public void demo() {
        System.out.println("hello world");
      }
    };
  }

  public void testExceptionInNewThreadInsideDemo() {
    //Exceptions in threads created inside demos can only be caught by using a ThredGroup
    //created by the given convenience method.
    final RuntimeException exception = new RuntimeException();
    IDemoCase demoCase = new DemoCase("demo") {
      public void demo() throws InterruptedException {
        new Thread(createThreadGroup(), new Runnable() {
          public void run() {
            throw exception;
          }
        }).start();
        Thread.sleep(1000); //demo duration longer than it takes to throw the exception
      }
    };
    IDemoCaseRunnable runner = demoCase.createRunnable();
    runner.run();
    assertEquals(DemoState.CRASHED, runner.getState());
    assertEquals(exception, runner.getThrowable());
  }
}