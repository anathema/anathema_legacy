package de.jdemo.framework;

/**
 * Demo case base class for demos having output not supported by the other demo case base classes.
 * Plain demo cases are useful when you want to demonstrate output to an LPT/COM/USB port or to a
 * soundcard for example.
 * 
 * @author Markus Gebhard
 */
public class PlainDemoCase extends AbstractDemoCase {

  public IDemoCaseRunnable createRunnable() {
    return new PlainDemoCaseRunnable((PlainDemoCase) this.clone());
  }

}