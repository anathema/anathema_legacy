package de.jdemo.framework;

/**
 * @author Markus Gebhard
 */
public class PlainDemoCaseRunnable extends DemoCaseRunnable implements IDemoCaseRunnable {

  public PlainDemoCaseRunnable(PlainDemoCase demoCase) {
    super(demoCase);
  }

  public void run() {
    Thread thread = new Thread(Thread.currentThread().getThreadGroup(), new Runnable() {
      public void run() {
        runInternal();
      }
    });
    setRunThread(thread);
    thread.start();
  }

  protected void checkShowWasCalled() {
    //nothing to do
  }

}