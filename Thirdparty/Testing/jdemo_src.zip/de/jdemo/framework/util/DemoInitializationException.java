package de.jdemo.framework.util;

/**
 * @author Markus Gebhard
 */
public class DemoInitializationException extends RuntimeException {

  public DemoInitializationException(String message, Throwable cause) {
    super(message, cause);
  }
}