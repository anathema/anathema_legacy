package de.jdemo.framework.util;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import de.jdemo.framework.DemoIdentifier;
import de.jdemo.framework.IDemo;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.exceptions.DemoClassNotFoundException;

/**
 * @author Markus Gebhard
 */
public class DemoUtilities {
  public static final String DEMO_METHOD_NAME_PREFIX = "demo";
  public static final String SUITE_METHOD_NAME = "suite";

  public static IDemoCase createDemoCase(String demoName, Class demoClass) {
    IDemoCase demo;
    try {
      try {
        Class[] classArgs = { String.class };
        Constructor constructor = demoClass.getConstructor(classArgs);
        Object newInstance = constructor.newInstance(new Object[]{ demoName });
        if (!(newInstance instanceof IDemoCase)) {
          demo= createDemoDoesNotImplementDemoInterfaceError(demoName);
        } else {
        demo = (IDemoCase) newInstance;
        }
      }
      catch (NoSuchMethodException e) {
        Constructor constructor = demoClass.getConstructor(new Class[0]);
        Object newInstance = constructor.newInstance(new Object[0]);
        if (!(newInstance instanceof IDemoCase)) {
          demo = createDemoDoesNotImplementDemoInterfaceError(demoName);
        } else {
          demo = (IDemoCase) newInstance;
          demo.setName(demoName);
        }
      }
      return demo;
    }
    catch (InstantiationException e) {
      return createErrorDemo("Could not create demo '" + demoName + "' (" + e + ")", e);
    }
    catch (IllegalAccessException e) {
      return createErrorDemo("Could not create demo '" + demoName + "' (" + e + ")", e);
    }
    catch (InvocationTargetException e) {
      return createErrorDemo("Could not create demo '" + demoName + "' (" + e + "", e);
    }
    catch (NoSuchMethodException e) {
      return createErrorDemo("Could not create demo '" + demoName + "' (" + e + "", e);
    }
  }

  private static IDemoCase createDemoDoesNotImplementDemoInterfaceError(String demoName) {
    return createErrorDemo("Could not create demo '" +demoName+"' - class does not implement the "+IDemoCase.class, null);
  }

  public static IDemoCase createErrorDemo(final String message, final Throwable exception) {
    return new ErrorDemoCase(new DemoInitializationException(message, exception));
  }

  public static String getDisplayName(IDemo demo) {
    String name = demo.getName();
    if (DEMO_METHOD_NAME_PREFIX.equals(name)) {
      name = getRawClassName(demo.getClass());
    }
    return formatDemoName(name);
  }

  private static String getRawClassName(Class class1) {
    String name = class1.getName();
    if (name.endsWith("Demo")) {
      name = name.substring(0, name.length() - 4);
    }
    if (name.indexOf('.') != -1) {
      name = name.substring(name.lastIndexOf('.') + 1);
    }
    return name;
  }

  private static String formatDemoName(String name) {
    if (name == null) {
      return null;
    }

    if (isClassName(name)) {
      return name;
    }

    //handle demos w/o name
    if (DEMO_METHOD_NAME_PREFIX.equals(name)) {
      return DEMO_METHOD_NAME_PREFIX + "()";
    }

    if (name.startsWith(DEMO_METHOD_NAME_PREFIX)) {
      name = name.substring(4);
    }

    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < name.length(); ++i) {
      char ch = name.charAt(i);
      if (i > 0) {
        if (Character.isUpperCase(ch)) {
          sb.append(' ');
        }
        else if (Character.isDigit(ch) && !Character.isDigit(name.charAt(i - 1))) {
          sb.append(' ');
        }
      }
      sb.append(ch);
    }
    return sb.toString();
  }

  private static boolean isClassName(String name) {
    return name.indexOf('.') != -1;
  }

  public static IDemoCase createDemo(DemoIdentifier demoId) throws DemoClassNotFoundException {
    Class clazz;
    try {
      //      clazz = new DemoCaseClassLoader().loadClass(demoId.getClassName(), true);
      clazz = Class.forName(demoId.getClassName());
    }
    catch (ClassNotFoundException e) {
      throw new DemoClassNotFoundException(demoId.getClassName());
    }
    return createDemoCase(demoId.getMethodName(), clazz);
  }

  public static boolean isDemoIdentifier(String demoName) {
    return DemoIdentifier.isValidIdentifier(demoName);
  }
}