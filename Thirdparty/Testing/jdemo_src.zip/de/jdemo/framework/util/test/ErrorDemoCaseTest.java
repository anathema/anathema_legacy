package de.jdemo.framework.util.test;

import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.state.DemoState;
import de.jdemo.framework.util.ErrorDemoCase;

import junit.framework.TestCase;

/**
 * @author Markus Gebhard
 */
public class ErrorDemoCaseTest extends TestCase {

  public void test() {
    RuntimeException cause = new RuntimeException("cause");
    ErrorDemoCase demoCase = new ErrorDemoCase(cause);
    assertNotNull(demoCase.getIdentifier());
    IDemoCaseRunnable runnable = demoCase.createRunnable();
    runnable.run();
    assertEquals(DemoState.CRASHED, runnable.getState());
    assertEquals(cause, runnable.getThrowable());
  }

}