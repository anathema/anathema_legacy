package de.jdemo.framework;

/**
 * @author Markus Gebhard
 */
public interface ITextLauncher {

  public void launch(CharSequence text);

}
