package de.jdemo.framework;

/**
 * An actual demo case that can be launched using its runner.
 * @author Markus Gebhard
 */
public interface IDemoCase extends IDemo {
  /** Creates a runnable for running this demo case. */
  public IDemoCaseRunnable createRunnable();

  public DemoIdentifier getIdentifier();
}