package de.jdemo.framework;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

import de.jdemo.framework.util.DemoInitializationException;
import de.jdemo.framework.util.DemoUtilities;
import de.jdemo.framework.util.ErrorDemoCase;

public class DemoSuite implements IDemoSuite {
  private List demos = new ArrayList(10);
  private String name;

  /**
   * Constructs an empty DemoSuite.
   */
  public DemoSuite() {
    //nothing to do
  }

  /**
   * Constructs a DemoSuite from the given class with the given name.
   * @see DemoSuite#DemoSuite(Class)
   */
  public DemoSuite(Class theClass, String name) {
    this(theClass);
    setName(name);
  }

  /**
   * Constructs a DemoSuite from the given class. Adds all the methods
   * starting with "demo" as demo cases to the suite.
   */
  public DemoSuite(final Class theClass) {
    name = theClass.getName();
    try {
      getDemoConstructor(theClass); // Avoid generating multiple error messages
    }
    catch (NoSuchMethodException e) {
      addDemo(createErrorDemo("Class "
          + theClass.getName()
          + " has no public constructor "
          + theClass.getName()
          + "(String name) or "
          + theClass.getName()
          + "()", e));
      return;
    }

    if (!Modifier.isPublic(theClass.getModifiers())) {
      addDemo(createErrorDemo("Class " + theClass.getName() + " is not public", null));
      return;
    }

    Class superClass = theClass;
    List names = new ArrayList();
    while (IDemo.class.isAssignableFrom(superClass)) {
      Method[] methods = superClass.getDeclaredMethods();
      for (int i = 0; i < methods.length; i++) {
        addDemoMethod(methods[i], names, theClass);
      }
      superClass = superClass.getSuperclass();
    }
    if (demos.size() == 0) {
      addDemo(createErrorDemo("No demos found in " + theClass.getName(), null));
    }
  }

  /**
   * Constructs an empty DemoSuite.
   */
  public DemoSuite(String name) {
    setName(name);
  }

  public void accept(IDemoVisitor visitor) {
    visitor.visitDemoSuite(this);
  }

  /**
   * Adds a demo to the suite.
   */
  public void addDemo(IDemo demo) {
    demos.add(demo);
  }

  /**
   * Adds the demos from the given class to the suite
   */
  public void addDemoSuite(Class demoClass) {
    addDemo(new DemoSuite(demoClass));
  }

  private void addDemoMethod(Method method, List names, Class theClass) {
    String name = method.getName();
    if (names.contains(name))
      return;
    if (!isPublicDemoMethod(method)) {
      if (isDemoMethod(method)) {
        addDemo(createErrorDemo("Demo method '" + method.getName() + "' is not public in " + theClass, null));
      }
      return;
    }
    names.add(name);
    addDemo(createDemo(theClass, name));
  }

  /**
   * ...as the moon sets over the early morning Merlin, Oregon
   * mountains, our intrepid adventurers type...
   */
  public static IDemo createDemo(Class theClass, String name) {
    Constructor constructor;
    try {
      constructor = getDemoConstructor(theClass);
    }
    catch (NoSuchMethodException e) {
      return createErrorDemo("Class "
          + theClass.getName()
          + " has no public constructor "
          + theClass.getName()
          + "(String name) or "
          + theClass.getName()
          + "()", e);
    }
    IDemo demo;
    try {
      if (constructor.getParameterTypes().length == 0) {
        demo = (IDemo) constructor.newInstance(new Object[0]);
        demo.setName(name);
      }
      else {
        demo = (IDemo) constructor.newInstance(new Object[]{ name });
      }
    }
    catch (InstantiationException e) {
      return (createErrorDemo("Cannot instantiate demo case: " + name + " (" + exceptionToString(e) + ")", e));
    }
    catch (InvocationTargetException e) {
      return (createErrorDemo("Exception in constructor: "
          + name
          + " ("
          + exceptionToString(e.getTargetException())
          + ")", e.getTargetException()));
    }
    catch (IllegalAccessException e) {
      return (createErrorDemo("Cannot access demo case: " + name + " (" + exceptionToString(e) + ")", e));
    }
    return demo;
  }

  /**
   * Converts the stack trace into a string
   */
  private static String exceptionToString(Throwable t) {
    StringWriter stringWriter = new StringWriter();
    PrintWriter writer = new PrintWriter(stringWriter);
    t.printStackTrace(writer);
    return stringWriter.toString();

  }

  /**
   * Gets a constructor which takes a single String as
   * its argument or a no arg constructor.
   */
  public static Constructor getDemoConstructor(Class theClass) throws NoSuchMethodException {
    Class[] args = { String.class };
    try {
      return theClass.getConstructor(args);
    }
    catch (NoSuchMethodException e) {
      // fall through
    }
    return theClass.getConstructor(new Class[0]);
  }

  private boolean isPublicDemoMethod(Method m) {
    return isDemoMethod(m) && Modifier.isPublic(m.getModifiers());
  }

  private boolean isDemoMethod(Method m) {
    String name = m.getName();
    Class[] parameters = m.getParameterTypes();
    Class returnType = m.getReturnType();
    return parameters.length == 0
        && name.startsWith(DemoUtilities.DEMO_METHOD_NAME_PREFIX)
        && returnType.equals(Void.TYPE);
  }

  /**
   * Returns the demo at the given index
   */
  public IDemo getDemoAt(int index) {
    return (IDemo) demos.get(index);
  }

  public String toString() {
    if (getName() != null)
      return getName();
    return super.toString();
  }

  /**
   * Sets the name of the suite.
   * @param name The name to set
   */
  public void setName(String name) {
    this.name = name;
  }

  /**
   * Returns the name of the suite. Not all
   * demo suites have a name and this method
   * can return <code>null</code>.
   */
  public String getName() {
    return name;
  }

  /**
   * Returns a demo which will fail and log a warning message.
   */
  private static IDemo createErrorDemo(final String message, Throwable cause) {
    return new ErrorDemoCase(new DemoInitializationException(message, cause));
  }

  /**
   * Returns the number of demos in this suite
   */
  public int getDemoCount() {
    return demos == null ? 0 : demos.size();
  }
}