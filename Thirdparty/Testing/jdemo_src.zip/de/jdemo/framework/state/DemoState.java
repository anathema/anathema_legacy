package de.jdemo.framework.state;

/**
 * Typesafe enumeration for demo execution states.
 * @author Markus Gebhard
 */
public abstract class DemoState {

  public static DemoState INITIAL =
    new DemoState("initial") { //$NON-NLS-1$
      public boolean isTerminated() {
        return false;
      }
      public void accept(IDemoStateVisitor visitor){
        visitor.visitInitial(this);
      }
  };

  public static DemoState CRASHED =
    new DemoState("crashed") { //$NON-NLS-1$
      public boolean isTerminated() {
        return true;
      }
      public void accept(IDemoStateVisitor visitor){
        visitor.visitCrashed(this);
      }
  };

  public static DemoState STARTING =
    new DemoState("starting") { //$NON-NLS-1$
      public boolean isTerminated() {
        return false;
      }
      public void accept(IDemoStateVisitor visitor){
        visitor.visitStarting(this);
      }
  };

  public static DemoState RUNNING =
    new DemoState("running") { //$NON-NLS-1$
      public boolean isTerminated() {
        return false;
      }
      public void accept(IDemoStateVisitor visitor){
        visitor.visitRunning(this);
      }
  };

  public static DemoState FINISHED =
    new DemoState("finished") { //$NON-NLS-1$
      public boolean isTerminated() {
        return true;
      }
      public void accept(IDemoStateVisitor visitor){
        visitor.visitFinished(this);
      }
  };

  private String name;

  private DemoState(String name) {
    this.name = name;
  }

  public String toString() {
    return "DemoCase{" + name + "}"; //$NON-NLS-1$ //$NON-NLS-2$
  }
  
  public abstract boolean isTerminated();

  public abstract void accept(IDemoStateVisitor visitor);
}