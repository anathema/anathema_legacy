package de.jdemo.framework.state;

/**
 * @author Markus Gebhard
 */
public interface IDemoStateChangeListener {

  public void demoStateChanged(IDemoStateChangeEvent event);

}