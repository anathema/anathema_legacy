package de.jdemo.junit;

import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

import junit.framework.TestCase;
import junit.framework.TestResult;

import de.jdemo.framework.DemoCase;
import de.jdemo.framework.IDemoCase;
import de.jdemo.framework.IDemoCaseRunnable;
import de.jdemo.framework.ITextLauncher;
import de.jdemo.framework.PlainDemoCase;
import de.jdemo.framework.state.DemoState;
import de.jdemo.framework.state.IDemoStateVisitor;
import de.jdemo.util.BooleanHolder;
import de.jdemo.util.IFileLauncher;

public class DemoTestCase extends TestCase {

  private IDemoCase demo;
  private long timeOutMillis;

  public DemoTestCase(IDemoCase demo, long timeOutMillis) {
    super(demo.getName());
    this.demo = demo;
    this.timeOutMillis = timeOutMillis;
  }

  public void run(TestResult result) {
    runDemoCaseAsTest(demo, result);
  }

  private void runDemoCaseAsTest(final IDemoCase demoCase, final TestResult result) {
    result.startTest(this);

    if (demoCase instanceof DemoCase) {
      ((DemoCase) demoCase).setFileLauncher(new IFileLauncher() {
        public void launch(File file) throws Exception {
          //nothing to do
        }
      });
      ((DemoCase) demoCase).setTextLauncher(new ITextLauncher() {
        public void launch(CharSequence text) {
          //nothing to do
        }
      });
    }

    final IDemoCaseRunnable runner = demoCase.createRunnable();

    if (!(demoCase instanceof PlainDemoCase)) {
      executeDemoCaseRunnable(demoCase, result, runner);
    }

    result.endTest(this);
  }

  private void executeDemoCaseRunnable(
      final IDemoCase demoCase,
      final TestResult result,
      final IDemoCaseRunnable runner) {
    final BooleanHolder timeOutFlag = new BooleanHolder(false);
    Timer timer = new Timer();
    timer.schedule(new TimerTask() {
      public void run() {
        timeOutFlag.setValue(true);
        runner.cancel();
      }
    }, timeOutMillis);

    runner.run();
    timer.cancel();
    if (!runner.getState().isTerminated()) {
      runner.cancel();
    }

    if (timeOutFlag.getValue()) {
      result.addError(DemoTestCase.this, new Error("Timeout when running demo "
          + demoCase.getIdentifier()
          + ": Demo method did not return within "
          + timeOutMillis
          + "ms."));
    }
    else {
      runner.getState().accept(new IDemoStateVisitor() {
        public void visitFinished(DemoState state) {
          //test succeeded
        }

        public void visitRunning(DemoState state) {
          result.addError(DemoTestCase.this, new Error("Illegal state for a demo "
              + demoCase.getIdentifier()
              + ": "
              + state
              + " although being run/cancelled"));
        }

        public void visitInitial(DemoState state) {
          result.addError(DemoTestCase.this, new Error("Illegal state for a demo "
              + demoCase.getIdentifier()
              + ": "
              + state
              + " although being run/cancelled"));
        }

        public void visitCrashed(DemoState state) {
          result.addError(DemoTestCase.this, runner.getThrowable());
        }

        public void visitStarting(DemoState state) {
          result.addError(DemoTestCase.this, new Error("Illegal state for a demo "
              + demoCase.getIdentifier()
              + ": "
              + state
              + " although being run/cancelled"));
        }
      });
    }
  }
}