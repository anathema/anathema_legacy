/*  Copyright (c) 2000-2004 jMock.org
 */
package org.jmock.builder;


public interface IdentityBuilder
{
    void id( String id );
}
