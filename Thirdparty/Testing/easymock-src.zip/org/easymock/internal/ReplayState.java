/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.internal;

import java.lang.reflect.Method;

import org.easymock.ArgumentsMatcher;

public class ReplayState implements IMockControlState {

    private IBehavior behavior;

    public ReplayState(IBehavior behavior) {
        this.behavior = behavior;
    }

    public Object invoke(Object proxy, Method method, Object[] args)
        throws Throwable {
        return behavior.addActual(new MethodCall(method, args)).returnObjectOrThrowException();
    }

    public void verify() {
        behavior.verify();
    }

    public void replay() {
        throwIllegalStateException();
    }

    public void setVoidCallable(Range count) {
        throwIllegalStateException();
    }

    public void setThrowable(Throwable throwable, Range count) {
        throwIllegalStateException();
    }

    public void setReturnValue(boolean value, Range count) {
        throwIllegalStateException();
    }

    public void setReturnValue(long value, Range count) {
        throwIllegalStateException();
    }

    public void setReturnValue(float value, Range count) {
        throwIllegalStateException();
    }

    public void setReturnValue(double value, Range count) {
        throwIllegalStateException();
    }

    public void setReturnValue(Object value, Range count) {
        throwIllegalStateException();
    }

    public void setDefaultVoidCallable() {
        throwIllegalStateException();
    }

    public void setDefaultThrowable(Throwable throwable) {
        throwIllegalStateException();
    }

    public void setDefaultReturnValue(float value) {
        throwIllegalStateException();
    }

    public void setDefaultReturnValue(boolean value) {
        throwIllegalStateException();
    }

    public void setDefaultReturnValue(long value) {
        throwIllegalStateException();
    }

    public void setDefaultReturnValue(double value) {
        throwIllegalStateException();
    }

    public void setDefaultReturnValue(Object value) {
        throwIllegalStateException();
    }

    public void setMatcher(ArgumentsMatcher matcher) {
        throwIllegalStateException();
    }

    public void setDefaultMatcher(ArgumentsMatcher matcher) {
        throwIllegalStateException();
    }

    private void throwIllegalStateException() {
        throw new IllegalStateException("This method must not be called in replay state.");
    }
}