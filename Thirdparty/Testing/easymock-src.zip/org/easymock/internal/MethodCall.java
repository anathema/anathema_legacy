/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.internal;

import java.lang.reflect.Method;

import org.easymock.ArgumentsMatcher;

public class MethodCall {

    private Arguments arguments;
    private Method method;

    public MethodCall(Method method, Object[] arguments) {
        this(method, new Arguments(arguments));
    }

    public MethodCall(Method method, Arguments arguments) {
		this.method = method;
		this.arguments = arguments;
    }

    public int hashCode() {
		throw new UnsupportedOperationException("hashCode() is not implemented");
    }

    public boolean equals(Object o) {
        if (o == null || !o.getClass().equals(this.getClass()))
            return false;

        MethodCall other = (MethodCall) o;
        return this.method.equals(other.method)
            && this.arguments.equals(other.arguments);
    }

    public Method getMethod() {
        return method;
    }

	public Arguments getArguments() {
		return arguments;
	}
        
	public boolean equals(MethodCall methodCall, ArgumentsMatcher matcher) {
		return method.equals(methodCall.method)
						&& arguments.matches(methodCall.arguments, matcher);
	}

	public String toString(ArgumentsMatcher matcher) {
        return method.getName()
            + "("
            + arguments.toString(matcher)
            + ")";
    }

}
