/*
 * Copyright (c) 2001-2004 OFFIS. This program is made available under the terms of
 * the MIT License.
 */
package org.easymock.internal;

import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import junit.framework.AssertionFailedError;

import org.easymock.ArgumentsMatcher;

public class ResultListMap {

    private Map resultListMap = new TreeMap();

    private ArgumentsMatcher matcher;
    private Method method;

    public ResultListMap(Method method, ArgumentsMatcher matcher) {
        this.method = method;
        this.matcher = matcher;
    }

    public void addExpected(Arguments expected, Result result, Range count) {
        MatchableArguments matchable = new MatchableArguments(expected, matcher);

        if (!resultListMap.containsKey(matchable)) {
            resultListMap.put(matchable, new ResultList());
        }

        ResultList list = (ResultList) resultListMap.get(matchable);
        list.add(result, count);
    }

    public Result addActual(Arguments actual) {
        boolean matched = false;
        MatchableArguments arguments = new MatchableArguments(actual, matcher);
        ResultList list = (ResultList) resultListMap.get(arguments);

        if (list != null) {
            matched = true;
            Result result = list.next();
            if (result != null) {
                return result;
            }
        }

        throw new AssertionFailedError(createFailureMessage(arguments, matched));
    }

    private String createFailureMessage(MatchableArguments actual,
            boolean matched) {
        StringBuffer result = new StringBuffer();

        if (!matched) {
            result.append("\n    ");
            result.append(new MethodCall(method, actual.getArguments())
                    .toString(matcher));
            result.append(": ");
            result.append(new Range(7).expectedAndActual(1).replace('7', '0'));
        }

        for (Iterator it = resultListMap.keySet().iterator(); it.hasNext(); ) {
            MatchableArguments expected = (MatchableArguments) it.next();
            ResultList list = (ResultList) resultListMap.get(expected);

            if (list.hasValidCallCount() && !expected.equals(actual)) {
                continue;
            }
            
            int count = list.getCallCount()
                    + ((expected.equals(actual)) ? 1 : 0);
            result.append("\n    ");
            result.append(new MethodCall(method, expected.getArguments())
                    .toString(matcher));
            result.append(": ");
            result.append(list.getMessage(count));
        }

        return result.toString();
    }

    public void verify() {
        String failureMessage = "";
        boolean verifyFailed = false;

        for (Iterator it = resultListMap.keySet().iterator(); it.hasNext(); ) {
            MatchableArguments expected = (MatchableArguments) it.next();
            ResultList list = (ResultList) resultListMap.get(expected);

            if (list.hasValidCallCount()) {
                continue;
            }
            verifyFailed = true;
            failureMessage += "\n    "
                    + new MethodCall(method, expected.getArguments())
                            .toString(matcher) + ": "
                    + list.getMessage();
        }
        if (verifyFailed) {
            throw new AssertionFailedError(failureMessage);
        }
    }
}