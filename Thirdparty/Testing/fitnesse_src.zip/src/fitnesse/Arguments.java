// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

public class Arguments
{
	public static final String DEFAULT_PORT = "80";
	public static final String DEFAULT_DIRECTORY = ".";
	public static final String DEFAULT_ROOT_DIR = "FitNesseRoot";
	public static final String DEFAULT_LOG_DIR = null;
	public static final String DEFAULT_DAYS_TILL_VERSIONS_EXPIRE = "14";

	private String rootPath;
	private int port;
	private String rootDirectory;
	private String logDirectory;
	private boolean omitUpdate = false;
	private int daysTillVersionsExpire;

	public String getRootPath()
	{
		return rootPath;
	}

	public void setRootPath(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public int getPort()
	{
		return port;
	}

	public void setPort(String port)
	{
		this.port = Integer.parseInt(port);
	}

	public String getRootDirectory()
	{
		return rootDirectory;
	}

	public void setRootDirectory(String rootDirectory)
	{
		this.rootDirectory = rootDirectory;
	}

	public String getLogDirectory()
	{
		return logDirectory;
	}

	public void setLogDirectory(String logDirectory)
	{
		this.logDirectory = logDirectory;
	}

	public void setOmitUpdates(boolean omitUpdates)
	{
		this.omitUpdate = omitUpdates;
	}

	public boolean isOmittingUpdates()
	{
		return omitUpdate;
	}

	public int getDaysTillVersionsExpire()
	{
		return daysTillVersionsExpire;
	}

	public void setDaysTillVersionsExpire(String daysTillVersionsExpire)
	{
		this.daysTillVersionsExpire = Integer.parseInt(daysTillVersionsExpire);
	}

}
