// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import fitnesse.http.*;
import fitnesse.responders.*;
import fitnesse.components.*;
import java.net.*;
import java.io.*;
import java.util.GregorianCalendar;

public class FitnesseExpediter implements ResponseSender
{
	private Socket socket;
	private InputStream input;
	private OutputStream output;
	private HttpRequest request;
	private Response response;
	private FitNesseContext context;
	protected long requestTimeout;

	public FitnesseExpediter(Socket s, FitNesseContext context) throws Exception
	{
		this.context = context;
		socket = s;
		input = s.getInputStream();
		output = s.getOutputStream();
		requestTimeout = 60000;
	}

	public void start() throws Exception
	{
		try
		{
			HttpRequest request = makeRequest();
			Response response = makeResponse(request);
			sendResponse(response);
		}
		catch(SocketException se)
		{
			// can be thrown by makeResponse or sendResponse.
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	public void setRequestTimeout(long t)
	{
		requestTimeout = t;
	}

	public long getRequestTimeout()
	{
		return requestTimeout;
	}

	public void send(byte[] bytes) throws Exception
	{
		try
		{
			output.write(bytes);
			output.flush();
		}
		catch(IOException ioe)
		{}
	}

	public void close() throws Exception
	{
		try
		{
			log(socket, request, response);
			socket.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	public Socket getSocket() throws Exception
	{
		return socket;
	}

	public HttpRequest makeRequest() throws Exception
	{
		request = new HttpRequest(input);
		return request;
	}

	public void sendResponse(Response response) throws Exception
	{
		this.response = response;
		response.readyToSend(this);
	}

	private Response makeResponse(HttpRequest request) throws Exception
	{
		Response response = null;

		try
		{
			Thread parseThread = createParsingThread(request);
			parseThread.start();

			boolean badRequest = isRequestBad(request);
			if(badRequest)
			{
				parseThread.interrupt();
				response = createErrorResponse();
			}
			else
			{
				response = createGoodResponse(request);
			}
		}
		catch(SocketException se)
		{
			throw(se);
		}
		catch(Exception e)
		{
			response = new ErrorResponder(e).makeResponse(context, request);
		}
		return response;
	}

	private Response createGoodResponse(HttpRequest request) throws Exception
	{
		Response response;
		Responder responder = context.responderFactory.makeResponder(request, context.root);
		response = responder.makeResponse(context, request);
		response.addHeader("Server", "FitNesse-" + Fitnesse.VERSION);
		response.addHeader("Connection", "close");
		return response;
	}

	private Response createErrorResponse()
	{
		Response response;
		SimpleResponse errorResponse = new SimpleResponse();
		errorResponse.setContent("");
		errorResponse.setStatus(400);
		response = errorResponse;
		return response;
	}

	private boolean isRequestBad(HttpRequest request) throws InterruptedException
	{
		boolean badRequest = false;
		long start = System.currentTimeMillis();
		long now = start;
		while(!request.hasBeenParsed() && !badRequest)
		{
			Thread.sleep(10);
			now = System.currentTimeMillis();
			if(now - start > requestTimeout)
				badRequest = true;
		}
		return badRequest;
	}

	private Thread createParsingThread(final HttpRequest request)
	{
		Thread parseThread = new Thread()
		{
			public synchronized void run()
			{
				try {
					request.parse();
				} catch(Exception e) {
				}
			}
		};
		return parseThread;
	}

	public static LogData makeLogData(Socket socket, HttpRequest request, Response response)
	{
		LogData data = new LogData();
		data.host = ((InetSocketAddress) socket.getRemoteSocketAddress()).getAddress().getHostAddress();
		data.time = new GregorianCalendar();
		data.requestLine = request.getRequestLine();
		data.status = response.getStatus();
		data.size = response.getContentSize();

		return data;
	}

	public void log(Socket s, HttpRequest request, Response response) throws Exception
	{
		if(context.logger != null)
			context.logger.log(makeLogData(s, request, response));
	}
}
