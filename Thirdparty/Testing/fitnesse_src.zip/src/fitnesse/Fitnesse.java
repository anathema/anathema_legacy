// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import fitnesse.socketservice.SocketService;
import fitnesse.wiki.*;
import fitnesse.responders.ResponderFactory;
import fitnesse.components.Logger;
import fitnesse.updates.Updater;
import fitnesse.schedule.*;
import com.neoworks.util.Getopts;

import java.net.BindException;
import java.io.File;

public class Fitnesse
{
	public static final String VERSION = "20040119";
	public static int daysTillVersionsExpire = 14; //TODO yucky global variable.  Perhaps setting this in the root page would be better.

	public FitNesseContext context = new FitNesseContext();
	private SocketService theService;

	public static void main(String[] args) throws Exception
	{
		Arguments arguments = parseCommandLine(args);
		if(arguments != null)
		{
			FitNesseContext context = new FitNesseContext();
			context.port = arguments.getPort();
			context.root = FileSystemPage.makeRoot(arguments.getRootPath(), arguments.getRootDirectory());
			context.rootPath = arguments.getRootPath() + "/" + arguments.getRootDirectory();
			context.logger = makeLogger(arguments);
			context.schedule = makeSchedule(context.root);
			daysTillVersionsExpire = arguments. getDaysTillVersionsExpire();
			Fitnesse fitnesse = new Fitnesse(context);
			if(!arguments.isOmittingUpdates())
				fitnesse.applyUpdates();
			boolean started = fitnesse.start();
			if(started)
				printStartMessage(arguments);
		}
		else
		{
			printUsage();
			System.exit(1);
		}
	}

	public static Arguments parseCommandLine(String[] args)
	{
		Arguments arguments = null;
		Getopts opts = new Getopts("p:d:r:l:e:o", args);

		if(opts.error() == false)
		{
			arguments = new Arguments();
			arguments.setPort(opts.option('p', Arguments.DEFAULT_PORT));
			arguments.setRootPath(opts.option('d', Arguments.DEFAULT_DIRECTORY));
			arguments.setRootDirectory(opts.option('r', Arguments.DEFAULT_ROOT_DIR));
			arguments.setLogDirectory(opts.option('l', Arguments.DEFAULT_LOG_DIR));
			arguments.setDaysTillVersionsExpire(opts.option('e', Arguments.DEFAULT_DAYS_TILL_VERSIONS_EXPIRE));
			arguments.setOmitUpdates(opts.hasOption('o'));
		}
		return arguments;
	}

	private static Logger makeLogger(Arguments arguments)
	{
		String logDirectory = arguments.getLogDirectory();
		return logDirectory != null ? new Logger(logDirectory) : null;
	}

	public static Schedule makeSchedule(WikiPage root) throws Exception
	{
		Schedule schedule = new ScheduleImpl(5000);
		return schedule;
	}

	private static void printUsage()
	{
		System.err.println("Usage: java fitnesse.Fitnesse [-pdrlo]");
		System.err.println("\t-p <port number> {" + Arguments.DEFAULT_PORT + "}");
		System.err.println("\t-d <working directory> {" + Arguments.DEFAULT_DIRECTORY + "}");
		System.err.println("\t-r <page root directory> {" + Arguments.DEFAULT_ROOT_DIR + "}");
		System.err.println("\t-l <log directory> {no logging}");
		System.err.println("\t-e <days> {" + Arguments.DEFAULT_DAYS_TILL_VERSIONS_EXPIRE + "} Number of days before page versions expire");
		System.err.println("\t-o omit updates");
	}

	private static void printStartMessage(Arguments args)
	{
		System.out.println("Fitnesse (" + VERSION + ") Started...");
		System.out.println("\ton port      " + args.getPort());
		System.out.println("\tusing path   '" + args.getRootPath() + "'");
		System.out.println("\tusing dir    '" + args.getRootDirectory() + "'");
		System.out.println("\tpage version expiration set to " + args.getDaysTillVersionsExpire() + " days.");
		if(args.getLogDirectory() == null)
			System.out.println("\tNot logging.");
		else
			System.out.println("\tlogging dir  '" + args.getLogDirectory() + "'");
	}

	private static void printBadPortMessage(int port)
	{
		System.err.println("FitNesse cannot be started...");
		System.err.println("Port " + port + " is already in use.");
		System.err.println("Use the -p <port#> command line argument to use a different port.");
	}

	private static void establishDirectory(String path)
	{
		File filesDir = new File(path);
		if(!filesDir.exists())
			filesDir.mkdir();
	}

	public Fitnesse(FitNesseContext context) throws Exception
	{
		this.context = context;
		prepare();
	}

	public boolean start()
	{
		try
		{
			context.responderFactory = new ResponderFactory(context.rootPath);
			theService = new SocketService(context.port, new FitnesseServer(context));
			context.schedule.start();
			return true;
		}
		catch(BindException e)
		{
			printBadPortMessage(context.port);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	public void prepare() throws Exception
	{
		establishDirectory(context.rootPath);
		establishDirectory(context.rootPath + "/files");
	}

	public void applyUpdates() throws Exception
	{
		Updater updater = new Updater(context.root);
		updater.update();
	}

	public void stop() throws Exception
	{
		if(theService != null)
			theService.close();
		context.schedule.stop();
	}
}
