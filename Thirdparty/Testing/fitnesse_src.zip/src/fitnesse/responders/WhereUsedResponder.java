// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.components.WhereUsed;
import fitnesse.wiki.*;
import fitnesse.http.HttpRequest;

public class WhereUsedResponder extends ResultResponder
{
	protected String getPageFooterInfo(int hits) throws Exception
	{
		return "<a href=" + new PageCrawler().getQualifiedName(page) + ">" + page.getName() + "</a> is used in " + hits + " page(s).";
	}

	protected void startSearching() throws Exception
	{
		new WhereUsed(root).searchForReferencingPages(page, this);
	}

	protected String getHtmlTitle() throws Exception
	{
		return getTitle();
	}

	protected String getTitle() throws Exception
	{
		return "Where Used Results for '" + request.getResource() + "'";
	}

}
