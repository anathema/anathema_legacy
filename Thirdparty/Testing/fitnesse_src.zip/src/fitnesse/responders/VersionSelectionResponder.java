// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.responders.html.*;

import java.util.*;
import java.text.ParsePosition;

public class VersionSelectionResponder implements Responder
{
	private WikiPage page;
	private List versions;
	private List ageStrings;
	private PageData pageData;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		String resource = request.getResource();
		page = new PageCrawler().getPage(context.root, resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);

		pageData = page.getData();
		versions = getVersionsList(pageData);
		ageStrings = new ArrayList();
		Calendar now = new GregorianCalendar();
		for(Iterator iterator = versions.iterator(); iterator.hasNext();)
		{
			String name = (String) iterator.next();
			Calendar calendar = convertToDate(name);
			ageStrings.add(howLongAgoString(now, calendar));
		}

		response.setContent(html());

		return response;
	}

	public String html() throws Exception
	{
		HtmlPage html = new HtmlPage();
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(new PageCrawler().getQualifiedName(page))));
		table.addRow(new TableRow("", makeRightColumn()));
		html.addElement(table);
		return html.html();
	}

	public String makeRightColumn() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<h3>Select a version.</h3>");
		buffer.append("<form action=\"" + new PageCrawler().getQualifiedName(page) + "\" method=\"get\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"viewVersion\">");
		buffer.append("<select name=\"version\">");
		buffer.append("<option value=\"default\"> - Select a Version -");

		for(int i = 0; i < versions.size(); i++)
			buffer.append(makeOptionTag(i));

		buffer.append("</select>");
		buffer.append("<br><br>");
		buffer.append("<input type=\"submit\" value=\"View Version\">");
		buffer.append("</form>");

		return buffer.toString();
	}

	private String makeOptionTag(int i)
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("\t<option value=\"").append(versions.get(i)).append("\"> ");
		buffer.append(versions.get(i)).append(" - ").append(ageStrings.get(i)).append(" ago");
		return buffer.toString();
	}

	public static List getVersionsList(PageData data)
	{
		List list = new ArrayList(data.getVersionNames());
		Collections.sort(list);
		Collections.reverse(list);
		return list;
	}

	public static String howLongAgoString(Calendar now, Calendar then)
	{
		long time = Math.abs(now.getTime().getTime() - then.getTime().getTime()) / 1000;

		if(time < 60)
			return pluralize(time, "second");
		else if(time < 3600)
			return pluralize(time / 60, "minute");
		else if(time < 86400)
			return pluralize(time / (3600), "hour");
		else if(time < 31536000)
			return pluralize(time / (86400), "day");
		else
			return pluralize(time / (31536000), "year");
	}

	private static String pluralize(long time, String unit)
	{
		String age = time + " " + unit;
		if(time > 1)
			age = age + "s";

		return age;
	}

	public static Calendar convertToDate(String versionName)
	{
		Date date = RawPage.versionNameFormat.parse(versionName, new ParsePosition(0));
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(date);
		return calendar;
	}

}
