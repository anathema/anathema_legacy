// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.*;
import fitnesse.responders.html.*;

public class SearchFormResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		response.setContent(html());

		return response;
	}

	private String html() throws Exception
	{
		HtmlPage page = new HtmlPage();
      Table table = new Table();
		table.addRow(TableRow.titleRow("Search Form"));
		table.addRow(new TableRow("", makeRightColumn()));
		page.addElement(table);

		return page.html();
	}

	private String makeRightColumn()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action=\"search\" method=\"post\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"search\">");
		buffer.append("Search regex: <input type=\"text\" name=\"searchString\">");
		buffer.append("<br>");
		buffer.append("<input type=\"submit\" value=\"Search!\">");
		buffer.append("</form>");
		return buffer.toString();
	}

}
