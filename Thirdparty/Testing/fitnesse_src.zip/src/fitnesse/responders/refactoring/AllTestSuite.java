// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(DeletePageResponderTest.class));
		suite.addTest(new TestSuite(RenamePageResponderTest.class));
		suite.addTest(new TestSuite(RefactorPageResponderTest.class));
		suite.addTest(new TestSuite(MovePageResponderTest.class));
		return suite;
	}
}
