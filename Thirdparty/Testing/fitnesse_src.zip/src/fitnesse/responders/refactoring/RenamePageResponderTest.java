// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.*;
import fitnesse.responders.refactoring.RenamePageResponder;
import fitnesse.responders.ResponderTest;
import fitnesse.wiki.*;
import fitnesse.http.*;
import java.io.File;

public class RenamePageResponderTest extends ResponderTest
{
	protected Responder responderInstance()
	{
		return new RenamePageResponder();
	}

	public void testDontRenameFrontPage() throws Exception
	{
		root.addPage("FrontPage", "Content");
		Response response = sendRenameResponse("FrontPage", "ReNamed");
		assertNotNull(response);
		assertEquals(303, response.getStatus());
		assertEquals("FrontPage", response.getHeader("Location"));
	}

	public void testPageRedirection() throws Exception
	{
		root.addPage("OneOne", "Content").addPage("TwoOne");
		Response response = sendRenameResponse("OneOne.TwoOne", "Renamed");
		assertNotNull(response);
		assertEquals(303, response.getStatus());
		assertEquals("OneOne.TwoOne", response.getHeader("Location"));

		response = sendRenameResponse("OneOne.TwoOne", "ReNamed");
		assertEquals("OneOne.ReNamed", response.getHeader("Location"));
	}

	public void testPageWasRenamed() throws Exception
	{
		root.addPage("OneOne", "Content");
		File pageOneOne = new File(fitnesseRoot + "/OneOne");
		File pageWonWon = new File(fitnesseRoot + "/WonWon");
		assertTrue(pageOneOne.exists());
		assertFalse(pageWonWon.exists());

		sendRenameResponse("OneOne", "WonWon");

		assertTrue(pageWonWon.exists());
		assertFalse(pageOneOne.exists());
	}

	public void testReferencesChanged() throws Exception
	{
		root.addPage("PageOne", "Line one\nPageTwo\nLine three");
		root.addPage("PageTwo", "Page two content");

		sendRenameResponse("PageTwo", "PageThree");
		assertNotNull(root.getChildPage("PageThree"));
		WikiPage pageOne = root.getChildPage("PageOne");
		assertEquals("Line one\nPageThree\nLine three", pageOne.getData().getContent());
	}

	public void testDontRenameToExistingPage() throws Exception
	{
		root.addPage("PageOne", "Page one content");
		root.addPage("PageTwo", "Page two content");
		File pageOne = new File(fitnesseRoot + "/PageOne");
		File pageTwo = new File(fitnesseRoot + "/PageTwo");

		Response response = sendRenameResponse("PageOne", "PageTwo");
		assertTrue(pageOne.exists());
		assertTrue(pageTwo.exists());
		assertEquals("Page two content", root.getChildPage("PageTwo").getData().getContent());
		assertEquals("PageOne", response.getHeader("Location"));
	}

	private Response sendRenameResponse(String fromName, String toName) throws Exception
	{
		request.setResource(fromName);
		request.addInput("newName", toName);
		return responder.makeResponse(new FitNesseContext(root), request);
	}
}