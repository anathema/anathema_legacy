// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.http.*;

public class RefactorPageResponder implements Responder
{
	private String qualifiedName;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		qualifiedName = request.getResource();
		SimpleResponse response = new SimpleResponse();
		response.setContent(html());
		return response;
	}

	public String html() throws Exception
	{
		HtmlPage html = new HtmlPage();
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(qualifiedName)));
		table.addRow(new TableRow("", mainContent()));
		html.addElement(table);
		return html.html();
	}

	private String mainContent()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<h1>Refactor</h1>");
        buffer.append(deletePageForm());
        buffer.append("<hr>");
        buffer.append(renamePageForm());
        buffer.append("<hr>");
        //buffer.append(movePageForm());
		return buffer.toString();
	}

    private String deletePageForm()
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append("<hr><h3>Delete this page:</h3>");
        buffer.append("<form action=\"" + qualifiedName + "\">");
        buffer.append("  <input type=\"submit\" value=\"Delete Page\">");
        buffer.append("  <input type=\"hidden\" name=\"responder\" value=\"deletePage\">");
        buffer.append("</form>");
        return buffer.toString();
    }

    private String movePageForm()
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append("<h3>Move this page.</h3>");
        buffer.append("Moving this page will find all references and change them accordingly.");
        buffer.append("<form action=\"" + qualifiedName + "\">");
        buffer.append("  <input type=\"hidden\" name=\"responder\" value=\"movePage\">");
        buffer.append("  New Location: <input type=\"text\" name=\"newLocation\">");
        buffer.append("  <br><input type=\"submit\" value=\"Move Page\">");
        buffer.append("</form>");
        return buffer.toString();
    }

    private String renamePageForm() {
        StringBuffer buffer = new StringBuffer();
        buffer.append("<h3>Rename this page.</h3>");
        buffer.append("Renaming this page will find all references and change them accordingly.");
        buffer.append("<form action=\"" + qualifiedName + "\">");
        buffer.append("  <input type=\"hidden\" name=\"responder\" value=\"renamePage\">");
        buffer.append("  New Name: <input type=\"text\" name=\"newName\">");
        buffer.append("  <br><input type=\"submit\" value=\"Rename Page\">");
        buffer.append("</form>");
        return buffer.toString();
    }

}
