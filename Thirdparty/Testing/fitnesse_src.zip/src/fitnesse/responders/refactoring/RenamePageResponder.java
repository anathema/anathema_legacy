// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.*;
import fitnesse.responders.NotFoundResponder;
import fitnesse.components.PageReferenceRenamer;
import fitnesse.wikitext.widgets.WikiWordWidget;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class RenamePageResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		String qualifiedName = request.getResource();

		String newName = (String) request.getInput("newName");
		if(newName != null && !qualifiedName.equals("FrontPage") && WikiWordWidget.isWikiWord(newName))
		{
			PageCrawler pageCrawler = new PageCrawler();
			
			WikiPage subjectPage = pageCrawler.getPage(context.root, qualifiedName);
			if(subjectPage == null)
				return new NotFoundResponder().makeResponse(context, request);
			WikiPage parent = subjectPage.getParent();
			final boolean pageExists = pageCrawler.pageExists(parent, newName);
			if(!pageExists)
			{
				PageReferenceRenamer renamer = new PageReferenceRenamer(context.root);
				renamer.renameReferences(subjectPage, newName);

				parent.renamePage(subjectPage.getName(), newName);
				subjectPage = pageCrawler.getPage(parent, newName);
				qualifiedName = pageCrawler.getQualifiedName(subjectPage);
			}
		}

		SimpleResponse response = new SimpleResponse();
		response.redirect(qualifiedName);
		return response;
	}

}
