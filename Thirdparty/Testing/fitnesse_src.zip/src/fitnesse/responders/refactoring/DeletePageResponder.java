// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.responders.NotFoundResponder;
import fitnesse.http.*;
import fitnesse.wiki.*;
import java.util.List;

public class DeletePageResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		String qualifiedPageName = request.getResource();

		if(qualifiedPageName.equals("FrontPage"))
			response.redirect("FrontPage");
		else
		{
			String confirmedString = (String)request.getInput("confirmed");
			if("yes".equals(confirmedString))
			{
				WikiPage pageToBeDeleted = new PageCrawler().getPage(context.root, qualifiedPageName);
				if(pageToBeDeleted == null)
					return new NotFoundResponder().makeResponse(context, request);
				pageToBeDeleted.getParent().removePage(pageToBeDeleted.getName());
				redirectToParent(response, qualifiedPageName);
			}
			else
				response.setContent(buildConfirmationHtml(context.root, qualifiedPageName));
		}

		return response;
	}

	private String buildConfirmationHtml(WikiPage root, String qualifiedPageName) throws Exception
	{
		HtmlPage html = new HtmlPage();
		Table table = new Table();
		table.addRow(TableRow.titleRow("Delete Confirmation"));
		table.addRow(new TableRow("", makeMainContent(root, qualifiedPageName)));
		html.addElement(table);
		return html.html();
	}

	private String makeMainContent(WikiPage root, String qualifiedPageName) throws Exception
	{
		WikiPage pageToDelete = new PageCrawler().getPage(root, qualifiedPageName);
		List children = pageToDelete.getChildren();
		boolean addSubPageWarning = true;
		if(children == null || children.size() == 0)
			addSubPageWarning = false;

		StringBuffer buffer = new StringBuffer();
		buffer.append("<center>");
		buffer.append("<font size =\"4\">");
		if(addSubPageWarning)
			buffer.append("Warning, this page contains one or more subpages.<br>");
		buffer.append("Are you sure you want to delete " + qualifiedPageName + "?");
		buffer.append("</font><br>");
		buffer.append("<a href=\"" + qualifiedPageName + "?responder=deletePage&confirmed=yes\">Yes</a> ");
		buffer.append("&nbsp;&nbsp;&nbsp;&nbsp;");
		buffer.append("<a href=\"" + qualifiedPageName + "\">No</a>");
		buffer.append("</center>");
		return buffer.toString();
	}

	private void redirectToParent(SimpleResponse response, String qualifiedPageName)
	{
		String parentName = "";
		int dotIndex = qualifiedPageName.lastIndexOf(".");
		if(dotIndex > -1)
			parentName = qualifiedPageName.substring(0, dotIndex);
		response.redirect(parentName);
	}

}
