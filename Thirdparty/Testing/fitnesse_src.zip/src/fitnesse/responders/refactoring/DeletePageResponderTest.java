// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;
import fitnesse.responders.refactoring.DeletePageResponder;
import fitnesse.responders.ResponderTest;
import java.io.File;
import java.util.List;

public class DeletePageResponderTest extends ResponderTest
{
	final String level1Name = "LevelOne";
	final String level2Name = "LevelTwo";
	final String qualifiedLevel2Name = level1Name + "." + level2Name;

	public void testDeleteConfirmation() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot(fitnesseRoot);
		root.addPage(level1Name).addPage(level2Name);
		MockHttpRequest request = new MockHttpRequest();
		request.setResource(qualifiedLevel2Name);
		request.addInput("deletePage", "");

		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String content = response.getContent();
		assertSubString("Are you sure you want to delete " + qualifiedLevel2Name, content);
	}

	public void testDeletePage() throws Exception
	{
		root.addPage(level1Name).addPage(level2Name);
		File childOne = new File(fitnesseRoot + "/" + level1Name);
		assertTrue(childOne.exists());
		MockHttpRequest request = new MockHttpRequest();
		request.setResource(level1Name);
		request.addInput("confirmed", "yes");

		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String page = response.getContent();
		assertNotSubString("Are you sure you want to delete", page);
		assertEquals(303, response.getStatus());
		assertEquals("", response.getHeader("Location"));
		assertFalse(childOne.exists());

		List children = root.getChildren();
		assertEquals(0, children.size());
	}

	public void testDontDeleteFrontPage() throws Exception
	{
		root.addPage("FrontPage", "Content");
		request.setResource("FrontPage");
		request.addInput("confirmed", "yes");
		Response response = responder.makeResponse(new FitNesseContext(root), request);
		assertEquals(303, response.getStatus());
		assertEquals("FrontPage", response.getHeader("Location"));
	}

	protected Responder responderInstance()
	{
		return new DeletePageResponder();
	}
}