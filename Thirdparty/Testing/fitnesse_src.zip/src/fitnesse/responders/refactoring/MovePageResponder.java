// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.*;
import fitnesse.responders.NotFoundResponder;
import fitnesse.components.*;
import fitnesse.wiki.*;
import fitnesse.http.Response;
import fitnesse.http.HttpRequest;
import fitnesse.http.SimpleResponse;
import java.util.*;

public class MovePageResponder implements Responder
{
	private String oldName;
	private String newParentName;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		PageCrawler pageCrawler = new PageCrawler();

		oldName = request.getResource();
		newParentName = (String) request.getInput("newLocation");
		if(".".equals(newParentName))
			newParentName = "";
		WikiPage oldWikiPage = pageCrawler.getPage(context.root, oldName);
		if(oldWikiPage == null)
			return new NotFoundResponder().makeResponse(context, request);
		WikiPage newParent = pageCrawler.getPage(context.root, newParentName);

		if(!selfPage(oldWikiPage, newParent) && newParentPageExists(oldWikiPage.getName(), newParent))
		{
			MovedPageReferenceRenamer renamer = new MovedPageReferenceRenamer(context.root);
			renamer.renameReferences(oldWikiPage, newParentName);

			movePage(newParent, oldWikiPage);
			response.redirect(createRedirectionUrl(newParent, oldWikiPage));
			return response;
		}
		else
		{
			throw new Exception("Can not move page to destination");
		}
	}

	String createRedirectionUrl(WikiPage newParent, WikiPage oldWikiPage) throws Exception
	{
		if(newParent.isRoot())
			return oldWikiPage.getName();
		else
			return new PageCrawler().getQualifiedName(newParent) + "." + oldWikiPage.getName();
	}

	private boolean selfPage(WikiPage oldWikiPage, WikiPage newParent) throws Exception
	{
		return new PageCrawler().getQualifiedName(oldWikiPage.getParent()).equals(new PageCrawler().getQualifiedName(newParent));
	}

	private void movePage(WikiPage newParent, WikiPage oldWikiPage) throws Exception
	{
		WikiPage movedPage = newParent.addPage(oldWikiPage.getName(), oldWikiPage.getData().getContent());
		PageData movedData = movedPage.getData();
		PageData oldData = oldWikiPage.getData();
		movedData.setAttributes(oldData.getAttributes());
		movedData.setLastModificationTime(oldData.getLastModificationTime());
		List children = oldWikiPage.getChildren();
		if(children.size() > 0)
			moveChildren(movedPage, children);
		movedPage.commit(movedData);
		oldWikiPage.getParent().removePage(oldWikiPage.getName());
	}

	private boolean newParentPageExists(String oldWikiPageName, WikiPage newParent) throws Exception
	{
		List children = newParent.getChildren();
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage page = (WikiPage) iterator.next();
			if(oldWikiPageName.equals(page.getName()))
				return false;
		}
		return true;
	}

	private void moveChildren(WikiPage newParent, List children) throws Exception
	{
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage page = (WikiPage) iterator.next();
			List newChildren = page.getChildren();
			if(newChildren.size() > 0)
				moveChildren(page, newChildren);
			else
				movePage(newParent, page);
		}
	}

}
