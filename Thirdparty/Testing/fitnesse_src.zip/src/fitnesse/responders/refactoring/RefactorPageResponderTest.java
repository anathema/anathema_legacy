// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;
import fitnesse.responders.refactoring.RefactorPageResponder;

public class RefactorPageResponderTest extends RegexTest
{
	WikiPage root;
	private MockHttpRequest request;
	private Responder responder;
	private String childPage = "ChildPage";

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("root");
		root.addPage(childPage);

		request = new MockHttpRequest();
		request.setResource(childPage);
		responder = new RefactorPageResponder();
	}

	public void testHtml() throws Exception
	{
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertEquals(200, response.getStatus());

		String content = response.getContent();
		assertSubString("Delete Page", content);
		assertSubString("Rename Page", content);
//		assertSubString("Move Page", content);
	}
}
