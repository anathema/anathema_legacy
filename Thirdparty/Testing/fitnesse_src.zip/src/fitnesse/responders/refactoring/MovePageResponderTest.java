// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.refactoring;

import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.responders.refactoring.MovePageResponder;
import fitnesse.responders.ResponderTest;
import java.io.File;
import java.util.List;

public class MovePageResponderTest extends ResponderTest
{
	private WikiPage pageOne;
	private WikiPage pageA;
	private WikiPage pageTwo;

	protected Responder responderInstance()
	{
		return new MovePageResponder();
	}

	public void setUp() throws Exception
	{
		super.setUp();
		pageOne = root.addPage("PageOne", "^PageA");
		pageA = pageOne.addPage("PageA", "content");
		pageTwo = root.addPage("PageTwo");
	}

	// TODO cuz it always fails
	public void _testMovePage() throws Exception
	{
		pageA.getData().setAttribute("someAttribute", "someValue");
		File pageOneA = new File(fitnesseRoot + "/PageOne/PageA");
		File pageTwoPageA = new File(fitnesseRoot + "/PageTwo/PageA");
		assertTrue(pageOneA.exists());
		assertFalse(pageTwoPageA.exists());

		movePage("PageOne.PageA", "PageTwo");
		assertTrue(pageTwoPageA.exists());
		assertFalse(pageOneA.exists());

		WikiPage movedPage = new PageCrawler().getPage(root, "PageTwo.PageA");
		PageData data = movedPage.getData();
		assertEquals("content", data.getContent());
		assertEquals("someValue", data.getAttribute("someAttribute"));
	}

	private void movePage(String pageToMove, String newParent) throws Exception
	{
		request.addInput("newLocation", newParent);
		request.setResource(pageToMove);
		responder.makeResponse(new FitNesseContext(root), request);
	}

	public void testReferencesChanged() throws Exception
	{
		movePage("PageOne.PageA", "PageTwo");
		pageOne = root.getChildPage("PageOne");
		assertEquals(".PageTwo.PageA", pageOne.getData().getContent());
	}

	public void testCantMoveToSelf() throws Exception
	{
		pageA.getData().setAttribute("someAttribute", "someValue");
		File pageOneA = setUpPage("/PageOne/PageA");
		testException("PageOne.PageA", "PageOne");
		assertTrue(pageOneA.exists());
	}

	public void testCantReplaceExistingPage() throws Exception
	{
		pageTwo.addPage("PageA", "someContent");
		pageA.getData().setAttribute("someAttribute", "someValue");
		File pageOnePageA = new File(fitnesseRoot + "/PageOne/PageA");
		File pageTwoPageA = new File(fitnesseRoot + "/PageTwo/PageA");
		assertTrue(pageTwoPageA.exists());
		assertTrue(pageOnePageA.exists());

		testException("PageOne.PageA", "PageTwo");
		assertEquals("someContent", pageTwo.getChildPage("PageA").getData().getContent());
		assertEquals("content", pageA.getData().getContent());
		assertTrue(pageTwoPageA.exists());
		assertTrue(pageOnePageA.exists());
	}

	public void testChildrenGetMovedIfParentMoves() throws Exception
	{
		pageA.addPage("ChildOne", "child1Content");
		pageA.addPage("ChildTwo", "child2Content");
		File pageAChild1 = new File(fitnesseRoot + "/PageOne/PageA/ChildOne");
		File pageAChild2 = new File(fitnesseRoot + "/PageOne/PageA/ChildTwo");
		assertTrue(pageAChild1.exists());
		assertTrue(pageAChild2.exists());

		movePage("PageOne.PageA", "PageTwo");
		WikiPage movedPage = new PageCrawler().getPage(root, "PageTwo.PageA");
		assertFalse(pageAChild1.exists());
		assertFalse(pageAChild2.exists());
		List children = movedPage.getChildren();
		assertEquals(2, children.size());
	}

	public void testCantMovePageBelowChild() throws Exception
	{
		File pageOneA = setUpPage("/PageOne/PageA");
		testException("PageOne", "PageOne.PageA");
		assertTrue(pageOneA.exists());
	}

	public void testMoveToRoot() throws Exception
	{
		File pageOneA = setUpPage("/PageOne/PageA");
		movePage("PageOne.PageA", ".");
		WikiPage movedPage = root.getChildPage(pageA.getName());
		assertFalse(pageOneA.exists());
		assertEquals("content", movedPage.getData().getContent());
		assertEquals("PageA", new PageCrawler().getQualifiedName(movedPage));
		pageOne = root.getChildPage(pageOne.getName());
		assertEquals(".PageA", pageOne.getData().getContent());
	}

	public void testMoveFromRoot() throws Exception
	{
		File pageOne = setUpPage("/PageOne");
		movePage("PageOne", "PageTwo");
		WikiPage movedPagePage = pageTwo.getChildPage("PageOne");
		assertFalse(pageOne.exists());
		assertEquals(".PageTwo.PageOne", movedPagePage.getData().getContent());
		assertEquals("PageTwo.PageOne",new PageCrawler().getQualifiedName(movedPagePage));
	}

	public void testRedirection() throws Exception
	{
		String url = new MovePageResponder().createRedirectionUrl(pageOne, pageA);
		assertEquals("PageOne.PageA", url);

		url = new MovePageResponder().createRedirectionUrl(root, pageA);
		assertEquals("PageA", url);
	}

	public void testBadMoveLocationName() throws Exception
	{
		File pageOneA = setUpPage("/PageOne/PageA");
		testException("PageOne.PageA", "PageThree");
		assertTrue(pageOneA.exists());
	}

	private File setUpPage(String path)
	{
		File pageOneA = new File(fitnesseRoot + path);
		assertTrue(pageOneA.exists());
		return pageOneA;
	}

	private void testException(String pageToMove, String newParent)
	{
		try
		{
			movePage(pageToMove, newParent);
			fail();
		}
		catch(Exception e)
		{
		}
	}
}
