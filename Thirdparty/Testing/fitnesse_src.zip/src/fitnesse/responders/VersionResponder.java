// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.responders.html.*;
import fitnesse.*;

public class VersionResponder implements Responder
{
	private WikiPage page;
	private String version;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		String resource = request.getResource();
		version = (String) request.getInput("version");

		page = new PageCrawler().getPage(context.root, resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);
		PageData pageData = page.getData(version);

		HtmlPage html = new HtmlPage();
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(new PageCrawler().getQualifiedName(page)).html() + " version " + version));
		Button rollBackButton = new Button(new PageCrawler().getQualifiedName(page), "Rollback", "responder=rollback&version=" + version, "", false);
		String rightContent = new HtmlWikiPage(pageData).makeRightColumn();
		table.addRow(new TableRow(rollBackButton.html(), rightContent));
		html.addElement(table);

		SimpleResponse response = new SimpleResponse();
		response.setContent(html.html());

		return response;
	}

}
