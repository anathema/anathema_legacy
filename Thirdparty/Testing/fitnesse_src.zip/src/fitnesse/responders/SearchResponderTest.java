// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.testutil.*;
import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.FitNesseContext;
import junit.swingui.TestRunner;

public class SearchResponderTest extends RegexTest
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"SearchResponderTest"});
	}

	public void setUp() throws Exception
	{

		root = InMemoryPage.makeRoot("RooT");
		root.addPage("SomePage", "has something in it");
	}

	public void tearDown() throws Exception
	{
	}

	public void testHtml() throws Exception
	{
		String content = getResponseContentUsingSearchString("something");

		assertHasRegexp("something", content);
		assertHasRegexp("SomePage", content);
	}

	public void testEscapesSearchString() throws Exception
	{
		String content = getResponseContentUsingSearchString("%21%2B-%3C%26%3E");
		assertHasRegexp("!\\+-<&>", content);
	}

	private String getResponseContentUsingSearchString(String searchString) throws Exception
	{
		SearchResponder responder = new SearchResponder();
		MockHttpRequest request = new MockHttpRequest();
		request.addInput("searchString", searchString);

		Response response = responder.makeResponse(new FitNesseContext(root), request);
		Thread.sleep(500);  // make sure response waits for readyToSend() call
   	MockResponseSender sender = new MockResponseSender();
		response.readyToSend(sender);
		sender.waitForClose(5000);
		return sender.sentData();
	}
}
