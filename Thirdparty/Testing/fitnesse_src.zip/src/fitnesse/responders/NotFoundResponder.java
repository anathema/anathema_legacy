// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.widgets.WikiWordWidget;
import fitnesse.*;
import fitnesse.responders.html.*;

import java.util.regex.Pattern;

public class NotFoundResponder implements Responder
{
	private String resource;

	public NotFoundResponder()
	{
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse(404);
		resource = request.getResource();


		response.setContent(makeHtml());
		return response;
	}

	private String makeHtml() throws Exception
	{
		HtmlPage page = new HtmlPage();
		page.setHtmlTitle("Not Found - " + resource);
		Table table = new Table();
		table.addRow(TableRow.titleRow("Not Found<br>" + resource));
		table.addRow(new TableRow("", makeRightColumn(resource)));
		page.addElement(table);

		return page.html();
	}

	private String makeRightColumn(String name)
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("The requested resource: <i>" + name + "</i> was not found.");
		if(Pattern.matches(WikiWordWidget.REGEXP, name))
		{
			buffer.append("<ul>");
			buffer.append("<li>You could <a href=\"" + name + "?edit\">create this page!</a>");
			buffer.append("</ul>");
		}
		return buffer.toString();
	}

}
