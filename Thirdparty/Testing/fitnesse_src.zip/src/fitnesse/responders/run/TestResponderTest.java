// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.testutil.*;

public class TestResponderTest extends RegexTest
{
	private WikiPage root;
	private MockHttpRequest request;
	private TestResponder responder;
	private FitNesseContext context;
	private int port = 9123;
	private Response response;
	private MockResponseSender sender;
	private WikiPage testPage;
	private String results;
	private FitSocketReceiver receiver;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		request = new MockHttpRequest();
		responder = new TestResponder();
		context = new FitNesseContext(root);
		context.port = port;

		receiver = new FitSocketReceiver(port, context.socketDealer);
		receiver.receiveSocket();
	}

	public void tearDown() throws Exception
	{
		receiver.close();
	}

	public void testSimpleRun() throws Exception
	{
		doSimpleRun();

		assertSubString(testPage.getName(), results);
		assertSubString("Test Results", results);
		assertSubString("bgcolor", results);
		assertNotSubString("ClassNotFoundException", results);
	}

	private void doSimpleRun() throws Exception
	{
		testPage = root.addPage("TestPage", classpathWidgets() + "|!-fitnesse.testutil.PassFixture-!|\n");
		request.setResource(testPage.getName());

		response = responder.makeResponse(context, request);
		sender = new MockResponseSender(response);

		results = sender.sentData();
	}

	public void testFitSocketGetsClosed() throws Exception
	{
		doSimpleRun();
		assertTrue(receiver.socket.isClosed());
	}

	public void testStandardOutput() throws Exception
	{
		String content = classpathWidgets()
		  + outputWritingTable("output1")
		  + outputWritingTable("output2")
		  + outputWritingTable("output3");

		String errorLogContent = doRunAndGetErrorLog(content);

		assertHasRegexp("output1", errorLogContent);
		assertHasRegexp("output2", errorLogContent);
		assertHasRegexp("output3", errorLogContent);
	}

	public void testErrorOutput() throws Exception
	{
		String content = classpathWidgets()
		  + errorWritingTable("error1")
		  + errorWritingTable("error2")
		  + errorWritingTable("error3");

		String errorLogContent = doRunAndGetErrorLog(content);

		assertHasRegexp("error1", errorLogContent);
		assertHasRegexp("error2", errorLogContent);
		assertHasRegexp("error3", errorLogContent);
	}

	private String doRunAndGetErrorLog(String content) throws Exception
	{
		WikiPage testPage = root.addPage("TestPage", content);
		request.setResource(testPage.getName());

		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);
		String results = sender.sentData();

		assertHasRegexp("ErrorLog", results);

		WikiPage errorLog = testPage.getChildPage("ErrorLog");
		String errorLogContent = errorLog.getData().getContent();
		return errorLogContent;
	}

	public void testHasExitValueHeader() throws Exception
	{
		WikiPage testPage = root.addPage("TestPage", classpathWidgets() + "|!-fitnesse.testutil.PassFixture-!|\n");
		request.setResource(testPage.getName());

		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);
		String results = sender.sentData();

		assertSubString("Exit-Code: 0", results);
	}

	public void testFixtureThatCrashes() throws Exception
	{
		WikiPage testPage = root.addPage("TestPage", classpathWidgets() + "|!-fitnesse.testutil.CrashFixture-!|\n");
		request.setResource(testPage.getName());

		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);

		String results = sender.sentData();
		assertSubString("ErrorLog", results);
	}

	private String errorWritingTable(String message)
	{
		return "\n|!-fitnesse.testutil.ErrorWritingFixture-!|\n" +
		  "|" + message + "|\n\n";
	}

	private String outputWritingTable(String message)
	{
		return "\n|!-fitnesse.testutil.OutputWritingFixture-!|\n" +
		  "|" + message + "|\n\n";
	}

	private String classpathWidgets()
	{
		return "!path classes\n";
	}
}
