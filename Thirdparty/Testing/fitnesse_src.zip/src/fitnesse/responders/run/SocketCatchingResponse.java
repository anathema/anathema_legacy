// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.http.*;
import fitnesse.components.FitClient;
import java.net.Socket;

public class SocketCatchingResponse extends Response implements SocketDoner
{
	private int ticketNumber;
	private SocketDealer dealer;
	private Socket socket;
	private ResponseSender sender;

	public SocketCatchingResponse(int ticketNumber, SocketDealer dealer)
	{
		this.ticketNumber = ticketNumber;
		this.dealer = dealer;
	}

	//TODO this is a Liskov substitution violation
	public void readyToSend(ResponseSender sender) throws Exception
	{
		socket = sender.getSocket();
		this.sender = sender;
		if(dealer.isWaiting(ticketNumber))
		{
			FitClient.writeData("", socket.getOutputStream());
			dealer.dealSocketTo(ticketNumber, this);
		}
		else
		{
			String errorMessage = "There are no clients waiting for socket with ticketNumber " + ticketNumber;
			FitClient.writeData(errorMessage, socket.getOutputStream());
			setStatus(404);
			sender.close();
		}
	}

	protected void addSpecificHeaders()
	{
	}

	public int getContentSize()
	{
		return 0;
	}

	public Socket donateSocket()
	{
		return socket;
	}

	public void finishedWithSocket() throws Exception
	{
		sender.close();
	}
}
