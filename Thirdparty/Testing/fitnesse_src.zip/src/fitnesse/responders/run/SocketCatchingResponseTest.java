// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.http.*;
import fitnesse.testutil.*;

public class SocketCatchingResponseTest extends RegexTest
{
	private SocketDealer dealer;
	private SimpleSocketSeeker seeker;
	private MockResponseSender sender;

	public void setUp() throws Exception
	{
		dealer = new SocketDealer();
		seeker = new SimpleSocketSeeker();
		sender = new MockResponseSender();
	}

	public void tearDown() throws Exception
	{
	}

	public void testSuccess() throws Exception
	{
		int ticketNumber = dealer.seekingSocket(seeker);
		SocketCatchingResponse response = new SocketCatchingResponse(ticketNumber, dealer);
		response.readyToSend(sender);

		assertEquals("0000000000", sender.sentData());
	}

	public void testMissingSeeker() throws Exception
	{
		SocketCatchingResponse response = new SocketCatchingResponse(123, dealer);
		response.readyToSend(sender);

		assertHasRegexp("There are no clients waiting for socket with ticketNumber 123", sender.sentData());
		assertTrue(sender.closed);
		assertEquals(404, response.getStatus());
	}
}
