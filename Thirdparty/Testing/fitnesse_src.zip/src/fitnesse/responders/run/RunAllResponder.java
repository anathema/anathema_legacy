// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.components.*;
import fitnesse.responders.html.*;
import fitnesse.responders.run.CommandRunningResponder;
import fitnesse.FitNesseContext;

import java.util.*;
import java.io.*;

// TODO DELETE ME
public class RunAllResponder extends CommandRunningResponder
{
	private String testResultsPath;
	private List classPathElements;
	private HtmlWikiPage htmlWikiPage;
	public static final String SUITE_SETUP_NAME = "SuiteSetUp";
	public static final String SUITE_TEARDOWN_NAME = "SuiteTearDown";

	public RunAllResponder(String rootPath)
	{
		this.testResultsPath = rootPath + "/files/testResults";
		classPathElements = new ArrayList();
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();

		String resource = request.getResource();
		page = new VirtualEnabledPageCrawler().getPage(context.root, resource);
		pageData = page.getData();
		htmlWikiPage = new HtmlWikiPage(pageData);
		deleteTestResultFiles();

		List testPages = getAllTestPagesUnder(page);
		processTestPages(testPages);
		String classPathString = buildClassPath();
		String command = buildCommand(getClassName(request), classPathString);
		runner = new CommandRunner(command, makeSuiteHtml());
		runner.run();
		runCommand(context.root, request, response);

		return response;
	}

	private String buildClassPath() throws Exception
	{
		final ClassPathBuilder classPathBuilder = ClassPathBuilder.instance();
		final String pathSeparator = classPathBuilder.getPathSeparator(page);
		final String classPathString = classPathBuilder.createClassPathString(classPathElements, pathSeparator);
		return classPathString;
	}

	private void processTestPages(List testPages) throws Exception
	{
		HashSet visitedPages = new HashSet();
		for(Iterator iterator = testPages.iterator(); iterator.hasNext();)
		{
			WikiPage page = (WikiPage) iterator.next();
			addClassPathElements(page, visitedPages);
			makeParentDirectories(page);
			String html = new HtmlWikiPage(page.getData()).testableHtmlDocument();
			writeToFile(makeFilePath(page), html);
		}
	}

	private void addClassPathElements(WikiPage page, HashSet visitedPages) throws Exception
	{
		List pathElements = ClassPathBuilder.instance().getInheritedPathElements(page, visitedPages);
		pathElements.addAll(classPathElements);
		classPathElements = pathElements;
	}

	private void writeToFile(String filename, String html) throws IOException
	{
		OutputStream output = new FileOutputStream(filename);
		output.write(html.getBytes());
		output.close();
	}

	private void deleteTestResultFiles()
	{
		File base = new File(testResultsPath);
		if(base.exists())
		{
			File[] files = base.listFiles();
			for(int i = 0; i < files.length; i++)
			{
				File file = files[i];
				if(file.isDirectory())
					deleteDirectory(file);
				else
					file.delete();
			}
		}
	}

	private void deleteDirectory(File dir)
	{
		File[] files = dir.listFiles();

		for(int i = 0; files != null && i < files.length; i++)
		{
			File file = files[i];
			if(file.isDirectory())
				deleteDirectory(file);
			else
				file.delete();
		}
		dir.delete();
	}

	private void makeParentDirectories(WikiPage page) throws Exception
	{
		WikiPage parent = page.getParent();
		File dir = new File(makeDirectoryPath(parent));
		if(!dir.exists())
		{
			if(!parent.isRoot())
				makeParentDirectories(parent);
			dir.mkdir();
		}

	}

	public String makeDirectoryPath(WikiPage page) throws Exception
	{
		return makeDirectoryPath(page, testResultsPath);
	}

	public String makeDirectoryPath(WikiPage page, String rootPath) throws Exception
	{
		String location = new PageCrawler().getQualifiedName(page);
		location = location.replace('.', '/');
		String dirPath = rootPath + "/" + location;
		return dirPath;
	}

	public String makeFilePath(WikiPage page) throws Exception
	{
		return makeFilePath(page, testResultsPath);
	}

	public String makeFilePath(WikiPage page, String rootPath) throws Exception
	{
		return makeDirectoryPath(page, rootPath) + ".html";
	}

	public static List getAllTestPagesUnder(WikiPage suiteRoot) throws Exception
	{
		List testPages = new ArrayList();
		addTestPagesToList(testPages, suiteRoot);
		return testPages;
	}

	private static void addTestPagesToList(List testPages, WikiPage context) throws Exception
	{
		if(context.getData().hasAttribute("Test"))
			testPages.add(context);

		ArrayList children = new ArrayList();
		children.addAll(context.getChildren());
		children.addAll(context.getVirtualCoupling().getChildren());
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage page = (WikiPage) iterator.next();
			addTestPagesToList(testPages, page);
		}
	}

	protected String makeSuiteHtml() throws Exception
	{
		StringBuffer html = new StringBuffer();

		addSuiteSetUp(html);

		html.append("<table border=\"1\" cellspacing=\"0\">\n");
		html.append("<tr>\n<td>" + getRunAllClass() + "</td>\n</tr>\n");
		html.append("<tr>\n<td>").append(testResultsPath).append("</td>");
		html.append("<td>").append(new PageCrawler().getQualifiedName(page));
		html.append("</td>\n</tr>\n");
		html.append("</table>\n");
		html.append("<br>\n");
		html.append("<table border=\"1\" cellspacing=\"0\">\n");
		html.append("<tr>\n<td>fit.Summary</td>\n</tr>\n");
		html.append("</table>");

		addSuiteTearDown(html);
		html.append("<hr>");

		return html.toString();
	}

	protected String putOutputInPage(String output) throws Exception
	{
		String content = makeErrorLogLinkIfNeeded() + makeGreenOrRedBar() + output + htmlWikiPage.testableHtml();
		return new HtmlWikiPage(pageData).withHeaderAndFooter(content);
	}

	private void addSuiteSetUp(StringBuffer html) throws Exception
	{
		String suiteSetupHtml = htmlWikiPage.getHtmlOfInheritedPage(SUITE_SETUP_NAME, page);
		if(suiteSetupHtml != null && !suiteSetupHtml.equals(""))
			html.append(suiteSetupHtml + "\n");
	}

	private void addSuiteTearDown(StringBuffer html) throws Exception
	{
		String suiteTearDownHtml = htmlWikiPage.getHtmlOfInheritedPage(SUITE_TEARDOWN_NAME, page);
		if(suiteTearDownHtml != null && !suiteTearDownHtml.equals(""))
			html.append("\n" + suiteTearDownHtml);
	}

	private String getRunAllClass() throws Exception
	{
		String value = pageData.getVariable("SUITE_RUNNER");
		if(value == null)
			value = "fitnesse.fixtures.RecursiveAllFiles";
		return value;
	}

	// Utility method for unit tests.
	void setPageAndPageData(WikiPage page) throws Exception
	{
		this.page = page;
		pageData = page.getData();
		htmlWikiPage = new HtmlWikiPage(pageData);
	}
}
