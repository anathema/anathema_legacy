// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import junit.swingui.TestRunner;
import fitnesse.testutil.RegexTest;
import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.components.MockCommandRunner;
import fitnesse.responders.run.RunErrorResponder;

public class RunErrorResponderTest extends RegexTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RunErrorResponder"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testBasics() throws Exception
	{
		RunErrorResponder responder = new RunErrorResponder(new MockCommandRunner(), new MockWikiPage());
		SimpleResponse response = (SimpleResponse)responder.makeResponse(null, new MockHttpRequest());
		assertEquals(500, response.getStatus());
		assertHasRegexp("<html", response.getContent());
		assertHasRegexp("Exception", response.getContent());
	}

	public void testErrorMessageAndExceptions() throws Exception
	{
		MockCommandRunner runner = new MockCommandRunner();
		runner.setError("some standard error message");
		runner.addException(new Exception(" some exception"));
		RunErrorResponder responder = new RunErrorResponder(runner, new MockWikiPage());
		SimpleResponse response = (SimpleResponse)responder.makeResponse(null, new MockHttpRequest());
		assertHasRegexp("some standard error message", response.getContent());
		assertHasRegexp("some exception", response.getContent());
	}

	public void testClassDefNotFound() throws Exception
	{
		MockCommandRunner runner = new MockCommandRunner();
		runner.setError("java.lang.NoClassDefFoundError: fitnesse/FitFilters");
		runner.addException(new Exception(" some exception"));
		WikiPage root = InMemoryPage.makeRoot("root");
		root.addPage("PageOne", "");
		root.addPage("PageOne.PageTwo", "some content");
		RunErrorResponder responder = new RunErrorResponder(runner, new PageCrawler().getPage(root, "PageOne.PageTwo"));
		SimpleResponse response = (SimpleResponse)responder.makeResponse(null, new MockHttpRequest());
		assertHasRegexp("ClassPath", response.getContent());
		assertHasRegexp("<a", response.getContent());
		assertHasRegexp("href=\"PageOne[.]ClassPath[?]edit\"", response.getContent());
	}
}
