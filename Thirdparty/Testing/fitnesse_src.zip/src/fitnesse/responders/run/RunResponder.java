// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.components.*;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.responders.html.*;
import fitnesse.responders.run.CommandRunningResponder;
import fitnesse.responders.NotFoundResponder;
import fitnesse.FitNesseContext;

public class RunResponder extends CommandRunningResponder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		page = new VirtualEnabledPageCrawler().getPage(context.root, request.getResource());
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);
		pageData = page.getData();
		String program = getClassName(request);
		String classPath = ClassPathBuilder.instance().getClasspath(page);
		String command = buildCommand(program, classPath);
		runner = new CommandRunner(command, new HtmlWikiPage(pageData).testableHtml());
		runner.run();
		response = runCommand(context.root, request, response);
		return response;
	}

	protected String putOutputInPage(String output) throws Exception
	{
		// TODO the errorlog stuff needs to be refactored using the ErrorLogGenerator if we intend to keep this class around
		String content = makeErrorLogLinkIfNeeded() + "\n" + makeGreenOrRedBar() +  output;
		return new HtmlWikiPage(pageData).withHeaderAndFooter(content);
	}

}
