// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.responders.html.*;
import fitnesse.wiki.*;
import fitnesse.components.*;
import fit.*;
import java.util.*;

public class SuiteResponder extends TestResponder implements FitClientListener
{
	public static final String exceptionColor = "#ffffcf";
	public static final String wrongColor = "#ffcfcf";
	public static final String rightColor = "#cfffcf";
	public static final String ignoredColor = "#efefef";

	private static final String bgColor1 = "#efefef";
	private static final String bgColor2 = "#ffffff";

	private LinkedList processingQueue = new LinkedList();
	private boolean doneSending = false;
	private boolean doneReceiving = false;
	private StringBuffer testResults = new StringBuffer();
	private WikiPage currentTest = null;
	private String bgColor = bgColor1;
	private Counts summaryCounts = new Counts();
	private Counts totalCounts = new Counts();

	protected void doSending() throws Exception
	{
		buildHtml();
		response.add(html.pageHeader() + html.pageBody() + "\n");
		response.add("<center><a href=\"#summary\">View Suite Summay</a></center>\n");

		List testPages = makePageList();
		String classPath = buildClassPath(testPages);
		PageData data = page.getData();
		command = buildCommand(data, getClassName(data, request), classPath);
		client = new FitClient(this, command, context.port, context.socketDealer);
		client.start();

		if(client.isSuccessfullyStarted())
		{
			processTestPages(testPages);
			doneSending = true;

			client.done();
			client.join();

			synchronized(this)
			{
				if(!doneReceiving)
					this.wait();
			}
			ErrorLogGenerator errorLog = new ErrorLogGenerator(page, client);
			errorLog.generatePage();
			completeResponse();
		}
	}

	private void processTestPages(List testPages) throws Exception
	{
		for(Iterator iterator = testPages.iterator(); iterator.hasNext();)
		{
			WikiPage testPage = (WikiPage) iterator.next();
			processingQueue.addLast(testPage);
			String testableHtml = new HtmlWikiPage(testPage.getData()).testableHtml();
			client.send(testableHtml);
		}
	}

	protected void completeResponse() throws Exception
	{
		response.add(buildSummaryTable());
		ErrorLogGenerator errorLog = new ErrorLogGenerator(page, client);
		if(errorLog.needAttentionLabel())
      response.add(errorLog.generateAttentionLabel());
		response.add("<br><br><br><br><br>\n<center><font size=\"5\">Test Output</font></center><br><br>\n");
		response.add("<table border=\"1\" bordercolor=\"#000000\" width=\"100%\">" + testResults.toString() + "</table>");
		response.add(html.pageFooter());
		response.closeChunks();
		response.addTrailingHeader("Exit-Code", String.valueOf(totalCounts.wrong + totalCounts.exceptions));
		response.closeTrailer();
		response.close();
	}

	private String buildSummaryTable()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<a id=\"summary\">\n<br><br><br>");
		buffer.append("<table border=\"1\" width=\"500\" align=\"center\">\n");
		buffer.append("<tr><th colspan=\"2\">SUMMARY</th></tr>\n");
		buffer.append("<tr><td>Test Pages: </td><td bgcolor=\"").append(colorFor(summaryCounts)).append("\">").append(summaryCounts.toString()).append("</td></tr>");
		buffer.append("<tr><td>Assertions: </td><td bgcolor=\"").append(colorFor(totalCounts)).append("\">").append(totalCounts.toString()).append("</td></tr>");
		buffer.append("</table>");

		return buffer.toString();
	}

	public void acceptOutput(String output) throws Exception
	{
		WikiPage firstInLine = processingQueue.isEmpty() ? null : (WikiPage)processingQueue.getFirst();
		if(firstInLine != null && firstInLine != currentTest)
		{
			String relativeName = pageCrawler.getRelativeName(page, firstInLine);
			testResults.append("<tr><td bgcolor=\"cfcfff\">\n");
			testResults.append("<a id=\"").append(relativeName).append("\" ");
      testResults.append("href=\"").append(pageCrawler.getQualifiedName(firstInLine)).append("\">");
			testResults.append(relativeName).append("</a></td>\n");
			testResults.append("<tr><td bgcolor=\"").append(bgColor).append("\">\n");
			currentTest = firstInLine;
		}
		testResults.append(output);
	}

	public void acceptResults(Counts counts) throws Exception
	{
		tallyCounts(counts);

		testResults.append("</td></tr>\n");
		WikiPage testPage = (WikiPage)processingQueue.removeFirst();
		String relativeName = pageCrawler.getRelativeName(page, testPage);
		response.add(testResultHtml(relativeName, counts));

		if(processingQueue.isEmpty() && doneSending)
		{
			synchronized(this)
			{
				doneReceiving = true;
				this.notify();
			}
		}
	}

	protected String titleTail()
	{
		return "Suite Results";
	}

  private void tallyCounts(Counts counts)
	{
		totalCounts.tally(counts);
		if(counts.wrong > 0)
			summaryCounts.wrong += 1;
		else if(counts.exceptions > 0)
			summaryCounts.exceptions += 1;
		else if(counts.ignores > 0 && counts.right == 0)
			summaryCounts.ignores += 1;
		else
			summaryCounts.right += 1;
	}

	private String testResultHtml(String relativeName, Counts counts)
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<table width=\"100%\"><tr>");
		switchBgColor();
		buffer.append("<td bgcolor=\"").append(bgColor).append("\"><a href=\"#").append(relativeName).append("\">").append(relativeName).append("</a></td>");
		buffer.append("<td width=\"300\" bgcolor=\"").append(colorFor(counts)).append("\">").append(counts.toString()).append("</td>");
		buffer.append("</tr></table>\n");
		return buffer.toString();
	}

	private String colorFor(Counts count)
	{
		if(count.wrong > 0)
			return wrongColor;
		else if(count.exceptions > 0)
			return exceptionColor;
		else if(count.ignores > 0 && count.right == 0)
			return ignoredColor;
		else
			return rightColor;
	}

	private void switchBgColor()
	{
		if(bgColor1.equals(bgColor))
			bgColor = bgColor2;
		else
			bgColor = bgColor1;
	}

	public String buildClassPath(List testPages) throws Exception
	{
		final ClassPathBuilder classPathBuilder = ClassPathBuilder.instance();
		final String pathSeparator = classPathBuilder.getPathSeparator(page);
		List classPathElements = new ArrayList();
		Set visitedPages = new HashSet();

		for(Iterator iterator = testPages.iterator(); iterator.hasNext();)
		{
			WikiPage testPage = (WikiPage) iterator.next();
			addClassPathElements(testPage, classPathElements, visitedPages);
		}
		final String classPathString = classPathBuilder.createClassPathString(classPathElements, pathSeparator);
		return classPathString;
	}

	private void addClassPathElements(WikiPage page, List classPathElements, Set visitedPages) throws Exception
	{
		List pathElements = ClassPathBuilder.instance().getInheritedPathElements(page, visitedPages);
		classPathElements.addAll(pathElements);
	}

	public List makePageList() throws Exception
	{
		LinkedList pages = getAllTestPagesUnder(page);

		WikiPage suiteSetUp = HtmlWikiPage.getInheritedPage("SuiteSetUp", page);
		if(suiteSetUp != null)
		{
			if(pages.contains(suiteSetUp))
				pages.remove(suiteSetUp);
			pages.addFirst(suiteSetUp);
		}
		WikiPage suiteTearDown = HtmlWikiPage.getInheritedPage("SuiteTearDown", page);
		if(suiteTearDown != null)
		{
			if(pages.contains(suiteTearDown))
				pages.remove(suiteTearDown);
			pages.addLast(suiteTearDown);
		}

		return pages;
	}

	public static LinkedList getAllTestPagesUnder(WikiPage suiteRoot) throws Exception
	{
		LinkedList testPages = new LinkedList();
		addTestPagesToList(testPages, suiteRoot);
		return testPages;
	}

	private static void addTestPagesToList(List testPages, WikiPage context) throws Exception
	{
		if(context.getData().hasAttribute("Test"))
			testPages.add(context);

		ArrayList children = new ArrayList();
		children.addAll(context.getChildren());
		children.addAll(context.getVirtualCoupling().getChildren());
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage page = (WikiPage) iterator.next();
			addTestPagesToList(testPages, page);
		}
	}
}
