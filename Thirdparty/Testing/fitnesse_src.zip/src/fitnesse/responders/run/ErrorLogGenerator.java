// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.wiki.*;
import fitnesse.components.*;
import fitnesse.responders.ErrorResponder;
import java.util.*;
import java.text.SimpleDateFormat;

public class ErrorLogGenerator
{
	public static final String ErrorLogName = "ErrorLog";
	public static final SimpleDateFormat dateFormat = new SimpleDateFormat("h:mm:ss a (z) 'on' EEEE, MMMM d, yyyy");

	private WikiPage testPage;
	private WikiPage errorLogPage;
	private CommandRunner runner;
	private List reasons = new LinkedList();
	private List exceptions = new LinkedList();

	public ErrorLogGenerator(WikiPage page, CommandRunner client) throws Exception
	{
		this.testPage = page;
		this.runner = client;

		establishErrorLogExistance(page);
	}

	public void addException(Exception e)
	{
		exceptions.add(e);
	}

	private void establishErrorLogExistance(WikiPage page) throws Exception
	{
		if(!page.hasChildPage(ErrorLogName))
			page.addChildPage(ErrorLogName);

		errorLogPage = testPage.getChildPage(ErrorLogName);
	}

	public void addReason(String reason)
	{
		if(! reasons.contains(reason))
			reasons.add(reason);
	}

	public boolean needAttentionLabel()
	{
		findReasonsForAttentionLabel();
		return reasons.size() > 0;
	}

	private void findReasonsForAttentionLabel()
	{
		if(runner.hasOutput())
			addReason("Output was captured from standard output");
		if(runner.hasError())
			addReason("Output was captured from standard error");
		if(runner.hasExceptions() || exceptions.size() > 0)
			addReason("Internal Exceptions were thrown");
	}

	public String generateAttentionLabel() throws Exception
	{
		findReasonsForAttentionLabel();
		String errorLogQualifiedName = new PageCrawler().getQualifiedName(errorLogPage);
		StringBuffer buffer = new StringBuffer();
		buffer.append("<table border=\"1\" bordercolor=\"#FF0000\" align=\"center\" cellspacing=\"0\" cellpadding=\"5\"><tr><td bgcolor=\"#CCCCCC\">");
		buffer.append("<center><font size=\"5\" color=\"#FFFF00\"><b>Attention!</b></font></center><br>");
		buffer.append("You may wish to view the <a href=\"").append(errorLogQualifiedName).append("\">ErrorLog</a> for the following reason");
		if(reasons.size() > 1)
			buffer.append("s");
		buffer.append(":<br>");
		for(Iterator iterator = reasons.iterator(); iterator.hasNext();)
		{
			String reason = (String) iterator.next();
			buffer.append("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- ").append(reason).append("<br>");
		}
		buffer.append("<br><center><a href=\"").append(errorLogQualifiedName).append("\"><font size=\"2\">View ErrorLog</font></a></center>");
		buffer.append("</td></tr></table>");

		return buffer.toString();
	}

	public void generatePage() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		addEntry(buffer, "Date", dateFormat.format(new Date()));
		addEntry(buffer, "Command", runner.getCommand());
		addEntry(buffer, "Exit code", String.valueOf(runner.getExitCode()));
		addEntry(buffer, "Time elapsed", (((double)runner.getExecutionTime()) / 1000.0) + " seconds");
		if(runner.hasOutput())
			addOutputBlock(buffer);
		if(runner.hasError())
			addErrorBlock(buffer);
		if(runner.hasExceptions() || exceptions.size() > 0)
			addExceptionBlock(buffer);

		PageData data = errorLogPage.getData();
		data.setContent(buffer.toString());
		errorLogPage.commit(data);
	}

	private void addEntry(StringBuffer buffer, String key, String value)
	{
		buffer.append("|'''").append(key).append(": '''|").append("!-").append(value).append("-!").append("|\n");
	}

	private void addOutputBlock(StringBuffer buffer)
	{
		buffer.append("----");
		buffer.append("'''Standard Output:'''").append("\n");
		buffer.append("{{{ ").append(runner.getOutput()).append("}}}");
	}

	private void addErrorBlock(StringBuffer buffer)
	{
		buffer.append("----");
		buffer.append("'''Standard Error:'''").append("\n");
		buffer.append("{{{ ").append(runner.getError()).append("}}}");
	}

	private void addExceptionBlock(StringBuffer buffer)
	{
		exceptions.addAll(runner.getExceptions());
		buffer.append("----");
		buffer.append("'''Internal Exception");
		if(exceptions.size() > 1)
			buffer.append("s");
		buffer.append(":'''").append("\n");
		for(Iterator iterator = exceptions.iterator(); iterator.hasNext();)
		{
			Exception exception = (Exception) iterator.next();
			buffer.append("{{{ ").append(ErrorResponder.makeExceptionString(exception)).append("}}}");
		}
	}
}
