// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(RunResponderTest.class));
		suite.addTest(new TestSuite(RunErrorResponderTest.class));
		suite.addTest(new TestSuite(RunAllResponderTest.class));
		suite.addTest(new TestSuite(TestResponderTest.class));
		suite.addTest(new TestSuite(SuiteResponderTest.class));
		suite.addTest(new TestSuite(SocketDealerTest.class));
		suite.addTest(new TestSuite(SocketCatchingResponseTest.class));
		suite.addTest(new TestSuite(ErrorLogGeneratorTest.class));
		return suite;
	}
}
