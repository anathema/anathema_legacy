// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.responders.run.RunAllResponder;
import fitnesse.testutil.*;
import fitnesse.http.*;

import java.util.List;
import java.io.File;

public class RunAllResponderTest extends RegexTest
{
	private static final String ROOT = "./testdirectory";
  private static final String PATH = ROOT + "/files/testResults";

	private WikiPage root;
	private WikiPage suiteRoot;
	private WikiPage testOne;
	private WikiPage testTwo;
	private WikiPage testThree;
	private WikiPage suiteSetup;
	private WikiPage suiteTearDown;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		suiteRoot = root.addPage("TestSuite", "some content");
		setAttribute(suiteRoot, "Test", "true");
		suiteRoot.addPage("NotaTest", "not a test");
		suiteSetup = root.addPage("SuiteSetUp", "The Suite Setup");
		suiteTearDown = root.addPage("SuiteTearDown", "The Suite Teardown");
		testOne = suiteRoot.addPage("TestOne", "test one");
		setAttribute(testOne, "Test", "true");
		testTwo = suiteRoot.addPage("TestTwo", "test two");
		setAttribute(testTwo, "Test", "true");
		testThree = suiteRoot.addPage("TestOne.TestThree", "test three");
		setAttribute(testThree, "Test", "true");

		root.addPage("ClassPath", "!path path1");
		suiteRoot.addPage("ClassPath", "!path path2");
		testOne.addPage("ClassPath", "!path classes");
		testTwo.addPage("ClassPath", "!path shouldNotBeIncluded");

    new File(ROOT).mkdir();
    new File(ROOT + "/files").mkdir();
    boolean created = new File(PATH).mkdir();
    assertTrue(created);
	}

	private void setAttribute(WikiPage page, String attribute, String value) throws Exception
	{
		PageData data = page.getData();
		data.setAttribute(attribute, value);
		page.commit(data);
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(new File(ROOT));
	}

	public void testGetAllTestPages() throws Exception
	{
		List testPages = RunAllResponder.getAllTestPagesUnder(suiteRoot);
		assertEquals(4, testPages.size());
		assertEquals(true, testPages.contains(suiteRoot));
		assertEquals(true, testPages.contains(testOne));
		assertEquals(true, testPages.contains(testTwo));
		assertEquals(true, testPages.contains(testThree));
	}

	public void testMakeFilePath() throws Exception
	{
		RunAllResponder responder = new RunAllResponder(ROOT);
		assertEquals(PATH + "/TestSuite.html", responder.makeFilePath(suiteRoot));
		assertEquals(PATH + "/TestSuite/TestOne.html", responder.makeFilePath(testOne));
	}

	public void testFileCreation() throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("TestSuite");
		Responder responder = new RunAllResponder(ROOT);
		responder.makeResponse(new FitNesseContext(root), request);

		assertEquals(true, wasFileCreated("TestSuite.html"));
		assertEquals(true, wasFileCreated("TestSuite/TestOne.html"));
		assertEquals(true, wasFileCreated("TestSuite/TestTwo.html"));
		assertEquals(true, wasFileCreated("TestSuite/TestOne/TestThree.html"));

		assertEquals(false, wasFileCreated("TestSuite/TestTwo"));
	}

	public void testForFlagStatusAfterRun() throws Exception
	{
		String html = makeHTTPResponse("TestSuite");
		assertSubString("<font color=\"FF0000\" face=\"bold\" size=\"+2\">FAIL</font>", html);
	}

	public void testHtml() throws Exception
	{
		String html = makeHTTPResponse("TestSuite");

		assertHasRegexp("TestSuite", html);
		assertHasRegexp("TestSuite.TestOne", html);
		assertHasRegexp("TestSuite.TestTwo", html);
		assertHasRegexp("TestSuite.TestOne.TestThree", html);
	}

	private String makeHTTPResponse(String testSuite) throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource(testSuite);
		Responder responder = new RunAllResponder(ROOT);
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String html = response.getContent();
		return html;
	}

	public void testMakeSuiteHtml() throws Exception
	{
		RunAllResponder responder = new RunAllResponder(ROOT);
		responder.setPageAndPageData(suiteRoot);
		String suiteHtml = responder.makeSuiteHtml();
		String setup = suiteSetup.getData().getContent() + "\n";
		String teardown = "\n" + suiteTearDown.getData().getContent();
		assertTrue(suiteHtml.startsWith(setup + "<table border=\"1\" cellspacing=\"0\">\n<tr>\n<td>fitnesse.fixtures.RecursiveAllFiles</td>"));
		assertTrue(suiteHtml.endsWith("<td>fit.Summary</td>\n</tr>\n</table>" + teardown + "<hr>"));
	}

	private boolean wasFileCreated(String filename)
	{
		return new File(PATH + "/" + filename).exists();
	}

	public void testShouldGetVirtualPage() throws Exception
	{
		WikiPage pageOne = root.addPage("SuiteOfTargetTests", "some content");
		WikiPage virtualTestPage = pageOne.addPage("TestPage", "test content");
		setAttribute(virtualTestPage, "Test", "true");
		FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)suiteRoot, pageOne);

		String responseResult = makeHTTPResponse("TestSuite");
		assertSubString("TestPage", responseResult);
	}

	public void testShouldRunAVirutalSuite() throws Exception
	{
		WikiPage pageOne = root.addPage("PageOne");
		pageOne.addPage("SuiteOfTargetTests", "some content");
		FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)suiteRoot, pageOne);
		try
		{
			makeHTTPResponse("TestSuite.SuiteOfTargetTests");
		}
		catch (NullPointerException e)
		{
			fail("This shouldn't be null.");
		}
	}
}
