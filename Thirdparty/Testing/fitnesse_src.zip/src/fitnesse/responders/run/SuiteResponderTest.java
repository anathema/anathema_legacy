// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.testutil.*;
import fitnesse.FitNesseContext;
import java.util.List;

public class SuiteResponderTest extends RegexTest
{
	private MockHttpRequest request;
	private SuiteResponder responder;
	private WikiPage root;
	private WikiPage suite;
	private int port = 9123;
	private FitNesseContext context;
	private FitSocketReceiver receiver;
	private WikiPage testPage;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		suite = root.addPage("SuitePage", "This is the test suite\n" + classpathWidgets());
		testPage = addTestPage("TestOne", "|!-fitnesse.testutil.PassFixture-!|\n");

		request = new MockHttpRequest();
		request.setResource("SuitePage");
		responder = new SuiteResponder();
		responder.page = suite;
		context = new FitNesseContext(root);
		context.port = port;

		receiver = new FitSocketReceiver(port, context.socketDealer);
	}

	private WikiPage addTestPage(String name, String content) throws Exception
	{
		WikiPage testPage = suite.addPage(name, content);
		PageData data = testPage.getData();
		data.setAttribute("Test");
		testPage.commit(data);
		return testPage;
	}

	public void tearDown() throws Exception
	{
		receiver.close();
	}

	public void testBuildClassPath() throws Exception
	{
		responder.page = suite;
		List testPages = RunAllResponder.getAllTestPagesUnder(suite);
		String classpath = responder.buildClassPath(testPages);
		assertSubString("classes", classpath);
		assertSubString("dummy.jar", classpath);
	}

	public void testWithOneTest() throws Exception
	{
		receiver.receiveSocket();
		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);
		String results = sender.sentData();

		assertHasRegexp("<a href=\"#TestOne\">TestOne</a>", results);
		assertHasRegexp("1 right", results);
		assertHasRegexp("<a id=\"TestOne\" href=\"SuitePage.TestOne\">TestOne</a>", results);
		assertHasRegexp("PassFixture", results);
	}

	public void testWithTwoTests() throws Exception
	{
		receiver.receiveSocket();
		addTestPage("TestTwo", "|!-fitnesse.testutil.FailFixture-!|\n\n|!-fitnesse.testutil.FailFixture-!|\n");
		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);
		String results = sender.sentData();

		assertHasRegexp("<a href=\"#TestOne\">TestOne</a>", results);
		assertHasRegexp("<a href=\"#TestTwo\">TestTwo</a>", results);
		assertHasRegexp("1 right", results);
		assertHasRegexp("2 wrong", results);
		assertHasRegexp("<a id=\"TestOne\"", results);
		assertHasRegexp("<a id=\"TestTwo\"", results);
		assertHasRegexp("PassFixture", results);
		assertHasRegexp("FailFixture", results);
	}

	public void testExitCodeHeader() throws Exception
	{
		receiver.receiveSocket();
		Response response = responder.makeResponse(context, request);
		MockResponseSender sender = new MockResponseSender(response);
		String results = sender.sentData();

		assertSubString("Exit-Code: 0", results);
	}

	public void testGetAllTestPages() throws Exception
	{
		WikiPage testPage2 = addTestPage("TestPageTwo", "test page two");
		WikiPage testChildPage = testPage2.addChildPage("TestChildPage");
		PageData data = testChildPage.getData();
		data.setAttribute("Test");
		testChildPage.commit(data);

		List testPages = SuiteResponder.getAllTestPagesUnder(suite);
		assertEquals(3, testPages.size());
		assertEquals(true, testPages.contains(testPage));
		assertEquals(true, testPages.contains(testPage2));
		assertEquals(true, testPages.contains(testChildPage));
	}

	public void testSutUpAndTearDown() throws Exception
	{
		WikiPage setUp = root.addPage("SuiteSetUp", "suite set up");
		WikiPage tearDown = root.addPage("SuiteTearDown", "suite tear down");

		List testPages = responder.makePageList();
		assertEquals(3, testPages.size());
		assertSame(setUp, testPages.get(0));
		assertSame(tearDown, testPages.get(2));
	}

	private String classpathWidgets()
	{
		return "!path classes\n" +
		  "!path lib/dummy.jar\n";
	}

}
