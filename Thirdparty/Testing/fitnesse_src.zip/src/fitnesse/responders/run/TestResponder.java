// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.responders.html.*;
import fitnesse.responders.*;
import fitnesse.components.*;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fit.Counts;

public class TestResponder extends ChunkingResponder implements FitClientListener
{
	protected HtmlPage html;
	protected FitClient client;
	protected String command;
	protected PageCrawler pageCrawler = new VirtualEnabledPageCrawler();

	protected PageCrawler getPageCrawler()
	{
		return pageCrawler;
	}

	public void acceptResults(Counts counts) throws Exception
	{
	}

  public void exceptionOccurred(Exception e)
  {
    try
    {
	    client.kill();

			ErrorLogGenerator log = new ErrorLogGenerator(page, client);
	    log.addException(e);
			log.generatePage();
	    log.addReason("Test execution aborted abnormally with error code " + client.getExitCode());
			response.add(log.generateAttentionLabel());

      completeResponse();
    }
    catch (Exception e1)
    {
      e1.printStackTrace();
    }
  }

  protected void completeResponse() throws Exception {
    response.add(html.pageFooter());
    response.closeChunks();
    response.addTrailingHeader("Exit-Code", String.valueOf(client.getExitCode()));
    response.closeTrailer();
    response.close();
  }

  public void acceptOutput(String output) throws Exception
	{
		response.add(output);
	}


	protected void doSending() throws Exception
	{
		PageData data = page.getData();

		buildHtml();
		response.add(html.pageHeader() + html.pageBody() + "\n");

		String testableHtml = new HtmlWikiPage(data).testableHtml();
		String classPath = ClassPathBuilder.instance().getClasspath(page);
		command = buildCommand(data, getClassName(data, request), classPath);
		client = new FitClient(this, command, context.port, context.socketDealer);
		client.start();
		if(client.isSuccessfullyStarted())
		{
			client.send(testableHtml);
			client.done();
			client.join();
		}

		ErrorLogGenerator log = new ErrorLogGenerator(page, client);
		log.generatePage();
		if(log.needAttentionLabel())
			response.add(log.generateAttentionLabel());

		completeResponse();
	}

	protected void buildHtml() throws Exception
	{
		html = new HtmlPage();
		html.setHtmlTitle(page.getName() + " " + titleTail());
		Table table = new Table();
		table.addRow(TableRow.titleRow(title()));
		html.addElement(table);
	}

	protected String titleTail()
	{
		return "Test Results";
	}

	protected String title() throws Exception
	{
		return "<a href=\"" + new PageCrawler().getQualifiedName(page) + "\">" + page.getName() + " </a> <i>" + titleTail() + "</i>";
	}

	public String getClassName(PageData data, HttpRequest request) throws Exception
	{
		String program = (String) request.getInput("className");
		if(program == null)
			program = data.getVariable("TEST_RUNNER");
		if(program == null)
			program = "fit.FitServer";
		return program;
	}

	protected String buildCommand(PageData data, String program, String classPath) throws Exception
	{
		String testRunner = data.getVariable("COMMAND_PATTERN");
		if(testRunner == null)
			testRunner = CommandRunningResponder.DEFAULT_COMMAND_PATTERN;
		String command = replace(testRunner, "%p", classPath);
		command = replace(command, "%m", program);
		return command;
	}

	// String.replaceAll(...) is not trustworthy because it seems to remove all '\' characters.
	protected String replace(String value, String mark, String replacement)
	{
		int index = value.indexOf(mark);
		if(index == -1)
			return value;

		return value.substring(0, index) + replacement + value.substring(index + mark.length());
	}

}
