// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.components.CommandRunner;
import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.responders.ErrorResponder;

import java.util.*;
import java.util.regex.*;

public class RunErrorResponder implements Responder
{
	private static Pattern ClassDefNotFoundPattern = Pattern.compile("java.lang.NoClassDefFoundError: (\\S*)");

	private CommandRunner runner;
	private WikiPage page;
	private String resource;

	public RunErrorResponder(CommandRunner runner, WikiPage page)
	{
		this.runner = runner;
		this.page = page;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse(500);
		resource = request.getResource();
		String html = makeHtml();
		response.setContent(html);
		return response;
	}

	public String makeHtml() throws Exception
	{
		HtmlPage page = new HtmlPage();
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(resource)));
		table.addRow(new TableRow("<!-- Run Error -->", makeRightColumn()));
		page.addElement(table);
		return page.html();
	}

	public String  makeRightColumn() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("Exceptions occurred during the execution of the supplied command<br><br>");
		if(runner.hasError())
		{
			buffer.append("The following Standard Error was captured:<br>");
			buffer.append("<pre>");
			buffer.append(runner.getError());
			buffer.append("</pre>");
			buffer.append(addClassPathSuggestionIfNeeded());
		}
		if(runner.hasOutput())
		{
			buffer.append("The following Standard Output was captured:<br>");
			buffer.append("<pre>");
			buffer.append(runner.getOutput());
			buffer.append("</pre>");
			buffer.append(addClassPathSuggestionIfNeeded());
		}
		buffer.append("<b>Exceptions</b>:<br>");
		buffer.append("<pre>");
		for(Iterator iterator = runner.getExceptions().iterator(); iterator.hasNext();)
		{
			Exception e = (Exception) iterator.next();
			buffer.append(ErrorResponder.makeExceptionString(e));
		}
		buffer.append("</pre>");
		return buffer.toString();
	}

	private String addClassPathSuggestionIfNeeded() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		Matcher match = ClassDefNotFoundPattern.matcher(runner.getError());
		if(match.find())
		{
			String classString = match.group(1).replace('/', '.');
			WikiPage parent = page.getParent();
			buffer.append("<ul><li>This suggests that you may need to add the class <i>" + classString + "</i> to the ");
			buffer.append("<a href=\"" + new PageCrawler().getQualifiedName(parent) + ".ClassPath?edit\">ClassPath</a>.</ul>");
		}
		return buffer.toString();
	}
}
