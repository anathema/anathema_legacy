// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.testutil.*;
import fitnesse.wiki.*;
import fitnesse.components.MockCommandRunner;

public class ErrorLogGeneratorTest extends RegexTest
{
	private static String ErrorLogName = ErrorLogGenerator.ErrorLogName;

	private WikiPage testPage;
	private MockCommandRunner runner;
	private ErrorLogGenerator log;

	public void setUp() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		testPage = root.addChildPage("TestPage");
	  runner = new MockCommandRunner("some command", 123);
	  log = new ErrorLogGenerator(testPage, runner);
	}

	public void tearDown() throws Exception
	{
	}

  public void testPageIsCreated() throws Exception
  {
	  log.generatePage();
	  assertTrue(testPage.hasChildPage(ErrorLogName));
  }

	public void testErrorLogContentIsReplaced() throws Exception
	{
		WikiPage errorLogPage = testPage.getChildPage(ErrorLogName);
		PageData data = errorLogPage.getData();
		data.setContent("old content");
		errorLogPage.commit(data);

		log.generatePage();
		String content = errorLogPage.getData().getContent();
		assertNotSubString("old content", content);
	}

	public void testBasicContent() throws Exception
	{
		String content = getGeneratedContent();

		assertSubString("'''Command: '''", content);
		assertSubString("!-some command-!", content);
		assertSubString("'''Exit code: '''", content);
		assertSubString("123", content);
		assertSubString("'''Date: '''", content);
		assertSubString("'''Time elapsed: '''", content);
	}

	private String getGeneratedContent() throws Exception
	{
		log.generatePage();
		WikiPage errorLogPage = testPage.getChildPage(ErrorLogName);
		String content = errorLogPage.getData().getContent();
		return content;
	}

	public void testNoExtraLogTextWasGenerated() throws Exception
	{
		String content = getGeneratedContent();

		assertNotSubString("Exception", content);
		assertNotSubString("Standard Error", content);
		assertNotSubString("Standard Output", content);
	}

	public void testStdout() throws Exception
	{
		runner.setOutput("standard output that got printed");
		String content = getGeneratedContent();

		assertSubString("'''Standard Output:'''", content);
		assertSubString("standard output that got printed", content);
	}

	public void testStderr() throws Exception
	{
		runner.setError("standard error that got printed");
		String content = getGeneratedContent();

		assertSubString("'''Standard Error:'''", content);
		assertSubString("standard error that got printed", content);
	}

	public void testException() throws Exception
	{
		log.addException(new Exception("I made this"));
		String content = getGeneratedContent();

		assertSubString("'''Internal Exception:'''", content);
		assertSubString("I made this", content);
	}

	public void testAddingExceptions() throws Exception
	{

	}

	public void testAttentionLabelGeneration() throws Exception
	{
		String content = log.generateAttentionLabel();
		assertSubString("ErrorLog", content);

		log.addReason("blah");
		content = log.generateAttentionLabel();
		assertSubString("blah", content);

		runner.setError("some error");
		content = log.generateAttentionLabel();
		assertSubString("standard error", content);
	}

	public void testNeedAttentionLabel() throws Exception
	{
		assertFalse(log.needAttentionLabel());

		runner.setError("error");
		assertTrue(log.needAttentionLabel());
	}
}
