// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import fitnesse.wiki.*;
import fitnesse.components.CommandRunner;
import fitnesse.http.*;
import fitnesse.*;

public abstract class CommandRunningResponder implements Responder
{
	public static final String DEFAULT_COMMAND_PATTERN = "java -cp %p %m";

	protected WikiPage page;
	protected PageData pageData;
	protected String programOutput;
	protected CommandRunner runner;
	protected String pathSeparator;

	protected SimpleResponse runCommand(WikiPage root, HttpRequest request, SimpleResponse response) throws Exception
	{
		if(runner.hasExceptions())
		{
			RunErrorResponder responder = new RunErrorResponder(runner, page);
			response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		}
		else
		{
			programOutput = runner.getOutput();
			String html = putOutputInPage(programOutput);
			response.setContent(html);
			response.addHeader("Exit-Code", Integer.toString(runner.getExitCode()));
		}
		return response;
	}

	protected abstract String putOutputInPage(String output) throws Exception;

	protected String makeErrorLogLinkIfNeeded() throws Exception
	{
        addErrorToErrorLog();
		StringBuffer buffer = new StringBuffer();
		if(runner.hasError())
		{
			buffer.append("<span style=\"background : #FFFF00\">");
			buffer.append("<font color=\"#FF0000\"><b>Note:</b></font> Ouput from Standard Error was captured during execution.  ");
			buffer.append("You may view it by visiting the <a href=\"" + new PageCrawler().getQualifiedName(page) + ".ErrorLog\">ErrorLog</a>");
			buffer.append("</span><br>");
		}
		return buffer.toString();
	}

	protected String makeGreenOrRedBar()
	{
		StringBuffer returnBuffer = new StringBuffer("<br>");
		if(runner.getExitCode() == 0)
		{
			returnBuffer.append("<font color=\"00FF00\" face=\"bold\" size=\"+2\">PASS</font>");
		} else
		{
			returnBuffer.append("<font color=\"FF0000\" face=\"bold\" size=\"+2\">FAIL</font>");
		}
		returnBuffer.append("<p>");
		return returnBuffer.toString();
	}


	private void addErrorToErrorLog() throws Exception
	{
		String content = getRunSummary() ;
		if(page.hasChildPage("ErrorLog"))
		{
			WikiPage errorLog = page.getChildPage("ErrorLog");
			PageData errorLogdata = errorLog.getData();
			errorLogdata.setContent(content);
			errorLog.commit(errorLogdata);
		}
		else
		{
			page.addPage("ErrorLog", content);
		}
	}

	public String getRunSummary()
	{
		StringBuffer buff = new StringBuffer();
		buff.append("'''Command: '''").append("!-").append(runner.getCommand()).append("-!").append("\n");
		buff.append("'''Exited with code: '''").append(runner.getExitCode()).append("----");
		if(runner.hasError())
			buff.append("'''Standard Error Output:'''").append("\n");
		buff.append("{{{ ").append(runner.getError()).append("}}}");
		return buff.toString();
	}

	protected String buildCommand(String program, String classPath) throws Exception
	{
		String testRunner = pageData.getVariable("COMMAND_PATTERN");
		if(testRunner == null)
			testRunner = DEFAULT_COMMAND_PATTERN;
		String command = replace(testRunner, "%p", classPath);
		command = replace(command, "%m", program);
		return command;
	}

	// String.replaceAll(...) is not trustworthy because it seems to remove all '\' characters.
	private String replace(String value, String mark, String replacement)
	{
		int index = value.indexOf(mark);
		if(index == -1)
			return value;

		return value.substring(0, index) + replacement + value.substring(index + mark.length());
	}

	public String getClassName(HttpRequest request) throws Exception
	{
		String program = (String) request.getInput("className");
		if(program == null)
			program = pageData.getVariable("TEST_RUNNER");
		if(program == null)
			program = "fitnesse.FitFilter";
		return program;
	}
}
