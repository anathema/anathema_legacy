// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.run;

import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;
import fitnesse.responders.run.RunResponder;
import fitnesse.testutil.*;

public class RunResponderTest extends RegexTest
{
	private WikiPage page;
	private MockResponseSender sender;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RunResponderTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testHelloWorld() throws Exception
	{
		buildResponse("simple content", "fitnesse.testutil.Hello");
		assertHasRegexp("Hello, World!", sender.sentData());
	}

	public void testEcho() throws Exception
	{
		buildResponse("simple content", "fitnesse.testutil.Echo");

		assertHasRegexp("<html>", sender.sentData());
		assertHasRegexp("this is the footer", sender.sentData());
		assertHasRegexp("simple content", sender.sentData());
	}

	public void testBigEcho() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		for(int i = 0; i < 500; i++)
		{
			buffer.append("saba ");
		}
		String bigEcho = buffer.toString();

		buildResponse(bigEcho, "fitnesse.testutil.Echo");

		assertHasRegexp(bigEcho, sender.sentData());
	}

	public void testErrorLogLink() throws Exception
	{
		buildResponse("Some junk", "fitnesse.testutil.ErrorEcho");
		assertHasRegexp("href=\"SimplePage.ErrorLog\"", sender.sentData());
		assertEquals(true, new PageCrawler().pageExists(page, "SimplePage.ErrorLog"));
		WikiPage errorPage = new PageCrawler().getPage(page, "SimplePage.ErrorLog");
		assertHasRegexp("standard error", errorPage.getData().getContent());
	}

	private SimpleResponse buildResponse(String content, String className) throws Exception
	{
		page = InMemoryPage.makeRoot("RooT");
		page.addPage("SimplePage", content);
		page.addPage("PageFooter", "this is the footer");
		page.addPage("ClassPath", "!path ./classes");

		MockHttpRequest request = new MockHttpRequest();
		request.setResource("SimplePage");
		request.addInput("className", className);

		Responder responder = new RunResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(page), request);

		sender = new MockResponseSender(response);

		return response;
	}

	public void testExitCodeHeader() throws Exception
	{
		Response response = buildResponse("", "fitnesse.testutil.Hello");
		assertEquals("0", response.getHeader("Exit-Code"));

		response = buildResponse("", "fitnesse.testutil.BadExit");
		assertEquals("-1", response.getHeader("Exit-Code"));
	}

	public void testFlagColorAfterTestsHaveRun() throws Exception
	{
		SimpleResponse response = buildResponse("some content", "fitnesse.testutil.Hello");
		assertSubString("<font color=\"00FF00\" face=\"bold\" size=\"+2\">PASS</font>", response.getContent());

		response = buildResponse("more content", "fitnesse.testUtil.BadExit");
		assertSubString("<font color=\"FF0000\" face=\"bold\" size=\"+2\">FAIL</font>", response.getContent());
	}

	public void testShouldRunAVirutalTest() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage pageOne = root.addPage("PageOne");
		pageOne.addPage("ChildPage", "some content");
		WikiPage pageTwo = root.addPage("PageTwo");
		FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)pageTwo, pageOne);
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageTwo.ChildPage");

		try
		{
			new RunResponder().makeResponse(new FitNesseContext(root), request);
		}
		catch (NullPointerException e)
		{
			fail("This shouldn't be null.");
		}

	}
}