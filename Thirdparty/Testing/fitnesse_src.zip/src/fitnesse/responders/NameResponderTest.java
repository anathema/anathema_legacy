// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.testutil.RegexTest;
import fitnesse.http.*;
import fitnesse.wiki.InMemoryPage;
import fitnesse.wiki.WikiPage;
import fitnesse.FitNesseContext;

public class NameResponderTest extends RegexTest
{
	private WikiPage root;
	private NameResponder responder;
	private MockHttpRequest request;

	protected void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		responder = new NameResponder();
		request = new MockHttpRequest();
	}

	public void testTextPlain() throws Exception
	{

		Response r = responder.makeResponse(new FitNesseContext(root), request);
		assertEquals("text/plain", r.getContentType());
	}

	public void testPageNamesFromRoot() throws Exception
	{
		root.addPage("PageOne", "");
		root.addPage("PageTwo", "");
		request.setResource("");
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertHasRegexp("PageOne", response.getContent());
		assertHasRegexp("PageTwo", response.getContent());
	}

	public void testPageNamesFromASubPage() throws Exception
	{
		WikiPage frontPage = root.addPage("FrontPage", "");
		frontPage.addPage("PageOne", "");
		frontPage.addPage("PageTwo", "");
		request.setResource("");
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertHasRegexp("FrontPage", response.getContent());
		assertDoesntHaveRegexp("PageOne", response.getContent());
		assertDoesntHaveRegexp("PageTwo", response.getContent());

		request.setResource("FrontPage");
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertHasRegexp("PageOne", response.getContent());
		assertHasRegexp("PageTwo", response.getContent());
		assertDoesntHaveRegexp("FrontPage", response.getContent());
	}
}
