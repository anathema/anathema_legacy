// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.*;
import fitnesse.responders.html.*;


public class ErrorResponder implements Responder
{
	Exception exception;

	public ErrorResponder(Exception e)
	{
		exception = e;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse(400);

		HtmlPage html = new HtmlPage();
		html.setHtmlTitle("Error Occurred");
		Table table = new Table();
		table.addRow(TableRow.titleRow("Error Occurred"));
		table.addRow(new TableRow("", "<pre>" + makeExceptionString(exception) + "</pre>"));
		html.addElement(table);

		response.setContent(html.html());

		return response;
	}

	public static String makeExceptionString(Exception e)
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append(e.toString()).append("\n");
		StackTraceElement[] stackTreace = e.getStackTrace();
		for(int i = 0; i < stackTreace.length; i++)
			buffer.append("\t" + stackTreace[i]).append("\n");

		return buffer.toString();
	}
}
