// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.wiki.WikiPage;
import fitnesse.wiki.InMemoryPage;
import fitnesse.http.*;
import fitnesse.testutil.RegexTest;
import fitnesse.FitNesseContext;

public class WhereUsedResponderTest extends RegexTest
{
	private WikiPage root;
	private WikiPage pageTwo;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		root.addPage("PageOne", "PageOne");
		pageTwo = root.addPage("PageTwo", "PageOne");
		pageTwo.addPage("ChildPage", ".PageOne");
	}

	public void testResponse() throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageOne");
		WhereUsedResponder responder = new WhereUsedResponder();

		Response response = responder.makeResponse(new FitNesseContext(root), request);
		MockResponseSender sender = new MockResponseSender();
		response.readyToSend(sender);
		sender.waitForClose(5000);
		
		String content = sender.sentData();
		assertEquals(200, response.getStatus());
		assertHasRegexp("Where Used", content);
		assertHasRegexp(">PageOne<", content);
		assertHasRegexp(">PageTwo<", content);
		assertHasRegexp(">PageTwo\\.ChildPage<", content);
	}
}

