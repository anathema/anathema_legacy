// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.components.*;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class RollbackResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();

		String resource = request.getResource();
		String version = (String) request.getInput("version");

		WikiPage page = new PageCrawler().getPage(context.root, resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);
		PageData data = page.getData(version);

		page.commit(data);

		RecentChanges.updateRecentChanges(context.root, resource);
		response.redirect(resource);

		return response;
	}

}
