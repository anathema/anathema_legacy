// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.wiki.*;
import fitnesse.http.*;
import java.net.SocketException;

public abstract class ChunkingResponder implements Responder
{
	protected WikiPage root;
	public WikiPage page;
	protected HttpRequest request;
	protected ChunkedResponse response;
	protected FitNesseContext context;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		this.context = context;
		this.request = request;
		this.root = context.root;
		response = new ChunkedResponse();
		String resource = request.getResource();
		page = getPageCrawler().getPage(root, resource);
		if(page == null && shouldRespondWith404())
			return new NotFoundResponder().makeResponse(context, request);

		new Thread(new RespondingRunnable(), getClass() + ": Responding Thread").start();

		return response;
	}

	protected boolean shouldRespondWith404()
	{
		return true;
	}

	private void startSending()
	{
		try
		{
			doSending();
		}
		catch(SocketException e)
		{
			// normal. someone stoped the request.
		}
		catch(Exception e)
		{
			// TODO this error should be logged
			e.printStackTrace();
		}
	}

	protected class RespondingRunnable implements Runnable
	{
		public void run()
		{
			while(!response.isReadyToSend())
				Thread.yield(); //todo use a monitor here.
			startSending();
		}
	}

	protected abstract void doSending() throws Exception;
	protected abstract PageCrawler getPageCrawler();
}
