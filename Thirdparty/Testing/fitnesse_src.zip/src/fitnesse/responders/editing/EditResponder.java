// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.components.SaveRecorder;
import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.wikitext.*;
import fitnesse.responders.html.*;
import fitnesse.*;
import java.util.*;

public class EditResponder implements Responder
{
	public static final String CONTENT_INPUT_NAME = "pageContent";
	public static final String SAVE_ID = "saveId";
	public static final String TICKET_ID = "ticketId";

	protected String content;
	protected WikiPage page;
	protected WikiPage root;
	protected PageData pageData;

	public EditResponder()
	{
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		if(request.hasInput("fixture") && !(this instanceof TableWizardResponder))  // TODO I'm not sure how this ugliness came about.
			return new TableWizardResponder().makeResponse(context, request);

		initializeResponder(context.root, request);

		SimpleResponse response = new SimpleResponse();
		String resource = request.getResource();
		if(!new PageCrawler().pageExists(root, resource))
			page = new MockingPageCrawler().getPage(root, resource);
		else
			page = new PageCrawler().getPage(root, resource);

		pageData = page.getData();
		content = createPageContent();

		String html = makeHtml(resource);

		response.setContent(html);
		response.setMaxAge(0);

		return response;
	}

	protected void initializeResponder(WikiPage root, HttpRequest request)
	{
		this.root = root;
	}

	protected String createPageContent() throws Exception
	{
		return pageData.getContent();
	}

	public String makeHtml(String resource) throws Exception
	{
		HtmlPage html = new HtmlPage();
		html.setHtmlTitle("Edit " + resource);
		html.setOnload("document.f." + CONTENT_INPUT_NAME + ".focus()");
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(resource)));
		table.addRow(new TableRow("<!-- Edit -->", makeEditForm(resource)));
		html.addElement(table);
		return html.html();
	}

	public String makeEditForm(String resource) throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form name=\"f\" action=\"" + resource + "\" method=\"post\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"saveData\">");
		buffer.append("<input type=\"hidden\" name=\"" + SAVE_ID + "\" value=\"" + SaveRecorder.newIdNumber() + "\">");
		buffer.append("<input type=\"hidden\" name=\"" + TICKET_ID + "\" value=\"" + SaveRecorder.newTicket() + "\">");
		buffer.append("<textarea name=\"" + CONTENT_INPUT_NAME + "\" style=\"width: 100%\" rows=\"25\" cols=\"70\" tabindex=\"1\">");
		buffer.append(Utils.escapeText(content));
		buffer.append("</textarea><br>");
		buffer.append("<table border=\"0\" width=\"100%\"> ");
		buffer.append("<tr>");
		buffer.append("<td valign=\"top\">");
		buffer.append("  <input type=\"submit\" value=\"Save\" tabindex=\"2\" accesskey=\"s\">&nbsp;&nbsp;&nbsp;");
		buffer.append(pasteTableFromExcelStuff());
		buffer.append(addTableWizard());
		buffer.append("</td>");
		buffer.append("<td align=\"right\" valign=\"top\">");
		buffer.append("&nbsp;");
		buffer.append("</td>");
		buffer.append("</tr>");
		buffer.append("</table>");
		buffer.append("</form>\n");
		buffer.append(addTableWizardForm(resource));
		return buffer.toString();
	}

	private String pasteTableFromExcelStuff() throws Exception
	{
		return "<script src=\"/files/javascript/browserDetection.js\" type=\"text/javascript\"></script>\n" +
		   "<script src=\"/files/javascript/excelPaste.js\" type=\"text/javascript\"></script>";
	}

	private String addTableWizard() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<script>\n" +
		              "  function addFixture()\n" +
		              "  {\n" +
		              "     document.tableWizardForm.text.value = document.f." + CONTENT_INPUT_NAME + ".value;\n" +
		              "     document.tableWizardForm.fixture.value = document.f.fixtureTable.options[document.f.fixtureTable.selectedIndex].value;\n" +
		              "     document.tableWizardForm.submit();\n" +
		              "  }\n" +
		              "</script>\n"
		);


		buffer.append("<br>\n<select name=\"fixtureTable\" onChange=\"addFixture()\">\n  <option value=\"\">- Insert Fixture Table -");
		buffer.append(getTableWizardOptions());
		buffer.append("</select>");
		return buffer.toString();
	}

	private String addTableWizardForm(String resource) throws Exception
	{
		return
		   "<form name=\"tableWizardForm\" action=\"" + resource + "\" method=\"post\">\n" +
		   "	<input type=\"hidden\" name=\"responder\" value=\"tableWizard\">\n" +
		   "	<input type=\"hidden\" name=\"text\">\n" +
		   "	<input type=\"hidden\" name=\"fixture\">\n" +
		   "</form>\n"
		   ;
	}

	private String getTableWizardOptions() throws Exception
	{
		List fixtureNames = FixtureListBuilder.instance().getFixtureNames(this.page);
		StringBuffer buf = new StringBuffer("");
		for(Iterator i = fixtureNames.iterator(); i.hasNext();)
		{
			String s = (String) i.next();
			buf.append("  <option value=\"" + s + "\">" + s + "\n");
		}
		return buf.toString();
	}
}
