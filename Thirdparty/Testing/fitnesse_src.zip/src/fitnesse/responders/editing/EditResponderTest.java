// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.*;
import fitnesse.responders.editing.EditResponder;
import fitnesse.testutil.*;
import fitnesse.http.*;
import fitnesse.wiki.*;
import junit.swingui.TestRunner;

public class EditResponderTest extends RegexTest
{
	private WikiPage root;
	private MockHttpRequest request;
	private Responder responder;
	private SimpleResponse response;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"EditResponderTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("root");
		request = new MockHttpRequest();
		responder = new EditResponder();
	}

	public void testResponse() throws Exception
	{
		root.addPage("ChildPage", "child content with <html>");
		request.setResource("ChildPage");

		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertEquals(200, response.getStatus());

		String body = response.getContent();
		assertHasRegexp("<html>", body);
		assertHasRegexp("<form", body);
		assertHasRegexp("method=\"post\"", body);
		assertHasRegexp("child content with &lt;html&gt;", body);
		assertHasRegexp("<input type=\"hidden\" name=\"responder\"", body);
		assertHasRegexp("<input type=\"hidden\" name=\"" + EditResponder.SAVE_ID + "\"", body);
		assertHasRegexp("<input type=\"hidden\" name=\"" + EditResponder.TICKET_ID + "\"", body);
    assertHasRegexp("<input type=\"submit\" value=\"Save\" tabindex=\"2\" accesskey=\"s\">",body);
	}

	public void testPasteFromExcelExists() throws Exception
	{
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String body = response.getContent();
		assertMatches("browserDetection.js", body);
		assertMatches("excelPaste", body);
	}

	public void testTableWizard() throws Exception
	{
		root.addPage(FixtureListBuilder.FIXTURES_PAGE_NAME, "!fixture FixtureOne\r\nNot.A.Fixture\r\n!fixture FixtureTwo");
		root.addPage("LevelOne", "Level one").addPage(FixtureListBuilder.FIXTURES_PAGE_NAME, "!fixture FixtureThree");
		root.getChildPage("LevelOne").addPage("LevelTwo", "Level two").addPage("LevelThree", "Level three");

		request.setResource("LevelOne.LevelTwo.LevelThree");

		setTestAttributeForPage(new PageCrawler().getPage(root, "LevelOne.LevelTwo.LevelThree"));
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String body = response.getContent();

		assertTrue(body.indexOf("<select name=\"fixtureTable\"") != -1);
		assertMatches("<option value=\"\">- Insert Fixture Table -", body);
		assertMatches("<option value=\"FixtureOne\">FixtureOne", body);
		assertMatches("<option value=\"FixtureTwo\">FixtureTwo", body);
		assertMatches("<option value=\"FixtureThree\">FixtureThree", body);
		assertTrue(body.indexOf("Not.A.Fixture") == -1);
	}

	public void testMissingPageDoesNotGetCreated() throws Exception
	{
		request.setResource("MissingPage");
		responder.makeResponse(new FitNesseContext(root), request);
		assertFalse(root.hasChildPage("MissingPage"));
	}

	public void testMissingLocalPageHasCorrectColor() throws Exception
	{
		request.setResource("NewPage");
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		String pageColor = getBackgroundColorFromHtml(response.getContent());
		assertEquals(RawPage.BG_COLOR, pageColor);
	}

	private String getBackgroundColorFromHtml(String html)
	{
		final String searchKey = "<body bgcolor=\"";
		int index = html.indexOf(searchKey);
		if(index == -1)
			return null;
		else
			return html.substring(index + searchKey.length(), index + searchKey.length() + 7);
	}

	private void setTestAttributeForPage(WikiPage page) throws Exception
	{
		PageData data = page.getData();
		data.setAttribute("Test", "true");
		page.commit(data);
	}
}
