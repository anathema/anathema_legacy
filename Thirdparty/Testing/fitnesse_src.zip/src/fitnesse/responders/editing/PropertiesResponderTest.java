// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.*;
import fitnesse.responders.editing.PropertiesResponder;
import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class PropertiesResponderTest extends RegexTest
{
	private WikiPage root;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
	}

	public void tearDown() throws Exception
	{
	}

	public void testResponse() throws Exception
	{
		WikiPage page = root.addPage("PageOne");
		PageData data = page.getData();
		data.setContent("some content");
		WikiPageProperties properties = data.getAttributes();
		properties.set("Test", "true");
		properties.set(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http://www.fitnesse.org");
		page.commit(data);

		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageOne");

		Responder responder = new PropertiesResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertEquals("max-age=0", response.getHeader("Cache-Control"));

		String content = response.getContent();
		assertHasRegexp("PageOne", content);
		assertHasRegexp("value=\"http://www.fitnesse.org\"", content);
		assertDoesntHaveRegexp("textarea name=\"extensionXml\"", content);
		assertHasRegexp("<input type=\"submit\" value=\"Save\" accesskey=\"s\">", content);

		assertSubString("<input type=\"hidden\" name=\"responder\" value=\"saveProperties\">", content);
	}

	public void testGetVirtualWikiValue() throws Exception
	{
		WikiPage page = root.addPage("PageOne");
		PageData data = page.getData();

		assertEquals("", PropertiesResponder.getVirtualWikiValue(data));

		data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http://www.objectmentor.com");
		assertEquals("http://www.objectmentor.com", PropertiesResponder.getVirtualWikiValue(data));
	}
}
