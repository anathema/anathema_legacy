// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import junit.framework.*;
import fitnesse.responders.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(EditResponderTest.class));
		suite.addTest(new TestSuite(SaveResponderTest.class));
		suite.addTest(new TestSuite(MergeResponderTest.class));
		suite.addTest(new TestSuite(PropertiesResponderTest.class));
		suite.addTest(new TestSuite(SavePropertiesResponderTest.class));
		suite.addTest(new TestSuite(TableWizardResponderTest.class));
		return suite;
	}
}
