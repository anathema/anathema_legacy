// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.responders.editing;

import fitnesse.*;
import fitnesse.responders.NotFoundResponder;
import fitnesse.components.*;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class SavePropertiesResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		String resource = request.getResource();
		WikiPage page = new PageCrawler().getPage(context.root, resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);
		PageData data = page.getData();
		saveAttributes(request, data);
		WikiPage.CommitRecord commitRecord = page.commit(data);
		response.addHeader("Previous-Version", commitRecord.perviousVersion);
		RecentChanges.updateRecentChanges(context.root, resource);
		response.redirect(resource);

		return response;
	}

	private void saveAttributes(HttpRequest request, PageData data) throws Exception
	{
		String[] attrs = WikiPage.STANDARD_ATTRIBUTES;
		for(int i = 0; i < attrs.length; i++)
		{
			if(isChecked(request, attrs[i]))
				data.setAttribute(attrs[i]);
			else
				data.removeAttribute(attrs[i]);
		}
		String value = HttpRequest.decodeContent((String)request.getInput(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE));
		if(!value.equals(data.getAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE)))
			data.getWikiPage().resetVirtualCoupling();
		if("".equals(value) || value == null)
			data.removeAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE);
		else
			data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, value);
	}

	private boolean isChecked(HttpRequest request, String name)
	{
		return (request.getInput(name) != null);
	}

}

