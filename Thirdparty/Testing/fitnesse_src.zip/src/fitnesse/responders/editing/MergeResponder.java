// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.wikitext.Utils;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.components.SaveRecorder;
import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.responders.editing.EditResponder;

public class MergeResponder implements Responder
{
	private HttpRequest request;
	private String newContent;
	private String existingContent;
	private String resource;

	public MergeResponder(HttpRequest request)
	{
		this.request = request;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		resource = this.request.getResource();
		WikiPage page = new PageCrawler().getPage(context.root, resource);
		existingContent = page.getData().getContent();
		newContent = (String) this.request.getInput(EditResponder.CONTENT_INPUT_NAME);
		newContent = HttpRequest.decodeContent(newContent);

		response.setContent(makePageHtml());

		return response;
	}

	private String makePageHtml() throws Exception
	{
		HtmlPage page = new HtmlPage();
		page.setHtmlTitle("Merge " + resource);
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(resource)));
		table.addRow(new TableRow("<!-- Merge -->", makeRightColumn()));

		page.addElement(table);
		return page.html();
	}

	private String makeRightColumn()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action=\"" + resource + "\" method=\"post\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"saveData\">");
		buffer.append("<input type=\"hidden\" name=\"" + EditResponder.SAVE_ID + "\" value=\"" + SaveRecorder.newIdNumber() + "\">");
		buffer.append("<input type=\"hidden\" name=\"" + EditResponder.TICKET_ID + "\" value=\"" + SaveRecorder.newTicket() + "\">");
		buffer.append("<center>This page has been recently modified.  You may want to merge existing page content into your changes.</center>");
		buffer.append("<table width=\"100%\"><tr><th>Your Changes</th><th>Existing Content (read only)</th></tr><tr><td width=\"50%\">");
		buffer.append("<textarea name=\"" + EditResponder.CONTENT_INPUT_NAME + "\" style=\"width: 100%\" rows=\"25\" cols=\"50\">");
		buffer.append(newContent);
		buffer.append("</textarea>");
		buffer.append("</td><td width=\"50%\">");
		buffer.append("<textarea name=\"oldContent\" style=\"width: 100%\" rows=\"25\" cols=\"50\" readonly>");
		buffer.append(Utils.escapeText(existingContent));
		buffer.append("</textarea>");
		buffer.append("</td></tr></table>");
		addHiddenAttributes(buffer);
		buffer.append("<input type=\"submit\" value=\"Save\" accesskey=\"s\">");
		buffer.append("</form>");
		return buffer.toString();
	}

	private void addHiddenAttributes(StringBuffer buffer)
	{
		for(int i = 0; i < WikiPage.STANDARD_ATTRIBUTES.length; i++)
		{
			String attribute = WikiPage.STANDARD_ATTRIBUTES[i];
			if(request.hasInput(attribute))
				buffer.append("<input type=\"hidden\" name=\"" + attribute + "\" value=\"On\">");
		}
	}
}
