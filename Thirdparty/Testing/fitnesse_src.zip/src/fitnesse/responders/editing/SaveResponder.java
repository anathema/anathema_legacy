// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.*;
import fitnesse.responders.editing.*;
import fitnesse.components.*;
import fitnesse.http.*;
import fitnesse.wiki.*;

public class SaveResponder implements Responder
{
	public SaveResponder()
	{
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		Response response = new SimpleResponse();

		String resource = request.getResource();
		WikiPage page = new PageCrawler().getPage(context.root, resource);
		if(page == null)
			page = context.root.addPage(resource, "");
		String saveIdString = (String) request.getInput(EditResponder.SAVE_ID);
		String ticketIdString = (String) request.getInput(EditResponder.TICKET_ID);

		PageData data = page.getData();
		long saveId = Long.parseLong(saveIdString);
		long ticketId = Long.parseLong(ticketIdString);
		if(SaveRecorder.changesShouldBeMerged(saveId, ticketId, data))
			response = new MergeResponder(request).makeResponse(context, request);
		else
		{
			String newContent = (String) request.getInput(EditResponder.CONTENT_INPUT_NAME);
			String decodedContent = HttpRequest.decodeContent(newContent);
			setData(data, decodedContent, ticketId);
			WikiPage.CommitRecord commitRecord = page.commit(data);
			response.addHeader("Previous-Version", commitRecord.perviousVersion);
			RecentChanges.updateRecentChanges(context.root, resource);
			response.redirect(resource);
		}

		return response;
	}

	private void setData(PageData data, String escapedContent, long ticket) throws Exception
	{
		data.setContent(escapedContent);
		data.setAttribute(EditResponder.TICKET_ID, ticket + "");
		SaveRecorder.pageSaved(data);
	}

}
