// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;
import fitnesse.responders.editing.*;
import fitnesse.testutil.RegexTest;

public class MergeResponderTest extends RegexTest
{
	private WikiPage source;
	private MockHttpRequest request;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"MerResponderTest"});
	}

	public void setUp() throws Exception
	{
		source = InMemoryPage.makeRoot("RooT");
		source.addPage("SimplePage", "this is SimplePage");
		request = new MockHttpRequest();
		request.setResource("SimplePage");
		request.addInput(EditResponder.SAVE_ID, "");
		request.addInput(EditResponder.CONTENT_INPUT_NAME, "some new content");
	}

	public void tearDown() throws Exception
	{
	}

	public void testHtml() throws Exception
	{
		Responder responder = new MergeResponder(request);
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(source), new MockHttpRequest());

		assertHasRegexp("textarea name=\\\"" + EditResponder.CONTENT_INPUT_NAME + "\\\"", response.getContent());
		assertHasRegexp("this is SimplePage", response.getContent());
		assertHasRegexp("textarea name=\\\"oldContent\\\"", response.getContent());
		assertHasRegexp("some new content", response.getContent());
	}

	public void testAttributeValues() throws Exception
	{
		request.addInput("Edit", "On");
		request.addInput("Test", "On");
		request.addInput("Search", "On");
		Responder responder = new MergeResponder(request);
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(source), new MockHttpRequest());

		assertHasRegexp("type=\"hidden\"", response.getContent());
		assertHasRegexp("name=\"Edit\"", response.getContent());
		assertHasRegexp("name=\"Test\"", response.getContent());
		assertHasRegexp("name=\"Search\"", response.getContent());
	}
}