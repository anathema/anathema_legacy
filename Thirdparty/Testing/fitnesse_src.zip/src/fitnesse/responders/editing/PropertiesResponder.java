// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.responders.NotFoundResponder;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class PropertiesResponder implements Responder
{
	private WikiPage page;
	public PageData pageData;
	private String resource;

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		resource = request.getResource();
		if(new PageCrawler().pageExists(context.root, resource) == false)
			page = new MockingPageCrawler().getPage(context.root, resource);
		else
			page = new PageCrawler().getPage(context.root , resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);

		pageData = page.getData();
		String html = makeHtml();

		response.setContent(html);
		response.setMaxAge(0);

		return response;
	}

	private String makeHtml() throws Exception
	{

		HtmlPage page = new HtmlPage();
		page.setHtmlTitle("Properties " + resource);
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.plain(resource)));
		table.addRow(new TableRow("<!--Properties-->", makeRightColumn()));
		page.addElement(table);
		return page.html();
	}

	private void makeAttributeCheckbox(StringBuffer buffer, String attribute) throws Exception
	{
		buffer.append("<tr><td align=\"right\">");
		buffer.append(attribute);
		buffer.append("</td><td>");
		buffer.append("<input type=\"checkbox\" name=\"" + attribute + "\" "
			+ (pageData.hasAttribute(attribute) ? "Checked" : "")
			+ ">");
		buffer.append("</td></tr>");
	}

	private String makeRightColumn() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action=\"" + resource + "\" method=\"post\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"saveProperties\">");
		buffer.append("<table>");
		for(int i = 0; i < WikiPage.STANDARD_ATTRIBUTES.length; i++)
		{
			String attribute = WikiPage.STANDARD_ATTRIBUTES[i];
			makeAttributeCheckbox(buffer, attribute);
		}
		buffer.append("<tr><td align=\"right\">VirtualWiki URL</td><td><input type=\"text\" size=\"40\" name=\"VirtualWiki\" value=\""
		               + getVirtualWikiValue(pageData) + "\"></td></tr>");
		buffer.append("</table>");
		buffer.append("<br><input type=\"submit\" value=\"Save\" accesskey=\"s\">");
		buffer.append("</form>");
		return buffer.toString();
	}

	public static String getVirtualWikiValue(PageData data) throws Exception
	{
		String value = data.getAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE);
		if(value == null)
			return "";
		else
			return value;
	}

}
