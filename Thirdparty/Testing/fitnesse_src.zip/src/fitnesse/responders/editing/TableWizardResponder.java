// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.components.*;
import fitnesse.responders.editing.EditResponder;

public class TableWizardResponder extends EditResponder
{
	private HttpRequest request;

	protected void initializeResponder(WikiPage root, HttpRequest request)
	{
		this.root = root;
		this.request = request;
	}

	protected String createPageContent() throws Exception
	{
		String textAreaContent = HttpRequest.decodeContent((String)request.getInput("text"));
		String fixtureName     = HttpRequest.decodeContent((String)request.getInput("fixture"));
		String template = createFixtureTableTemplate(fixtureName);
		if(!template.equals(""))
			template = "\n" + template;
		return textAreaContent + template;
	}

	private String createFixtureTableTemplate(String fixtureName) throws Exception
	{
		String commandLine = createCommandLine(page, fixtureName);
		CommandRunner runner = new CommandRunner(commandLine, null);
		runner.run();
		return runner.getOutput() + runner.getError();
	}

	protected String createCommandLine(WikiPage page, String fixtureName) throws Exception
	{
		String classpath = ClassPathBuilder.instance().getClasspath(page);

		return "java -cp " + classpath + " fitnesse.FixtureTemplateCreator " + fixtureName;
	}
}
