// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.editing;

import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.responders.editing.SavePropertiesResponder;
import fitnesse.testutil.*;
import java.util.List;

public class SavePropertiesResponderTest extends RegexTest
{
	private WikiPage root;
	private MockHttpRequest request;
	private WikiPage page;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
	}

	private void createRequest() throws Exception
	{
		page = root.addPage("PageOne", "");

		request = new MockHttpRequest();
		request.addInput("Test", "on");
		request.addInput("Properties", "on");
		request.addInput("Search", "on");
		request.addInput(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http%3A%2F%2Fwww.fitnesse.org");
		request.setResource("PageOne");
	}

	public void tearDown() throws Exception
	{
	}

	public void testClearChildrenWhenVWisCleared() throws Exception
	{
		WikiPage linker = createSimpleVirtualLink();

		// new request to get rid of the virtual wiki link
		SavePropertiesResponder responder = new SavePropertiesResponder();
		request = new MockHttpRequest();
		request.addInput(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "");
		request.setResource("LinkerPage");
		responder.makeResponse(new FitNesseContext(root), request);
		assertEquals(0, linker.getChildren().size());
	}

	private WikiPage createSimpleVirtualLink() throws Exception
	{
		WikiPage linkee = root.addPage("LinkeePage", "blah");
		linkee.addPage("ChildPageOne", "childPage");
		WikiPage linkee2 = root.addPage("LinkeePageTwo", "blah");
		linkee2.addPage("ChildPageTwo", "childPage");
		WikiPage linker = root.addPage("LinkerPage", "blah");
    FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)linker, linkee);

		List children = linker.getVirtualCoupling().getChildren();
		assertEquals(1, children.size());
		WikiPage child = (WikiPage)children.get(0);
		assertEquals("ChildPageOne", child.getName());
		return linker;
	}

	public void testClearChildrenChangingVW() throws Exception
	{
		WikiPage linker = createSimpleVirtualLink();
		assertTrue(! (linker.getVirtualCoupling() instanceof NullVirtualCouplingPage));

		// new request to get rid of the virtual wiki link
		SavePropertiesResponder responder = new SavePropertiesResponder();
		request = new MockHttpRequest();
		request.addInput(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http://localhost:" + FitnesseUtil.port + "/LinkeePageTwo");
		request.setResource("LinkerPage");
		responder.makeResponse(new FitNesseContext(root), request);

		assertTrue(linker.getVirtualCoupling() instanceof NullVirtualCouplingPage);
	}

	public void testResponse() throws Exception
	{
		createRequest();

		Responder responder = new SavePropertiesResponder();
		Response response = responder.makeResponse(new FitNesseContext(root), request);

		PageData data = page.getData();
		assertEquals("http://www.fitnesse.org", data.getAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE));
		assertTrue(data.hasAttribute("Test"));
		assertTrue(data.hasAttribute("Properties"));
		assertTrue(data.hasAttribute("Search"));
		assertFalse(data.hasAttribute("Edit"));

		assertEquals(303, response.getStatus());
		assertEquals("PageOne", response.getHeader("Location"));
	}

}
