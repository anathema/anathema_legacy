// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.responders.html.*;
import fitnesse.components.SearchObserver;
import fitnesse.wiki.*;

public abstract class ResultResponder extends ChunkingResponder implements SearchObserver
{
	private int hits = 0;

	protected PageCrawler getPageCrawler()
	{
		return new PageCrawler();
	}

	protected void doSending() throws Exception
	{
		HtmlPage page = new HtmlPage();
		page.setHtmlTitle(getHtmlTitle());
		Table table = new Table();
		table.addRow(TableRow.titleRow(getTitle()));
		page.addElement(table);
		response.add(page.pageHeader() + page.pageBody() + "<ul>\n");
		startSearching();
		response.add("</ul>\n" + getPageFooterInfo(hits).replaceAll("</html>", "") + "\n" + page.pageFooter());
		response.closeAll();
	}

	public void hit(WikiPage page) throws Exception
	{
		hits++;
		response.add("<li><a href=\"" + new PageCrawler().getQualifiedName(page) + "\">" + new PageCrawler().getQualifiedName(page) + "</a>\n");
	}

	protected abstract String getHtmlTitle() throws Exception;

	protected abstract String getTitle() throws Exception;

	protected abstract String getPageFooterInfo(int hits) throws Exception;

	protected abstract void startSearching() throws Exception;
}

