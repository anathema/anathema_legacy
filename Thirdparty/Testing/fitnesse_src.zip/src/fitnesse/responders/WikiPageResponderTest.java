// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.testutil.*;
import fitnesse.http.*;
import fitnesse.wiki.*;
import junit.swingui.TestRunner;

public class WikiPageResponderTest extends RegexTest
{
	private WikiPage root;
	private SimpleResponse response;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"WikiPageResponderTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("root");
	}

	public void tearDown() throws Exception
	{
	}

	public void testResponse() throws Exception
	{
		root.addPage("ChildPage", "child content");
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("ChildPage");

		Responder responder = new WikiPageResponder();
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);

		assertEquals(200, response.getStatus());

		String body = response.getContent();

		assertHasRegexp("<html>", body);
		assertHasRegexp("<body", body);
		assertHasRegexp("child content", body);
		assertHasRegexp("<a href=\"ChildPage\\?whereUsed\">ChildPage</a>", body);
		assertHasRegexp("Cache-Control: max-age=0", response.makeHttpHeaders());
	}

	public void testAttributeButtons() throws Exception
	{
		root.addPage("NormalPage", "");
		WikiPage noButtonsPage = root.addPage("NoButtonPage", "");
		for(int i = 0; i < WikiPage.STANDARD_ATTRIBUTES.length; i++)
		{
			String attribute = WikiPage.STANDARD_ATTRIBUTES[i];
			PageData data = noButtonsPage.getData();
			data.removeAttribute(attribute);
			noButtonsPage.commit(data);
		}

		SimpleResponse response = requestPage("NormalPage");
		assertHasRegexp("<!-- Edit button -->", response.getContent());
		assertHasRegexp("<!-- Search button -->", response.getContent());
		assertHasRegexp("<!-- Versions button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Suite button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Test button -->", response.getContent());

		response = requestPage("NoButtonPage");
		assertDoesntHaveRegexp("<!-- Edit button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Search button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Versions button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Suite button -->", response.getContent());
		assertDoesntHaveRegexp("<!-- Test button -->", response.getContent());
	}

	public void testHeadersAndFooters() throws Exception
	{
		root.addPage("NormalPage", "normal");
		root.addPage("TestPage", "test page");
		root.addPage("PageHeader", "header");
		root.addPage("PageFooter", "footer");
		root.addPage("SetUp", "setup");
		root.addPage("TearDown", "teardown");

		SimpleResponse response = requestPage("NormalPage");
		String content = response.getContent();
		assertHasRegexp("header", content);
		assertHasRegexp("normal", content);
		assertHasRegexp("footer", content);
		assertDoesntHaveRegexp("setup", content);
		assertDoesntHaveRegexp("teardown", content);

		response = requestPage("TestPage");
		content = response.getContent();
		assertHasRegexp("header", content);
		assertHasRegexp("test page", content);
		assertHasRegexp("footer", content);
		assertHasRegexp("setup", content);
		assertHasRegexp("teardown", content);
	}

	private SimpleResponse requestPage(String name) throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource(name);
		Responder responder = new WikiPageResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		return response;
	}

	public void testShouldGetVirtualPage() throws Exception
	{
		WikiPage pageOne = root.addPage("TargetPage", "some content");
		pageOne.addPage("ChildPage", "child content");
		WikiPage linkerPage = root.addPage("LinkerPage", "linker content");
		FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)linkerPage, pageOne);

		MockHttpRequest request = new MockHttpRequest();
		request.setResource("LinkerPage.ChildPage");

		Responder responder = new WikiPageResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);

		assertSubString("child content",response.getContent());
	}
}
