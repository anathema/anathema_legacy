// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import junit.swingui.TestRunner;
import fitnesse.testutil.RegexTest;
import fitnesse.http.*;
import fitnesse.FitNesseContext;

public class SearchFormResponderTest extends RegexTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"SearchFormResponderTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testHtml() throws Exception
	{
		SearchFormResponder responder = new SearchFormResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(null, new MockHttpRequest());
		assertHasRegexp("form", response.getContent());
		assertHasRegexp("input", response.getContent());

		assertSubString("<input type=\"hidden\" name=\"responder\" value=\"search\">", response.getContent());
	}
}
