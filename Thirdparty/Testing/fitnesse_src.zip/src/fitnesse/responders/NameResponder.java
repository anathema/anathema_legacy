// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.wiki.*;
import fitnesse.http.*;
import java.util.*;

public class NameResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		response.setContentType("text/plain");
		WikiPage parentPage = context.root;
		if(request.getResource().equals("") == false)
		{
			parentPage = new PageCrawler().getPage(context.root, request.getResource());
			if(parentPage == null)
				return new NotFoundResponder().makeResponse(context, request);
		}
		List children = parentPage.getChildren();
		StringBuffer contents = new StringBuffer();
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage child = (WikiPage) iterator.next();
			contents.append(child.getName() + "\n");
		}
		response.setContent(contents.toString());
		return response;
	}

}
