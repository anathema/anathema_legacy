// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.components.Searcher;
import fitnesse.http.HttpRequest;

public class SearchResponder extends ResultResponder
{
	private String getSearchString()
	{
		String searchString = HttpRequest.decodeContent((String) request.getInput("searchString"));
		return searchString;
	}

	protected String getPageFooterInfo(int hits) throws Exception
	{
		return "Found " + hits + " results for your search.";
	}

	protected String getHtmlTitle() throws Exception
	{
		return getTitle();
	}

	protected String getTitle() throws Exception
	{
		return "Search Results for '" + getSearchString() + "'";
	}

	protected void startSearching() throws Exception
	{
		String searchString = getSearchString();
		Searcher searcher = new Searcher(searchString, root);
		searcher.search(this);
	}

	protected boolean shouldRespondWith404()
	{
		return false;
	}
}
