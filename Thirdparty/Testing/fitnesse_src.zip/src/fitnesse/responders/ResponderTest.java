// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.testutil.*;
import fitnesse.wiki.*;
import fitnesse.http.MockHttpRequest;
import fitnesse.Responder;

// todo: make a similar version that doesn't use FileSystemPage
public abstract class ResponderTest extends RegexTest
{
	protected String fitnesseRoot = "TestRooT";
	protected WikiPage root;
	protected MockHttpRequest request;
	protected Responder responder;

	public void setUp() throws Exception
	{
		root = FileSystemPage.makeRoot(".", fitnesseRoot);
		request = new MockHttpRequest();
		responder = responderInstance();
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(fitnesseRoot);
	}

	// Return an instance of the Responder being tested.
	protected abstract Responder responderInstance();
}
