// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.http.*;

import junit.swingui.TestRunner;

import java.util.*;

public class VersionSelectionResponderTest extends RegexTest
{
	private WikiPage page;
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"VersionSelectionResponderTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		page = root.addPage("PageOne", "some content");
	}

	public void tearDown() throws Exception
	{
	}

	public void testGetVersionsList() throws Exception
	{
		Set set = new HashSet();
		set.add("123");
		set.add("456");
		set.add("111");
		set.add("122");

		PageData data = new PageData(page);
		data.addVersionNames(set);

		List list = VersionSelectionResponder.getVersionsList(data);
		assertEquals("111", list.get(3));
		assertEquals("122", list.get(2));
		assertEquals("123", list.get(1));
		assertEquals("456", list.get(0));
	}

	public void testConvertVersionNameToAge() throws Exception
	{
		GregorianCalendar now = new GregorianCalendar(2003, 0, 1, 00, 00, 01);
		GregorianCalendar tenSeconds = new GregorianCalendar(2003, 0, 1, 00, 00, 11);
		GregorianCalendar twoMinutes = new GregorianCalendar(2003, 0, 1, 00, 02, 01);
		GregorianCalendar fiftyNineSecs = new GregorianCalendar(2003, 0, 1, 00, 01, 00);
		GregorianCalendar oneHour = new GregorianCalendar(2003, 0, 1, 01, 00, 01);
		GregorianCalendar fiveDays = new GregorianCalendar(2003, 0, 6, 00, 00, 01);
		GregorianCalendar years = new GregorianCalendar(2024, 0, 1, 00, 00, 01);

		assertEquals("10 seconds", VersionSelectionResponder.howLongAgoString(now, tenSeconds));
		assertEquals("2 minutes", VersionSelectionResponder.howLongAgoString(now, twoMinutes));
		assertEquals("59 seconds", VersionSelectionResponder.howLongAgoString(now, fiftyNineSecs));
		assertEquals("1 hour", VersionSelectionResponder.howLongAgoString(now, oneHour));
		assertEquals("5 days", VersionSelectionResponder.howLongAgoString(now, fiveDays));
		assertEquals("21 years", VersionSelectionResponder.howLongAgoString(now, years));
	}

	public void testConvertVersionNameIntoDate() throws Exception
	{
		Calendar date = VersionSelectionResponder.convertToDate("20030101153904");
		assertEquals(2003, date.get(Calendar.YEAR));
		assertEquals(Calendar.JANUARY, date.get(Calendar.MONTH));
		assertEquals(1, date.get(Calendar.DAY_OF_MONTH));
		assertEquals(15, date.get(Calendar.HOUR_OF_DAY));
		assertEquals(39, date.get(Calendar.MINUTE));
		assertEquals(4, date.get(Calendar.SECOND));
	}

	public void testMakeReponder() throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageOne");

		Responder responder = new VersionSelectionResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);

		assertHasRegexp("<select name=\"version\">", response.getContent());
		assertHasRegexp("<form", response.getContent());
		assertHasRegexp("action=\"PageOne\"", response.getContent());
		assertSubString("<input type=\"hidden\" name=\"responder\" value=\"viewVersion\">", response.getContent());
	}
}
