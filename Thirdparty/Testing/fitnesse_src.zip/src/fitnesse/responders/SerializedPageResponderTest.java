// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;
import fitnesse.testutil.FileUtil;

import java.io.*;

public class SerializedPageResponderTest extends TestCase
{
	private final String RootPath = "TestRooT";

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"SerializedPageResponderTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(RootPath);
	}

	public void testWithInMemory() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		Object obj = doSetUpWith(root, "bones");
		doTestWith(obj);

	}

	public void testWithFileSystem() throws Exception
	{
		WikiPage root = FileSystemPage.makeRoot(".", RootPath);
		Object obj = doSetUpWith(root, "bones");
		FileUtil.deleteFileSystemDirectory(RootPath);
		doTestWith(obj);
	}

	private void doTestWith(Object obj) throws Exception
	{
		assertNotNull(obj);
		assertEquals(true, obj instanceof ProxyPage);
		WikiPage page = (WikiPage) obj;
		assertEquals("PageOne", page.getName());
	}

	private Object doSetUpWith(WikiPage root, String proxyType) throws Exception
	{
		WikiPage page1 = root.addPage("PageOne", "this is page one");
		PageData data = page1.getData();
		data.setAttribute("Attr1", "true");
		page1.commit(data);
		page1.addPage("ChildOne", "this is child one");

		MockHttpRequest request = new MockHttpRequest();
		request.addInput("type", proxyType);
		request.setResource("PageOne");

		return getObject(root, request);

	}

	private Object getObject(WikiPage root, MockHttpRequest request) throws Exception
	{
		Responder responder = new SerializedPageResponder();
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);

		ObjectInputStream ois = new ObjectInputStream(new ByteArrayInputStream(response.getContentBytes()));
		Object obj = ois.readObject();
		return obj;
	}

	public void testGetContentAndAttributes() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		Object obj = doSetUpWith(root, "meat");
		assertNotNull(obj);
		assertTrue(obj instanceof PageData);
		PageData data = (PageData) obj;

		assertEquals("this is page one", data.getContent());

		WikiPageProperties props = data.getAttributes();
		assertEquals("true", props.get("Attr1"));
	}

	public void testGetVersionOfPageData() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page = root.addPage("PageOne", "some content");
		WikiPage.CommitRecord commitRecord = page.commit(page.getData());

		MockHttpRequest request = new MockHttpRequest();
		request.addInput("type", "meat");
		request.addInput("version", commitRecord.perviousVersion);
		request.setResource("PageOne");

		Object obj = getObject(root, request);
		assertEquals(PageData.class, obj.getClass());
		PageData data = (PageData) obj;
		assertEquals("some content", data.getContent());
	}
}
