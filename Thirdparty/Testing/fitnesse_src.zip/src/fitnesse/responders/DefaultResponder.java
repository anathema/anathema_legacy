// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.*;
import fitnesse.responders.html.*;

public class DefaultResponder implements Responder
{
	public DefaultResponder()
	{
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		HtmlPage page = makeHtmlPage();
		response.setContent(page.html());
		return response;
	}

	private HtmlPage makeHtmlPage() throws Exception
	{
		HtmlPage page = new HtmlPage();
		page.setHtmlTitle("Default Responder");
		Table table = new Table();
		table.addRow(TableRow.titleRow("Default Responder"));
		table.addRow(new TableRow("", content()));
		page.addElement(table);
		return page;
	}

	private String content()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("This is the DefaultResponder page.<br>");
		buffer.append("Because you can see this page something has gone wrong.<br>");
		buffer.append("If you continue to get this page, please let us know how.<br>");
		buffer.append("Thanks,<br>");
		buffer.append("<ul><li><a href=\"mailto:micah@objectmentor.com\">The FitNesse development team.</a></ul>");
		return buffer.toString();
	}

}
