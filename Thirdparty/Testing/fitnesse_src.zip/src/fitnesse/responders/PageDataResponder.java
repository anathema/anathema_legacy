// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.wiki.*;
import fitnesse.http.*;

public class PageDataResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		String qualifiedName = request.getResource();

		PageCrawler pageCrawler = new PageCrawler();
		WikiPage requestedPage = pageCrawler.getPage(context.root, qualifiedName);
		if(requestedPage == null)
			return new NotFoundResponder().makeResponse(context, request);

		SimpleResponse response = new SimpleResponse();
		response.setContent(requestedPage.getData().getContent());
		return response;
	}

}
