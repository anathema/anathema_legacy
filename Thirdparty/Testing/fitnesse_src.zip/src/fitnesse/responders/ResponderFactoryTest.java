// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.Responder;
import fitnesse.responders.files.*;
import fitnesse.responders.refactoring.*;
import fitnesse.responders.editing.*;
import fitnesse.responders.run.*;
import fitnesse.testutil.FitnesseUtil;
import fitnesse.http.MockHttpRequest;
import fitnesse.wiki.*;
import junit.framework.TestCase;

public class ResponderFactoryTest extends TestCase
{
	private ResponderFactory factory;
	private MockHttpRequest request;
	private MockWikiPage nonExistantPage;
	private WikiPage root;

	public void setUp() throws Exception
	{
		factory = new ResponderFactory(".");
		request = new MockHttpRequest();
		root = InMemoryPage.makeRoot("root");
		nonExistantPage = new MockWikiPage();
	}

	public void testGetResponderKey() throws Exception
	{
		checkResponderKey("railroad", "railroad");
		checkResponderKey("responder=railroad", "railroad");
		checkResponderKey("", "");
	}

	private void checkResponderKey(String queryString, String key)
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setQueryString(queryString);
		assertEquals(key, factory.getResponderKey(request));
	}

	public void testWikiPageResponder() throws Exception
	{
		request.setResource("SomePage");
		assertResponderType(WikiPageResponder.class, root);
		request.setResource("");
		assertResponderType(WikiPageResponder.class, root);
    request.setResource("root");
    assertResponderType(WikiPageResponder.class, root);
	}

	public void testRefactorPageResponder() throws Exception
	{
		assertResponderTypeMatchesInput("refactor", RefactorPageResponder.class);
	}

	public void testDeletePageResponder() throws Exception
	{
		assertResponderTypeMatchesInput("deletePage", DeletePageResponder.class);
	}

	public void testRenamePageResponder() throws Exception
	{
		assertResponderTypeMatchesInput("renamePage", RenamePageResponder.class);
	}

	public void testEditResponder() throws Exception
	{
		request.addInput("responder", "edit");
		request.setResource("SomePage");
		assertResponderType(EditResponder.class, root);
		assertResponderType(EditResponder.class, nonExistantPage);
	}

	public void testPageDataResponder() throws Exception
	{
		request.addInput("responder", "pageData");
		request.setResource("SomePage");
		assertResponderType(PageDataResponder.class, root);
	}

	public void testSaveResponder() throws Exception
	{
		assertResponderTypeMatchesInput("saveData", SaveResponder.class);
	}

	public void testRunResponder() throws Exception
	{
		assertResponderTypeMatchesInput("start", RunResponder.class);
	}

	public void testTestResponder() throws Exception
	{
		assertResponderTypeMatchesInput("test", TestResponder.class);
	}

	public void testSuiteResponder() throws Exception
	{
		assertResponderTypeMatchesInput("suite", SuiteResponder.class);
	}

	public void testFileResponder() throws Exception
	{
		request.setResource("files/someFile");
		assertResponderType(FileResponder.class, nonExistantPage);
	}

	public void testSearchFormResponder() throws Exception
	{
		assertResponderTypeMatchesInput("searchForm", SearchFormResponder.class);
	}

	public void testSearchResponder() throws Exception
	{
		assertResponderTypeMatchesInput("search", SearchResponder.class);
	}

	public void testSerializedPageResponder() throws Exception
	{
		assertResponderTypeMatchesInput("proxy", SerializedPageResponder.class);
	}

	public void testVersionSelectionResponder() throws Exception
	{
		assertResponderTypeMatchesInput("versions", VersionSelectionResponder.class);
	}

	public void testVersionResponder() throws Exception
	{
		assertResponderTypeMatchesInput("viewVersion", VersionResponder.class);
	}

	public void testRollbackResponder() throws Exception
	{
		assertResponderTypeMatchesInput("rollback", RollbackResponder.class);
	}

	public void testNameReponder() throws Exception
	{
		assertResponderTypeMatchesInput("names", NameResponder.class);
	}

	public void testUploadResponder() throws Exception
	{
		assertResponderTypeMatchesInput("upload", UploadResponder.class);
	}

	public void testCreateDirectoryResponder() throws Exception
	{
		assertResponderTypeMatchesInput("createDir", CreateDirectoryResponder.class);
	}

	public void testDeleteFileResponder() throws Exception
	{
		assertResponderTypeMatchesInput("deleteOrRenameFile", DeleteFileResponder.class);
	}

	public void testCreatePropertiesResponder() throws Exception
	{
		assertResponderTypeMatchesInput("properties", PropertiesResponder.class);
	}

	public void testCreateSavePropertiesResponder() throws Exception
	{
		assertResponderTypeMatchesInput("saveProperties", SavePropertiesResponder.class);
	}

	public void testCreateWhereUsedResponder() throws Exception
	{
		assertResponderTypeMatchesInput("whereUsed", WhereUsedResponder.class);
	}

	public void testCreateMovePageResponer() throws Exception
	{
		assertResponderTypeMatchesInput("movePage", MovePageResponder.class);
	}

	public void testCreateTableWizardResponder() throws Exception
	{
		assertResponderTypeMatchesInput("tableWizard", TableWizardResponder.class);
	}

	public void testSocketCatcher() throws Exception
	{
		assertResponderTypeMatchesInput("socketCatcher", SocketCatcher.class);
	}

	public void testWillDisplayVirtualPages() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page1 = root.addPage("PageOne");
		page1.addPage("ChildOne", "child content");
		WikiPage page2 = root.addPage("PageTwo");
		FitnesseUtil.bindVirtualLinkToPage((InMemoryPage)page2, page1);
		request.setResource("PageTwo.ChildOne");
		assertResponderType(WikiPageResponder.class, root);
	}

	private void assertResponderType(Class expectedClass, WikiPage page) throws Exception
	{
		Responder responder = factory.makeResponder(request, page);
		assertEquals(expectedClass, responder.getClass());
	}

	private void assertResponderTypeMatchesInput(String responderType, Class responderClass) throws Exception
	{
		request.addInput("responder", responderType);
		assertResponderType(responderClass, root);
	}
}
