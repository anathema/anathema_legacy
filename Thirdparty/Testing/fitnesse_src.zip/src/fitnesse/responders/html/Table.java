// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import java.util.*;

public class Table extends HtmlElement
{

	private List rows = new ArrayList();

	public String html() throws Exception
	{
		StringBuffer html = new StringBuffer();
		html.append("<table width=\"100%\" id=\"mainTable\">").append(endl);
		for(Iterator iterator = rows.iterator(); iterator.hasNext();)
		{
			TableRow tableRow = (TableRow) iterator.next();
			html.append(tableRow.html());
		}
		html.append("</table>");

		return html.toString();
	}

	public void addRow(TableRow row)
	{
		rows.add(row);
	}
}
