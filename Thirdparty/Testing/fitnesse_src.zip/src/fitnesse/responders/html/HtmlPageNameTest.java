// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import fitnesse.testutil.RegexTest;

public class HtmlPageNameTest extends RegexTest
{
	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testOneWord() throws Exception
	{
		HtmlPageName wpn = HtmlPageName.plain("SomePage");
		String html = wpn.html();
		assertEquals("SomePage", html);
	}

	public void testTwoWords() throws Exception
	{
		HtmlPageName wpn = HtmlPageName.plain("ParentPage.ChildPage");
		String html = wpn.html();
		assertEquals("<font size=\"3\"><a href=\"ParentPage\">ParentPage</a>.</font><br>ChildPage", html);
	}

	public void testOneWordWhereUsed() throws Exception
	{
		HtmlPageName wpn = HtmlPageName.whereUsed("SomePage");
		String html = wpn.html();
		assertEquals("<a href=\"SomePage?whereUsed\">SomePage</a>", html);
	}

	public void testTwoWordsWhereUsed() throws Exception
	{
		HtmlPageName wpn = HtmlPageName.whereUsed("ParentPage.ChildPage");
		String html = wpn.html();
		String expected = "<font size=\"3\"><a href=\"ParentPage\">ParentPage</a>.</font><br>" +
		  "<a href=\"ParentPage.ChildPage?whereUsed\">ChildPage</a>";
		assertEquals(expected, html);
	}
}
