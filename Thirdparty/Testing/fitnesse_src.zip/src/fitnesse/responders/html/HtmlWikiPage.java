// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.responders.html;

import fitnesse.wiki.*;

public class HtmlWikiPage
{
	public static final boolean NO_NEW_WINDOW = false;
	private PageData pageData;
	private WikiPage page;

	public HtmlWikiPage(PageData data) throws Exception
	{
		pageData = data;
		page = pageData.getWikiPage();
	}

	public String fullHtml() throws Exception
	{
		HtmlPage html = new HtmlPage();
		html.setBackgroundColor(page.getBackgroundColor());
		html.setHtmlTitle(new PageCrawler().getQualifiedName(page));

		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.whereUsed(new PageCrawler().getQualifiedName(page))));
		table.addRow(new TableRow(makeButtons(), makeRightColumn()));

		html.addElement(table);
		return html.html();
	}

	public String withHeaderAndFooter(String value) throws Exception
	{
		HtmlPage html = new HtmlPage();
		html.setBackgroundColor(page.getBackgroundColor());
		html.setHtmlTitle(new PageCrawler().getQualifiedName(page));
		Table table = new Table();
		table.addRow(TableRow.titleRow(HtmlPageName.whereUsed(new PageCrawler().getQualifiedName(page))));
		table.addRow(new TableRow(makeButtons(), addHeaderAndFooter(value)));
		html.addElement(table);
		return html.html();
	}

	public String testableHtmlDocument() throws Exception
	{
		HtmlPage html = new HtmlPage();
		html.setBackgroundColor(page.getBackgroundColor());
		html.setHtmlTitle(new PageCrawler().getQualifiedName(page));
		html.addContent(testableHtml());
		return html.html();
	}

	private String makeButtons() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		String localPageName = new PageCrawler().getQualifiedName(page);
		String localOrRemotePageName = localPageName;
		boolean newWindowIfRemote = NO_NEW_WINDOW;
		if(page.isRemote())
		{
			ProxyPage proxyPage = (ProxyPage) page;
			localOrRemotePageName = proxyPage.getThisPageUrl();
			newWindowIfRemote = true;
		}
		if(pageData.hasAttribute("Test")) buffer.append(new Button(localPageName, "Test", "test", "t", NO_NEW_WINDOW).html());
		if(pageData.hasAttribute("Suite")) buffer.append(new Button(localPageName, "Suite", "suite", "", NO_NEW_WINDOW).html());
		if(pageData.hasAttribute("Edit")) buffer.append(new Button(localOrRemotePageName, "Edit", "edit", "e", newWindowIfRemote).html());
		if(pageData.hasAttribute("Properties")) buffer.append(new Button(localOrRemotePageName, "Properties", "properties", "p", newWindowIfRemote).html());
		if(pageData.hasAttribute("Versions")) buffer.append(new Button(localOrRemotePageName, "Versions", "versions", "v", newWindowIfRemote).html());
		if(pageData.hasAttribute("Search")) buffer.append(new Button("?searchForm", "Search", null, "s", NO_NEW_WINDOW).html());
		if(pageData.hasAttribute("Refactor")) buffer.append(new Button(localOrRemotePageName, "Refactor", "refactor", "r", newWindowIfRemote).html());
		return buffer.toString();
	}

	public String makeRightColumn() throws Exception
	{
		String content = testableHtml();
		return addHeaderAndFooter(content);
	}

	private String addHeaderAndFooter(String content) throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append(getHtmlOfInheritedPage("PageHeader", pageData.getWikiPage()));
		buffer.append(content);
		buffer.append(getHtmlOfInheritedPage("PageFooter", pageData.getWikiPage()));
		return buffer.toString();
	}

	public String testableHtml() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		if(pageData.hasAttribute("Test")) buffer.append(getHtmlOfInheritedPage("SetUp", pageData.getWikiPage()));
		buffer.append(pageData.getHtml());
		if(pageData.hasAttribute("Test")) buffer.append(getHtmlOfInheritedPage("TearDown", pageData.getWikiPage()));
		return buffer.toString();
	}

	public String getHtmlOfInheritedPage(String pageName, WikiPage context) throws Exception
	{
		WikiPage inheritedPage = getInheritedPage(pageName, page);
		if(inheritedPage != null) return inheritedPage.getData().getHtml(context); else return "";
	}

	// TODO move this method to somewhere more appropriote.
	public static WikiPage getInheritedPage(String pageName, WikiPage context) throws Exception
	{
		WikiPage page = context;
		do
		{
			page = page.getParent();
			WikiPage namedPage = page.getChildPage(pageName);
			if(namedPage != null)
				return namedPage;
		} while(!page.isRoot());
		return null;
	}
}