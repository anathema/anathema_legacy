// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

public class Button extends HtmlElement
{
	private String action;
	private String name;
	private String inputName;
	private String accessKey;
	private boolean newWindow;

	public Button(String action, String name, String inputName, String accessKey, boolean newWindow)
	{
		this.action = action;
		this.name = name;
		this.inputName = inputName;
		this.accessKey = accessKey;
		this.newWindow = newWindow;
	}

	public String html() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("  <!-- ").append(name).append(" button -->\n");
		buffer.append("  <a href=\"").append(action);
		if(inputName != null)
			buffer.append("?").append(inputName);
		buffer.append("\"");
		if(newWindow)
			buffer.append(" target=\"newWindow\"");
		buffer.append(" accesskey=\"").append(accessKey).append("\">\n");
		buffer.append("   <img src=\"/files/images/ball.gif\" border=\"0\">");
		buffer.append(name).append("\n");
		buffer.append("  </a><br>");

		return buffer.toString();
	}
}
