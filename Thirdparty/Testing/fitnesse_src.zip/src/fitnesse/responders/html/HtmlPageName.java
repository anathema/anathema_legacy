// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import java.util.StringTokenizer;

public class HtmlPageName extends HtmlElement
{
	private String pageName;

	private HtmlPageName(String name)
	{
		pageName = name;
	}

	public String html()
	{
		return makeNameList();
	}

	private String makeNameList()
	{
		if(pageName == null)
			return null;
		StringBuffer titleString = new StringBuffer();
		StringBuffer pageNameAccumulator = new StringBuffer();
		StringTokenizer tokenizer = new StringTokenizer(pageName, ".");
		while(tokenizer.hasMoreTokens())
		{
			String page = tokenizer.nextToken();
			if(tokenizer.hasMoreTokens())
			{
				pageNameAccumulator.append(page);
				titleString.append(
				   "<font size=\"3\"><a href=\""
				   + pageNameAccumulator + "\">" + page + "</a>.</font><br>");
				pageNameAccumulator.append(".");
			}
			else
			{
				return titleString.append(mainPage(pageName, page)).toString();
			}
		}
		return titleString.toString();
	}

	protected String mainPage(String qualifiedName, String name)
	{
		return name;
	}

	public static HtmlPageName plain(String name)
	{
		return new HtmlPageName(name);
	}

	public static HtmlPageName whereUsed(String name)
	{
		return new WhereUsedHtmlPageName(name);
	}

	private static class WhereUsedHtmlPageName extends HtmlPageName
	{
		private WhereUsedHtmlPageName(String name)
		{
			super(name);
		}

		protected String mainPage(String qualifiedName, String name)
		{
			return "<a href=\"" + qualifiedName + "?whereUsed\">" + name + "</a>";
		}
	}
}
