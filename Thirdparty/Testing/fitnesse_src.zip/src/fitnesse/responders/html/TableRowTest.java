// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import fitnesse.testutil.RegexTest;

public class TableRowTest extends RegexTest
{
	private TableRow row;

	public void setUp() throws Exception
	{
		row = new TableRow();
	}

	public void tearDown() throws Exception
	{
	}

	public void testHtml() throws Exception
	{
		String html = row.html();
		assertSubString("<tr>", html);
		assertSubString("</tr>", html);
		assertSubString("<td width=\"100\"", html);
		assertSubString("</td>", html);
	}

	public void testSetContent() throws Exception
	{
		row.setLeftContent("left-content");
		row.setRightContent("right-content");
		assertEquals("left-content", row.getLeftContent());
		assertEquals("right-content", row.getRightContent());
		String html = row.html();
		assertSubString("left-content", html);
		assertSubString("right-content", html);
	}
}
