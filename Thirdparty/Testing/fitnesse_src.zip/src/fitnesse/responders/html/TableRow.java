// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

public class TableRow extends HtmlElement
{
	HtmlElement rightContent = new RawHtml("&nbsp;");
	HtmlElement leftContent = new RawHtml("&nbsp;");

	public TableRow()
	{
	}

   public TableRow(String leftContent, String rightContent)
   {
	   this.leftContent = new RawHtml(leftContent);
	   this.rightContent = new RawHtml(rightContent);
   }

   public TableRow(HtmlElement leftContent, HtmlElement rightContent)
   {
	   this.leftContent = leftContent;
	   this.rightContent = rightContent;
   }

   public TableRow(String leftContent, HtmlElement rightContent)
   {
	   this.leftContent = new RawHtml(leftContent);
	   this.rightContent = rightContent;
   }

	public String html() throws Exception
	{
		StringBuffer html = new StringBuffer();
		html.append("\t<tr>").append(endl);
		html.append("\t\t<td width=\"100\" valign=\"top\">").append(endl);
		html.append(getLeftContent()).append(endl);
		html.append("\t\t</td>").append(endl);
		html.append("\t\t<td valign=\"top\">").append(endl);
		html.append(getRightContent()).append(endl);
		html.append("\t\t</td>").append(endl);
		html.append("\t</tr>").append(endl);

		return html.toString();
	}

	public void setRightContent(String content)
	{
		rightContent = new RawHtml(content);
	}

	public void setLeftContent(String content)
	{
		leftContent = new RawHtml(content);
	}

	public void setRightContent(HtmlElement content)
	{
		rightContent = content;
	}

	public void setLeftContent(HtmlElement content)
	{
		leftContent = content;
	}

	public String getRightContent() throws Exception
	{
		return rightContent.html();
	}

	public String getLeftContent() throws Exception
	{
		return leftContent.html();
	}

	public static TableRow titleRow(String title) throws Exception
	{
		return titleRow(new RawHtml(title));
	}

	public static TableRow titleRow(HtmlElement element) throws Exception
	{
		TableRow row = new TableRow();
		row.setLeftContent("\t\t\t<img src=\"/files/images/FitNesseLogoIcon.jpg\">");
		row.setRightContent("\t\t\t<h1>" + element.html() + "</h1>");
		return row;
	}
}
