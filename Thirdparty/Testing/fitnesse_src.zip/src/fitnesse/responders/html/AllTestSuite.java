// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite(html)");
		suite.addTest(new TestSuite(HtmlPageTest.class));
		suite.addTest(new TestSuite(TableTest.class));
		suite.addTest(new TestSuite(TableRowTest.class));
		suite.addTest(new TestSuite(HtmlPageNameTest.class));
		suite.addTest(new TestSuite(ButtonTest.class));
		return suite;
	}
}

