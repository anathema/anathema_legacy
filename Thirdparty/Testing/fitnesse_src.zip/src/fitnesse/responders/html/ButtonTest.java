// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

import fitnesse.testutil.RegexTest;

public class ButtonTest extends RegexTest
{
	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testHtml() throws Exception
	{
      Button local = new Button("edit", "Edit", "edit", "e", false);
      Button newWindow = new Button("edit", "Edit", "edit", "e", true);

      assertHasRegexp("<a href=\".*?edit\" accesskey=\"e\">", local.html());
		assertSubString("<img src=\"/files/images/ball.gif\" border=\"0\">", local.html());
		assertSubString("Edit", local.html());
		assertSubString("target=\"newWindow\"", newWindow.html());
	}
}
