// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.html;

public class RawHtml extends HtmlElement
{
	private String html;

	public RawHtml(String html)
	{
		this.html = html;
	}

	public String html()
	{
		return html;
	}
}
