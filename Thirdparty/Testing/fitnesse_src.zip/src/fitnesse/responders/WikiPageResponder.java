// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.http.*;
import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.responders.html.*;

public class WikiPageResponder implements Responder
{
	protected WikiPage page;
	protected PageData pageData;
	protected String pageTitle;
	HttpRequest request;

	public WikiPageResponder()
	{
	}

	public WikiPageResponder(WikiPage page) throws Exception
	{
		this.page = page;
		pageData = page.getData();
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		String resource = request.getResource();

		if("".equals(resource))
			resource = "FrontPage";

		page = new VirtualEnabledPageCrawler().getPage(context.root, resource);
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);
		pageData = page.getData();
		pageTitle = new PageCrawler().getQualifiedName(page);
		String html = makeHtml();

		SimpleResponse response = new SimpleResponse();
		response.setMaxAge(0);
		response.setContent(html);

		return response;
	}

	public String makeHtml() throws Exception
	{
		String html = new HtmlWikiPage(pageData).fullHtml();
		return html;
	}

}
