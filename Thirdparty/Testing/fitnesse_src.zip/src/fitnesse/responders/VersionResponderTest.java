// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import junit.swingui.TestRunner;
import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;
import fitnesse.http.*;
import fitnesse.*;

public class VersionResponderTest extends RegexTest
{
	private String oldVersion;
	private SimpleResponse response;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"VersionResponderTest"});
	}

	private void makeTestResponse() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page = root.addPage("PageOne", "original content");
		PageData data = page.getData();
		data.setContent("new stuff");
		WikiPage.CommitRecord commitRecord = page.commit(data);
		oldVersion = commitRecord.perviousVersion;

		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageOne");
		request.addInput("version", oldVersion);

		Responder responder = new VersionResponder();
		response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
	}

	public void testVersionName() throws Exception
	{
		makeTestResponse();

		assertHasRegexp("original content", response.getContent());
		assertDoesntHaveRegexp("new stuff", response.getContent());
		assertHasRegexp(oldVersion, response.getContent());
	}

	public void testButtons() throws Exception
	{
		makeTestResponse();

		assertDoesntHaveRegexp("Edit button", response.getContent());
		assertDoesntHaveRegexp("Search button", response.getContent());
		assertDoesntHaveRegexp("Test button", response.getContent());
		assertDoesntHaveRegexp("Suite button", response.getContent());
		assertDoesntHaveRegexp("Versions button", response.getContent());

		assertHasRegexp("Rollback button", response.getContent());
	}
}
