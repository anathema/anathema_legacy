// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;
import fitnesse.*;
import fitnesse.http.*;

public class PageDataResponderTest extends RegexTest
{
	WikiPage root;
	WikiPage pageOne;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		pageOne = root.addPage("PageOne", "Line one\nLine two");
	}

	public void testGetPageData() throws Exception
	{
		Responder responder = new PageDataResponder();
		MockHttpRequest request = new MockHttpRequest();
		request.setResource("PageOne");
		request.addInput("pageData", "");
		SimpleResponse response = (SimpleResponse)responder.makeResponse(new FitNesseContext(root), request);
		assertEquals(pageOne.getData().getContent(), response.getContent());
	}
}
