// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import junit.framework.TestCase;
import fitnesse.http.MockHttpRequest;
import fitnesse.http.Response;
import fitnesse.responders.files.RenameFileResponder;

import java.io.File;

public class RenameFileResponderTest extends TestCase
{
	private MockHttpRequest request;

	public void setUp()
	{
		request = new MockHttpRequest();
	}

	public void testMakeResponse() throws Exception
	{
		File file = new File("testfile");
		RenameFileResponder responder = new RenameFileResponder("");
		request.addInput("filename", "testfile");
		request.addInput("newName", "newName");
		request.setResource("");
		Response response = responder.makeResponse(null, request);
		response.getHeader("");
		assertFalse(file.exists());
		assertEquals(303, response.getStatus());
		assertEquals("/", response.getHeader("Location"));
		file.delete();
	}

}
