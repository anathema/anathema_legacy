// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.http.*;
import fitnesse.testutil.FileUtil;
import fitnesse.responders.files.UploadResponder;
import junit.framework.TestCase;
import junit.textui.TestRunner;

import java.io.File;

public class UploadResponderTest extends TestCase
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"UploadResponderTest"});
	}

	public void setUp() throws Exception
	{
		FileUtil.makeDir("testdir");
		FileUtil.makeDir("testdir/files");
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testdir");
	}

	public void testMakeResponse() throws Exception
	{
		UploadResponder responder = new UploadResponder("testdir");
		MockHttpRequest request = new MockHttpRequest();
		request.addInput("file", new UploadedFile("testFile.txt", "plain/text", "test content".getBytes()));
		request.setResource("files/");

		Response response = responder.makeResponse(null, request);

		File file = new File("testdir/files/testFile.txt");
		assertTrue(file.exists());
		assertEquals("test content", FileUtil.getFileContent(file));

		assertEquals(303, response.getStatus());
		assertEquals("/files/", response.getHeader("Location"));
	}

	public void testMakeRelativeFilename() throws Exception
	{
		String name1 = "name1.txt";
		String name2 = "name2";
		String name3 = "C:\\folder\\name3.txt";
		String name4 = "/home/user/name4.txt";

		assertEquals("name1.txt", UploadResponder.makeRelativeFilename(name1));
		assertEquals("name2", UploadResponder.makeRelativeFilename(name2));
		assertEquals("name3.txt", UploadResponder.makeRelativeFilename(name3));
		assertEquals("name4.txt", UploadResponder.makeRelativeFilename(name4));
	}
}

//public class UploadResponderTest extends TestCase
//{
//	public void setUp() throws Exception {
//		FileUtil.makeDir("testdir");
//		FileUtil.makeDir("testdir/files");
//	}
//
//	public void tearDown() throws Exception {
//		FileUtil.deleteFileSystemDirectory("testdir");
//	}
//
//	public void testMakeResponse() throws Exception {
//		UploadResponder responder = new UploadResponder("testdir");
//		MockHttpRequest request = new MockHttpRequest();
//		request.addInput("file", new UploadedFile("testFile.txt", "plain/text", "test content".getBytes()));
//		request.setResource("files/");
//
//		SimpleResponse response = responder.makeResponse(null, request);
//
//		File file = new File("testdir/files/testFile.txt");
//		assertTrue(file.exists());
//		assertEquals("test content", FileUtil.getFileContent(file));
//
//		assertEquals(303, response.getStatus());
//		assertEquals("/files/", response.getHeader("Location"));
//	}
//
//	public void testMakeRelativeFilename() throws Exception {
//		String name1 = "name1.txt";
//		String name2 = "name2";
//		String name3 = "C:\\folder\\name3.txt";
//		String name4 = "/home/user/name4.txt";
//
//		assertEquals("name1.txt", UploadResponder.makeRelativeFilename(name1));
//		assertEquals("name2", UploadResponder.makeRelativeFilename(name2));
//		assertEquals("name3.txt", UploadResponder.makeRelativeFilename(name3));
//		assertEquals("name4.txt", UploadResponder.makeRelativeFilename(name4));
//	}
//}
