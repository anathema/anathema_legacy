// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.http.*;
import fitnesse.wiki.WikiPage;
import fitnesse.*;
import fitnesse.responders.html.*;
import fitnesse.responders.NotFoundResponder;

import java.io.*;
import java.net.*;
import java.util.*;

public class FileResponder implements Responder
{
	private static FileNameMap fileNameMap = URLConnection.getFileNameMap();
	private String resource;
	private String rootPath;

	public FileResponder(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		resource = request.getResource();

		FileInfo requestedFile = new FileInfo(new File(rootPath + "/" + resource));
		if(!requestedFile.file.exists())
			response = (SimpleResponse)new NotFoundResponder().makeResponse(context, request);
		else if(requestedFile.file.isDirectory())
		{
			if(!resource.endsWith("/"))
				setRedirectForDirectory(response);
			else
				response.setContent(makeDirectoryListingPage(requestedFile.file));
		}
		else
			prepareFileResponse(request, response, requestedFile);

		return response;
	}

	private void setRedirectForDirectory(Response response)
	{
		if(!resource.startsWith("/"))
			resource = "/" + resource;
		response.redirect(resource + "/");
	}

	private void prepareFileResponse(HttpRequest request, SimpleResponse response, FileInfo requestedFile)
	{
		determineLastModifiedInfo(requestedFile);

		if(!setNotModifiedHeader(request, response, requestedFile))
		{
			response.setContent(getFileContent(requestedFile.file));
			setContentType(requestedFile.file, response);
			response.setLastModifiedHeader(requestedFile.lastModifiedDateString);
		}
	}

	// If applicable, set a header indicating that the client already has the most recent
	// version of the file.
	private boolean setNotModifiedHeader(HttpRequest request, Response response, FileInfo requestedFile)
	{
		boolean notModifiedSet = false;
		String queryDateString = (String) request.getHeader("If-Modified-Since");
		if(queryDateString != null && !queryDateString.equals(""))
		{
			try
			{
				Date queryDate = SimpleResponse.getStandardHttpDateFormat().parse(queryDateString);
				if(!queryDate.before(requestedFile.lastModifiedDate))
				{
					response.setStatus(304);
					response.addHeader("Date", SimpleResponse.getStandardHttpDateFormat().format(new Date()));
					response.addHeader("Cache-Control", "private");
					response.setLastModifiedHeader(requestedFile.lastModifiedDateString);
					notModifiedSet = true;
				}
			}
			catch(NumberFormatException nfe)
			{
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		return notModifiedSet;
	}

	private void determineLastModifiedInfo(FileInfo fileInfo)
	{
		fileInfo.lastModifiedDate = new Date(fileInfo.file.lastModified());
		fileInfo.lastModifiedDateString = SimpleResponse.getStandardHttpDateFormat().format(fileInfo.lastModifiedDate);

		try  // remove milliseconds
		{
			fileInfo.lastModifiedDate =
			   SimpleResponse.getStandardHttpDateFormat().parse(
			      fileInfo.lastModifiedDateString
			   );
		}
		catch(java.text.ParseException jtpe)
		{
			jtpe.printStackTrace();
		}
	}

	private String makeDirectoryListingPage(File dir) throws Exception
	{
		HtmlPage page = new HtmlPage();
		page.setHtmlTitle(resource);
		Table table = new Table();
		table.addRow(TableRow.titleRow("Files Section<br>" + resource));
		table.addRow(new TableRow("", makeRightColumn(dir)));
		page.addElement(table);

		return page.html();
	}

	private byte[] getFileContent(File file)
	{
		try
		{
			InputStream input = new FileInputStream(file);
			long fileLength = file.length();
			byte[] bytes = new byte[(int) fileLength];
			input.read(bytes);
			input.close();
			return bytes;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	private void setContentType(File file, Response response)
	{
		String contentType = fileNameMap.getContentTypeFor(file.getName());
		if(contentType == null)
			contentType = "plain/text";
		response.setContentType(contentType);
	}

	private String makeRightColumn(File dir)
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action=\"/" + resource + "\" method=\"get\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"deleteOrRenameFile\"><br>");
		buffer.append("<hr>");
		File[] files = dir.listFiles();
		for(int i = 0; i < files.length; i++)
		{
			File file = files[i];
			buffer.append("<input type=\"radio\" name=\"filename\" value=\"" + file.getName() + "\">");
			buffer.append("<a href=\"").append(file.getName());
			if(file.isDirectory())
				buffer.append("/");
			buffer.append("\">");
			buffer.append(file.getName()).append("</a><br>\n");
		}
		buffer.append("<hr>");
		buffer.append(makeRenameButton());
		buffer.append(makeDeleteButton());
		buffer.append("<table><tr>");
		buffer.append("</form><td width=\"10\">&nbsp;</td><td>");
		buffer.append(makeUploadForm());
		buffer.append("</td><td width=\"10\">&nbsp;</td><td>");
		buffer.append(makeDirectoryForm());
		buffer.append("</td></tr></form></table>");
		return buffer.toString();
	}

	private String makeDirectoryForm()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form action=\"/" + resource + "\" method=\"get\">");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"createDir\">");
		buffer.append("<!--create directory form-->");
		buffer.append("Create a directory<br>");
		buffer.append("<input type=\"text\" name=\"dirname\" value=\"\"><br>");
		buffer.append("<input type=\"submit\" value=\"Create\">");
		buffer.append("</form>");
		return buffer.toString();
	}

	private String makeDeleteButton()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<!--create delete form-->");
		buffer.append("<input type=\"submit\" name=\"deleteFile\" value=\"Delete\">");
		return buffer.toString();
	}

	private String makeRenameButton()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<!--create renameReferences form-->");
		buffer.append("<input type=\"text\" name=\"newName\" value=\"\">");
		buffer.append("<input type=\"submit\" name=\"renameFile\" value=\"Rename\">");
		return buffer.toString();
	}

	private String makeUploadForm()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("<form enctype=\"multipart/form-data\" action=\"/" + resource + "\" method=\"post\">");
		buffer.append("<!--upload form-->");
		buffer.append("Upload a file<br>");
		buffer.append("<input type=\"hidden\" name=\"responder\" value=\"upload\"><br>");
		buffer.append("<input type=\"file\" name=\"file\" value=\"\"><br>");
		buffer.append("<input type=\"submit\" value=\"Upload\">");
		buffer.append("</form>");
		return buffer.toString();
	}

	private class FileInfo
	{
		public File file;
		public Date lastModifiedDate;
		public String lastModifiedDateString;

		public FileInfo(File file)
		{
			this.file = file;
		}
	}
}
