// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.*;
import fitnesse.http.*;
import java.io.File;

public class CreateDirectoryResponder implements Responder
{
	private String rootPath; // TODO can get rid of this and others since it is in the FitNesseContext

	public CreateDirectoryResponder(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();

		String resource = request.getResource();
		String dirname = (String) request.getInput("dirname");
		String pathname = rootPath + "/" + resource + dirname;
		File file = new File(pathname);
		if(!file.exists())
			file.mkdir();

		response.redirect("/" + resource);
		return response;
	}

}
