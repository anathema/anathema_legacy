// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import junit.swingui.TestRunner;
import fitnesse.*;
import fitnesse.responders.files.FileResponder;
import fitnesse.testutil.*;
import fitnesse.http.*;

import java.io.*;
import java.util.*;

public class FileResponderTest extends RegexTest
{
	MockHttpRequest request;
	private static String base = ".";
	private final String HTTP_DATE_REGEXP = "[SMTWF][a-z]{2}\\,\\s[0-9]{2}\\s[JFMASOND][a-z]{2}\\s[0-9]{4}\\s[0-9]{2}\\:[0-9]{2}\\:[0-9]{2}\\sGMT";
	private SimpleResponse response;
	// Example: "Tue, 02 Apr 2003 22:18:49 GMT"

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"FileResponderTest"});
	}

	public void setUp() throws Exception
	{
		request = new MockHttpRequest();
		makeSampleFiles();
	}

	public void tearDown() throws Exception
	{
		deleteSampleFiles();
	}

	public void testFileContent() throws Exception
	{
		request.setResource("files/testFile1");
		Responder responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);
		assertHasRegexp("file1 content", response.getContent());
	}

	public void testLastModifiedHeader() throws Exception
	{
		request.setResource("files/testFile1");
		Responder responder = new FileResponder(base);
		Response response = responder.makeResponse(null, request);
		String lastModifiedHeader = response.getHeader("Last-Modified");
		assertMatches(HTTP_DATE_REGEXP, lastModifiedHeader);
	}

	public void test304IfNotModified() throws Exception
	{
		Calendar now = new GregorianCalendar();
		now.add(Calendar.DATE, -1);
		String yesterday = SimpleResponse.getStandardHttpDateFormat().format(now.getTime());
		now.add(Calendar.DATE, 2);
		String tomorrow = SimpleResponse.getStandardHttpDateFormat().format(now.getTime());

		request.setResource("files/testFile1");
		request.addHeader("If-Modified-Since", yesterday);
		Responder responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);
		assertEquals(200, response.getStatus());

		request.setResource("files/testFile1");
		request.addHeader("If-Modified-Since", tomorrow);
		responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);
		assertEquals(304, response.getStatus());
		assertEquals("", response.getContent());
		assertMatches(HTTP_DATE_REGEXP, response.getHeader("Date"));
		assertNotNull(response.getHeader("Cache-Control"));
	}

	public void testDirectotyListing() throws Exception
	{
		request.setResource("files/testDir/");
		Responder responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);
		assertHasRegexp("testDir", response.getContent());
		assertHasRegexp("testFile2</a>", response.getContent());
		assertHasRegexp("testFile3</a>", response.getContent());
		assertHasRegexp("<a href=", response.getContent());
	}

	public void testNotFoundFile() throws Exception
	{
		request.setResource("files/something/that/aint/there");
		Responder responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);
		assertEquals(404, response.getStatus());
		assertHasRegexp("files/something/that/aint/there", response.getContent());
	}

	public void testButtons() throws Exception
	{
		request.setResource("files/testDir/");
		Responder responder = new FileResponder(base);
		response = (SimpleResponse)responder.makeResponse(null, request);

		assertHasRegexp("upload form", response.getContent());
		assertHasRegexp("create directory form", response.getContent());
	}

	public void testRedirectForDirectory() throws Exception
	{
		request.setResource("files/testDir");
		Responder responder = new FileResponder(base);
		Response response = responder.makeResponse(null, request);
		assertEquals(303, response.getStatus());
		assertEquals("/files/testDir/", response.getHeader("Location"));
	}

    public static void makeSampleFiles()
	{
		new File(base + "/files").mkdir();
		new File(base + "/files/testDir").mkdir();

		FileUtil.createFile(base + "/files/testFile1", "file1 content");
		FileUtil.createFile(base + "/files/testDir/testFile2", "file2 content");
		FileUtil.createFile(base + "/files/testDir/testFile3", "file3 content");
	}

	public static void deleteSampleFiles()
	{
		String[] filesToDelete = {"/files/testDir/testFile2", "/files/testDir/testFile3", "/files/testFile1", "/files/testDir", "/files"};

		for(int i = 0; i < filesToDelete.length; i++)
		{
			String s = filesToDelete[i];
			String fullFilename = base + s;
			boolean result = new File(fullFilename).delete();
			if(!result)
				System.err.println("Could not delete " + fullFilename);
		}
	}
}
