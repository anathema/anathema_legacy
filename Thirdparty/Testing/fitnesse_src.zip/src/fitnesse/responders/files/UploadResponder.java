// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.*;
import fitnesse.wiki.WikiPage;
import fitnesse.http.*;
import java.io.*;
import java.util.regex.*;

public class UploadResponder implements Responder
{
	private static final Pattern filenamePattern = Pattern.compile("([^/\\\\]*[/\\\\])*([^/\\\\]*)");

	private String rootPath;

	public UploadResponder(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		String resource = request.getResource();
		UploadedFile uploadedFile = (UploadedFile) request.getInput("file");
		if(uploadedFile.isUsable())
		{
			File file = makeFileToCreate(uploadedFile, resource);
			writeFile(file, uploadedFile);
		}

		response.redirect("/" + resource);
		return response;
	}

	private void writeFile(File file, UploadedFile uploadedFile) throws Exception
	{
		FileOutputStream output = new FileOutputStream(file);
		output.write(uploadedFile.getContents());
		output.close();
	}

	private File makeFileToCreate(UploadedFile uploadedFile, String resource)
	{
		String filename = makeRelativeFilename(uploadedFile.getName());
		File file = new File(makeFullFilename(resource, filename));
		while(file.exists())
		{
			filename = "_" + filename;
			file = new File(makeFullFilename(resource, filename));
		}
		return file;
	}

	private String makeFullFilename(String resource, String filename)
	{
		return rootPath + "/" + resource + filename;
	}

	public static String makeRelativeFilename(String name)
	{
		Matcher match = filenamePattern.matcher(name);
		if(match.find())
			return match.group(2);
		else
			return name;
	}

}
