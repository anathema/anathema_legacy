// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.*;
import fitnesse.wiki.WikiPage;
import fitnesse.http.Response;
import fitnesse.http.HttpRequest;
import fitnesse.http.SimpleResponse;

import java.io.File;

public class DeleteFileResponder implements Responder
{
	public String resource;
	public String rootPath;

	public DeleteFileResponder(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		//TODO this decision should go in the ResponderFactory
		if(request.hasInput("renameFile"))
			return new RenameFileResponder(rootPath).makeResponse(context, request);

		Response response = new SimpleResponse();
		resource = request.getResource();
		String filename = (String) request.getInput("filename");
		String pathname = rootPath + "/" + resource + filename;
		File file = new File(pathname);

		if(file.isDirectory())
			deleteFileSystemDirectory(file);
		else
			file.delete();

		response.redirect("/" + resource);
		return response;
	}

	private void deleteFileSystemDirectory(File current)
	{
		File[] files = current.listFiles();

		for(int i = 0; files != null && i < files.length; i++)
		{
			File file = files[i];
			if(file.isDirectory())
				deleteFileSystemDirectory(file);
			else
				file.delete();
		}
		current.delete();
	}
}
