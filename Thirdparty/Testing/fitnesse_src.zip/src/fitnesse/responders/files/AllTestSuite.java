// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import junit.framework.*;
import fitnesse.responders.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(fitnesse.responders.html.AllTestSuite.suite());
		suite.addTest(new TestSuite(FileResponderTest.class));
		suite.addTest(new TestSuite(UploadResponderTest.class));
		suite.addTest(new TestSuite(CreateDirectoryResponderTest.class));
		suite.addTest(new TestSuite(DeleteFileResponderTest.class));
		suite.addTest(new TestSuite(RenameFileResponderTest.class));
		return suite;
	}
}
