// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.*;
import fitnesse.http.HttpRequest;
import fitnesse.http.Response;
import fitnesse.http.SimpleResponse;
import java.io.File;

public class RenameFileResponder implements Responder
{
	private String rootPath;
	private String resource;
	String newFilename;

	public RenameFileResponder(String rootPath)
	{
		this.rootPath = rootPath;
	}

	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		Response response = new SimpleResponse();
		resource = request.getResource();
		String filename = (String) request.getInput("filename");
		newFilename = HttpRequest.decodeContent((String) request.getInput("newName"));

		String pathname = rootPath + "/" + resource;
		File file = new File(pathname + filename);
		file.renameTo(new File(pathname + newFilename));
		response.redirect("/" + resource);
		return response;
	}

}
