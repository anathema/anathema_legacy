// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.testutil.FileUtil;
import fitnesse.http.*;
import fitnesse.responders.files.CreateDirectoryResponder;
import fitnesse.FitNesseContext;

import java.io.File;

public class CreateDirectoryResponderTest extends TestCase
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"CreateDirectoryResponderTest"});
	}

	public void setUp() throws Exception
	{
		FileUtil.makeDir("testdir");
		FileUtil.makeDir("testdir/files");
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testdir");
	}

	public void testMakeResponse() throws Exception
	{
		CreateDirectoryResponder responder = new CreateDirectoryResponder("testdir");
		MockHttpRequest request = new MockHttpRequest();
		request.addInput("dirname", "subdir");
		request.setResource("");

		Response response = responder.makeResponse(null, request);

		File file = new File("testdir/subdir");
		assertTrue(file.exists());
		assertTrue(file.isDirectory());

		assertEquals(303, response.getStatus());
		assertEquals("/", response.getHeader("Location"));
	}
}
