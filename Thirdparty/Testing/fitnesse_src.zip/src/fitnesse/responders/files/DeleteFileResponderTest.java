// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders.files;

import fitnesse.testutil.RegexTest;
import fitnesse.http.MockHttpRequest;
import fitnesse.http.Response;
import fitnesse.responders.files.DeleteFileResponder;
import fitnesse.FitNesseContext;

import java.io.File;

public class DeleteFileResponderTest extends RegexTest
{
	public MockHttpRequest request;

	public void setUp()
	{
		request = new MockHttpRequest();
	}

	public void testDelete() throws Exception
	{
		File file = new File("testfile");
		DeleteFileResponder responder = new DeleteFileResponder("");
		request.addInput("filename", "testfile");
		request.setResource("");
		Response response = responder.makeResponse(null, request);
		response.getHeader("");
		assertFalse(file.exists());
		assertEquals(303, response.getStatus());
		assertEquals("/", response.getHeader("Location"));
	}

	public void testDeleteDirectory() throws Exception
	{
		File file = new File("/dir");
		file.mkdir();
		File childFile = new File(file.getAbsolutePath() + "testChildFile");
		DeleteFileResponder responder = new DeleteFileResponder("");
		request.addInput("filename", "dir");
		request.setResource("");
		Response response = responder.makeResponse(null, request);
		response.getHeader("");
		assertFalse(childFile.exists());
		assertFalse(file.exists());

	}
}
