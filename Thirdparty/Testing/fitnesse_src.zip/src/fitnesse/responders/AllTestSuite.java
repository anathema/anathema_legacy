// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(fitnesse.responders.html.AllTestSuite.suite());
		suite.addTest(fitnesse.responders.files.AllTestSuite.suite());
		suite.addTest(fitnesse.responders.refactoring.AllTestSuite.suite());
		suite.addTest(fitnesse.responders.editing.AllTestSuite.suite());
		suite.addTest(fitnesse.responders.run.AllTestSuite.suite());
		suite.addTest(new TestSuite(WikiPageResponderTest.class));
		suite.addTest(new TestSuite(ResponderFactoryTest.class));
		suite.addTest(new TestSuite(ErrorResponderTest.class));
		suite.addTest(new TestSuite(NotFoundResponderTest.class));
		suite.addTest(new TestSuite(SearchFormResponderTest.class));
		suite.addTest(new TestSuite(SearchResponderTest.class));
		suite.addTest(new TestSuite(SerializedPageResponderTest.class));
		suite.addTest(new TestSuite(VersionSelectionResponderTest.class));
		suite.addTest(new TestSuite(VersionResponderTest.class));
		suite.addTest(new TestSuite(NameResponderTest.class));
		suite.addTest(new TestSuite(WhereUsedResponderTest.class));
		suite.addTest(new TestSuite(PageDataResponderTest.class));
		return suite;
	}
}
