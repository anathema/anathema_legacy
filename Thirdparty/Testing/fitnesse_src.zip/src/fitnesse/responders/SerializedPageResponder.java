// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.responders;

import fitnesse.*;
import fitnesse.wiki.*;
import fitnesse.http.*;

import java.io.*;

public class SerializedPageResponder implements Responder
{
	public Response makeResponse(FitNesseContext context, HttpRequest request) throws Exception
	{
		SimpleResponse response = new SimpleResponse();
		response.setContentType("application/octet-stream");

		WikiPage page = new PageCrawler().getPage(context.root, request.getResource());
		if(page == null)
			return new NotFoundResponder().makeResponse(context, request);

		Object object;
		if("bones".equals(request.getInput("type")))
			object = new ProxyPage(page);
		else if("meat".equals(request.getInput("type")))
		{
			PageData originalData = page.getData();
			if(request.hasInput("version"))
				originalData = page.getData((String) request.getInput("version"));
			PageData data = new PageData(originalData);
			object = data;
		}
		else
			throw new Exception("Improper use of proxy retrieval");

		ByteArrayOutputStream byteStream = new ByteArrayOutputStream();
		ObjectOutputStream os = new ObjectOutputStream(byteStream);
		os.writeObject(object);
		os.close();
		response.setContent(byteStream.toByteArray());

		return response;
	}

}
