// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import fitnesse.wiki.*;
import fitnesse.testutil.*;
import fitnesse.responders.*;
import fitnesse.responders.files.FileResponderTest;
import fitnesse.components.*;
import fitnesse.http.*;
import junit.swingui.TestRunner;

import java.util.regex.Pattern;
import java.io.*;
import java.net.Socket;

public class FitnesseServerTest extends RegexTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.FitnesseServerTest"});
	}

	public void setUp() throws Exception
	{
		FileResponderTest.makeSampleFiles();
	}

	public void tearDown() throws Exception
	{
		FileResponderTest.deleteSampleFiles();
	}

	public void testSimple() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		root.addPage("SomePage", "some string");
		String output = getSocketOutput("GET /SomePage HTTP/1.1\r\n\r\n", root);
		String statusLine = "HTTP/1.1 200 OK\r\n";
		assertTrue("Should have statusLine", Pattern.compile(statusLine, Pattern.MULTILINE).matcher(output).find());
		assertTrue("Should have canned Content", hasSubString("some string", output));
	}

	public void testNotFound() throws Exception
	{
		String output = getSocketOutput("GET /WikiWord HTTP/1.1\r\n\r\n", new MockWikiPage());

		String notFound = "404 Not Found";
		assertTrue("Should have notFound", hasSubString(notFound, output));
	}

	public void testBadRequest() throws Exception
	{
		String output = getSocketOutput("Bad Request \r\n\r\n", new MockWikiPage());

		String badRequest = "400 Bad Request";
		assertTrue("Should have baddRequest", hasSubString(badRequest, output));
	}

	public void testFrontPageRequest() throws Exception
	{
		WikiPage rootPage = InMemoryPage.makeRoot("RootPage");
		rootPage.addPage("FrontPage", "This is the FrontPage content");
		String output = getSocketOutput("GET / HTTP/1.1\r\n\r\n", rootPage);
		String expected = "This is the .* content";
		assertTrue("Should have content", hasSubString(expected, output));
	}

	public void testSomeOtherPage() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RootPage");
		root.addPage("PageOne", "Page One Content");
		String output = getSocketOutput("GET /PageOne HTTP/1.1\r\n\r\n", root);
		String expected = "Page One Content";
		assertTrue("Should have page one", hasSubString(expected, output));
	}

	public void testSecondLevelPage() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RootPage");
		root.addPage("PageOne", "Page One Content");
		root.addPage("PageOne.PageTwo", "Page Two Content");
		String output = getSocketOutput("GET /PageOne.PageTwo HTTP/1.1\r\n\r\n", root);

		String expected = "Page Two Content";
		assertTrue("Should have page Two", hasSubString(expected, output));
	}

	public void testRelativeAndAbsoluteLinks() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RootPage");
		root.addPage("PageOne", "PageOne");
		root.addPage("PageOne.PageTwo", "PageTwo");
		String output = getSocketOutput("GET /PageOne.PageTwo HTTP/1.1\r\n\r\n", root);

		String expected = "href=\"PageOne.PageTwo\".*PageTwo";
		assertTrue("Should have relative link", hasSubString(expected, output));

		root.addPage("PageTwo", "PageTwo at root");
		root.addPage("PageOne.PageThree", "PageThree has link to .PageTwo at the root");
		output = getSocketOutput("GET /PageOne.PageThree HTTP/1.1\r\n\r\n", root);
		expected = "href=\"PageTwo\".*[.]PageTwo";
		assertTrue("Should have absolute link", hasSubString(expected, output));
	}

	public void testServingRegularFiles() throws Exception
	{
		String output = getSocketOutput("GET /files/testDir/testFile2 HTTP/1.1\r\n\r\n", new MockWikiPage());
		assertHasRegexp("file2 content", output);
	}

	public void testLoggingDataCreation() throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		SimpleResponse response = new SimpleResponse(200);
		MockSocket socket = new MockSocket("something");

		socket.setHost("1.2.3.4");
		request.setRequestLine("GET / HTTP/1.1");
		response.setContent("abc");

		LogData data = FitnesseExpediter.makeLogData(socket, request, response);

		assertEquals("1.2.3.4", data.host);
		assertNotNull(data.time);
		assertEquals("GET / HTTP/1.1", data.requestLine);
		assertEquals(200, data.status);
		assertEquals(3, data.size);
	}

	public void testIncompleteRequestsTimeOut() throws Exception
	{
		PipedInputStream input = new PipedInputStream();
		PipedOutputStream output = new PipedOutputStream(input);
		MockSocket socket = new MockSocket(input, output);
		final TestingResponseSender sender = new TestingResponseSender(socket);

		Thread senderThread = new Thread(new Runnable(){
			public void run()
			{
				try{
					sender.start();
				} catch (Exception e){
					e.printStackTrace();
				}
			}
		});
		senderThread.start();
		Thread.sleep(sender.requestTimeout + 1000);

		if(senderThread.isAlive())
			senderThread.interrupt();

		String response = sender.buffer.toString();
		assertSubString("400 Bad Request", response);
		//TODO According to HTTP protocol the response should have status code 408.
		//assertSubString("408 Request Time-out", response);
	}

	public class TestingResponseSender extends FitnesseExpediter
	{
		public StringBuffer buffer = new StringBuffer();
		public TestingResponseSender(Socket s) throws Exception
		{
			super(s, new FitNesseContext());
			requestTimeout = 1000;
		}
		public void send(byte[] bytes) throws Exception
		{
			buffer.append(new String(bytes));
			super.send(bytes);
		}
	}

	private String getSocketOutput(String requestLine, WikiPage page) throws Exception
	{
		MockSocket s = new MockSocket(requestLine);
		FitNesseContext context = new FitNesseContext();
		context.responderFactory = new ResponderFactory(".");
		context.root = page;
		FitnesseServer server = new FitnesseServer(context);
		server.serve(s, 1000);
		String output = s.getOutput();
		return output;
	}

	private String getSocketOutput(WikiPage page) throws Exception
	{
		return getSocketOutput("GET /someResource HTTP/1.1\r\n\r\n", page);
	}

	private static boolean hasSubString(String expected, String output)
	{
		return Pattern.compile(expected, Pattern.MULTILINE).matcher(output).find();
	}
}
