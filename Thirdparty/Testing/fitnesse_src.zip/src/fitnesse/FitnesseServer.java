// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import fitnesse.socketservice.SocketServer;
import java.net.*;

public class FitnesseServer implements SocketServer
{
	private FitNesseContext context;

	public FitnesseServer(FitNesseContext context)
	{
		this.context = context;
	}

	public void serve(Socket s)
	{
		serve(s, 60000);
	}

	public void serve(Socket s, long requestTimeout)
	{
		try
		{
			FitnesseExpediter sender = new FitnesseExpediter(s, context);
			sender.setRequestTimeout(requestTimeout);
			sender.start();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}