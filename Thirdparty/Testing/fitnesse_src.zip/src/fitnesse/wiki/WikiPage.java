// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.wiki;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.List;

public interface WikiPage extends Serializable, Comparable
{
	SimpleDateFormat versionNameFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	String[] STANDARD_ATTRIBUTES = {"Test", "Search", "Edit", "Properties", "Suite", "Versions", "Refactor"};

	public WikiPage getParent() throws Exception;

	public WikiPage addPage(String path) throws Exception;
	public WikiPage addPage(String path, String content) throws Exception;
	public WikiPage addChildPage(String name) throws Exception;

	public boolean hasChildPage(String name) throws Exception;
	public WikiPage getChildPage(String name) throws Exception;
	public List getChildren() throws Exception;
	public List getCachedChildren() throws Exception;

	public void removePage(String name) throws Exception;

	public void resetVirtualCoupling() throws Exception;
	public WikiPage getVirtualCoupling() throws Exception;

	public boolean isRemote();

	public String getName() throws Exception;
	public void setName(String newName) throws Exception;
	public boolean renamePage(String pageName, String newName) throws Exception;

	public boolean isRoot() throws Exception;
	public WikiPage getRoot() throws Exception;

	public String getBackgroundColor();

	public PageData getData() throws Exception;
	public PageData getData(String versionName) throws Exception;
	public void dumpExpiredCachedData() throws Exception;

	public CommitRecord commit(PageData data) throws Exception;
	public void commitWithoutVersion(PageData data) throws Exception;

	public class CommitRecord {
		public final String perviousVersion;

		public CommitRecord(String perviousVersion)
		{
			this.perviousVersion = perviousVersion;
		}
	}
}



