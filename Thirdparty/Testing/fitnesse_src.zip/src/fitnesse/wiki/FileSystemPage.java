// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import java.io.*;
import java.util.*;
import java.util.regex.Pattern;
import java.util.zip.*;

public class FileSystemPage extends RawPage
{
	public static final String contentFilename = "/content.txt";
	public static final String propertiesFilename = "/properties.xml";
	private String path;

	private FileSystemPage(String path, String name, WikiPage parent) throws Exception
	{
		super(name, parent);
		this.path = path;
	}

	public static WikiPage makeRoot(String path, String name) throws Exception
	{
		FileSystemPage root = new FileSystemPage(path, name, null);
		return root;
	}

	public void removePage(String name) throws Exception
	{
		super.removePage(name);
		File fileToBeDeleted = new File(getFileSystemPath() + "/" + name);
		deleteDirectoryHierarchy(fileToBeDeleted);
	}

	public boolean renamePage(String pageName, String newName) throws Exception
	{
		if(!super.renamePage(pageName, newName))
			return false;

		File page = new File(getFileSystemPath() + "/" + pageName);
		page.renameTo(new File(getFileSystemPath() + "/" + newName));
		return true;
	}

	public boolean hasChildPage(String pageName) throws Exception
	{
		File f = new File(getFileSystemPath() + "/" + pageName);
		if(f.exists())
		{
			FileSystemPage page = new FileSystemPage(path, pageName, this);
			children.put(pageName, page);
			return true;
		}
		else
			return false;
	}

	protected synchronized void saveContent(String content) throws Exception
	{
		if(content == null)
			return;

		if(content.endsWith("|"))
			content += "\n";

		File output = new File(getFileSystemPath() + contentFilename);
		FileWriter writer = new FileWriter(output);
		writer.write(content);
		writer.close();
	}

	private synchronized void saveAttributes(WikiPageProperties attributes) throws Exception
	{
		String propertiesFileName = getFileSystemPath() + propertiesFilename;
		OutputStream output = new FileOutputStream(propertiesFileName);
		attributes.save(output);
		output.close();
	}

	protected RawPage createChildPage(String name) throws Exception
	{
		FileSystemPage newPage = new FileSystemPage(path, name, this);
		new File(newPage.getFileSystemPath()).mkdirs();
		return newPage;
	}

	private void loadContent(PageData data) throws Exception
	{
		String content = "";

		String name = getFileSystemPath() + contentFilename;
		File input = new File(name);
		if(input.exists())
		{
			char chars[] = new char[0];
			chars = new char[(int) (input.length())];
			FileReader in = new FileReader(input);
			in.read(chars);
			in.close();
			content = new String(chars);
		}
		data.setContent(content);
	}

	protected void loadChildren() throws Exception
	{
		File thisDir = new File(getFileSystemPath());
		String[] subFiles = thisDir.list();
		for(int i = 0; i < subFiles.length; i++)
		{
			String subFile = subFiles[i];
			if(fileIsValid(subFile, thisDir) && !children.containsKey(subFile))
				children.put(subFile, getChildPage(subFile));
		}
	}

	private boolean fileIsValid(String filename, File dir)
	{
		if(PageCrawler.nameIsValid(filename))
		{
			File f = new File(dir, filename);
			if(f.isDirectory())
				return true;
		}
		return false;
	}

	private String getParentFileSystemPath() throws Exception
	{
		return (parent != null) ? ((FileSystemPage) parent).getFileSystemPath() : path;
	}

	public String getFileSystemPath() throws Exception
	{
		return getParentFileSystemPath() + "/" + getName();
	}

	private void loadAttributes(PageData data) throws Exception
	{
		WikiPageProperties props = new WikiPageProperties();
		File file = new File(getFileSystemPath() + propertiesFilename);
		if(file.exists())
		{
			InputStream input = new FileInputStream(file);
			props.loadXml(input);
			input.close();
			data.setAttributes(props);
		}
	}

	public void doCommit(PageData data) throws Exception
	{
		saveContent(data.getContent());
		saveAttributes(data.getAttributes());
	}

	protected PageData makePageData() throws Exception
	{
		PageData pagedata = new PageData(this);
		pagedata.setLastModificationTime(getLastModifiedDate());
		loadContent(pagedata);
		loadAttributes(pagedata);
		loadVersionNames(pagedata);
		return pagedata;
	}

	public PageData getData(String versionName) throws Exception
	{
		String filename = getFileSystemPath() + "/" + versionName + ".zip";
		File file = new File(filename);
		if(!file.exists())
			throw new NoSuchVersionException("There is no version '" + versionName + "'");

		PageData data = new PageData(this);
		data.setLastModificationTime(getLastModifiedDate());
		ZipFile zipFile = new ZipFile(file);
		loadVersionContent(zipFile, data);
		loadVersionAttributes(zipFile, data);
		loadVersionNames(data);
		zipFile.close();
		return data;
	}

	private void loadVersionNames(PageData data) throws Exception
	{
		File dir = new File(getFileSystemPath());
		File[] files = dir.listFiles();
		if(files != null)
		{
			Set versions = new HashSet();
			for(int i = 0; i < files.length; i++)
			{
				File file = files[i];
				if(isVersionFile(file))
					versions.add(makeVersionName(file));
			}
			data.addVersionNames(versions);
		}
	}

	protected String makeVersion() throws Exception
	{
		String dirPath = getFileSystemPath();
		Set filesToZip = getFilesToZip(dirPath);
		String name = versionNameFormat.format(getVersionDate());

		if(filesToZip.size() == 0)
			return "first_commit";

		String filename = makeVersionFileName(name);
		ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(filename));

		for(Iterator iterator = filesToZip.iterator(); iterator.hasNext();)
			addToZip((File) iterator.next(), zos);

		zos.finish();
		zos.close();
		return name;
	}

	private String makeVersionFileName(String name) throws Exception
	{
		return getFileSystemPath() + "/" + name + ".zip";
	}

	protected void removeVersion(String versionName) throws Exception
	{
		String versionFileName = makeVersionFileName(versionName);
		File versionFile = new File(versionFileName);
		versionFile.delete();
	}

	private Set getFilesToZip(String dirPath)
	{
		Set filesToZip = new HashSet();
		File dir = new File(dirPath);
		File[] files = dir.listFiles();
		if(files == null)
			return filesToZip;
		for(int i = 0; i < files.length; i++)
		{
			File file = files[i];
			if(!(isVersionFile(file) || file.isDirectory()))
				filesToZip.add(file);
		}
		return filesToZip;
	}

	private boolean isVersionFile(File file)
	{
		return Pattern.matches("\\d+\\.zip", file.getName());
	}

	private void addToZip(File file, ZipOutputStream zos) throws IOException
	{
		ZipEntry entry = new ZipEntry(file.getName());
		zos.putNextEntry(entry);
		FileInputStream is = new FileInputStream(file);
		int size = (int) file.length();
		byte[] bytes = new byte[size];
		is.read(bytes);
		is.close();
		zos.write(bytes, 0, size);

	}

	private void loadVersionContent(ZipFile zipFile, PageData data) throws Exception
	{
		String content = "";
		ZipEntry contentEntry = zipFile.getEntry("content.txt");
		if(contentEntry != null)
		{
			InputStream contentIS = zipFile.getInputStream(contentEntry);
			InputStreamReader reader = new InputStreamReader(contentIS);
			char[] chars = new char[(int) contentEntry.getSize()];
			reader.read(chars);
			reader.close();
			content = new String(chars);
		}
		data.setContent(content);
	}

	private void loadVersionAttributes(ZipFile zipFile, PageData data) throws Exception
	{
		ZipEntry attributes = zipFile.getEntry(propertiesFilename);
		if(attributes != null)
		{
			InputStream attributeIS = zipFile.getInputStream(attributes);
			WikiPageProperties props = new WikiPageProperties(attributeIS);
			attributeIS.close();
			data.setAttributes(props);
		}
	}

	private String makeVersionName(File file)
	{
		String name = file.getName();
		return name.substring(0, name.length() - 4);
	}

	private Date getLastModifiedDate() throws Exception
	{
		long content = new File(getFileSystemPath() + contentFilename).lastModified();
		long properties = new File(getFileSystemPath() + propertiesFilename).lastModified();
		if(content > properties)
			return new Date(content);
		else
			return new Date(properties);
	}

	void deleteDirectoryHierarchy(File file)
	{
		if(file.isDirectory())
		{
			File[] children = file.listFiles();
			for(int i = 0; i < children.length; i++)
			{
				File child = children[i];
				deleteDirectoryHierarchy(child);

			}
		}
		file.delete();
	}
}
