// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.testutil.FitnesseUtil;
import java.util.List;


public class RawPageVirtualTest extends TestCase
{
	public WikiPage root;
	public RawPage page1;
	public WikiPage page2;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RawPageVirtualTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		FitnesseUtil.startFitnesse(root);

		page2 = root.addPage("PageTwo", "page two");
		page2.addPage("PageTwoChild", "page two child");
		page1 = (RawPage) root.addPage("PageOne", "page one content\n!contents\n");
		page1.addPage("SomeOtherPage", "some other page");

		setVirtualWiki(page1, "http://localhost:" + FitnesseUtil.port  + "/PageTwo");
	}

	public static void setVirtualWiki(WikiPage page, String virtualWikiURL) throws Exception
	{
		PageData data = page.getData();
		data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, virtualWikiURL);
		page.commit(data);
	}

	public void tearDown() throws Exception
	{
		FitnesseUtil.stopFitnesse();
	}

	public void testVirtualSubPage() throws Exception
	{
		assertNull(page1.getChildPage("PageTwoChild"));
		assertNotNull(page1.getVirtualSubpage("PageTwoChild"));
		assertNull(page1.getVirtualSubpage("PageTwo"));
		WikiPage child1 = page1.getVirtualSubpage("PageTwoChild");
		assertTrue(child1 instanceof ProxyPage);
		assertEquals("page two child", child1.getData().getContent());
	}

	public void testGetChildren() throws Exception
	{
		List children = page1.getChildren();
		assertEquals(1, children.size());
		assertEquals("SomeOtherPage", ((WikiPage)children.get(0)).getName());

		children = page1.getVirtualCoupling().getChildren();
		assertEquals(1, children.size());
		assertTrue(children.get(0) instanceof ProxyPage);
		assertEquals("PageTwoChild", ((WikiPage)children.get(0)).getName());
	}

	public void testNewProxyChildrenAreFound() throws Exception
	{
		RawPage.cacheTime = 0;
		RawPage realChild = (RawPage) page2.getChildPage("PageTwoChild");

		ProxyPage childProxy = (ProxyPage) new VirtualEnabledPageCrawler().getPage(page1, "PageTwoChild");
		assertNull(childProxy.getChildPage("AnotherChild"));

		realChild.addPage("AnotherChild", "another child");
		assertNotNull(childProxy.getChildPage("AnotherChild"));
	}

	public void testProxyChildrenAreFoundOnStartUp() throws Exception
	{
		WikiPage page3 = root.addPage("PageThree", "page three content");
		setVirtualWiki(page3, "http://localhost:" + FitnesseUtil.port  + "/PageTwo");
		List children = page3.getVirtualCoupling().getChildren();
		assertEquals(1, children.size());
		assertEquals("PageTwoChild", ((WikiPage)children.get(0)).getName());
	}

	public void testGetChildrenOnlyAsksOnce() throws Exception
	{
		ProxyPage.retrievalCount = 0;
		page1.getVirtualCoupling().getChildren();
		assertEquals(1, ProxyPage.retrievalCount);
	}

	public void testNoNastyExceptionIsThrownWhenVirutalChildrenAreLoaded() throws Exception
	{
		WikiPage page3 = root.addPage("PageThree", "page three content");
		setVirtualWiki(page3, "http://google.com/SomePage");
		try
		{
			page3.getVirtualCoupling().getChildren();
			assertNotNull(page3.getChildPage("VirtualWikiNetworkError"));
		}
		catch(Exception e)
		{
			e.printStackTrace();
			fail("an exception was thrown");
		}
	}

}