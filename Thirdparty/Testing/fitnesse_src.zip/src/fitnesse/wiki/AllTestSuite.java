// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("Wiki All Test Suite");
		suite.addTest(new TestSuite(RawPageTest.class));
		suite.addTest(new TestSuite(RawPageVirtualTest.class));
		suite.addTest(new TestSuite(FileSystemPageTest.class));
		suite.addTest(new TestSuite(ProxyPageTest.class));
		suite.addTest(new TestSuite(PageDataTest.class));
		suite.addTest(new TestSuite(FileSystemPageVersioningTest.class));
		suite.addTest(new TestSuite(WikiPagePropertiesTest.class));
		suite.addTest(new TestSuite(XmlWriterTest.class));
		suite.addTest(new TestSuite(FixtureListBuilderTest.class));
		suite.addTest(new TestSuite(PageCrawlerTest.class));
		suite.addTest(new TestSuite(VirtualEnabledPageCrawlerTest.class));
		suite.addTest(new TestSuite(MockingPageCrawlerTest.class));

		return suite;
	}
}