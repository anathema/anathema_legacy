// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import java.util.*;

public class NullVirtualCouplingPage extends VirtualCouplingPage
{
	public NullVirtualCouplingPage(RawPage hostPage) throws Exception
	{
		super(hostPage);
	}

	public List getChildren() throws Exception
	{
		return new ArrayList();
	}
}
