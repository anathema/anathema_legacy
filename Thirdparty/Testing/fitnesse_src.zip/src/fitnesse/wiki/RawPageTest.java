// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.wiki;

import junit.framework.TestCase;
import junit.swingui.TestRunner;
import java.util.*;

public class RawPageTest extends TestCase
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RawPageTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
	}

	public void testCreate() throws Exception
	{
		String alpha = "AlphaAlpha";
		WikiPage root = InMemoryPage.makeRoot("root");
		assertFalse(root.hasChildPage(alpha));

		root.addPage(alpha, "content");
		assertTrue(root.hasChildPage(alpha));

	}

	public void testRecursiveAddbyName() throws Exception
	{
		root.addPage("AaAa", "its content");
		assertTrue(root.hasChildPage("AaAa"));

		root.addPage("AaAa.BbBb", "floop");
		assertTrue(new PageCrawler().pageExists(root, "AaAa.BbBb"));
		assertEquals("floop", new PageCrawler().getPage(root, "AaAa.BbBb").getData().getContent());
	}

	public void testTwoLevel() throws Exception
	{
		String alpha = "AlphaAlpha";
		String beta = "BetaBeta";
		WikiPage subPage1 = root.addPage(alpha, "");
		subPage1.addPage(beta, "");
		assertTrue(new PageCrawler().pageExists(root, alpha + "." + beta));

	}

	public void testTrailingDot() throws Exception
	{
		String alpha = "AlphaAlpha";
		root.addPage(alpha, "");
		assertFalse(new PageCrawler().pageExists(root, alpha + "."));

	}

	public void testDoubleDot() throws Exception
	{
		String alpha = "AlphaAlpha";
		String beta = "BetaBeta";
		WikiPage subPage1 = root.addPage(alpha, "");
		subPage1.addPage(beta, "");
		assertFalse(new PageCrawler().pageExists(root, alpha + ".." + beta));

	}

	public void testGetContent() throws Exception
	{
		String alpha = "AlphaAlpha";
		WikiPage a = root.addPage(alpha, "a");

		assertEquals("a", a.getData().getContent());
	}

	public void testReplaceContent() throws Exception
	{
		String alpha = "AlphaAlpha";
		WikiPage page = root.addPage(alpha, "a");

		PageData data = page.getData();
		data.setContent("b");
		page.commit(data);
		assertEquals("b", page.getData().getContent());
	}

	public void testClearPage() throws Exception
	{
		String child = "ChildPage";
		root.addPage(child, "content");
		assertTrue(root.hasChildPage(child));
		root.removePage(child);
		assertFalse(root.hasChildPage(child));
	}

	public void testRenamePage() throws Exception
	{
		final String oldPageName = "ChildPage";
		final String newPageName = "RenamedChildPage";

		root.addPage(oldPageName, "some content");
		assertTrue(root.hasChildPage(oldPageName));
		assertTrue(!root.hasChildPage(newPageName));

		root.renamePage(oldPageName, newPageName);

		assertTrue(!root.hasChildPage(oldPageName));
		assertTrue(root.hasChildPage(newPageName));
		assertEquals("some content", new PageCrawler().getPage(root, newPageName).getData().getContent());
	}

	public void testGetParent() throws Exception
	{
		WikiPage child1 = root.addPage("ChildOne", "ChildOne");
		WikiPage child2 = child1.addPage("ChildTwo", "ChildTwo");

		assertSame(child1, child2.getParent());
		assertSame(root, child1.getParent());
		assertEquals(root, root.getParent());
	}

	public void testIsRoot() throws Exception
	{
		assertTrue(root.isRoot());
		WikiPage page = root.addPage("PageOne");
		assertFalse(page.isRoot());
	}

	public void testGetName() throws Exception
	{
		WikiPage frontPage = root.addPage("FrontPage", "FrontPage");
		WikiPage c1 = frontPage.addPage("ChildOne", "ChildOne");
		assertEquals("ChildOne", c1.getName());
		assertEquals("FrontPage.ChildOne", new PageCrawler().getQualifiedName(c1));
	}

	public void testDefaultAttributes() throws Exception
	{
		WikiPage page = root.addPage("SomePage", "");
		assertTrue(page.getData().hasAttribute("Edit"));
		assertTrue(page.getData().hasAttribute("Search"));
		assertFalse(page.getData().hasAttribute("Test"));
		assertFalse(page.getData().hasAttribute("TestSuite"));
	}

	public void testSetAttributes() throws Exception
	{
		PageData data = root.getData();
		data.setAttribute("Test", "true");
		data.setAttribute("Search", "true");
		root.commit(data);
		assertTrue(root.getData().hasAttribute("Test"));
		assertTrue(root.getData().hasAttribute("Search"));

		assertEquals("true", root.getData().getAttribute("Test"));
	}

	public void testSimpleVersionTaskes() throws Exception
	{
		WikiPage page = root.addPage("PageOne", "old content");
		PageData data = page.getData();
		data.setContent("new content");
		WikiPage.CommitRecord commitRecord = page.commit(data);
		String previousVersion = commitRecord.perviousVersion;

		data = page.getData();
		Set versionNames = data.getVersionNames();
		assertEquals(1, versionNames.size());
		assertEquals(true, versionNames.contains(previousVersion));

		PageData loadedData = page.getData(previousVersion);
		assertSame(page, loadedData.getWikiPage());
		assertEquals("old content", loadedData.getContent());
	}

	public void testNoVersionException() throws Exception
	{
		WikiPage page = root.addPage("PageOne", "old content");
		try
		{
			page.getData("abc");
			fail("a NoSuchVersionException should have been thrown");
		}
		catch(NoSuchVersionException e)
		{
			assertEquals("There is no version 'abc'", e.getMessage());
		}
	}

	public void testPageDataIsCached() throws Exception
	{
		RawPage.cacheTime = 100;
		WikiPage page = root.addPage("PageOne", "some content");

		PageData data1 = page.getData();
		PageData data2 = page.getData();
		Thread.sleep(200);

		PageData data3 = page.getData();

		assertSame(data1, data2);
		assertNotSame(data1, data3);
	}

	public void testDumpCachedExpiredData() throws Exception
	{
		RawPage.cacheTime = 100;
		RawPage page = (RawPage) root.addPage("PageOne", "some content");
		PageData data = page.getData();
		assertSame(data, page.getCachedData());
		Thread.sleep(200);
		page.dumpExpiredCachedData();
		assertNull(page.getCachedData());
	}

	public void testGetPageThatStartsWithDot() throws Exception
	{
		WikiPage page1 = root.addPage("PageOne", "page one");
		WikiPage child1 = root.addPage("PageOne.ChildOne", "child one");
      PageCrawler crawler = new PageCrawler();
		assertSame(page1, crawler.getPage(page1, ".PageOne"));
		assertSame(child1, crawler.getPage(page1, ".PageOne.ChildOne"));
		assertSame(page1, crawler.getPage(child1, ".PageOne"));
	}

	public void testGetPageUsingRootKeyWord() throws Exception
	{
		WikiPage page1 = root.addPage("PageOne", "page one");
		assertSame(root, new PageCrawler().getPage(page1, "root"));
		assertSame(root, new PageCrawler().getPage(root, "root"));
	}

	public void testEquals() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage pageOne = root.addPage("PageOne", "content");
		assertEquals(pageOne, pageOne);

		root.removePage("PageOne");
		WikiPage pageOneOne = root.addPage("PageOne");
		assertEquals(pageOne, pageOneOne);
	}

	public void testCachedDataIsTrashedBeforeOutOfMemoryError() throws Exception
	{
		RawPage page = (RawPage)root.addPage("SomePage", "some content");
		page.getData();
		assertTrue(page.getCachedData() != null);
		boolean exceptionThrown = false;
		try
		{
			new MemoryEater();
		}
		catch(OutOfMemoryError e)
		{
			assertTrue(page.getCachedData() == null);
			exceptionThrown = true;
		}
		assertTrue(exceptionThrown);
	}

	class MemoryEater
	{
		long[] array = new long[1000000];
		MemoryEater eater = new MemoryEater();
	}
}
