// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import fitnesse.wikitext.widgets.*;
import fitnesse.wikitext.WidgetBuilder;
import fitnesse.responders.*;
import fitnesse.responders.run.RunAllResponder;
import fitnesse.responders.editing.EditResponder;
import fitnesse.components.SaveRecorder;

import java.util.*;
import java.io.Serializable;

public class PageData implements Serializable
{
	private transient WidgetRoot preProcessedRoot;
	private transient WikiPage wikiPage;
	private String content;
	private WikiPageProperties attributes = new WikiPageProperties();
	private Set versionNames;
	private Date lastModified = new Date(0);

	public PageData(WikiPage page) throws Exception
	{
		wikiPage = page;
		initializeAttributes();
		versionNames = new HashSet();
	}

	public PageData(WikiPage page, String content) throws Exception
	{
		this(page);
		setContent(content);
	}

	public PageData(PageData data) throws Exception
	{
		this(data.getWikiPage());
		wikiPage = data.wikiPage;
		content = data.content;
		attributes = data.attributes;
		lastModified = data.lastModified;
		addVersionNames(data.getVersionNames());
	}

	public String getStringOfAllAttributes()
	{
		return attributes.toString();
	}

	public void initializeAttributes() throws Exception
	{
		attributes.set("Edit", "true");
		attributes.set("Search", "true");
		attributes.set("Versions", "true");
		attributes.set("Properties", "true");
		attributes.set("Refactor", "true");
		attributes.set(EditResponder.TICKET_ID, SaveRecorder.newTicket() + "");

		final String pageName = wikiPage.getName();
		if(pageName.startsWith("Test"))
			attributes.set("Test", "true");
		if(pageName.startsWith("Suite") &&
		   !pageName.equals(RunAllResponder.SUITE_SETUP_NAME) &&
		   !pageName.equals(RunAllResponder.SUITE_TEARDOWN_NAME))
		{
			attributes.set("Suite", "true");
		}
	}

	public WikiPageProperties getAttributes() throws Exception
	{
		return attributes;
	}

	public String getAttribute(String key) throws Exception
	{
		return attributes.get(key);
	}

	public void removeAttribute(String key) throws Exception
	{
		attributes.remove(key);
	}

	public void setAttribute(String key, String value) throws Exception
	{
		attributes.set(key, value);
	}

	public void setAttribute(String key) throws Exception
	{
		attributes.set(key);
	}

	public boolean hasAttribute(String attribute) throws Exception
	{
		return attributes.has(attribute);
	}

	public void setAttributes(WikiPageProperties attributes)
	{
		this.attributes = attributes;
	}

	public String getContent() throws Exception
	{
		return content;
	}

	public void setContent(String content) throws Exception
	{
		this.content = content;
	}

	public String getHtml() throws Exception
	{
		String preProcessedContent = preProcess();
		return processHTMLWidgets(preProcessedContent, wikiPage);
	}

	public String getHtml(WikiPage context) throws Exception
	{
		String preProcessedContent = preProcess();
		return processHTMLWidgets(preProcessedContent, context);
	}

	public String getVariable(String name) throws Exception
	{
		preProcess();
		return preProcessedRoot.getVariable(name);
	}

	public String preProcess() throws Exception
	{
		if(preProcessedRoot != null)
			return preProcessedRoot.render();

		WidgetRoot preRoot = new WidgetRoot(getContent(), wikiPage, WidgetBuilder.preprocessingWidgetBuilder);
		preRoot.setEscaping(false);
		int evaluations = 0;
		while(preRoot.preProcessingComplete() == false)
		{
			if(evaluations >= 10)
				throw new Exception("Pre-processing did not converge.  Check for !define or !include cycles");
			else
				evaluations++;

			String renderedContent = preRoot.render();
			preRoot.reset();
			preRoot.addChildWidgets(renderedContent);
		}

		preProcessedRoot = preRoot;
		return preRoot.render();
	}

	private String processHTMLWidgets(String content, WikiPage context) throws Exception
	{
		WidgetRoot root = new WidgetRoot(content, context, WidgetBuilder.htmlWidgetBuilder);
		root.setLiterals(preProcessedRoot.getLiterals());
		return root.render();
	}

	public void setWikiPage(WikiPage page)
	{
		wikiPage = page;
	}

	public WikiPage getWikiPage()
	{
		return wikiPage;
	}

	public List getClasspaths() throws Exception
	{
		return getTextOfWidgets(WidgetBuilder.classpathWidgetBuilder);
	}

	public List getFixtureNames() throws Exception
	{
		return getTextOfWidgets(WidgetBuilder.fixtureWidgetBuilder);
	}

	private List getTextOfWidgets(WidgetBuilder builder) throws Exception
	{
		WidgetRoot root = new TextIgnoringWidgetRoot(preProcess(), wikiPage, builder);
        List widgets = root.getChildren();
        List values = new ArrayList();
        for (Iterator iterator = widgets.iterator(); iterator.hasNext();) {
            TextWidget widget = (TextWidget) iterator.next();
            values.add(widget.getText());
        }
        return values;
	}

	public Set getVersionNames()
	{
		return versionNames;
	}

	public void addVersionNames(Collection names)
	{
		versionNames.addAll(names);
	}

	public Date getLastModificationTime()
	{
		return lastModified;
	}

	public void setLastModificationTime(Date date)
	{
		lastModified = date;
	}
}
