// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import java.util.*;

public class FixtureListBuilder extends InheritedItemBuilder  // Singleton
{
	public static final String FIXTURES_PAGE_NAME = "FixtureList";
	private static FixtureListBuilder instance = new FixtureListBuilder();
	public static FixtureListBuilder instance()
	{
		return instance;
	}

	private FixtureListBuilder()
	{
	}

	public List getFixtureNames(WikiPage page) throws Exception
	{
		return getInheritedItems(page, new HashSet(89));
	}

	protected WikiPage getDeprecatedDirectivePage(WikiPage parent) throws Exception
	{
		return parent.getChildPage(FIXTURES_PAGE_NAME);
	}

	protected List getItemsFromPage(WikiPage page) throws Exception
	{
		return page.getData().getFixtureNames();
	}
}
