// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import fitnesse.Fitnesse;

import java.util.*;
import java.text.ParseException;

public class PageVersionPruner {
  private RawPage page;

  public PageVersionPruner(RawPage page) {
    this.page = page;
  }

  public void pruneVersions() throws Exception {
    List versionNames = makeSortedVersionList();
    if (versionNames.size() > 0) {
      String lastVersion = (String) versionNames.get(versionNames.size() - 1);
      GregorianCalendar expirationDate = makeVersionExpirationDate(lastVersion);
      for (Iterator iterator = versionNames.iterator(); iterator.hasNext();) {
        String version = (String) iterator.next();
        removeVersionIfExpired(version, expirationDate);
      }
    }
  }

  private List makeSortedVersionList() throws Exception {
    PageData data = page.makePageData();
    List versionNames = new ArrayList(data.getVersionNames());
    Collections.sort(versionNames);
    return versionNames;
  }

  private GregorianCalendar makeVersionExpirationDate(String lastVersion) throws ParseException {
    Date dateOfLastVersion = WikiPage.versionNameFormat.parse(lastVersion);
    GregorianCalendar expirationDate = new GregorianCalendar();
    expirationDate.setTime(dateOfLastVersion);
    expirationDate.add(Calendar.DAY_OF_MONTH, -(Fitnesse.daysTillVersionsExpire));
    return expirationDate;
  }

  private void removeVersionIfExpired(String version, GregorianCalendar expirationDate) throws Exception {
    Calendar thisDate = new GregorianCalendar();
    thisDate.setTime(WikiPage.versionNameFormat.parse(version));
    if (thisDate.before(expirationDate) || thisDate.equals(expirationDate)) {
      page.removeVersion(version);
    }
  }
}
