// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.*;
import fitnesse.testutil.FileUtil;
import fitnesse.Fitnesse;
import java.io.File;
import java.util.*;
import java.text.*;

public class FileSystemPageVersioningTest extends TestCase
{
	public FileSystemPage page;
	private String firstVersion;
	private PseudoVersionTimeSource versionTimeSource;

	public void setUp() throws Exception
	{
		WikiPage root = FileSystemPage.makeRoot("testDir", "RooT");
		page = (FileSystemPage) root.addPage("PageOne", "original content");
		versionTimeSource = new PseudoVersionTimeSource("20031213000000");
		page.setVersionTimeSource(versionTimeSource);

		PageData data = page.getData();
		WikiPage.CommitRecord commitRecord = page.commit(data);
		firstVersion = commitRecord.perviousVersion;
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testDir");
	}

	public void testSave() throws Exception
	{
		String dirPath = page.getFileSystemPath();
		File dir = new File(dirPath);
		String[] filenames = dir.list();

		List list = Arrays.asList(filenames);
		assertTrue(list.contains(firstVersion + ".zip"));
	}

	public void testLoad() throws Exception
	{
		PageData data = page.getData();
		data.setContent("new content");
		WikiPage.CommitRecord commitRecord = page.commit(data);

		PageData loadedData = page.getData(commitRecord.perviousVersion);
		assertEquals("original content", loadedData.getContent());
	}

	public void testGetVersions() throws Exception
	{
		Set versionNames = page.getData().getVersionNames();
		assertEquals(1, versionNames.size());
		assertTrue(versionNames.contains(firstVersion));
	}

	public void testSubWikisDontInterfere() throws Exception
	{
		page.addPage("SubPage", "sub page content");
		try
		{
			page.commit(page.getData());
		}
		catch(Exception e)
		{
			fail("this exception should not have been thrown: " + e.getMessage());
		}
	}

	public void testTwoVersions() throws Exception
	{
		PageData data = page.getData();
		data.setContent("new content");
		WikiPage.CommitRecord commitRecord = page.commit(data);
		String secondVersion = commitRecord.perviousVersion;
		Set versionNames = page.getData().getVersionNames();
		assertEquals(2,versionNames.size());
		assertTrue(versionNames.contains(firstVersion));
		assertTrue(versionNames.contains(secondVersion));
	}

	public void testVersionsExpire() throws Exception
	{
		Fitnesse.daysTillVersionsExpire = 3;
		PageData data = page.getData();

		versionTimeSource.setDate("20031213000000");
		page.commit(data);

		versionTimeSource.setDate("20031214000000");
		page.commit(data);

		versionTimeSource.setDate("20031215000000");
		page.commit(data);

		assertEquals(3,page.getData().getVersionNames().size());

		versionTimeSource.setDate("20031216000000");
		page.commit(data);

		Set versionNames = page.getData().getVersionNames();
		assertEquals(3,versionNames.size());
		assertTrue(versionNames.contains("20031214000000"));
		assertTrue(versionNames.contains("20031215000000"));
		assertTrue(versionNames.contains("20031216000000"));
	}

	// Supply dates without having to wait for time to change.
	static class PseudoVersionTimeSource extends RawPage.VersionTimeSource {
		private GregorianCalendar calendar;
		public PseudoVersionTimeSource(String startDate) throws Exception
		{
			calendar = new GregorianCalendar();
			setDate(startDate);
		}

		public void setDate(String startDate) throws ParseException
		{
			calendar.setTime(WikiPage.versionNameFormat.parse(startDate));
		}

		public Date getVersionDate()
		{
			Date date = calendar.getTime();
			calendar.add(Calendar.SECOND, 1);
			return date;
		}
	}
}
