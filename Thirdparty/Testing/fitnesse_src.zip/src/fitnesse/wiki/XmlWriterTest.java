// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.*;
import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;

public class XmlWriterTest extends TestCase
{
	private ByteArrayOutputStream output;
	private Document doc;

	static String sampleXml = null;

	static
	{
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		PrintWriter writer = new PrintWriter(out);
		writer.println("<?xml version=\"1.0\"?>");
		writer.println("<rootElement>");
		writer.println("\t<emptytElement/>");
		writer.println("\t<fullElement>");
		writer.println("\t\t<childElement/>");
		writer.println("\t</fullElement>");
		writer.println("\t<text>some text</text>");
		writer.println("</rootElement>");
		writer.flush();
		sampleXml = new String(out.toByteArray());
	}

	public void setUp() throws Exception
	{
		DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
		doc = builder.parse(new ByteArrayInputStream(sampleXml.getBytes()));
		output = new ByteArrayOutputStream();
	}

	public void tearDown() throws Exception
	{
	}

	public void testAll() throws Exception
	{
		XmlWriter writer = new XmlWriter(output);
		writer.write(doc);
		writer.flush();
		writer.close();

		String results = new String(output.toByteArray());
		assertEquals(sampleXml, results);
	}
}
