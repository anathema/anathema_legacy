// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import java.util.*;
import java.io.*;
import org.w3c.dom.*;
import fitnesse.util.XmlUtil;

public class WikiPageProperties implements Serializable
{

	private Map map;
	public static final String VIRTUAL_WIKI_ATTRIBUTE = "VirtualWiki";

	public WikiPageProperties() throws Exception
	{
		map = new HashMap();
	}

	public WikiPageProperties(Map map) throws Exception
	{
		this();
		for(Iterator iterator = map.keySet().iterator(); iterator.hasNext();)
		{
			String key = (String) iterator.next();
			String value = (String) map.get(key);
			if(! "false".equals(value))
				this.map.put(key, value);
		}
	}

	public WikiPageProperties(InputStream inputStream) throws Exception
	{
		this();
		loadXml(inputStream);
	}

	public void loadXml(InputStream inputStream) throws Exception
	{
		Document document = XmlUtil.newDocument(inputStream);
		Element root = document.getDocumentElement();
		NodeList nodes = root.getChildNodes();
		for(int i = 0; i < nodes.getLength(); i++)
		{
			Node node = nodes.item(i);
			if(node.getNodeType() != Node.ELEMENT_NODE)
				continue;
			String key = node.getNodeName();
            String value = node.hasChildNodes() ? node.getFirstChild().getNodeValue() : "true";
            map.put(key, value);
		}
	}

	public void save(OutputStream outputStream) throws Exception
	{
		Document document = XmlUtil.newDocument();
		Element root = document.createElement("properties");
		document.appendChild(root);

		List keys = new ArrayList(map.keySet());
		Collections.sort(keys);

		for(Iterator iterator = keys.iterator(); iterator.hasNext();)
		{
			String key = (String) iterator.next();
			String value = (String) map.get(key);
			Element element = document.createElement(key);
			if(!"true".equals(value))
				element.appendChild(document.createTextNode(value));
			root.appendChild(element);
		}

		XmlWriter writer = new XmlWriter(outputStream);
		writer.write(document);
		writer.flush();
		writer.close();
	}

	public boolean has(String key)
	{
		return map.containsKey(key);
	}

	public String get(String key) throws Exception
	{
		return (String)map.get(key);
	}

	public void set(String key, String value)
	{
		map.put(key, value);
	}

	public void set(String key)
	{
		set(key, "true");
	}

	public void remove(String key)
	{
		map.remove(key);
	}

	public Set keySet()
	{
		return map.keySet();
	}

	public String toString()
	{
		StringBuffer s = new StringBuffer("WikiPageProperties:\n");
		for(Iterator iterator = map.keySet().iterator(); iterator.hasNext();)
		{
			String key = (String) iterator.next();
      String value = (String) map.get(key);
			s.append("\t").append(key).append(" = ").append(value).append("\n");
		}
		return s.toString();
	}

}
