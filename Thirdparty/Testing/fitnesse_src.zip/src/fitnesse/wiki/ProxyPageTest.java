// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.testutil.FitnesseUtil;
import java.util.*;
public class ProxyPageTest extends TestCase
{
	private WikiPage root;
	private WikiPage original;
	private ProxyPage proxy;
	public WikiPage child1;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"ProxyPageTest"});
	}

	public void setUp() throws Exception
	{
		RawPage.cacheTime = 0;
		root = InMemoryPage.makeRoot("RooT");
		original = root.addPage("PageOne", "page one content");
		child1 = original.addPage("ChildOne", "child one");
		original.addPage("ChildTwo", "child two");
		PageData data = original.getData();
		data.setAttribute("Attr1", "true");
		original.commit(data);

		FitnesseUtil.startFitnesse(root);

		proxy = new ProxyPage(original);
		proxy.setHost("localhost");
		proxy.setHostPort(FitnesseUtil.port);
	}

	public void tearDown() throws Exception
	{
		FitnesseUtil.stopFitnesse();
	}

	public void testConstructor() throws Exception
	{
		assertEquals("page one content", proxy.getData().getContent());
		assertEquals("PageOne", proxy.getName());
		assertEquals("PageOne", new PageCrawler().getQualifiedName(proxy));
		assertEquals(true, proxy.getData().hasAttribute("Attr1"));
	}

	public void testHasChildren() throws Exception
	{
		assertEquals(false, proxy.hasChildPage("BlaH"));
		assertEquals(true, proxy.hasChildPage("ChildOne"));
		assertEquals(true, proxy.hasChildPage("ChildTwo"));
	}

	public void testGetChildrenOneAtATime() throws Exception
	{
		WikiPage child1 = proxy.getChildPage("ChildOne");
		assertEquals("child one", child1.getData().getContent());
		WikiPage child2 = proxy.getChildPage("ChildTwo");
		assertEquals("child two", child2.getData().getContent());
	}

	public void testGetAllChildren() throws Exception
	{
		List children = proxy.getChildren();
		assertEquals(2, children.size());
		WikiPage child = (WikiPage)children.get(0);
		assertEquals(true, "ChildOne".equals(child.getName()) || "ChildTwo".equals(child.getName()));
		child = (WikiPage)children.get(1);
		assertEquals(true, "ChildOne".equals(child.getName()) || "ChildTwo".equals(child.getName()));
	}

	public void testSetHostAndPort() throws Exception
	{
		List children = proxy.getChildren();
		proxy.setHost("a.new.host");
		proxy.setHostPort(123);

		assertEquals("a.new.host", proxy.getHost());
		assertEquals(123, proxy.getHostPort());

		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			ProxyPage page = (ProxyPage) iterator.next();
			assertEquals("a.new.host", page.getHost());
			assertEquals(123, page.getHostPort());
		}
	}

	public void testCanFindNewChildOfAProxy() throws Exception
	{
		ProxyPage child1Proxy = (ProxyPage) proxy.getChildPage("ChildOne");
		assertNull(child1Proxy.getChildPage("ChildOneChild"));

		child1.addPage("ChildOneChild", "child one child");
		assertNotNull(child1Proxy.getChildPage("ChildOneChild"));
	}

	public void testHasSubpageCallsLoadChildrenNoMoreThanNeeded() throws Exception
	{
		proxy.loadChildren();
		ProxyPage.retrievalCount = 0;
		proxy.hasChildPage("ChildTwo");
		assertEquals(0, ProxyPage.retrievalCount);
		proxy.hasChildPage("SomeMissingChild");
		assertEquals(1, ProxyPage.retrievalCount);
	}

	public void testChildrenAreCached() throws Exception
	{
		RawPage.cacheTime = 100;
		proxy.getChildren();
		int startingNumber = ProxyPage.retrievalCount;
		assertEquals(startingNumber, ProxyPage.retrievalCount);
		proxy.getChildren();
		assertEquals(startingNumber, ProxyPage.retrievalCount);
		Thread.sleep(200);
		proxy.getChildren();
		assertEquals(startingNumber + 1, ProxyPage.retrievalCount);
	}
}
