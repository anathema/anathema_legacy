// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.wiki;

import junit.framework.TestCase;
import junit.swingui.TestRunner;
import java.io.File;
import java.util.*;
import fitnesse.testutil.*;

public class FileSystemPageTest extends TestCase
{
	private static final String defaultPath = "./teststorage";
	private static final File base = new File(defaultPath);
	FileSystemPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"FileSystemPageTest"});
	}

	public void setUp() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(base);
		createFileSystemDirectory(base);
		root = (FileSystemPage) FileSystemPage.makeRoot(defaultPath, "RooT");
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(base);
		FileUtil.deleteFileSystemDirectory("RooT");
	}

	public static void createFileSystemDirectory(File current)
	{
		current.mkdir();
	}

	public void testCreateBase() throws Exception
	{
		FileSystemPage levelA = (FileSystemPage) root.addPage("PageA", "");
		assertEquals("./teststorage/RooT/PageA", levelA.getFileSystemPath());
		assertTrue(new File(defaultPath + "/RooT/PageA").exists());
	}

	public void testTwoLevel() throws Exception
	{
		WikiPage levelA = root.addPage("PageA", "");
		levelA.addPage("PageB", "");
		assertTrue(new File(defaultPath + "/RooT/PageA/PageB").exists());
	}

	public void testContent() throws Exception
	{
		assertEquals("", new PageCrawler().getPage(root, "").getData().getContent());
		root.addPage("AaAa", "A content");
		assertEquals("A content", root.getChildPage("AaAa").getData().getContent());
		root.addPage("AaAa.BbBb", "B content");
		assertEquals("B content", new PageCrawler().getPage(root, "AaAa.BbBb").getData().getContent());
	}

	public void testBigContent() throws Exception
	{
		StringBuffer buffer = new StringBuffer();
		for(int i = 0; i < 1000; i++) buffer.append("abcdefghijklmnopqrstuvwxyz");
		root.addPage("BigPage", buffer.toString());
		String content = root.getChildPage("BigPage").getData().getContent();
		assertTrue(buffer.toString().equals(content));
	}

	public void testPageExists() throws Exception
	{
		root.addPage("AaAa", "A content");
		assertTrue(root.hasChildPage("AaAa"));
	}

	public void testGetChidren() throws Exception
	{
		root.addPage("AaAa", "A content");
		root.addPage("BbBb", "B content");
		root.addPage("CcCc", "C content");
		new File(defaultPath + "/root/someOtherDir").mkdir();
		List children = root.getChildren();
		assertEquals(3, children.size());
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage child = (WikiPage) iterator.next();
			String name = child.getName();
			boolean isOk = "AaAa".equals(name) || "BbBb".equals(name) || "CcCc".equals(name);
			assertTrue("WikiPAge is not a valid one: " + name, isOk);
		}
	}

	public void testRemovePage() throws Exception
	{
		WikiPage levelOne = root.addPage("LevelOne");
		levelOne.addPage("LevelTwo");
		levelOne.removePage("LevelTwo");
		File fileOne = new File(defaultPath + "/RooT/LevelOne");
		File fileTwo = new File(defaultPath + "/RooT/LevelOne/LevelTwo");
		assertTrue(fileOne.exists());
		assertFalse(fileTwo.exists());
	}

	public void testDelTree() throws Exception
	{
		FileSystemPage fsRoot = (FileSystemPage)FileSystemPage.makeRoot(".", "RooT");
		fsRoot.addPage("LevelOne").addPage("LevelTwo");
		File childOne = new File("RooT/LevelOne");
		File childTwo = new File("RooT/LevelOne/LevelTwo");
		assertTrue(childOne.exists());
		fsRoot.deleteDirectoryHierarchy(childOne);
		assertFalse(childTwo.exists());
		assertFalse(childOne.exists());
	}

	public void testDefaultAttributes() throws Exception
	{
		WikiPage page = root.addPage("PageOne", "something");
		assertTrue(page.getData().hasAttribute("Edit"));
		assertTrue(page.getData().hasAttribute("Search"));
		assertFalse(page.getData().hasAttribute("Test"));
		assertFalse(page.getData().hasAttribute("TestSuite"));
	}

	public void testPersistentAttributes() throws Exception
	{
		root.addPage("FrontPage", "");
		WikiPage createdPage = root.getChildPage("FrontPage");
		PageData data = createdPage.getData();
		data.setAttribute("Test", "true");
		data.setAttribute("Search", "true");
		createdPage.commit(data);
		assertTrue(data.hasAttribute("Test"));
		assertTrue(data.hasAttribute("Search"));
		WikiPage page = root.getChildPage("FrontPage");
		assertTrue(page.getData().hasAttribute("Test"));
		assertTrue(page.getData().hasAttribute("Search"));
	}

	public void testCachedInfo() throws Exception
	{
		WikiPage page1 = root.addPage("PageOne", "page one");
		WikiPage child1 = page1.addPage("ChildOne", "child one");
		WikiPage child = page1.getChildPage("ChildOne");
		assertSame(child1, child);
	}

	public void testCanFindExistingPages() throws Exception
	{
		root.addPage("FrontPage", "front page");
		WikiPage newRoot = FileSystemPage.makeRoot(defaultPath, "RooT");
		assertNotNull(newRoot.getChildPage("FrontPage"));
	}

	public void testGetPath() throws Exception
	{
		assertEquals(defaultPath + "/RooT", root.getFileSystemPath());
	}

	public void testLastModifiedTime() throws Exception
	{
		WikiPage page = root.addPage("SomePage", "some text");
		page.commit(page.getData());
		Date now = new Date();
		Date lastModified = page.getData().getLastModificationTime();
		assertTrue(now.getTime() - lastModified.getTime() <= 1000);
	}

	public void testRenamePage() throws Exception
	{
		final String oldPageName = "ChildPage";
		final String newPageName = "RenamedChildPage";
		root.addPage(oldPageName, "Child content");
		File childPage = new File(defaultPath + "/RooT/" + oldPageName);
		File renamedPage = new File(defaultPath + "/RooT/" + newPageName);
		assertTrue(childPage.exists());

		root.renamePage(oldPageName, newPageName);
		assertTrue(renamedPage.exists());
		assertFalse(childPage.exists());		
	}
}
