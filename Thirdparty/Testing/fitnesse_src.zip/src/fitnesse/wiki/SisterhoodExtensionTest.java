// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import junit.framework.*;
import org.w3c.dom.Document;
import fitnesse.util.XmlUtil;

public class SisterhoodExtensionTest extends TestCase
{
	public void setUp() throws Exception
	{
		Document doc = XmlUtil.newDocument();
	}

	public void tearDown() throws Exception
	{
	}

	public void testCreation() throws Exception
	{

	}
}
