// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.wiki;

import fitnesse.responders.*;
import fitnesse.Fitnesse;
import java.util.*;
import java.lang.ref.SoftReference;
import java.text.ParseException;

public abstract class RawPage implements WikiPage
{
	public static int cacheTime = 3000;
	public static final String BG_COLOR = "#FFFFFF";

	protected String name;
	protected WikiPage parent;
	protected HashMap children = new HashMap();
	protected VirtualCouplingPage virtualCoupling;

	public transient boolean virtualChildrenLoaded = false;
	private transient SoftReference cachedData;
	private transient long cachedDataCreationTime = 0;
	private transient VersionTimeSource versionTimeSource = new VersionTimeSource();

	public RawPage(String name, WikiPage parent) throws Exception
	{
		this.name = name;
		this.parent = parent;
		resetVirtualCoupling();
	}

	public abstract boolean hasChildPage(String pageName) throws Exception;

	protected abstract RawPage createChildPage(String name) throws Exception;

	protected abstract void loadChildren() throws Exception;

	protected abstract PageData makePageData() throws Exception;

	protected abstract void doCommit(PageData data) throws Exception;

	protected abstract String makeVersion() throws Exception;

	protected abstract void removeVersion(String versionName) throws Exception;

	public WikiPage getParent() throws Exception
	{
		return isRoot() ? this : parent;
	}

	public boolean isRoot() throws Exception
	{
		return parent == null;
	}

	public boolean isRemote()
	{
		return false;
	}

	public WikiPage addPage(String path, String content) throws Exception
	{
		WikiPage page = addPage(path);
		if(page != null)
		{
			PageData data = new PageData(page);
			data.setContent(content);
			page.commit(data);
		}
		return page;
	}

	public WikiPage addPage(String path) throws Exception
	{
		return new PageCrawler().getOrMakePage(this, path);
	}

	public String getName() throws Exception
	{
		return name;
	}

	public void setName(String newName) throws Exception
	{
		name = newName;
	}

	public WikiPage getRoot() throws Exception
	{
		if(parent == null)
			return this;
		else
			return parent.getRoot();
	}

	public String toString()
	{
		return this.getClass() + " : " + name;
	}

	public WikiPage addChildPage(String name) throws Exception
	{
		RawPage page = createChildPage(name);
		children.put(name, page);
		return page;
	}

	public List getChildren() throws Exception
	{
		loadChildren();
		return getCachedChildren();
	}

	public List getCachedChildren() throws Exception
	{
		return new ArrayList(children.values());
	}

	public void resetVirtualCoupling() throws Exception
	{
		virtualCoupling = new NullVirtualCouplingPage(this);
	}

	public void removePage(String name) throws Exception
	{
		if(hasCachedSubpage(name))
			children.remove(name);
	}

	// TODO I don't think this method is needed as long as we have setName(). The logic here should go into RenamePageResponder.
	public boolean renamePage(String pageName, String newName) throws Exception
	{
		if(hasCachedSubpage(pageName) && !hasCachedSubpage(newName))
		{
			WikiPage thePage = getChildPage(pageName);
			thePage.setName(newName);
			children.put(newName, thePage);
			children.remove(pageName);
			return true;
		}
		return false;
	}

	public WikiPage getChildPage(String name) throws Exception
	{
		if(hasCachedSubpage(name) || hasChildPage(name))
			return (WikiPage) children.get(name);
		else
			return null;
	}

	public WikiPage getVirtualSubpage(String name) throws Exception
	{
		detectAndLoadVirtualChildren();
		return virtualCoupling.getChildPage(name);
	}

	protected void detectAndLoadVirtualChildren() throws Exception
	{
		PageData data = getData();
		if(data.hasAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE))
			loadVirtualChildren(data.getAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE));
	}

	protected boolean hasCachedSubpage(String name)
	{
		return children.containsKey(name);
	}

	public void loadVirtualChildren(String url) throws Exception
	{
		try
		{
			ProxyPage proxy = ProxyPage.retrievePage(url);
			virtualCoupling = new VirtualCouplingPage(this, proxy);
		}
		catch(Exception e)
		{
			WikiPage page = (WikiPage) children.get("VirtualWikiNetworkError");
			if(page == null)
				page = addChildPage("VirtualWikiNetworkError");
			PageData data = page.getData();
			data.setContent("{{{" + ErrorResponder.makeExceptionString(e) + "}}}");
			page.commit(data);
		}
	}

	public String getBackgroundColor()
	{
		return BG_COLOR;
	}

	public int compareTo(Object o)
	{
		try
		{
			return getName().compareTo(((WikiPage) o).getName());
		}
		catch(Exception e)
		{
			return 0;
		}
	}

	protected void checkVersionIsValid(PageData version, String versionName) throws NoSuchVersionException
	{
		if(version == null)
			throw new NoSuchVersionException("There is no version '" + versionName + "'");
	}

	public PageData getData() throws Exception
	{
		if(cachedDataExpired())
		{
			cachedDataCreationTime = System.currentTimeMillis();
			setCachedData(makePageData());
		}
		return getCachedData();
	}

	private boolean cachedDataExpired() throws Exception
	{
		long now = System.currentTimeMillis();
		boolean expired = getCachedData() == null || now >= (cachedDataCreationTime + cacheTime);
		return expired;
	}

	public void dumpExpiredCachedData() throws Exception
	{
		if(cachedDataExpired())
			clearCachedData();
	}

	public WikiPage.CommitRecord commit(PageData data) throws Exception
	{
    String previousVersion = makeVersion();
    PageVersionPruner pruner = new PageVersionPruner(this);
    pruner.pruneVersions();
		commitWithoutVersion(data);
		return new CommitRecord(previousVersion);
	}

	public void commitWithoutVersion(PageData data) throws Exception
	{
		clearCachedData();
		doCommit(data);
	}

	public boolean equals(Object o)
	{
		if(this == o)
			return true;
		if(!(o instanceof WikiPage))
			return false;
		try
		{
			return new PageCrawler().getQualifiedName(this).equals(new PageCrawler().getQualifiedName(((WikiPage) o)));
		}
		catch(Exception e)
		{
			return false;
		}
	}

	public WikiPage getVirtualCoupling() throws Exception
	{
		detectAndLoadVirtualChildren();
		return virtualCoupling;
	}

	private void setCachedData(PageData data)
	{
		cachedData = new SoftReference(data);
	}

	private void clearCachedData()
	{
		if(cachedData != null)
			cachedData.clear();
	}

	public PageData getCachedData()
	{
		if(cachedData != null)
			return (PageData) cachedData.get();
		else
			return null;
	}

	protected Date getVersionDate()
	{
		return versionTimeSource.getVersionDate();
	}

  // Test Method, So unit tests can control the way time passes for versions.
	protected void setVersionTimeSource(VersionTimeSource versionTimeSource)
	{
		this.versionTimeSource = versionTimeSource;
	}

	static class VersionTimeSource
	{
		public Date getVersionDate()
		{
			return new Date();
		}
	}
}