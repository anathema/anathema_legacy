// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.

package fitnesse.wiki;

import java.util.*;

public class MockWikiPage implements WikiPage
{
	public String name;
	protected String location;
	private String bgColor = "#FFFFFF";
	private PageData pageData;
	private WikiPage parent;
	public static final int daysTillVersionsExpire = 14;

	public MockWikiPage(String name, String content, String bgColor) throws Exception
	{
		this.name = name;
		pageData = new PageData(this, content);
		this.bgColor = bgColor;
	}

	public MockWikiPage(String name, String location)
	{
		this.location = location;
		this.name = name;
	}

	public MockWikiPage(String location)
	{
		this.location = location;
		name = "Default";
	}

	public MockWikiPage()
	{
		location = null;
		name = "Default";
	}

	public String getBackgroundColor()
	{
		return bgColor;
	}

	public void loadVirtualChildren(String url) throws Exception
	{
	}

	public String getName()
	{
		return name;
	}

	public void setName(String newName)
	{
		name = newName;
	}

	public WikiPage getParent()
	{
		return parent;
	}

	public boolean isRoot() throws Exception
	{
		return false;
	}

	public boolean isRemote()
	{
		return false;
	}

	public void setParent(WikiPage parent)
	{
		this.parent = parent;
	}

	public WikiPage addPage(String path, String content)
	{
		return null;
	}

	public WikiPage addPage(String path)
	{
		return null;
	}

	public PageData getData() throws Exception
	{
		return pageData;
	}

	public WikiPage.CommitRecord commit(PageData data) throws Exception
	{
		pageData = data;
		return new CommitRecord("mockVersionNumber");
	}

	public List getChildren()
	{
		return new ArrayList();
	}

	public void setAttributes(String[] attributes)
	{
	}

	public WikiPage getRoot()
	{
		return null;
	}

	public void clearPage(String name) throws Exception
	{
	}

	public int compareTo(Object o)
	{
		return 0;
	}

	public PageData getData(String versionName) throws Exception
	{
		return null;
	}

	public void dumpExpiredCachedData() throws Exception
	{
	}

	public List getCachedChildren() throws Exception
	{
		return new ArrayList();
	}

	public void resetVirtualCoupling() throws Exception
	{
	}

	public void removePage(String name) throws Exception
	{
	}

	public boolean renamePage(String pageName, String newName) throws Exception
	{
		return false;
	}

	public void commitWithoutVersion(PageData data) throws Exception
	{
	}

	public WikiPage addChildPage(String name) throws Exception
	{
		return null;
	}

	public boolean hasChildPage(String name) throws Exception
	{
		return false;
	}

	public WikiPage getChildPage(String name) throws Exception
	{
		return null;
	}

	public WikiPage getVirtualCoupling() throws Exception
	{
		return null;
	}
}