// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

public class NoSuchVersionException extends Exception
{
	public NoSuchVersionException(String message)
	{
		super(message);
	}
}
