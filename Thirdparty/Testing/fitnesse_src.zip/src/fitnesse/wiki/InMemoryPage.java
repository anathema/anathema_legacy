// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wiki;

import java.util.*;

public class InMemoryPage extends RawPage
{
	private static final String currentVersion = "current_version";

	private Map versions = new HashMap();
	private Map actualChildren = new HashMap();

	private InMemoryPage(String name, String content, WikiPage parent) throws Exception
	{
		super(name, parent);
		versions.put(currentVersion, new PageData(this, content));
	}

	public WikiPage addChildPage(String name) throws Exception
	{
		RawPage page = createChildPage(name);
		children.put(name, page);
		actualChildren.put(name,page);
		return page;
	}

	public static WikiPage makeRoot(String name) throws Exception
	{
		InMemoryPage root = new InMemoryPage(name, "", null);
		return root;
	}

	protected RawPage createChildPage(String name) throws Exception
	{
		RawPage newPage = new InMemoryPage(name, "", this);
		actualChildren.put(newPage.getName(), newPage);
		return newPage;
	}

	public void removePage(String name) throws Exception
	{
		super.removePage(name);
		actualChildren.remove(name);
	}

	public boolean renamePage(String pageName, String newName) throws Exception
	{
		if(!super.renamePage(pageName, newName))
			return false;

		Object o = actualChildren.get(pageName);
		actualChildren.put(newName, o);
		actualChildren.remove(pageName);
		return true;
	}

	public boolean hasChildPage(String pageName)
	{
		return actualChildren.containsKey(pageName);
	}

	public void loadChildren()
	{
		children.putAll(actualChildren);
	}

	protected String makeVersion() throws Exception
	{
		Date date = new Date();
		String name = versionNameFormat.format(date);
		PageData current = getData(currentVersion);
		versions.put(name, current);
		return name;
	}

	protected void removeVersion(String versionName) throws Exception
	{
		versions.remove(versionName);
	}

	public void doCommit(PageData newData) throws Exception
	{
		Date date = getVersionDate();
		newData.setLastModificationTime(date);
		versions.put(currentVersion, newData);
	}

	protected PageData makePageData() throws Exception
	{
		return getData(currentVersion);
	}

	public PageData getData(String versionName) throws Exception
	{
		PageData version = (PageData) versions.get(versionName);
		checkVersionIsValid(version, versionName);

		Set names = new HashSet(versions.keySet());
		names.remove(currentVersion);
		version.addVersionNames(names);
		return new PageData(version);
	}

	public int numberOfVersions()
	{
		return versions.size() - 1;
	}

	public void setVirtualCoupling(VirtualCouplingPage coupling) throws Exception
	{
		virtualCoupling = coupling;
	}
}