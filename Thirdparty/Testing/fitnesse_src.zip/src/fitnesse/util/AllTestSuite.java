// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.util;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("fitnesse.util.AllTestSuite");
		suite.addTest(new TestSuite(WildcardTest.class));

		return suite;
	}
}
