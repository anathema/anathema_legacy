// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import junit.swingui.TestRunner;

import fitnesse.wiki.*;
import fitnesse.testutil.*;
import fitnesse.http.HttpResponseParser;
import java.net.URL;
import java.io.*;

public class TestRunnerTest extends RegexTest
{
	private fitnesse.TestRunner runner;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"TestRunnerTest"});
	}

	public void setUp() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		root.addPage("ClassPath", "!path classes");
		root.addPage("FrontPage", "front page");
		FitnesseUtil.startFitnesse(root);

		runner = new fitnesse.TestRunner();
	}

	public void tearDown() throws Exception
	{
		FitnesseUtil.stopFitnesse();
		System.setOut(System.out);
	}

	public void testParseArgs() throws Exception
	{
		String[] args = new String[]{};
		assertFalse(runner.acceptAgrs(args));

		args = new String[]{"blah", "http://localhost/FrontPage"};
		assertFalse(runner.acceptAgrs(args));

		args = new String[]{"http://localhost/FrontPage"};
		assertTrue(runner.acceptAgrs(args));
		assertFalse(runner.verbose);
		assertFalse(runner.showHtml);

		args = new String[]{"-v", "-h", "http://localhost/FrontPage"};
		assertTrue(runner.acceptAgrs(args));
		assertTrue(runner.verbose);
		assertTrue(runner.showHtml);
	}

	public void testEvaluateUrl() throws Exception
	{
		HttpResponseParser response = runner.getResponse(new URL("http://localhost:" + FitnesseUtil.port  + "/FrontPage?responder=start&className=fitnesse.testutil.Echo"));
		int code = runner.getExitCode(response);
		assertEquals(0, code);

		response = runner.getResponse(new URL("http://localhost:" + FitnesseUtil.port  + "/FrontPage?responder=start&className=fitnesse.testutil.BadExit"));
		code = runner.getExitCode(response);
		assertEquals(-1, code);
	}

	public void testShowHtmlOption() throws Exception
	{
		ByteArrayOutputStream outputByteStream = new ByteArrayOutputStream();
		PrintStream outputPrintStream = new PrintStream(outputByteStream);
		System.setOut(outputPrintStream);
		runner.run(new String[]{"http://localhost:" + FitnesseUtil.port  + "/FrontPage?responder=start&className=fitnesse.testutil.Hello"});
		assertEquals("", outputByteStream.toString());

		runner.run(new String[]{"-h", "http://localhost:" + FitnesseUtil.port  + "/FrontPage?responder=start&className=fitnesse.testutil.Hello"});
		assertHasRegexp(Hello.message, outputByteStream.toString());
	}
}
