// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

public class UploadedFile
{
	private String name;
	private String type;
	private byte[] contents;

	public UploadedFile(String name, String type, byte[] contents)
	{
		this.name = name;
		this.type = type;
		this.contents = contents;
	}

	public String getName()
	{
		return name;
	}

	public String getType()
	{
		return type;
	}

	public byte[] getContents()
	{
		return contents;
	}

	public String toString()
	{
		return "name : " + getName() + "; type : " + getType() + "; content : " + getContents();
	}

	public boolean isUsable()
	{
		return (name != null && name.length() > 0);
	}
}
