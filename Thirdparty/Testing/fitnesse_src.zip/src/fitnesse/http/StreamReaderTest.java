// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import junit.swingui.TestRunner;
import java.io.*;
import fitnesse.testutil.RegexTest;

public class StreamReaderTest extends RegexTest
{
	private PipedOutputStream output;
	private StreamReader reader;
	private String readResult;
	private Thread thread;
	private Exception exception;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"StreamReaderTest"});
	}

	public void setUp() throws Exception
	{
		output = new PipedOutputStream();
		reader = new StreamReader(new PipedInputStream(output));
	}

	public void tearDown() throws Exception
	{
		output.close();
		reader.close();
	}

	private void writeToPipe(String value) throws Exception
	{
		byte[] bytes = value.getBytes();
		output.write(bytes);
	}

	public void testReadLine() throws Exception
	{
		startReading(new ReadLine());
		writeToPipe("a line\r\n");
		finishReading();
		assertEquals("a line", readResult);
	}

	public void testBufferCanGrow() throws Exception
	{
		startReading(new ReadLine());
		for(int i = 0; i < 1001; i++)
			writeToPipe(i + ",");
		writeToPipe("\r\n");

		finishReading();
		assertHasRegexp("1000", readResult);
	}

	public void testReadNumberOfBytes() throws Exception
	{
		startReading(new ReadCount(100));
		StringBuffer buffer = new StringBuffer();
		for(int i = 0; i < 100; i++)
		{
			buffer.append("*");
			writeToPipe("*");
		}
		finishReading();

		assertEquals(buffer.toString(), readResult);
	}

	public void testReadingZeroBytes() throws Exception
	{
		startReading(new ReadCount(0));
		finishReading();
		assertEquals("", readResult);
	}

	public void testReadUpTo() throws Exception
	{
		startReading(new ReadUpTo("--boundary"));
		writeToPipe("some bytes--boundary");
		finishReading();

		assertEquals("some bytes", readResult);
	}

	public void testReadUpTo2() throws Exception
	{
		startReading(new ReadUpTo("--bob"));
		writeToPipe("----bob\r\n");
		finishReading();

		assertEquals("--", readResult);
	}

	public void testBufferEndsWithBoundary() throws Exception
	{
		byte[] bytes = "123abc456def".getBytes();
		assertTrue(StreamReader.bytesEndWith(12, bytes, "def"));
		assertFalse(StreamReader.bytesEndWith(12, bytes, "6de"));
		assertTrue(StreamReader.bytesEndWith(9, bytes, "456"));
		assertTrue(StreamReader.bytesEndWith(6, bytes, "abc"));
		assertTrue(StreamReader.bytesEndWith(3, bytes, "123"));
		assertFalse(StreamReader.bytesEndWith(0, bytes, "123"));
	}

	public void testEarlyClosingStream() throws Exception
	{
		startReading(new ReadCount(10));
		output.close();
		finishReading();
		assertEquals("", readResult);
	}

	private void startReading(ReadThread thread)
	{
		this.thread = thread;
		this.thread.start();
	}

	private void finishReading() throws Exception
	{
		thread.join();
	}

	abstract class ReadThread extends Thread
	{
		public void run()
		{
			try
			{
				doRead();
			}
			catch(Exception e)
			{
			 exception = e;
			}
		}

		public abstract void doRead() throws Exception;
	};

	class ReadLine extends ReadThread
	{
		public void doRead() throws Exception
		{
			readResult = reader.readLine();
		}
	}

	class ReadCount extends ReadThread
	{
		private int amount;

		public ReadCount(int amount)
		{
			this.amount = amount;
		}

		public void doRead() throws Exception
		{
			readResult = reader.read(amount);
		}
	}

	class ReadUpTo extends ReadThread
	{
		private String boundary;

		public ReadUpTo(String b)
		{
			boundary = b;
		}

		public void doRead() throws Exception
		{
			readResult = reader.readUpTo(boundary);
		}
	}
}
