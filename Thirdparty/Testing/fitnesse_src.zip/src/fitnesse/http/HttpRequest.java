// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.net.URLDecoder;

public class HttpRequest
{
	private static final Pattern requestLinePattern = Pattern.compile("(\\p{Upper}+?) ([^\\s]+)");
	private static final Pattern requestUriPattern = Pattern.compile("([^?]+)\\??(.*)");
	private static final Pattern queryStringPattern = Pattern.compile("([^=]*)=?([^&]*)&?");
	private static final Pattern headerPattern = Pattern.compile("([^:]*): (.*)");
	private static final Pattern boundaryPattern = Pattern.compile("boundary=(.*)");
	private static final Pattern multipartHeaderPattern = Pattern.compile("([^ =]+)=\\\"([^\"]*)\\\"");

	private static Collection allowedMethods = buildAllowedMethodList();

	private boolean hasBeenParsed;
	private StreamReader input;
	protected String requestURI;
	protected String resource;
	protected String queryString;
	protected HashMap inputs = new HashMap();
	protected HashMap headers = new HashMap();
	protected String entityBody = "";
	protected String requestLine;

	public static HttpRequest makeAndParse(InputStream input) throws Exception
	{
		HttpRequest request = new HttpRequest(input);
		request.parse();
		return request;
	}

	public static Set buildAllowedMethodList()
	{
		Set methods = new HashSet(20);
		methods.add("GET");
		methods.add("POST");
		return methods;
	}

	protected HttpRequest()
	{
	}

	public HttpRequest(InputStream input) throws Exception
	{
		this.input = new StreamReader(input);
	}

	public void parse() throws Exception
	{
		parseRequestLine();
		headers = parseHeaders(input);
		parseEntityBody();
		hasBeenParsed = true;
	}

	private void parseRequestLine() throws Exception
	{
		requestLine = input.readLine();
		Matcher match = requestLinePattern.matcher(requestLine);
		checkRequestLine(match);
		requestURI = match.group(2);
		parseRequestUri(requestURI);
	}

	private HashMap parseHeaders(StreamReader reader) throws Exception
	{
		HashMap headers = new HashMap();
		String line = reader.readLine();
		while(!"".equals(line))
		{
			Matcher match = headerPattern.matcher(line);
			if(match.find())
			{
				String key = match.group(1);
				String value = match.group(2);
				headers.put(key.toLowerCase(), value);
			}
			line = reader.readLine();
		}
		return headers;
	}

	private void parseEntityBody() throws Exception
	{
		String lengthHeader = "Content-Length";
		String typeHeader = "Content-Type";
		if(hasHeader(lengthHeader))
		{
			int bytesToRead = Integer.parseInt((String) getHeader(lengthHeader));
			entityBody = input.read(bytesToRead);

			String contentType = (String) getHeader(typeHeader);
			if(contentType != null && contentType.startsWith("multipart/form-data"))
			{
				Matcher match = boundaryPattern.matcher(contentType);
				match.find();
				parseMultiPartContent(match.group(1), input.getBufferedBytes());
			}
			else
			{
				parseQueryString(entityBody);
			}
		}
	}

	private void parseMultiPartContent(String boundary, byte[] bytes) throws Exception
	{
		boundary = "--" + boundary;
		ByteArrayInputStream byteStream = new ByteArrayInputStream(bytes);
		StreamReader reader = new StreamReader(byteStream);

		reader.readUpTo(boundary);
		while(true)
		{
			String line = reader.readLine();
			if(!"".equals(line))
				break;
			HashMap headers = parseHeaders(reader);
			String contentDisposition = (String) headers.get("content-disposition");
			Matcher matcher = multipartHeaderPattern.matcher(contentDisposition);
			while(matcher.find())
				headers.put(matcher.group(1), matcher.group(2));

			String value = reader.readUpTo("\r\n" + boundary);
			String name = (String) headers.get("name");
			if(headers.containsKey("filename"))
			{
				String filename = (String) headers.get("filename");
				String contentType = (String) headers.get("content-type");
				inputs.put(name, new UploadedFile(filename, contentType, reader.getBufferedBytes()));
			}
			else
				inputs.put(name, value);
		}
	}

	private void checkRequestLine(Matcher match) throws HttpException
	{
		if(!match.find())
			throw new HttpException("The request string is malformed and can not be parsed");
		if(!allowedMethods.contains(match.group(1)))
			throw new HttpException("The " + match.group(1) + " method is not currently supported");
	}

	private void parseRequestUri(String requestUri)
	{
		Matcher match = requestUriPattern.matcher(requestUri);
		match.find();
		resource = stripLeadingSlash(match.group(1));
		queryString = match.group(2);
		parseQueryString(queryString);
	}

	protected void parseQueryString(String queryString)
	{
		Matcher match = queryStringPattern.matcher(queryString);
		while(match.find())
		{
			String key = match.group(1);
			String value = match.group(2);
			inputs.put(key, value);
		}
	}

	public String getRequestLine()
	{
		return requestLine;
	}

	public String getRequestUri()
	{
		return requestURI;
	}

	public String getResource()
	{
		return resource;
	}

	public String getQueryString()
	{
		return queryString;
	}

	public boolean hasInput(String key)
	{
		return inputs.containsKey(key);
	}

	public Object getInput(String key)
	{
		return inputs.get(key);
	}

	public boolean hasHeader(String key)
	{
		return headers.containsKey(key.toLowerCase());
	}

	public Object getHeader(String key)
	{
		return headers.get(key.toLowerCase());
	}

	public String getBody()
	{
		return entityBody;
	}

	private String stripLeadingSlash(String url)
	{
		return url.substring(1);
	}

	public String toString()
	{
		StringBuffer buffer = new StringBuffer();
		buffer.append("HttpRequest").append("\n");
		buffer.append("Request URI:  ").append(requestURI).append("\n");
		buffer.append("Resource:     ").append(resource).append("\n");
		buffer.append("Query String: ").append(queryString).append("\n");
		buffer.append("Hearders: (" + headers.size() + ")\n");
		addMap(headers, buffer);
		buffer.append("Form Inputs: (" + inputs.size() + ")\n");
		addMap(inputs, buffer);
		buffer.append("Entity Body: ").append("\n");
		buffer.append(entityBody);
		buffer.append("End HttpRequest.\n");

		return buffer.toString();
	}

	private void addMap(HashMap map, StringBuffer buffer)
	{
		if(map.size() == 0)
		{
			buffer.append("\tempty");
		}
		for(Iterator iterator = map.keySet().iterator(); iterator.hasNext();)
		{
			String key = (String) iterator.next();
			String value = map.get(key) != null ? escape(map.get(key).toString()) : null;
			buffer.append("\t[[" + escape(key) + "]] --> [[" + value + "]]\n");
		}
	}

	private String escape(String foo)
	{
		return foo.replaceAll("[\n\r]+", "|");
	}

	public static String decodeContent(String content)
	{
		String escapedContent = null;
		try
		{
			escapedContent = URLDecoder.decode(content, "ISO-8859-1");
		}
		catch(UnsupportedEncodingException e)
		{
			escapedContent = "URLDecoder Error";
		}
		return escapedContent;
	}

	public boolean hasBeenParsed()
	{
		return hasBeenParsed;
	}
}
