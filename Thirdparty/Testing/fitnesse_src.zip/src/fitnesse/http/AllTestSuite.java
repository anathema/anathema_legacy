// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(HttpRequestTest.class));
		suite.addTest(new TestSuite(SimpleResponseTest.class));
		suite.addTest(new TestSuite(HttpRequestBuilderTest.class));
		suite.addTest(new TestSuite(HttpResponseParserTest.class));
		suite.addTest(new TestSuite(StreamReaderTest.class));
		suite.addTest(new TestSuite(ChunkedResponseTest.class));

		return suite;
	}
}
