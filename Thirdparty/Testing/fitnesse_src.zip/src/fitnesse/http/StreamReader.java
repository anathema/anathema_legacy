// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import java.io.*;

public class StreamReader
{
	private InputStream input;
	private State state;
	private byte[] bufferedBytes;
	private int bufferIndex;
	private int readAmount;
	private String boundary;

	public StreamReader(InputStream input)
	{
		this.input = input;
	}

	public void close() throws Exception
	{
		input.close();
	}

	public String readLine() throws Exception
	{
		state = READLINE_STATE;
		return doReading();
	}

	public String read(int count) throws Exception
	{
		readAmount = count;
		state = READCOUNT_STATE;
		return doReading();
	}

	public String readUpTo(String boundary) throws Exception
	{
		this.boundary = boundary;
		state = READUPTO_STATE;
		return doReading();
	}

	public byte[] getBufferedBytes()
	{
		byte[] bytes = new byte[bufferIndex];
		for(int i = 0; i < bytes.length; i++)
			bytes[i] = bufferedBytes[i];

		return bytes;
	}

	private String doReading() throws Exception
	{
		clearBuffer();
		while(!state.finished())
			state.read(input);

		return bufferToString();
	}

	private void clearBuffer()
	{
		bufferedBytes = new byte[1000];
		bufferIndex = 0;
	}

	private void bufferByte(byte b)
	{
		checkForReallocations();
		bufferedBytes[bufferIndex++] = b;
	}

	private String bufferToString()
	{
		return new String(bufferedBytes, 0, bufferIndex);
	}

	private void checkForReallocations()
	{
		if(bufferIndex == bufferedBytes.length)
		{
			byte[] newBuffer = new byte[bufferIndex * 2];
			for(int i = 0; i < bufferedBytes.length; i++)
				newBuffer[i] = bufferedBytes[i];
			bufferedBytes = newBuffer;
		}
	}

	private void changeState(State state)
	{
		this.state = state;
	}

	public static boolean bytesEndWith(int index, byte[] bytes, String boundary)
	{
		int boundaryLength = boundary.length();
		if(index >= boundaryLength)
		{
			String subString = new String(bytes, index - boundaryLength, boundaryLength);
			return boundary.equals(subString);
		}
		else
			return false;
	}

	private static abstract class State
	{
		public void read(InputStream input) throws Exception
		{
		}

		public boolean finished()
		{
			return false;
		}
	}

	private final State READLINE_STATE = new State()
	{
		public void read(InputStream input) throws Exception
		{
			int b = input.read();
			if(b == '\n')
				changeState(FINAL_STATE);
			else if(b == -1)
			{
				changeState(FINAL_STATE);
			}
			else if(b != '\r')
				bufferByte((byte) b);
		}
	};

	private final State READCOUNT_STATE = new State()
	{
		public void read(InputStream input) throws Exception
		{
			byte[] bytes = new byte[readAmount - bufferIndex];
			int bytesRead = input.read(bytes);

			if(bytesRead < 0)
				changeState(FINAL_STATE);
			else
			{
				for(int i = 0; i < bytesRead; i++)
					bufferByte(bytes[i]);
			}
		}

		public boolean finished()
		{
			return bufferIndex >= readAmount;
		}
	};

	private final State READUPTO_STATE = new State()
	{
		public void read(InputStream input) throws Exception
		{
			int b = input.read();
			if(b == -1)
				changeState(FINAL_STATE);
			else
				bufferByte((byte) b);

			if(bytesEndWith(bufferIndex, bufferedBytes, boundary))
			{
				bufferIndex -= boundary.length();
				changeState(FINAL_STATE);
			}
		}
	};

	private final State FINAL_STATE = new State()
	{
		public boolean finished()
		{
			return true;
		}
	};
}
