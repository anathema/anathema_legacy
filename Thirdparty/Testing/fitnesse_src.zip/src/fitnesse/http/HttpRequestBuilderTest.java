// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import junit.swingui.TestRunner;
import fitnesse.testutil.RegexTest;

public class HttpRequestBuilderTest extends RegexTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"HttpRequestBuilder"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testDeafultValues() throws Exception
	{
		HttpRequestBuilder builder = new HttpRequestBuilder("/someResource");
		String text = builder.getText();
		assertHasRegexp("GET /someResource HTTP/1.1\r\n", text);
	}

	public void testChangingMethod() throws Exception
	{
		HttpRequestBuilder builder = new HttpRequestBuilder("/");
		builder.setMethod("POST");
		String text = builder.getText();
		assertHasRegexp("POST / HTTP/1.1\r\n", text);
	}

	public void testSettingMessageBody() throws Exception
	{
		HttpRequestBuilder builder = new HttpRequestBuilder("/");
		builder.setMessageBody("abc");
		String text = builder.getText();
		assertHasRegexp("Content-Length: 3\r\n", text);
		assertHasRegexp("\r\nabc", text);
	}
}
