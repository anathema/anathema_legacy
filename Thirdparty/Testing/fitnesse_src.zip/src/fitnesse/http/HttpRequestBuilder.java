// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.http;

import java.util.*;

public class HttpRequestBuilder
{
	private String resource;
	private String method = "GET";
	private String body = "";
	private HashMap headers = new HashMap();

	public HttpRequestBuilder(String resource)
	{
		this.resource = resource;
	}

	public void setMethod(String method)
	{
		this.method = method;
	}

	public void setMessageBody(String body)
	{
		this.body = body;
		addHeader("Content-Length", body.length() + "");
	}

	public void addHeader(String key, String value)
	{
		headers.put(key, value);
	}

	public String getText()
	{
		StringBuffer text = new StringBuffer();
		text.append(method).append(" ").append(resource).append(" HTTP/1.1").append("\r\n");
		for(Iterator iterator = headers.keySet().iterator(); iterator.hasNext();)
		{
			String key = (String) iterator.next();
			text.append(key).append(": ").append(headers.get(key)).append("\r\n");
		}
		text.append("\r\n");
		text.append(body);

		return text.toString();
	}
}
