// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.ColumnFixture;
import fitnesse.wiki.WikiPage;

public class PageCreator extends ColumnFixture
{
	public String pageName;
	public String pageContents;
	public String pageAttributes = "Not implemented";

	public boolean valid() throws Exception
	{
		WikiPage root = FitnesseFixtureContext.root;
		root.addPage(pageName, pageContents);
		return true;
	}
}

