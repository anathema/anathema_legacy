// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

public class RowEntryExample extends RowEntryFixture
{
	public int v;
	public void enterRow() throws Exception
	{
		if (v == 0)
			throw new Exception("Oh, no!  Zero!");
	}
}
