// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import junit.swingui.TestRunner;
import fit.*;
import fitnesse.testutil.*;

import java.util.List;
import java.io.*;

public class RecursiveAllFilesTest extends RegexTest
{
	private static final String PATH = "./testdir";
	private static final String sampleHtml = "<table><tr><td></td></tr><tr><td>" + PATH + "</td><td>testSuite</td></tr></table>";

	private RecursiveAllFiles fixture;
	private String onePath;
	private String twoPath;
	private String fourPath;
	private String sixPath;
	private Parse parse;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RecursiveAllFiles"});
	}

	public void setUp() throws Exception
	{
		FileUtil.makeDir(PATH);
		FileUtil.makeDir(PATH + "/testSuite");
		onePath = PATH + "/testSuite/one.html";
		FileUtil.createFile(onePath, makeSimpleTable("PassFixture"));
		twoPath = PATH + "/testSuite/two.html";
		FileUtil.createFile(twoPath, makeSimpleTable("FailFixture"));
		FileUtil.makeDir(PATH + "/testSuite/three");
		fourPath = PATH + "/testSuite/three/four.html";
		FileUtil.createFile(fourPath, makeSimpleTable("ErrorFixture"));
		FileUtil.makeDir(PATH + "/testSuite/five");
		sixPath = PATH + "/testSuite/five/six.html";
		FileUtil.createFile(sixPath, makeSimpleTable("NotFoundFixture"));

		parse = new Parse(sampleHtml);
		fixture = new RecursiveAllFiles();
		fixture.doTable(parse);
	}

	private String makeSimpleTable(String ClassName)
	{
		return "<table><tr><td>fitnesse.testutil." + ClassName + "</td></tr></table>";
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory(PATH);
	}

	public void testCreations() throws Exception
	{
		assertEquals(PATH, fixture.directory);
	}

	public void testCanFindFiles() throws Exception
	{
		List filenames = fixture.getFilenames();
		assertEquals(4, filenames.size());
		assertEquals("testSuite/five/six.html", filenames.get(0));
		assertEquals("testSuite/one.html", filenames.get(1));
		assertEquals("testSuite/three/four.html", filenames.get(2));
		assertEquals("testSuite/two.html", filenames.get(3));
	}

	public void testResultFileContents() throws Exception
	{
		String one = FileUtil.getFileContent(onePath);
		String two = FileUtil.getFileContent(twoPath);
		String four = FileUtil.getFileContent(fourPath);
		String six = FileUtil.getFileContent(sixPath);

		assertHasRegexp("#cfffcf", one);
		assertHasRegexp("#ffcfcf", two);
		assertHasRegexp("#ffffcf", four);
		assertHasRegexp("ClassNotFoundException", six);
	}

	public void testResultsHtml() throws Exception
	{
		StringWriter sWriter = new StringWriter();
		PrintWriter writer = new PrintWriter(sWriter);
		parse.print(writer);

		String results = sWriter.toString();

		assertDoesntHaveRegexp("<td>./testdir</td>", results);
		assertDoesntHaveRegexp("\\[!\\]", results);  // Ward's old footnote notation.
		assertHasRegexp("<a href=\"/files/testResults/testSuite/one.html\">one</a>", results);
		assertHasRegexp("two", results);
		assertHasRegexp("four", results);
		assertHasRegexp("six", results);
	}
}
