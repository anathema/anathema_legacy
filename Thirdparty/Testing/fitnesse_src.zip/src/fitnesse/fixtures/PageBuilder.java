// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.Fixture;

import java.io.PrintWriter;
import java.io.StringWriter;

public class PageBuilder extends Fixture
{
	private PrintWriter writer;
	private StringWriter stringWriter;

	public PageBuilder()
	{
		stringWriter = new StringWriter();
		writer = new PrintWriter(stringWriter);
	}

	public void line(String line)
	{
		writer.println(line);
	}

	public void page(String name) throws Exception
	{
		String content = stringWriter.toString();
		FitnesseFixtureContext.root.addPage(name, content);
	}
}
