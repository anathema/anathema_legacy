// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import java.io.PrintWriter;
import java.io.StringWriter;

import fit.*;

public abstract class RowEntryFixture extends ColumnFixture
{
	public abstract void enterRow() throws Exception;
	public final static String ERROR_INDICATOR = "Unable to enter last row: ";
	public static final String RIGHT_COLOR =  "#cfffcf";
	public static final String WRONG_COLOR =  "#ffcfcf";
	
	public void doRow(Parse row) {
		if (row.parts.body.indexOf(ERROR_INDICATOR) != -1)
			return;
		super.doRow(row);
		try {
			enterRow();
			markRow(row, "entered", RIGHT_COLOR);
		} catch (Exception e) {
			markRow(row, "skipped", WRONG_COLOR);
			reportError(row, e);
		}
	}
	
	void markRow(Parse row, String text, String color) {
		appendCell(row, text);
		row.parts.last().addToTag(" bgcolor=\"" + color + "\"");
	}
		
	void appendCell(Parse row, String text) {
		row.parts.last().more = new Parse("td", text, null, null);
	}
	
	public void reportError(Parse row, Exception e) {
		Parse errorCell = makeMessageCell(e);		
		insertRowAfter(row, new Parse("tr", null, errorCell, null));			
	}

	public Parse makeMessageCell(Exception e) {
		Parse errorCell = new Parse("td", "", null, null);
		final StringWriter buffer = new StringWriter();
		
		e.printStackTrace(new PrintWriter(buffer));
		errorCell.addToTag(" colspan=\"" + (columnBindings.length + 1) + "\"");
		errorCell.addToBody("<i>" + ERROR_INDICATOR + e.getMessage() + "</i>");
		errorCell.addToBody("<font size=-2><pre>" + (buffer.toString()) + "</pre></font>");
		wrong(errorCell);
		
		return errorCell;
	}
	
	public void insertRowAfter(Parse currentRow, Parse rowToAdd) {
		Parse nextRow = currentRow.more;
		currentRow.more = rowToAdd;
		rowToAdd.more = nextRow;		
	}
		
}
