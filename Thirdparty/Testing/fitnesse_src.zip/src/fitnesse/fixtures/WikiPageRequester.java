// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.ColumnFixture;
import fitnesse.http.*;
import fitnesse.responders.WikiPageResponder;
import fitnesse.wiki.*;
import fitnesse.FitNesseContext;

public class WikiPageRequester extends ColumnFixture
{
	public String pageName;

	public boolean valid() throws Exception
	{
		MockHttpRequest request = new MockHttpRequest();
		request.setResource(pageName);
		FitnesseFixtureContext.page = new PageCrawler().getPage(FitnesseFixtureContext.root, pageName);
		WikiPageResponder responder = new WikiPageResponder(FitnesseFixtureContext.root);
		FitnesseFixtureContext.response = responder.makeResponse(new FitNesseContext(FitnesseFixtureContext.root), request);
		FitnesseFixtureContext.sender = new MockResponseSender(FitnesseFixtureContext.response);
		return true;
	}

	public String contents() throws Exception
	{
		WikiPage page = new PageCrawler().getPage(FitnesseFixtureContext.root, pageName);
		return "<pre>" + page.getData().getContent() + "</pre>";
	}
}
