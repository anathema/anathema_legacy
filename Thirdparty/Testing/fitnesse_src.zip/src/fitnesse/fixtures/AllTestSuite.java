// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All fixture tests");
		suite.addTest(new TestSuite(RecursiveAllFilesTest.class));
    suite.addTest(new TestSuite(RowEntryFixtureTest.class));
		return suite;
	}
}
