// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.ColumnFixture;

import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.util.StringTokenizer;

public class ResponseExaminer extends ColumnFixture
{
	public String type;
	public String pattern;
	public String value;
	public int number;
	private Matcher matcher;

	public String contents()
	{
		return FitnesseFixtureContext.sender.sentData();
	}

	public boolean matches()
	{
		Pattern p = Pattern.compile(pattern, Pattern.MULTILINE + Pattern.DOTALL);
		value = null;
		if(type.equals("contents"))
			value = contents();
		else if(type.equals("status"))
			value = "" + FitnesseFixtureContext.response.getStatus();
		else if(type.equals("headers"))
		{
			String text = FitnesseFixtureContext.sender.sentData();
			int headerEnd = text.indexOf("\r\n\r\n");
			value = text.substring(0, headerEnd + 2);
		}

		matcher = p.matcher(value);
		return matcher.find();
	}

	public String string() throws Exception
	{
		String value = null;
		if(type.equals("content"))
		{
			return FitnesseFixtureContext.page.getData().getHtml();
		}
		else if(type.equals("line"))
		{
			String pageContent = FitnesseFixtureContext.page.getData().getHtml();
			String lineizedContent = pageContent.replaceAll("<br>", System.getProperty("line.separator"));
			StringTokenizer t = new StringTokenizer(lineizedContent, System.getProperty("line.separator"));
			for(int i = number; i != 0; i--)
				value = t.nextToken();
			return value;
		}
		else
		{
			throw new Exception("Bad type in ResponseExaminer");
		}
	}

	public String found()
	{
		return matcher.group(0);
	}

	public String source()
	{
		return value;
	}
}
