// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.Fixture;
import java.io.File;

public class FileSystemPageTearDown extends Fixture
{
	public FileSystemPageTearDown() throws Exception
	{
		fitnesse.testutil.FileUtil.deleteFileSystemDirectory(new File(FitnesseFixtureContext.baseDir));
		FitnesseFixtureContext.root = null;

	}
}
