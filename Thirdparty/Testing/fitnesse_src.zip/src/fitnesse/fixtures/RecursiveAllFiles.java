// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.*;

import java.util.*;
import java.io.*;

public class RecursiveAllFiles extends Fixture
{
	public String directory;
	private ArrayList filenames = new ArrayList();
	private Parse startingRow;
	private String page;

	public void doTable(Parse table)
	{
		startingRow = table.parts;
		Parse row = startingRow.more;
		startingRow.more = null;
		doRow(row);
	}

	public void doRow(Parse row)
	{
		directory = row.parts.text();
		page = row.parts.more.text();
		addFilenamesFrom("");
		Collections.sort(filenames);
		doFiles();
	}

	public class ErrorHandlingFixture extends Fixture
	{
		public void doTables(Parse tables)
		{
			summary.put("start date", new Date());
			summary.put("start elapsed time", new RunTime());
			while(tables != null)
			{
				Parse heading = tables.at(0, 0, 0);
				if(heading != null)
				{
					try
					{
						Fixture fixture = (Fixture) (Class.forName(heading.text()).newInstance());
						fixture.counts = counts;
						fixture.summary = summary;
						fixture.doTable(tables);
					}
					catch(Throwable e)
					{
						exception(heading, e);
					}
				}
				tables = tables.more;
			}
		}
	}

	private void addFilenamesFrom(String dirPath)
	{
		File dir = new File(directory + "/" + dirPath);
		String[] children = dir.list();
		for(int i = 0; i < children.length; i++)
		{
			String filename;
			if("".equals(dirPath))
				filename = children[i];
			else
				filename = dirPath + "/" + children[i];
			File f = new File(directory + "/" + filename);
			if(f.isDirectory())
				addFilenamesFrom(filename);
			else
				filenames.add(filename);
		}
	}

	public List getFilenames()
	{
		return filenames;
	}

	protected void doFiles()
	{
		Parse row = startingRow;
		for(Iterator i = filenames.iterator(); i.hasNext();)
		{
			String filename = (String) i.next();
			File path = new File(directory + "/" + filename);
			Parse cells = td(makeLinkTo(filename), td("", null));
			row = (row.more = tr(cells, row.more));
			Fixture fixture = new ErrorHandlingFixture();
			run(path, fixture, cells);
			summarize(fixture);
		}
	}

	private String makeLinkTo(String filename)
	{
		StringBuffer link = new StringBuffer();
		link.append("<a href=\"/files/testResults/").append(filename).append("\">");
		link.append(makeRelativePageName(filename)).append("</a>");

		return link.toString();
	}

	private String makeRelativePageName(String filename)
	{
		String dottedFileName = filename.replace('/', '.');
		String linkName = dottedFileName;
		if(dottedFileName.startsWith(page))
			linkName = dottedFileName.substring(page.length() + 1);

		if(linkName.endsWith(".html"))
			linkName = linkName.substring(0, linkName.length() - 5);
		return linkName;
	}

	protected void run(File path, Fixture fixture, Parse cells)
	{
		try
		{
			String input = read(path);
			Parse tables = new Parse(input);
			fixture.doTables(tables);

			cells.more.addToBody(gray(fixture.counts.toString()));
			if(fixture.counts.wrong == 0 && fixture.counts.exceptions == 0)
				right(cells.more);
			else
				wrong(cells.more);

			PrintWriter writer = new PrintWriter(new FileOutputStream(path));
			tables.print(writer);
			writer.flush();
			writer.close();
		}
		catch(Exception e)
		{
			exception(cells, e);
		}
	}

	protected String read(File input) throws IOException
	{
		char chars[] = new char[(int) (input.length())];
		FileReader in = new FileReader(input);
		in.read(chars);
		in.close();
		return new String(chars);
	}

	private void summarize(Fixture fixture)
	{
		String totalString = "total counts";
		Counts runCounts = summary.containsKey(totalString)
		  ? (Counts) summary.get(totalString)
		  : new Counts();
		runCounts.tally(fixture.counts);
		summary.put(totalString, runCounts);
	}

	Parse tr(Parse cells, Parse more)
	{
		return new Parse("tr", null, cells, more);
	}

	Parse td(String text, Parse more)
	{
		return new Parse("td", gray(text), null, more);
	}
}
