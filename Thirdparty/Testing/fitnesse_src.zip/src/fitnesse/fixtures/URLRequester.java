// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.fixtures;

import fit.ColumnFixture;
import fitnesse.http.*;
import fitnesse.*;

import java.io.*;

public class URLRequester extends ColumnFixture
{
	public String url;

	public boolean valid() throws Exception
	{
		String requestText = "GET /" + url + " HTTP/1.1\r\n\r\n";
		ByteArrayInputStream is = new ByteArrayInputStream(requestText.getBytes());
		HttpRequest request = new HttpRequest(is);
		request.parse();
		Responder responder = FitnesseFixtureContext.responderFactory.makeResponder(request, FitnesseFixtureContext.root);
		FitnesseFixtureContext.response = responder.makeResponse(new FitNesseContext(FitnesseFixtureContext.root), request);
		FitnesseFixtureContext.sender = new MockResponseSender(FitnesseFixtureContext.response);
		return true;
	}
}