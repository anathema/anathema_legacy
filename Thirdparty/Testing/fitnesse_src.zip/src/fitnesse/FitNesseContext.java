// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import fitnesse.wiki.WikiPage;
import fitnesse.responders.ResponderFactory;
import fitnesse.responders.run.SocketDealer;
import fitnesse.components.Logger;
import fitnesse.schedule.*;

public class FitNesseContext
{
	public int port = 80;
	public String rootPath = "";
	public WikiPage root;
	public ResponderFactory responderFactory;
	public Logger logger;
	public Schedule schedule = new NullSchedule();
	public SocketDealer socketDealer = new SocketDealer();

	public FitNesseContext()
	{
	}

	public FitNesseContext(WikiPage root)
	{
		this.root = root;
	}
}
