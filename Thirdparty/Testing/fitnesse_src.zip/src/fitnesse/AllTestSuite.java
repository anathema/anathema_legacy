// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");

		suite.addTest(fitnesse.wikitext.AllTestSuite.suite());
		suite.addTest(fitnesse.wiki.AllTestSuite.suite());
		suite.addTest(fitnesse.http.AllTestSuite.suite());
		suite.addTest(fitnesse.responders.AllTestSuite.suite());
		suite.addTest(fitnesse.components.AllTestSuite.suite());
		suite.addTest(fitnesse.socketservice.AllTestSuite.suite());
		suite.addTest(fitnesse.fixtures.AllTestSuite.suite());
		suite.addTest(fitnesse.updates.AllTestSuite.suite());
		suite.addTest(fitnesse.schedule.AllTestSuite.suite());
		suite.addTest(fitnesse.util.AllTestSuite.suite());
		suite.addTestSuite(FitnesseServerTest.class);
		suite.addTestSuite(FitNesseMainTest.class);
		suite.addTestSuite(ArgumentsTest.class);
		suite.addTestSuite(TestRunnerTest.class);
		suite.addTestSuite(FixtureTemplateCreatorTest.class);

		return suite;
	}
}
