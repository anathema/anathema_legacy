// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(UpdaterTest.class));
		suite.addTest(new TestSuite(VersionsAttributeUpdateTest.class));
		suite.addTest(new TestSuite(VirtualWikiDepricationUpdateTest.class));
		suite.addTest(new TestSuite(FileUpdateTest.class));
		suite.addTest(new TestSuite(PropertiesToXmlUpdateTest.class));

		return suite;
	}
}
