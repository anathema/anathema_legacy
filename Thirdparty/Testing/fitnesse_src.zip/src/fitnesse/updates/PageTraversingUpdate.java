// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import java.util.*;
import fitnesse.wiki.*;
import fitnesse.components.FitnesseTraversal;

public abstract class PageTraversingUpdate extends FitnesseTraversal implements Update
{
	private Properties properties;
	private WikiPage root;

	public PageTraversingUpdate(Updater updater)
	{
		properties = updater.getProperties();
		root = updater.getRoot();
	}

	public void doUpdate() throws Exception
	{
		processPagesUnder(root);
		properties.setProperty(getName(), "applied");
	}

	public abstract void processPage(WikiPage currentPage) throws Exception;

	public boolean shouldBeApplied() throws Exception
	{
		boolean usesFileSystem = root instanceof FileSystemPage;
		boolean hasBeenApplied = properties.getProperty(getName()) != null;

		return usesFileSystem && !hasBeenApplied;
	}
}
