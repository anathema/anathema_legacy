// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import junit.framework.*;
import fitnesse.testutil.FileUtil;
import fitnesse.wiki.*;

public abstract class UpdateTest extends TestCase
{
	protected WikiPage root;
	protected Update update;
	protected Updater updater;
	protected WikiPage pageOne;
	protected WikiPage pageTwo;

	public void setUp() throws Exception
	{
		FileUtil.makeDir("testDir");
		root = FileSystemPage.makeRoot("testDir", "RooT");
		pageOne = root.addPage("PageOne", "some content");
		pageTwo = pageOne.addPage("PageTwo", "page two content");

		updater = new Updater(root);
		update = makeUpdate();
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testDir");
	}

	protected abstract Update makeUpdate() throws Exception;
}
