// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.testutil.FileUtil;

import java.io.File;

public class UpdaterTest extends TestCase
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"UpdaterTest"});
	}

	public void setUp() throws Exception
	{
		Updater.testing = true;

		FileUtil.makeDir("testDir");
		root = FileSystemPage.makeRoot("testDir", "RooT");
		root.addPage("PageOne");
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testDir");
	}

	public void testProperties() throws Exception
	{
		File file = new File("testDir/RooT/properties");
		assertFalse(file.exists());
		Updater updater = new Updater(root);
		updater.update();
		assertTrue(file.exists());
	}
}
