// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import fitnesse.wiki.*;

import java.util.Properties;

public class VersionsAttributeUpdateTest extends UpdateTest
{
	public Update makeUpdate()
	{
		return new VersionsAttributeUpdate(updater);
	}

	public void testShouldBeApplied() throws Exception
	{
		assertTrue(update.shouldBeApplied());

		Properties props = updater.getProperties();
		props.setProperty(update.getName(), "applied");

		assertFalse(update.shouldBeApplied());
	}

	public void testApplication() throws Exception
	{
		clearAttributes(pageOne);
		clearAttributes(pageTwo);

		update.doUpdate();

		checkForVersionsAttribute(pageOne);
		checkForVersionsAttribute(pageTwo);

		assertEquals("applied", updater.getProperties().getProperty(update.getName()));
	}

	private void checkForVersionsAttribute(WikiPage page) throws Exception
	{
		PageData data = page.getData();
		assertEquals("true", data.getAttribute("Versions"));
	}

	private void clearAttributes(WikiPage page) throws Exception
	{
		PageData data = page.getData();
		data.setAttributes(new WikiPageProperties());
		page.commit(data);
	}
}
