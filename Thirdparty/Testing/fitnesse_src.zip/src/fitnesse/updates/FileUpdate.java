// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import java.io.*;
import java.net.*;
import java.util.*;

public class FileUpdate implements Update
{
	private String filename;
	private String url;
	private File file;
	private String rootDir;

	public FileUpdate(Updater updater, String filename, String url) throws Exception
	{
		this.filename = filename;
		this.url = url;
		rootDir = updater.root.getFileSystemPath();
		file = new File(rootDir + filename);
	}

	public void doUpdate() throws Exception
	{
		makeSureDirectoriesExisit();
		byte[] bytes = getBytesFromUrl();
		createFile(bytes);
	}

	private void createFile(byte[] bytes) throws IOException
	{
		FileOutputStream os = new FileOutputStream(file);
		os.write(bytes);
		os.close();
	}

	private void makeSureDirectoriesExisit()
	{
		LinkedList pathList = new LinkedList();
		StringTokenizer tokens = new StringTokenizer(filename, "/");
		while(tokens.hasMoreTokens())
			pathList.add(tokens.nextToken());

		pathList.removeLast();
		String currentDir = rootDir;

		for(Iterator iterator = pathList.iterator(); iterator.hasNext();)
		{
			String s = (String) iterator.next();
			currentDir = currentDir + "/" + s;
			File f = new File(currentDir);
			if(! file.exists());
				f.mkdir();
		}
	}

	private byte[] getBytesFromUrl() throws Exception
	{
		try
		{
			URL url = new URL(this.url);
			URLConnection connection = url.openConnection();
			int size = connection.getContentLength();
			InputStream is = connection.getInputStream();
			byte[] bytes = new byte[size];
			for(int i = 0; i < size; i++)
				bytes[i] = (byte)is.read();

			is.close();
			return bytes;
		}
		catch(Exception e)
		{
			String message = "(" + e + ")\n\tFitNesse was unable to automatically install this file into your installation." +
			  "\n\tMake sure you have access to fitnesse.org or download the full distribution.";

			throw new Exception(message);
		}
	}

	public String getMessage()
	{
		return "Installing the file: " + file.getAbsolutePath();
	}

	public String getName()
	{
		return "FileUpdate(" + file.getName() + ")";
	}

	public boolean shouldBeApplied() throws Exception
	{
		return ! file.exists();
	}
}
