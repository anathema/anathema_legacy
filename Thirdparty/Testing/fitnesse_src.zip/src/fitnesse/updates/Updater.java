// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import fitnesse.wiki.*;

import java.util.Properties;
import java.io.*;

public class Updater
{
	public static boolean testing = false;

	FileSystemPage root;
	Properties rootProperties;

	public Updater(WikiPage root) throws Exception
	{
		this.root = (FileSystemPage)root;
		rootProperties = loadProperties();
	}

	public void update() throws Exception
	{
		Update[] updates = makeUpdates();
		for(int i = 0; i < updates.length; i++)
		{
			Update update = updates[i];
			if(update.shouldBeApplied())
				performUpdate(update);
		}
		saveProperties();
	}

	private void performUpdate(Update update) throws Exception
	{
		try
		{
			print(update.getMessage());
			update.doUpdate();
			print("...done\n");
		}
		catch(Exception e)
		{
			print("\n\t" + e + "\n");
		}
	}

	private Update[] makeUpdates() throws Exception
	{
		return new Update[]{
			new VersionsAttributeUpdate(this),
			new AttributeAdderUpdate(this, "Properties"),
			new AttributeAdderUpdate(this, "Refactor"),
			new VirtualWikiDepricationUpdate(this),
			new FileUpdate(this, "/files/images/ball.gif", "http://fitnesse.org/files/images/ball.gif"),
			new FileUpdate(this, "/files/javascript/browserDetection.js", "http://fitnesse.org/files/javascript/browserDetection.js"),
			new FileUpdate(this, "/files/javascript/excelPaste.js", "http://fitnesse.org/files/javascript/excelPaste.js"),
			new FileUpdate(this, "/files/pages/pasteTable.html", "http://fitnesse.org/files/pages/pasteTable.html"),
			new PropertiesToXmlUpdate(this)
		};
	}

	public WikiPage getRoot()
	{
		return root;
	}

	public Properties getProperties()
	{
		return rootProperties;
	}

	public Properties loadProperties() throws Exception
	{
		Properties properties = new Properties();
		if(root instanceof FileSystemPage)
		{
			File propFile = getPropertiesFile();
			if(propFile.exists())
			{
				InputStream is = new FileInputStream(propFile);
				properties.load(is);
				is.close();
			}
		}
		return properties;
	}

	private File getPropertiesFile() throws Exception
	{
		String filename = root.getFileSystemPath() + "/properties";
		File propFile = new File(filename);
		return propFile;
	}

	public void saveProperties() throws Exception
	{
		if(root instanceof FileSystemPage)
		{
			File propFile = getPropertiesFile();
			OutputStream os = new FileOutputStream(propFile);
			rootProperties.store(os, "FitNesse properties");
			os.close();
		}
	}

	private void print(String message)
	{
		if(!testing)
			System.out.print(message);

	}

}
