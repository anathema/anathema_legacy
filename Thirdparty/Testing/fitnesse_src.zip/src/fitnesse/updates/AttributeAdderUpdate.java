// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import fitnesse.wiki.*;

public class AttributeAdderUpdate extends PageTraversingUpdate
{
	private String attributeName;

	public AttributeAdderUpdate(Updater updater, String attributeName)
	{
		super(updater);
		this.attributeName = attributeName;
	}

	public String getName()
	{
		return attributeName + "AttributeUpate";
	}

	public String getMessage()
	{
		return "Adding '" + attributeName + "' attribute to all pages";
	}

	public void processPage(WikiPage page) throws Exception
	{
		PageData data = page.getData();
		data.setAttribute(attributeName, "true");
		page.commit(data);
	}
}

