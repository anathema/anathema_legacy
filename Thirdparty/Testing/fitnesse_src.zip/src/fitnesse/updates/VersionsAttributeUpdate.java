// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;


// This class could be replaced with a AttributeAdderUpdate except that
// its name doesn't follow the convention
public class VersionsAttributeUpdate extends AttributeAdderUpdate
{
	private static final String name = "versionsAttributeUpdate";

	public VersionsAttributeUpdate(Updater updater)
	{
		super(updater, "Versions");
	}

	public String getName()
	{
		return name;
	}
}
