// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import java.io.File;

public class FileUpdateTest extends UpdateTest
{
	protected Update makeUpdate() throws Exception
	{
		return new FileUpdate(updater, "/files/images/ball.gif", "http://fitnesse.org/files/images/ball.gif");
	}

	public void testSimpleFunctions() throws Exception
	{
		assertTrue(update.shouldBeApplied());
		assertTrue(update.getMessage().startsWith("Installing the file: "));
		assertTrue(update.getMessage().endsWith("ball.gif"));
		assertEquals("FileUpdate(ball.gif)", update.getName());
	}

	public void testUpdateWithMissingDirectories() throws Exception
	{
		try
		{
			update.doUpdate();

			File file = new File("testDir/RooT/files/images/ball.gif");
			assertTrue(file.exists());

			assertFalse(update.shouldBeApplied());
		}
		catch(Exception e)
		{
			if(e.getMessage().indexOf("UnknownHostException: fitnesse.org") == -1)
				fail(e.getMessage());
		}
	}

	public void testFileMissing() throws Exception
	{
		update = new FileUpdate(updater, "/files/images/ball.gif", "http://fitnesse.org/files/missingFile");

		try
		{
			update.doUpdate();
			fail();
		}
		catch(Exception e)
		{
		}
	}
}
