// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

import fitnesse.wiki.*;
import fitnesse.wikitext.widgets.*;
import fitnesse.wikitext.*;

public class VirtualWikiDepricationUpdate extends PageTraversingUpdate
{
	public VirtualWikiDepricationUpdate(Updater updater)
	{
		super(updater);
	}

	public String getMessage()
	{
		return "Updating pages with !virtualwiki widgets";
	}

	public String getName()
	{
		return "VirtualWikiDepricationUpdate";
	}

	public void processPage(WikiPage page) throws Exception
	{
		PageData data = page.getData();
		WidgetRoot widgetRoot = new WidgetRoot(data.preProcess(), page, WidgetBuilder.virtualWidgetBuilder);
		while(widgetRoot.hasNextChild())
		{
			WikiWidget widget = widgetRoot.nextChild();
			if(widget instanceof VirtualWikiWidget)
			{
				VirtualWikiWidget vWidget = (VirtualWikiWidget)widget;
				String url = vWidget.getRemoteUrl();
				data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, url);
				page.commit(data);
				break;
			}
		}
	}
}
