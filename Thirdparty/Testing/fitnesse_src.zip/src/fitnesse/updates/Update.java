// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.updates;

public interface Update
{
	public String getName();

	public String getMessage();

	public boolean shouldBeApplied() throws Exception;

	public void doUpdate() throws Exception;
}
