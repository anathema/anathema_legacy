// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.testutil.FileUtil;

import java.io.File;

public class FitNesseMainTest extends TestCase
{

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"FitNesseMainTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
		FileUtil.deleteFileSystemDirectory("testFitnesseRoot");
	}

	public void testDirCreations() throws Exception
	{
		FitNesseContext context = new FitNesseContext();
		context.port = 80;
		context.rootPath = "testFitnesseRoot";
		new Fitnesse(context);

		assertTrue(new File("testFitnesseRoot").exists());
		assertTrue(new File("testFitnesseRoot/files").exists());

	}
}
