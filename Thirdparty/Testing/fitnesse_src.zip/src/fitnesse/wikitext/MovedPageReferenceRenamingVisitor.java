// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext;

import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.widgets.*;

public class MovedPageReferenceRenamingVisitor implements WidgetVisitor
{
	private WikiPage subjectPage;
	private String newParentName;

	public MovedPageReferenceRenamingVisitor(WikiPage subjectPage, String newParentName)
	{
		this.subjectPage = subjectPage;
		this.newParentName = newParentName;
	}

	public void visit(AliasLinkWidget widget) throws Exception
	{
	}

	public void visit(WikiWidget widget) throws Exception
	{
	}

	public void visit(WikiWordWidget widget) throws Exception
	{
		widget.renameMovedPageIfReferenced(subjectPage, newParentName);
	}
}
