// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wikitext.WikiWidget;
import fitnesse.wiki.*;

import java.util.*;

public class TOCWidget extends WikiWidget
{
	public static final String REGEXP = "^!contents[ \t]*$";

	public TOCWidget(ParentWidget parent, String text)
	{
		super(parent);
	}

	public String render() throws Exception
	{
		StringBuffer contents = new StringBuffer();
		contents.append("<ul>\n");
		WikiPage page = getWikiPage();

		List pageList = new ArrayList();
		pageList.addAll(page.getChildren());
		WikiPage virtualCoupling = page.getVirtualCoupling();
		pageList.addAll(virtualCoupling.getChildren());

		Collections.sort(pageList);
		for(Iterator iterator = pageList.iterator(); iterator.hasNext();)
		{
			WikiPage childPage = (WikiPage) iterator.next();
			contents.append("<li><a href=\"" + new PageCrawler().getQualifiedName(childPage) + "\">");
			if(childPage.isRemote())
				contents.append("<i>" + childPage.getName() + "</i>");
			else
				contents.append(childPage.getName());

			contents.append("</a></li>\n");

		}
		contents.append("</ul>\n");
		return contents.toString();
	}
}
