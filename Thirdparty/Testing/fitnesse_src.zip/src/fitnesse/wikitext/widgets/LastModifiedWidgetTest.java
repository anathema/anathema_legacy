// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import java.util.*;

//created by Jason Sypher

public class LastModifiedWidgetTest extends WidgetTest
{
	public void testRegularExpression() throws Exception
	{
		assertMatchEquals("!lastmodified", "!lastmodified");
	}

	public void testResults() throws Exception
	{
    WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page = root.addPage("SomePage", "some text");
		Date date = page.getData().getLastModificationTime();
		String formattedDate = LastModifiedWidget.formatDate(date);
		LastModifiedWidget widget = new LastModifiedWidget(new WidgetRoot(page), "!lastmodified");
		assertHasRegexp(formattedDate, widget.render());
	}

	public void testDateFormat() throws Exception
	{
		GregorianCalendar date = new GregorianCalendar(2003, 3, 1, 11, 41, 30);
		String formattedDate = LastModifiedWidget.formatDate(date.getTime());
		assertEquals("Apr 01, 2003 at 11:41:30 AM", formattedDate);
	}

	protected String getRegexp()
	{
		return LastModifiedWidget.REGEXP;
	}

}
