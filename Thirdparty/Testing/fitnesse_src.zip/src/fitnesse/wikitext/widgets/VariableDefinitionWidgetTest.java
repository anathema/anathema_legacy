// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.InMemoryPage;
import fitnesse.wiki.WikiPage;
import junit.swingui.TestRunner;

public class VariableDefinitionWidgetTest extends WidgetTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.widgets.VariableDefinitionWidgetTest"});
	}

	protected String getRegexp()
	{
		return VariableDefinitionWidget.REGEXP;
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatches("!define xyz {\n123\r\n456\r\n}\r\n");
		assertMatches("!define abc {1}\n");
		assertMatches("!define abc (1)\n");
		assertNoMatch("!define\n");
		assertNoMatch("!define x\n");
		assertNoMatch(" !define x {1}\n");
		assertMatches("!define x (!define y {123})\n");
	}

	public void testHtml() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page = root.addPage("MyPage", "content");
		WikiPage page2 = root.addPage("SecondPage", "content");

		WidgetRoot widgetRoot = new WidgetRoot(page);
		VariableDefinitionWidget widget = new VariableDefinitionWidget(widgetRoot, "!define x {1}\n");
		assertEquals("", widget.render());
		assertEquals("1", widgetRoot.getVariable("x"));

		widgetRoot = new WidgetRoot(page2);
		widget = new VariableDefinitionWidget(widgetRoot, "!define xyzzy (\nbird\n)\n");
		widget.render();
		assertEquals("\nbird\n", widgetRoot.getVariable("xyzzy"));
	}
}
