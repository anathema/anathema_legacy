// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import fitnesse.wikitext.WidgetVisitor;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AliasLinkWidget extends ParentWidget
{
	public static final String REGEXP = "\\[\\[[^\n\r\\]]+\\]\\[[^\n\r\\]]+\\]\\]";
	public static final Pattern pattern = Pattern.compile("\\[\\[([^\n\r\\]]+)\\]\\[([^\n\r\\]]+)\\]\\]");
	private String tag;
	private String href;
	WikiPage parentPage;

	public AliasLinkWidget(ParentWidget parent, String text) throws Exception
	{
		super(parent);
		parentPage = getWikiPage().getParent();
		Matcher match = pattern.matcher(text);
		if(match.find())
		{
			tag = match.group(1);
			href = match.group(2);
			addChildWidgets(tag);
		}
	}

	public String render() throws Exception
	{
		if(WikiWordWidget.isWikiWord(href))
		{
			WidgetRoot root = new WidgetRoot(getWikiPage());
			WikiWordWidget www = new WikiWordWidget(root, href);
			String theWord = www.getWikiWord();
			String qualifiedName = new PageCrawler().getPageLocation(parentPage, theWord);
			if(new PageCrawler().pageExists(parentPage, theWord))
				return ("<a href=\"" + qualifiedName + "\">" + childHtml() + "</a>");
			else
				return (childHtml() + "<a href=\"" + qualifiedName + "?edit\">?</a>");
		}
		else
			return ("<a href=\"" + href + "\">" + childHtml() + "</a>");
	}

	public String asWikiText() throws Exception
	{
		return "[[" + tag + "][" + href + "]]";
	}

	public void acceptVisitor(WidgetVisitor visitor) throws Exception
	{
		visitor.visit(this);
	}

	public void renamePageIfReferenced(WikiPage pageToRename, String newName) throws Exception
	{
		if(WikiWordWidget.isWikiWord(href))
		{
			WidgetRoot root = new WidgetRoot(getWikiPage());
			WikiWordWidget www = new WikiWordWidget(root, href);
			www.renamePageIfReferenced(pageToRename, newName);
			href = www.getText();
		}
	}
}
