// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.framework.TestCase;
import java.util.regex.Pattern;

public class PreformattedWidgetTest extends TestCase
{

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		Pattern pattern = Pattern.compile(PreformattedWidget.REGEXP, Pattern.DOTALL);
		assertTrue("match1", pattern.matcher("{{{preformatted}}}").matches());
		assertTrue("match2", pattern.matcher("{{{{preformatted}}}}").matches());
		assertFalse("match3", pattern.matcher("{{ {not preformatted}}}").matches());
		assertTrue("match4", pattern.matcher("{{{\npreformatted\n}}}").matches());
	}

	public void testHtml() throws Exception
	{
		PreformattedWidget widget = new PreformattedWidget(new WidgetRoot(null), "{{{preformatted text}}}");
		assertEquals("<pre>preformatted text</pre>", widget.render());
	}

	public void testMultiLine() throws Exception
	{
		PreformattedWidget widget = new PreformattedWidget(new WidgetRoot(null), "{{{\npreformatted text\n}}}");
		assertEquals("<pre>\npreformatted text\n</pre>", widget.render());
	}

	public void testAsWikiText() throws Exception
	{
		PreformattedWidget widget = new PreformattedWidget(new WidgetRoot(null), "{{{preformatted text}}}");
		assertEquals("{{{preformatted text}}}", widget.asWikiText());

	}

}