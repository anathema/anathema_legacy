// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wikitext.WikiWidget;

import java.util.regex.*;

public class ImageWidget extends WikiWidget
{
	public static final String REGEXP = "(?:!img(?:-[lr])? \\S+)|(?:" + LinkWidget.REGEXP + ".(?:gif|jpg|GIF|JPG))";
	private static final Pattern pattern = Pattern.compile("(!img(-[lr])? )?(\\S*)");

	private String picturePath;
	private String alignment;

	public ImageWidget(ParentWidget parent, String text)
	{
		super(parent);
		Matcher match = pattern.matcher(text);
		if(match.find())
		{
			picturePath = LinkWidget.makeUrlUsable(match.group(3));
			alignment = match.group(2);
		}
		else
			System.err.println("ImagesWidget parse error: " + text);
	}

	public String render() throws Exception
	{
		StringBuffer html = new StringBuffer("<img src=\"");
		html.append(picturePath).append("\"");
		if(alignment != null)
		{
			html.append(" align=\"");
			if("-l".equals(alignment))
				html.append("left");
			else
				html.append("right");
			html.append("\"");
		}
		html.append(">");

		return html.toString();
	}

	public String asWikiText() throws Exception
	{
		final String alignmentString = (alignment==null ? "" : alignment);
		String pathString = picturePath;
		if (pathString.startsWith("/files"))
			pathString = "http:/"+pathString;
		return "!img" + alignmentString + " " + pathString;
	}

}


