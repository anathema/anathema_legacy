// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

public class TableCellWidget extends ParentWidget
{
	private TableRowWidget parentRow = null;

	public TableCellWidget(TableRowWidget parentRow, String text) throws Exception
	{
		super(parentRow);
		this.parentRow = parentRow;
		addChildWidgets(text.trim());
	}

	public String render() throws Exception
	{
		String colspan = computeColSpan();
		StringBuffer html = new StringBuffer("<td" + colspan + ">");
		html.append(childHtml()).append("</td>");
		return html.toString();
	}

	private String computeColSpan()
	{
		int currentColumn = parentRow.children.indexOf(this) + 1;
		int maxTableColumn = parentRow.getParentTable().getColumns();
		int maxColumnThisRow = parentRow.numberOfChildren();

		String colspan = "";
		if(currentColumn == maxColumnThisRow && currentColumn != maxTableColumn)
		{
			colspan = " colspan=\"" + (maxTableColumn - currentColumn + 1) + "\"";
		}
		return colspan;
	}
}

