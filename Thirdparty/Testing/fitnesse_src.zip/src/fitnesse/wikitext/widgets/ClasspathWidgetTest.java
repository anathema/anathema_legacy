// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.swingui.TestRunner;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClasspathWidgetTest extends WidgetTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"ClasspathWidget"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals("!path somePath", "!path somePath");
	}

	public void testHtml() throws Exception
	{
		ClasspathWidget widget = new ClasspathWidget(new WidgetRoot(null), "!path some.path");
		Pattern p = Pattern.compile("classpath: some.path");
		Matcher match = p.matcher(widget.render());
		assertTrue("pattern not found", match.find());
	}

	public void testTwoNewLinesAtEnd() throws Exception
	{
		ClasspathWidget widget = new ClasspathWidget(new WidgetRoot(null), "!path some.path");
		Pattern p = Pattern.compile("classpath: some.path");
		Matcher match = p.matcher(widget.render());
		assertTrue("pattern not found", match.find());
	}

	public void testAsWikiText() throws Exception
	{
		final String PATH_WIDGET = "!path some.path";
		ClasspathWidget w = new ClasspathWidget(new WidgetRoot(null), PATH_WIDGET);
		assertEquals(PATH_WIDGET, w.asWikiText());
	}

	protected String getRegexp()
	{
		return ClasspathWidget.REGEXP;
	}
}
