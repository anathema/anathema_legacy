// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(ParentWidgetTest.class));
		suite.addTest(new TestSuite(TextWidgetTest.class));
		suite.addTest(new TestSuite(WikiWordWidgetTest.class));
		suite.addTest(new TestSuite(ItalicWidgetTest.class));
		suite.addTest(new TestSuite(BoldWidgetTest.class));
		suite.addTest(new TestSuite(PreformattedWidgetTest.class));
		suite.addTest(new TestSuite(HruleWidgetTest.class));
		suite.addTest(new TestSuite(HeaderWidgetTest.class));
		suite.addTest(new TestSuite(CenterWidgetTest.class));
		suite.addTest(new TestSuite(TableWidgetTest.class));
		suite.addTest(new TestSuite(TableRowWidgetTest.class));
		suite.addTest(new TestSuite(TableCellWidgetTest.class));
		suite.addTest(new TestSuite(ListWidgetTest.class));
		suite.addTest(new TestSuite(ListItemWidgetTest.class));
		suite.addTest(new TestSuite(RunWidgetTest.class));
		suite.addTest(new TestSuite(ClasspathWidgetTest.class));
		suite.addTest(new TestSuite(ImageWidgetTest.class));
		suite.addTest(new TestSuite(LinkWidgetTest.class));
		suite.addTest(new TestSuite(TOCWidgetTest.class));
		suite.addTest(new TestSuite(AliasLinkWidgetTest.class));
		suite.addTest(new TestSuite(LiteralWidgetTest.class));
		suite.addTest(new TestSuite(NoteWidgetTest.class));
		suite.addTest(new TestSuite(CommentWidgetTest.class));
		suite.addTest(new TestSuite(VariableDefinitionWidgetTest.class));
		suite.addTest(new TestSuite(VariableWidgetTest.class));
		suite.addTest(new TestSuite(PreProcessorLiteralWidgetTest.class));
		suite.addTest(new TestSuite(StrikeWidgetTest.class));
		suite.addTest(new TestSuite(IncludeWidgetTest.class));
		suite.addTest(new TestSuite(LastModifiedWidgetTest.class));
		suite.addTest(new TestSuite(FixtureWidgetTest.class));
		suite.addTest(new TestSuite(TextIgnoringWidgetRootTest.class));
		suite.addTest(new TestSuite(WidgetVisitorTest.class));
		suite.addTest(new TestSuite(VirtualWikiWidgetTest.class));
		suite.addTest(new TestSuite(WidgetRootTest.class));
		return suite;
	}
}
