// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.swingui.TestRunner;
import fitnesse.wikitext.WikiWidget;

public class NoteWidgetTest extends WidgetTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"NoteTestClass"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals("!note some note", "!note some note");
		assertMatchEquals("! note some note", null);
	}

	public void test() throws Exception
	{
		WikiWidget widget = new NoteWidget(new WidgetRoot(null), "!note some note");
		assertEquals("<font size=\"2\" color=\"" + NoteWidget.GREY + "\">some note</font>", widget.render());
	}

	protected String getRegexp()
	{
		return NoteWidget.REGEXP;
	}
}
