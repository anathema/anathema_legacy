// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import junit.swingui.TestRunner;

public class RunWidgetTest extends WidgetTest
{
	public WikiPage page;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RunWidgetTest"});
	}

	public void setUp() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		page = root.addPage("SomePage");
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals("!r Run", "!r Run");
		assertMatchEquals("\n!r Run", "!r Run");
		assertMatchEquals(" !r Run", null);
	}

	public void testHtml() throws Exception
	{
		RunWidget widget = new RunWidget(new WidgetRoot(page), "!r Package.Class");
		assertHasRegexp("<a href=\\\"SomePage\\?responder=start&className=Package.Class\\\">", widget.render());
	}

	public void testClassNameNotParsed() throws Exception
	{
		RunWidget widget = new RunWidget(new WidgetRoot(page), "!r SomePackage.SomeClass");
		assertHasRegexp("SomePackage.SomeClass<", widget.render());
	}

	public void testAsWikiText() throws Exception
	{
		final String RUN_WIDGET = "!r someCommand";
		RunWidget w = new RunWidget(new WidgetRoot(null), RUN_WIDGET);
		assertEquals(RUN_WIDGET, w.asWikiText());
	}

	protected String getRegexp()
	{
		return RunWidget.REGEXP;
	}
}
