// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import junit.swingui.TestRunner;

public class ImageWidgetTest extends WidgetTest
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.widgets.ImageWidgetTest"});
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals("http://www.objectmentor.com/resources/bookstore/books/PPPCoverIcon.gif", "http://www.objectmentor.com/resources/bookstore/books/PPPCoverIcon.gif");
		assertMatchEquals("http://www.objectmentor.com/x.jpg", "http://www.objectmentor.com/x.jpg");
		assertMatchEquals("http://www.objectmentor.com/x.GIF", "http://www.objectmentor.com/x.GIF");
		assertMatchEquals("http://www.objectmentor.com/x.JPG", "http://www.objectmentor.com/x.JPG");
		assertMatchEquals("!img http://files/someImage", "!img http://files/someImage");
		assertMatchEquals("!img http://www.oma.com/x.gif", "!img http://www.oma.com/x.gif");
		assertMatchEquals("!img /root/file.gif", "!img /root/file.gif");
		assertMatchEquals("!img  /root/file.gif", null);
		assertMatchEquals("!img-l http://files/x.gif", "!img-l http://files/x.gif");
	}

	public void testWidget() throws Exception
	{
		ImageWidget widget = new ImageWidget(new WidgetRoot(null), "http://host.com/file.jpg");
		assertEquals("<img src=\"http://host.com/file.jpg\">", widget.render());

		widget = new ImageWidget(new WidgetRoot(null), "!img http://files/file.jpg");
		assertEquals("<img src=\"/files/file.jpg\">", widget.render());

		widget = new ImageWidget(new WidgetRoot(null), "!img-l http://files/file.jpg");
		assertEquals("<img src=\"/files/file.jpg\" align=\"left\">", widget.render());

		widget = new ImageWidget(new WidgetRoot(null), "!img /files/file.jpg");
		assertEquals("<img src=\"/files/file.jpg\">", widget.render());
	}

	public void testAsWikiText() throws Exception
	{
		checkWikiTextReconstruction("!img http://hello.jpg");
		checkWikiTextReconstruction("!img http://files/hello.jpg");
		checkWikiTextReconstruction("!img-l http://hello.jpg");
		checkWikiTextReconstruction("!img-r http://hello.jpg");
	}

	private void checkWikiTextReconstruction(String original) throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("root");
		WikiPage somePage = root.addPage("SomePage");
		WidgetRoot widgetRoot = new WidgetRoot(somePage);
		ImageWidget widget = new ImageWidget(widgetRoot, original);
		assertEquals(original, widget.asWikiText());
	}

	protected String getRegexp()
	{
		return ImageWidget.REGEXP;
	}
}
