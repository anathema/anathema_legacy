// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.WidgetBuilder;

import java.util.*;

public class WidgetRoot extends ParentWidget
{
	public String value;
	private Map variables = new HashMap();
	private WidgetBuilder builder;
	private WikiPage page;
	private boolean doEscaping = true;
	private ArrayList literals = new ArrayList();

	public WidgetRoot(WikiPage page) throws Exception
	{
		this("", page, WidgetBuilder.htmlWidgetBuilder);
	}

	public WidgetRoot(String value, WikiPage page, WidgetBuilder builder) throws Exception
	{
		super(null);
		this.page = page;
		this.builder = builder;
		this.value = value;
		buildWidgets(value);
	}

	public WidgetRoot(String value, WikiPage page) throws Exception
	{
		this(value, page, WidgetBuilder.htmlWidgetBuilder);
	}

	public WidgetBuilder getBuilder()
	{
		return builder;
	}

	private void buildWidgets(String value) throws Exception
	{
		if(value != null)
			addChildWidgets(value);
	}

	public String render() throws Exception
	{
		return childHtml();
	}

	public String getVariable(String key) throws Exception
	{
		String value = (String) variables.get(key);

		WikiPage page = getWikiPage();
		while(!page.isRoot() && value == null)
		{
			page = page.getParent();
			value = page.getData().getVariable(key);
		}

		return value;
	}

	public void addVariable(String key, String value)
	{
		variables.put(key, value);
	}

	public int defineLiteral(String literal)
	{
		int literalNumber = literals.size();
		literals.add(literal);
		return literalNumber;
	}

	public String getLiteral(int literalNumber)
	{
		if(literalNumber >= literals.size())
			return "literal(" + literalNumber + ") not found.";
		return (String) literals.get(literalNumber);
	}

	public WikiPage getWikiPage()
	{
		return page;
	}

	public void setEscaping(boolean value)
	{
		doEscaping = value;
	}

	public boolean doEscaping()
	{
		return doEscaping;
	}

	public ArrayList getLiterals()
	{
		return literals;
	}

	public void setLiterals(ArrayList literals)
	{
		this.literals = literals;
	}

	public String asWikiText() throws Exception
	{
		return childWikiText();
	}
}

