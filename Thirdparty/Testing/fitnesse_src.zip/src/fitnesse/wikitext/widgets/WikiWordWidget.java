// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import fitnesse.components.PageReferencer;
import fitnesse.wikitext.WidgetVisitor;
import java.util.regex.Pattern;

public class WikiWordWidget extends TextWidget implements PageReferencer
{
	public static final String SINGLE_WIKIWORD_REGEXP = "\\b\\p{Upper}(?:\\p{Lower}+\\p{Upper}\\p{Lower}*)+";
	public static final String REGEXP = "\\^?(?:[.]?" + SINGLE_WIKIWORD_REGEXP + ")+\\b";

	WikiPage parentPage;

	public WikiWordWidget(ParentWidget parent, String text) throws Exception
	{
		super(parent, text);
		WikiPage wikiPage = getWikiPage();
		parentPage = wikiPage.getParent();
	}

	public String render() throws Exception
	{
		String theWord = getWikiWord();

		StringBuffer html = new StringBuffer();
		if(new PageCrawler().pageExists(parentPage, theWord))
		{
			html.append("<a href=\"");
			html.append(new PageCrawler().getPageLocation(parentPage, theWord)).append("\">");
			html.append(getText()).append("</a>");
		}
		else
		{
			html.append(getText());
			html.append("<a href=\"").append(new PageCrawler().getPageLocation(parentPage, theWord));
			html.append("?edit");
			html.append("\">?</a>");
		}

		return html.toString();
	}

	// If pageToRename is referenced somewhere in this wiki word (could be a parent, etc.),
	// rename it to newName.
	public void renamePageIfReferenced(WikiPage pageToRename, String newName) throws Exception
	{
		String qualifiedReference = getQualifiedWikiWord();
		String qualifiedTarget = "." + new PageCrawler().getQualifiedName(pageToRename);
		if(refersTo(qualifiedReference, qualifiedTarget))
		{
			int oldNameLength = qualifiedTarget.length();
			String newQualifiedTarget = "." + rename(qualifiedTarget.substring(1), newName);
			String newQualifiedReference = newQualifiedTarget + qualifiedReference.substring(oldNameLength);
			String renamedReference = makeRenamedRelativeReference(newQualifiedReference);
			setText(renamedReference);
		}
	}

	public void renameMovedPageIfReferenced(WikiPage subjectPage, String newParentName) throws Exception
	{
		String oldQualifiedName = "." + new PageCrawler().getQualifiedName(subjectPage);
		String reference = getQualifiedWikiWord();
		if(refersTo(reference, oldQualifiedName))
		{
			String newQualifiedName;
			if("".equals(newParentName))
				newQualifiedName = "." + subjectPage.getName();
			else
				newQualifiedName = "." + newParentName + "." + subjectPage.getName();

     		setText(newQualifiedName);
		}
	}

	String makeRenamedRelativeReference(String newQualifiedReference) throws Exception
	{
		String rawReference = getText();
		String renamedRawReference = rawReference;
		if(rawReference.startsWith(".")) // absolute reference
			renamedRawReference = newQualifiedReference;
		else // relative reference
		{
			String qualifiedReferenceToParent = "." + new PageCrawler().getQualifiedName(parentPage);
			boolean parentPrefixHasTrailingDot = !parentPage.isRoot();
			String parentPrefix = qualifiedReferenceToParent + (parentPrefixHasTrailingDot ? "." : "");
			String referenceRemainder = newQualifiedReference.substring(parentPrefix.length());
			if(newQualifiedReference.startsWith(parentPrefix)) // It's not a component of the parent that is being renamed.
			{
				if(rawReference.startsWith("^"))
					renamedRawReference = "^" + referenceRemainder.substring(referenceRemainder.indexOf(".") + 1);
				else
					renamedRawReference = referenceRemainder;
			}
		}
		return renamedRawReference;
	}

	static boolean refersTo(String qualifiedReference, String qualifiedTarget)
	{
		if(qualifiedReference.equals(qualifiedTarget))
			return true;
		if(qualifiedReference.startsWith(qualifiedTarget + "."))
			return true;
		return false;
	}

	private String getQualifiedWikiWord() throws Exception
	{
		return "." + new PageCrawler().getPageLocation(parentPage, expandUparrow(getText()));
	}

	private String rename(String oldQualifiedName, String newPageName)
	{
		String newQualifiedName = oldQualifiedName;

		int lastDotIndex = oldQualifiedName.lastIndexOf(".");
		if(lastDotIndex < 1)
			newQualifiedName = newPageName;
		else
			newQualifiedName = oldQualifiedName.substring(0, lastDotIndex + 1) + newPageName;
		return newQualifiedName;
	}

	String getWikiWord() throws Exception
	{
		String theWord = getText();
		theWord = expandUparrow(theWord);
		return theWord;
	}

	public static boolean isWikiWord(String word)
	{
		return Pattern.matches(REGEXP, word);
	}

	protected String expandUparrow(String theWord) throws Exception
	{
		if(theWord.charAt(0) == '^')
		{
			theWord = getWikiPage().getName() + "." + theWord.substring(1);
		}
		return theWord;
	}

	public WikiPage getReferencedPage() throws Exception
	{
		String theWord = getWikiWord();
		return new PageCrawler().getPage(parentPage, theWord);
	}

	public void acceptVisitor(WidgetVisitor visitor) throws Exception
	{
		visitor.visit(this);
	}
}
