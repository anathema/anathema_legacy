// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import java.util.Date;
import java.text.SimpleDateFormat;

import fitnesse.wikitext.WikiWidget;

//created by Jason Sypher

public class LastModifiedWidget extends WikiWidget
{
	public static final String REGEXP = "^!lastmodified";
	private static final SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a");
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");

	public LastModifiedWidget(ParentWidget parent, String text) throws Exception
	{
		super(parent);
	}

	public String render() throws Exception
	{
		String formattedDate = formatDate(getWikiPage().getData().getLastModificationTime());
		StringBuffer buffer = new StringBuffer();
		brownText(buffer, "Last modified on " + formattedDate);

		return buffer.toString();
	}

	public static String formatDate(Date date)
	{
		String formattedDate = dateFormat.format(date) + " at " + timeFormat.format(date);

		return formattedDate;
	}

}