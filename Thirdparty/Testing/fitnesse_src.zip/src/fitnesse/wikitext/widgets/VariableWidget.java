// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;


import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class VariableWidget extends ParentWidget
{
	public static final String REGEXP = "\\$\\{\\w+\\}";
	public static final Pattern pattern = Pattern.compile("\\$\\{(\\w+)\\}", Pattern.MULTILINE + Pattern.DOTALL);
	private String name = null;

	public VariableWidget(ParentWidget parent, String text)
	{
		super(parent);
		Matcher match = pattern.matcher(text);
		if(match.find())
		{
			name = match.group(1);
		}
	}

	public String render() throws Exception
	{
		String value = parent.getVariable(name);
		if(value != null)
			return value;
		else
			return makeUndefinedVariableExpression(name);
	}

	private String makeUndefinedVariableExpression(String name)
	{
		return "!-<span style=\"background : #FFFF00\">undefined variable: " + name + "</span>-!";
	}

}


