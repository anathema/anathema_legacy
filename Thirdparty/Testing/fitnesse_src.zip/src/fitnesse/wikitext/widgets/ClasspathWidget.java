// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;


import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class ClasspathWidget extends TextWidget
{
	public static final String REGEXP = "^!path [^\r\n]*";
	private static final Pattern pattern = Pattern.compile("^!path (.*)");

	public ClasspathWidget(ParentWidget parent, String text)
	{
		super(parent);
		Matcher match = pattern.matcher(text);
		if(match.find())
			this.text = match.group(1);
	}

	public String render() throws Exception
	{
		StringBuffer html = new StringBuffer();
		brownText(html, "classpath: " + getText());

		return html.toString();
	}

	public String asWikiText() throws Exception
	{
		return "!path " + this.text;
	}
}