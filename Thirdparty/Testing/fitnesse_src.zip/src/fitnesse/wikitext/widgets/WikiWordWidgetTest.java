// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import junit.framework.TestCase;
import junit.swingui.TestRunner;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WikiWordWidgetTest extends TestCase
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.widgets.WikiWordWidgetTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
	}

	public void tearDown() throws Exception
	{
	}

	public void testWikiWordRegexp() throws Exception
	{
		checkWord(true, "SimpleWikiWord", "WikiWord");
		checkWord(true, "ThreeWordWikiWord", "WordWordWord");
		checkWord(false, "DoubleCapitals", "HelloDDouble");
		checkWord(true, "Initials", "RcM");
		checkWord(false, "Hello", "Hello");
		checkWord(true, "many words", "WikiWordWithManyWords");
		checkWord(true, "dot seperated", "WidgetRoot.ChildPage");
		checkWord(true, "three level", "GrandPa.FatheR.SoN");
		checkWord(true, "Dot at start", ".RootPage.ChildPage");
		checkWord(false, "Lower case at start", "lowerCaseAtStart");
		checkWord(true, "SubPage", "^SubPage");
		checkWord(true, "SubPage Multiple", "^SubPage.SubPage");
	}

	public void testHtml() throws Exception
	{
		WikiPage page = root.addPage("PageOne");
		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(page), "WikiWord");
		assertEquals("WikiWord<a href=\"WikiWord?edit\">?</a>", widget.render());
		page = root.addPage("WikiWord");
		widget = new WikiWordWidget(new WidgetRoot(page), "WikiWord");
		assertEquals("<a href=\"WikiWord\">WikiWord</a>", widget.render());
	}

	public void testSubPageWidget() throws Exception
	{
 		WikiPage root = InMemoryPage.makeRoot("root");
		WikiPage superPage = root.addPage("SuperPage");
		superPage.getData().setContent("^SubPage");
		String renderedText = superPage.getData().getHtml();
		assertEquals("^SubPage<a href=\"SuperPage.SubPage?edit\">?</a>", renderedText);
		superPage.addPage("SubPage");
		renderedText = superPage.getData().getHtml();
		assertEquals("<a href=\"SuperPage.SubPage\">^SubPage</a>", renderedText);
	}

	private void checkWord(boolean equals, String message, String word)
	{
		Pattern p = Pattern.compile(WikiWordWidget.REGEXP, Pattern.DOTALL | Pattern.MULTILINE);
		Matcher match = p.matcher(word);
		assertEquals(message + " does not match", equals, match.find());
		if(equals)
			assertEquals(message, word, match.group(0));
	}

	public void testIsWikiWord() throws Exception
	{
		assertEquals(true, WikiWordWidget.isWikiWord("HelloThere"));
		assertEquals(false, WikiWordWidget.isWikiWord("not.a.wiki.word"));
	}

	public void testAsWikiText() throws Exception
	{
		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(root.addPage("SomePage")), "OldText");
		assertEquals("OldText", widget.asWikiText());
		widget.setText("NewText");
		assertEquals("NewText", widget.asWikiText());
	}

	public void testQualifiedReferenceToSubReference() throws Exception
	{
		WikiPage myPage = root.addPage("MyPage");
		myPage.addPage("SubPage");
		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(myPage), "^SubPage");
		assertEquals("^NewName", widget.makeRenamedRelativeReference(".MyPage.NewName"));
	}

	public void testQualifiedReferenceToRelativeReference() throws Exception
	{
		WikiPage myPage = root.addPage("MyPage");
		root.addPage("MyBrother");
		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(myPage), "MyBrother");
		assertEquals("MyBrother", widget.makeRenamedRelativeReference(".MyBrother"));

		WikiPage subPageOne = myPage.addPage("SubPageOne");
		myPage.addPage("SubPageTwo");
		widget = new WikiWordWidget(new WidgetRoot(subPageOne), "SubPageTwo");
		assertEquals("SubPageTwo", widget.makeRenamedRelativeReference(".MyPage.SubPageTwo"));
	}

	public void testRefersTo() throws Exception
	{
		assertTrue(WikiWordWidget.refersTo(".PageOne", ".PageOne"));
		assertTrue(WikiWordWidget.refersTo(".PageOne.PageTwo", ".PageOne"));
		assertFalse(WikiWordWidget.refersTo(".PageOne.PageTwo", ".PageOne.PageTw"));
	}

	public void testRenameMovedPageIfReferenced1() throws Exception
	{
		WikiPage page1 = root.addPage("PageOne");
		WikiPage page2 = root.addPage("PageTwo");

		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(page1), "PageTwo");
		widget.renameMovedPageIfReferenced(page2, "PageOne");
		assertEquals(".PageOne.PageTwo", widget.text);
	}

	public void testRenameMovedPageIfReferenced2() throws Exception
	{
		WikiPage page1 = root.addPage("PageOne");
		WikiPage page2 = page1.addPage("PageTwo");

		WikiWordWidget widget = new WikiWordWidget(new WidgetRoot(page1), "^PageTwo");
		widget.renameMovedPageIfReferenced(page2, "");
		assertEquals(".PageTwo", widget.text);
	}
}
