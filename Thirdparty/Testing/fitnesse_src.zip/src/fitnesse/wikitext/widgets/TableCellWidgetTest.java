// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wikitext.WikiWidget;
import junit.framework.TestCase;
import junit.swingui.TestRunner;

public class TableCellWidgetTest extends TestCase
{
	public TableRowWidget row;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.widgets.TableCellWidgetTest"});
	}

	public void setUp() throws Exception
	{
		TableWidget table = new TableWidget(new WidgetRoot(null), "");
		row = new TableRowWidget(table, "");
	}

	public void tearDown() throws Exception
	{
	}

	public void testOne() throws Exception
	{
	}

	public void testSimpleCell() throws Exception
	{
		TableCellWidget cell = new TableCellWidget(row, "a");
		assertEquals(1, cell.numberOfChildren());
		WikiWidget child = cell.nextChild();
		assertEquals(TextWidget.class, child.getClass());
		assertEquals("a", ((TextWidget) child).getText());
	}

	public void testTrimsWhiteSpace() throws Exception
	{
		TableCellWidget cell = new TableCellWidget(row, " 1 item ");
		assertEquals(1, cell.numberOfChildren());
		WikiWidget child = cell.nextChild();
		assertEquals(TextWidget.class, child.getClass());
		assertEquals("1 item", ((TextWidget) child).getText());
	}
}