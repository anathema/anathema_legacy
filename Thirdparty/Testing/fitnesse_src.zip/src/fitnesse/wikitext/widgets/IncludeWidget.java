// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import fitnesse.components.PageReferencer;

import java.util.regex.*;

public class IncludeWidget extends ParentWidget implements PageReferencer
{
	public static final String REGEXP = "^!include " + WikiWordWidget.REGEXP;
	private static final Pattern pattern = Pattern.compile("^!include (.*)");

	private String pageName;

	public IncludeWidget(ParentWidget parent, String text) throws Exception
	{
		super(parent);
		Matcher match = pattern.matcher(text);
		if(match.find())
		{
			pageName = match.group(1);
			addChildWidgets(getIncludedPageContent());
		}
	}

	public String render() throws Exception
	{
		return childHtml();
	}

	private String getIncludedPageContent() throws Exception
	{
		WikiPage parentPage = getParentPage();
		if(new PageCrawler().pageExists(parentPage, pageName))
		{
			WikiPage page = new PageCrawler().getPage(parentPage, pageName);
			return page.getData().getContent();
		}
		else
		{
			return "----\n'''Page include failed because the page " + pageName + " does not exist.'''\n----";
		}
	}

	private WikiPage getParentPage() throws Exception
	{
		return parent.getWikiPage().getParent();
	}

	public WikiPage getReferencedPage() throws Exception
	{
		return new PageCrawler().getPage(getParentPage(), pageName);
	}
}
