// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TableRowWidget extends ParentWidget
{
	private static final Pattern pattern = Pattern.compile("\\|([^\\|\n\r]*)");
	private TableWidget parentTable;

	public TableRowWidget(TableWidget parentTable, String text) throws Exception
	{
		super(parentTable);
		this.parentTable = parentTable;
		addCells(text);
	}

	public int getColumns()
	{
		return numberOfChildren();
	}

	public TableWidget getParentTable()
	{
		return parentTable;
	}

	public String render() throws Exception
	{
		StringBuffer html = new StringBuffer("<tr>");
		html.append(childHtml()).append("</tr>\n");
		return html.toString();
	}

	private void addCells(String text) throws Exception
	{
		Matcher match = pattern.matcher(text);
		if(match.find())
		{
			new TableCellWidget(this, match.group(1));
			addCells(text.substring(match.end()));
		}
	}
}

