// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.MockWikiPage;
import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.WikiWidget;
import junit.swingui.TestRunner;

public class ListWidgetTest extends WidgetTest
{
	private WikiPage mockSource;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"ListWidgetTest"});
	}

	public void setUp() throws Exception
	{
		mockSource = new MockWikiPage();
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals(" *Item1", " *Item1");
		assertMatchEquals(" *Item1\n *Item2", " *Item1\n *Item2");
		assertMatchEquals(" * Item1\n *  Item2\n", " * Item1\n *  Item2\n");
		assertMatchEquals(" *Item1\n  *Item1a", " *Item1\n  *Item1a");
		assertMatchEquals("*Item1  *Item1a", null);
		assertMatchEquals(". *Item1", null);
		assertMatchEquals(" 1Item1", " 1Item1");
		assertMatchEquals("\nWikiTextExample *hello\n", null);
	}

	public void testSimpleList() throws Exception
	{
		ListWidget list = new ListWidget(new WidgetRoot(null), " *Item1");
		assertTrue("should not be ordered", !list.isOrdered());
		assertEquals(0, list.getLevel());
		assertEquals(1, list.numberOfChildren());
		WikiWidget child = list.nextChild();
		assertEquals(ListItemWidget.class, child.getClass());
		ListItemWidget item = (ListItemWidget) child;
		assertEquals(1, item.numberOfChildren());
		child = item.nextChild();
		assertEquals(TextWidget.class, child.getClass());
		assertEquals("Item1", ((TextWidget) child).getText());
	}

	public void testSimpleOrderedList() throws Exception
	{
		ListWidget list = new ListWidget(new WidgetRoot(null), " 1Item1");
		assertTrue("should be ordered", list.isOrdered());
		assertEquals(0, list.getLevel());
		assertEquals(1, list.numberOfChildren());
	}

	public void testMultipleItems() throws Exception
	{
		ListWidget list = new ListWidget(new WidgetRoot(null), " *Item1\n *Item2");
		assertEquals(2, list.numberOfChildren());
		assertEquals(ListItemWidget.class, list.nextChild().getClass());
		assertEquals(ListItemWidget.class, list.nextChild().getClass());
	}

	public void testMultiLevelList() throws Exception
	{
		ListWidget list = new ListWidget(new WidgetRoot(null), " *Item1\n  1Item1a\n *Item2");
		assertEquals(3, list.numberOfChildren());
		assertEquals(0, list.getLevel());
		assertEquals(ListItemWidget.class, list.nextChild().getClass());

		WikiWidget child = list.nextChild();
		assertEquals(ListWidget.class, child.getClass());
		ListWidget childList = (ListWidget) child;
		assertEquals(1, childList.getLevel());
		assertTrue("should be ordered", childList.isOrdered());

		assertEquals(ListItemWidget.class, list.nextChild().getClass());
	}

	public void testHtml() throws Exception
	{
		compareHtmlResult(" *Item1", "<ul>\n\t<li>Item1\n</ul>\n");
		compareHtmlResult(" 1Item1", "<ol>\n\t<li>Item1\n</ol>\n");
		compareHtmlResult(" *Item1\n  0Item1a", "<ul>\n\t<li>Item1\n\t<ol>\n\t\t<li>Item1a\n\t</ol>\n</ul>\n");
	}

	private void compareHtmlResult(String s1, String s2) throws Exception
	{
		ListWidget list = new ListWidget(new WidgetRoot(null), s1);
		assertEquals(s2, list.render());
	}

	protected String getRegexp()
	{
		return ListWidget.REGEXP;
	}

}