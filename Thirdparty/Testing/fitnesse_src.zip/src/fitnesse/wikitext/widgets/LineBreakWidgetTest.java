// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.framework.TestCase;
import junit.swingui.TestRunner;

import java.util.regex.Pattern;

public class LineBreakWidgetTest extends TestCase
{
	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.widgets.LineBreakWidgetTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertTrue("match1", Pattern.matches(LineBreakWidget.REGEXP, "\n"));
		assertTrue("match2", Pattern.matches(LineBreakWidget.REGEXP, "\r"));
		assertTrue("match3", Pattern.matches(LineBreakWidget.REGEXP, "\r\n"));
		assertTrue("match4", !Pattern.matches(LineBreakWidget.REGEXP, "\n\r"));
	}

	public void testHtml() throws Exception
	{
		LineBreakWidget widget = new LineBreakWidget(new WidgetRoot(null), "\n");
		assertEquals("<br>", widget.render());
	}
}