// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;


public class MockWidget extends TextWidget
{
	public MockWidget(ParentWidget parent, String text)
	{
		super(parent, text);
	}
}

