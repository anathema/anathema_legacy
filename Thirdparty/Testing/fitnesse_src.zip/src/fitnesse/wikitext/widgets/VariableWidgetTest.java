// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.swingui.TestRunner;
import fitnesse.wiki.WikiPage;
import fitnesse.wiki.InMemoryPage;
import fitnesse.wikitext.WidgetBuilder;

public class VariableWidgetTest extends WidgetTest
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"VariableWidgetTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("root");
	}

	public void tearDown() throws Exception
	{
	}

	public void testMatches() throws Exception
	{
		assertMatches("${X}");
		assertMatches("${xyz}");
	}

	protected String getRegexp()
	{
		return VariableWidget.REGEXP;
	}

	public void testVariableIsExpressed() throws Exception
	{
		WikiPage page = root.addPage("MyPage", "");
		WidgetRoot widgetRoot = new WidgetRoot("", page, WidgetBuilder.preprocessingWidgetBuilder);
		widgetRoot.addVariable("x", "1");
		VariableWidget w = new VariableWidget(widgetRoot, "${x}");
		assertEquals("1", w.render());
	}

	public void testVariableInParentPage() throws Exception
	{
		WikiPage parent = root.addPage("ParentPage", "!define var {zot}\n");
		WikiPage child = parent.addPage("ChildPage", "ick");

		WidgetRoot widgetRoot = new WidgetRoot("", child, WidgetBuilder.preprocessingWidgetBuilder);
		VariableWidget w = new VariableWidget(widgetRoot, "${var}");
		assertEquals("zot", w.render());
	}

	public void testUndefinedVariable() throws Exception
	{
		WikiPage page = root.addPage("MyPage", "");
		WidgetRoot widgetRoot = new WidgetRoot("", page, WidgetBuilder.preprocessingWidgetBuilder);
		VariableWidget w = new VariableWidget(widgetRoot, "${x}");
		assertEquals("!-<span style=\"background : #FFFF00\">undefined variable: x</span>-!", w.render());
	}
}
