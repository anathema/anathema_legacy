// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wiki.*;
import fitnesse.wikitext.WidgetBuilder;

public class IncludeWidgetTest extends WidgetTest
{
	private WikiPage root;
	private WikiPage page1;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		page1 = root.addPage("PageOne", "page one");
		root.addPage("PageTwo", "page '''two'''");
		root.addPage("PageTwo.ChildOne", "child page");
	}

	public void tearDown() throws Exception
	{
	}

	public void testRegexp() throws Exception
	{
		assertMatchEquals("!include SomePage", "!include SomePage");
		assertMatchEquals("abc\n!include SomePage\nxyz", "!include SomePage");
		assertMatchEquals("!include .SomePage.ChildPage", "!include .SomePage.ChildPage");
		assertNoMatch("!include nonWikiWord");
		assertNoMatch(" !include WikiWord");
	}

	public void testRender() throws Exception
	{
		IncludeWidget widget = new IncludeWidget(new WidgetRoot(page1), "!include PageOne");
		assertEquals("page one", widget.render());
		widget = new IncludeWidget(new WidgetRoot(page1), "!include .PageTwo.ChildOne");
		assertEquals("child page", widget.render());
	}

	public void testRenderWhenMissing() throws Exception
	{
		IncludeWidget widget = new IncludeWidget(new WidgetRoot(page1), "!include MissingPage");
		assertHasRegexp("MissingPage.*does not exist", widget.render());
	}

	protected String getRegexp()
	{
		return IncludeWidget.REGEXP;
	}

    public void testNoNullPointerWhenIncludingFromRootPage() throws Exception
    {
		IncludeWidget widget = new IncludeWidget(new WidgetRoot(root), "!include .PageOne");
		assertEquals("page one", widget.render());
    }

	public void testIncludingVariables() throws Exception
	{
		root.addPage("VariablePage", "This is VariablePage\n!define X {blah!}\n");
		root.addPage("IncludingPage");
		WidgetRoot widgetRoot = new WidgetRoot("This is IncludingPage\n!include .VariablePage X=${X}",
		                                       root.getChildPage("IncludingPage"), WidgetBuilder.preprocessingWidgetBuilder);
		String content = widgetRoot.render();
		assertHasRegexp("X=blah!", content);
	}
}
