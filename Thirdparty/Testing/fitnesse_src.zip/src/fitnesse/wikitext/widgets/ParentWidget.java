// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wikitext.*;

import java.util.*;
import java.util.regex.Matcher;

public abstract class ParentWidget extends WikiWidget
{
	protected ArrayList children = new ArrayList();
	private int currentChild = 0;

	public ParentWidget(ParentWidget parent)
	{
		super(parent);
	}

	public void reset()
	{
		children.clear();
		currentChild = 0;
	}

	public void addChild(WikiWidget widget)
	{
		children.add(widget);
	}

	public int numberOfChildren()
	{
		return children.size();
	}

    public List getChildren()
    {
        return children;
    }

	public WikiWidget nextChild()
	{
		if(hasNextChild())
			return (WikiWidget) children.get(currentChild++);
		else
			throw new ArrayIndexOutOfBoundsException("No next child exists");
	}

	public boolean hasNextChild()
	{
		return (currentChild < numberOfChildren());
	}

	public String childHtml() throws Exception
	{
		currentChild = 0;
		StringBuffer html = new StringBuffer();
		while(hasNextChild())
		{
			WikiWidget child = nextChild();
			html.append(child.render());
		}

		return html.toString();
	}

	public String childWikiText() throws Exception
	{
		currentChild = 0;
		StringBuffer wikiText = new StringBuffer();
		while(hasNextChild())
		{
			WikiWidget child = nextChild();
			wikiText.append(child.asWikiText());
		}

		return wikiText.toString();

	}

	public int defineLiteral(String literal)
	{
		return parent.defineLiteral(literal);
	}

	public String getLiteral(int literalNumber)
	{
		return parent.getLiteral(literalNumber);
	}

	public void addVariable(String key, String value)
	{
		parent.addVariable(key, value);
	}

	public String getVariable(String key) throws Exception
	{
		return parent.getVariable(key);
	}

	public void addChildWidgets(String value) throws Exception
	{
		Matcher m = getBuilder().getWidgetPattern().matcher(value);

		if(m.find())
		{
			String preString = value.substring(0, m.start());
			if(!preString.equals(""))
				new TextWidget(this, preString);
			getBuilder().makeWidget(this, m);
			String postString = value.substring(m.end(), value.length());
			if(!postString.equals(""))
				addChildWidgets(postString);
		}
		else
			new TextWidget(this, value);
	}

	public WidgetBuilder getBuilder()
	{
		return parent.getBuilder();
	}

	public boolean doEscaping()
	{
		return parent.doEscaping();
	}

	public boolean preProcessingComplete()
	{
		return (children.size() == 1 && (children.get(0) instanceof TextWidget));
	}

	public void acceptVisitor(WidgetVisitor visitor) throws Exception
	{
		visitor.visit(this);
		currentChild = 0;
		while(hasNextChild())
		{
			WikiWidget child = nextChild();
			child.acceptVisitor(visitor);
		}
	}
}

