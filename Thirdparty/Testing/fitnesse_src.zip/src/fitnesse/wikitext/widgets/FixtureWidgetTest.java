// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

public class FixtureWidgetTest extends WidgetTest
{
	public void testHtml() throws Exception
	{
		assertMatches("test 123", "test 123");
		FixtureWidget widget = new FixtureWidget(new WidgetRoot(null), "!fixture some.FixtureName");
		String html = widget.render();
		assertMatches("fixture: some.FixtureName", html);
	}

	public void testAsWikiText() throws Exception
	{
		final String FIXTURE_WIDGET = "!fixture myFixture";
		FixtureWidget w = new FixtureWidget(new WidgetRoot(null), FIXTURE_WIDGET);
		assertEquals(FIXTURE_WIDGET, w.asWikiText());
	}

	protected String getRegexp()
	{
		return FixtureWidget.REGEXP;
	}
}
