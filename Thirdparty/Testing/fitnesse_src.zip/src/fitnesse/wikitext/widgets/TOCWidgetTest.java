// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.testutil.FitnesseUtil;

public class TOCWidgetTest extends WidgetTest
{
	private WikiPage root;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"TOCWidgetTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		WikiPage parent = root.addPage("ParenT", "parent");
		root.addPage("ParentTwo", "parent two");
		parent.addPage("ChildOne", "content");
		parent.addPage("ChildTwo", "content");
	}

	public void tearDown() throws Exception
	{
	}

	public void testMatch() throws Exception
	{
		assertMatchEquals("!contents\n", "!contents");
		assertMatchEquals("!contents\r", "!contents");
		assertMatchEquals(" !contents\n", null);
		assertMatchEquals("!contents zap\n", null);
		assertMatchEquals("!contents \n", "!contents ");
	}

	public void testHtml() throws Exception
	{
		WikiPage parent = root.getChildPage("ParenT");
		TOCWidget w = new TOCWidget(new WidgetRoot(parent), "!contents\n");
		assertHasRegexp("<ul>\n", w.render());
		assertHasRegexp("<li><a href=\"ParenT.ChildOne\">ChildOne</a></li>\n", w.render());
		assertHasRegexp("<li><a href=\"ParenT.ChildTwo\">ChildTwo</a></li>\n", w.render());
		assertHasRegexp("</ul>\n", w.render());
	}

	public void testTocOnRoot() throws Exception
	{
		TOCWidget widget = new TOCWidget(new WidgetRoot(root), "!contents\n");
		String html = widget.render();
		assertHasRegexp("ParenT", html);
		assertHasRegexp("ParentTwo", html);
	}

	public void testDisplaysVirtualChildren() throws Exception
	{
		WikiPage page = root.addPage("VirtualParent");
		PageData data = page.getData();
		data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http://localhost:" + FitnesseUtil.port + "/ParenT");
		page.commit(data);
		try
		{
			FitnesseUtil.startFitnesse(root);
			TOCWidget widget = new TOCWidget(new WidgetRoot(page), "!contents\n");
			String html = widget.render();

			assertSubString("<li><a href=\"VirtualParent.ChildOne\"><i>ChildOne</i></a></li>\n", html);
			assertSubString("<li><a href=\"VirtualParent.ChildTwo\"><i>ChildTwo</i></a></li>\n", html);
		}
		finally
		{
			FitnesseUtil.stopFitnesse();
		}
	}

	protected String getRegexp()
	{
		return TOCWidget.REGEXP;
	}
}
