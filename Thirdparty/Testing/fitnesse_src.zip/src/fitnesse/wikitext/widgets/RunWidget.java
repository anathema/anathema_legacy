// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext.widgets;

import fitnesse.wikitext.WikiWidget;
import fitnesse.wiki.PageCrawler;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RunWidget extends WikiWidget
{
	public static final String REGEXP = "^![rR] [^\r\n]*";
	private static final Pattern pattern = Pattern.compile("^![rR] (.*)");

	public String className = null;

	public RunWidget(ParentWidget parent, String text)
	{
		super(parent);
		Matcher match = pattern.matcher(text);
		if(match.find())
			className = match.group(1);
	}

	public String render() throws Exception
	{
		StringBuffer html = new StringBuffer("<a href=\"");
		html.append(new PageCrawler().getQualifiedName(getWikiPage()));
		html.append("?responder=start&className=").append(className);
		html.append("\">");
		html.append("<img src=\"/files/images/runArrow.gif\" border=\"0\"><b><i> ");
		html.append(className);
		html.append("</i></b>");
		html.append("</a>");

		return html.toString();
	}

	public String asWikiText() throws Exception
	{
		return "!r " + className;
	}

}
