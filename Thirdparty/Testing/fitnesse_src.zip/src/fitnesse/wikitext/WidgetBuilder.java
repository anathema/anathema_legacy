// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext;

import fitnesse.wikitext.widgets.*;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WidgetBuilder
{
	private static Class[] referenceModifyingWidgetClasses = new Class[]{
		WikiWordWidget.class,
		PreProcessorLiteralWidget.class,
		CommentWidget.class,
		PreformattedWidget.class,
		ImageWidget.class,
		LinkWidget.class,
		AliasLinkWidget.class,
		ClasspathWidget.class,
		FixtureWidget.class,
		RunWidget.class
	};

	private static Class[] preprocessingWidgetClasses = new Class[]{
		PreProcessorLiteralWidget.class,
		VariableDefinitionWidget.class,
		VariableWidget.class,
		IncludeWidget.class
	};

	private static Class[] htmlWidgetClasses = new Class[]{
		CommentWidget.class,
		LiteralWidget.class,
		WikiWordWidget.class,
		BoldWidget.class,
		ItalicWidget.class, // Italic must follow bold because '''x''' matches the italic pattern.
		PreformattedWidget.class,
		HruleWidget.class,
		HeaderWidget.class,
		CenterWidget.class,
		NoteWidget.class,
		TableWidget.class,
		ListWidget.class,
		RunWidget.class,
		ClasspathWidget.class,
		LineBreakWidget.class,
		ImageWidget.class,
		LinkWidget.class,
		TOCWidget.class,
		AliasLinkWidget.class,
		VirtualWikiWidget.class,
		StrikeWidget.class,
		LastModifiedWidget.class,
		FixtureWidget.class
	};

	public static WidgetBuilder htmlWidgetBuilder = new WidgetBuilder(htmlWidgetClasses);
	public static WidgetBuilder preprocessingWidgetBuilder = new WidgetBuilder(preprocessingWidgetClasses);
	public static WidgetBuilder virtualWidgetBuilder = new WidgetBuilder(new Class[]{VirtualWikiWidget.class});
	public static WidgetBuilder classpathWidgetBuilder = new WidgetBuilder(new Class[]{ClasspathWidget.class});
	public static WidgetBuilder fixtureWidgetBuilder = new WidgetBuilder(new Class[]{FixtureWidget.class});
	public static WidgetBuilder literalWidgetBuilder = new WidgetBuilder(new Class[]{PreProcessorLiteralWidget.class});
	public static WidgetBuilder referenceModifyingWidgetBuilder = new WidgetBuilder(referenceModifyingWidgetClasses);

	private Class[] widgetClasses;
	private Pattern widgetPattern;

	public WidgetBuilder(Class[] widgetClasses)
	{
		this.widgetClasses = widgetClasses;
		widgetPattern = buildCompositeWidgetPattern();
	}

	private Pattern buildCompositeWidgetPattern()
	{
		StringBuffer pattern = new StringBuffer();
		for(int i = 0; i < widgetClasses.length; i++)
		{
			Class widgetClass = widgetClasses[i];
			String regexp = getRegexpFromWidgetClass(widgetClass);
			pattern.append("(").append(regexp).append(")");
			if(i != (widgetClasses.length - 1))
				pattern.append("|");
		}
		return Pattern.compile(pattern.toString(), Pattern.DOTALL | Pattern.MULTILINE);
	}

	private static String getRegexpFromWidgetClass(Class widgetClass)
	{
		String regexp = null;
		try
		{
			Field f = widgetClass.getField("REGEXP");
			regexp = (String) f.get(widgetClass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return regexp;
	}

	public WikiWidget makeWidget(ParentWidget parent, Matcher matcher) throws Exception
	{
		int group = getGroupMatched(matcher);
		Class widgetClass = widgetClasses[group - 1];
		return constructWidget(widgetClass, parent, matcher.group());
	}

	private WikiWidget constructWidget(Class widgetClass, ParentWidget parent, String text) throws Exception
	{
		try
		{
			Constructor widgetConstructor = widgetClass.getConstructor(new Class[]{ParentWidget.class, String.class});
			WikiWidget widget = (WikiWidget) widgetConstructor.newInstance(new Object[]{parent, text});
			return widget;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			Exception exception = new Exception("Widget Construction failed for " + widgetClass.getName() + "\n" + e.getMessage());
			exception.setStackTrace(e.getStackTrace());
			throw exception;
		}
	}

	public int getGroupMatched(Matcher matcher)
	{
		for(int i = 1; i <= matcher.groupCount(); i++)
		{
			if(matcher.group(i) != null)
				return i;
		}
		return -1;
	}

	public Pattern getWidgetPattern()
	{
		return widgetPattern;
	}
}
