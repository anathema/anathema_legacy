// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext;

import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.widgets.ParentWidget;

public abstract class WikiWidget
{
	protected ParentWidget parent = null;

	protected WikiWidget(ParentWidget parent)
	{
		this.parent = parent;
		if(this.parent != null)
			this.parent.addChild(this);
	}

	public abstract String render() throws Exception;

	public void acceptVisitor(WidgetVisitor visitor) throws Exception
	{
		visitor.visit(this);
	}

	public WikiPage getWikiPage()
	{
		return parent.getWikiPage();
	}

	public void brownText(StringBuffer buffer, String text)
	{
		buffer.append("<i><font color=\"#A02020\">");
		buffer.append(text);
		buffer.append("</font></i>");
	}

	public String asWikiText() throws Exception
	{
		return "WIKI_TEXT";
	}
}

