// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext;

import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All Test Suite");
		suite.addTest(new TestSuite(WidgetBuilderTest.class));
		suite.addTest(new TestSuite(WikiTextTranslatorTest.class));
		suite.addTest(fitnesse.wikitext.widgets.AllTestSuite.suite());
		return suite;
	}
}
