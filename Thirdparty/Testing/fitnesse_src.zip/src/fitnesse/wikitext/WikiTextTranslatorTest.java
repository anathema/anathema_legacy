// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.wikitext;

import fitnesse.wiki.*;
import fitnesse.wikitext.widgets.WidgetRoot;
import junit.framework.TestCase;
import junit.swingui.TestRunner;

public class WikiTextTranslatorTest extends TestCase
{
	private WikiPage root;
	private WikiPage page;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"fitnesse.wikitext.WikiTextTranslatorTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		page = root.addPage("WidgetRoot");
	}

	public void tearDown() throws Exception
	{
	}

	public void testTranslation1() throws Exception
	{
		String wikiText = "!c !1 This is a WidgetRoot\n" +
		  "\n" +
		  "''' ''Some Bold and Italic text'' '''\n";
		String html = "<center><h1>This is a <a href=\"WidgetRoot\">WidgetRoot</a></h1></center>" +
		  "<br>" +
		  "<b> <i>Some Bold and Italic text</i> </b><br>";
		assertEquals(html, translate(wikiText, page));
	}

	public void testHtmlEscape() throws Exception
	{
		String wikiText = "<h1>this \"&\" that</h1>";
		String html = "&lt;h1&gt;this \"&amp;\" that&lt;/h1&gt;";
		assertEquals(html, translate(wikiText, new MockWikiPage()));
	}

	public void testTableHtml() throws Exception
	{
		String wikiText = "|this|is|a|table|\n|that|has|four|columns|\n";
		String html = "<table border=\"1\" cellspacing=\"0\">\n<tr><td>this</td><td>is</td><td>a</td><td>table</td></tr>\n" +
		  "<tr><td>that</td><td>has</td><td>four</td><td>columns</td></tr>\n</table>\n";
		assertEquals(html, translate(wikiText, new MockWikiPage()));
	}

	private static String translate(String value, WikiPage source) throws Exception
	{
		WidgetRoot page = new WidgetRoot(value, source);
		return page.render();
	}
}