// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import fitnesse.*;
import fitnesse.wiki.*;

public class FitnesseUtil
{
	private static Fitnesse instance = null;
	public static final int port = 1999;

	public static void startFitnesse(WikiPage root) throws Exception
	{
		FitNesseContext context = new FitNesseContext();
		context.root = root;
		context.port = port;
		context.rootPath = "TestDir";
		instance = new Fitnesse(context);
		instance.start();
	}

	public static void stopFitnesse() throws Exception
	{
		instance.stop();
		FileUtil.deleteFileSystemDirectory("TestDir");
	}

	public static void bindVirtualLinkToPage(InMemoryPage host, WikiPage proxy) throws Exception
	{
		VirtualCouplingPage coupling = new VirtualCouplingPage(host, proxy);
		host.setVirtualCoupling(coupling);
	}
}
