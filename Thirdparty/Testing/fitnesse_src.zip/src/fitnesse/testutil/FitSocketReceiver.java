// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import java.net.*;
import fitnesse.http.HttpRequest;
import fitnesse.responders.run.SocketDealer;

public class FitSocketReceiver
{
	public ServerSocket serverSocket;
	public Socket socket;
	public int port = 9123;
	public SocketDealer dealer;

	public FitSocketReceiver(int port, SocketDealer dealer)
	{
		this.port = port;
		this.dealer = dealer;
	}

	public void receiveSocket() throws Exception
	{
		serverSocket = new ServerSocket(port);
		new Thread(){
			public void run()
			{
				try
				{
					socket = serverSocket.accept();
					HttpRequest request = new HttpRequest(socket.getInputStream());
					request.parse();
					socket.getOutputStream().write("0000000000".getBytes());
					int ticket = Integer.parseInt(request.getInput("ticket").toString());
					dealSocket(ticket);
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

			}
		}.start();
	}

	protected void dealSocket(int ticket) throws Exception
	{
		dealer.dealSocketTo(ticket, new SimpleSocketDoner(socket));
	}

	public void close() throws Exception
	{
		if(serverSocket != null)
			serverSocket.close();
		if(socket != null)
			socket.close();
	}
}
