// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

public class Hello
{
	public static String message = "Hello, World!";

	public static void main(String[] args) throws Exception
	{
		while(System.in.read() != -1);
			System.out.println(message);
	}
}