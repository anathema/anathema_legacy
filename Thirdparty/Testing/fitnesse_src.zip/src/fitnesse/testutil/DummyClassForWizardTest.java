// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import fit.ColumnFixture;

public class DummyClassForWizardTest extends ColumnFixture
{
	public int v1;
	public int f1(){return 0;};
}
