// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import java.net.*;
import java.io.*;

public class PipedSocket extends Socket
{
	protected PipedInputStream input;
	protected PipedOutputStream output;
	public PipedSocket otherSide;
	private boolean closed;

	public PipedSocket() throws Exception
	{
		input = new PipedInputStream();
		PipedOutputStream otherOutput = new PipedOutputStream(input);
		output = new PipedOutputStream();
		PipedInputStream otherInput = new PipedInputStream(output);
		otherSide = new PipedSocket(otherInput, otherOutput, this);
	}

	protected PipedSocket(PipedInputStream input, PipedOutputStream output, PipedSocket counterPart)
	{
		this.input = input;
		this.output = output;
		this.otherSide = counterPart;
	}

	public InputStream getInputStream()
	{
		return input;
	}

	public OutputStream getOutputStream()
	{
		return output;
	}

	public void close()
	{
		closed = true;
		try
		{
			input.close();
			output.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	public boolean isClosed()
	{
		return closed;
	}
}
