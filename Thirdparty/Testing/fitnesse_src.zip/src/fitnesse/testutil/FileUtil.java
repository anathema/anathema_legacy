// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import java.io.*;

public class FileUtil
{

	public static void createFile(String path, String content)
	{
		try
		{
			FileOutputStream file = new FileOutputStream(path);
			file.write(content.getBytes());
			file.close();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	public static boolean makeDir(String path)
	{
		return new File(path).mkdir();
	}

	public static void deleteFileSystemDirectory(String dirPath)
	{
		deleteFileSystemDirectory(new File(dirPath));
	}

	public static void deleteFileSystemDirectory(File current)
	{
		File[] files = current.listFiles();

		for(int i = 0; files != null && i < files.length; i++)
		{
			File file = files[i];
			if(file.isDirectory())
				deleteFileSystemDirectory(file);
			else
				file.delete();
		}
		current.delete();
	}

	public static String getFileContent(String path) throws IOException
	{
		File input = new File(path);
		return getFileContent(input);
	}

	public static String getFileContent(File input) throws IOException
	{
		char chars[] = new char[(int) (input.length())];
		FileReader in = new FileReader(input);
		in.read(chars);
		in.close();
		return new String(chars);
	}
}
