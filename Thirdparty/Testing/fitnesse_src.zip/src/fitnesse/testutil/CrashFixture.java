// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.testutil;

import fit.Fixture;

public class CrashFixture extends Fixture {
  public CrashFixture() {
    System.exit(1);
  }
}
