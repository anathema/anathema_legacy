// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

//TODO move me into the testutil package
public class MockCommandRunner extends CommandRunner
{

	public MockCommandRunner()
	{
		super("", "");
	}

	public MockCommandRunner(String command, int exitCode)
	{
		super(command, "");
		this.exitCode = exitCode;
	}

	public void setOutput(String output)
	{
		outputBuffer = new StringBuffer(output);
	}

	public void setError(String error)
	{
		errorBuffer = new StringBuffer(error);
	}

	public void addException(Exception e)
	{
		exceptions.add(e);
	}

	public void setExitCode(int i)
	{
		exitCode = i;
	}
}
