// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.testutil.RegexTest;
import fitnesse.wiki.*;

public class PageReferenceRenamerTest extends RegexTest
{
	WikiPage root;
	WikiPage subWiki;
	WikiPage subWiki_pageOne;
	WikiPage subWiki_pageTwo;
	WikiPage subWiki_pageTwo_pageTwoChild;

	PageReferenceRenamer renamer;

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		subWiki = root.addPage("SubWiki", "");
		renamer = new PageReferenceRenamer(root);
		subWiki_pageTwo = subWiki.addPage("PageTwo", "");
		subWiki_pageTwo_pageTwoChild = subWiki_pageTwo.addPage("PageTwoChild", "");
	}

	public void testReferencesOnPageOne_1() throws Exception
	{
		checkChangesOnPageOne("Stuff PageTwo Stuff\n", "Stuff PageThree Stuff\n");
	}

	public void testReferencesOnPageOne_2() throws Exception
	{
		checkChangesOnPageOne("Stuff !-PageTwo-! Stuff\n", "Stuff !-PageTwo-! Stuff\n");
	}

	public void testReferencesOnPageOne_3() throws Exception
	{
		checkChangesOnPageOne("Stuff PageOne.PageTwo Stuff\n", "Stuff PageOne.PageTwo Stuff\n");
	}

	public void testReferencesOnPageOne_4() throws Exception
	{
		checkChangesOnPageOne("Stuff .SubWiki.PageTwo.PageTwoChild Stuff\n", "Stuff .SubWiki.PageThree.PageTwoChild Stuff\n");
	}

	public void testReferencesOnPageOne_5() throws Exception
	{
		checkChangesOnPageOne("Stuff ^PageTwo Stuff\n", "Stuff ^PageTwo Stuff\n");
	}

	public void testReferencesOnPageOne_6() throws Exception
	{
		checkChangesOnPageOne("# Stuff PageTwo Stuff\n", "# Stuff PageTwo Stuff\n");
	}

	public void testReferencesOnPageOne_7() throws Exception
	{
		checkChangesOnPageOne("{{{Stuff PageTwo Stuff}}}\n", "{{{Stuff PageTwo Stuff}}}\n");
	}

	public void testReferencesOnPageOne_8() throws Exception
	{
		checkChangesOnPageOne("Stuff .SubWiki.PageTwo Stuff\n", "Stuff .SubWiki.PageThree Stuff\n");
	}

	public void testReferencesOnPageOne_9() throws Exception
	{
		checkChangesOnPageOne("Stuff .SubWiki.PageTwo.NoPage Stuff\n", "Stuff .SubWiki.PageThree.NoPage Stuff\n");
	}

	public void testTestReferencesToSubWiki_1() throws Exception
	{
		PageData data = subWiki.getData();
		data.setContent("Stuff ^PageTwo Stuff\n");
		subWiki.commit(data);

		renamer.renameReferences(subWiki_pageTwo, "PageThree");
		String updatedSubWikiContent = subWiki.getData().getContent();
		assertEquals("Stuff ^PageThree Stuff\n", updatedSubWikiContent);
	}

	public void testTestReferencesToSubWiki_2() throws Exception
	{
		PageData data = subWiki.getData();
		data.setContent("Stuff ^PageTwo.DeepPage Stuff\n");
		subWiki.commit(data);

		renamer.renameReferences(subWiki_pageTwo, "PageThree");
		String updatedSubWikiContent = subWiki.getData().getContent();
		assertEquals("Stuff ^PageThree.DeepPage Stuff\n", updatedSubWikiContent);
	}

	private void checkChangesOnPageOne(String beforeText, String expectedAfterText) throws Exception
	{
		subWiki_pageOne = subWiki.addPage("PageOne", beforeText);
		renamer.renameReferences(subWiki_pageTwo, "PageThree");
		subWiki_pageOne = subWiki.getChildPage("PageOne");
		String updatedPageOneContent = subWiki_pageOne.getData().getContent();
		assertEquals(expectedAfterText, updatedPageOneContent);
	}

	public void testRenameParentPage() throws Exception
	{
		PageData pageTwoChildData = subWiki_pageTwo_pageTwoChild.getData();
		pageTwoChildData.setContent("gunk .SubWiki.PageTwo gunk");
		subWiki_pageTwo_pageTwoChild.commit(pageTwoChildData);
		renamer.renameReferences(subWiki_pageTwo, "PageThree");
		String updatedContent = subWiki_pageTwo_pageTwoChild.getData().getContent();
		assertEquals("gunk .SubWiki.PageThree gunk", updatedContent);
	}

	public void testRenameParentWithReferenceOnSibling() throws Exception
	{
		WikiPage pageOne = subWiki.addPage("PageOne", "gunk ^SubPage gunk");
		renamer.renameReferences(subWiki, "RenamedSubWiki");
		String updatedContent = pageOne.getData().getContent();
		assertEquals("gunk ^SubPage gunk", updatedContent);
	}

	public void testRenameParentWithSubPageReferenceOnSibling() throws Exception
	{
		WikiPage pageOne = subWiki.addPage("PageOne", "gunk PageTwo gunk");
		renamer.renameReferences(subWiki, "RenamedSubWiki");
		String updatedContent = pageOne.getData().getContent();
		assertEquals("gunk PageTwo gunk", updatedContent);
	}

	public void testRenameSiblingOfRoot() throws Exception
	{
		WikiPage source = root.addPage("SourcePage", "gunk TargetPage gunk");
		WikiPage target = root.addPage("TargetPage");
		renamer.renameReferences(target, "RenamedPage");
		String updatedSourceContent = source.getData().getContent();
		assertEquals("gunk RenamedPage gunk", updatedSourceContent);
	}

	public void testRenameSubpageOfRoot() throws Exception
	{
		WikiPage source = root.addPage("SourcePage", "gunk ^TargetPage gunk");
		WikiPage target = source.addPage("TargetPage");
		renamer.renameReferences(target, "RenamedPage");
		String updatedSourceContent = source.getData().getContent();
		assertEquals("gunk ^RenamedPage gunk", updatedSourceContent);
	}

	public void testImageNotChanged() throws Exception
	{
		final String IMAGE_WIDGET = "!img http://PageTwo.jpg";
		checkChangesOnPageOne(IMAGE_WIDGET, IMAGE_WIDGET);
	}

	public void testLinkNotChanged() throws Exception
	{
		final String LINK_WIDGET = "http://PageTwo";
		checkChangesOnPageOne(LINK_WIDGET, LINK_WIDGET);
	}

	public void testPathNotChanged() throws Exception
	{
		final String PATH_WIDGET = "!path PageTwo";
		checkChangesOnPageOne(PATH_WIDGET, PATH_WIDGET);
	}

	public void testFixtureNotChanged() throws Exception
	{
		final String FIXTURE_WIDGET = "!fixture PageTwo";
		checkChangesOnPageOne(FIXTURE_WIDGET, FIXTURE_WIDGET);
	}

	public void testRunWidgetNotChanged() throws Exception
	{
		final String RUN_WIDGET = "!r PageTwo";
		checkChangesOnPageOne(RUN_WIDGET, RUN_WIDGET);
	}

	public void testAliasTagNotChanged() throws Exception
	{
		final String ALIAS_LINK = "[[PageTwo][MyPageTwo]]";
		checkChangesOnPageOne(ALIAS_LINK, ALIAS_LINK);
	}

	public void testAliasLinkRenamed() throws Exception
	{
		checkChangesOnPageOne("gunk [[gunk][PageTwo]] gunk", "gunk [[gunk][PageThree]] gunk");
	}
}

