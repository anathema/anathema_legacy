// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fit.Counts;

public interface FitClientListener
{
	public void acceptOutput(String output) throws Exception;
	public void acceptResults(Counts counts) throws Exception;
  public void exceptionOccurred(Exception e);
}
