// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import junit.framework.*;

public class AllTestSuite
{
	public static Test suite()
	{
		TestSuite suite = new TestSuite("All component tests");
		suite.addTest(new TestSuite(SaveRecorderTest.class));
		suite.addTest(new TestSuite(RecentChangesTest.class));
		suite.addTest(new TestSuite(SearcherTest.class));
		suite.addTest(new TestSuite(CommandRunnerTest.class));
		suite.addTest(new TestSuite(LoggerTest.class));
		suite.addTest(new TestSuite(ClassPathBuilderTest.class));
		suite.addTest(new TestSuite(WhereUsedTest.class));
		suite.addTest(new TestSuite(PageReferenceRenamerTest.class));
		suite.addTest(new TestSuite(FitClientTest.class));

		return suite;
	}
}
