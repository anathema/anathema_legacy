// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.*;
import fitnesse.wikitext.widgets.WidgetRoot;
import fitnesse.wikitext.*;

public abstract class ReferenceRenamer extends FitnesseTraversal
{
	protected WikiPage root;

	public ReferenceRenamer(WikiPage root)
	{
		this.root = root;
	}

	protected void renameReferences() throws Exception
	{
		this.processPagesUnder(root);
	}

	protected void processPage(WikiPage currentPage) throws Exception
	{
		PageData data = currentPage.getData();
		String content = data.getContent();
		WidgetRoot widgetRoot = new WidgetRoot(content, currentPage, WidgetBuilder.referenceModifyingWidgetBuilder);
		widgetRoot.acceptVisitor(getVisitor());

		String newContent = widgetRoot.asWikiText();
		boolean pageHasChanged = !newContent.equals(content);
		if (pageHasChanged) {
			data.setContent(newContent);
			currentPage.commit(data);
		}
	}

	protected abstract WidgetVisitor getVisitor();
}
