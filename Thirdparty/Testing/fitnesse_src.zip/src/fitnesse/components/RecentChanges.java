// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.*;

import java.util.*;
import java.io.*;
import java.text.*;

public class RecentChanges
{
	private static final String RECENT_CHANGES = "RecentChanges";
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("kk:mm:ss EEE, MMM dd, yyyy");

	public static void updateRecentChanges(WikiPage pageSource, String resource) throws Exception
	{
		createRecentChangesIfNecessary(pageSource);
		addCurrentPageToRecentChanges(pageSource, resource);
	}

	public static List getRecentChangesLines(PageData recentChangesdata) throws Exception
	{
		String content = recentChangesdata.getContent();
		BufferedReader reader = new BufferedReader(new StringReader(content));
		List lines = new ArrayList();
		String line = null;
		while((line = reader.readLine()) != null)
			lines.add(line);
		return lines;
	}

	private static void addCurrentPageToRecentChanges(WikiPage root, String resource) throws Exception
	{
		WikiPage recentChanges = root.getChildPage(RECENT_CHANGES);
		PageData recentChangesdata = recentChanges.getData();
		List lines = getRecentChangesLines(recentChangesdata);
		removeDuplicate(lines, resource);
		lines.add(0, makeRecentChangesLine(resource));
		trimExtraLines(lines);
		String content = convertLinesToWikiText(lines);
		recentChangesdata.setContent(content);
		recentChanges.commitWithoutVersion(recentChangesdata);
	}

	private static void createRecentChangesIfNecessary(WikiPage pageSource) throws Exception
	{
		if(!pageSource.hasChildPage(RECENT_CHANGES))
			pageSource.addPage(RECENT_CHANGES, "");
	}

	private static String makeRecentChangesLine(String resource)
	{
		return "|" + resource + "|" + dateFormat.format(new Date()) + "|";
	}

	private static void removeDuplicate(List lines, String resource)
	{
		for(ListIterator iterator = lines.listIterator(); iterator.hasNext();)
		{
			String s = (String) iterator.next();
			if(s.startsWith("|" + resource + "|"))
				iterator.remove();
		}
	}

	private static String convertLinesToWikiText(List lines)
	{
		StringBuffer buffer = new StringBuffer();
		for(Iterator iterator = lines.iterator(); iterator.hasNext();)
		{
			String s = (String) iterator.next();
			buffer.append(s).append("\n");
		}
		return buffer.toString();
	}

	private static void trimExtraLines(List lines)
	{
		while(lines.size() > 100)
			lines.remove(100);
	}
}
