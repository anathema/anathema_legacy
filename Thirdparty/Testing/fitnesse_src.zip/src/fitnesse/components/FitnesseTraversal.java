// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.*;
import java.util.*;

public abstract class FitnesseTraversal
{
	protected abstract void processPage(WikiPage currentPage) throws Exception;

	protected void processPagesUnder(WikiPage treeRoot) throws Exception
	{
		List children = treeRoot.getChildren();
		for(Iterator iterator = children.iterator(); iterator.hasNext();)
		{
			WikiPage wikiPage = (WikiPage) iterator.next();
			processPage(wikiPage);
			processPagesUnder(wikiPage);
		}
	}
}
