// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import java.io.*;
import java.text.DecimalFormat;
import java.net.Socket;
import fit.Counts;
import fitnesse.http.*;
import fitnesse.responders.run.*;

public class FitClient extends CommandRunner implements SocketSeeker
{
	public static int TIMEOUT = 60000;
	private static final DecimalFormat format = new DecimalFormat("0000000000");

	private FitClientListener listener;
	private int port;
	private int ticketNumber;
	private Socket fitSocket;
	private OutputStream fitInput;
	private StreamReader fitOutput;

	private int sent = 0;
	private int received = 0;
	private boolean isDoneSending = false;
	private boolean connectionEstablished = false;
	private SocketDoner doner;
	private Thread fitListeningThread;

	public FitClient(FitClientListener listener, String command, int port, SocketDealer dealer) throws Exception
	{
		super(command, "");
		this.listener = listener;
		this.port = port;
		ticketNumber = dealer.seekingSocket(this);
	}

	public void start() throws Exception
	{
		super.start();

		new Thread(new TimeoutRunnable(), "FitClient timeout").start();
		new Thread(new EarlyTerminationRunnable(), "FitClient early termination").start();
		waitForConnection();
	}

	void setTicketNumber(int ticketNumber)
	{
		this.ticketNumber = ticketNumber;
	}

	public void acceptSocketFrom(SocketDoner doner) throws Exception
	{
		this.doner = doner;
		fitSocket = doner.donateSocket();
		fitInput = fitSocket.getOutputStream();
		fitOutput = new StreamReader(fitSocket.getInputStream());

		fitListeningThread = new Thread(new FitListeningRunnable(), "FitClient fitOutput");
		fitListeningThread.start();

		synchronized(this)
		{
			this.notify();
		}

		connectionEstablished = true;
	}

	public boolean isSuccessfullyStarted()
	{
		return fitSocket != null;
	}

	public void send(String data) throws Exception
	{
		writeData(data, fitInput);
		sent++;
	}

	public void done() throws Exception
	{
		fitInput.write(format.format(0).getBytes());
		fitInput.flush();
		isDoneSending = true;
	}

	public void join() throws Exception
	{
		try
		{
			super.join();
			if(fitListeningThread != null)
				fitListeningThread.join();
			if(doner != null)
				doner.finishedWithSocket();
		}
		catch(InterruptedException e)
		{
		}
	}

	public void kill() throws Exception
	{
		if(fitListeningThread != null)
			fitListeningThread.interrupt();
		super.kill();
	}

	public void exceptionOccurred(Exception e)
	{
		super.exceptionOccurred(e);
		listener.exceptionOccurred(e);
	}

	private void waitForConnection() throws InterruptedException
	{
		synchronized(this)
		{
			if(fitSocket == null)
				this.wait();
		}
	}

	protected void sendInput() throws Exception
	{
		writeData(getHost(), stdin);
		writeData(getHttp(), stdin);
	}

	public static void writeData(String data, OutputStream output) throws Exception
	{
		byte[] bytes = writeData_getBytes(data);
		int length = writeData_getBytesLength(bytes);
		String formattedLength = writeData_format(length);
		byte[] lengthBytes = writeData_getFormattedLength(formattedLength);
		writeData_writeLengthBytes(output, lengthBytes);
		writeData_writeBytes(output, bytes);
		writeData_flush(output);
	}

	private static void writeData_flush(OutputStream output) throws IOException
	{
		output.flush();
	}

	private static void writeData_writeBytes(OutputStream output, byte[] bytes) throws IOException
	{
		output.write(bytes);
	}

	private static void writeData_writeLengthBytes(OutputStream output, byte[] lengthBytes) throws IOException
	{
		output.write(lengthBytes);
	}

	private static byte[] writeData_getFormattedLength(String formattedLength)
	{
		byte[] lengthBytes = formattedLength.getBytes();
		return lengthBytes;
	}

	private static String writeData_format(int length)
	{
		String formattedLength = format.format(length);
		return formattedLength;
	}

	private static int writeData_getBytesLength(byte[] bytes)
	{
		int length = bytes.length;
		return length;
	}

	private static byte[] writeData_getBytes(String data)
	{
		byte[] bytes = data.getBytes();
		return bytes;
	}

	private void listenToFit()
	{
		try
		{
			while(!finishedReading())
			{
				int size;
				size = readSize();
				if(size != 0)
				{
					String readValue = fitOutput.read(size);
					if(readValue.length() < size)
						throw new Exception("The output stream was closed before I finished reading");
					listener.acceptOutput(readValue);
				}
				else
				{
					Counts counts = readResults();
					listener.acceptResults(counts);
					received++;
				}
			}
		}
		catch(Exception e)
		{
			exceptionOccurred(e);
		}
	}

  private boolean finishedReading()
	{
		return isDoneSending && received == sent;
	}

	private int readSize() throws Exception
	{
		String sizeString = fitOutput.read(10);
		if(sizeString.length() < 10)
			throw new Exception("A size value could not be read from fitOutput");
		else
			return format.parse(sizeString).intValue();
	}

	private Counts readResults() throws Exception
	{
		Counts counts = new Counts();
		counts.right = readSize();
		counts.wrong = readSize();
		counts.ignores = readSize();
		counts.exceptions = readSize();
		return counts;
	}

	public String getHost()
	{
		return "localhost:" + port;
	}

	public String getHttp()
	{
		HttpRequestBuilder request = new HttpRequestBuilder("/?responder=socketCatcher&ticket=" + ticketNumber);
		return request.getText();
	}

	private class FitListeningRunnable implements Runnable
	{
		public void run()
		{
			listenToFit();
		}
	}

	private class TimeoutRunnable implements Runnable
	{
		long timeSlept = 0;

		public void run()
		{
			try
			{
				Thread.sleep(TIMEOUT);
				synchronized(FitClient.this)
				{
					if(fitSocket == null)
					{
						FitClient.this.notify();
						listener.exceptionOccurred(new Exception("FitClient: communication socket was not received on time."));
					}
				}
			}
			catch(InterruptedException e)
			{
				// ok
			}
		}
	}

	private class EarlyTerminationRunnable implements Runnable
	{
		public void run()
		{
			try
			{
				process.waitFor();
				synchronized(FitClient.this)
				{
					if(! connectionEstablished)
					{
						FitClient.this.notify();
						listener.exceptionOccurred(new Exception("FitClient: external process terminated before a connection could be stablished."));
					}
				}
			}
			catch(InterruptedException e)
			{
				// ok
			}
		}
	}
}
