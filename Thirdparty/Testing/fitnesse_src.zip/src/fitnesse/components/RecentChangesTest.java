// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import junit.swingui.TestRunner;
import fitnesse.wiki.*;
import fitnesse.testutil.RegexTest;

import java.util.*;

public class RecentChangesTest extends RegexTest
{
	private WikiPage rootPage;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"RecentChangesTest"});
	}

	public void setUp() throws Exception
	{
		rootPage = InMemoryPage.makeRoot("RooT");
	}

	public void tearDown() throws Exception
	{
	}

	public void testFirstRecentChange() throws Exception
	{
		assertEquals(false, rootPage.hasChildPage("RecentChanges"));
		RecentChanges.updateRecentChanges(rootPage, "SomeNewPage");
		assertEquals(true, rootPage.hasChildPage("RecentChanges"));
		WikiPage recentChanges = rootPage.getChildPage("RecentChanges");
		List lines = RecentChanges.getRecentChangesLines(recentChanges.getData());
		assertEquals(1, lines.size());
		assertHasRegexp("SomeNewPage", (String) lines.get(0));
	}

	public void testTwoChanges() throws Exception
	{
		RecentChanges.updateRecentChanges(rootPage, "PageOne");
		RecentChanges.updateRecentChanges(rootPage, "PageTwo");
		WikiPage recentChanges = rootPage.getChildPage("RecentChanges");
		List lines = RecentChanges.getRecentChangesLines(recentChanges.getData());
		assertEquals(2, lines.size());
		assertHasRegexp("PageTwo", (String) lines.get(0));
		assertHasRegexp("PageOne", (String) lines.get(1));
	}

	public void testNoDuplicates() throws Exception
	{
		RecentChanges.updateRecentChanges(rootPage, "PageOne");
		RecentChanges.updateRecentChanges(rootPage, "PageOne");
		WikiPage recentChanges = rootPage.getChildPage("RecentChanges");
		List lines = RecentChanges.getRecentChangesLines(recentChanges.getData());
		assertEquals(1, lines.size());
		assertHasRegexp("PageOne", (String) lines.get(0));
	}

	public void testMaxSize() throws Exception
	{
		for(int i = 0; i < 101; i++)
		{
			StringBuffer b = new StringBuffer("LotsOfAs");
			for(int j = 0; j < i; j++)
				b.append("a");
			RecentChanges.updateRecentChanges(rootPage, b.toString());
		}

		WikiPage recentChanges = rootPage.getChildPage("RecentChanges");
		List lines = RecentChanges.getRecentChangesLines(recentChanges.getData());
		assertEquals(100, lines.size());

	}

	public void testCommitWitoutVersion() throws Exception
	{
		RecentChanges.updateRecentChanges(rootPage, "PageOne");
		InMemoryPage recentChanges = (InMemoryPage) rootPage.getChildPage("RecentChanges");
		assertEquals(1, recentChanges.numberOfVersions());
		RecentChanges.updateRecentChanges(rootPage, "PageOne");
		assertEquals(1, recentChanges.numberOfVersions());
	}
}