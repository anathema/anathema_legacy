// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.WikiPage;
import java.util.*;
import java.util.regex.*;

public class Searcher extends FitnesseTraversal implements SearchObserver
{
	Pattern pattern;
	WikiPage root;
	List hits;
	SearchObserver observer;

	public Searcher(String exp, WikiPage root) throws Exception
	{
		pattern = Pattern.compile(exp);
		this.root = root;
		hits = new ArrayList();
	}

	public void hit(WikiPage page) throws Exception
	{
		hits.add(page);
	}

	public void search(SearchObserver observer) throws Exception
	{
		this.observer = observer;
		processPage(root);
		processPagesUnder(root);
	}

	public List getResults() throws Exception
	{
		hits.clear();
		search(this);
		sortHits();
		return hits;
	}

	protected void processPage(WikiPage currentPage) throws Exception
	{
		if(isHit(currentPage))
			observer.hit(currentPage);
	}

	private boolean isHit(WikiPage page) throws Exception
	{
		Matcher match = pattern.matcher(page.getData().getContent());
		return match.find();
	}

	private void sortHits()
	{
		Collections.sort(hits, new Comparer());
	}

	private class Comparer implements Comparator
	{
		public int compare(Object o1, Object o2)
		{
			try
			{
				WikiPage page1 = (WikiPage) o1;
				WikiPage page2 = (WikiPage) o2;
				return page1.getName().compareTo(page2.getName());
			}
			catch(Exception e)
			{
				return 0;
			}
		}
	}
}
