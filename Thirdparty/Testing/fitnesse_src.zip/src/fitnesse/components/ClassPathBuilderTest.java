// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.*;
import fitnesse.testutil.*;
import fitnesse.util.WildcardTest;
import fitnesse.components.ClassPathBuilder;

public class ClassPathBuilderTest extends RegexTest
{
	private WikiPage root;
	private ClassPathBuilder builder;
	String pathSeparator = System.getProperty("path.separator");
	
	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		builder = ClassPathBuilder.instance();
	}

	public void testGetClasspath() throws Exception
	{
		root.addPage("ClassPath", "!path fitnesse.jar\n!path my.jar");
		root.addPage("TestPage", "Test page content.");
		String expected = "fitnesse.jar" + pathSeparator + "my.jar";
		assertEquals(expected, builder.getClasspath(root.getChildPage("TestPage")));
	}

	public void testGetPaths_OneLevel() throws Exception
	{
		String pageContent = "This is some content\n" +
		  "!path aPath\n" +
		  "end of conent\n";
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage page = root.addPage("ClassPath", pageContent);
		String path = builder.getClasspath(page);
		assertEquals("aPath", path);
	}

	public void testGetClassPathMultiLevel() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		root.addPage("ClassPath", "!path path1");
		root.addPage("ProjectOne", "Project 1");
		root.addPage("ProjectOne.ClassPath", "!path path2\n!path path 3");
		root.addPage("ProjectOne.TesT", "this is the test");

		String cp = builder.getClasspath(new PageCrawler().getPage(root, "ProjectOne.TesT"));
		String expected = "path2" + pathSeparator + "\"path 3\"" + pathSeparator + "path1";
		assertEquals(expected, cp);
	}

	public void testLinearClassPath() throws Exception
	{
		WikiPage root = InMemoryPage.makeRoot("RooT");
		WikiPage superPage = root.addPage("SuperPage", "!path superPagePath");
		WikiPage subPage = superPage.addPage("SubPage","!path subPagePath");
		String cp = builder.getClasspath(subPage);
		assertEquals("subPagePath" + pathSeparator + "superPagePath", cp);

	}

	public void testGetClassPathFromPageThatDoesntExist() throws Exception
	{
		String classPath = makeClassPathFromSimpleStructure("somePath");

		assertEquals("somePath", classPath);
	}

	private String makeClassPathFromSimpleStructure(String path) throws Exception
	{
		root.addPage("ClassPath", "!path " + path);
		WikiPage page = new MockingPageCrawler().getPage(root, "SomePage");
		String classPath = builder.getClasspath(page);
		return classPath;
	}

	public void testThatPathsWithSpacesGetQuoted() throws Exception
	{
		root.addPage("ClassPath", "!path Some File.jar");
		WikiPage page = new MockingPageCrawler().getPage(root, "SomePage");

		assertEquals("\"Some File.jar\"", builder.getClasspath(page));

		root.addPage("ClassPath", "!path somefile.jar\n!path Some Dir/someFile.jar");
		assertEquals("somefile.jar" + pathSeparator + "\"Some Dir/someFile.jar\"", builder.getClasspath(page));
	}

	public void testWildCardExpansion() throws Exception
	{
		try
		{
			WildcardTest.makeSampleFiles();

			String classPath = makeClassPathFromSimpleStructure("testDir/*.jar");
			assertHasRegexp("one\\.jar", classPath);
			assertHasRegexp("two\\.jar", classPath);

			classPath = makeClassPathFromSimpleStructure("testDir/*.dll");
			assertHasRegexp("one\\.dll", classPath);
			assertHasRegexp("two\\.dll", classPath);

			classPath = makeClassPathFromSimpleStructure("testDir/one*");
			assertHasRegexp("one\\.dll", classPath);
			assertHasRegexp("one\\.jar", classPath);
			assertHasRegexp("oneA", classPath);
		}
    finally
		{
			WildcardTest.deleteSampleFiles();
		}
	}
}
