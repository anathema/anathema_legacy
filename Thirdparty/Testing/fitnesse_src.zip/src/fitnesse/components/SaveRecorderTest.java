// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import junit.framework.*;
import junit.swingui.TestRunner;
import fitnesse.components.SaveRecorder;
import fitnesse.wiki.*;

public class SaveRecorderTest extends TestCase
{
	public WikiPage somePage;
	public WikiPage root;
//	public WikiPage neverSaved;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"SaveRecorderTest"});
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		somePage = root.addPage("SomePage", "some page");
	}

	public void tearDown() throws Exception
	{
	}

	public void testTiming() throws Exception
	{
		long time = SaveRecorder.pageSaved(somePage.getData());
		assertEquals(true, SaveRecorder.changesShouldBeMerged(time - 1, 0, somePage.getData()));
		assertEquals(false, SaveRecorder.changesShouldBeMerged(time + 1, 0, somePage.getData()));
	}

	public void testDefaultValues() throws Exception
	{
		WikiPage neverSaved = root.addPage("NeverSaved", "never saved");
		assertEquals(false, SaveRecorder.changesShouldBeMerged(12345, 0, neverSaved.getData()));
	}

}
