// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import fitnesse.wiki.WikiPage;
import fitnesse.wikitext.*;

public class MovedPageReferenceRenamer extends ReferenceRenamer
{
	private WikiPage subjectPage;
	private String newParentName;

	public MovedPageReferenceRenamer(WikiPage root)
	{
		super(root);
	}

	public void renameReferences(WikiPage subjectPage, String newParentName) throws Exception
	{
		this.subjectPage = subjectPage;
		this.newParentName = newParentName;
		renameReferences();
	}

	protected WidgetVisitor getVisitor()
	{
		return new MovedPageReferenceRenamingVisitor(subjectPage, newParentName);
	}
}
