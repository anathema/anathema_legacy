// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse.components;

import junit.framework.*;
import fitnesse.wiki.*;
import fitnesse.testutil.FitnesseUtil;
import java.util.*;

public class SearcherTest extends TestCase implements SearchObserver
{
	WikiPage root;
	private WikiPage pageTwo;

	private List hits = new ArrayList();

	public void hit(WikiPage page) throws Exception
	{
		hits.add(page);
	}

	public void setUp() throws Exception
	{
		root = InMemoryPage.makeRoot("RooT");
		root.addPage("PageOne", "has PageOne content");
		root.addPage("PageOne.PageOneChild", "PageChild is a child of PageOne");
		pageTwo = root.addPage("PageTwo", "PageTwo has a bit of content too\n^PageOneChild");
		PageData data = pageTwo.getData();
		data.setAttribute(WikiPageProperties.VIRTUAL_WIKI_ATTRIBUTE, "http://localhost:" + FitnesseUtil.port  + "/PageOne");
		pageTwo.commit(data);
	}

	public void testSearcher() throws Exception
	{
		Searcher searcher = new Searcher("has", root);
		List results = searcher.getResults();
		assertEquals(2, results.size());
		hasNamedPageAtIndex(results, "PageOne", 0);
		hasNamedPageAtIndex(results, "PageTwo", 1);
	}

	public void testSearcherAgain() throws Exception
	{
		Searcher searcher = new Searcher(".", root);
		List results = searcher.getResults();
		assertEquals(3, results.size());
		hasNamedPageAtIndex(results, "PageOne", 0);
		hasNamedPageAtIndex(results, "PageOneChild", 1);
		hasNamedPageAtIndex(results, "PageTwo", 2);
	}

	public void testDontSearchProxyPages() throws Exception
	{
		Searcher searcher = new Searcher(".", pageTwo);
		List results = searcher.getResults();
		assertEquals(1, results.size());
	}

	public void testObserving() throws Exception
	{
		Searcher searcher = new Searcher("has", root);
		searcher.search(this);
		assertEquals(2, hits.size());
	}

	private void hasNamedPageAtIndex(List results, String name, int index) throws Exception
	{
		WikiPage p = (WikiPage)results.get(index);
		assertEquals(name, p.getName());
	}
}
