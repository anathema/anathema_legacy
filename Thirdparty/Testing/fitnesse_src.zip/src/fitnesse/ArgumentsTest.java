// Copyright (C) 2003 by Robert C. Martin and Micah D. Martin. All rights reserved.
// Released under the terms of the GNU General Public License version 2 or later.
package fitnesse;

import junit.framework.*;
import junit.swingui.TestRunner;

public class ArgumentsTest extends TestCase
{
	private Arguments args;

	public static void main(String[] args)
	{
		TestRunner.main(new String[]{"ArgumentsTest"});
	}

	public void setUp() throws Exception
	{
	}

	public void tearDown() throws Exception
	{
	}

	public void testSimpleCommandline() throws Exception
	{
		args = makeArgs(new String[0]);
		assertNotNull(args);
		int port = Integer.parseInt(Arguments.DEFAULT_PORT);
		assertEquals(port, args.getPort());
		assertEquals(Arguments.DEFAULT_DIRECTORY, args.getRootPath());
	}

	private Arguments makeArgs(String[] args)
	{
		return Fitnesse.parseCommandLine(args);
	}

	public void testAllArguments() throws Exception
	{
		args = makeArgs(new String[]{"-p", "81", "-d", "directory", "-r", "root", "-l", "myLogDirectory", "-o", "-e", "22"});
		assertNotNull(args);
		assertEquals(81, args.getPort());
		assertEquals("directory", args.getRootPath());
		assertEquals("root", args.getRootDirectory());
		assertEquals("myLogDirectory", args.getLogDirectory());
		assertTrue(args.isOmittingUpdates());
		assertEquals(22,args.getDaysTillVersionsExpire());
	}

	public void testNotOmitUpdates() throws Exception
	{
		args = makeArgs(new String[]{"-p", "81", "-d", "directory", "-r", "root", "-l", "myLogDirectory"});
		assertNotNull(args);
		assertEquals(81, args.getPort());
		assertEquals("directory", args.getRootPath());
		assertEquals("root", args.getRootDirectory());
		assertEquals("myLogDirectory", args.getLogDirectory());
		assertTrue(!args.isOmittingUpdates());

	}

	public void testBadArgument() throws Exception
	{
		args = makeArgs(new String[]{"-x"});
		assertNull(args);
	}
}
