package eg.bowling;

public interface Bowling
{
	int currentFrame();
	int currentBall();
	int scoreableFrame();
	boolean validGame();
	boolean gameOver();
	boolean isGameOver();
	void roll(int pins);
	int score(int frame);
}
