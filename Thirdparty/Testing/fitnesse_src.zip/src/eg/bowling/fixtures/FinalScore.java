package eg.bowling.fixtures;

import fitnesse.fixtures.TableFixture;
import eg.bowling.*;

public class FinalScore extends TableFixture
{
	private Bowling game;

	protected void doStaticTable(int rows)
	{
		game = new BowlingGame();
		doRolls();
		doScore();
	}

	private void doRolls()
	{
		for(int i = 0; i < 21; i++)
		{
			if(!blank(0, i))
			{
				int pins = getInt(0, i);
				game.roll(pins);
			}
		}
	}

	private void doScore()
	{
		int expected = getInt(0, 21);
		int actual = game.score(10);
		if(actual == expected)
			right(0, 21);
		else
			wrong(0, 21, "" + actual);
	}
}

