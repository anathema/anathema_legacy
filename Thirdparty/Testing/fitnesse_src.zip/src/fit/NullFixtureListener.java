package fit;

public class NullFixtureListener implements FixtureListener
{
	public void tableFinished(Parse table)
	{
	}

	public void tablesFinished(Counts count)
	{
	}
}
