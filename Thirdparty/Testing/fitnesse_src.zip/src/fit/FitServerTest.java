package fit;

import junit.framework.*;
import java.io.*;
import java.net.*;
import fitnesse.http.StreamReader;

public class FitServerTest extends TestCase
{
	private Process process;
	private OutputStream stdin;
	private Socket socket;
	private ServerSocket serverSocket;
	private InputStream socketInput;
	private OutputStream socketOutput;
	private byte[] httpRequest;
	private ByteArrayOutputStream stdoutBytes;
	private String connectionStatusSize = "0000000000";

	public void tearDown() throws Exception
	{
		process.destroy();
		if(socket != null)
			socket.close();
		if(serverSocket != null)
			serverSocket.close();
	}

	public void testSimpleStartUp() throws Exception
	{
		prepareSessionProcess();
		assertEquals("GET /testSocket?id=23\r\n\r\n", new String(httpRequest));
	}

	public void testBadConnection() throws Exception
	{
		String errorMessage = "FAILURE";
		connectionStatusSize = "0000000007";
		prepareSessionProcess();
		socketOutput.write(errorMessage.getBytes());

		int exitValue = process.waitFor();
		assertEquals(-1, exitValue);

		String stdoutString = new String(stdoutBytes.toByteArray());
		assertTrue(stdoutString.indexOf(errorMessage) != -1);
	}

	public void testNonTestInput() throws Exception
	{
		prepareSessionProcess();
		socketOutput.write("0000000020".getBytes());
		socketOutput.write("some untestable text".getBytes());
		socketOutput.flush();
		String output = read(419);
		assertTrue(output.indexOf("Exception") != -1);
		assertTrue(output.indexOf("Can't find tag: table") != -1);
	}

	public void testOneSimpleRun_Fail() throws Exception
	{
		String table = simpleTable("FailFixture");
		prepareSessionProcess();
		checkDocumentExecution(table);
		checkDocumentResults(0, 1, 0, 0);
		terminateSessionProcess();

		assertEquals(1, process.exitValue());
	}

	public void testOneSimpleRun_Pass() throws Exception
	{
		String table = simpleTable("PassFixture");
		prepareSessionProcess();
		checkDocumentExecution(table);
		checkDocumentResults(1, 0, 0, 0);
		terminateSessionProcess();

		assertEquals(0, process.exitValue());
	}

	public void testTwoSimpleRuns() throws Exception
	{
		String table = simpleTable("FailFixture");
		prepareSessionProcess();
		checkDocumentExecution(table);
		checkDocumentResults(0, 1, 0, 0);
		checkDocumentExecution(table);
		checkDocumentResults(0, 1, 0, 0);
		terminateSessionProcess();

		assertEquals(2, process.exitValue());
	}

	public void testOneMulitiTableRun() throws Exception
	{
		String document = simpleTable("FailFixture") + simpleTable("FailFixture");
		prepareSessionProcess();

		socketOutput.write(formattedDocumentSize(document));
		socketOutput.write(document.getBytes());
		socketOutput.flush();
		checkSize("0000000080"); //length of colored FailFixture table
		checkForAttribute_bgcolor();
		checkSize("0000000080"); //length of colored FailFixture table
		checkForAttribute_bgcolor();
		checkSize("0000000000");

		checkDocumentResults(0, 2, 0, 0);
		terminateSessionProcess();
		assertEquals(2, process.exitValue());
	}

	private byte[] formattedDocumentSize(String document)
	{
		return FitServer.format.format(document.length()).getBytes();
	}

	public void testExtraTextIdPrinted() throws Exception
	{
		String document = "<html>" + simpleTable("PassFixture") + "monkey" + simpleTable("PassFixture") + "</html>";
		prepareSessionProcess();

		socketOutput.write(formattedDocumentSize(document));
		socketOutput.write(document.getBytes());
		socketOutput.flush();

		String output = "";
		checkSize("0000000086");
		output += read(86);
		checkSize("0000000093");
		output += read(93);

		assertTrue(output.startsWith("<html>"));
		assertTrue(output.indexOf("monkey") != -1);
		assertTrue(output.endsWith("</html>"));
		terminateSessionProcess();
	}

	private String read(int n) throws Exception
	{
		return new StreamReader(socketInput).read(n);
	}

	private void prepareSessionProcess() throws Exception
	{
		process = Runtime.getRuntime().exec(command());
		stdin = process.getOutputStream();

		stdoutBytes = new ByteArrayOutputStream();

		watchForOutput(process.getInputStream(), new PrintStream(stdoutBytes));
		watchForOutput(process.getErrorStream(), System.err);

		establishConnection();
	}

	private void establishConnection() throws Exception
	{
		serverSocket = new ServerSocket(1234);
		socket = null;

		listenForConnectionSocket();
		sendConnectionParameters();
		waitForConnectionSocket();

		assertNotNull(socket);
		assertNotNull(socketInput);
		assertNotNull(socketOutput);

		httpRequest = new byte[25];
		socketInput.read(httpRequest);

		socketOutput.write(connectionStatusSize.getBytes());
	}

	private void waitForConnectionSocket() throws InterruptedException
	{
		synchronized(serverSocket)
		{
			if(socket == null)
				serverSocket.wait();
		}
	}

	private void listenForConnectionSocket()
	{
		new Thread(){
			public void run()
			{
				try
				{
					synchronized(serverSocket)
					{
						socket = serverSocket.accept();
						socketInput = socket.getInputStream();
						socketOutput = socket.getOutputStream();
						serverSocket.notify();
					}
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}.start();
	}

	private void sendConnectionParameters() throws IOException
	{
		stdin.write("0000000014".getBytes());
		stdin.write("localhost:1234".getBytes());
		stdin.write("0000000025".getBytes());
		stdin.write("GET /testSocket?id=23\r\n\r\n".getBytes());
		stdin.flush();
	}

	private void terminateSessionProcess() throws IOException, InterruptedException
	{
		socketOutput.write("0000000000".getBytes());
		process.waitFor();
		socketInput.close();
	}

	private void watchForOutput(final InputStream processOutput, final PrintStream consoleOutput)
	{
		new Thread(){
			public void run()
			{
				try
				{
					int b = 0;
					while( (b = processOutput.read()) != -1)
						consoleOutput.print((char)b);
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
		}.start();
	}

	private void checkDocumentResults(int right, int wrong, int ignored, int exceptions) throws Exception
	{
    byte[] bytes = new byte[10];
		socketInput.read(bytes);
		int actualRight = FitServer.format.parse(new String(bytes)).intValue();
		socketInput.read(bytes);
		int actualWrong = FitServer.format.parse(new String(bytes)).intValue();
		socketInput.read(bytes);
		int actualIgnored = FitServer.format.parse(new String(bytes)).intValue();
		socketInput.read(bytes);
		int actualExceptions = FitServer.format.parse(new String(bytes)).intValue();

		assertEquals(right, actualRight);
		assertEquals(wrong, actualWrong);
		assertEquals(ignored, actualIgnored);
		assertEquals(exceptions, actualExceptions);
	}

	private void checkDocumentExecution(String table) throws Exception
	{
		socketOutput.write("0000000062".getBytes()); //length of the FailFixture table
		socketOutput.write(table.getBytes());
		socketOutput.flush();
		checkSize("0000000080"); //length of colored FailFixture table
		checkForAttribute_bgcolor();
		checkSize("0000000000");
	}

	private void checkForAttribute_bgcolor() throws Exception
	{
		String output = read(80);
		assertTrue("'bgcolor' attribute was not found", output.indexOf("bgcolor=") != -1);
	}

	private void checkSize(String sizeString) throws Exception
	{
		assertEquals(sizeString, read(10));
	}

	private String command()
	{
		return "java -cp classes fit.FitServer";
	}

	private String simpleTable(String fixtureName)
	{
		return "<table>" +
		  "<tr><td>fitnesse.testutil." + fixtureName + "</td></tr>" +
		  "</table>";
	}
}
