package fit;

public interface FixtureListener
{
	public void tableFinished(Parse table);
	public void tablesFinished(Counts count);
}
