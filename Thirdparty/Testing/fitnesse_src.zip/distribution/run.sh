#!/bin/sh
java -cp fitnesse.jar fitnesse.FitNesse $1 $2 $3 $4 $5

