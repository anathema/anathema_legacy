Fitnesse - www.fitnesse.org
The fully integrated standalone wiki, and acceptance testing framework.
-----------------------------------------------------------------------

REQUIREMENTS:
Java 1.4.0 or newer.
java.exe must be in the system path.

INSTALATION:
Unzip distribution to a reasonable location.

RUNNING FITNESSE:
Windows:
    Double-click run.bat.
Unix:
    Run run.sh.

USAGE:
Navigate to the installation machine in you browser of choice.
If this is the installation machine use http://localhost

Enjoy!

    Micah Martin
    micah@objectmentor.com

Please visit www.fitnesse.org for questions or comments.


