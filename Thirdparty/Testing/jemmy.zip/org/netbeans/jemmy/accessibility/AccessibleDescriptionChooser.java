/*
 * Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License Version
 * 1.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is available at http://www.sun.com/
 * 
 * The Original Code is the Jemmy library.
 * The Initial Developer of the Original Code is Alexandre Iline.
 * All Rights Reserved.
 * 
 * Contributor(s): Alexandre Iline.
 * 
 * $Id: AccessibleDescriptionChooser.java,v 1.1 2002/07/27 00:17:38 jemmy Exp $ $Revision: 1.1 $ $Date: 2002/07/27 00:17:38 $
 * 
 */

package org.netbeans.jemmy.accessibility;

import javax.accessibility.AccessibleContext;

import org.netbeans.jemmy.operators.Operator;
import org.netbeans.jemmy.operators.Operator.StringComparator;

public class AccessibleDescriptionChooser extends AccessibilityChooser {
    String description;
    StringComparator comparator;
    public AccessibleDescriptionChooser(String description, StringComparator comparator) {
        this.description = description;
        this.comparator = comparator;
    }
    public AccessibleDescriptionChooser(String description) {
        this(description, Operator.getDefaultStringComparator());
    }
    public final boolean checkContext(AccessibleContext context) {
        return(comparator.equals(context.getAccessibleDescription(), description));
    }
    public String getDescription() {
        return("JComponent with \"" + description + "\" accessible description");
    }
}
