/*
 * Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License Version
 * 1.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is available at http://www.sun.com/
 * 
 * The Original Code is the Jemmy library.
 * The Initial Developer of the Original Code is Alexandre Iline.
 * All Rights Reserved.
 * 
 * Contributor(s): Alexandre Iline.
 * 
 * $Id: JTreeAPIDriver.java,v 1.4 2003/02/19 04:07:26 jemmy Exp $ $Revision: 1.4 $ $Date: 2003/02/19 04:07:26 $
 * 
 */

package org.netbeans.jemmy.drivers.trees;

import java.awt.event.KeyEvent;

import javax.swing.text.JTextComponent;

import javax.swing.tree.TreePath;

import org.netbeans.jemmy.Timeout;

import org.netbeans.jemmy.drivers.DriverManager;
import org.netbeans.jemmy.drivers.LightSupportiveDriver;
import org.netbeans.jemmy.drivers.TextDriver;
import org.netbeans.jemmy.drivers.TreeDriver;

import org.netbeans.jemmy.operators.ComponentOperator;
import org.netbeans.jemmy.operators.JTextComponentOperator;
import org.netbeans.jemmy.operators.JTreeOperator;

/**
 * TreeDriver for javax.swing.JTree component type.
 * Uses API calls.
 *
 * @author Alexandre Iline(alexandre.iline@sun.com)
 */
public class JTreeAPIDriver extends LightSupportiveDriver implements TreeDriver {
    /**
     * Constructs a JTreeAPIDriver.
     */
    public JTreeAPIDriver() {
	super(new String[] {"org.netbeans.jemmy.operators.JTreeOperator"});
    }

    public void selectItem(ComponentOperator oper, int index) {
	selectItems(oper, new int[] {index});
    }

    public void selectItems(ComponentOperator oper, int[] indices) {
	checkSupported(oper);
	((JTreeOperator)oper).clearSelection();
	((JTreeOperator)oper).addSelectionRows(indices);
    }

    public void expandItem(ComponentOperator oper, int index) {
	checkSupported(oper);
	((JTreeOperator)oper).expandRow(index);
    }

    public void collapseItem(ComponentOperator oper, int index) {
	checkSupported(oper);
	((JTreeOperator)oper).collapseRow(index);
    }

    public void editItem(ComponentOperator oper, int index, Object newValue, Timeout waitEditorTime) {
	JTextComponentOperator textoper = startEditingAndReturnEditor(oper, index, waitEditorTime);
	TextDriver text = DriverManager.getTextDriver(JTextComponentOperator.class);
	text.clearText(textoper);
	text.typeText(textoper, newValue.toString(), 0);
	((JTreeOperator)oper).stopEditing();
    }

    public void startEditing(ComponentOperator oper, int index, Timeout waitEditorTime) {
	startEditing(oper, index, waitEditorTime);
    }

    private JTextComponentOperator startEditingAndReturnEditor(ComponentOperator oper, int index, Timeout waitEditorTime) {
	checkSupported(oper);
	JTreeOperator toper = (JTreeOperator)oper;
	toper.startEditingAtPath(toper.getPathForRow(index));
	toper.getTimeouts().
	    setTimeout("ComponentOperator.WaitComponentTimeout", waitEditorTime.getValue());
	return(new JTextComponentOperator((JTextComponent)toper.
					  waitSubComponent(new JTextComponentOperator.
							   JTextComponentFinder())));
    }
}
