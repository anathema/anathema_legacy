/*
 * Sun Public License Notice
 * 
 * The contents of this file are subject to the Sun Public License Version
 * 1.0 (the "License"). You may not use this file except in compliance with
 * the License. A copy of the License is available at http://www.sun.com/
 * 
 * The Original Code is the Jemmy library.
 * The Initial Developer of the Original Code is Alexandre Iline.
 * All Rights Reserved.
 * 
 * Contributor(s): Alexandre Iline.
 * 
 * $Id: MultiSelListDriver.java,v 1.2 2002/08/07 05:22:27 jemmy Exp $ $Revision: 1.2 $ $Date: 2002/08/07 05:22:27 $
 * 
 */

package org.netbeans.jemmy.drivers;

import org.netbeans.jemmy.operators.ComponentOperator;

/**
 * Defines how to work with lists allowing multiple selection.
 */
public interface MultiSelListDriver extends ListDriver {

    /**
     * Selects some items.
     * @param oper List operator.
     * @param indices Item indices.
     */
    public void selectItems(ComponentOperator oper, int[] indices);
}
