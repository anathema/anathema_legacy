// Copyright (c) 2005 by disy Informationssysteme GmbH
// Created on 07.03.2005
package net.disy.commons.core.testing;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import junit.framework.TestCase;

import net.disy.commons.core.exception.UnreachableCodeReachedException;
import net.disy.commons.core.util.ISimpleBlock;

// NOT_PUBLISHED
public class CoreTestCase extends TestCase {

  public final static void assertThrowsException(Class exceptionClass, ISimpleBlock block) {
    try {
      block.execute();
      fail("expected: " + exceptionClass.getName() + ", actual: no exception thrown"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception thrown) {
      assertIsAssignableFrom(exceptionClass, thrown.getClass());
    }
  }

  public final static void assertThrowsException(Class exceptionClass, ExceptionConvertingBlock block) {
    try {
      block.execute();
      fail("expected: " + exceptionClass.getName() + ", actual: no exception thrown"); //$NON-NLS-1$ //$NON-NLS-2$
    }
    catch (Exception thrown) {
      assertIsAssignableFrom(exceptionClass, thrown.getCause().getClass());
    }
  }
  
  public final static void assertIsAssignableFrom(Class expected, Class actual) {
    assertTrue("expected: " + expected + ", actual: " + actual, expected.isAssignableFrom(actual)); //$NON-NLS-1$ //$NON-NLS-2$
  }

  public final static Object assertSerialization(Object object) {
    try {
      Object deserializedObject = serializeAndDeserialize(object);
      if (object.getClass().isArray()) {
        assertEquals("deserialized vs. original", (Object[]) object, (Object[]) deserializedObject); //$NON-NLS-1$
      }
      else {
        assertEquals("deserialized vs. original", object, deserializedObject); //$NON-NLS-1$
      }
      return deserializedObject;
    }
    catch (Exception e) {
      fail("Unable to Serialize object '" + object + "' " + e); //$NON-NLS-1$ //$NON-NLS-2$
      throw new UnreachableCodeReachedException();
    }
  }

  public final static void assertEquals(Object[] expected, Object[] actual) {
    assertEquals(null, expected, actual);
  }

  public final static void assertEquals(String message, Object[] expected, Object[] actual) {
    message = (message == null) ? "" : message + " - "; //$NON-NLS-1$//$NON-NLS-2$
    if (expected == null) {
      assertNull(message + "actual is not null", actual); //$NON-NLS-1$
      return;
    }
    assertNotNull(message + "actual is null", actual); //$NON-NLS-1$
    assertEquals(message + "array lengths", expected.length, actual.length); //$NON-NLS-1$
    for (int i = 0; i < expected.length; ++i) {
      assertEquals(message + "at index " + i, expected[i], actual[i]); //$NON-NLS-1$
    }
  }

  public static Object serializeAndDeserialize(Object object)
      throws IOException,
      ClassNotFoundException {
    ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
    ObjectOutputStream out = new ObjectOutputStream(byteOut);
    out.writeObject(object);
    ByteArrayInputStream byteIn = new ByteArrayInputStream(byteOut.toByteArray());
    ObjectInputStream in = new ObjectInputStream(byteIn);
    return in.readObject();
  }
}